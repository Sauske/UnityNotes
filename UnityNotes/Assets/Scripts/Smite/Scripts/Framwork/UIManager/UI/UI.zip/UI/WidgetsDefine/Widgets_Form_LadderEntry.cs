namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_LadderEntry
	{
		EN_BravePanel = 0,
		EN_imgBraveProcess = 1,
		EN_txtBraveProcess = 2,
		EN_txtBraveExchange = 3,
		EN_RewardPanel = 4,
		EN_txtRewardTip = 5,
		EN_BPModePanel = 6,
		EN_BPTag1 = 7,
		EN_BPTag2 = 8,
		EN_BPTag5 = 9,
		EN_SuperKingRank = 10,
		EN_pnlGameInfo = 11,
		EN_RewardItemCell1 = 12,
		EN_RewardItemCell2 = 13,
		EN_RewardItemCell1GotText = 14,
		EN_txtContinousWinNum = 15,
		EN_UI_effect = 16,
	}
};