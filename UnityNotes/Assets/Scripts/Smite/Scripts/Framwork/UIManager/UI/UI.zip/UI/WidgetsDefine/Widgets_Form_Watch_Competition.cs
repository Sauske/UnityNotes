namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_Watch_Competition
	{
		EN_DetailControl = 0,
	}
};