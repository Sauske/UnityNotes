namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_MentorPrivilege
	{
		EN_titleLevelCount = 0,
		EN_privilegeLvCount = 1,
		EN_bonusLvCount = 2,
		EN_titleDesc = 3,
		EN_levelRequirement = 4,
		EN_Button_TurnLeft = 5,
		EN_Button_TurnRight = 6,
		EN_TitleCount = 7,
		EN_rewardList = 8,
	}
};