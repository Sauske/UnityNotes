﻿//==================================================================================
/// UI事件枚举
/// @neoyang
/// @2015.03.02
//==================================================================================

using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using Assets.Scripts.GameSystem;
using Assets.Scripts.GameLogic;
using UnityEngine.EventSystems;
using ResData;

#if UNITY_EDITOR
using System.Reflection;
using Assets.Scripts.UI;
#endif

namespace Assets.Scripts.UI
{
    //--------------------------------------------------
    /// UI事件ID
    //--------------------------------------------------    
    public enum enUIEventID
    {
        #region Old_Event_Ids
        None = 0,

        Common_OpenUrl = 6,
        Common_ParticlHide = 7,
        Common_ParticlShow = 8,
        Common_ParticlTimer = 9,  
        Common_SendMsgAlertOpen = 10,
        Common_SendMsgAlertClose = 11, 
        Common_WifiCheckTimer = 12,
        Common_ShowOrHideWifiInfo = 13,
        Common_BattleWifiCheckTimer = 14,
        Common_BattleShowOrHideWifiInfo = 15,
        Common_NewHeroOrSkinFormClose = 16,
		Common_RedDotParsEvent = 17,                    //保存小红点是否删除标记用事件

        //版本更新
        VersionUpdate_ConfirmYYBSaveUpdateApp = 18,
        VersionUpdate_JumpToHomePage = 19,
        VersionUpdate_ConfirmUpdateApp = 20,
        VersionUpdate_QuitApp = 21,
        VersionUpdate_CancelUpdateApp = 22,
        VersionUpdate_ConfirmUpdateResource = 23,
        VersionUpdate_RetryCheckAppVersion = 24,
        VersionUpdate_ConfirmUpdateAppNoWifi = 25,
        VersionUpdate_ConfirmUpdateResourceNoWifi = 26,
        VersionUpdate_RetryCheckFirstExtractResource = 27,
        VersionUpdate_RetryCheckResourceVersion = 28,
        VersionUpdate_OnAnnouncementListElementEnable = 52,
        VersionUpdate_SwitchAnnouncementListElementToFront = 53,
        VersionUpdate_SwitchAnnouncementListElementToBehind = 54,
        VersionUpdate_OnAnnouncementListSelectChanged = 55,
        VersionUpdate_UpdateToPreviousVersion = 56,

        //Cheat相关
        Cheat_TriggerDown = 30,
        Cheat_TriggerUp = 31,
        Cheat_OnIIPSServerSelectChanged = 32,
        Cheat_CheatFormClosed = 33,
        Cheat_ClearCache = 34,
        Cheat_TDirChanged = 35,
        Cheat_OnErrorLogSelectChanged = 36,
        Cheat_HideErrorLogPanel = 37,
        Cheat_AppearErrorLogPanel = 38,
        Cheat_ClearErrorLog = 39,
        Cheat_MaintainBlock = 40,
        Cheat_JoystickConfigChanged = 41,

        //UI Form 通用事件
        UI_OnFormPriorityChanged = 45,
        UI_OnFormVisibleChanged = 46,
        UI_OnFormCloseWithAnimation = 47,

        CheckDevice_Quit = 49,
        Tips_Close = 51,


        //显示道具tips
        Tips_ItemInfoOpen = 60,

        //关闭道具tips
        Tips_ItemInfoClose = 61,

        //显示物品获得详情tips
        Tips_ItemSourceInfoOpen = 62,

        //点击物品获得详情列表项
        Tips_ItemSourceElementClick = 63,

        Tips_Skill_FormOpen = 64,
        Tips_Skill_FormClose = 65,

        //显示道具tips
        Tips_CommonInfoOpen = 66,

        //关闭道具tips
        Tips_CommonInfoClose = 67,

        //autoscroll自动滚动结束
        UIComponent_AutoScroller_Scroll_Finish = 70,

        //大厅到一级入口通用动画过度接口事件
        UIFade_ResetLobbyFormFadeRecover = 73,
        UIFade_CloseFormWithAniPopUp = 74,
        UIFade_CloseFormWithAni = 75,

        UIFade_OpenFormWitAni_Hero = 76,
        UIFade_OpenFormWitAni_Symbol = 77,
        UIFade_OpenFormWitAni_Skill = 78,
        UIFade_OpenFormWitAni_Equip = 79,
        UIFade_OpenFormWitAni_ChatSetting = 80,
        UIFade_OpenFormWitAni_Chengjiu = 81,
        UIFade_OpenFormWitAni_BattleTeam = 82,
        UIFade_OpenFormWitAni_Bag = 83,
        UIFade_OpenFormWitAni_Mishu = 84,
        
        UIFade_OpenFormWitAni_Shop = 85,
        UIFade_OpenFormWitAni_OB = 86,

        UIFade_OpenFormWitAni_Charge = 87,
        UIFade_OpenFormWitAni_Friend = 88,
        UIFade_OpenFormWitAni_Mail = 89,
        UIFade_OpenFormWitAni_Setting = 90,
        
        UIFade_OpenFormWitAni_PvpEntry = 91,
        UIFade_OpenFormWitAni_LadderEntry = 92,
        UIFade_OpenFormWitAni_PveEntry = 93,
        UIFade_OpenFormWitAni_UnionBattleEntry = 94,   
        

        //背包系统
        Bag_OpenForm = 100,
        Bag_OnCloseForm = 101,
        Bag_MenuSelect = 102,
        Bag_SelectItem = 103,
        Bag_SaleItem = 104,
        Bag_UseItem = 105,
        Bag_OpenSaleForm = 106,
        Bag_CloseSaleForm = 107,
        Bag_SaleForm_CountDown = 108,
        Bag_SaleForm_CountUp = 109,
        Bag_SaleForm_CountMax = 110,
        Bag_SaleForm_ConfirSale = 111,
        Bag_AddExp_HoldStart = 112,
        Bag_AddExp_Hold = 113,
        Bag_AddExp_HoldEnd = 114,
        Bag_AddExp_Click = 115,
        Bag_ItemElement_Enable = 116,
        Bag_OpenUseForm = 117,
        Bag_UseForm_CountDown = 118,
        Bag_UseForm_CountUp = 119,
        Bag_UseForm_CountMax = 120,
        Bag_UseItemWithAnimation = 121,           //播放道具使用动画
        Bag_OnUseItemAnimationPlayOver = 122,     //道具使用动画播放完成
        Bag_UseItemWithAnimationConfirm = 123,
        Bag_OnSecurePwdConfirmUse = 124,
        Bag_OnSecurePwdConfirmUseWithAnimation = 125,
        Bag_OnAutoSaleBtnClick = 126,
        Bag_OnSecurePwdConfirmSale = 127,

        //角色属性系统
        HeroView_SortTypeClick = 148,
        HeroView_SortTypeSelect = 149,
        HeroInfo_OpenForm = 150,
        HeroInfo_CloseForm = 151,
        HeroInfo_StepUp = 152,
        HeroInfo_OpenCustomEquipPanel= 153,
        HeroInfo_ViewProperty = 154,
        HeroView_OpenForm = 155,
        HeroView_CloseForm = 156,
        HeroView_MenuSelect = 157,
        HeroView_ItemSelect = 158,
        HeroInfo_MenuSelect = 159,
        HeroInfo_Appear = 160,
        HeroView_SecurePwdConfirmBuyHeroForFriend = 161,
        HeroView_SecurePwdConfirmBuyHeroSkinForFriend = 162,
   //     HeroInfo_AddExp = 163,
        HeroInfo_GotoRank_God = 163,
        HeroInfo_StarUp = 164,
        HeroView_BuyHeroForFriend = 165,
        HeroInfo_TurnLeft = 166,
        HeroInfo_TurnRight = 167,
        HeroInfo_ModelDrag = 168,
        HeroInfo_ConfirmStarUp = 169,
        HeroInfo_ModelClick = 170,
        HeroInfo_MenuSelect_Dummy = 171,
        HeroView_ConfirmBuyHeroForFriend = 172,
        HeroView_ItemEnable = 173,
        HeroView_BuyHero = 174,
        HeroView_OpenBuyHeroForFriend = 175,        
        HeroView_ConfirmBuyHero = 176,
        HeroInfo_ViewStory = 177,
        HeroInfo_FormClose = 178,
        HeroInfo_Advance = 179,

        //装备与合成系统
        EquipInfo_OpenForm = 180,
        EquipInfo_CloseForm = 181,
        EquipInfo_Equip = 182,
        EquipInfo_ShowCombinePanel = 183,
        EquipInfo_CombineMenuSelect = 184,
        EquipInfo_CombineMaterialClick = 185,
        EquipInfo_CombineConfirm = 186,
        
        HeroView_Own_Flag_Change = 187,
        HeroInfo_OpenSkinUrl = 188,
        HeroView_OpenStoryUrl = 189,


        // 闯关
        Adv_OpenChapterForm = 200,        
        Adv_SelectChapter = 201,
        Adv_OpenLevelForm = 202,
        Adv_SelectChapterExternal = 203,
//         Adv_PrevSection = 203,
//         Adv_NextSection = 204,
        Adv_GetSectionReward = 205,
        Adv_OpenChooseHeroForm = 206,
        Adv_Mopup = 207,
        Adv_MopupTenTimes = 208, 
        Adv_OpenTaskPanel = 209,
        Adv_ChooseHeroReady = 210,
        Adv_ConfirmDiamondMopup = 211,
        Adv_DifficultyNormal = 212,
        Adv_DifficultyElite = 213,
        Adv_BuyPlayTime = 214,
        Adv_GetChapterReward = 215,
        Adv_CloseChapterForm = 216,
        Adv_ChapterStartDrag = 217,
        Adv_ConfirmBuyPlayTime = 218,
        Adv_ConfirmItemFullMopup = 219,
        Adv_ConfirmItemFullAdv = 220,
        Adv_ChapterScroll = 221,
        Adv_OpenChapterRewardPanel = 222,
        Adv_CloseChapterRewardPanel = 223,
        Adv_CloseSettleForm = 224,
        Adv_ConfirmTeamPowerCheck = 225,
        Adv_ConfirmTeamNumCheck = 226,
        Adv_SelectPreChapter = 227,
        Adv_SelectNextChapter = 228,
        Adv_ExploreScroll = 229,
        Adv_ExploreSelect = 230,
        Adv_SelectLevel = 231,
        Adv_SelectDifficult = 232,

        // 大厅相关
        Lobby_ToggleSysBtn = 250,
        Lobby_OpenLobbyForm = 251,
        Lobby_OpenSysEntryForm = 252,
        Lobby_ConfirmErrExit = 253,
        Lobby_OnMouseDown = 254,
        Lobby_OnMouseClick = 255,
        Lobby_OnDragStart = 256,
        Lobby_OnDragging = 257,
        Lobby_OnDragEnd = 258,
        Lobby_OnMouseUp = 259,
        Lobby_OpenTopLobbyForm = 260,
        Lobby_CloseTopLobbyForm = 270,
        Lobby_UnlockAnimation_End = 271,
        Lobby_LobbyFormShow = 272,
        Lobby_LobbyFormHide = 273,
        Lobby_ShowMoreBtn = 274,
        Lobby_HideMoreBtn = 275,
        Lobby_UnlockAnimation_Start = 276,
        Lobby_MysteryShopClose = 277,
        Lobby_RankingListElementEnable = 278,
        Lobby_Close = 279,
        Lobby_PrepareFight_Sub = 280,       // 备战 带2个 子按钮 
        Lobby_PrepareFight_Origin = 281,           // 备战 origin
        Lobby_GotoBattleWebHome = 282,      //赛事微官网入口

        // 房间
        Room_OpenCreateForm = 300,
        Room_CloseCreateForm = 301,
        Room_CreateRoom = 302,
        Room_CloseForm = 303,
        Room_SelectMap = 304,        
        Room_OpenInvite = 305,
        Room_StartGame = 306,
        Room_AddRobot = 307,
        Room_ChangePos = 308,
        Room_KickPlayer = 309,
        Room_LeaveRoom = 310,
        Room_AddFriend = 311,
        Room_ShareRoom = 312, //分享房间信息给社交好友
        Room_ChangePos_TimeUp = 313, //换位置倒计时时间到
        //Room_ChangePos_Cancle = 314, //你主动换位置，主动取消
        Room_ChangePos_Confirm = 315,//别人找你换位置，你确认
        Room_ChangePos_Refuse = 316,//别人找你换位置，你拒绝
        Room_ChangePos_Box_TimerChange = 317, //别人找你换位置，timer改变
        Room_On_Close = 318, //房间界面被关闭
		Room_Observe_Fold = 319,		//展开/关闭观战位
		Room_Observe_Seat = 320,		//点击坐下观战位
		Room_Observe_Kick = 321,
		Room_Observe_Swap = 322,

        // 邀请
        //Invite_OpenForm = 350,
        Invite_SendInvite = 351,
        Invite_SelectInvite = 352,
        Invite_DeselectInvite = 353,
        Invite_AcceptInvite = 354,
        Invite_RejectInvite = 355,
        Invite_SendInviteFriend = 356,
        Invite_FriendListElementEnable = 357,
        Invite_TabChange = 358,
        Invite_GuildMemberListElementEnable = 359,
        Invite_SendInviteGuildMember = 360,
        Invite_RefreshGameStateTimeout = 361,
        //Invite_BuyHeroListElementEnable = 362,
        //Invite_BuySkinListElementEnable = 363,
        Invite_AddToMsgCenter = 364,
        Invite_LBSListElementEnable = 365,
        Invite_SendInviteLBS = 366,
        Invite_TimeOut = 367,

        Invite_RefuseReason_ClickDown = 368,
        Invite_RefuseReason_ClickList = 369,
        Invite_RefuseReason_Send = 370,
        Invite_Form_Closed = 371,
        Invite_RefuseReason_ItemEnable = 372,
        Invite_RefuseReason_BgClick = 373,



        // 匹配
        Matching_OpenEntry = 400,
        Matching_StartMulti = 408,      //多人匹配确认按钮事件
        Matching_KickPlayer = 410,
        Matching_LeaveTeam = 412,
        Matching_ReqLeave = 416,
        Matching_TimeUpdate = 417,
        Matchingt_ShowConfirmHead = 418,

        Matching_Robot1V1 = 420,
        Matching_Begin1v1 = 421,
        Matching_Begin5v5Team = 422,
        Matching_Begin3v3Team = 423,
        Matching_Begin5v5LadderIn2 = 424, //双排
        Matching_Begin5v5LadderIn5 = 425, //5人排位
        Matching_RejectMatch = 426,
        Matching_ConfirmMatch = 427,
        Matching_OpenConfirmBox = 428,

        Matching_BtnGroup_Click = 429,
        Matching_BtnGroup_ClickClose = 430,
        Matching_Robot_BtnGroup_Click = 431,

        Matching_RobotTeamENTERTAINMENT = 435,
		Matching_RobotTeamVERSUS = 436,
        Matching_OpenLadder = 437,
        Matching_ADButton = 439,
        Matching_ADForm_Close = 440,
        Matching_OnConfirmTimeout = 441,

        Matching_RuleView = 442,

        Matching_Guide_1v1 = 443,
        Matching_Guide_3v3 = 444,
        Matching_Guide_Casting = 445,
        Matching_Training = 446,
        Matching_GuidePanel = 447,
        Matching_GuideAdvance = 448,
        Matching_Guide_5v5 = 449,
        Matching_Guide_Jungle = 470,

        MatchingExt_BeginMelee = 471,

        Matching_Waiting =472,

        MatchingExt_BeginEnterTrainMent = 473,
        Matching_EnterTainMentMore = 474,
		Matching_Guide_1v1_ChooseHeroType = 475,
        Matching_Guide_5v5_ChooseHeroType = 476,		
        Matching_ClickFogHelp = 477,
        Matching_Guide_1v1_Confirm = 478,
        Matching_Guide_3v3_Confirm = 479,
        Matching_Guide_5v5_Confirm = 480,
        Matching_Guide_Casting_Confirm = 481,
        Matching_Guide_Jungle_Confirm = 482,
        // PvP结算
        PvPSettle_Confirm = 450,
        PvPSettle_AddFriend = 451,  
        PvPSettle_TabChanged = 452,
        PvPSettle_ShowStatistics = 453,
        PvPSettle_ShowData = 454,
        PvPSettle_HideData = 455,
        PvPSettle_ShowAchievementTips = 456,
        PvPSettle_Again = 457,
        PvPSettle_ShowRankPointTips = 458,
        PvPSettle_HideRankPointTips = 459,
        PvPSettle_ShowReportPlayer = 460,
        PvPSettle_CloseReportPlayer = 461,
        PvPSettle_DoReporting = 462,
        PvPSettle_LadderSettleClickContinue = 463,
        PvPSettle_LadderSettleAgain = 464,
        PvPSettle_OnChangeStateTimerEnd = 465,

        //任务
        Task_OpenForm = 500,
        Task_CloseForm = 501,
        Task_Submit = 502,
        Task_AwardClose = 503,

        //每日任务
        DailyTask_CloseForm = 504,

        Task_LinkPve = 505,
        Task_LinkMall = 506,
        Task_LinkBurnPve = 507,
        Task_LinkActivityPve = 508,

        Task_TabChanged = 509,
        Task_Refresh = 510,
        Task_Refresh_OK = 511,
        Task_Refresh_Cancle = 512,
        Task_Finish_Ok = 513,

        Task_List_ElementEnable = 514,
        Task_Week_Reaward1 = 515,
        Task_Week_Reaward2 = 516,
        Task_Day_Reaward = 517,
        Task_EngineCloseForm = 518,     // 被动关闭 该form

        Task_JumpToReward = 519,        // 跳转到未领取奖励的关卡节点
        Task_Award_Get_Confirm = 520,           //奖励领取完成

        // 师徒任务
        Task_Mentor_Close = 521,
        Task_Mentor_GetReward = 522,

        //小秘书
        MiShu_OnClickMiShu = 530,
        MiShu_OnCheckTalk = 531,
        MiShu_OnClickGoto = 532,
        MiShu_OnCloseTalk = 533,
        MiShu_OnCheckFirstWin = 534,
        MiShu_OnPlayAnimation = 535,

        //召唤师技能
        AddedSkill_OpenForm = 550,
        AddedSkill_CloseForm = 551,
        AddedSkill_GetDetail = 552,
        AddedSkill_Selected = 553,
        AddedSkill_ShowChuanSongHelp = 554,

        // 选将
        //HeroChoose_OpenForm = 600,
        HeroChoose_OpenChoose = 601,
        HeroChoose_ChooseConfirm = 602,
        
        // 剧情对话
        Dialogue_NextPage = 700,
        Dialogue_SkipPages = 701,
        Dialogue_AnyWhereClick = 702,

        // 结算
        Settle_ClickForm = 800,
        Settle_Back = 801,
        Settle_CloseLvlUp = 802,
        Settle_CloseWinForm = 803,
        Settle_EscapeAnim = 804,
        Settle_ShowExpForm = 805,
        Settle_ShowRewardForm = 806,
        Settle_BattleAgain = 807,
        Settle_NextLevel = 808,
        Settle_BackToLobby = 809,
        Settle_OpenLvlUp = 810,
        Settle_AnimEnd = 811,
        Settle_ClickItemDetailEnd = 812,
        Settle_OnGameEnd = 813,

        // 好友系统
        Friend_OpenForm = 900,
        Friend_CloseForm = 901,
        Friend_Open_SerchFriendMenu = 902,
        Friend_SerchFriend = 903,                   // 收索好友
        Friend_RequestBeFriend = 904,               // 好友申请
        Friend_Accept_RequestFriend = 905,          // 同意好友请求
        Friend_Refuse_RequestFriend = 906,          // 拒绝好友请求
        Friend_DelFriend = 907,                     // 删除好友
        Friend_SendPower = 908,                     // 送心
        Friend_CheckInfo = 909,                     // 查看好友信息
        Friend_InvitePK = 910,                      // 邀请好友对战
        Friend_OpenAddFriendForm = 911,             // 添加好友界面
        Friend_SendPowerAll = 912,                  // 一键赠送好友体力
        Friend_Tab_Change = 913,
        Friend_Tab_Friend = 914,
        Friend_Tab_FriendRequest = 915,
        Friend_DelFriend_OK = 916,
        Friend_DelFriend_Cancle = 917,
        Friend_InviteGuild = 918,                   // 邀请入会
        Friend_RecommendGuild = 919,                // 推荐入会
        Friend_List_ElementEnable = 920,            // 好友列表
        Friend_Request_ElementEnable = 921,         // 好友请求
        Friend_Recommand_ElementEnable = 922,       // 系统推荐好友

        Friend_Search_Tab_Change = 923,     // 搜索好友左边的 tab 页签
        Friend_Close_AddForm = 924,         // 关闭搜索好友界面
        Friend_AddAll_SNS_Friend = 925,
        Friend_Invite_SNS_Friend = 926,
        Friend_SNSList_ElementEnable = 927,
        Friend_SendCoin = 928,//赠送金币
        Friend_SNS_SendCoin = 929, //SNS赠送金币
        Friend_Share_SendCoin = 930,//分享送金币消息
        Friend_SNS_ReCall = 931,//召回流失好友
        Friend_SNS_Share_Switch_Click = 932,//屏蔽分享信息
        Friend_SNS_Add_Switch_Click = 933, //屏蔽添加好友

        // 好友验证
        Friend_Verify_Close = 934,      // 关闭form
        Friend_Verify_Send = 935,       // 点击确定按钮响应
        Friend_Chat_Button = 936,       // 点聊天按钮 跟好友聊天
        Friend_Show_Rule = 937,         // 规则按钮
        Friend_Block = 938,             // 屏蔽好友
        Friend_CancleBlock = 939,       // 取消 屏蔽好友
        Friend_CancleBlock_Ok = 940,       // 确认 屏蔽好友
        Friend_CancleBlock_Cancle = 941,   // 最终取消
        Friend_Block_Ok = 942,             // 屏蔽好友 2次确认
        Friend_Block_Cancle = 943,         // 屏蔽好友 最终取消

        Friend_Gift = 944,
        Friend_OB_Click = 945,//好友界面观战
		
		// LBS
        Friend_LBS_NoShare   = 946,
        Friend_LBS_Nan       = 947,
        Friend_LBS_Nv        = 948,
        Friend_LBS_Refresh   = 949,
        Friend_LBS_CheckInfo = 950,

        // 游戏房间加好友
        Friend_Room_AddFriend = 951,

        // 好友亲密度关系 cao
        IntimacyRela_Menu_Btn_Click = 952,
        IntimacyRela_Show_Drop_List = 953,
        IntimacyRela_Drop_ListElement_Click = 954,
        IntimacyRela_OK = 955,
        IntimacyRela_Cancle = 956,
        IntimacyRela_Menu_Close = 957,
        IntimacyRela_Item_Enable = 958,
        IntimacyRela_FristChoise = 959,
        IntimacyRela_Drop_ListElement_Enable = 960,
        IntimacyRela_Delete_Relation = 961,
        IntimacyRela_PrevState = 962,
        IntimacyRela_LoadingClick = 963,
        IntimacyRela_Delete_Relation_OK = 964,

        // 
        Friend_Recruit_zmzBtn = 970,
        Friend_Recruit_bzmzBtn = 971,
        Friend_Recruit_bzmRoleBtn = 972,
        Friend_Recruit_RecruitBtn = 973,
        Friend_Recruit_zmzListEnable = 974,
        Friend_Recruit_zmzItemClickDown = 975,
        Friend_Recruit_TabChange = 976,

        Friend_Recommend_CheckInfo = 977,
		
        // Team
        //Team_OpenForm = 1000,
        Team_CloseForm = 1001,
        Team_HeroClick = 1002,
        Team_LibrarySelectionChanged = 1003,
        Team_TeamSelectionChanged = 1004,
        Team_ConfirmSelection = 1005,

		// Battle
        Battle_StateViewClickHeroIcon = 1099,       // 统计界面 点击英雄头像

		Battle_OpenSysMenu = 1100,
		Battle_PickHeroHead = 1101,
        Battle_SwitchAutoAI = 1102,
        Battle_ChgFreeCamera = 1103,
        Battle_OnAxisChanged = 1104,
        Battle_OnCameraAxisChanged = 1006,
        Battle_OnCameraAxisReleased = 1007,
        Battle_OnCameraAxisPushed = 1008,
        Battle_OnPanelCameraStartDrag = 1009,
        Battle_OnPanelCameraDraging = 1010,
        Battle_OnPanelCameraEndDrag = 1011,
        Battle_OnPanelCameraClickDown = 1012,
        Battle_OnPanelCameraClickUp = 1013,
        Battle_OnSkillButtonDown = 1105,
        Battle_OnSkillButtonUp = 1106,
        Battle_SysReturnLobby = 1107,
        Battle_SysQuitGame = 1108,
        Battle_SysReturnGame = 1109,
		Battle_ToggleStatView = 1110,
		Battle_CloseStatView = 1111,
        Battle_HeroInfoSwitch = 1112,
        Battle_OnSkillButtonDragged = 1113,

        Battle_HeroInfoPanelOpen = 1114,
        Battle_HeroInfoPanelClose = 1115,
        Battle_ClickMiniMap = 1116,
        Battle_ClickReault = 1117,
        Battle_ClickBigMap = 1118,

        Battle_MultiHashInvalid = 1120,

        Battle_StartCameraDrag = 1130,
        Battle_CameraDraging = 1131,
        Battle_EndCameraDrag = 1132,

        Battle_OnSkillButtonHold = 1133,
        Battle_OnSkillButtonHoldEnd=1134,
        Battle_OnAtkSelectHeroDown = 1135,
        Battle_OnAtkSelectHeroUp = 1136,
        Battle_OnAtkSelectSoldierDown = 1137,
        Battle_OnAtkSelectSoldierUp = 1138,
        Battle_OnLastHitButtonDown = 1139,
        Battle_OnLastHitButtonUp = 1141,

        Battle_OpenForm = 1150,
        Battle_CloseForm = 1151,
        Battle_OnCloseForm = 1152,
        Battle_ActivateForm = 1140,

        Battle_OnHideForm = 1142,
        Battle_OnAppearForm = 1143,

        Battle_OnOpMode = 1153,
        Battle_OnDragonBorn = 1154,
        Battle_OnOpenDragonTip = 1155,
        Battle_OnCloseDragonTip = 1156,
        Battle_OnFloatTextAnimEnd = 1157,

        Battle_FPSAndLagUpdate = 1158,
        Battle_Hold_MiniMap = 1159,
        Battle_Drag_SignalPanel = 1160,
        Battle_Click_MiniMap_Up = 1161,
        Battle_Drag_SignalPanel_End = 1162,
        Battle_Disable_Alert = 1163,
        Battle_ConfirmSysReturnLobby = 1164,
        Battle_OnSignalButtonClicked = 1165,
        Battle_OnSignalTipsListElementEnable = 1166,
        Battle_Down_MiniMap = 1167,     

		Battle_TaskPanel_SlideEnd = 1169,
        Battle_RevivieTimer = 1170,
        Battle_Click_Scene = 1171,
        Battle_SkillLevelUpEffectPlayEnd = 1172,
        Battle_EquipBoughtEffectPlayEnd = 1173,
        Battle_BattleStatViewSortClick = 1174, //默认排序  金币排序
        Battle_CloseBigMap = 1175,             //关闭大地图

        Battle_PauseMultiGame = 1176,          //请求暂停多人游戏
        Battle_ResumeMultiGame = 1177,         //请求恢复多人游戏

        Battle_Pause_Game = 1180,
        Battle_Resume_Game = 1181,

        Battle_Voice_Btn = 1182,

        Battle_BuffSkillBtn_Down = 1185,
        Battle_BuffSkillBtn_Up = 1183,

        Battle_LearnSkillBtn_Click = 1184,

        Battle_Disable_Down = 1186,
        Battle_Disable_Up = 1187,

        Training_HelperOpen = 1188,
        Training_HelperClose = 1189,
        Training_HelperInit = 1190,
        Training_HelperUninit = 1191,
        Training_HelperCheat = 1192,

        Battle_Surrender = 1193,
        Battle_Surrender_Confirm = 1194,
        Battle_Surrender_Against = 1195,
        Battle_Surrender_CountDown = 1196,
        Battle_Surrender_TimeUp = 1197,
        Battle_Surrender_TimeStart = 1198,
        Battle_ReviveTimeChange = 1199,


        // Purchase
        Purchase_OpenBuyActionPoint = 1200,
        Purchase_OpenBuyCoin = 1201,
        Purchase_OpenBuySkillPt = 1202,
        Purchase_BuyActPt = 1204,
        Purchase_BuyCoinOne = 1205,
        Purchase_BuyCoinTen = 1206,
        Purchase_BuySkillPt = 1207,
        Purchase_CloseBuyActionPoint = 1208,
        Purchase_CloseBuyCoin = 1209,
        Purchase_CloseBuySkillPt = 1210,
 //       Purchase_OpenBuyDiamond = 1211,
        Purchase_CloseBuyDiamond = 1212,
        Purchase_BuySymbolPage = 1213,
        Purchase_BuyDiamond = 1214,

        // 大地图上图标点击
        BigMap_Click_5_Dalong = 1230,            // 5v5 大龙
        BigMap_Click_5_Xiaolong = 1231,          // 5v5 小龙
        BigMap_Click_3_long = 1232,          // 5v5 小龙
        BigMap_Click_Organ = 1233,
        BigMap_Click_Hero = 1234,
        BigMap_Click_Map = 1235,

        BigMap_Open_BigMap = 1236,
        BigMap_Click_Eye = 1237,            //5v5眼

        Battle_3DTouch_Left = 1238,
        Battle_3DTouch_Right = 1239,
        Battle_3DTouch_FullScreen = 1240,
        Battle_3DTouch_FullScreen_Scene = 1241,
        BigMap_Click_Solider = 1242,            //小兵

        // 大地图上的信号面板
        BigMap_Hold_EmptyArea = 1243,                   // 按住大地图空白区域
        BigMap_HoldEnd = 1244,                          // 按住大地图空白区域 结束
        BigMap_SignalPanel_Up_0 = 1245,
        BigMap_SignalPanel_Up_1 = 1246,
        BigMap_SignalPanel_Up_2 = 1247,
        BigMap_SignalPanel_Up_3 = 1248,
        BigMap_SignalPanel_Drag = 1249,


        //抽奖系统
        Lottery_OpenForm = 1300,
        Lottery_CloseForm = 1301,
        Lottery_Coin_BuyOneFree = 1302,
        Lottery_Coin_BuyOne = 1303,
        Lottery_Coin_BuyTen = 1304,
        Lottery_Gold_BuyOneFree = 1305,
        Lottery_Gold_BuyOne = 1306,
        Lottery_Gold_BuyTen = 1307,
        Lottery_Coin_Free_Draw_CD_UP = 1308,
        Lottery_Gold_Free_Draw_CD_UP = 1309,
        Lottery_CloseResultForm = 1310,

        Lottery_Coin_OpenForm = 1311,
        Lottery_Coin_CloseForm = 1312,
        Lottery_Coin_Quick_Buy = 1313,
        Lottery_Coin_Quick_Sale = 1314,
        Lottery_Coin_Select_Sale = 1315,
        Lottery_Show_Reward = 1316,
        Lottery_Coin_Diamond_Buy = 1317,
        Lottery_Show_Reward_End = 1318,
        Lottery_Show_Hero = 1319,
        Lottery_Show_Skin = 1320,
        Lottery_Refresh_3D_Model_Timer_Up = 1321,
        Lottery_Coin_Quick_Buy_Confirm = 1322,
        Lottery_Coin_Quick_Buy_Pause = 1323,
        Lottery_Show_Reward_Start = 1324,

        Lottery_Common_BuyFiveSymbol = 1325,
        Lottery_Senior_BuyOneSymbol = 1326,
        Lottery_Close_FX = 1327,
        Lottery_Symbol_Boom = 1328,
        Lottery_BuySymbolConfirm = 1329,
        Lottery_Senior_BuyFiveSymbol = 1330,
        Lottery_Senior_BuyFreeSymbol = 1331,
        Lottery_Common_BuyOneSymbol = 1332,
        Lottery_Open_Form = 1333,
        Lottery_Close_Form = 1334,
        Lottery_Action_Mask_Reset = 1335,
        Lottery_Skip_Animation = 1336,

        //mail
        Mail_OpenForm = 1400,
        Mail_CloseForm = 1401,
        Mail_TabFriend = 1402,
        Mail_TabSystem = 1403,
        Mail_FriendAccessAll = 1404,
        Mail_SysAccess = 1405,
        Mail_SysRead = 1406,
        Mail_FriendRead = 1407,
        Mail_FriendOpenForm = 1408,
        Mail_SysOpenForm = 1409,
        Mail_FriendCloseForm = 1410,
        Mail_SysCloseForm = 1411,
        Mail_SysDelete = 1412,
        Mail_SysAccessAll = 1413,
        Mail_FriendAccess = 1414,
        Mail_ListElementEnable = 1415,
        Mail_TabMsgCenter = 1416,
        Mail_MsgCenterDeleteAll = 1417,
        Mail_JumpForm = 1418,
        Mail_JumpUrl = 1419,
        Mail_Form_OnClose = 1420,
        Mail_Open_Mail_Write_Form = 1421,
        Mail_Send_Guild_Mail = 1422,
        Mail_FriendDelete = 1423,
        Mail_Invite = 1424,


        // 聊天系统
        Chat_OpenForm = 1500,
        Chat_CloseForm = 1501,
        Chat_Tab_Change = 1502,
        Chat_ToolBar_Voice = 1503,
        Chat_ToolBar_Input = 1504,
        Chat_ToolBar_Face = 1505,
        Chat_ToolBar_Add = 1506,
        Chat_Conent_Head_Icon = 1507,              // 聊天内容区域的点击头像
        Chat_FriendTab_Item = 1508,                // 聊天中的 好友列表 item点击
        Chat_ToolBar_Input_Start_Edit = 1509,
        Chat_ToolBar_Input_End_Edit = 1510,
        Chat_Tab_FriendClick = 1511,
        Chat_Tab_FriendItem_Refresh = 1512,
        Chat_Tab_ChatItem_Refresh = 1513,
        Chat_List_FriendItem_Change = 1514,         // 点击 好友列表中的 item
        Chat_EntryPanel_Click = 1515,         // 点击 聊天入口面板
        Chat_Text_Send = 1516,
        Chat_FaceList_Selected = 1517,
        Chat_ScreenButton_Click = 1518,
        Chat_SendButton_Click = 1519,
        Chat_ClearText_Click = 1520,

        Chat_FriendChat_Elem_Enable = 1521,
        Chat_LobbyChat_Elem_Enable = 1522,
        Chat_RoomChat_Elem_Enable = 1523,
        Chat_GuildChat_Elem_Enable = 1524,

        // 聊天选将
        Chat_Hero_Select_OpenForm = 1525,
        Chat_Hero_Select_CloseForm = 1526,
        Chat_Hero_Select_Bottom_BtnClick = 1527,
        Chat_Hero_Select_TabChange = 1528,
        Chat_Hero_Select_TemplateList_Click = 1529,
        Chat_Hero_Select_List_ElementEnable = 1530,

        //聊天系统
        Chat_Cost_Send = 1531,
        Chat_Timer_Changed = 1532,

        // 聊天选将继续
        Chat_Hero_Select_Tab_Input = 1533,
        Chat_Hero_Select_Tab_Voice = 1534,
        Chat_Hero_Select_Send_Text = 1535,
        

        Mini_Player_Info_Open_Form = 1536,
        Mini_Player_Info_AddFriend = 1537,
        Mini_Player_Info_Profile = 1538,
        Mini_Player_Info_Invite_3v3 = 1539,
        Mini_Player_Info_Invite_5v5 = 1540,
        Mini_Player_Info_CloseForm = 1541,

        //聊天系统
        Chat_Form_Revert_To_Visible = 1542,
        Chat_Form_Revert_To_Hide = 1543,
        Chat_Form_Open_Mini_Player_Info_Form = 1544,

        //聊天选将

        Chat_Hero_Select_Chat_Bubble_Close = 1580,

        Chat_Hero_Select_OpenSpeaker = 1581,
        Chat_Hero_Select_OpenMic = 1582,
        Chat_ClickBubble = 1583,
        Chat_Guild_Recruit_List_Element_Enabled = 1584,

        //设置菜单
        Settings_OpenForm = 1600,
        Settings_ReqLogout = 1601,
        Settings_ConfirmLogout = 1602,
        Settings_SettingTypeChange = 1603,
        Settings_CloseForm = 1604,
        Settings_CameraHeight = 1605,
        //Settings_OpenBattleForm = 1606,
        Settings_PrivacyPolicy = 1607,
        Settings_TermOfService = 1608,
        Settings_Contract = 1609,
        Settings_UpdateTimer = 1610,
        Settings_ConfirmQuality_Accept = 1611,
        Settings_ConfirmQuality_Cancel = 1612,
        Settings_SurrenderCDReady = 1613,
        Settings_OpenNetworkAccelerator = 1614,
        Settings_AutomaticOpenNetworkAccelerator = 1615,
        Settings_ClickMoveCameraGuide = 1616,
        Settings_KingTimeCourse = 1617,
        Settings_ClickSkillCancleTypeHelp = 1618,
        Settings_OnClickReplayKitHelp = 1619,
        Settings_OnSmartCastChange = 1620,
        Settings_OnLunPanCastChange = 1621,
        Settings_OnPickNearestChange = 1622,
        Settings_OnPickMinHpChange = 1623,
        Settings_OnCommonAttackType1Change = 1624,
        Settings_OnCommonAttackType2Change = 1625,
        Settings_OnSkillCanleType1Change = 1626,
        Settings_OnSkillCanleType2Change = 1627,
        Settings_OnJoyStickMoveChange = 1628,
        Settings_OnJoyStickNoMoveChange = 1629,
        Settings_OnRightJoyStickBtnLocChange = 1630,
        Settings_OnRightJoyStickFingerLocChange = 1631,

        Settings_Slider_onMusicChange = 1632,
        Settings_Slider_onSoundEffectChange = 1633,
        Settings_Slider_onModelLODChange = 1634,
        Settings_Slider_onParticleLODChange = 1635,
        //Settings_Slider_onSmartCastChange = 1636,
        Settings_Slider_onSkillTipChange = 1637,
        Settings_Slider_onFpsChange = 1638,
        Settings_Slider_onVoiceChange = 1639,
        Settings_Slider_onInputChatChange = 1640,
        Settings_Slider_onVibrateChange = 1641,
        Settings_Slider_onMoveCameraChange = 1642,
        Settings_Slider_onReplayKitEnableChange = 1643,    
        Settings_Slider_onReplayKitEnableAutoModeChange = 1644,   
        Settings_Slider_onHDBarChange = 1645,            
        Settings_Slider_onLunpanSensitivityChange = 1646,
        Settings_Slider_onCameraSensitivityChange = 1647,
        Settings_Slider_onMusicSensitivityChange = 1648,
        Settings_Slider_onSoundSensitivityChange = 1649,
        Settings_Slider_onVoiceSensitivityChange = 1650,
        Settings_Slider_onRecordKingTimeEnableChange = 1651,
        Settings_Slider_onRecordCommonModeChange = 1652,
        Settings_Slider_onSecurePwdEnableChange = 1653,
        Settings_Slider_OnHeroInfoBarChange = 1654,
        Settings_OnClickHeroInfoBarHelp = 1655,
        Settings_Toggle_OnLockEnemyHeroChange = 1656,
        Settings_Toggle_OnShowEnemyHeroChange = 1657,
        Settings_Toggle_OnClickHeroSelectSortTypeDefault = 1658,
        Settings_Toggle_OnClickHeroSelectSortTypeProficiency = 1659,

        Settings_OnNoneLastHitModeChange = 1660,
        Settings_OnLastHitModeChange = 1661,

        Settings_Toggle_OnNotLockEnemyHeroChange = 1662,
        Settings_Toggle_OnNotShowEnemyHeroChange = 1663,

        Settings_OnClickLockEnemyHeroHelp = 1664,
        Settings_OnClickLastHitModeHelp = 1665,
        Settings_OnClickShowEnemyHeroHelp = 1666,
        Settings_Slider_On3DTouchBarChange = 1667,

        Settings_ReplayKitCourse = 1668,
        Settings_Slider_onRecordReplayKitEnableChange = 1669,
        Settings_OnClickBPHeroSelectHelpBtn = 1670,
        Settings_Slider_3DTouchChange = 1671,
        Settings_Slider_ShowEquipInfo = 1672,
        Settings_Slider_OnRecordSetVideoHighQualityEnableChange = 1673,
        Settings_Slider_OnPrivacyHistoryBarChange = 1674,
        Settings_Slider_OnPrivacyWatchingBarChange = 1675,
        Settings_Slider_OnPrivacyVipLevelVarChange = 1676,

        Settings_OnRecordFreeRecordHelpBtnClick = 1677,
        Settings_OnCheckMna = 1678,
        Settings_OnClickRecommendEquipDesHelp = 1679,
        Settings_OnClickGuiZuLevelHelp = 1680,
        Settings_OnCheckMnaTimeOut = 1681,

        //商店系统
        Shop_OpenForm = 1700,
        Shop_CloseForm = 1701,
        Shop_SelectTab = 1702,
        Shop_SelectItem = 1703,
        Shop_CloseItemForm = 1704,
        Shop_BuyItem = 1705,
        Shop_ManualRefresh = 1706,
        Shop_ConfirmManualRefresh = 1707,
        Shop_CancelManualRefresh = 1708,
        Shop_SaleTipCancel = 1709,
        Shop_SaleTipConfirm = 1710,
        Shop_AutoRefreshTimerTimeUp = 1711,
        Shop_MysteryShopActive = 1712,
        Shop_OpenMysteryShop = 1713,
        Shop_OpenFormBySaleCancel = 1714,
        Shop_Refresh = 1715,
        Shop_RefuseMysteryShop = 1716,
        Shop_AcceptMysteryShop = 1717,
        Shop_CloseMysteryShop = 1718,
        Shop_ReturnToShopForm = 1719,
        Shop_Fixed_Shop_Character_Click = 1720,
        Shop_Mystery_Shop_Character_Click = 1721,
        Shop_Character_Tip_Time_Up = 1723,
        Shop_Page_Up = 1724,
        Shop_Page_Down = 1725,
        Shop_OpenHonorShop = 1726,
        Shop_GetBurningCoin = 1727,
        Shop_GetBurningCoinConfirm = 1728,
        Shop_GetArenaCoin = 1729,
        Shop_GetArenaCoinConfirm = 1730,
        Shop_OpenArenaShop = 1731,
        Shop_OpenBurningShop = 1732,
        Shop_OpenGuildShop = 1733,
        Shop_BuyItem_Confirm = 1734,
        Shop_SelectSubTab = 1735,

        //活动副本
        ActivityPve_OpenForm = 1800,
        ActivityPve_CloseForm = 1801,
        ActivityPve_CommonLevelChange = 1802,
        ActivityPve_OpenLevelForm = 1804,
        ActivityPve_CloseLevelForm = 1805,
        ActivityPve_LevelSelect = 1806,
        Explore_OpenForm = 1807,
        Explore_ClsoeForm = 1808,
        Explore_HeroChooseOpenForm = 1809,
        Explore_ChooseHeroReady = 1810,
        ActivityPve_OpenZhuangZi = 1811,
        ActivityPve_CloseZhuangZi = 1812,
        ActivityPve_ZhuangZiLevelChange = 1813,

        //排位赛信息查看相关
        Qualifying_OpenForm = 1900,
        Qualifying_CloseForm = 1901,
        Qualifying_MenuSelect = 1902,
        Qualifying_HeroInfoSelect = 1903,
        Qualifying_BattleAreaBtnDown = 1904,
        Qualifying_BattleAreaBtnUp = 1905,
        Qualifying_RankListSelect = 1906,
        Qualifying_RankListElementInit = 1907,

        //特色功能解锁
        FucUnlock_CloseForm = 2000,
        FucUnlock_TimerUp = 2001,

        //SearchBox
        StrSenderBox_OnSend = 2048,
        SearchBox_CloseForm = 2049,

        //新版英雄选择事件
//      HeroSelect_OpenForm = 2100,
//      HeroSelect_CloseForm = 2101,
        HeroSelect_SelectHero = 2102,
        HeroSelect_SelectTeamHero = 2103,
        HeroSelect_ConfirmHeroSelect = 2104,
        HeroSelect_Del_Hero = 2105,
        HeroSelect_Skill_Down = 2106,
        HeroSelect_Skill_Up = 2107,
        HeroSelect_ModelDrag = 2108,
        HeroSelect_ModelClick = 2109,
       // HeroSelect_SymbolPageSelect   = 2110,
        HeroSelect_ReqCloseForm = 2111,
        HeroSelect_FormClose = 2112,
        HeroSelect_OpenFullHeroList = 2113,
        HeroSelect_CloseFullHeroList = 2114,

        HeroSelect_MenuSelect = 2115,
        HeroSelect_RefreshSkinPanel = 2116,
        //HeroSelect_OpenFullSkinList = 2117,
        //HeroSelect_CloseFullSkinList = 2118,
        HeroSelect_SkinSelect = 2119,
        HeroSelect_AddedSkillSelected = 2220,
        HeroSelect_AddedSkillOpenForm = 2221,
        HeroSelect_AddedSkillCloseForm = 2222,
        HeroSelect_AddedSkillConfirm = 2223,
        HeroSelect_LeftHeroItemEnable = 2224,
        HeroSelect_RandomHero = 2225,
        HeroSelect_OnTimerCountDown = 2226,
        HeroSelect_UseHeroExpCard = 2227,
        HeroSelect_UseHeroExpCardChanel = 2228,
        HeroSelect_HeroJobMenuSelect = 2229,
        HeroSelect_FullHeroTipsComplete = 2230,
        HeroSelect_ChangeRcmdEquipPlan = 2231,

        //BanPick选将相关

        //总控相关
        HeroSelect_BanPick_FormClose = 2251,
        HeroSelect_BanPick_HeroJobMenuSelect = 2252,

        //皮肤相关
        //HeroSelect_BanPick_RefreshSkinPanel = 2253,
        HeroSelect_BanPick_SkinSelect = 2254,

        //选将相关
        HeroSelect_BanPick_SelectHero = 2255,
        HeroSelect_BanPick_CenterHeroItemEnable = 2256,
        HeroSelect_BanPick_ConfirmHeroSelect = 2257,

        HeroSelect_BanPick_SwapHeroReq = 2258,
        HeroSelect_BanPick_SwapHeroAllow = 2259,
        HeroSelect_BanPick_SwapHeroCanel = 2260,

        //符文相关
        HeroSelect_BanPick_Symbol_PageDownBtnClick = 2261,
        HeroSelect_BanPick_SymbolPageSelect = 2262,
        HeroSelect_BanPick_Symbol_ViewProp_Down = 2263,
        HeroSelect_BanPick_Symbol_ViewProp_Up = 2264,


        //召唤师技能相关
        HeroSelect_BanPick_AddedSkillOpenForm = 2265,
        HeroSelect_BanPick_AddedSkillSelected = 2266,
        HeroSelect_BanPick_AddedSkillConfirm = 2267,
        HeroSelect_BanPick_AddedSkillCloseForm = 2268,


        //其它
        HeroSelect_BanPick_OnTimerCountDown = 2269,
        HeroSelect_BanPick_UseHeroExpCard = 2270,
        HeroSelect_BanPick_UseHeroExpCardChanel = 2271,
        HeroSelect_BanPick_ChangeRcmdEquipPlan = 2272,

        //创建角色
        ROLE_CREATE = 2200,
        ROLE_CREATE_CHANGED = 2201,
        ROLE_CREATE_RANDOM = 2202,

        GAME_DIFF_SELECT = 2203,
        GAME_DIFF_CONFIRM = 2204,
        
        ROLE_CREATE_TIMER_CHANGE = 2205,
        ROLE_HeroType_Select = 2206,
        ROLE_HeroType_Confirm = 2207,

        Hero_Init_Select = 2250,

        //局类英雄信息查看
        BattleHeroInfo_InfoTypeChange=2280,
        BattleMatchInfo_InfoTypeChange=2281,

        //符文
        Symbol_OpenForm = 2300,
        Symbol_CloseForm = 2301,

        Symbol_MenuSelect = 2302,

        Symbol_BagItemEnable = 2303,
        Symbol_BagShow = 2304,
        Symbol_BagViewHide = 2305,

        Symbol_View = 2306,
        Symbol_Off = 2307,

        Symbol_PageAddClick = 2308,
        Symbol_ChangeConfirm = 2309,
        Symbol_PageItemSelect = 2310,
        Symbol_PageDownBtnClick = 2311,     //选将界面查看符文页

        Symbol_ViewProp_Down = 2312,        //选将界面查看属性
        Symbol_ViewProp_Up = 2313,

        Symbol_ChangePageName = 2314,
        Symbol_ConfirmChgPageName = 2315,

        Symbol_SymbolPageDownBtnClick = 2316,  //符文界面查看符文页
        Symbol_BagItemClick = 2317,

        Symbol_ChangeSymbolClick = 2318,

        Symbol_OpenUnlockLvlTip = 2319,
        Symbol_SwitchPropPanel = 2320,
        Symbol_PageClear = 2321,           //一键拆卸
        Symbol_FormClose = 2322,
        Symbol_PageClearConfirm = 2323,           //一键拆卸二级确认
        Symbol_RevertToVisible = 2324,
        Symbol_OpenForm_ToMakeTab = 2325,
        Symbol_Update_Sub_Module = 2326,
        Symbol_View_NotWear_Item = 2327,    //查看未装配的符文
        Symbol_Jump_To_MiShu = 2328,        //跳转到小秘书，我要符文界面
        Symbol_SymbolForm_PageChangeName = 2329,

        //符文制作占坑
        SymbolMake_ListItemEnable = 2330,        //符文制作与分解
        SymbolMake_ListItemClick = 2331,
        SymbolMake_OnItemMakeClick = 2332,
        SymbolMake_OnItemBreakClick = 2333,
        SymbolMake_OnItemBreakConfirm = 2334,
        SymbolMake_OnBreakExcessSymbolClick = 2335,   //分解多余的符文
        SymbolMake_LevelTabSelect = 2336, 
        SymbolMake_TypeTabSelect = 2337,  
        SymbolMake_OnBreakExcessSymbolConfirm = 2338,   //确认分解多余的符文
        SymbolMake_TypeMenuSelect = 2339,   //符文类别
        SymbolMake_LevelMenuSelect = 2340,   //符文等级改变
        SymbolMake_OnItemMakeConfirm = 2341,
        SymbolMake_ItemBreakAnimatorEnd = 2342,
        SymbolMake_SelectBreakLvlItem = 2343,
        SymbolMake_CoinNotEnoughGotoSymbolMall = 2344,
        SymbolMake_OnSecurePwdItemBreakConfirm = 2345,
        SymbolMake_OnSecurePwdBreakExcessSymbolConfirm = 2346,

        //符文格钻石购买
        Symbol_PromptBuyGrid = 2350,
        Symbol_ConfirmBuyGrid = 2351,
        Symbol_ConfirmWhenMoneyNotEnough = 2352,

        //批量分解详情
        Symbol_BreakItemEnable = 2360,
        Symbol_BreakItemSelectChange = 2361,
        Symbol_OpenBreakDetailForm = 2362,
        Symbol_BreakDetailFormConfirm = 2363,
        Symbol_BreakDetailFormCancle = 2364,
        Symbol_BreakListItemSelToggle = 2365,

        SymbolRcmd_OpenChangeHeroForm = 2370,
        SymbolRcmd_HeroListItemClick = 2371,
        SymbolRcmd_LevelListIndexChange = 2372,
        SymbolRcmd_HeroTypeChange = 2373,
        SymbolRcmd_HeroOwnFlagChange = 2374,
        SymbolRcmd_HeroListItemEnable = 2375,
        SymbolRcmd_RcmdListItemEnable = 2376,

        SymbolPage_PageItemEnable = 2377,
        SymbolPage_PageItemChangeName = 2378,
        SymbolPage_PageItemUse = 2379,

        //公会系统
        Guild_OpenForm = 2400,  //打开公会
        Guild_CloseForm = 2401, //关闭公会
        Guild_Guild_Join = 2402,    //加入公会
        Guild_Guild_Search_In_Preview_Panel = 2403,  //公会一览中搜索公会
        Guild_Guild_Help = 2404,    //公会帮助
        Guild_PrepareGuild_Create = 2405,   //创建筹备期公会按钮点击
        Guild_PrepareGuild_Create_Cancel = 2406,   //取消创建筹备期公会
        Guild_PrepareGuild_Create_Confirm = 2407,  //再次确定

        Guild_PrepareGuild_Tip_Cancel = 2408,   //Tip取消

        Guild_PrepareGuild_Join = 2409, //响应筹备公会
        Guild_PrepareGuild_Join_Confirm = 2410, //确认响应筹备公会
        Guild_PrepareGuild_Join_Cancel = 2411, //取消响应筹备公会

        Guild_Guild_Select_In_Guild_List = 2412, //公会列表中某公会被选中
        Guild_Prepare_Guild_Select = 2413, //筹备中公会列表中某公会被选中

        Guild_Info_Member_Info = 2414,
        Guild_Member_Select = 2415,
        Guild_List_View_Change_Tab = 2416,
        Guild_Info_View_Change_Tab = 2417,
        //Guild_Donate = 2418,
        //Guild_Donate_Cancel = 2419,
        //Guild_Donate_Confirm = 2420,
        Guild_PrepareGuild_Timeout = 2421,
        Guild_PrepareGuild_Create_Modify_Icon = 2422,
        Guild_PrepareGuild_Create_Icon_Selected = 2423,
        //Guild_PrepareGuild_Create_Icon_Cancel = 2424,
        Guild_Guild_Setting_Open = 2425,
        //Guild_Guild_Setting_Close = 2426,
        Guild_Guild_Setting_Confirm = 2427,
        Guild_Guild_Application_Pass = 2428,
        Guild_Guild_Application_Reject = 2429,
        Guild_Guild_Apply_Quit = 2430,
        Guild_Guild_Apply_Quit_Confirm = 2431,
        Guild_Guild_Apply_Quit_Cancel = 2432,
        Guild_Guild_Apply_Time_Up = 2433,
        Guild_Accept_Invite = 2434,
        Guild_HyperLink_Click = 2435,
        Guild_Hyperlink_Search_Guild = 2436,        //通过超链接搜索公会
        Guild_Recommend_Invite = 2437,    //邀请被推荐人入会(公会管理界面)
        Guild_Recommend_Reject = 2438,    //拒绝被推荐人入会(公会管理界面)
        Guild_Hyperlink_Search_PrepareGuild = 2439, //通过超链接搜索筹备期公会

        Guild_Preview_Guild_List_Element_Select = 2440, //公会一览中某公会被选中

        Guild_Construct_Upgrade = 2441,     //公会建筑升级
        Guild_Construct_View = 2442,        //公会建筑查看
        Guild_Construct_Guide = 2443,       //公会建筑说明

        Guild_Position_Appoint_Vice_Chairman = 2445,            //任命公会副会长
        Guild_Position_Appoint_Vice_Chairman_Confirm = 2446,    //任命公会副会长确认
        Guild_Position_Fire_Member = 2447,                      //开除公会成员
        Guild_Position_Fire_Member_Confirm = 2448,              //开除公会成员确认
        //Guild_Open_Management_Setting_Form = 2449,              //打开管理设置页面
        Guild_Position_Chairman_Transfer = 2450,                //会长传位
        Guild_Position_Chairman_Transfer_Confirm = 2451,        //会长传位确认
        Guild_Position_Recommend_Self_As_Chairman = 2452,       //自荐会长
        Guild_Position_Recommend_Self_As_Chairman_Confirm = 2453,//自荐会长确认
        Guild_Position_Agree_Self_Recommend = 2454,              //通过自荐会长
        Guild_Position_Disagree_Self_Recommend = 2455,           //否决自荐会长

        //Guild_Get_Guild_Dividend = 2456,    //领取公会分红

        Guild_Guild_Search_In_Guild_List_Panel = 2457,         //在公会列表页面搜索公会
        Guild_Guild_Search_In_Prepare_Guild_List_Panel = 2458, //在筹备期公会列表页面搜索公会
        Guild_Only_Friend_Slider_Value_Changed = 2459,         //是否只允许好友加入公会Slider值变化

        //Guild_Rankpoint_Open_Rankpoint_Form = 2460,             //打开公会竞技页面
        //Guild_Rankpoint_Request_Rank_List = 2461,               //请求公会竞技排行榜数据
        Guild_Rankpoint_Help = 2462,                            //打开公会竞技规则说明
        Guild_Rankpoint_Enter_Matching = 2463,                  //进入竞技模式
        Guild_Rankpoint_Rank_List_Tab_Change = 2464,            //公会竞技排行榜tab切换
        Guild_Rankpoint_Open_Rankpoint_Rank_Form = 2465,        //打开公会竞技排行榜页面
        Guild_Rankpoint_Member_List_Element_Enabled = 2466,     //公会竞技成员列表项enabled
        Guild_Rankpoint_Rank_List_Element_Enabled = 2467,       //公会竞技排行榜列表项enabled

        Guild_Symbol_Open_Symbol_Form = 2470,                   //打开公会符文页面
        Guild_Symbol_Open_Or_Upgrade_Symbol = 2471,             //打开或升级符文
        Guild_Symbol_Symbol_List_Select_Change = 2472,          //公会符文列表选项改变
        Guild_Symbol_Open_Rule = 2473,                          //打开公会符文规则

        Guild_Prepare_Guild_List_Element_Enabled = 2476,        //筹备期公会列表元素enabled
        Guild_Requesst_More_Prepare_Guild_List = 2477,          //请求更多筹备期公会列表（分页请求拉取）
        Guild_Guild_List_Element_Enabled = 2478,                //公会列表元素enabled
        Guild_Request_More_Guild_List = 2479,                   //请求更多公会列表（分页请求拉取）

        Guild_Open_Apply_List_Form = 2480,                      //打开公会申请列表页面
        Guild_Need_Approval_Slider_Value_Changed = 2481,        //入会是否需审批slider值改变
        Guild_Add_Friend = 2482,                                //公会中添加好友
        Guild_Guild_Setting_Open_Icon_Form = 2483,              //在管理设置页面打开公会图标页面
        Guild_Guild_Setting_Guild_Icon_Selected = 2484,         //在管理设置页面打开的公会图标页面中某icon被选中

        Guild_Open_Modify_Guild_Bulletin_Form = 2486,           //打开修改公会宣言页面
        Guild_Confirm_Modify_Guild_Bulletin = 2487,             //确定修改公会宣言
        //Guild_Request_Apply_Or_Recommend_List = 2488,           //请求申请或推荐列表

        Guild_Preview_Request_Ranking_List = 2490,              //公会一览中获取排行榜
        Guild_Preview_Guild_List_Element_Enabled = 2491,        //公会一览中公会列表项enabled
        Guild_Preview_Request_More_Guild_List = 2492,           //公会一览中请求更多公会（分页请求拉取）

        Guild_Extend_Member_Limit = 2493,                       //扩充成员人数上限
        Guild_Extend_Member_Limit_Confirm = 2494,               //扩充成员人数上限确认

        Guild_Guild_Member_List_Element_Enabled = 2495,         //公会成员列表元素enabled


        //局内天赋
        //Talent_MenuSelect = 2500,       //已废弃
        //Talent_TalentClick = 2501,      //已废弃
        Talent_Open = 2502,
        Talent_Close = 2503,
        Talent_ItemClick = 2504,
        Talent_BtnLearnClick = 2505,

        Talent_Buy_Open = 2550,
        Talent_Buy_BtnSellClick = 2551,
        Talent_Buy_ConfirmClick = 2552,
        Talent_Buy_Close = 2553,

        //英雄觉醒
        HeroAwake_Open = 2580,
        HeroAwake_StartAwake = 2581,
        HeroAwake_FinishTask = 2582,

        // 燃烧远征
        Burn_Reset = 2600,
        Burn_Challenge = 2601,
        Burn_CloseEnemyInfo = 2602,
        Burn_LevelButton = 2603,
        Burn_BoxButton = 2604,
        Burn_Return = 2605,
        Burn_OpenForm = 2606,
        Burn_BuffClick = 2607,
        Burn_SettleConfirm = 2608,
        Burn_WinLoseConfirm = 2609,

        Burn_GotoShop = 2610,
        Burn_Info_Open = 2611,
        Burn_Info_Close = 2612,
		Burn_Reset_Ok = 2613,
        Burn_Reset_Cancel = 2614,
        Burn_OnCloseForm = 2615,
		//超链接事件
        Hyper_Link_Click = 2701,

        //网络连接
        Net_ReconnectConfirm = 2800,
        Net_ReconnectCancel = 2801,
        Net_ReconnectClosed = 2802,
        Net_SvrNtfReloginNow = 2803,

        Net_SingleGameFinishError = 2804,
        //战斗UI上skilltips
        SkillTips_Open = 2900,
        SkillTips_Close = 2901,
        
        HeroSkin_Wear = 3000,
        HeroSkin_ItemEnable = 3001,
        HeroSkin_ItemSelect = 3002,
        HeroSkin_Buy = 3003,
        HeroSkin_BuyConfirm = 3004,
        //HeroSkin_GoldBuy = 3003,
        //HeroSkin_DiamondBuy = 3004,
        HeroSkin_LoadNewHeroOrSkin3DModel = 3005,
        HeroSkin_OpenBuySkinForm = 3006,
        HeroSkin_OnCloseBuySkinForm = 3007,
       
	    HeroCount_Buy = 3008,
        HeroCount_CancelBuy = 3009,


        HeroSkin_OpenBuyHeroSkinForFriend = 3050,
        HeroSkin_BuyHeroSkinForFriend = 3051,
        HeroSkin_ConfirmBuyHeroSkinForFriend = 3052,
        HeroSkin_SearchFriend = 3053,
        HeroSkin_OnFriendListElementEnable = 3054,
        HeroSkin_OnUseSkinExpCard = 3055,
        HeroSkin_LeaveMsgForFriend = 3056,
        HeroView_LeaveMsgForFriend = 3057,

        //排位系统UI事件added by venomhuang
        Ranking_OpenForm = 3100,
        Ranking_CloseForm = 3101,
        Ranking_ChangePage = 3102,
        Ranking_Page0Scroll = 3103,
        Ranking_Page1Scroll = 3104,
        Ranking_DragModel = 3105,
        Ranking_ClickModel = 3106,
        Ranking_HoldDetail = 3107,
        Ranking_HoldDetailOff = 3108,
        Ranking_ElementEnable = 3109,
        Ranking_AddFriend = 3110,
        Ranking_ClickListItem = 3111,
        Ranking_ClickMe = 3112,
        Ranking_ClickCloseBtn = 3113,
        Ranking_ChangeView = 3114,
        Ranking_ShowAllRankType = 3115,

        Ranking_ChangeRankTypeToLadder = 3117,
        Ranking_ChangeRankTypeToHeroCount = 3118,
        Ranking_ChangeRankTypeToSkinCount = 3119,
        Ranking_ChangeRankTypeToAchievement = 3120,
        Ranking_ChangeRankTypeToWinCount = 3121,
        Ranking_ChangeRankTypeToConWinCount = 3122,
        Ranking_ChangeRankTypeToVip = 3123,
        Ranking_Friend_SNS_SendCoin = 3124,
        Ranking_Friend_GAME_SendCoin = 3125,
        Ranking_ChangeRankTypeToArena = 3126,
        Ranking_ChangeRankTypeToGod = 3127,
        Ranking_ArenaElementEnable = 3128,
        Ranking_ArenaAddFriend = 3129,
        Ranking_HeroChg_Title_Click = 3130,
        Ranking_HeroChg_Hero_Item_Enable = 3131,
        Ranking_HeroChg_Hero_Click = 3132,

        Ranking_Open_HeroChg_Form = 3133,
        Ranking_Open_HeroChg_Rule_Form = 3134,
        Ranking_Open_HeroChg_Detail_Form = 3135,
        Ranking_Click_HeroChg_Detail_Tab = 3136,
        Ranking_Click_Detail_Equip = 3137,
        Ranking_Detail_Symbol_Enable = 3138,
        Ranking_Close_Detail_Form = 3139,

        Ranking_ChangeRankTypeToMentorPoint = 3140,


        //玩家资料
        Player_Info_OpenForm = 3200,
        Player_Info_CloseForm = 3201,
        Player_Info_Tab_Change = 3202,
        Player_Info_Open_Pvp_Info = 3203,
        Player_Info_Open_Base_Info = 3204,
        Player_Info_Quit_Game = 3205,
        Player_Info_Quit_Game_Confirm = 3206,
        Player_Info_Most_Used_Hero_Item_Enable = 3207,
        Player_Info_Show_Rule = 3208,
        Player_Info_Most_Used_Hero_Item_Click = 3209,
        Player_Info_License_ListItem_Enable = 3210,
        Player_Info_Common_Hero_Enable = 3211,
        Player_Info_Update_Sub_Module = 3212,
        Player_Info_Honor_Item_Enable = 3213,
        Player_Info_Honor_Select_Change = 3214,
        Player_Info_Honor_Chosen = 3215,
        Player_Info_PvpHistory_Item_Enable = 3216,
        Player_Info_PvpHistory_Click_DetailInfo = 3217,
        Player_Info_PvpHistory_Click_Close_Detail = 3218,
        Player_Info_PvpHistory_Click_Statistics = 3219,
        Player_Info_PvpHistory_Click_AddFriend = 3220,

        Player_Info_Pvp_MainList_Click = 3221,
        Player_Info_Pvp_SubList_Click = 3222,
        Player_Info_Pvp_SubList_Show = 3223,
        Player_Info_Pvp_Graph_Show = 3224,
        Player_Info_Pvp_Detail_Show = 3225,
        Player_Info_Pvp_Share = 3226,

        Player_Info_Common_Hero_Main_List_Click = 3227,
        Player_Info_Common_Hero_Sub_List_Click = 3228,
        Player_Info_Common_Hero_Sort_List_Click = 3229,
        Player_Info_Common_Hero_Detail_List_Enable = 3230,
        Player_Info_Common_Hero_Sub_List_Show = 3231,
        
        Player_Info_Credit_Score_Reward_Enable = 3232,
        Player_Info_Achievement_Trophy_Click = 3233,

        //PVE竞技场相关
        Arena_OpenForm = 3300,
        Arena_TeamConfig = 3301,
        Arena_ChangeHeroList = 3302,
        Arena_BuyChangeTimes = 3303,
        Arena_ConfirmBuyChangeTimes = 3304,
        Arena_ResetCD = 3305,
        Arena_OpenPlayerInfoForm = 3306,
        Arena_OpenRankInfoForm = 3307,
        Arena_OpenRecordForm = 3308,
        Arena_OpenShopForm = 3309,
        

        Arena_StartFight = 3310,
        Arena_RankInfoMenuClick = 3311,

        Arena_ReciveDefTeamInfo = 3312,
        Arena_RankElementEnable = 3313,
        Arena_CDTimeEnd = 3314,
        Arena_RecordElementEnable = 3315,
        Arena_ResetByNewDay = 3316,
        Arena_ConfirmBuyResetCD= 3317,
        Arena_ConfirmResutlForm = 3318,
        Arena_OpenTips= 3319,
        Arena_CloseTps = 3320,
        Arena_OnClose = 3321,
        //登录系统
        Login_Platform_QQ = 3401,
        Login_Platform_WX = 3402,
        Login_Platform_Guest = 3403,
        Login_Platform_WTLogin = 3404,
        Login_Platform_Quit = 3405,
        Login_Start_Game = 3406,
        Login_Select_Server = 3407,
        Login_Platform_Logout = 3408,
        Login_Install_Weixin = 3409,
        Login_Trans_Visitor_Yes = 3410,
        Login_Trans_Visitor_No = 3411,
        Login_Change_Account_Yes = 3412,
        Login_Change_Account_No = 3413,
        Login_Enable_Start_Btn_Timer_End = 3414,
        Login_Platform_None = 3415,
        Login_Platform_QRWechat = 3416,
        Login_Update_Sub_Module = 3417,

        //选区选服
        TDir_ZoneGroupSelect = 3500,
        TDir_ZoneSelect = 3501,
        TDir_LastZoneSelect = 3502,
        TDir_ShowZoneSelect = 3503,
        TDir_BackToStartGame = 3504,
        TDir_ConnectLobby = 3505,

        // 新手引导
        Newbie_CloseIntroForm = 3600,
        Newbie_CloseGestureGuide = 3601,
        Newbie_CloseJoyStickGuide = 3602,
        Newbie_CloseSettle = 3603,
        Newbie_ConfirmAdvanceGuide = 3604,
        Newbie_RejectAdvanceGuide = 3605,
        Newbie_AchieveFormClose = 3606,
        Newbie_CloseIntroForm2 = 3607,
        Newbie_CloseTyrantAlert = 3608,
        Newbie_CloseTyrantTip = 3609,
        Newbie_CloseTyrantTip2 = 3610,
        Newbie_CloseSkillGesture = 3611,
        Matching_GuideAdvanceConfirm = 3613,
        Matching_GuideAdvanceCancel = 3614,
        Newbie_OldPlayerFirstFormClose = 3615,
        Newbie_BannerIntroDlg_ClickPrePage = 3616,
        Newbie_BannerIntroDlg_ClickNextPage = 3617,
        Newbie_BannerIntroDlg_DragStart = 3618,
        Newbie_BannerIntroDlg_DragEnd = 3619,
        Newbie_BannerIntroDlg_Close = 3620,
        Newbie_BannerIntroDlg_ClickConfirm = 3621,
        Newbie_BannerIntroDlg_OnMoveTimeUp = 3622,
        Newbie_ClickVictoryTips = 3623,
        Newbie_ClickCompleteNewbieGuide = 3624,
        Newbie_ClickNotCompleteNewbieGuide = 3625,
        Newbie_ClickProfitContinue = 3626,
        Newbie_BubbleTimeout = 3627,
        Newbie_CommomBubbleTimeout = 3628,

        //Gear装备
        Gear_Level_Up = 3700,
        Gear_Advance = 3701,
        Gear_Menu_Select = 3702,
        Gear_Item_Click = 3703,
        Gear_AdvMaterial_Click = 3704,
        Gear_Back_Advance = 3705,
        Gear_LvlUp_Max = 3706,
		
        HeroInfo_OpenHeroLvlUpPanel = 3750,
        HeroInfo_OpenHeroStarUpPanel = 3751,
        HeroInfo_OpenHeroAdvPanel = 3752,
        HeroInfo_OpenBaseInfoPanel = 3753,
        HeroInfo_OpenSkinPanel = 3754,
        HeroInfo_OpenGearPanel = 3755,
//        HeroInfo_SkillSelect = 3756,

        HeroInfo_LevelUp = 3757,
        HeroInfo_LevelUpMax = 3758,
        HeroInfo_GotoMall = 3759,
        HeroInfo_UpgradeFormClose = 3760,
        HeroInfo_Material_Direct_Buy = 3761,
        HeroInfo_Material_Direct_Buy_Confirm = 3762,
        HeroInfo_OpenPropPanel = 3763,
        HeroInfo_OpenBuyHeroForm = 3764,
        HeroInfo_SkillTipOpen = 3765,
        HeroInfo_SkillTipClose = 3766,
        HeroInfo_SymbolPropOpen = 3767,
        HeroInfo_SymbolPropClose = 3768,
        HeroInfo_Show2DImage = 3769,
        HeroInfo_Show3DImage = 3770,

        Quit_Game = 3798,
        Quit_GameCancel = 3799,
        #region 充值
        Pay_OpenFirstPayPanel = 3800,
        Pay_OpenRenewalPanel = 3801,
        Pay_GetFirstPayReward = 3802,
        Pay_GetRenewalReward = 3803,
        Pay_OpenBuyDianQuanPanel = 3804,
        Pay_FirstPayDianQuan = 3805,
        Pay_RenewalDianQuan = 3806,
        Pay_ClickDianQuanGift = 3807,
        Pay_BuyDianQuanPanelClose = 3808,
        Pay_ClickGetNewHeroPanel = 3809,
        Pay_PlayHeroVideo = 3810,
        Pay_TehuiShop = 3811,
        Pay_GotoTehuiShop = 3812,
        Pay_OpenBuyDianQuanPanelinLobby = 3813,
        Pay_ClosePayDianQuanForm = 3814,
        Pay_OpenBuyDianQuanPanelWithLobby = 3820,
        Pay_RevertToVisiable = 3821,
        #endregion 充值

        TDir_QuitGame = 3900,
        TDir_TryAgain = 3901,

        Guild_Open_Log_Form = 4010,                         //打开日志页面
        Guild_Setting_Down_Join_Level_Num = 4011,           //减少入队等级
        Guild_Setting_Up_Join_Level_Num = 4012,             //增加入队等级
        Guild_Setting_Down_Join_Grade = 4013,               //减少入队段位
        Guild_Setting_Up_Join_Grade = 4014,                 //增加入队段位
        Guild_Member_List_Sort_Position_Desc = 4015,        //战队成员列表按职位降序排序
        Guild_Member_List_Sort_Week_Rankpoint_Desc = 4016,  //战队成员列表按周竞技点降序排序
        Guild_Member_List_Sort_Season_Rankpoint_Desc = 4017,//战队成员列表按赛季竞技点降序排序
        Guild_Member_List_Sort_Online_Status_Desc = 4018,   //战队成员列表按在线状态降序排序

        Guild_Sign = 4020,
        Guild_Rankpoint_Season_Rank_List_Tab_Change = 4021,     //公会竞技赛季排行榜列表Tab改变
        Guild_ApplyList_Save_Pref = 4022,                       //公会申请列表配置保存
        Guild_Open_Transfer_Chairman_Without_Secure_Pwd_Confirm = 4023, //打开无二次密码转让队长确认
        Guild_Real_Transfer_Chairman = 4024,                            //真正队长转移
        Guild_Apply_List_Element_Head_Selected = 4025,                  //申请者列表项头像选中
        Guild_Recruit_Send_Recruit = 4026,                              //发送战队招募
        Guild_Recruit_Send_Recruit_CD_Timeout = 4027,                   //发送战队招募CD到
        Guild_Recruit_Apply_Join = 4028,                                //战队招募频道申请加入
        Guild_Apply_List_Element_Enabled = 4029,                        //战队申请列表元素enabled
        
        Guild_BindQQGroup = 4040,       //绑定QQ群
        Guild_UnBindQQGroup = 4041,     //解绑QQ群
        Guild_JoinQQGroup = 4042,       //加入QQ群
        Guild_UnBindQQGroupConfirm = 4043,  //解绑QQ群确认

        Guild_Match_OpenMatchForm = 4050,
        Guild_Match_OpenMatchRecordForm = 4051,
        Guild_Match_StartGame = 4052,
        Guild_Match_OBGame = 4053,
        //Guild_Match_TeamListElementEnabled = 4054,
        Guild_Match_RankTabChanged = 4055,
        Guild_Match_GuildScoreListElementEnabled = 4056,
        Guild_Match_MemberScoreListElementEnabled = 4057,
        Guild_Match_Invite = 4058,
        Guild_Match_Kick = 4059,
        Guild_Match_AppointOrCancelLeader = 4060,
        Guild_Match_AppointOrCancelLeaderConfirm = 4061,
        Guild_Match_Accept_Invite = 4062,
        Guild_Match_MemberInviteListElementEnabled = 4063,
        Guild_Match_RefreshGameStateTimeout = 4064,
        Guild_Match_Refuse_Invite = 4065,
        Guild_Match_ReadyGame = 4066,
        Guild_Match_CancelReadyGame = 4067,
        Guild_Match_OnMatchFormOpened = 4068,
        Guild_Match_OnMatchFormClosed = 4069,
        Guild_Match_KickConfirm = 4070,
        Guild_Match_ObWaitingTimeout = 4071,
        Guild_Match_RecordListElementEnabled = 4072,
        Guild_Match_RankSubTitleSliderValueChanged = 4073,
        Guild_Match_OpenMatchFormAndReadyGame = 4074,
        Guild_Match_Remind_Ready = 4075,
        Guild_Match_Open_Rule = 4076,
        Guild_Match_Team_List_Element_Enabled = 4077,
        Guild_Match_InviteConfirm = 4078,
        Guild_Match_RemindButtonCdOver = 4079,
        Guild_Match_OpenSignUpCardForm = 4080,
        Guild_Match_OpenSignUpListForm = 4081,
        Guild_Match_CreateSignUpCard = 4082,
        Guild_Match_OpenModifySignUpCardForm = 4083,
        Guild_Match_ModifySignUpCard = 4084,
        Guild_Match_ViewInvitation = 4085,
        //Guild_Match_AcceptInvitation = 4086,
        Guild_Match_AcceptInvitationBtnClick = 4087,
        Guild_Match_RefuseInvitationBtnClick = 4088,
        //Guild_Match_OpenTeamFullTipInInvitation = 4089,
        Guild_Match_SignUpCardPos1Click = 4090,
        Guild_Match_SignUpCardSelectPos1 = 4091,
        Guild_Match_SignUpCardPos2Click = 4092,
        Guild_Match_SignUpCardSelectPos2 = 4093,
        Guild_Match_SignUpListSortStateDesc = 4094,
        Guild_Match_SignUpListInviteBtnClick = 4095,
        Guild_Match_SignUpListElementEnabled = 4096,
        Guild_Match_SignUpListSortRankGradeDesc = 4097,
        Guild_Match_SignUpListSortLevelDesc = 4098,
        Guild_Match_SignUpListSortPosDesc = 4099,

        #region 改名
        NameChange_OpenPlayerNameChangeForm = 4100,
        NameChange_OpenGuildNameChangeForm = 4101,
        NameChange_ChangeName = 4102,
        NameChange_GuideToMall = 4103,
        NameChange_BuyNameChangeCardConfirm = 4104,
        #endregion

        Guild_Match_OnMatchRecordFormClosed = 4150,
        Guild_Match_OnSignUpCardFormClosed = 4151,
        Guild_Match_OnSignUpListFormClosed = 4152,
        Guild_Match_OnInvitationFormClosed = 4153,
        Guild_Match_OnOnlineInvitationFormClosed = 4154,

        #region 大小喇叭
        Speaker_Form_Open = 4200,
        Speaker_Form_Clsoe = 4201,
        Speaker_Send = 4202,
        Speaker_Tips_Open = 4203,
        Speaker_Tips_Close= 4204,
        Speaker_Tips_TimeUp = 4205,
        Speaker_EntryNode_Open = 4206,
        Speaker_EntryNode_TimeUp = 4267,
        Speaker_Form_Update = 4268,
        Speaker_OpenFactoryShop = 4269,
        #endregion

        #region progressbar
        ProgressBar_TimerGo = 4300,
        #endregion

        #region 运营活动
        Wealfare_OpenForm = 5001,
		Wealfare_CloseForm = 5002,
		Wealfare_ClickGet = 5003,
		Wealfare_Select = 5004,
		Wealfare_CheckInGet = 5005,
		Wealfare_MonthCheckInGet = 5006,
		Wealfare_MonthCheckFillConfirm = 5007,
		Wealfare_MonthCheckFillCancel = 5008,
		Wealfare_MonthCheckClickMore = 5009,
		Activity_OpenForm = 5011,
		Activity_CloseForm = 5012,
		Activity_Select = 5013,
		Activity_ClickGet = 5014,
		Activity_ClickMore = 5015,
		Activity_ClickGoto = 5016,
		Wealfare_DayCheckCellPress = 5020,
		Wealfare_DayCheckCellRelease = 5021,
		Wealfare_LevelAwardClick = 5022,
		Wealfare_DayCheckCellClicked = 5023,
		Activity_HeroShow_Back = 5050,
		Activity_AwardShow_Back = 5051,
		Activity_NoticeJump = 5052,
		Activity_BannerClick = 5053,
        IDIP_OpenForm = 5116,
        IDIP_CloseForm = 5117,
        IDIP_SelectItem = 5118,
        MSDK_NOTICE_CloseForm = 5119,
        IDIP_GOTO_COMPLETE = 5120,
        IDIP_QQVIP_OpenWealForm = 5121,
        MENU_PopupMenuFinish = 5122,
        WEB_OpenURL = 5123,
		WEB_OpenHome = 5124,
        OPEN_QQ_Buluo = 5125,
        NOBE_OPEN_Form = 5126,
        NOBE_TAB_Change = 5127,
        NOBE_CLOSE_Form = 5128,
        NOBE_PAY = 5129,
        NOBE_GOTO_STROE = 5130,
        NOBE_LEFT = 5131,
        NOBE_RIGHT = 5132,
        NOBE_LEFT_Nobe_Level = 5133,
        NOBE_RIGHT_Nobe_Level = 5134,
        NOBE_CHANGEHEAD_ICON_OPEN_FORM = 5135,
        NOBE_CHANGEHEAD_ICON_CLOSE_FORM = 5136,
        NOBE_CHANGEHEAD_ICON_Select_HeadIDX = 5137,
        WEB_IntegralHall = 5138,  //积分墙
        MSDK_NOTICE_Btn_Complete = 5139,
        Activity_Select_TitleMenu = 5140,
        GameCenter_OpenWXRight = 5141,
        Activity_Exchange = 5142,
        XinYue_Open = 5143,
        GameCenter_OpenQQRight = 5144,
        OPEN_HELPME = 5145,
        OPEN_HELPMEMONEY = 5146,
        GameCenter_OpenGuestRight = 5147,
        Pandroa_ShowActBox = 5148,
        Activity_PtExchange = 5149,
        Activity_ExchangeConfirm = 5150,
        Activity_PtExchangeConfirm = 5151,
        OPEN_TongCai = 5152,
        Activity_ExchangeCountReady = 5153,
        Activity_PtExchangeCountReady = 5154,

        //兑换物品个数选择界面
        Activity_OnAddExchangeCount = 5155,
        Activity_OnDecreseExchangeCount = 5156,
        Activity_OnMaxExchangeCount = 5157,
        Activity_ExchangeHeroSkinConfirm = 5158,
        NOBE_LevelUp_Form_Close = 5159,
        #endregion 运营活动

        #region 更换头像
        HeadIcon_Change_Tab_Click = 5200,
        HeadIcon_Change_Icon_Click = 5201,
        HeadIcon_Change_Confirm = 5202,
        HeadIcon_Change_Form_Close = 5203,
        HeadIcon_Change_Form_Open = 5204,
        HeadIcon_Change_Item_Enable = 5205,
        #endregion 更换头像

        #region 赠礼中心
        Mall_GiftCenter_Open = 5500,
        Mall_GiftCenter_Close = 5501,
        Mall_GiftFadeInAnim_End = 5502,
        Mall_OnGiftMenuChanged = 5503,
        Mall_OnGiftSubMenueChanged = 5504,
        Mall_GiftEnable = 5505,
        Mall_GiftSortClick = 5506,
        Mall_GiftSortChange = 5507,
        Mall_GiftShowDetail = 5508,
        Mall_GiftGive = 5509,
        #endregion 赠礼中心

        #region 商城事件
        Mall_OpenForm = 6000,
        Mall_CloseForm = 6001,
        Mall_Mall_Tab_Change = 6002,
		Mall_Product_Buy = 6011,
        Mall_Continue_Show_Reward = 6012,
        Mall_Product_Confirm_Buy = 6013,
        Mall_Open_Item_Prop_Gifts_Tab = 6014,
        Mall_Open_Factory_Shop_Tab = 6015,
        Mall_Prepare_Continue_Show_Reward = 6016,
        Mall_Appear = 6017,
        Mall_GoToSymbolTab = 6018,
        
        //轮盘抽奖
        Mall_Roulette_Tab_Change = 6019,
        Mall_Roulette_Buy_One = 6020,
        Mall_Roulette_Buy_Five = 6021,
        Mall_Roulette_Buy_One_Confirm = 6022,
        Mall_Roulette_Buy_Five_Confirm = 6023,
        Mall_Roulette_Spin_Change = 6024,
        Mall_Roulette_Spin_End = 6025,
        Mall_Roulette_Open_Extern_Reward_Tip = 6026,
        Mall_Roulette_Draw_Extern_Reward = 6027,    //领取额外奖励
        Mall_Roulette_Reset_Reward_Draw_Cnt = 6028,    //领取额外奖励
        Mall_Action_Mask_Reset = 6029,
        Mall_Roulette_Show_Reward_Item = 6030,
        Mall_Roulette_Show_Rule = 6031,
        Mall_Roulette_Tmp_Reward_Enable = 6032,
        Mall_Skip_Animation = 6033,
        Mall_Roulette_Close_Award_Form = 6034,
        Mall_GoToSkinTab = 6035,
        Mall_GoToTreasureTab = 6036,
        Mall_GotoCouponsTreasureTab = 6037,
        Mall_GotoDianmondTreasureTab = 6038,
        Mall_Skip_Mask_Reset = 6039,
        Mall_Get_AWARD_CLOSE_FORM = 6040,

        Mall_HeroItem_Enable = 6050,
        Mall_Hero_JobSelect = 6051,
        Mall_Hero_OnBuyBtnClick = 6052,
        Mall_SkinItem_Enable = 6053,
        Mall_Skin_JobSelect = 6054,
        Mall_Skin_OnBuyBtnClick = 6055,
        Mall_Jump_Form = 6056,
        Mall_Hero_Own_Flag_Change = 6057,
        Mall_Skin_Own_Flag_Change = 6058,

        Mall_Mystery_ItemEnable = 6060,
        Mall_GoToMysteryTab = 6061,
        Mall_Close_Mystery_Shop = 6062,
        Mall_Mystery_On_Open_Buy_Form = 6063,
        Mall_Mystery_On_Buy_Item = 6064,
        Mall_Mystery_On_Confirm_Buy_Item = 6065,
        Mall_Mystery_On_Roll_Discount = 6066,
        Mall_Mystery_On_Time_End = 6067,
        Mall_Mystery_On_Buy_Hero_Not_Own = 6068,
        Mall_Mystery_On_Default_Item_Click = 6069,

        Mall_Recommend_On_Lottery_Buy = 6070,
        Mall_Recommend_On_Lottery_Buy_Confirm = 6071,
        Mall_Recommend_Tab_Change = 6072,
        Mall_Recommend_On_Exchange = 6073,
        Mall_Recommend_On_Exchange_Confirm = 6074,
        Mall_Recommend_On_Buy = 6075,
        Mall_Recommend_On_Buy_Confirm = 6076,
        Mall_Recommend_Hero_Skill_Down = 6077,
        Mall_Recommend_Hero_Skill_Up = 6078,
        Mall_Recommend_Exchange_More = 6079,
        Mall_Recommend_List_Tab_Change = 6080,
        Mall_Recommend_Hero_List_Item_Enable = 6081,
        Mall_Recommend_Skin_List_Item_Enable = 6082,
        Mall_Recommend_Timer_End = 6083,
        Mall_GoToRecommendHeroTab = 6084,
        Mall_GoToRecommendSkinTab = 6085,
        Mall_GoToBoutiqueTab = 6086,

        Mall_Boutique_New_Arrival_Enable = 6087,
        Mall_Boutique_Hot_Sale_Enable = 6088,
        Mall_Boutique_Factory_Product_Click = 6089,
        Mall_Boutique_Factory_Product_Confirm_Buy = 6090,

        Mall_Update_Sub_Module = 6091,
        Mall_Sort_Type_Select = 6092,
        Mall_Sort_Type_Change = 6093,
        Mall_Buy_Product_Confirm = 6094,

        Mall_Crystal_More = 6095,
        Mall_Cystal_List_Item_Enable = 6096,

        Mall_Crystal_On_Exchange = 6097,
        Mall_Crystal_On_Exchange_Confirm = 6098,
        Mall_CryStal_On_TabChange = 6099,

        Mall_Factory_On_TabChange = 6100,
        #endregion

		#region 购买选择
		BuyPick_Add = 6201,
		BuyPick_Dec = 6202,
		BuyPick_Max = 6203,
		BuyPick_Confirm = 6204,
		BuyPick_Cancel = 6205,
        BuyPick_QQ = 6206,
        BuyPick_QQVIP = 6207,
        BuyPick_QQ_VIP = 6208,
        DeepLink_OnClick = 6209,
        QQBOX_OnClick = 6210,
        BuyPick_ConfirmFactoryShopBuy = 6211,
        BuyPcik_factoyShopTipsForm = 6212, //购买英雄检查是否在特卖表有配置
        BuyPcik_factoyShopTipsCancelForm = 6213,
        BuyPick_CloseForm = 6214,
        #endregion

        #region 托管英雄
        Trusteeship_Accept = 6300,
        Trusteeship_Cancel = 6301,
        #endregion

        #region 画质调整
        Degrade_Quality_Accept = 6400,
        Degrade_Quality_Cancel = 6401,
        #endregion

        #region 分享
        Share_NewHero = 7000,
        Share_CloseNewHeroorSkin = 7001,
        Share_CloseNewHeroShareForm = 7002,
        Share_ShareFriend = 7003,
        Share_ShareTimeLine = 7004,
        Share_ShareSavePic = 7005,
        Share_SharePVPScore = 7006,
        Share_SharePVPSCcoreClose = 7007,
        Share_ClosePVPSCoreOld = 7008,
        Share_MysteryDiscount = 7009,
        Share_ClosePVPAchievement = 7010,
        Share_ShowPVPSettleData = 7011,
        Share_ShowPVPSettleDataClose = 7012,
        Share_ShowUpdateGradeShare = 7013,
        Share_ShowUpdateGradeShareClose = 7014,
        Share_DownloadPlayConfirm = 7015,
        Share_DownloadPlayCancel = 7016,
        #endregion

        #region VOICE
        VOICE_HoldStart_VOCEBtn = 8000,
        VOICE_Hold_VOCEBtn = 8001,
        VOICE_HoldEnd_VOCEBtn = 8002,

        BannerImage_HoldStart = 8003,
        BannerImage_HoldEnd = 8004,

        VOICE_OpenSpeaker = 8005,
        VOICE_OpenMic = 8006,
        BannerImage_ClickItem = 8007,
        BannerImage_Item_Enable = 8008,
        
        #endregion

        Particle_PlayLobbyBtnEffect = 9000,
        Particle_PlayLobbyBtnTopEffect = 9001,
        Particle_PlayLobbyBtnLeftEffect = 9002,
        Particle_PlayLobbyBtnRightEffect = 9003,

        #region pve复活
        ReviveHero_OnSelectBuff0 = 9010,
        ReviveHero_OnSelectBuff1 = 9011,
        ReviveHero_OnSelectBuff2 = 9012,
        ReviveHero_OnReviveBtnClick = 9013,
        ReviveHero_OnExitBtnClick = 9014,
        ReviveHero_OnConfirmRevive = 9015,
        ReviveHero_OnReviveFailed = 9016,
        ReviveHero_OnReviveTimeout = 9017,
        #endregion

        #region 排位赛
        Ladder_StartMatching = 9050,
        Ladder_ShowHistory = 9051,
        Ladder_ShowRecent = 9052,
        Ladder_ShowRules = 9053,
        Ladder_ExpandHistoryItem = 9054,
        Ladder_ShrinkHistoryItem = 9055,
        Ladder_ConfirmSeasonRank = 9056,
        Ladder_ReqGetSeasonReward = 9057,
        Ladder_GetSeasonRewardDone = 9058,
        Ladder_OnEntryFormOpened = 9059,
        Ladder_OnEntryFormClosed = 9060,
        Ladder_OnClickBpGuide = 9061,
        Ladder_OnClickShowRecentUsedHero = 9062,
        Ladder_OnClickHideRecentUsedHero = 9063,
        Ladder_ShowGameInfo = 9064,
        Ladder_ShowBraveScoreRule = 9065,
        Ladder_GetSkinReward = 9066,
        #endregion

        #region 新结算面板
        SettlementSys_ProfitContinue = 10000,
        SettlementSys_ShowRankTip = 10001,
        SettlementSys_HideRankTip = 10002,
        SettlementSys_TimerEnd = 10003,
        SettlementSys_ClickBack = 10004,
        SettlementSys_ClickAgain = 10005,
        SettlementSys_ClickShare = 10006,
        SettlementSys_ClickStatistics = 10007,
        SettlementSys_ShowReport = 10008,
        SettlementSys_CloseReport = 10009,
        SettlementSys_DoReport = 10010,
        SettlementSys_OnCloseProfit = 10011,
        SettlementSys_OnCloseSettlement = 10012,
        SettlementSys_SwitchAddFriendReport = 10013,
        SettlementSys_ClickAddFriend = 10014,
        SettlementSys_ClickLadderContinue = 10015,
        SettlementSys_ClickShowAchievements = 10016,
        SettlementSys_LeftSwitchPVPAchievement = 10017,
        SettlementSys_RightSwitchPVPAchievement = 10018,
        SettlementSys_OpenSharePVPAchievement = 10019,
        SettlementSys_CloseSharePVPDefeat = 10020,
        SettlementSys_OpenSharePVPDefeat = 10021,
        SettlementSys_ShareDefeatAddBarrage = 10022,
        SettlementSys_ShareDefeatSelectBarrage = 10023,
        SettlementSys_ShareDefeatBarrageEnable = 10024,
        SettlementSys_CloseShareDefeatBarrage = 10025,
        SettlementSys_ClickItemDisplay = 10026,
        //SettlementSys_ContinuousWinLastMarkShinningEnd = 10027,     //最后一个标记闪烁结束
        //SettlementSys_ContinuousWinNoLastMarkShinningEnd = 10028,   //非最后一个标记闪烁结束
		SettlementSys_SaveReplay = 10029,   //保存本地录像
        SettlementSys_ShowAddFriendBtn = 10030,
        SettlementSys_ShowReportBtn = 10031,
        SettlementSys_ShowDianLaBtn = 10032,
        SettlementSys_ClickDianLa = 10033,
        SettlementSys_OpenPlayerDetailInfo = 10034,
        SettlementSys_GetMoreGold = 10035,
        SettlementSys_Ladder_OnAnimatiorBravePanelShowInEnd = 10036,
        SettlementSys_Ladder_OnAnimatiorBraveProgressFillEnd = 10037,
        SettlementSys_Ladder_OnAnimatiorBraveDigitalJitterEnd = 10038,
        SettlementSys_Ladder_OnAnimatiorBraveDigitalReductionEnd = 10039,
        SettlementSys_Ladder_OnAnimatiorBraveDigitalRisingStarEnd = 10040,
        SettlementSys_Ladder_OnAnimatiorBraveProgressFillFull = 10041,
        #endregion

        #region 局内装备
        BattleEquip_Form_Open = 10100,
        BattleEquip_Form_Close = 10101,
        BattleEquip_TypeList_Select = 10102,
        BattleEquip_Item_Select = 10103,
        BattleEquip_BagItem_Select = 10104,
        BattleEquip_BuyBtn_Click = 10105,
        BattleEquip_SaleBtn_Click = 10106,
        BattleEquip_RecommendEquip_Buy = 10107,
        BattleEquip_OpenEquipTree = 10108,
        BattleEquip_CloseEquipTree = 10109,
        BattleEquip_SelectItemInEquipTree = 10110,
        BattleEquip_BackEquipListSelectedChanged = 10111,
        BattleEquip_BackEquipListScrollChanged = 10112,
        BattleEquip_BackEquipListMoveLeft = 10113,
        BattleEquip_BackEquipListMoveRight = 10114,
        BattleEquip_ShowOrHideInBattle = 10115,
        BattleEquip_ChangeSelfRcmEuipPlan = 10116,
        BattleEquip_OpenSelfRcmEuipPlanForm = 10117,
        #endregion

        #region 局内引导tips相关
        Battle_Guide_PanelMisson_1_Close = 10200,
        Battle_Guide_PanelMisson_2_Close = 10201,
        Battle_Guide_PanelMisson_3_Close = 10202,
        Battle_Guide_CloseTrainLevel_Award = 10203,
        #endregion

        #region 赏金赛事相关
        Union_Battle_ClickEntry = 10300,
        Union_Battle_BattleEntryGroup_Click = 10301,
        Union_Battle_SubBattleEntryGroup_Click = 10302,
        Union_Battle_Click_SingleStartMatch = 10303,
        Union_Battle_Click_Rank = 10304,
        Union_Battle_ConfirmBuyItem = 10305,
        Union_Battle_Click_Rule = 10306,
        Union_Battle_RewardMatch_TimeUp = 10307,
        Union_Battle_BuyTiketClick = 10308,
        Union_Battle_Click_MatchType_Menu = 10309,
        Union_Battle_Click_DateType_Menu = 10310,
        Union_Battle_Rank_ClickDetail = 10311,
        Union_Battle_Rank_DateList_Element_Enable = 10312,
        Union_Battle_Rank_TeamList_Element_Enable = 10313,
        Union_battle_Click_StartOneMatchRound = 10314,
        Union_Battle_Click_RewardIntro = 10315,
        Union_Battle_Click_GetReward = 10316,
        Union_Battle_GotReward = 10317,
        Union_Battle_RewardIntro_ItemEnable = 10318,
        Union_Battle_Click_ExChgRewwad = 10319,
        Union_Battle_CliCk_LoseTips = 10320,
        Union_Battle_Click_GetRewardTips = 10321,
        Union_Battle_Click_BattleVideo = 10322,
        Union_Battle_Click_BattleNews = 10323,
        #endregion

        #region 自定义推荐装备相关
        CustomEquip_OpenForm = 10400,
        CustomEquip_FormClose = 10401,
        CustomEquip_UsageListSelect = 10402,
        CustomEquip_ItemClick = 10403,
        CustomEquip_ViewEquipTree = 10404,
        CustomEquip_ChangeHero = 10405,
        CustomEquip_ModifyEquip = 10406,
        CustomEquip_ConfirmModify = 10407,
        CustomEquip_CancleModify = 10408,
        CustomEquip_AddEquip = 10409,
        CustomEquip_DeleteEquip = 10410,
        CustomEquip_RevertDefault = 10411,
        CustomEquip_ViewGodEquip = 10412,
        CustomEquip_Expand = 10413,
        CustomEquip_PackUp = 10414,
        CustomEquip_HeroTypeListSelect = 10415,
        CustomEquip_HeroListItemEnable = 10416,
        CustomEquip_HeroListItemClick = 10417,
        CustomEquip_OwnFlagChange = 10418,
        CustomEquip_GodEquipItemEnable = 10419,
        CustomEquip_GodEquipUseBtnClick = 10420,
        CustomEquip_EditItemClick = 10421,
        CustomEquip_BackEquipTurnLeft = 10422,
        CustomEquip_BackEquipTurnRight = 10423,
        CustomEquip_BackEquipListElementEnable = 10424,
        CustomEquip_GodEquipReqTimeOut = 10425,
        CustomEquip_CircleTimerUp = 10426,
        CustomEquip_ShowConfirmRevertDefaultTip = 10427,
        CustomEquip_OnBackEquipListSelectChanged = 10428,
        CustomEquip_OnEquipTreeItemSelected = 10429,
        CustomEquip_OnEquipTreeClosed = 10430,
        CustomEquip_OnGodEquipTabChanged = 10431,
        CustomEquip_GodEquipSysUseBtnClick = 10432,
        CustomEquip_IWantJudgeBtnClick = 10433,
        CustomEquip_JudgeMarkSubmitBtnClick = 10434,
        CustomEquip_OpenJudgeRule = 10435,
        CustomEquip_OpenSelfEquipPlanForm = 10436,
        CustomEquip_ChangeCurEquipPlanName = 10437,
        CustomEquip_ChangeEquipPlanListItemName = 10438,
        CustomEquip_UseEquipPlanListItem = 10439,
        CustomEquip_ConfirmChgEquipPlanName = 10440,
        #endregion

        #region 七日签到
        SevenCheck_OpenForm = 10500,
        SevenCheck_CloseForm = 10501,
        SevenCheck_Request = 10502,
        SevenCheck_LoginOpen = 10503,
        Day14Check_OnItemEnable = 10504,
        Day14Check_OnRequestCheck = 10505,
        Day14Check_CloseForm = 10506,
        Day14Check_LeftUIItemEnable = 10507,
        Day14Check_OpenForm = 10508,
        #endregion


        #region 局内聊天

        InBattleMsg_OpenForm = 11000,
        InBattleMsg_CloseForm = 11001,
        InBattleMsg_ClickBGMap = 11002,
        InBattleMsg_TabChange = 11003,
        InBattleMsg_ListElement_Enable = 11004,
        InBattleMsg_ListElement_Click = 11005,

        // 局内打字聊天
        InBattle_InputChat_SwitchCamp = 11006,      // 切换阵营
        InBattle_InputChat_InputClick = 11007,      // 输入

        //
        InBatShortcut_OpenForm = 11008,
        InBatShortcut_CloseForm= 11009,

        InBatShortcut_LeftItem_Enable = 11010,
        InBatShortcut_Delete = 11011,
        InBatShortcut_Record = 11012,
        InBatShortcut_UseDefault = 11013,
        InBatShortcut_Change = 11014,
        InBatShortcut_OK = 11015,
        InBatShortcut_Cancle = 11016,
        InBatShortcut_RightTab_Change = 11017,
        InBatShortcut_RightItem_Enable = 11018,
        InBatShortcut_RightItem_Click = 11019,
        InBatShortcut_UseDefault_Ok = 11020, 


        #endregion



        #region 新的主线任务

        Task_ClickLevelNode = 12000,                // 点击等级节点
        Task_ClickUnlockBtn = 12001,                // 点击解锁功能去中的 前往按钮
        Task_ClickGetLevelReward = 12002,           // 点击等级奖励中的 领取按钮
        Task_ClickCheckLevelTask = 12003,           // 点击 等级任务按钮
        Task_CloseCheckLevelTask = 12004,           // 关闭 等级任务2级菜单
        Task_LevelElemntEnable = 12005,     // 任务列表 element on enable 事件

        #endregion

        #region 观战与回放外围
        OB_Form_Open = 12100,
        OB_Form_Close = 12101,
        OB_Video_Tab_Click = 12102, //大神 好友 本地
        OB_Video_Sub_Tab_Click = 12103,//英雄类型
        OB_Video_Enter = 12104, //进入观看
        OB_Element_Enable = 12105, 
        OB_Video_Editor_Click = 12106,//编辑按钮(删除)
        OB_Video_Delete = 12107 , //删除(目前只有本地录像可以删除)
        OB_Video_Delete_Confirm = 12108,
        OB_Video_Enter_Confirm = 12109,//确认观看录像
        OB_Video_Btn_VideoMgr_Click = 12110, // 按钮弹出gamejoy录像视频管理界面
        #endregion 观战与回放外围

		#region 观战与回放

		Watch_CameraDraging = 13000,
		Watch_PickCampList_1 = 13001,
		Watch_PickCampList_2 = 13002,
		Watch_ClickPlay = 13003,
		Watch_ClickSpeedUp = 13004,
		Watch_ClickSpeedDown = 13005,
		Watch_Quit = 13006,
		Watch_ClickCampFold_1 = 13007,
		Watch_ClickCampFold_2 = 13008,
		Watch_ClickBottomFold = 13009,
		Watch_ClickReplayTalk = 13010,
		Watch_ClickCampFold_1_End = 13011,
		Watch_ClickCampFold_2_End = 13012,
		Watch_QuitConfirm = 13013,
		Watch_QuitCancel = 13014,
		Watch_FormClosed = 13015,
		Watch_HideView = 13016,
        Watch_JudgePause = 13017,
        Watch_SelectHorizonBoth = 13018,
        Watch_SelectHorizonCamp_1 = 13019,
        Watch_SelectHorizonCamp_2 = 13020,
        Watch_ClickBottomFold_End = 13021,
        Watch_ClickBottomEquipFold = 13022,
        Watch_ClickBottomEquipFold_Over = 13023,

        #endregion 观战与回放

        #region 录像

        #region iOS 9 录像
        ReplayKit_Start_Recording = 14000,
        ReplayKit_Pause_Recording = 14001,
        ReplayKit_Preview_Record  = 14002,
        ReplayKit_Discard_Record  = 14003,
        #endregion

        Record_Save_Moment_Video = 14010,
        Record_Save_Moment_Video_Cancel = 14011,
        Record_Check_WhiteList_TimeUp = 14012,
        #endregion

        #region 网络加速器
        NetworkAccelerator_TurnOn = 14100,
        NetworkAccelerator_Ignore = 14101,
        #endregion

        #region 二次密码
        SecurePwd_ApplyForceCloseConfirm = 15000,
        SecurePwd_ApplyCancelForceCloseConfirm = 15001,
        SecurePwd_OpenSetPwdForm = 15002,
        SecurePwd_OpenModifyPwdForm = 15003,
        SecurePwd_OpenClosePwdForm = 15004,
        SecurePwd_OnSetPwd = 15005,
        SecurePwd_OnOpCancel = 15006,
        SecurePwd_OnModifyPwd = 15007,
        SecurePwd_OnClosePwd = 15008,
        SecurePwd_OpenApplyClosePwdForm = 15009,
        SecurePwd_OnApplyClose = 15010,
        SecurePwd_OnCancelApplyClose = 15011,
        SecurePwd_OnValidateConfirm = 15012,
        SecurePwd_OnValidateCancel = 15013,
        #endregion

        #region Battle
        Battle_EnemyHeroAtkBtn_Down = 15100,
        Battle_EnemyHeroAtkBtn_Up = 15101,
        Battle_DeadInfo_Click = 15102,
        Battle_DeadInfoForm_Close_Click = 15103,
        #endregion

        #region 成就-奖杯
        Achievement_Open_Overview_Form = 15200, //弃用
        Achievement_Open_List_Form = 15201, //弃用
        Achievement_Get_Award = 15202,  //弃用
        Achievement_List_Element_Enabled = 15203,   //弃用
        Achievement_ShowShareBtn = 15204,
        Achievement_OpenAwardForm = 15205,  //弃用
        Achievement_Filter_Menu_Change = 15206,
        Achievement_Trophy_Enable = 15207,
        Achievement_Trophy_Click = 15208,
        Achievement_Item_Enable = 15209,
        Achievement_Browse_All_Rewards = 15210,
        Achievement_Trophy_Reward_Info_Enable = 15211,
        Achievement_Get_Trophy_Reward = 15212,
        Achievement_Close_Share_Form = 15213,
        Achievement_Change_Selected_Trophy = 15214,
        Achievement_Selector_Trophy_Enable = 15215,
        Achievement_Selector_Trophy_Select = 15216,
        Achievement_Selector_Trophy_Select_Confirm = 15217,
        Achievement_Show_Rule = 15218,
        #endregion

        #region 礼包
        GiftBag_OnShowDetail = 15300,

        #endregion


        #region mentor
        Mentor_IWant = 15500,
        Mentor_MentorQuest = 15501,
        Mentor_OpenRequestList = 15502,
        Mentor_AddMentor = 15503,
        Mentor_FamousRights = 15504,
        Mentor_RefuseRequest = 15505,
        Mentor_WatchHisMentor = 15506,
        Mentor_DynamicInfo = 15507,
        Mentor_FriendFormTabChange = 15508,
        Mentor_RequestListOnEnable = 15509,
        Mentor_AcceptRequest = 15510,
        Mentor_CloseRequestList = 15511,
        Mentor_RemoveMentor = 15512,
        Mentor_AddApprentice = 15513,
        Mentor_OpenPrivilegePage = 15514,
        Mentor_PrivilegePageLeft = 15515,
        Mentor_PrivilegePageRight = 15516,
        Mentor_PrivilegeListEnable = 15517,
        Mentor_OpenMentorPage = 15518,
        Mentor_ApplyRequest = 15519,
        Mentor_OpenMentorIntro = 15520,
        Mentor_GetMoreMentor = 15521,
        #endregion

        #region loading界面
        Loading_LoadingFromOpen = 15600,
        Loading_LoadingFromClose = 15601,
        #endregion
        #region 自动测试
        AutoTest_Test5v5 = 15650,
        #endregion

        #region 第三方

        Partner_OpenForm = 15700,
        Partner_OpenXunYou_Buy = 15701,
        Partner_Refresh_Entry = 15702,
        Partner_OpenXunYou_Buy_Confirm = 15703,
        Partner_OpenTongcai_Buy_Confirm = 15704,
        #endregion


        #endregion



        #region  RGame_Event_Ids
        RGame_Event_Begin = 20000,
        RGM_InputBox_Confirm,                                       

        RFriend_OpenForm = 20005,    
        RFriend_CloseForm,
        RFriend_MenuItemUpdate,
        RFriend_MenuItemClick,   
        RFriend_FriendItemUpdate,
        RFriend_FriendItemClick,           
        RFriend_Xuegongwen,   //加关注
        RFriend_DelectChatRecords,  //删除聊天记录
        RFriend_WriteMood_Open,  
        RFriend_WriteMood_BackPanel,
        RFriend_WriteMood_AddPhoto,    
        RFriend_WriteMood_Release,

        RFriend_SearchPanel_Open,
        RFriend_SearchPanel_Close,
        RFriend_SearchPanel_MenuItemUpdate,
        RFriend_SearchPanel_MenuItemClick,
        RFriend_SearchPanel_FriendItemUpdate,
        RFriend_SearchPanel_FriendItemClick,

        RFriend_DianZan,           //点赞
        RFriend_Comment,           //评论
        RFriend_AddFriend,
        RFriend_Search,


        //匹配
       
        RMatch_MatchBox_OpenForm,
        RMatch_MatchBox_CloseForm,
        RMatch_MatchBox_UpdateMember,
        RMatch_MatchBox_Confirm,
        RMatch_MatchEntry_ReqLeave,
        RMatch_MatchEntry_Open,
        RMatch_MatchEntry_Close,
        RMatch_MatchEntry_CloseMsg,

        Login_Account_Response,
        Login_Fresh_User_Info,
        #endregion

        // bodong add
        // used to change Dictionary to Array
        // 这个只能放最后 谁在它后面加东西 拖出去枪毙
        MAX_Tag
        // 别在我后面加东西 不谢
    };

    //--------------------------------------------------
    /// UI事件参数
    //--------------------------------------------------
    public struct stUIEventParams
    {
        public stSnsFriendEventParams snsFriendEventParams;     //传递好友信息
        public stItemGetInfoParams itemGetInfoParams;           //传递获得信息用
		public stSkillTipParams skillTipParam;                  //skillTip文本    
        public stSkillPropertyPrams[] skillPropertyDesc;             //技能描述属性
        // public ResDT_SkillDescription[] skillPropertyDesc;             //技能描述属性

        public stHeroSkinEventParams heroSkinParam;             //英雄皮肤信息
        public CUseable iconUseable;                            //传递useable用
        public SkillSlotType m_skillSlotType;                   //技能按钮类型       

        public enSelectGameType heroSelectGameType;           // 选将模块游戏类型 

        public stSymbolEventParams symbolParam;         //符文类型

        public stSymbolTransformParams symbolTransParam;  //符文制作参数

        public stDianQuanBuyParam dianQuanBuyPar;         //钻石参数

        public stOpenHeroFormParams openHeroFormPar;

        public stBattleEquipParams battleEquipPar;        //局内装备参数

        public stFriendHeroSkinParams friendHeroSkinPar;    //好友赠送英雄皮肤参数

        public UInt32 heroId;                           //传递英雄id用
        public List<uint> tagList;                   //传递英雄id列表用
        public UInt32 taskId;                           //传递任务id用

        public UInt32 weakGuideId;                      //弱引导id用

        public int selectIndex;                         //传递选中下标用

        public int tag;                                 //传递int类tag用
        public int tag2;                                //传递int类tag用
        public int tag3;                                //传递int类tag用   

        public uint tagUInt;                            //传递uint类tag用

        public string tagStr;                           //传递string类tag用
        public string tagStr1;

        public uint commonUInt32Param1;                 //通用uint参数1
        public UInt16 commonUInt16Param1;               //通用uint16参数1
        public UInt64 commonUInt64Param1;               //通用uint64参数1
        public UInt64 commonUInt64Param2;               //通用uint64参数2


       
        public int skillSlotId;                         //技能槽位Id  
                                                        // 队伍管理页面类型
        public float sliderValue;                       //Slider控件的值
        public bool togleIsOn;                          //toggle控件是否被选中

        public bool commonBool;                         //通用bool值

        public enUIEventID srcUIEventID;                //源事件
        public string pwd;                              //二级密码

        public CUseableContainer useableContainer;      //自动出售道具传递道具列表用

        public GameObject commonGameObject;             //通用保存GameObject对象
    };
       
    //--------------------------------------------------
    /// UI事件
    //--------------------------------------------------
    public class CUIEvent
    {
        public CUIFormScript m_srcFormScript;                           //源Form
        public GameObject m_srcWidget;                                  //源控件
        public CUIComponent m_srcWidgetScript;                          //源控件UI组件基类
        public CUIListScript m_srcWidgetBelongedListScript;             //源控件所属List(仅当源控件作为List元素时有效)
        public int m_srcWidgetIndexInBelongedList { get; set; } //源控件在所属List中的索引(仅当源控件作为List元素时有效)
        public PointerEventData m_pointerEventData;                     //源操作事件数据
        public stUIEventParams m_eventParams;                           //事件参数
        public enUIEventID m_eventID;                                   //事件ID

        public bool m_inUse = false;

        //--------------------------------------
        /// Clear  
        //--------------------------------------
        public void Clear()
        {
            m_srcFormScript = null;
            m_srcWidget = null;
            m_srcWidgetScript = null;
            m_srcWidgetBelongedListScript = null;
            m_srcWidgetIndexInBelongedList = -1;
            m_pointerEventData = null;
            m_eventID = enUIEventID.None;

            m_inUse = false;
        }
    };

#if UNITY_EDITOR

    public static class CUIEventEnumCheker
    {
        public static bool IsIgnore(int Val, int[] IgnoreLists)
        {
            foreach(int i in IgnoreLists)
            {
                if( i == Val)
                {
                    return true;
                }
            }

            return false;
        }

        public static void Check()
        {
            int[] IgnoreList = new int[]
            {
                // 如果是故意设置成一样的 请将数值添加到这里
                // 比如：503, 1153
            };


            string[] EnumNames = Enum.GetNames(typeof(enUIEventID));
            Dictionary<int, string> Collections = new Dictionary<int, string>();

            foreach (string name in EnumNames)
            {
                int Value = Convert.ToInt32(Enum.Parse(typeof(enUIEventID), name));

                string ExistsName = "";

                if (Collections.TryGetValue(Value, out ExistsName))
                {
                    if( !IsIgnore(Value, IgnoreList))
                    {
                        DebugHelper.Assert(false, "repeat enUIEventID enum value, {0} == {1}, value={2}", ExistsName, name, Value);
                    }
                }
                else
                {
                    Collections.Add(Value, name);
                }
            }

        }
    }

#endif
};