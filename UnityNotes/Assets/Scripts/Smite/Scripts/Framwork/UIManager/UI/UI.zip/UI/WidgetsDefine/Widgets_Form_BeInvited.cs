namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_BeInvited
	{
		EN_Button_Send = 0,
		EN_Button_Confirm = 1,
		EN_HeadFrame = 2,
		EN_HeadIcon = 3,
		EN_Gender = 4,
		EN_Name = 5,
		EN_From = 6,
		EN_RankCon = 7,
		EN_MatchInfo = 8,
		EN_MentorIcon = 9,
	}
};