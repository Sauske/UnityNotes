namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_AddFriend
	{
		EN_TitleText = 0,
		EN_Placeholder = 1,
		EN_SearchTipsTitle = 2,
		EN_InfoText = 3,
	}
};