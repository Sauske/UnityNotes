namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_MentorRequestList
	{
		EN_RequestList = 0,
		EN_msgEnable = 1,
	}
};