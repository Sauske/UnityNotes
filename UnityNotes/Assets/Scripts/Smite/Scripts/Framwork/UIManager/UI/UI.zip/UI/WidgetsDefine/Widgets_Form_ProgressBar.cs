namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_ProgressBar
	{
		EN_Image = 0,
		EN_Text = 1,
		EN_Timer = 2,
		EN_TipsText = 3,
	}
};