namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_Friend
	{
		EN_List = 0,
		EN_FriendList = 1,
		EN_info_node = 2,
		EN_ChatList = 3,
		EN_DynamicList = 4,
	}
};