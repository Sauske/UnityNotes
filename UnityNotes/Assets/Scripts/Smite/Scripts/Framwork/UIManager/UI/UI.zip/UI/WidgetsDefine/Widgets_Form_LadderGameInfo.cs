namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_LadderGameInfo
	{
		EN_RecentPanel = 0,
		EN_SeasonPanel = 1,
		EN_SeasonTimePanel = 2,
		EN_imageIcon = 3,
		EN_Bp = 4,
		EN_Friend = 5,
		EN_FiveFriend = 6,
		EN_txtRecentResult = 7,
		EN_txtRecentTime = 8,
		EN_txtWinNum = 9,
		EN_txtGameNum = 10,
		EN_txtContinuousWin = 11,
		EN_txtSeasonTime = 12,
		EN_txtSeasonNoRecord = 13,
		EN_txtRecentNoRecord = 14,
		EN_txtSeasonTimeLabel = 15,
	}
};