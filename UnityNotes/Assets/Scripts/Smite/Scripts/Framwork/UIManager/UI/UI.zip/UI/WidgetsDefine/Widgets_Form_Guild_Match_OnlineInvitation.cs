namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_Guild_Match_OnlineInvitation
	{
		EN_txtContent = 0,
		EN_btnRefuse = 1,
		EN_btnAccept = 2,
	}
};