namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_Search
	{
		EN_SearchResult = 0,
		EN_SearchRecommend = 1,
		EN_TitleText = 2,
	}
};