namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_Guild_Match_Invitation
	{
		EN_txtContent = 0,
		EN_btnGroup = 1,
		EN_txtState = 2,
		EN_imgState = 3,
	}
};