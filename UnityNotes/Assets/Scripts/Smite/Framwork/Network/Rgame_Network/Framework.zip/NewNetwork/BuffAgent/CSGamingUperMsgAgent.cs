﻿using proto.pvp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGame
{
    public class CSGamingUperMsgAgent : PBAgent
    {
        private static int MAX_COUNT = 3;
        private CSGamingUperMsg mMsg;

        private CSGamingUperInfo[] mCSGamingUperInfo;
        private CSGamingUperDT[] mCSGamingUperDT;
        private CSGamingCCSyncInfo[] mCSGamingCCSyncInfo;
        private CSGamingCSSyncInfo[] mCSGamingCSSyncInfo;
  
        private CSGamingCSSyncUN[] mCSGamingCSSyncUN;
        private CSSyncCmdBaseAttack[] mCSSyncCmdBaseAttack;
        private CSSyncCmdUseDirectionalSkill[] mCSSyncCmdUseDirectionalSkill;
        private CSSyncCmdMove[] mCSSyncCmdMove;
        private CSSyncCmdUseObjectIveSkill[] mCSSyncCmdUseObjectIveSkill;
        private CSSyncCmdUsePositionSkill[] mCSSyncCmdUsePositionSkill;

        public CSGamingUperMsgAgent()
        {
            bChkReset = false;

            mCSGamingUperInfo = new CSGamingUperInfo[MAX_COUNT];
            mCSGamingUperDT = new CSGamingUperDT[MAX_COUNT];
            mCSGamingCCSyncInfo = new CSGamingCCSyncInfo[MAX_COUNT];
            mCSGamingCSSyncInfo = new CSGamingCSSyncInfo[MAX_COUNT];
  
            mCSGamingCSSyncUN = new CSGamingCSSyncUN[MAX_COUNT];
            mCSSyncCmdBaseAttack = new CSSyncCmdBaseAttack[MAX_COUNT];
            mCSSyncCmdUseDirectionalSkill = new CSSyncCmdUseDirectionalSkill[MAX_COUNT];
            mCSSyncCmdMove = new CSSyncCmdMove[MAX_COUNT];
            mCSSyncCmdUseObjectIveSkill = new CSSyncCmdUseObjectIveSkill[MAX_COUNT];
            mCSSyncCmdUsePositionSkill = new CSSyncCmdUsePositionSkill[MAX_COUNT];

            for (int i = 0; i < MAX_COUNT; i++)
            {
                mCSGamingUperInfo[i] = new CSGamingUperInfo();
                mCSGamingUperDT[i] = new CSGamingUperDT();
                mCSGamingCCSyncInfo[i] = new CSGamingCCSyncInfo(); 
                mCSGamingCSSyncInfo[i] = new CSGamingCSSyncInfo();

                mCSGamingCSSyncUN[i] = new CSGamingCSSyncUN();
                mCSSyncCmdBaseAttack[i] = new CSSyncCmdBaseAttack();
                mCSSyncCmdUseDirectionalSkill[i] = new CSSyncCmdUseDirectionalSkill();
                mCSSyncCmdMove[i] = new CSSyncCmdMove();
                mCSSyncCmdUseObjectIveSkill[i] = new CSSyncCmdUseObjectIveSkill();
                mCSSyncCmdUsePositionSkill[i] = new CSSyncCmdUsePositionSkill();
                mCSSyncCmdUsePositionSkill[i].stPosition = new Vector2();
            }

            mMsg = new CSGamingUperMsg();

            OnUse();
        }

        //对象从池中被启用
        public override void OnUse()
        {
            base.OnUse();

            mMsg.bNum = 0;
            mMsg.astUperInfo.Clear();

            for (int i = 0; i < MAX_COUNT; i++) 
            {
                mCSGamingUperInfo[i].bType = -1;
                mCSGamingUperInfo[i].dwCmdSeq = 0;
                mCSGamingUperInfo[i].stUperDt = mCSGamingUperDT[i];

                mCSGamingUperDT[i].chReserve = 0;
                mCSGamingUperDT[i].stCCInfo = null;
                mCSGamingUperDT[i].stCSInfo = null;

                mCSGamingCCSyncInfo[i].wLen = 0;
                mCSGamingCCSyncInfo[i].szBuff = null;

                mCSGamingCSSyncInfo[i].bSyncType = 0;
                mCSGamingCSSyncInfo[i].stCSSyncDt = mCSGamingCSSyncUN[i];
                mCSGamingCSSyncUN[i].bReserve = 0;
                mCSGamingCSSyncUN[i].stBaseAttack = null;
                mCSGamingCSSyncUN[i].stDirectionSkill = null;
                mCSGamingCSSyncUN[i].stMove = null;
                mCSGamingCSSyncUN[i].stObjectiveSkill = null;
                mCSGamingCSSyncUN[i].stPositionSkill = null;

                mCSSyncCmdBaseAttack[i].bStart = 0;
                mCSSyncCmdBaseAttack[i].dwObjectID = 0;

                mCSSyncCmdUseDirectionalSkill[i].chSlotType = 0;
                mCSSyncCmdUseDirectionalSkill[i].dwObjectID = 0;
                mCSSyncCmdUseDirectionalSkill[i].nDegree = 0;

                mCSSyncCmdMove[i].bSeq = 0;
                mCSSyncCmdMove[i].nDegree = 0;

                mCSSyncCmdUseObjectIveSkill[i].chSlotType = 0;
                mCSSyncCmdUseObjectIveSkill[i].iObjectID = 0;

                mCSSyncCmdUsePositionSkill[i].chSlotType = 0;
                mCSSyncCmdUsePositionSkill[i].stPosition.X = 0;
                mCSSyncCmdUsePositionSkill[i].stPosition.Z = 0;
            }






            //mMsg.bNum = 3;
            //CSGamingUperInfo info = null;
            //for (int i = 0; i < mMsg.bNum; i++)
            //{
            //    info = mMsg.astUperInfo[i];
            //    info.bType = 0;
            //    info.dwCmdSeq = 0;
            //    info.stUperDt.chReserve = 0;
            //    info.stUperDt.stCCInfo.wLen = -1;
            //    info.stUperDt.stCCInfo.szBuff = null;

            //    // CS 
            //    info.stUperDt.stCSInfo.bSyncType = -1;
            //    info.stUperDt.stCSInfo.stCSSyncDt.bReserve = 0;

            //    info.stUperDt.stCSInfo.stCSSyncDt.stBaseAttack.bStart = -1;
            //    info.stUperDt.stCSInfo.stCSSyncDt.stBaseAttack.dwObjectID = 0;

            //    info.stUperDt.stCSInfo.stCSSyncDt.stDirectionSkill.chSlotType = -1;
            //    info.stUperDt.stCSInfo.stCSSyncDt.stDirectionSkill.dwObjectID = 0;
            //    info.stUperDt.stCSInfo.stCSSyncDt.stDirectionSkill.nDegree = 0;

            //    info.stUperDt.stCSInfo.stCSSyncDt.stMove.bSeq = -1;
            //    info.stUperDt.stCSInfo.stCSSyncDt.stMove.nDegree = 0;

            //    info.stUperDt.stCSInfo.stCSSyncDt.stObjectiveSkill.chSlotType = -1;
            //    info.stUperDt.stCSInfo.stCSSyncDt.stObjectiveSkill.iObjectID = 0;

            //    info.stUperDt.stCSInfo.stCSSyncDt.stPositionSkill.chSlotType = -1;
            //    info.stUperDt.stCSInfo.stCSSyncDt.stPositionSkill.stPosition.X = 0;
            //    info.stUperDt.stCSInfo.stCSSyncDt.stPositionSkill.stPosition.Z = 0;
            //}
        }

        //对象还回池中善后
        public override void OnRelease()
        {
            base.OnRelease();
        }

        public override ProtoBuf.IExtensible GetMsg() 
        {
            return mMsg; 
        }

        public CSGamingUperInfo[] CSGamingUperInfo
        {
            get
            {
                return mCSGamingUperInfo;
            }
        }

        public CSGamingCCSyncInfo[] CSGamingCCSyncInfo
        {
            get
            {
                return mCSGamingCCSyncInfo;
            }
        }

        public CSGamingCSSyncInfo[] CSGamingCSSyncInfo
        {
            get
            {
                return mCSGamingCSSyncInfo;
            }
        }

        public CSSyncCmdBaseAttack[] CSSyncCmdBaseAttack
        {
            get
            {
                return mCSSyncCmdBaseAttack;
            }
        }

        public CSSyncCmdUseDirectionalSkill[] CSSyncCmdUseDirectionalSkill
        {
            get
            {
                return mCSSyncCmdUseDirectionalSkill;
            }
        }

        public CSSyncCmdMove[] CSSyncCmdMove
        {
            get
            {
                return mCSSyncCmdMove;
            }
        }

        public CSSyncCmdUseObjectIveSkill[] CSSyncCmdUseObjectIveSkill
        {
            get
            {
                return mCSSyncCmdUseObjectIveSkill;
            }
        }

        public CSSyncCmdUsePositionSkill[] CSSyncCmdUsePositionSkill
        {
            get
            {
                return mCSSyncCmdUsePositionSkill;
            }
        }
    }
}
