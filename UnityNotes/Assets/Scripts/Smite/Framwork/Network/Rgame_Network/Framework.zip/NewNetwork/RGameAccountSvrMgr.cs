﻿using Assets.Scripts.UI;

namespace RGame
{
    public class RGameAccountSvrMgr : Singleton<RGameAccountSvrMgr>
    {
        //给到外部调用系统最后一次错误码，方便外部系统处理
        public delegate void ConnectFailHandler();
        public event ConnectFailHandler connectFailHandler;

        public delegate void ConnectSuccessHandler();
        public event ConnectSuccessHandler connectSuccessHandler;

        private string mIp = "192.168.30.28";
        private ushort mPort = 30003;
        private bool mConnected = false;

        private bool canReconnect = true;
        private bool mConnecting = false;
        public bool Connected
        {
            get { return mConnected; }
        }

        public bool Connecting
        {
            get { return mConnecting; }
        }

        public void ConnectAccountServer()
        {
            if (mConnecting) return;

            if (!RGameNetworkModule.GetInstance().isOnlineMode) return;

            mConnected = false;
            mConnecting = true;

            RGameConnectorParam param = new RGameConnectorParam();
            param.bUDP = false;
            param.ip = mIp;
            param.port = mPort;

            RGameNetworkModule.GetInstance().lobbySrv.ConnectedEvent -= OnConnected;
            RGameNetworkModule.GetInstance().lobbySrv.DisconnectEvent -= OnDisconnected;
            RGameNetworkModule.GetInstance().lobbySrv.GetTryReconnect -= OnTryReconnect;
            RGameNetworkModule.GetInstance().lobbySrv.ConnectedEvent += OnConnected;
            RGameNetworkModule.GetInstance().lobbySrv.DisconnectEvent += OnDisconnected;
            RGameNetworkModule.GetInstance().lobbySrv.GetTryReconnect += OnTryReconnect;

            DebugHelper.ConsoleLog("Begin connect game server ip=" + mIp + " port= " + mPort);

            bool Result = RGameNetworkModule.GetInstance().InitLobbyServerConnect(param);

            DebugHelper.ConsoleLog("connect game server result:" + Result);
            if (Result)
            {
                CUIManager.GetInstance().OpenSendMsgAlert(null, 10);//转菊花
            }
        }

        public void DisconnectAccountServer()
        {
            RGameNetworkModule.GetInstance().CloseLobbyServerConnect();
        }

        public void AccountLogin(proto.AccountCheckReq account)
        {
            RGameLobbyMsgHandler.SendMsg(proto.ProtoID.CSID_ACCOUNT_CHECK, account);
        }

        public void AccountRegister(proto.AccountRegisterReq register_account)
        {
            RGameLobbyMsgHandler.SendMsg(proto.ProtoID.CSID_ACCOUNT_REGISTER, register_account);
        }

        /// <summary>
        /// 连接服务器成功
        /// </summary>
        /// <param name="sender"></param>
        private void OnConnected(object sender)
        {
            mConnecting = false;
            mConnected = true;
            CUIManager.GetInstance().CloseSendMsgAlert();
            if (connectSuccessHandler != null)
                connectSuccessHandler();
        }

        private void OnDisconnected(object sender)
        {
            mConnecting = false;
            mConnected = false;
            DebugHelper.Log("AccountServer Disconnected");
        }

        private uint OnTryReconnect(uint curConnectTime, uint maxcount)
        {
            DebugHelper.Log(string.Format("curConnectTime:{0},maxCount:{1}", curConnectTime, maxcount));

            if (canReconnect)
            {
                if (curConnectTime > maxcount)
                {
                    if (curConnectTime == maxcount + 1)
                        ConnectFailed();
                }
                else
                {
                    CUIManager.GetInstance().OpenSendMsgAlert(null, 10);//转菊花
                }
            }
            return curConnectTime;//根据最新的防止重新连接，需要重连就直接返回curConnectTime
        }

        private void ConnectFailed()
        {
            mConnecting = false;
            mConnected = false;
            PopConfirmingReconnecting();
            if (connectFailHandler != null)
            {
                connectFailHandler();
            }
        }

        private void PopConfirmingReconnecting()
        {
            CUIFormScript msgBoxForm = CUIManager.GetInstance().GetForm(CUIUtility.s_Form_Common_Dir + "Form_MessageBox.prefab");
            if (msgBoxForm == null)
            {
                CUIManager.GetInstance().OpenMessageBoxWithCancel("重连服务器失败，请检测手机网络环境。"
                    , enUIEventID.Net_ReconnectConfirm
                    , enUIEventID.Net_ReconnectCancel);
                CUIEventManager.GetInstance().AddUIEventListener(enUIEventID.Net_ReconnectConfirm, OnConfirmReconnecting);
                CUIEventManager.GetInstance().AddUIEventListener(enUIEventID.Net_ReconnectCancel, OnCancelReconnecting);
            }
        }

        private void OnConfirmReconnecting(CUIEvent uiEvent)
        {
            CUIEventManager.GetInstance().RemoveUIEventListener(enUIEventID.Net_ReconnectConfirm, OnConfirmReconnecting);
            CUIEventManager.GetInstance().RemoveUIEventListener(enUIEventID.Net_ReconnectCancel, OnCancelReconnecting);

            ConnectAccountServer();
        }

        private void OnCancelReconnecting(CUIEvent uiEvent)
        {
            CUIEventManager.GetInstance().RemoveUIEventListener(enUIEventID.Net_ReconnectConfirm, OnConfirmReconnecting);
            CUIEventManager.GetInstance().RemoveUIEventListener(enUIEventID.Net_ReconnectCancel, OnCancelReconnecting);
        }
    }
}
