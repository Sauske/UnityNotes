﻿using System;
using proto;
using ProtoBuf;
using System.IO;
using Assets.Scripts.UI;
using Assets.Scripts.GameSystem;
using CSProtocol;

namespace RGame
{
    [RGameMessageHandlerClassAttribute]
    public class RGameLobbyMsgHandler
    {
        public static void SendMsg(ProtoID cmdId,IExtensible msg)
        {
            NetPkg pkg = NetPkg.CreateNetReqPkg((int)cmdId, msg);
            RGameNetworkModule.GetInstance().SendLobbyMsg(ref pkg);
        }

        [RGameMessageHandlerAttribute(ProtoID.SCID_ACCOUNT_REGISTER)]
        public static void OnAccountRegister(NetPkg msg)
        {
            AccountRegisterRet ret = RGameUtil.Deserialize<AccountRegisterRet>(msg);
            EventRouter.GetInstance().BroadCastEvent<uint>(EventID.Account_Register_Response,ret.result);
        }

        [RGameMessageHandler(ProtoID.SCID_ACCOUNT_CHECK)]
        public static void OnAccountLogin(NetPkg msg)
        {
            AccountCheckRet ret = RGameUtil.Deserialize<AccountCheckRet>(msg);
            EventRouter.GetInstance().BroadCastEvent<uint>(EventID.Account_Login_Response, ret.result);
        }

        [RGameMessageHandlerAttribute(ProtoID.ProtoID_LoginRet)]
        public static void OnGameLoginResponse(NetPkg msg)
        {
            AccountLoginRes res = RGameUtil.Deserialize<AccountLoginRes>(msg);

            //登录成功
            if (res.succeed == 1)
            {
                RPlayerSys.GetInstance().InitPlayer(res.userid,(int)res.logicworldid,res.accountid);

                RPlayerSys.SetServerTime((int)res.severtime);
            }

            EventRouter.GetInstance().BroadCastEvent<uint>(EventID.Login_Game_Response, res.succeed);
        }

        [RGameMessageHandlerAttribute(ProtoID.ProtoID_FreshUserInfo)]
        public static void OnFreshUserInfoResponse(NetPkg msg)
        {
            freshUserInfoRet res = RGameUtil.Deserialize<freshUserInfoRet>(msg);
            RGame.RPlayerSys.instance.RefreshPlayer(res);
        }

        [RGameMessageHandler(ProtoID.SCID_ACCOUNT_Unreg)]
        public static void OnAccountUnregister(NetPkg pkg)
        {
            SCAccountUnreg msg = RGameUtil.Deserialize<SCAccountUnreg>(pkg);
            EventRouter.GetInstance().BroadCastEvent<uint>(EventID.Account_Unregister, (uint)msg.type);
        }

        [RGameMessageHandlerAttribute(ProtoID.CSID_GAMESVRPING)]
        public static void OnPingResponse(NetPkg msg)
        {
            LobbySrvPing ping = RGameUtil.Deserialize<LobbySrvPing>(msg);

            UInt32 delay = (UInt32)(UnityEngine.Time.realtimeSinceStartup * 1000f) - ping.dwTime;

            //UInt32 lobbyping = RGame.RGameNetworkModule.GetInstance().lobbyPing;
            //lobbyping = (delay + lobbyping) / 2;

            RGame.RGameNetworkModule.GetInstance().lobbyPing = delay;

            //DebugHelper.LogWarning("lobby ping: "+ lobbyping);

        }

        [RGameMessageHandlerAttribute(ProtoID.CSID_LobbyReconnect)]
        public static void OnReconnectResponse(NetPkg msg)
        {
            DebugHelper.Log("Reconnect Response");
        }

        #region  多人游戏
        /// <summary>
        /// SCID_MULTGAMEREADYNTF = 1078  服务器下发帧同步服务器地址
        /// </summary>
        [RGameMessageHandlerAttribute(ProtoID.SCID_MULTGAMEREADYNTF)]
        public static void OnMatchFightServerInfoRet(NetPkg msg)
        {
            MatchFightServerInfoRet ret = RGameUtil.Deserialize<MatchFightServerInfoRet>(msg);
            if (null == ret)
            {
                return;
            }

            //是否开启裁决位
            if (ret.bCamp == (uint)COM_PLAYERCAMP.COM_PLAYERCAMP_MID)
            {
                WatchController.GetInstance().StartJudgeEx();
            }

            //链接成功后服务器需要这些数据
            MatchDataMgr.GetInstance().MatchId = ret.matchid;
            MatchDataMgr.GetInstance().Masterid = ret.masterid;
            MatchDataMgr.GetInstance().Relationid = ret.relationid;
            if (ret.usernameSpecified)
            {
                MatchDataMgr.GetInstance().Username = System.Text.Encoding.UTF8.GetString(ret.username);
            }
            else
            {
                MatchDataMgr.GetInstance().Username = "";
            }

            RGameConnectorParam param = new RGameConnectorParam();
            if (ret.bIsUDP == 1)
            {
                param.bUDP = true;
            }
            else
            {
                param.bUDP = false;
            }
            param.ip = ret.fightip;
            param.port = (ushort)ret.fightport;
            RGameNetworkModule.GetInstance().gameSrv.ConnectEvent = RGameLobbyMsgHandler.OnGameConnectEvent;
            RGameNetworkModule.GetInstance().InitGameServerConnect(param);

            RSelectHeroSys.GetInstance().GotoSelectHero();
        }

        private static void OnGameConnectEvent(enDealConnectStatus status)
        {
            if (status == enDealConnectStatus.Deal_Connect_Success)
            {
                DebugHelper.Log("--------------------------------------send : CSID_MULTGAME_FIGHTUSER,链接成功后发送");
                RLobbyMsgHandler.SendMultGameFightUser();
            }
        }

        #endregion
        #region  多人游戏重连 jasonbao
        /// <summary>
        /// 向大厅服务器询问是否在战斗服务器
        /// </summary>
        [RGameMessageHandlerAttribute(ProtoID.SCID_ASKINMULTGAME_RSP)]
        public static void OnAskInMultGame(NetPkg msg)
        {
            SCAskInMultGameRsp ret = RGameUtil.Deserialize<SCAskInMultGameRsp>(msg);
            if (null == ret)
            {
                return;
            }

            CSProtocol.CSPkg msgPkg = Assets.Scripts.Framework.NetworkModule.CreateDefaultCSPKG(CSProtocol.CSProtocolMacros.SCID_ASKINMULTGAME_RSP);
            if (ret.bYes)
                msgPkg.stPkgData.stAskInMultGameRsp.bYes = 1;
            else
                msgPkg.stPkgData.stAskInMultGameRsp.bYes = 0;

            RGameReconnection.onQueryIsRelayGaming(msgPkg);
        }
        /// <summary>
        /// 通知client重连relay恢复多人游戏
        /// onMultiGameReady
        /// </summary>
        /// <param name="msg"></param>
        [RGameMessageHandlerAttribute(ProtoID.SCID_MULTGAMERECOVERNTF)]
        public static void OnMultiGameRecover(NetPkg msg)
        {
            
            if (RGameNetworkModule.GetInstance().gameSrv.Connected ||
                Assets.Scripts.GameLogic.LobbyLogic.instance.inMultiGame)
            {
                // 在游戏中，自己知道重连
                DebugHelper.Log("--------------------------------------rev : SCID_MULTGAMERECOVERNTF, 在游戏中，自己知道重连");
            }
            else
            {
                SCMultGameRecoverNtf ret = RGameUtil.Deserialize<SCMultGameRecoverNtf>(msg);

                if (ret.bCamp == (byte)COM_PLAYERCAMP.COM_PLAYERCAMP_MID)//裁判位
                {
                    DebugHelper.Log("--------------------------------------rev : SCID_MULTGAMERECOVERNTF, 裁判位");
                    //WatchController.GetInstance().StartJudge(msg.stPkgData.stMultGameRecoverNtf.stRelayTGW);
                    WatchController.GetInstance().StartJudgeEx();
                }
                //else
                {
                    DebugHelper.Log("--------------------------------------rev : SCID_MULTGAMERECOVERNTF, InitGameServerConnect()");
                    MatchDataMgr.instance.MatchId = ret.wMatchId;//匹配id
                    //原来用InitRelayConnnecting
                    RGameConnectorParam param = new RGameConnectorParam();
                    param.bUDP = ret.bIsUDP;
                    param.ip = ret.stIP;
                    param.port = (ushort)ret.wVPort;
                    RGameNetworkModule.GetInstance().gameSrv.ConnectEvent = RGameLobbyMsgHandler.OnGameConnectEvent;
                    RGameNetworkModule.GetInstance().InitGameServerConnect(param);
                }
            }
        }
        #endregion
    }
}
