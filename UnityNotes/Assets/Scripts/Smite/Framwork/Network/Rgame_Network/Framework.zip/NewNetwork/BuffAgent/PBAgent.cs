﻿using Assets.Scripts.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGame
{
    public class PBAgent : PooledClassObject
    {
        public virtual ProtoBuf.IExtensible GetMsg() { return null; }
    }
}
