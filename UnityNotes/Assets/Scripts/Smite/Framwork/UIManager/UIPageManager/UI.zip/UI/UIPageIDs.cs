﻿namespace RGame
{
    public partial class UIPageIDs
    {
        public const int PAGE_ID_LOGIN = 1;
        public const int PAGE_ID_MATCH = 2;
        public const int PAGE_ID_FRIEND = 3;
        public const int PAGE_ID_BAG = 5;
        public const int PAGE_ID_MAIL = 6;
        public const int PAGE_ID_PLAYER_INFO = 7;
        public const int PAGE_ID_PLAYERINFO_CHANGENAME = 8;
        public const int PAGE_ID_PLAYERINFO_CHANGEHEAD = 9;
        public const int PAGE_ID_PLAYERINFO_CHANGECOUNTRY = 10;
        public const int PAGE_ID_PLAYERINFO_COMMONHERO = 11;
        public const int PAGE_ID_PLAYERINFO_HONOR = 12;
        public const int PAGE_ID_HEROLIST = 13;
        public const int PAGE_ID_HERODETAIL = 14;
        public const int PAGE_ID_SHOW_REWARD = 15;
        public const int PAGE_ID_RANK = 16;
        public const int PAGE_ID_PLAYERINFO_CHANGEAUDIO = 17;
        public const int PAGE_ID_PLAYERINFO_COMMONPHOTO = 18;
        public const int PAGE_ID_PLAYERINFO_CREDITSCORE = 19;

        public const int PAGE_ID_SINGLE_MATCH = 20;
        public const int PAGE_ID_MULTI_MATCH = 21;
        public const int PAGE_ID_MATCH_CONFIRM = 22;
        public const int PAGE_ID_MATCH_BEINVITED = 23;

        public const int PAGE_ID_PVPPLAYERPROFIT = 30;
        public const int PAGE_ID_PVPMULTISETTLEMENT = 31;

        /// 商店界面 ////////
        public const int PAGE_ID_SHOP = 40;     //商店界面
        public const int PAGE_ID_BUYHERO = 41;  //购买英雄
        public const int PAGE_ID_BUYSKIN = 42;  //购买皮肤
        public const int PAGE_ID_BUYGIFT = 43;  //购买礼包
        public const int PAGE_ID_BUYPROP = 44;  //购买道具
        public const int PAGE_ID_BUYDIANQUAN = 45;  //购买点券

        ///聊天界面 ///
        public const int PAGE_ID_CHATROOM = 50;     //聊天室
        public const int PAGE_ID_CHAT = 51;         //聊天面板
        public const int PAGE_ID_CHATUSER = 52;     //聊天室玩家界面
        public const int PAGE_ID_SPEAKER = 53;      //喇叭界面
        
        //选择英雄界面
        public const int PAGE_ID_HEROSELECT_NORMAL = 70;        //常规选择英雄界面
        public const int PAGE_ID_HEROSELECT_BANPICK = 71;       //排位选择英雄界面

        // 直播界面
        public const int PAGE_ID_DB_LOBBY = 100;                       // 直播大厅界面
        public const int PAGE_ID_DB_DECORATE = 101;                    // 直播装扮界面
        public const int PAGE_ID_DB_ROOM = 102;                        // 直播房间界面
        public const int PAGE_ID_DB_DISCLAIMER = 103;                  // 免责申明界面
        public const int PAGE_ID_DB_DECORATEPREVIEW = 104;             // 装扮预览界面
        public const int PAGE_ID_DB_PLAYERINFO_CHANGEAUDIO = 105;      // 录音界面
        public const int PAGE_ID_DB_PLAYERINFO_GUESSAUDIENCE = 106;    // 竞猜观众界面
        public const int PAGE_ID_DB_PLAYERINFO_GUESSHOST = 107;        // 竞猜主播界面
        public const int PAGE_ID_DB_PLAYERINFO_GUESSINFO = 108;        // 竞猜信息界面
    }
}
