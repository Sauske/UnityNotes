namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_FriendForm
	{
		EN_Text = 0,
		EN_Buttons = 1,
		EN_node = 2,
		EN_mentorButtons = 3,
		EN_BtnIWant = 4,
		EN_mentorTips = 5,
		EN_Image = 6,
		EN_btnRule = 7,
		EN_ApprenticeIntroRequire = 8,
		EN_MentorIntroRequire = 9,
		EN_MentorSubTab = 10,
		EN_FriendList = 11,
		EN_pnlMoreMentor = 12,
		EN_ApprenticeIntroText = 13,
		EN_mentorIntroText = 14,
	}
};