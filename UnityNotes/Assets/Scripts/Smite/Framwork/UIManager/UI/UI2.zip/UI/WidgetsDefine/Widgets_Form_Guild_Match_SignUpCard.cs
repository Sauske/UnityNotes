namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_Guild_Match_SignUpCard
	{
		EN_txtTitle = 0,
		EN_txtNickName = 1,
		EN_txtRankGrade = 2,
		EN_listPosition1 = 3,
		EN_listPosition2 = 4,
		EN_txtMostUsedHero = 5,
		EN_inputMemo = 6,
		EN_txtSignUpTime = 7,
		EN_txtCurSelectPosition1 = 8,
		EN_txtCurSelectPosition2 = 9,
		EN_ButtonDown1 = 10,
		EN_ButtonDown2 = 11,
		EN_btnViewSignUpList = 12,
		EN_btnConfirm = 13,
		EN_txtRankStar = 14,
	}
};