﻿//==================================================================================
/// UI编辑菜单选项
/// @neoyang
/// @2015.03.03
//==================================================================================
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace UnityEditor.UI
{
    enum enUIListType
    {
        Horizontal,
    }

    enum CUIGraphType
    {
        Triangle,
        Line,
    }
    static internal class CUIMenuOptions
    {
        //从UGUI源码kiang的
        private const string kUILayerName = "UI";
        private const float kWidth = 160f;
        private const float kThickHeight = 30f;
        private const float kThinHeight = 20f;
        private const string kStandardSpritePath = "UI/Skin/UISprite.psd";
        private const string kBackgroundSpriteResourcePath = "UI/Skin/Background.psd";
        private const string kInputFieldBackgroundPath = "UI/Skin/InputFieldBackground.psd";
        private const string kKnobPath = "UI/Skin/Knob.psd";
        private const string kCheckmarkPath = "UI/Skin/Checkmark.psd";

        private static Vector2 s_ThickGUIElementSize = new Vector2(kWidth, kThickHeight);
        //private static Vector2 s_ThinGUIElementSize = new Vector2(kWidth, kThinHeight);
        private static Vector2 s_ImageGUIElementSize = new Vector2(256f, 256f);
        private static Color s_DefaultSelectableColor = new Color(1f, 1f, 1f, 1f);
        //private static Color s_PanelColor = new Color(1f, 1f, 1f, 0.392f);
        private static Color s_TextColor = new Color(50f / 255f, 50f / 255f, 50f / 255f, 1f);
        private static Vector2 s_joystickSize = new Vector2(450f, 450f);
        private static Vector2 s_joystickAxisSize = new Vector2(256f, 256f);

        //List 默认尺寸
        private const float c_listWidth = 640f;
        private const float c_listHeight = 480f;
        private const float c_listBorder = 20f;
        private const float c_listScrollBarSize = 40f;
        private const float c_listElementWidth = 200;
        private const float c_listElementHeight = 120;


        [MenuItem("GameObject/UI/Form", false, 1000)]
        static public void AddForm(MenuCommand menuCommand)
        {
            GameObject form = new GameObject("Form");
            form.layer = LayerMask.NameToLayer(kUILayerName);
            Canvas canvas = form.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceCamera;   //(CUIUtility.c_formRenderMode == enFormRenderMode.Camera) ? RenderMode.ScreenSpaceCamera : RenderMode.ScreenSpaceOverlay;
            canvas.pixelPerfect = true;

            CanvasScaler canvasScaler = form.AddComponent<CanvasScaler>();
            canvasScaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            canvasScaler.referenceResolution = new Vector2(CUIUtility.c_formBaseWidth, CUIUtility.c_formBaseHeight);
            canvasScaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            canvasScaler.matchWidthOrHeight = 1.0f;

            form.AddComponent<GraphicRaycaster>();
            form.AddComponent<CUIFormScript>();
            
            Undo.RegisterCreatedObjectUndo(form, "Create " + form.name);

            GameObjectUtility.SetParentAndAlign(form, menuCommand.context as GameObject);
            if (form.transform.parent as RectTransform)
            {
                RectTransform rect = form.transform as RectTransform;
                rect.anchorMin = Vector2.zero;
                rect.anchorMax = Vector2.one;
                rect.anchoredPosition = Vector2.zero;
                rect.sizeDelta = Vector2.zero;
            }

            Selection.activeGameObject = form;
        }

        [MenuItem("GameObject/UI/VerticalList", false, 1001)]
        static public void AddVerticalList(MenuCommand menuCommand)
        {
            CreateList(Selection.activeGameObject, enUIListType.Vertical, false);
        }

        [MenuItem("GameObject/UI/HorizontalList", false, 1002)]
        static public void AddHorizontalList(MenuCommand menuCommand)
        {
            CreateList(Selection.activeGameObject, enUIListType.Horizontal, false);
        }

        [MenuItem("GameObject/UI/VerticalGridList", false, 1003)]
        static public void AddVerticalGridList(MenuCommand menuCommand)
        {
            CreateList(Selection.activeGameObject, enUIListType.VerticalGrid, false);
        }

        [MenuItem("GameObject/UI/HorizontalGridList", false, 1004)]
        static public void AddHorizontalGridList(MenuCommand menuCommand)
        {
            CreateList(Selection.activeGameObject, enUIListType.HorizontalGrid, false);
        }

        [MenuItem("GameObject/UI/VerticalToggleList", false, 1005)]
        static public void AddVerticalToggleList(MenuCommand menuCommand)
        {
            CreateList(Selection.activeGameObject, enUIListType.Vertical, true);
        }

        [MenuItem("GameObject/UI/HorizontalToggleList", false, 1006)]
        static public void AddHorizontalToggleList(MenuCommand menuCommand)
        {
            CreateList(Selection.activeGameObject, enUIListType.Horizontal, true);
        }

        [MenuItem("GameObject/UI/GridToggleList", false, 1007)]
        static public void AddGridToggleList(MenuCommand menuCommand)
        {
            CreateList(Selection.activeGameObject, enUIListType.VerticalGrid, true);
        }

        [MenuItem("GameObject/UI/RawImage", false, 1008)]
        static public void AddRawImage(MenuCommand menuCommand)
        {
            CreateRawImage(Selection.activeGameObject);
        }

        [MenuItem("GameObject/UI/Container", false, 1009)]
        static public void AddContainer(MenuCommand menuCommand)
        {
            CreateContainer(Selection.activeGameObject);
        }

        [MenuItem("GameObject/UI/Timer", false, 1010)]
        static public void AddTimer(MenuCommand menuCommand)
        {
            CreateTimer(Selection.activeGameObject);
        }

        [MenuItem("GameObject/UI/Joystick", false, 1011)]
        static public void AddJoystick(MenuCommand menuCommand)
        {
            CreateJoystick(Selection.activeGameObject);
        }

        [MenuItem("GameObject/UI/StepList", false, 1012)]
        static public void AddStepList(MenuCommand menuCommand)
        {
            CreateStepList(Selection.activeGameObject);
        }

        [MenuItem("GameObject/UI/3DImage", false, 1013)]
        static public void Add3DImage(MenuCommand menuCommand)
        {
            Create3DImage(Selection.activeGameObject);
        }

        [MenuItem("GameObject/UI/HttpImage", false, 1014)]
        static public void AddHttpImage(MenuCommand menuCommand)
        {
            CreateHttpImage(Selection.activeGameObject);
        }

        [MenuItem("GameObject/UI/Particle", false, 1015)]
        static public void AddUIParticle(MenuCommand menuCommand)
        {
            CreateUIParticle(Selection.activeGameObject);
        }

        [MenuItem("GameObject/UI/ExpandList", false, 1016)]
        static public void AddExpandList(MenuCommand menuCommand)
        {
            CreateExpandList(Selection.activeGameObject);
        }

        [MenuItem("GameObject/UI/HttpText", false, 1017)]
        static public void AddHttpText(MenuCommand menuCommand)
        {
            CreateHttpText(Selection.activeGameObject);
        }
        [MenuItem("GameObject/UI/Polygon", false, 1018)]
        static public void AddPolygon(MenuCommand menuCommand)
        {
           CreatePolygon(Selection.activeGameObject);
        }

        [MenuItem("GameObject/UI/GraphLine", false, 1019)]
        static public void AddGraphLine(MenuCommand menuCommand)
        {
            CreateGraph(Selection.activeGameObject, CUIGraphType.Line);
        }
        [MenuItem("GameObject/UI/GraphTriangle", false, 1020)]
        static public void AddGraphTriangle(MenuCommand menuCommand)
        {
            CreateGraph(Selection.activeGameObject, CUIGraphType.Triangle);
        }


        //--------------------------------------------------
        /// 创建List
        /// @parent
        /// @listType
        /// @isToggleList
        //--------------------------------------------------
        private static void CreateList(GameObject parent, enUIListType listType, bool isToggleList)
        {
            if (parent == null || parent.GetComponent<RectTransform>() == null)
            {
                Debug.Log("List Must Create Under UI!!!");
                return;
            }

            //Create List Root
            GameObject listObject = CreateUIObject(isToggleList ? "ToggleList" : "List", parent, new Vector2(c_listWidth, c_listHeight));
            listObject.AddComponent<Image>();
            CUIListScript listScript = isToggleList ? listObject.AddComponent<CUIToggleListScript>() : listObject.AddComponent<CUIListScript>();

            listScript.m_listType = listType;
            listScript.m_elementAmount = 1;

            //Create ScrollRect
            Vector2 scrollRectSize = Vector2.zero;            
            if (listType == enUIListType.Vertical || listType == enUIListType.VerticalGrid)
            {
                scrollRectSize = new Vector2(c_listWidth - c_listBorder - c_listScrollBarSize, c_listHeight - c_listBorder * 2);
            }
            else
            {
                scrollRectSize = new Vector2(c_listWidth - c_listBorder * 2, c_listHeight - c_listBorder - c_listScrollBarSize);
            }

            GameObject scrollRectObject = CreateScrollRect(listObject, scrollRectSize, listType, isToggleList);

            //Add ScrollBar
            Vector2 scrollBarSize = Vector2.zero;

            if (listType == enUIListType.Vertical || listType == enUIListType.VerticalGrid)
            {
                scrollBarSize = new Vector2(c_listScrollBarSize, c_listHeight - c_listBorder * 2);
            }
            else
            {
                scrollBarSize = new Vector2(c_listWidth - c_listBorder * 2, c_listScrollBarSize);
            }

            GameObject scrollBarObject = CreateScrollbar(listObject, scrollBarSize, listType);

            ScrollRect scrollRect = scrollRectObject.GetComponent<ScrollRect>();
            if (listType == enUIListType.Vertical || listType == enUIListType.VerticalGrid)
            {
                scrollRect.horizontalScrollbar = null;
                scrollRect.verticalScrollbar = scrollBarObject.GetComponent<Scrollbar>();
            }
            else
            {
                scrollRect.horizontalScrollbar = scrollBarObject.GetComponent<Scrollbar>();
                scrollRect.verticalScrollbar = null;
            }

            Selection.activeGameObject = listObject;
        }

        //--------------------------------------------------
        /// 创建List
        /// @parent
        //--------------------------------------------------
        static public void CreateStepList(GameObject parent)
        {
            if (parent == null || parent.GetComponent<RectTransform>() == null)
            {
                Debug.Log("StepList Must Create Under UI!!!");
                return;
            }

            //Create List Root
            GameObject listObject = CreateUIObject("StepList", parent, new Vector2(c_listWidth, c_listHeight));
            listObject.AddComponent<Image>();
            CUIListScript listScript = listObject.AddComponent<CUIStepListScript>();
            listScript.m_listType = enUIListType.Horizontal;
            listScript.m_elementAmount = 1;

            //Create ScrollRect
            Vector2 scrollRectSize = Vector2.zero;
            scrollRectSize = new Vector2(c_listWidth - c_listBorder * 2, c_listHeight - c_listBorder * 2);

            /*GameObject scrollRectObject = */CreateScrollRect(listObject, scrollRectSize, enUIListType.Horizontal, false);
            // ScrollRect scrollRect = scrollRectObject.GetComponent<ScrollRect>();

            Selection.activeGameObject = listObject;
        }

        static public GameObject CreateScrollRect(GameObject parent, Vector2 size, enUIListType listType, bool isToggleList)
        {
            GameObject scrollRectObject = CreateUIObject("ScrollRect", parent, size);
            RectTransform rectTransform = scrollRectObject.transform as RectTransform;

            //修改锚点和枢轴点
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMin = new Vector2(0, 0);
            rectTransform.anchorMax = new Vector2(1, 1);

            if (listType == enUIListType.Vertical || listType == enUIListType.VerticalGrid)
            {
                rectTransform.offsetMin = new Vector2(c_listBorder, c_listBorder);
                rectTransform.offsetMax = new Vector2(-c_listScrollBarSize, -c_listBorder);
            }
            else
            {
                rectTransform.offsetMin = new Vector2(c_listBorder, c_listScrollBarSize);
                rectTransform.offsetMax = new Vector2(-c_listBorder, -c_listBorder);
            }

            ScrollRect scrollRectScript = scrollRectObject.AddComponent<ScrollRect>();

            if (listType == enUIListType.Vertical || listType == enUIListType.VerticalGrid)
            {
                scrollRectScript.horizontal = false;
                scrollRectScript.vertical = true;
            }
            else
            {
                scrollRectScript.horizontal = true;
                scrollRectScript.vertical = false;
            }

            //Add Mask and Image for ScrollRect
            scrollRectObject.AddComponent<Mask>().showMaskGraphic = false;
            scrollRectObject.AddComponent<Image>();

            //Add BackGround for ScrollRect
            GameObject backgroundObject = CreateUIObject("Background", scrollRectObject, size);
            rectTransform = backgroundObject.transform as RectTransform;

            //修改锚点和枢轴点
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMin = new Vector2(0, 0);
            rectTransform.anchorMax = new Vector2(1, 1);
            rectTransform.offsetMin = new Vector2(0, 0);
            rectTransform.offsetMax = new Vector2(0, 0);

            //Add Image for ScrollRect Background
            backgroundObject.AddComponent<Image>().color = new Color(1, 0, 0, 1);

            //Add Content for ScrollRect
            GameObject contentObject = CreateUIObject("Content", scrollRectObject, size);
            rectTransform = contentObject.transform as RectTransform;

            //修改锚点和枢轴点
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMin = new Vector2(0, 0);
            rectTransform.anchorMax = new Vector2(1, 1);
            rectTransform.offsetMin = new Vector2(0, 0);
            rectTransform.offsetMax = new Vector2(0, 0);

            //Add ListElement
            if (isToggleList)
            {
                GameObject elementObject = CreateToggle(contentObject, new Vector2(c_listElementWidth, c_listElementHeight));
                elementObject.AddComponent<Image>().color = new Color(0, 0, 1, 1);
                elementObject.AddComponent<CUIToggleListElementScript>();
            }
            else
            {
                GameObject elementObject = CreateUIObject("ListElement", contentObject, new Vector2(c_listElementWidth, c_listElementHeight));
                elementObject.AddComponent<Image>().color = new Color(0, 0, 1, 1);
                elementObject.AddComponent<CUIListElementScript>();
            }

            scrollRectScript.content = contentObject.transform as RectTransform;

            return scrollRectObject;
        }

        static public GameObject CreateScrollbar(GameObject parent, Vector2 size, enUIListType listType)
        {
            // Create GOs Hierarchy
            GameObject scrollbarRoot = CreateUIObject("Scrollbar", parent, size);

            GameObject sliderArea = CreateUIObject("Sliding Area", scrollbarRoot);
            GameObject handle = CreateUIObject("Handle", sliderArea);

            Image bgImage = scrollbarRoot.AddComponent<Image>();
            bgImage.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>(kBackgroundSpriteResourcePath);
            bgImage.type = Image.Type.Sliced;
            bgImage.color = s_DefaultSelectableColor;

            Image handleImage = handle.AddComponent<Image>();
            handleImage.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>(kStandardSpritePath);
            handleImage.type = Image.Type.Sliced;
            handleImage.color = s_DefaultSelectableColor;

            RectTransform sliderAreaRect = sliderArea.GetComponent<RectTransform>();
            sliderAreaRect.sizeDelta = new Vector2(-20, -20);
            sliderAreaRect.anchorMin = Vector2.zero;
            sliderAreaRect.anchorMax = Vector2.one;

            RectTransform handleRect = handle.GetComponent<RectTransform>();
            handleRect.sizeDelta = new Vector2(20, 20);

            Scrollbar scrollbar = scrollbarRoot.AddComponent<Scrollbar>();
            scrollbar.handleRect = handleRect;
            scrollbar.targetGraphic = handleImage;

            if (listType == enUIListType.Vertical || listType == enUIListType.VerticalGrid)
            {
                scrollbar.direction = Scrollbar.Direction.BottomToTop;
            }
            else
            {
                scrollbar.direction = Scrollbar.Direction.LeftToRight;
            }

            SetDefaultColorTransitionValues(scrollbar);

            //修改锚点和枢轴点
            RectTransform rectTransform = scrollbarRoot.transform as RectTransform;

            if (listType == enUIListType.Vertical || listType == enUIListType.VerticalGrid)
            {
                rectTransform.pivot = new Vector2(1, 0.5f);
                rectTransform.anchorMin = new Vector2(1, 0);
                rectTransform.anchorMax = new Vector2(1, 1);
                rectTransform.offsetMin = new Vector2(-c_listScrollBarSize, c_listBorder);
                rectTransform.offsetMax = new Vector2(0, -c_listBorder);
            }
            else
            {
                rectTransform.pivot = new Vector2(0.5f, 0);
                rectTransform.anchorMin = new Vector2(0, 0);
                rectTransform.anchorMax = new Vector2(1, 0);
                rectTransform.offsetMin = new Vector2(c_listBorder, 0);
                rectTransform.offsetMax = new Vector2(-c_listBorder, c_listScrollBarSize);
            }

            return scrollbarRoot;
        }

        static public GameObject CreateToggle(GameObject parent, Vector2 size)
        {
            // Set up hierarchy
            GameObject toggleRoot = CreateUIObject("Toggle", parent, size);

            GameObject background = CreateUIObject("Background", toggleRoot);
            GameObject checkmark = CreateUIObject("Checkmark", background);
            GameObject childLabel = CreateUIObject("Label", toggleRoot);

            // Set up components
            Toggle toggle = toggleRoot.AddComponent<Toggle>();
            toggle.interactable = false;
            toggle.isOn = false;

            Image bgImage = background.AddComponent<Image>();
            bgImage.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>(kStandardSpritePath);
            bgImage.type = Image.Type.Sliced;
            bgImage.color = s_DefaultSelectableColor;

            Image checkmarkImage = checkmark.AddComponent<Image>();
            checkmarkImage.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>(kCheckmarkPath);

            UnityEngine.UI.Text label = childLabel.AddComponent<UnityEngine.UI.Text>();
            label.text = "Toggle";
            SetDefaultTextValues(label);

            toggle.graphic = checkmarkImage;
            toggle.targetGraphic = bgImage;
            SetDefaultColorTransitionValues(toggle);

            RectTransform bgRect = background.GetComponent<RectTransform>();
            bgRect.pivot = new Vector2(0.5f, 0.5f);
            bgRect.anchorMin = new Vector2(0f, 0f);
            bgRect.anchorMax = new Vector2(1f, 1f);
            bgRect.offsetMin = new Vector2(20f, (size.y - 40) / 2);
            bgRect.offsetMax = new Vector2(-(size.x - 20 - 40), -((size.y - 40) / 2));
            //bgRect.anchoredPosition = new Vector2(10f, -10f);
            //bgRect.sizeDelta = new Vector2(size.x - 40, size.y - 40);

            RectTransform checkmarkRect = checkmark.GetComponent<RectTransform>();
            checkmarkRect.pivot = new Vector2(0.5f, 0.5f);
            checkmarkRect.anchorMin = new Vector2(0, 0);
            checkmarkRect.anchorMax = new Vector2(1, 1);
            checkmarkRect.offsetMin = Vector2.zero;
            checkmarkRect.offsetMax = Vector2.zero;
            //checkmarkRect.anchoredPosition = Vector2.zero;
            //checkmarkRect.sizeDelta = new Vector2(size.x - 40, size.y - 40);

            RectTransform labelRect = childLabel.GetComponent<RectTransform>();
            labelRect.pivot = new Vector2(0.5f, 0.5f);
            labelRect.anchorMin = new Vector2(0f, 0f);
            labelRect.anchorMax = new Vector2(1f, 1f);
            labelRect.offsetMin = new Vector2(80f, 0f);
            labelRect.offsetMax = new Vector2(0f, 0f);

            return toggleRoot;
        }

        //--------------------------------------
        /// 创建RawImage
        //--------------------------------------
        private static void CreateRawImage(GameObject parent)
        {
            if (parent == null || parent.GetComponent<RectTransform>() == null)
            {
                Debug.Log("RawImage Must Create Under UI!!!");
                return;
            }

            GameObject go = CreateUIObject("RawImage", parent, s_ImageGUIElementSize);
            go.AddComponent<RawImage>();
            go.AddComponent<CUIRawImageScript>();

            //Create Camera
            GameObject cameraObject = new GameObject("RTCamera");
            Camera camera = cameraObject.AddComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(camera.backgroundColor.r, camera.backgroundColor.g, camera.backgroundColor.b, 0);
            camera.cullingMask = (1 << LayerMask.NameToLayer("UIRaw"));
            camera.fieldOfView = 45f;            
            GameObjectUtility.SetParentAndAlign(cameraObject, go);

            //Create Directional Light
            GameObject lightObject = new GameObject("Directional light");
            Light lightScript = lightObject.AddComponent<Light>();
            lightScript.type = LightType.Directional;
            lightScript.cullingMask = (1 << LayerMask.NameToLayer("UIRaw"));
            GameObjectUtility.SetParentAndAlign(lightObject, cameraObject);

            //Create RawRoot
            GameObject rawRootObject = new GameObject("RawRoot");
            GameObjectUtility.SetParentAndAlign(rawRootObject, cameraObject);
            rawRootObject.layer = LayerMask.NameToLayer("UIRaw");
            rawRootObject.transform.localPosition = new Vector3(0, 0, 6);

            Selection.activeGameObject = go;
        }

        //--------------------------------------
        /// 创建UIContainer
        //--------------------------------------
        private static void CreateContainer(GameObject parent)
        {
            if (parent == null || parent.GetComponent<RectTransform>() == null)
            {
                Debug.Log("Container Must Create Under UI!!!");
                return;
            }

            GameObject containerObject = CreateUIObject("Container", parent);

            RectTransform rectTransform = containerObject.transform as RectTransform;
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMin = Vector2.zero;
            rectTransform.anchorMax = Vector2.one;
            rectTransform.offsetMin = Vector2.zero;
            rectTransform.offsetMax = Vector2.zero;

            containerObject.AddComponent<CUIContainerScript>();

            Selection.activeGameObject = containerObject;
        }

        //--------------------------------------
        /// 创建UITimer
        //--------------------------------------
        private static void CreateTimer(GameObject parent)
        {
            if (parent == null || parent.GetComponent<RectTransform>() == null)
            {
                Debug.Log("Timer Must Create Under UI!!!");
                return;
            }

            GameObject timerObject = CreateUIObject("Timer", parent, s_ThickGUIElementSize);
            timerObject.AddComponent<Image>();
            timerObject.AddComponent<CUITimerScript>();

            //添加Text
            GameObject textObject = CreateUIObject("Text", timerObject);
            RectTransform rectTransform = textObject.transform as RectTransform;
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMin = Vector2.zero;
            rectTransform.anchorMax = Vector2.one;
            rectTransform.offsetMin = Vector2.zero;
            rectTransform.offsetMax = Vector2.zero;

            UnityEngine.UI.Text text = textObject.AddComponent<UnityEngine.UI.Text>();
            text.text = "00:00:00";
            text.fontSize = 24;
            text.alignment = TextAnchor.MiddleCenter;
            text.color = new Color(0, 0, 0, 1);

            Selection.activeGameObject = timerObject;
        }

        //--------------------------------------
        /// 创建UIJoystick
        //--------------------------------------
        private static void CreateJoystick(GameObject parent)
        {
            if (parent == null || parent.GetComponent<RectTransform>() == null)
            {
                Debug.Log("Joystick Must Create Under UI!!!");
                return;
            }

            GameObject joystickObject = CreateUIObject("Joystick", parent, s_joystickSize);
            RectTransform joystickRootRectTransform = joystickObject.transform as RectTransform;
            joystickRootRectTransform.pivot = Vector2.zero;
            joystickRootRectTransform.anchorMin = Vector2.zero;
            joystickRootRectTransform.anchorMax = Vector2.zero;
            joystickRootRectTransform.anchoredPosition = Vector2.zero;

            Image joystickImage = joystickObject.AddComponent<Image>();
            joystickImage.color = new Color(joystickImage.color.r, joystickImage.color.g, joystickImage.color.b, 0f);

            joystickObject.AddComponent<CUIJoystickScript>();

            //Create Axis
            GameObject axisObject = CreateUIObject("Axis", joystickObject, s_joystickAxisSize);
            RectTransform axisRectTransform = axisObject.transform as RectTransform;
            axisRectTransform.pivot = new Vector2(0.5f, 0.5f);
            axisRectTransform.anchorMin = new Vector2(0.5f, 0.5f);
            axisRectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            axisRectTransform.anchoredPosition = Vector2.zero;

            axisObject.AddComponent<Image>();

            CanvasGroup canvasGroup = axisObject.AddComponent<CanvasGroup>();
            canvasGroup.interactable = false;
            canvasGroup.blocksRaycasts = false;

            //Create Cursor
            GameObject cursorObject = CreateUIObject("Cursor", axisObject, s_joystickAxisSize);
            RectTransform cursorRectTransform = cursorObject.transform as RectTransform;
            cursorRectTransform.pivot = new Vector2(0.5f, 0.5f);
            cursorRectTransform.anchorMin = new Vector2(0.5f, 0.5f);
            cursorRectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            cursorRectTransform.anchoredPosition = Vector2.zero;

            cursorObject.AddComponent<Image>();

            canvasGroup = cursorObject.AddComponent<CanvasGroup>();
            canvasGroup.interactable = false;
            canvasGroup.blocksRaycasts = false;

            Selection.activeGameObject = joystickObject;
        }

        //--------------------------------------
        /// 创建3DImage
        //--------------------------------------
        private static void Create3DImage(GameObject parent)
        {
            if (parent == null || parent.GetComponent<RectTransform>() == null)
            {
                Debug.Log("3DImage Must Create Under UI!!!");
                return;
            }

            GameObject gameObject = CreateUIObject("3DImage", parent, s_ImageGUIElementSize);

            //Add Camera
            Camera camera = gameObject.AddComponent<Camera>();
            camera.clearFlags = CameraClearFlags.Depth;
            //camera.cullingMask = (1 << CUI3DImageScript.s_cameraLayers[(int)en3DImageLayer.Background]);
            camera.orthographic = true;

            //Add Directional Light
            Light lightScript = gameObject.AddComponent<Light>();
            lightScript.type = LightType.Directional;
            //lightScript.cullingMask = (1 << CUI3DImageScript.s_cameraLayers[(int)en3DImageLayer.Background]);

            //Add Image
            Image image = gameObject.AddComponent<Image>();
            image.color = new Color(1, 1, 1, 0);

            //Add 3DImage
            gameObject.AddComponent<CUI3DImageScript>();

            Selection.activeGameObject = gameObject;
        }

        //--------------------------------------
        /// 创建HttpImage控件
        //--------------------------------------
        private static void CreateHttpImage(GameObject parent)
        {
            if (parent == null || parent.GetComponent<RectTransform>() == null)
            {
                Debug.Log("HttpImage Must Create Under UI!!!");
                return;
            }

            GameObject gameObject = CreateUIObject("HttpImage", parent, s_ImageGUIElementSize);

            //Add Image
            Image image = gameObject.AddComponent<Image>();
            image.color = new Color(1, 1, 1, 1);

            //Add HttpImage
            gameObject.AddComponent<CUIHttpImageScript>();
        }

        //--------------------------------------
        /// 创建HttpText控件
        //--------------------------------------
        private static void CreateHttpText(GameObject parent)
        {
            if (parent == null || parent.GetComponent<RectTransform>() == null)
            {
                Debug.Log("HttpText Must Create Under UI!!!");
                return;
            }

            GameObject gameObject = CreateUIObject("HttpText", parent, s_ImageGUIElementSize);

            //Add Image
            Image image = gameObject.AddComponent<Image>();
            image.color = new Color(0, 0, 0, 1);

            //Add HttpText
            gameObject.AddComponent<CUIHttpTextScript>();

            //Add ScorllRect
            GameObject scrollRectObject = CreateUIObject("ScrollRect", gameObject, s_ImageGUIElementSize);
            RectTransform rectTransform = scrollRectObject.transform as RectTransform;

            //修改枢轴点和锚点
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMin = new Vector2(0, 0);
            rectTransform.anchorMax = new Vector2(1, 1);
            rectTransform.offsetMin = new Vector2(0, 0);
            rectTransform.offsetMax = new Vector2(0, 0);

            ScrollRect scrollRectScript = scrollRectObject.AddComponent<ScrollRect>();
            scrollRectScript.horizontal = false;
            scrollRectScript.vertical = true;

            //Add Mask and Image for ScrollRect
            scrollRectObject.AddComponent<Mask>().showMaskGraphic = false;
            scrollRectObject.AddComponent<Image>();

            //Add Text
            GameObject textObject = CreateUIObject("Text", scrollRectObject, s_ImageGUIElementSize);
            RectTransform textRectTransform = textObject.transform as RectTransform;

            //修改枢轴点和锚点
            textRectTransform.pivot = new Vector2(0.5f, 1f);
            textRectTransform.anchorMin = new Vector2(0, 1);
            textRectTransform.anchorMax = new Vector2(1, 1);
            textRectTransform.offsetMin = new Vector2(0, 0);
            textRectTransform.offsetMax = new Vector2(0, 0);

            Text textScript = textObject.AddComponent<Text>();
            textScript.fontSize = 20;
            textScript.horizontalOverflow = HorizontalWrapMode.Wrap;
            textScript.verticalOverflow = VerticalWrapMode.Overflow;

            ContentSizeFitter contentSizeFitter = textObject.AddComponent<ContentSizeFitter>();
            contentSizeFitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
            contentSizeFitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            scrollRectScript.content = textRectTransform;
        }

        //--------------------------------------
        /// 创建多边形组件
        //--------------------------------------
        private static void CreatePolygon(GameObject parent)
        {
            if (parent == null)
            {
                Debug.Log("CUIGraph parent be null!");
                return;
            }
            GameObject gameObject = CreateUIObject("Polygon", parent, s_ImageGUIElementSize);

            gameObject.AddComponent<CUIPolygon>();
        }
        //--------------------------------------
        /// 创建GL画线组件
        //--------------------------------------
        private static void CreateGraph(GameObject parent, CUIGraphType graphType)
        {
            if (parent == null)
            {
                Debug.Log("CUIGraph parent be null!");
                return;
            }
            GameObject gameObject = CreateUIObject("Graph", parent, s_ImageGUIElementSize);
            if (graphType == CUIGraphType.Line)
            {
                gameObject.AddComponent<CUIGraphLineScript>();
            }
            else if (graphType == CUIGraphType.Triangle)
            {
                gameObject.AddComponent<CUIGraphTriangleScript>();
            }
            CUIGraphBaseScript graph = gameObject.GetComponent<CUIGraphBaseScript>();
            Camera camera = gameObject.AddComponent<Camera>();
            camera.depth = CUIGraphBaseScript.s_depth;
            camera.clearFlags = CameraClearFlags.Depth;
            camera.cullingMask = 1 << CUIGraphBaseScript.s_cullingMask;
            camera.orthographic = true;
            gameObject.layer = CUIGraphBaseScript.s_cullingMask;
        }
        //--------------------------------------
        /// 创建UI粒子控件
        //--------------------------------------
        private static void CreateUIParticle(GameObject parent)
        {
            if (parent == null || parent.GetComponent<RectTransform>() == null)
            {
                Debug.Log("UIParticle Must Create Under UI!!!");
                return;
            }

            GameObject gameObject = CreateUIObject("Particle", parent, s_ImageGUIElementSize);

            //Add ParticleScript
            gameObject.AddComponent<CUIParticleScript>();
        }

        //--------------------------------------
        /// 创建扩展List
        //--------------------------------------
        private static void CreateExpandList(GameObject parent)
        {
            if (parent == null || parent.GetComponent<RectTransform>() == null)
            {
                Debug.Log("ExpandList Must Create Under UI!!!");
                return;
            }

            //Create List Root
            GameObject listObject = CreateUIObject("ExpandList", parent, new Vector2(c_listWidth, c_listHeight));
            listObject.AddComponent<Image>();
            CUIListScript listScript = listObject.AddComponent<CUIExpandListScript>();
            listScript.m_listType = enUIListType.Horizontal;
            listScript.m_elementAmount = 1;

            //Create ScrollRect
            Vector2 scrollRectSize = Vector2.zero;
            scrollRectSize = new Vector2(c_listWidth - c_listBorder * 2, c_listHeight - c_listBorder * 2);

            GameObject scrollRectObject = CreateUIObject("ScrollRect", listObject, scrollRectSize);
            RectTransform rectTransform = scrollRectObject.transform as RectTransform;

            //修改锚点和枢轴点
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMin = new Vector2(0, 0);
            rectTransform.anchorMax = new Vector2(1, 1);
            rectTransform.offsetMin = new Vector2(c_listBorder, c_listBorder);
            rectTransform.offsetMax = new Vector2(-c_listBorder, -c_listBorder);

            ScrollRect scrollRectScript = scrollRectObject.AddComponent<ScrollRect>();
            scrollRectScript.horizontal = true;
            scrollRectScript.vertical = false;

            //Add Mask and Image for ScrollRect
            scrollRectObject.AddComponent<Mask>().showMaskGraphic = false;
            scrollRectObject.AddComponent<Image>();

            //Add BackGround for ScrollRect
            GameObject backgroundObject = CreateUIObject("Background", scrollRectObject, scrollRectSize);
            rectTransform = backgroundObject.transform as RectTransform;

            //修改锚点和枢轴点
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMin = new Vector2(0, 0);
            rectTransform.anchorMax = new Vector2(1, 1);
            rectTransform.offsetMin = new Vector2(0, 0);
            rectTransform.offsetMax = new Vector2(0, 0);

            //Add Image for ScrollRect Background
            backgroundObject.AddComponent<Image>().color = new Color(1, 0, 0, 1);

            //Add Content for ScrollRect
            GameObject contentObject = CreateUIObject("Content", scrollRectObject, scrollRectSize);
            rectTransform = contentObject.transform as RectTransform;

            //修改锚点和枢轴点
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMin = new Vector2(0, 0);
            rectTransform.anchorMax = new Vector2(1, 1);
            rectTransform.offsetMin = new Vector2(0, 0);
            rectTransform.offsetMax = new Vector2(0, 0);

            //Add ListElement
            GameObject elementObject = CreateUIObject("ExpandListElement", contentObject, new Vector2(c_listElementWidth, c_listElementHeight));
            elementObject.AddComponent<Image>().color = new Color(1, 1, 1, 1);
            elementObject.AddComponent<Mask>().showMaskGraphic = false;
            elementObject.AddComponent<CUIExpandListElementScript>();

            scrollRectScript.content = contentObject.transform as RectTransform;

            Selection.activeGameObject = listObject;
        }

        //--------------------------------------
        /// 创建UIObject
        //--------------------------------------
        private static GameObject CreateUIObject(string name, GameObject parent)
        {
            GameObject go = new GameObject(name);
            go.AddComponent<RectTransform>();
            GameObjectUtility.SetParentAndAlign(go, parent);

            return go;
        }

        //-------------------------------------------------------
        /// 创建UIObject并设定其大小、锚点及枢轴点(默认为Top-Left)
        //-------------------------------------------------------
        private static GameObject CreateUIObject(string name, GameObject parent, Vector2 size)
        {
            GameObject go = CreateUIObject(name, parent);

            RectTransform rectTransform = go.transform as RectTransform;
            rectTransform.anchorMin = new Vector2(0, 1);
            rectTransform.anchorMax = new Vector2(0, 1);
            rectTransform.pivot = new Vector2(0, 1);
            rectTransform.anchoredPosition = new Vector2(0, 0);
            rectTransform.sizeDelta = size;
            rectTransform.localRotation = Quaternion.identity;
            rectTransform.localScale = new Vector3(1f, 1f, 1f);

            //if (parent != menuCommand.context) // not a context click, so center in sceneview
            //{
            //    SetPositionVisibleinSceneView(parent.GetComponent<RectTransform>(), rectTransform);
            //}           
            //Selection.activeGameObject = child;

            return go;
        }

        private static void SetDefaultColorTransitionValues(Selectable slider)
        {
            ColorBlock colors = slider.colors;
            colors.highlightedColor = new Color(0.882f, 0.882f, 0.882f);
            colors.pressedColor = new Color(0.698f, 0.698f, 0.698f);
            colors.disabledColor = new Color(0.521f, 0.521f, 0.521f);
        }

        private static void SetDefaultTextValues(UnityEngine.UI.Text lbl)
        {
            // Set text values we want across UI elements in default controls.
            // Don't set values which are the same as the default values for the Text component,
            // since there's no point in that, and it's good to keep them as consistent as possible.
            lbl.alignment = TextAnchor.MiddleLeft;
            lbl.fontSize = 24;
            lbl.color = s_TextColor;
        }

/*
        private static void SetPositionVisibleinSceneView(RectTransform canvasRTransform, RectTransform itemTransform)
        {
            // Find the best scene view
            SceneView sceneView = SceneView.lastActiveSceneView;
            if (sceneView == null && SceneView.sceneViews.Count > 0)
                sceneView = SceneView.sceneViews[0] as SceneView;

            // Couldn't find a SceneView. Don't set position.
            if (sceneView == null || sceneView.camera == null)
                return;

            // Create world space Plane from canvas position.
            Vector2 localPlanePosition;
            Camera camera = sceneView.camera;
            Vector3 position = Vector3.zero;
            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRTransform, new Vector2(camera.pixelWidth / 2, camera.pixelHeight / 2), camera, out localPlanePosition))
            {
                // Adjust for canvas pivot
                localPlanePosition.x = localPlanePosition.x + canvasRTransform.sizeDelta.x * canvasRTransform.pivot.x;
                localPlanePosition.y = localPlanePosition.y + canvasRTransform.sizeDelta.y * canvasRTransform.pivot.y;

                localPlanePosition.x = Mathf.Clamp(localPlanePosition.x, 0, canvasRTransform.sizeDelta.x);
                localPlanePosition.y = Mathf.Clamp(localPlanePosition.y, 0, canvasRTransform.sizeDelta.y);

                // Adjust for anchoring
                position.x = localPlanePosition.x - canvasRTransform.sizeDelta.x * itemTransform.anchorMin.x;
                position.y = localPlanePosition.y - canvasRTransform.sizeDelta.y * itemTransform.anchorMin.y;

                Vector3 minLocalPosition;
                minLocalPosition.x = canvasRTransform.sizeDelta.x * (0 - canvasRTransform.pivot.x) + itemTransform.sizeDelta.x * itemTransform.pivot.x;
                minLocalPosition.y = canvasRTransform.sizeDelta.y * (0 - canvasRTransform.pivot.y) + itemTransform.sizeDelta.y * itemTransform.pivot.y;

                Vector3 maxLocalPosition;
                maxLocalPosition.x = canvasRTransform.sizeDelta.x * (1 - canvasRTransform.pivot.x) - itemTransform.sizeDelta.x * itemTransform.pivot.x;
                maxLocalPosition.y = canvasRTransform.sizeDelta.y * (1 - canvasRTransform.pivot.y) - itemTransform.sizeDelta.y * itemTransform.pivot.y;

                position.x = Mathf.Clamp(position.x, minLocalPosition.x, maxLocalPosition.x);
                position.y = Mathf.Clamp(position.y, minLocalPosition.y, maxLocalPosition.y);
            }

            itemTransform.anchoredPosition = position;
            itemTransform.localRotation = Quaternion.identity;
            itemTransform.localScale = Vector3.one;
        }
*/ 
	};
};