using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Sprites;

public class SGameSpriteSettings : MonoBehaviour
{
    public ImageAlphaTexLayout layout = ImageAlphaTexLayout.None;
}