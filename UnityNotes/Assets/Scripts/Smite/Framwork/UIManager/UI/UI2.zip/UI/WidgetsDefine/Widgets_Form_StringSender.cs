namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_StringSender
	{
		EN_inputText = 0,
		EN_txtDesc = 1,
		EN_titleText = 2,
		EN_Placeholder = 3,
	}
};