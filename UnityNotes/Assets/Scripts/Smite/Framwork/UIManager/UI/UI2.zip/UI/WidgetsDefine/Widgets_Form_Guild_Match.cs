namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_Guild_Match
	{
		EN_imgGuildHead = 0,
		EN_txtGuildName = 1,
		EN_txtGuildMatchScore = 2,
		EN_TeamList = 3,
		EN_ListTab = 4,
		EN_txtOnlineNum = 5,
		EN_GuildScoreList = 6,
		EN_MemberScoreList = 7,
		EN_InviteList = 8,
		EN_SelfMemberRankPanel = 9,
		EN_txtMatchOpenTime = 10,
		EN_TimerRefreshGameState = 11,
		EN_txtLeftMatchCnt = 12,
		EN_SelfGuildRankPanel = 13,
		EN_rankGuild = 14,
		EN_imgHeadGuild = 15,
		EN_txtNameGuild = 16,
		EN_txtScoreGuild = 17,
		EN_SubTitle = 18,
		EN_txtTitle = 19,
		EN_Text = 20,
		EN_Slider = 21,
		EN_txtMoreLeader = 22,
		EN_btnSignUpCard = 23,
		EN_btnSignUpList = 24,
		EN_SignUpBubble = 25,
		EN_txtSignUpBubble = 26,
		EN_InvitationList = 27,
	}
};