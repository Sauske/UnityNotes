namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_Guild_Match_SignUpList
	{
		EN_txtTitle = 0,
		EN_listSignUp = 1,
		EN_txtSignUpTime = 2,
		EN_btnModifySignUpCard = 3,
		EN_txtLeaderIsExaming = 4,
	}
};