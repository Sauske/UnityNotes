namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_LadderSettle
	{
		EN_DetailScorePanel = 0,
		EN_NoScorePanel = 1,
		EN_txtNoScore = 2,
		EN_txtBraveScore = 3,
		EN_BravePanel = 4,
		EN_Tip = 5,
		EN_BPmodeopen = 6,
		EN_txtJizhan = 7,
		EN_txtLiansheng = 8,
		EN_txtXianfeng = 9,
		EN_txtTiaozhan = 10,
		EN_imgBraveProcess = 11,
		EN_txtBraveProcess = 12,
		EN_txtBraveExchange = 13,
		EN_ResultPanel = 14,
		EN_RankConOld = 15,
		EN_RankConNew = 16,
		EN_txtResult = 17,
		EN_lblJizhan = 18,
		EN_lblLiansheng = 19,
		EN_lblXianfeng = 20,
		EN_lblTiaozhan = 21,
		EN_FenGeXiang1 = 22,
		EN_FenGeXiang2 = 23,
		EN_FenGeXiang3 = 24,
		EN_FenGeXiang4 = 25,
	}
};