namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_GodEquip
	{
		EN_SubTab = 0,
		EN_godEquipPanel = 1,
		EN_systemEquipPanel = 2,
	}
};