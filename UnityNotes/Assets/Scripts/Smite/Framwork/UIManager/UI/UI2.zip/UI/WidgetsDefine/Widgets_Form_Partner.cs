namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_Partner
	{
		EN_toncai = 0,
		EN_xunyou = 1,
	}
};