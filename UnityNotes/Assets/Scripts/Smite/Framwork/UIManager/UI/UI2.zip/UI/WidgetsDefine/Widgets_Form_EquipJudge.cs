namespace Assets.Scripts.GameSystem
{
	public enum enWidgets_Form_EquipJudge
	{
		EN_equipPanel = 0,
		EN_ToggleList = 1,
		EN_MarksPanel = 2,
		EN_equipJudgeTitleMark = 3,
		EN_equipJudgeTitleDetail = 4,
	}
};