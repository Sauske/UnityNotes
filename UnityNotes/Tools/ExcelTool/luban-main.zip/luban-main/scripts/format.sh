cd ../src
dotnet format --severity error -v n
