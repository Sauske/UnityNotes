﻿namespace Luban.DataLoader.Builtin.DataVisitors;

class UnityAssetDataCreator : YamlDataCreator
{
    public new static UnityAssetDataCreator Ins = new();
}
