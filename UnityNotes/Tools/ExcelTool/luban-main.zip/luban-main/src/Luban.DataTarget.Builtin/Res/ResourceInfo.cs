namespace Luban.DataExporter.Builtin.Res;

public class ResourceInfo
{
    public string Resource { get; set; }

    public string Tag { get; set; }
}
