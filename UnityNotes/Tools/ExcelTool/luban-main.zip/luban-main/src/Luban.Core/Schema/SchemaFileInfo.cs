namespace Luban.Schema;

public class SchemaFileInfo
{
    public string FileName { get; set; }

    public string Type { get; set; }
}
