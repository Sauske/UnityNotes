﻿namespace Luban.Serialization;

public interface ITypeId
{
    int GetTypeId();
}
