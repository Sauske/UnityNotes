namespace Luban.RawDefs;

public class TypeMapper
{
    public List<string> Targets { get; set; }

    public List<string> CodeTargets { get; set; }

    public Dictionary<string, string> Options { get; set; }
}
