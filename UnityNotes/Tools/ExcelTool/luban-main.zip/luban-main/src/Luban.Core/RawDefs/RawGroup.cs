namespace Luban.RawDefs;

public class RawGroup
{
    public bool IsDefault { get; set; }

    public List<string> Names { get; set; }
}
