﻿namespace Luban.RawDefs;

public class RawRefGroup
{
    public string Name { get; set; }

    public List<string> Refs { get; set; }
}
