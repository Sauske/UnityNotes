namespace Luban.Validator;

public enum ValidatorType
{
    Data,
    Table,
}
