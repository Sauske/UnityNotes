namespace Luban.CustomBehaviour;

public interface IPriorityBehaviour
{
    int Priority { get; }
}
