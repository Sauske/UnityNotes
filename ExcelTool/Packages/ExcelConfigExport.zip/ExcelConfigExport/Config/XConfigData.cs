﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace ExcelConfigExport
{
    class XConfigData
    {
        #region static

        public static XConfigData CreateConfigData(object[,] head, LogEventHandler handler)
        {
            XConfigData cfgData = new XConfigData();
            cfgData.LogEvent += handler;
            if (null == head || cfgData.Init(head) == false)
            {
                return null;
            }
            return cfgData;
        }

        public static Hashtable DataTypeMap { get; private set; }
        public static Hashtable ShareTypeMap { get; private set; }

        static XConfigData()
        {
            DataTypeMap = new Hashtable();
            foreach (XConfigDataType dt in XConfigDefine.ALL_DATA_TYPE)
            {
                DataTypeMap.Add(dt.ConfigName, dt);
            }

            ShareTypeMap = new Hashtable();
            foreach (XConfigShareType share in XConfigDefine.ALL_SHARE_TYPE)
            {
                ShareTypeMap.Add(share.Name, share);
            }
        }

        private static XConfigDataType GetDataType(object s)
        {
            if (null == s)
            {
                return null;
            }
            if (DataTypeMap.Contains(s.ToString().Trim()))
            {
                return DataTypeMap[s] as XConfigDataType;
            }
            return null;
        }

        private static XConfigShareType GetShareType(object s)
        {
            if (null == s)
            {
                return null;
            }
            if (ShareTypeMap.Contains(s.ToString().Trim()))
            {
                return ShareTypeMap[s] as XConfigShareType;
            }
            return null;
        }

        #endregion

        #region Members

        public event LogEventHandler LogEvent;

        private XColumnInfo[] AllColumnInfo;

        private int ColumnNumber
        {
            get {
                return AllColumnInfo == null ? 0 : AllColumnInfo.Length;
            }
        }

        private List<object[]> m_LoadedData;

        #endregion

        #region Constructor and Init

        private XConfigData()
        {
            AllColumnInfo = null;
            m_LoadedData = new List<object[]>();
        }

        private bool Init(object[,] head)
        {
            if (null == head)
            {
                Log(ELogType.ERROR, "数据表表头为空");
                return false;
            }
            if (head.GetLength(0) <= (int)EConfigHeadType.Count)
            {
                Log(ELogType.ERROR, "数据表表头行数不正确, 需求行数:{0}, 实际行数:{1}", (int)EConfigHeadType.Count, head.GetLength(0));
                return false;
            }

            AllColumnInfo = new XColumnInfo[head.GetLength(1)];
            int rowBase = head.GetLowerBound(0);
            int colBase = head.GetLowerBound(1);
            for (int col = 0; col < ColumnNumber; ++col)
            {
                if (SetColumnInfo(col,
                    head[rowBase + (int)EConfigHeadType.Desc,       col + colBase],
                    head[rowBase + (int)EConfigHeadType.CodeName,   col + colBase],
                    head[rowBase + (int)EConfigHeadType.DataType,   col + colBase],
                    head[rowBase + (int)EConfigHeadType.ShareType, col + colBase]) == false)
                {
                    Log(ELogType.ERROR, "获取数据表头信息失败, 列:{0}", col);
                    return false;
                }
            }
            return true;
        }

        #endregion

        #region Logical Interface

        public void ClearData()
        {
            m_LoadedData.Clear();
        }

        public bool CheckLine(object[] line)
        {
            return doAddLine(line, false);
        }

        public bool AddLine(object[] line)
        {
            return doAddLine(line, true);
        }

        public bool CheckMultiLine(object[,] multiLine, int addRowBegin)
        {
            return doAddMultiLine(multiLine, addRowBegin, false);
        }

        public bool AddMultiLine(object[,] multiLine, int addRowBegin)
        {
            return doAddMultiLine(multiLine, addRowBegin, true);
        }

        public bool ExportConfigFile(XCfgExportInfo cfgInfo)
        {
            if (null == cfgInfo)
            {
                return false;
            }
            if (doExportConfig(EConfigShareFlag.Client, cfgInfo.ClientConfig) == false)
            {
                return false;
            }
            if (doExportConfig(EConfigShareFlag.Server, cfgInfo.ServerConfig) == false)
            {
                return false;
            }
            return true;
        }

        public bool ExportSourceFile(XSrcExportInfo srcInfo)
        {
            if (null == srcInfo)
            {
                return false;
            }
            if (doExportSource(ECodeLanguageType.CS, srcInfo) == false)
            {
                return false;
            }
            //服务器不需要导出
            //if (doExportSource(ECodeLanguageType.CPP, srcInfo) == false)
            //{
            //    return false;
            //}
            return true;
        }

        #endregion

        #region Excel 表格导入

        private bool SetColumnInfo(int col, object desc, object name, object dt, object share)
        {
            if (col < 0 || col >= ColumnNumber)
            {
                return false;
            }
            XConfigShareType shareType = GetShareType(share);
            if (null == shareType)
            {
                Log(ELogType.ERROR, "数据表的共享类型定义不正确, 列:{0}, 列名:{1}, 共享类型:{2}, 描述:{3}", col, name, share, desc);
                return false;
            }
            XConfigDataType dataType = null;
            if (EConfigShareFlag.Skip != shareType.Flag)
            {
                dataType = GetDataType(dt);
                if (null == dataType)
                {
                    Log(ELogType.ERROR, "数据表的数据类型定义不正确, 列:{0}, 列名:{1}, 数据类型:{2}, 描述:{3}", col, name, dt, desc);
                    return false;
                }
            }
            XColumnInfo info = XColumnInfo.CreateColumnInfo(desc, name, dataType, shareType);
            if (null == info)
            {
                Log(ELogType.ERROR, "数据表的列名(变量名)不符合要求, 列:{0}, 列名:{1}, 描述:{2}", col, name, desc);
                return false;
            }
            AllColumnInfo[col] = info;
            return true;
        }

        private object GetColumnData(int col, object data)
        {
            if (col < 0 || col >= ColumnNumber)
            {
                return null;
            }
            XColumnInfo info = AllColumnInfo[col];
            if (null == info)
            {
                Log(ELogType.ERROR, "加载数据行错误, 列定义未加载, 列:{0}", col);
                return null;
            }
            if (info.ShareType.Flag == EConfigShareFlag.Skip)
            {
                return string.Empty;
            }
            object ret = info.DataType.GetData(data);
            if (null == ret)
            {
                Log(ELogType.ERROR, "加载数据行错误, 数据值和列定义不相符, 列:{0} 列名:{1} 数据值:{2}", col, info.ConfigName, null != data ? data.ToString() : string.Empty);
                return null;
            }
            return ret;
        }

        private bool isSkipFlag(object cell)
        {
            return cell.ToString().Trim().StartsWith(XConfigDefine.SKIP_LINE_FLAG);
        }

        private bool doAddLine(object[] line, bool bAddData)
        {
            if (null == line)
            {
                Log(ELogType.ERROR, "加载数据行错误, 空行");
                return false;
            }
            if (line.GetLength(0) != ColumnNumber)
            {
                Log(ELogType.ERROR, "加载数据行错误, 数据项和表的列数不一致, 需求列数:{0}, 实际列数:{1}", ColumnNumber, line.GetLength(0));
                return false;
            }
            int colFirst = line.GetLowerBound(0), colLast = line.GetUpperBound(0);

            // 跳过的行
            if (colFirst <= colLast && isSkipFlag(line[colFirst]))
            {
                return true;
            }
            object[] dataLine = new object[ColumnNumber];
            for (int col = colFirst; col <= colLast; ++col)
            {
                dataLine[col] = GetColumnData(col, line[col]);
                if (null == dataLine[col])
                {
                    Log(ELogType.ERROR, "添加数据行失败, 第 {0} 列数据有问题", col);
                    return false;
                }
            }
            if (bAddData)
            {
                m_LoadedData.Add(dataLine);
            }
            return true;
        }

        private bool doAddMultiLine(object[,] multiLine, int addRowBegin, bool bAddData)
        {
            if (null == multiLine)
            {
                Log(ELogType.ERROR, "加载数据行错误, 空行");
                return false;
            }

            Log(ELogType.INFO, "--4> 开始加载数据");

            if (addRowBegin < multiLine.GetLowerBound(0))
            {
                Log(ELogType.ERROR, "读取数据失败, 数据下标范围错误");
                return false;
            }
            if (multiLine.GetLength(1) != ColumnNumber)
            {
                Log(ELogType.ERROR, "加载数据行错误, 数据项和表的列数不一致, 需求列数:{0}, 实际列数:{1}", ColumnNumber, multiLine.GetLength(1));
                return false;
            }
            int addRowLast = multiLine.GetUpperBound(0);
            int colBase = multiLine.GetLowerBound(1);

            List<object[]> allDataLine = new List<object[]>();
            for (int row = addRowBegin; row <= addRowLast; ++row)
            {
                // 跳过无用行
                if (ColumnNumber > 0 && isSkipFlag(multiLine[row, colBase]))
                {
                    continue;
                }
                object[] dataLine = new object[ColumnNumber];
                for (int col = 0; col < ColumnNumber; ++col)
                {
                    dataLine[col] = GetColumnData(col, multiLine[row, col + colBase]);
                    if (null == dataLine[col])
                    {
                        Log(ELogType.ERROR, "加载第 {0} 行数据失败", row);
                        return false;
                    }
                }
                allDataLine.Add(dataLine);
            }
            if (bAddData)
            {
                m_LoadedData.AddRange(allDataLine);
                Log(ELogType.INFO, "成功加载 {0} 行数据, 加载的有效数据总行数:{1}", allDataLine.Count, m_LoadedData.Count);
            }

            Log(ELogType.INFO, "--4> 成功加载数据");
            return true;
        }

        #endregion

        #region 导出txt配置文件

        private bool doExportConfig(EConfigShareFlag flag, string sFileName)
        {
            Log(ELogType.INFO, "--4> 开始导出 {0} 配置文件, 文件名:{1}", flag.ToString(), sFileName);

            // 如果没有相关配置列导出, 不创建目标文件
            List<int> exColList = getExportColumnList(flag);
            if (exColList.Count > 0)
            {
                if (createFile(sFileName) == false)
                {
                    return false;
                }
                try
                {
                    using (StreamWriter fs = new StreamWriter(sFileName, false, XConfigDefine.UTF8_EMITBOM))
                    {
                        
                        //写入客户端TXT文件
                        if(flag == EConfigShareFlag.Client)
                        {
                            string oLine = "#";

                            // 写表头
                            for (int i = 0; i < exColList.Count; ++i)
                            {
                                if (i > 0)
                                {
                                    oLine += XConfigDefine.SPLIT_STRING;
                                }
                                oLine += AllColumnInfo[exColList[i]].ConfigName;
                            }
                            fs.WriteLine(oLine);

                            // 写数据
                            foreach (object[] line in m_LoadedData)
                            {
                                //--4>TODO: 可以改成 string.Join() 来实现
                                oLine = string.Empty;
                                for (int i = 0; i < exColList.Count; ++i)
                                {
                                    if (i > 0)
                                    {
                                        oLine += XConfigDefine.SPLIT_STRING;
                                    }
                                    oLine += line[exColList[i]].ToString();
                                }
                                fs.WriteLine(oLine);
                            }
                        }

                        //写入服务器python脚本
                        else if(flag == EConfigShareFlag.Server)
                        {
                            fs.WriteLine("#============================================");
                            fs.WriteLine("#--4>:");
                            fs.WriteLine("# Exported by ExcelConfigExport");
                            fs.WriteLine("#");
                            fs.WriteLine("# 此代码为工具根据配置自动生成, 建议不要修改");
                            fs.WriteLine("#");
                            fs.WriteLine("#============================================");
                            fs.WriteLine("import Math");
                            fs.WriteLine("datas = {");
                            Dictionary<string, string> dct = new Dictionary<string, string>();
                            foreach (object[] line in m_LoadedData)
                            {
                                fs.WriteLine("\t{0}:", line[0]);
                                fs.WriteLine("\t\t{");

                                dct.Clear();
                                for (int i = 0; i < exColList.Count; ++i)
                                {
                                    XColumnInfo info = AllColumnInfo[exColList[i]];
                                    string text = line[exColList[i]].ToString();
                                    if(info.IsArray)
                                    {
                                        if(!dct.ContainsKey(info.DefName))
                                        {
                                            dct.Add(info.DefName, "[");
                                        }

                                        if (info.DataType is XConfigDataType_Normal)
                                        {
                                            if (info.DataType.ConfigName == "string")
                                            {
                                                text = string.Format("\"{0}\"", text);
                                            }
                                            dct[info.DefName] = string.Format("{0}{1},", dct[info.DefName], text);
                                        }
                                        else if(info.DataType is XConfigDataType_Special)
                                        {
                                            string[] ts = text.Split(';');
                                            if (ts.Length < 3)
                                            {
                                                Log(ELogType.ERROR, "导出 {0} 配置文件失败, 文件名:{1}, 431 line for XConfigDataType_Special", flag.ToString(), sFileName);
                                                return false;
                                            }
                                            text = string.Format("Math.Vector3({0}, {1}, {2})", ts[0], ts[1], ts[2]);
                                            dct[info.DefName] = string.Format("{0}{1},", dct[info.DefName], text);

                                        }
                                    }
                                    else if (info.DataType is XConfigDataType_Normal)
                                    {
                                        if(info.DataType.ConfigName == "string")
                                        {
                                            text = string.Format("\"{0}\"", text);
                                        }
                                        fs.WriteLine("\t\t\t\"{0}\":{1},", info.DefName, text);
                                    }
                                    else if (info.DataType is XConfigDataType_Special)
                                    {
                                        string[] ts = text.Split(';');
                                        if(ts.Length < 3)
                                        {
                                            Log(ELogType.ERROR, "导出 {0} 配置文件失败, 文件名:{1}, 431 line for XConfigDataType_Special", flag.ToString(), sFileName);
                                            return false;
                                        }
                                        text = string.Format("Math.Vector3({0}, {1}, {2})", ts[0], ts[1], ts[2]);
                                        fs.WriteLine("\t\t\t\"{0}\":{1},", info.DefName, text);
                                    }

                                    //fs.WriteLine("\t\t\t{0}:{1},", info.GetVarDefineStr(ECodeLanguageType.CPP), text);
                                }
                                foreach(KeyValuePair<string, string> kvp in dct)
                                {
                                    fs.WriteLine("\t\t\t\"{0}\":{1}],", kvp.Key, kvp.Value);

                                }

                                fs.WriteLine("\t\t},");
                            }
                                //foreach (int col in exColList)
                                //{
                                //    XColumnInfo info = AllColumnInfo[col];

                                //    //第一行肯定为ID

                                //    if (info.DataType is XConfigDataType_Normal)
                                //    {
                                //        //为数组
                                //        if(info.IsArray)
                                //        {

                                //        }
                                //        else
                                //        {

                                //        }
                                //    }

                                //    else if (info.DataType is XConfigDataType_Special)
                                //    {

                                //    }
                                //}

                                fs.WriteLine("}");
                        }
                        fs.Close();
                    }
                }
                catch (System.Exception ex)
                {
                    Log(ELogType.ERROR, "导出 {0} 配置文件失败, 文件名:{1}, 错误:{2}", flag.ToString(), sFileName, ex.ToString());
                    return false;
                }
            }
            Log(ELogType.INFO, "--4> 成功导出 {0} 配置文件, 文件名:{1}, 数据行数:{2}", flag.ToString(), sFileName, m_LoadedData.Count);
            return true;
        }

        #endregion

        #region 导出源代码

        private bool doExportSource(ECodeLanguageType e, XSrcExportInfo cfgSrc)
        {
            string sFileName = cfgSrc.GetSourceName(e);
            Log(ELogType.INFO, "--4> 开始导出 {0} 代码文件, 文件名:{1}", e.ToString(), sFileName);

            bool bRet = false;

            // 如果没有相关配置列导出, 不创建目标文件
            List<int> exColList = getExportColumnList(e == ECodeLanguageType.CPP ? EConfigShareFlag.Server : EConfigShareFlag.Client);
            if (null != exColList && exColList.Count > 0)
            {
                switch (e)
                {
                    case ECodeLanguageType.CS:
                        bRet = doExportCSharpSource(cfgSrc.CsInfo);
                        break;
                    case ECodeLanguageType.CPP:
                        bRet = doExportCppSource(cfgSrc.CppInfo);
                        break;
                    default:
                        bRet = false;
                        break;
                }
            }
            else
            {
                bRet = true;
            }
            if (bRet)
            {
                Log(ELogType.INFO, "--4> 成功导出 {0} 代码文件, 文件名:{1}", e.ToString(), sFileName);
            }
            else
            {
                Log(ELogType.ERROR, "--4> 导出 {0} 代码文件失败, 文件名:{1}", e.ToString(), sFileName);
            }
            return bRet;
        }

        #region 导出 CSharp 代码

        private bool doExportCSharpSource(XCsSrcInfo cfgSrc)
        {
            string sClassName = cfgSrc.ClassName;
            string sFileName = cfgSrc.FilePath;

            if (XConfigDefine.IsValidCodeName(sClassName) == false)
            {
                Log(ELogType.ERROR, "导出 C# 代码文件失败, 类名不符合规则, 文件名:{0}, 类名:{1}", sFileName, sClassName);
                return false;
            }

            if (createFile(sFileName) == false)
            {
                return false;
            }

            try
            {
                using (StreamWriter fs = new StreamWriter(sFileName, false, XConfigDefine.UTF8_EMITBOM))
                {
                    List<int> exColList = getExportColumnList(EConfigShareFlag.Client);

                    // 头部数据
                    writeCode(fs, 0, XConfigDefine.SOURCE_FILE_HEAD);
                    fs.WriteLine();
                    writeCode(fs, 0, XConfigDefine.CSHARP_INCLUDE);
                    fs.WriteLine();

                    // 管理器定义  注释掉
                   // writeCsMgrDef(fs, cfgSrc);

                    // 类定义
                    writeCsClassDef(fs, cfgSrc);
                    writeCode(fs, 1, "{");

                    //// 导出列的字符串索引
                    //foreach (int col in exColList)
                    //{
                    //    XColumnInfo info = AllColumnInfo[col];
                    //    writeCode(fs, 1, "public static readonly string {0}{1} = \"{2}\";",
                    //        XConfigDefine.CSHARP_KEY_PREFIX, info.ConfigName, info.ConfigName);
                    //}
                    fs.WriteLine();

                    // 成员变量定义
                    foreach (int col in exColList)
                    {
                        XColumnInfo info = AllColumnInfo[col];
                        // 数组只有下标为 0 的需要定义
                        if (false == info.IsArray || 0 == info.ArrayIndex)
                        {
                            writeCode(fs, 2, "public {0} {{ get; private set; }}\t\t\t\t// {1}", info.GetVarDefineStr(ECodeLanguageType.CS), info.ColDesc);
                        }
                    }
                    fs.WriteLine();

                    // 构造函数定义(用于初始化数组变量)
                    writeCode(fs, 2, "public {0}()", sClassName);
                    writeCode(fs, 2, "{");
                    foreach (int col in exColList)
                    {
                        XColumnInfo info = AllColumnInfo[col];
                        if (info.IsArray && 0 == info.ArrayIndex)
                        {
                            writeCode(fs, 3, "{0} = new {1}[{2}];", info.DefName, info.DataType.CsName, info.ArraySize);
                        }
                    }
                    writeCode(fs, 2, "}");
                    fs.WriteLine();

                    //writeCsKeyInterface(fs, cfgSrc);

                    // 数据读取函数
                    writeCode(fs, 2, XConfigDefine.CSHARP_READ_METHOD);
                    writeCode(fs, 2, "{");
                    writeCode(fs, 3, "string[] text = XUtil.Split(dataRowText);");
                    writeCode(fs, 3, "int index = 0;");
                    foreach (int col in exColList)
                    {
                        XColumnInfo info = AllColumnInfo[col];
                        if (info.DataType is XConfigDataType_Normal)
                        {
                            writeCode(fs, 3, "{0} = XUtil.Get<{2}>(text[index++]);", info.VarName, XConfigDefine.CSHARP_READ_READER,
                                info.DataType.CsName, XConfigDefine.CSHARP_KEY_PREFIX, info.ConfigName);
                        }
                        else if (info.DataType is XConfigDataType_Special)
                        {
                            writeCode(fs, 3, "{0} = {5}(text[index++]);", info.VarName, XConfigDefine.CSHARP_READ_READER,
                                info.DataType.CsName, XConfigDefine.CSHARP_KEY_PREFIX, info.ConfigName, (info.DataType as XConfigDataType_Special).Reader_CS);
                        }
                    }

                    // 函数末尾
                    //writeCode(fs, 2, "return true;");
                    writeCode(fs, 2, "}");

                    writeCode(fs, 1, "}");
                    writeCode(fs, 0, "}");
                    fs.WriteLine();
                    fs.Close();
                }
            }
            catch (System.Exception ex)
            {
                Log(ELogType.ERROR, "导出 c# 代码文件失败, 文件名:{0}, 类名:{1}, 错误:{2}", sFileName, sClassName, ex.ToString());
                return false;
            }
            return true;
        }

        // 管理器类定义
        private void writeCsMgrDef(StreamWriter fs, XCsSrcInfo cfgSrc)
        {
            string sClassName = cfgSrc.ClassName;
            string sMgrName = sClassName + XConfigDefine.MANAGER_CLASS_SUFFIX;
            switch (cfgSrc.MgrType.MgrEnum)
            {
                case ECfgMgrType.NoKeyList:
                    writeCode(fs, 0, "partial class {0} : {1}<{0}, {2}> {{ }};", sMgrName, cfgSrc.MgrType.CsMgrBaseName, sClassName);
                    fs.WriteLine();
                    break;
                case ECfgMgrType.OneKeyMgr:
                    writeCode(fs, 0, "partial class {0} : {1}<{0}, {2}, {3}> {{ }};",
                        sMgrName, cfgSrc.MgrType.CsMgrBaseName, AllColumnInfo[XConfigDefine.KEY1_INDEX].DataType.CsName, sClassName);
                    fs.WriteLine();
                    break;
                case ECfgMgrType.OneGroupMgr:
                    writeCode(fs, 0, "partial class {0} : {1}<{0}, {2}, {3}> {{ }};",
                        sMgrName, cfgSrc.MgrType.CsMgrBaseName, AllColumnInfo[XConfigDefine.KEY1_INDEX].DataType.CsName, sClassName);
                    fs.WriteLine();
                    break;
                case ECfgMgrType.TwoKeyMgr:
                    writeCode(fs, 0, "partial class {0} : {1}<{0}, {2}, {3}, {4}> {{ }};",
                        sMgrName, cfgSrc.MgrType.CsMgrBaseName, AllColumnInfo[XConfigDefine.KEY1_INDEX].DataType.CsName,
                        AllColumnInfo[XConfigDefine.KEY2_INDEX].DataType.CsName, sClassName);
                    fs.WriteLine();
                    break;
                default:
                    break;
            }
        }

        private void writeCsClassDef(StreamWriter fs, XCsSrcInfo cfgSrc)
        {
            string sClassName = cfgSrc.ClassName;

            writeCode(fs, 0, "namespace CC");
            writeCode(fs, 0, "{");
            writeCode(fs, 1, "public partial class {0} : {1}",
                        sClassName, XConfigDefine.CSHARP_CLASS_BASE_0KEY);

            //
            //switch (cfgSrc.MgrType.MgrEnum)
            //{
            //    case ECfgMgrType.OneKeyMgr:
            //    case ECfgMgrType.OneGroupMgr:
            //        writeCode(fs, 0, "partial class {0} : {1}<{2}>",
            //            sClassName, XConfigDefine.CSHARP_CLASS_BASE_1KEY,
            //            AllColumnInfo[XConfigDefine.KEY1_INDEX].DataType.CsName);
            //        break;
            //    case ECfgMgrType.TwoKeyMgr:
            //        writeCode(fs, 0, "partial class {0} : {1}<{2}, {3}>",
            //            sClassName, XConfigDefine.CSHARP_CLASS_BASE_2KEY,
            //            AllColumnInfo[XConfigDefine.KEY1_INDEX].DataType.CsName,
            //            AllColumnInfo[XConfigDefine.KEY2_INDEX].DataType.CsName);
            //        break;
            //    default:
            //        writeCode(fs, 0, "partial class {0} : {1}",
            //            sClassName, XConfigDefine.CSHARP_CLASS_BASE_0KEY);
            //        break;
            //}
        }

        // 根据管理器类别输出结构体的键值接口
        private void writeCsKeyInterface(StreamWriter fs, XCsSrcInfo cfgSrc)
        {
            switch (cfgSrc.MgrType.MgrEnum)
            {
                case ECfgMgrType.OneKeyMgr:
                case ECfgMgrType.OneGroupMgr:
                    writeCode(fs, 1, "public {0} {1}() {{ return {2}; }}",
                        AllColumnInfo[XConfigDefine.KEY1_INDEX].DataType.CsName,
                        XConfigDefine.KEY1_FUN, AllColumnInfo[XConfigDefine.KEY1_INDEX].VarName);
                    fs.WriteLine();
                    break;
                case ECfgMgrType.TwoKeyMgr:
                    writeCode(fs, 1, "public {0} {1}() {{ return {2}; }}",
                        AllColumnInfo[XConfigDefine.KEY1_INDEX].DataType.CsName,
                        XConfigDefine.KEY1_FUN, AllColumnInfo[XConfigDefine.KEY1_INDEX].VarName);
                    fs.WriteLine();
                    writeCode(fs, 1, "public {0} {1}() {{ return {2}; }}",
                        AllColumnInfo[XConfigDefine.KEY2_INDEX].DataType.CsName,
                        XConfigDefine.KEY2_FUN, AllColumnInfo[XConfigDefine.KEY2_INDEX].VarName);
                    fs.WriteLine();
                    break;
                default:
                    break;
            }
        }

        #endregion

        #region 导出 C++ 代码

        private bool doExportCppSource(XCppSrcInfo cfgSrc)
        {
            string sClassName = cfgSrc.ClassName;
            string sFileName = cfgSrc.FilePath;

            if (XConfigDefine.IsValidCodeName(sClassName) == false)
            {
                Log(ELogType.ERROR, "导出 C++ 代码文件失败, 类名不符合规则, 文件名:{0}, 类名:{1}", sFileName, sClassName);
                return false;
            }

            if (createFile(sFileName) == false)
            {
                return false;
            }

            try
            {
                // 服务器代码加上 UTF8 标记, 不然 VS 可能识别报错
                using (StreamWriter fs = new StreamWriter(sFileName, false, Encoding.UTF8))
                {
                    List<int> exColList = getExportColumnList(EConfigShareFlag.Server);

                    // 头部数据
                    writeCode(fs, 0, XConfigDefine.SOURCE_FILE_HEAD);
                    fs.WriteLine();
                    writeCppHead(fs, cfgSrc);

                    // 类定义
                    //--4>TODO: 考虑加上大小
                    writeCode(fs, 0, "struct {0} : public {1}<{2}, {3}>", sClassName, XConfigDefine.CPP_CLASS_BASE, sClassName, cfgSrc.Capacity);
                    writeCode(fs, 0, "{");

                    // 成员变量定义
                    foreach (int col in exColList)
                    {
                        XColumnInfo info = AllColumnInfo[col];
                        // 数组只有下标为 0 的需要定义
                        if (false == info.IsArray || 0 == info.ArrayIndex)
                        {
                            writeCode(fs, 1, "{0};\t\t\t\t// {1}", info.GetVarDefineStr(ECodeLanguageType.CPP), info.ColDesc);
                        }
                    }
                    fs.WriteLine();

                    // 定义获取主键值的函数
                    writeCppKeyInterface(fs, cfgSrc);

                    // 数据读取函数
                    writeCode(fs, 1, XConfigDefine.CPP_READ_METHOD);
                    writeCode(fs, 1, "{");

                    // 所有字段读取
                    // 临时变量定义标记
                    bool[] bTempVarFlag = new bool[] { false, false, false }; // int, float, string
                    foreach (int col in exColList)
                    {
                        XColumnInfo info = AllColumnInfo[col];
                        switch (info.DataType.ConfigName)
                        {
                            case "int":
                            case "uint":
                            case "short":
                            case "ushort":
                            case "word":
                            case "byte":
                            case "char":
                                if (false == bTempVarFlag[0])
                                {
                                    writeCode(fs, 2, "INT {0};", XConfigDefine.CPP_TEMP_INT);
                                    bTempVarFlag[0] = true;
                                }
                                writeCode(fs, 2, "{0}.GetInteger(\"{1}\", 0, (int*)&{2}); this->{3} = ({4}){2};",
                                    XConfigDefine.CPP_READ_READER, info.ConfigName, XConfigDefine.CPP_TEMP_INT, info.VarName, info.DataType.CppName);
                                break;
                            case "float":
                                if (false == bTempVarFlag[1])
                                {
                                    writeCode(fs, 2, "FLOAT {0};", XConfigDefine.CPP_TEMP_FLOAT);
                                    bTempVarFlag[1] = true;
                                }
                                writeCode(fs, 2, "{0}.GetFloat(\"{1}\", 0, (float*)&{2}); this->{3} = ({4}){2};",
                                    XConfigDefine.CPP_READ_READER, info.ConfigName, XConfigDefine.CPP_TEMP_FLOAT, info.VarName, info.DataType.CppName);
                                break;
                            case "string":
                            case "vector3":
                                if (false == bTempVarFlag[2])
                                {
                                    writeCode(fs, 2, "char {0}[{2}];", XConfigDefine.CPP_TEMP_STRING, XConfigDefine.CPP_TEMP_STRING, XConfigDefine.CPP_TEMP_STR_LEN);
                                    bTempVarFlag[2] = true;
                                }
                                if (info.DataType is XConfigDataType_Normal)
                                {
                                    writeCode(fs, 2, "{0}.GetString(\"{1}\", \"\", {2}, {3}); this->{4} = ({5}){2};",
                                        XConfigDefine.CPP_READ_READER, info.ConfigName, XConfigDefine.CPP_TEMP_STRING,
                                        XConfigDefine.CPP_TEMP_STR_LEN, info.VarName, info.DataType.CppName);
                                }
                                else
                                {
                                    writeCode(fs, 2, "{0}.GetString(\"{1}\", \"\", {2}, {3}); this->{4} = {5}({2});",
                                        XConfigDefine.CPP_READ_READER, info.ConfigName, XConfigDefine.CPP_TEMP_STRING,
                                        XConfigDefine.CPP_TEMP_STR_LEN, info.VarName, (info.DataType as XConfigDataType_Special).Reader_CPP);
                                }
                                break;
                            default:
                                Log(ELogType.ERROR, "导出 c++ 代码文件失败, 字段类型不对, 字段名:{0}, 字段类型:{1}, 文件名:{2}, 类名:{3}",
                                    info.VarName, info.DataType.ConfigName, sFileName, sClassName);
                                return false;
                        }
                    }

                    // 函数末尾
                    writeCode(fs, 2, "return TRUE;");
                    writeCode(fs, 1, "}");

                    // 类末尾
                    writeCode(fs, 0, "};");
                    fs.WriteLine();

                    // 管理器定义
                    writeCppMgrDef(fs, cfgSrc);

                    fs.Close();
                }
            }
            catch (System.Exception ex)
            {
                Log(ELogType.ERROR, "导出 c# 代码文件失败, 文件名:{0}, 类名:{1}, 错误:{2}", sFileName, sClassName, ex.ToString());
                return false;
            }
            return true;
        }

        // 头文件
        private void writeCppHead(StreamWriter fs, XCppSrcInfo cfgSrc)
        {
            writeCode(fs, 0, XConfigDefine.CPP_INCLUDE);
            writeCode(fs, 0, cfgSrc.MgrType.CppMgrHead);
            fs.WriteLine();
        }

        // 根据管理器类别输出结构体的键值接口
        private void writeCppKeyInterface(StreamWriter fs, XCppSrcInfo cfgSrc)
        {
            switch (cfgSrc.MgrType.MgrEnum)
            {
                case ECfgMgrType.OneKeyMgr:
                case ECfgMgrType.OneGroupMgr:
                    writeCode(fs, 1, "inline {0} {1}() const {{ return {2}; }}", AllColumnInfo[XConfigDefine.KEY1_INDEX].DataType.CppName,
                        XConfigDefine.KEY1_FUN, AllColumnInfo[XConfigDefine.KEY1_INDEX].VarName);
                    fs.WriteLine();
                    break;
                case ECfgMgrType.TwoKeyMgr:
                    writeCode(fs, 1, "inline {0} {1}() const {{ return {2}; }}", AllColumnInfo[XConfigDefine.KEY1_INDEX].DataType.CppName,
                        XConfigDefine.KEY1_FUN, AllColumnInfo[XConfigDefine.KEY1_INDEX].VarName);
                    fs.WriteLine();
                    writeCode(fs, 1, "inline {0} {1}() const {{ return {2}; }}", AllColumnInfo[XConfigDefine.KEY2_INDEX].DataType.CppName,
                        XConfigDefine.KEY2_FUN, AllColumnInfo[XConfigDefine.KEY2_INDEX].VarName);
                    fs.WriteLine();
                    break;
                default:
                    break;
            }
        }

        // 管理器类定义
        private void writeCppMgrDef(StreamWriter fs, XCppSrcInfo cfgSrc)
        {
            string sClassName = cfgSrc.ClassName;
            string sMgrName = sClassName + XConfigDefine.MANAGER_CLASS_SUFFIX;
            switch (cfgSrc.MgrType.MgrEnum)
            {
                case ECfgMgrType.NoKeyList:
                    writeCode(fs, 0, "class {0} : public {1}<{0}, {2}, {3}, {4}> {{ }};", sMgrName,
                        cfgSrc.MgrType.CppMgrBaseName, sClassName, cfgSrc.Capacity, cfgSrc.StepSize);
                    fs.WriteLine();
                    break;
                case ECfgMgrType.OneKeyMgr:
                    writeCode(fs, 0, "class {0} : public {1}<{0}, {2}, {3}, {4}, {5}> {{ }};", sMgrName, cfgSrc.MgrType.CppMgrBaseName,
                        AllColumnInfo[XConfigDefine.KEY1_INDEX].DataType.CppName, sClassName, cfgSrc.Capacity, cfgSrc.StepSize);
                    fs.WriteLine();
                    break;
                case ECfgMgrType.OneGroupMgr:
                    writeCode(fs, 0, "class {0} : public {1}<{0}, {2}, {3}, {4}, {5}> {{ }};", sMgrName, cfgSrc.MgrType.CppMgrBaseName,
                        AllColumnInfo[XConfigDefine.KEY1_INDEX].DataType.CppName, sClassName, cfgSrc.KeyCount, cfgSrc.GroupSize);
                    fs.WriteLine();
                    break;
                case ECfgMgrType.TwoKeyMgr:
                    writeCode(fs, 0, "class {0} : public {1}<{0}, {2}, {3}, {4}, {5}, {6}> {{ }};", sMgrName, cfgSrc.MgrType.CppMgrBaseName,
                        AllColumnInfo[XConfigDefine.KEY1_INDEX].DataType.CppName, AllColumnInfo[XConfigDefine.KEY2_INDEX].DataType.CppName,
                        sClassName, cfgSrc.KeyCount, cfgSrc.GroupSize);
                    fs.WriteLine();
                    break;
                default:
                    break;
            }
        }

        #endregion

        private void writeCode(StreamWriter fs, int tabNum, string data)
        {
            writeCode(fs, tabNum, data, null);
        }

        private void writeCode(StreamWriter fs, int tabNum, string format, params object[] args)
        {
            if (tabNum < 0 || tabNum > XConfigDefine.TAB_STRING_MAX.Length)
            {
                tabNum = 0;
            }
            if (null == args)
            {
                fs.WriteLine(XConfigDefine.TAB_STRING_MAX.Substring(0, tabNum) + format);
            }
            else
            {
                fs.WriteLine(XConfigDefine.TAB_STRING_MAX.Substring(0, tabNum) + string.Format(format, args));
            }
        }

        #endregion

        private List<int> getExportColumnList(EConfigShareFlag flag)
        {
            List<int> exColList = new List<int>();
            for (int col = 0; col < ColumnNumber; ++col)
            {
                if ((AllColumnInfo[col].ShareType.Flag & flag) != EConfigShareFlag.None)
                {
                    exColList.Add(col);
                }
            }
            return exColList;
        }

        private bool createFile(string sFileName)
        {
            if (null == sFileName || sFileName == string.Empty)
            {
                Log(ELogType.ERROR, "创建文件失败, 文件名为空");
                return false;
            }
            try
            {
                if (File.Exists(sFileName))
                {
                    if (FileAttributes.ReadOnly == (File.GetAttributes(sFileName) & FileAttributes.ReadOnly))
                    {
                        Log(ELogType.ERROR, "文件:{0} 是只读的, 请先从 Perforce 版本库 checkout.", sFileName);
                        return false;
                    }
                    else
                    {
                        File.Delete(sFileName);
                    }
                }
                using (FileStream fs = File.Create(sFileName))
                {
                    fs.Close();
                }
            }
            catch (System.Exception ex)
            {
                Log(ELogType.ERROR, "创建文件失败, 文件:{0}, 错误:{1}", sFileName, ex.ToString());
                return false;
            }
            return true;
        }

        public void Log(ELogType t, string format, params object[] args)
        {
            if (LogEvent != null)
            {
                LogEvent(t, format, args);
            }
        }
    }
}
