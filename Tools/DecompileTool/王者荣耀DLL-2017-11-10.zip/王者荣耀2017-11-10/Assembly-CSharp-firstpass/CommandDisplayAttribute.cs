using System;

[AttributeUsage]
internal class CommandDisplayAttribute : AutoRegisterAttribute
{
}
