using System;

namespace Apollo.Plugins.Msdk
{
	internal class Common
	{
		public const string PluginName = "MsdkAdapter";
	}
}
