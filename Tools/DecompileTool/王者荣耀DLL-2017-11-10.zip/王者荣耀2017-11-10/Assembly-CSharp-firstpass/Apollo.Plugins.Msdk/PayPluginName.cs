using System;

namespace Apollo.Plugins.Msdk
{
	public enum PayPluginName
	{
		Midas = 1
	}
}
