using System;

namespace Apollo.Plugins.Msdk
{
	public enum PayAction
	{
		BuyGameCoin = 1,
		BuyMounthCard,
		LaunchMPMall = 4,
		LaunchMPItem = 8,
		BuyMonth = 16
	}
}
