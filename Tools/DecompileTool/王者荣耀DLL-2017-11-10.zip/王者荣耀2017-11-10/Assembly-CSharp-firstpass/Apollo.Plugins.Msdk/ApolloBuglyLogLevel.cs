using System;

namespace Apollo.Plugins.Msdk
{
	public enum ApolloBuglyLogLevel
	{
		ApolloBuglyLogLevelS,
		ApolloBuglyLogLevelE,
		ApolloBuglyLogLevelW,
		ApolloBuglyLogLevelI,
		ApolloBuglyLogLevelD,
		ApolloBuglyLogLevelV
	}
}
