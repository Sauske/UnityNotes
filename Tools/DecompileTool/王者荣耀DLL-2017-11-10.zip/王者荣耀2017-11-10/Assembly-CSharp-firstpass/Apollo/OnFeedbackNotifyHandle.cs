using System;

namespace Apollo
{
	public delegate void OnFeedbackNotifyHandle(int flag, string desc);
}
