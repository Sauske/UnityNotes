using System;

namespace Apollo
{
	public delegate void OnLocationGotNotifyHandle(ApolloLocation aRelation);
}
