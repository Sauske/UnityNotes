using System;

namespace Apollo
{
	public delegate void OnBindGroupNotifyHandle(ApolloGroupResult groupRet);
}
