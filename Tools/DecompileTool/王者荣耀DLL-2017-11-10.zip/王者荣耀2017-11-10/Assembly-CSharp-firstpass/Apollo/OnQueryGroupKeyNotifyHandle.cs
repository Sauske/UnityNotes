using System;

namespace Apollo
{
	public delegate void OnQueryGroupKeyNotifyHandle(ApolloGroupResult groupRet);
}
