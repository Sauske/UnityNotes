using System;

namespace Apollo
{
	public enum ApolloWxMessageType
	{
		WxMessageType_Text,
		WxMessageType_Image,
		WxMessageType_Video,
		WxMessageType_Link
	}
}
