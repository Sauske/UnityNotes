using System;

namespace Apollo
{
	internal delegate void UnitySendMessageDelegate(IntPtr obj, IntPtr method, IntPtr msg);
}
