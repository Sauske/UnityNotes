using System;

namespace Apollo
{
	public enum ApolloEncryptMethod
	{
		None,
		Tea,
		QQ,
		Aes,
		Aes2
	}
}
