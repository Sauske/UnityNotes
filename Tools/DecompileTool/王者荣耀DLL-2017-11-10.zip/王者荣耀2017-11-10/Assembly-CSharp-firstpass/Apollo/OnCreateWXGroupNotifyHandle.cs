using System;

namespace Apollo
{
	public delegate void OnCreateWXGroupNotifyHandle(ApolloGroupResult groupRet);
}
