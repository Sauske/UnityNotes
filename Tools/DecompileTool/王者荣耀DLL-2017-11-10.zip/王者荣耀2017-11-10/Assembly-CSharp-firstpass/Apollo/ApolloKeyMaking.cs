using System;

namespace Apollo
{
	public enum ApolloKeyMaking
	{
		None,
		Auth,
		Server,
		RawDH,
		EncDH
	}
}
