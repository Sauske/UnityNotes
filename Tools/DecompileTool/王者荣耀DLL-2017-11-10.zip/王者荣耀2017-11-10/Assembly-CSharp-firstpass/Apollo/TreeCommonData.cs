using System;

namespace Apollo
{
	public struct TreeCommonData
	{
		public int ispCode;

		public int provinceCode;
	}
}
