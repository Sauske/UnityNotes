using System;

namespace Apollo
{
	public delegate void AccountLoginHandle(ApolloResult result, ApolloAccountInfo accountInfo);
}
