using System;

namespace Apollo
{
	public delegate void RawMessageHandler(RawMessageEventArgs args);
}
