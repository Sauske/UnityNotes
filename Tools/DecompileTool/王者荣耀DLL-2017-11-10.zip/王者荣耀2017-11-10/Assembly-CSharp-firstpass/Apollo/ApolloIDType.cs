using System;

namespace Apollo
{
	public enum ApolloIDType
	{
		IDCards,
		HKMacaoPass,
		HKMacaoTaiwanID,
		PassPort,
		PoliceCertificate
	}
}
