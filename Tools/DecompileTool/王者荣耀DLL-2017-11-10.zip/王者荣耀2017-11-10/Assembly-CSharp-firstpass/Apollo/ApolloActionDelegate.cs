using System;

namespace Apollo
{
	public delegate void ApolloActionDelegate(ApolloResult result, ApolloActionBufferBase action);
}
