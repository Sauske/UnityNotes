using System;

namespace Apollo
{
	internal class ApolloServiceManager
	{
	}
}
