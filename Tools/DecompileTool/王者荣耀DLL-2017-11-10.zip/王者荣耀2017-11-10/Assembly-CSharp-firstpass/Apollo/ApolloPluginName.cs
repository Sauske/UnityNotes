using System;

namespace Apollo
{
	public class ApolloPluginName
	{
		public const string WTLogin = "WTLogin";

		public const string Default = "MSDK";

		public const string Msdk = "MSDK";

		public const string Platform91 = "91";

		public const string _360 = "360";

		public const string UC = "UC";

		public const string Netmarble = "Netmarble";
	}
}
