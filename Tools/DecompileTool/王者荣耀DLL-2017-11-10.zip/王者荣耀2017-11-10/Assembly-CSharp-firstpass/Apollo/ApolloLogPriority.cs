using System;

namespace Apollo
{
	public enum ApolloLogPriority
	{
		Debug,
		Info,
		Warning,
		Event,
		Error,
		None
	}
}
