using System;

namespace Apollo
{
	public delegate void OnApolloPaySvrEvenHandle(ApolloBufferBase payResponseInfo);
}
