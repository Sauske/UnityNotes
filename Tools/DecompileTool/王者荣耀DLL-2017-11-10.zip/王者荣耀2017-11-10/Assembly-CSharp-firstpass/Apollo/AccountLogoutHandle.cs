using System;

namespace Apollo
{
	public delegate void AccountLogoutHandle(ApolloResult result);
}
