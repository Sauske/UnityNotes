using System;

namespace Apollo
{
	public delegate void OnRelationNotifyHandle(ApolloRelation aRelation);
}
