using System;

namespace Apollo
{
	public class Pay4MPMallInfo : PayInfo
	{
		public Pay4MPMallInfo()
		{
			this.Name = 1;
			base.Action = 4;
		}
	}
}
