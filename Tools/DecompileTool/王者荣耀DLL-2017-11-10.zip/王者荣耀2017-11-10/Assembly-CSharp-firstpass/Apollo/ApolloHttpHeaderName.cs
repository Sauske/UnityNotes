using System;

namespace Apollo
{
	internal class ApolloHttpHeaderName
	{
		public const string APOLLO_SERVER_IP = "apollo-server-ip";
	}
}
