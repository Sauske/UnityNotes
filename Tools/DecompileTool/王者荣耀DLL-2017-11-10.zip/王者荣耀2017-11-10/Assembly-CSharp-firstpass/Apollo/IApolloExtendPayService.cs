using System;

namespace Apollo
{
	public interface IApolloExtendPayService : IApolloExtendPayServiceBase
	{
	}
}
