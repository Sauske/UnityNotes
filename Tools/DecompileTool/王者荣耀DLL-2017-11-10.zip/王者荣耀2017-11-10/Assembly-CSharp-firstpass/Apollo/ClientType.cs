using System;

namespace Apollo
{
	public enum ClientType
	{
		None,
		Android,
		IOS,
		PC
	}
}
