using System;

namespace Apollo
{
	public delegate void ApolloQuickLoginNotify(ApolloWakeupInfo wakeupInfo);
}
