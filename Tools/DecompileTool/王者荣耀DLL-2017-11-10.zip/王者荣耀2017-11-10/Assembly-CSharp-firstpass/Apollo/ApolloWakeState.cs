using System;

namespace Apollo
{
	public enum ApolloWakeState
	{
		Success,
		NeedLogin,
		NeedSelectAccount
	}
}
