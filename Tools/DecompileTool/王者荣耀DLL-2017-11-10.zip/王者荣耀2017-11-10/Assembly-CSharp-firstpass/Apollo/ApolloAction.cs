using System;

namespace Apollo
{
	public class ApolloAction : ApolloActionBufferBase
	{
		public ApolloAction() : base(0)
		{
		}

		public override void WriteTo(ApolloBufferWriter writer)
		{
		}

		public override void ReadFrom(ApolloBufferReader reader)
		{
		}
	}
}
