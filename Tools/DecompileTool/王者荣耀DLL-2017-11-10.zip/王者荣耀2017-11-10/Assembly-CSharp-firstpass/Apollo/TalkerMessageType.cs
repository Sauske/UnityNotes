using System;

namespace Apollo
{
	internal enum TalkerMessageType
	{
		Notice,
		Request,
		Response
	}
}
