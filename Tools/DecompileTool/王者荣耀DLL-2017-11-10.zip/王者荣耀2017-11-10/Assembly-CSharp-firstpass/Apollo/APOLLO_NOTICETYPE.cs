using System;

namespace Apollo
{
	public enum APOLLO_NOTICETYPE
	{
		APO_NOTICETYPE_ALERT,
		APO_NOTICETYPE_SCROLL,
		APO_NOTICETYPE_ALL
	}
}
