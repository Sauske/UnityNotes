using System;

namespace Apollo
{
	internal delegate void ApolloLogDelegate(ApolloLogPriority pri, IntPtr msg);
}
