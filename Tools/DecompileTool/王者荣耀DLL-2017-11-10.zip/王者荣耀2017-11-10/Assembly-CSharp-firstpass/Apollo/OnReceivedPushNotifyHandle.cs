using System;

namespace Apollo
{
	public delegate void OnReceivedPushNotifyHandle(string alertDesc);
}
