using System;

namespace Apollo
{
	public delegate void ApolloLogHandler(ApolloLogPriority pri, string msg);
}
