using System;

namespace Apollo
{
	public delegate void OnQueryGroupInfoNotifyHandle(ApolloGroupResult groupRet);
}
