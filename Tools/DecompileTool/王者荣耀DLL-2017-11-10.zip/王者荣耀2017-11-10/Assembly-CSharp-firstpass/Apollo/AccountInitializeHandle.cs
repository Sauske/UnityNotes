using System;

namespace Apollo
{
	public delegate void AccountInitializeHandle(ApolloResult result, ApolloBufferBase initInfo);
}
