using System;

namespace Apollo
{
	public delegate void RouteChangedEventHandler(ulong serverId);
}
