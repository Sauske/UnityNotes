using System;

namespace Apollo
{
	public enum SvrFlag
	{
		NoFlag,
		New,
		Recommend,
		Hot
	}
}
