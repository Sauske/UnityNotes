using System;

namespace Apollo
{
	internal delegate void TXPerformSelectorDelegate(IntPtr selector);
}
