using System;

namespace Apollo
{
	public delegate void OnLocationNotifyHandle(ApolloRelation aRelation);
}
