using System;

namespace Apollo
{
	public delegate void ConnectorErrorEventHandler(ApolloResult result);
}
