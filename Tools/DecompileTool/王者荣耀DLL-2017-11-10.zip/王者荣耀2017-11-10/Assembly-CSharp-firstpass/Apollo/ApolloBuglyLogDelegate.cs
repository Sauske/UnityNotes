using System;
using UnityEngine;

namespace Apollo
{
	public delegate void ApolloBuglyLogDelegate(string condition, string stackTrace, LogType type);
}
