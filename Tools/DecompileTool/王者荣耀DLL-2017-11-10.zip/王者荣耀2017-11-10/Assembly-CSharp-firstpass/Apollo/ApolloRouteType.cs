using System;

namespace Apollo
{
	public enum ApolloRouteType
	{
		None,
		Zone,
		Server
	}
}
