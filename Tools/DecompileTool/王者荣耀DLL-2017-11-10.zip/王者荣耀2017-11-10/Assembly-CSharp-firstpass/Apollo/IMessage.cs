using System;

namespace Apollo
{
	public interface IMessage : IMessageRequest, IMessageResponse
	{
	}
}
