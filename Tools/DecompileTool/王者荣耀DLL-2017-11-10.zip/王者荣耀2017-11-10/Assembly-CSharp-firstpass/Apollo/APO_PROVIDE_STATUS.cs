using System;

namespace Apollo
{
	public enum APO_PROVIDE_STATUS
	{
		APO_PAYPROVIDESTATE_UNKOWN = -1,
		APO_PAYPROVIDESTATE_SUCC
	}
}
