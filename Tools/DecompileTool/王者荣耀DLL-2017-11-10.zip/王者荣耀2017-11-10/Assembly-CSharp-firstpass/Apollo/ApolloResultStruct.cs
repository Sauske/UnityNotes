using System;

namespace Apollo
{
	internal struct ApolloResultStruct
	{
		public ApolloResult result;
	}
}
