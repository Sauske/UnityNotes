using System;

namespace Apollo
{
	public enum ApolloWxButtonType
	{
		WxButtonType_Rank,
		WxButtonType_App,
		WxButtonType_Web
	}
}
