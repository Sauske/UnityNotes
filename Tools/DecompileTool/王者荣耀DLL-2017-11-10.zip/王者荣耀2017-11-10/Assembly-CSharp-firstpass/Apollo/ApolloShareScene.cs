using System;

namespace Apollo
{
	public enum ApolloShareScene
	{
		Session,
		TimeLine,
		QZone = 1,
		QSession
	}
}
