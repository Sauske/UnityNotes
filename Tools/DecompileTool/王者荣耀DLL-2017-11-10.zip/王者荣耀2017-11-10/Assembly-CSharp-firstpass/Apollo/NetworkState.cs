using System;

namespace Apollo
{
	public enum NetworkState
	{
		NotReachable,
		ReachableViaWWAN,
		ReachableViaWiFi
	}
}
