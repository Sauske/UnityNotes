using System;

namespace Apollo
{
	public delegate void OnJoinWXGroupNotifyHandle(ApolloGroupResult groupRet);
}
