using System;

namespace Apollo
{
	public delegate void ConnectEventHandler(ApolloResult result, ApolloLoginInfo loginInfo);
}
