using System;

namespace Apollo
{
	public enum ApolloServiceTypeBase
	{
		Account
	}
}
