using System;

namespace Apollo
{
	public class ServiceType
	{
		public const int Account = 0;

		public const int Pay = 2;

		public const int Tss = 1000;

		public const int Network = 1001;
	}
}
