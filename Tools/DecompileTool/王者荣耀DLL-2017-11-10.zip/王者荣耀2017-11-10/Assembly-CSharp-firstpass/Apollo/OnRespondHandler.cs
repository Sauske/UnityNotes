using System;

namespace Apollo
{
	public delegate void OnRespondHandler(IApolloHttpResponse rsp, ApolloResult rst);
}
