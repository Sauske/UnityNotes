using System;

namespace Apollo
{
	public delegate void RefreshAccessTokenHandler(ApolloResult result, ListView<ApolloToken> tokenList);
}
