using System;

namespace Apollo
{
	public enum APO_PAY_MP_STATUS
	{
		APO_PAY_MP_STATUS_SUCC,
		APO_PAY_MP_STATUS_ERR,
		APO_PAY_MP_STATUS_STOP
	}
}
