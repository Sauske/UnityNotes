using System;

namespace CSProtocol
{
	public enum CCSYNC_TYPE_DEF
	{
		CCSYNC_TYPE_COMMON = 1
	}
}
