using System;

namespace CSProtocol
{
	public enum ACNT_BANNED_REASON
	{
		ACNT_BANNED_REASON_NONE,
		ACNT_BANNED_REASON_IDIP
	}
}
