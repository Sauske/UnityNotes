using System;

namespace CSProtocol
{
	public enum ACCEPT_AIPLAYER_RSP
	{
		ACCEPT_AIPLAYER_NO,
		ACCEPT_AIPLAEYR_YES
	}
}
