using System;

namespace CSProtocol
{
	public enum ADD_FRIEND_OPTYPE
	{
		ADD_FRIEND_SELF = 1,
		ADD_FRIEND_PEER
	}
}
