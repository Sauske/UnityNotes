using System;

namespace Assets.Scripts.Common
{
	public enum enFindSymbolWearPosCode
	{
		FindNone = -1,
		FindSuccess,
		FindSymbolPosFull,
		FindSymbolNotOpen,
		FindSymbolLevelLimit
	}
}
