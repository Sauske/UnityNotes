using System;

namespace Assets.Scripts.Common
{
	public enum HeroAdvanceCode
	{
		AdvanceSuccess,
		LevelLimit,
		CoinNotEnough,
		MaterialNotEnough,
		HeroNotOwn,
		HeroMaxQuality
	}
}
