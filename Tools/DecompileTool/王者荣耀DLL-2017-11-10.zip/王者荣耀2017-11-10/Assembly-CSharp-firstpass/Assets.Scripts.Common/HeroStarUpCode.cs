using System;

namespace Assets.Scripts.Common
{
	public enum HeroStarUpCode
	{
		StarUpSuccess,
		HeroMaxStar,
		CoinNotEnough,
		FlagNotEnough,
		HeroNotOwn
	}
}
