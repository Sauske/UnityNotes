using System;

namespace Assets.Scripts.Common
{
	public enum SymbolBuyCode
	{
		BuySuccess,
		CoinNotEnough,
		DiamondNotEnough,
		PageFull
	}
}
