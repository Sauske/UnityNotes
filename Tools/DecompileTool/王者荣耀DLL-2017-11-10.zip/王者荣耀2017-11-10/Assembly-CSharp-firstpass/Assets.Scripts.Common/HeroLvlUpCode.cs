using System;

namespace Assets.Scripts.Common
{
	public enum HeroLvlUpCode
	{
		LvlUpSuccess,
		GradeLimit,
		RoleLevelLimit,
		ExpNotEnough,
		HeroNotOwn,
		MaxGradeMaxLevel
	}
}
