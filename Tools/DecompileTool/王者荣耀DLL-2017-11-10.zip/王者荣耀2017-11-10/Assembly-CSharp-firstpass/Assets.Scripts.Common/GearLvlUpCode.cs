using System;

namespace Assets.Scripts.Common
{
	public enum GearLvlUpCode
	{
		LvlUpSuccess,
		MaxGradeLevel,
		CoinNotEnough,
		GradeLimit,
		HeroLevelLimit
	}
}
