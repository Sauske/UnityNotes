using System;

namespace Assets.Scripts.Common
{
	public enum GearAdvanceCode
	{
		AdvanceSuccess,
		MaxGrade,
		CoinNotEnough,
		MaterialNotEnough,
		LevelLimit
	}
}
