using System;

namespace Assets.Scripts.Common
{
	public enum SymbolWearCode
	{
		WearSuccess,
		SymbolPosNotFind,
		SymbolLevelLimit,
		SymbolColorLimit,
		SymbolMaxLevelLimit
	}
}
