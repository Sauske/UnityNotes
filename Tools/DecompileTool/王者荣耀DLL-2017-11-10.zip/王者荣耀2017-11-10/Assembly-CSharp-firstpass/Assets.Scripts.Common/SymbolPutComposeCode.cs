using System;

namespace Assets.Scripts.Common
{
	public enum SymbolPutComposeCode
	{
		ComposeSuccess,
		SymbolLevelLimit,
		SymbolElementFull,
		SymbolCompMaxLevel
	}
}
