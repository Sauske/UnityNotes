using System;

namespace Assets.Scripts.Common
{
	public enum SymbolComposeCode
	{
		ComposeSuccess,
		CountNotEnough,
		CoinNotEnough
	}
}
