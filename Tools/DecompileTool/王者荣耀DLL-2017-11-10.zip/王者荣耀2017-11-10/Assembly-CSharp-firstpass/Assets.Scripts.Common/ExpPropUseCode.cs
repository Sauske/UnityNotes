using System;

namespace Assets.Scripts.Common
{
	public enum ExpPropUseCode
	{
		ExpPropUseSuccess,
		PropNotEnough,
		HeroMaxLevel,
		HeroNotOwn
	}
}
