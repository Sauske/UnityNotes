using System;

namespace Assets.Scripts.Common
{
	public enum SkillLevelUpCode
	{
		LevelUpSuccess,
		CoinNotEnough,
		SkillMaxLevel,
		SkillPointNotEnought,
		SkillLock,
		HeroNotOwn,
		FuncLocked
	}
}
