using System;
using UnityEngine;

public class CBinaryObject : ScriptableObject
{
	public byte[] m_data;
}
