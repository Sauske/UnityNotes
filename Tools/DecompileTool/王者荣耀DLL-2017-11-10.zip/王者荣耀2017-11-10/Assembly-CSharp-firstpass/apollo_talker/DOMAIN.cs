using System;

namespace apollo_talker
{
	public enum DOMAIN
	{
		DOMAIN_APP = 1,
		DOMAIN_TSS = 255
	}
}
