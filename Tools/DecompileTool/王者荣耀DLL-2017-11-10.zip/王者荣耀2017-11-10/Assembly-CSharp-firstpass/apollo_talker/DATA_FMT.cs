using System;

namespace apollo_talker
{
	public enum DATA_FMT
	{
		DATA_FMT_MSG,
		DATA_FMT_BIN = 16
	}
}
