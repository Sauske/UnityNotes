using System;

namespace apollo_talker
{
	public enum DATA_TYPE
	{
		DATA_TYPE_NOTICE,
		DATA_TYPE_REQUEST,
		DATA_TYPE_RESPONSE
	}
}
