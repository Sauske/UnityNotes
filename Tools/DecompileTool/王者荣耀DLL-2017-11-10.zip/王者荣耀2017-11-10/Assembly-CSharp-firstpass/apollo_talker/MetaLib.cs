using System;

namespace apollo_talker
{
	public class MetaLib
	{
		public static string getName()
		{
			return "apollo_talker";
		}

		public static string getMd5Sum()
		{
			return "f46b846d24edfe687af8c10888312dbe";
		}

		public static string getTdrVersion()
		{
			return "2.7.4, build at 20150114";
		}
	}
}
