using System;

namespace apollo_talker
{
	public enum CMD_FMT
	{
		CMD_FMT_NIL,
		CMD_FMT_STR,
		CMD_FMT_INT
	}
}
