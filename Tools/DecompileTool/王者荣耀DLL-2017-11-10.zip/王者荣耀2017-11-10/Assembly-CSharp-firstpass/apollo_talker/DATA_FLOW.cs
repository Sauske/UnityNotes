using System;

namespace apollo_talker
{
	public enum DATA_FLOW
	{
		DATA_FLOW_UP,
		DATA_FLOW_DOWN = 8
	}
}
