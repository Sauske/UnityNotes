using System;

namespace apollo_tss
{
	public class MetaLib
	{
		public static string getName()
		{
			return "apollo_tss";
		}

		public static string getMd5Sum()
		{
			return "c399044537ee5db64519e52131b7baee";
		}

		public static string getTdrVersion()
		{
			return "2.7.4, build at 20150114";
		}
	}
}
