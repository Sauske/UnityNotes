using System;

namespace apollo_tss
{
	public class apollo_tssMacros
	{
		public const int APOLLO_TSS_MAX_MSG_SIZE = 65535;
	}
}
