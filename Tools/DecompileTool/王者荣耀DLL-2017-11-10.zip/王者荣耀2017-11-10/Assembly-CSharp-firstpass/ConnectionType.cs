using System;

public enum ConnectionType
{
	Connection,
	ModifyNode
}
