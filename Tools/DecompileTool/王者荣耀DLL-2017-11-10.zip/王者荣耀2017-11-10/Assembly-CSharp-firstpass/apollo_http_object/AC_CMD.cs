using System;

namespace apollo_http_object
{
	public enum AC_CMD
	{
		AC_CMD_HTTP_REQ = 257,
		AC_CMD_HTTP_RSP
	}
}
