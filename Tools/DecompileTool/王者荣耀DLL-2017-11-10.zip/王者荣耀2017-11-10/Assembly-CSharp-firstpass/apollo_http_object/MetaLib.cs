using System;

namespace apollo_http_object
{
	public class MetaLib
	{
		public static string getName()
		{
			return "apollo_http_object";
		}

		public static string getMd5Sum()
		{
			return "c4de21d9ee4a57abe61a28b22ff1b6ff";
		}

		public static string getTdrVersion()
		{
			return "2.7.3, build at 20141126";
		}
	}
}
