using System;

public class AutoRegisterAttribute : Attribute
{
}
