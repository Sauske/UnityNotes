using System;

public class CCoroutineYieldBase
{
}
