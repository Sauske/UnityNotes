#include "UnityPrefix.h"

#if SUPPORT_APPLICATION_SUSPENSION

#include "ApplicationSuspender.h"

#include "Runtime/Application/ApplicationSuspender.h"
#include "Runtime/Threads/AtomicQueue.h"


static RuntimeStatic<ApplicationSuspender> g_ApplicationSuspender(kMemPermanent, "Manager", "ApplicationSuspender", RuntimeStatic<ApplicationSuspender>::kManual);

ApplicationSuspender& ApplicationSuspender::GetInstance()
{
    return *(g_ApplicationSuspender.EnsureInitialized());
}

ApplicationSuspender::ApplicationSuspender()
    : m_Suspended(0)
    , m_UserNotified(false)
    , m_SuspendTimeOut(FLT_MAX)
{
}

void ApplicationSuspender::Initialize()
{
    GlobalCallbacks::Get().suspendPointHook.Register(&SuspendPointHook);
}

void ApplicationSuspender::CleanUp()
{
    GlobalCallbacks::Get().suspendPointHook.Unregister(&SuspendPointHook);
}

void ApplicationSuspender::Suspend()
{
    m_SuspendStartTime = GetProfilerTime();
    atomic_store_explicit(&m_Suspended, 1, memory_order_release);
}

void ApplicationSuspender::Resume()
{
    atomic_store_explicit(&m_Suspended, 0, memory_order_release);
}

void ApplicationSuspender::SuspendPoint(bool midLoad)
{
    //Quick check if we are to suspend
    atomic_word suspendValue = atomic_load_explicit(&m_Suspended, memory_order_acquire);
    if (suspendValue > 0)
    {
        //If the platform has provided us a callback to user code and we haven't notified them yet, if we are on
        //the main thread we should notify the user from here.
        if (Thread::CurrentThreadIsMainThread() && !m_UserNotified && m_UserNotificationCallback != NULL)
        {
            m_UserNotified = true;
            m_UserNotificationCallback(midLoad);
        }

        float elapsedTime = GetElapsedTimeInSeconds(m_SuspendStartTime);

        //If the platform doesn't require us to notify the user, or if we have but they have no callback to check if the user
        //is ready for the suspension to happen, or finally if the suspend timeout has been reached then continue with the suspension,
        // otherwise drop out this suspension point and we will check again at the next one
        if (m_UserNotificationCallback == NULL || m_IsUserReadyForSuspension == NULL || m_IsUserReadyForSuspension() || elapsedTime > m_SuspendTimeOut)
        {
            //If current suspend point is being called on the main thread we are now definitely suspending so if there is one
            //call the final suspend callback
            if (Thread::CurrentThreadIsMainThread() && m_SuspendCallback != NULL)
            {
                m_SuspendCallback(midLoad);
            }

#if !MASTER_BUILD
            if (Thread::CurrentThreadIsMainThread() && elapsedTime > m_SuspendTimeOut)
            {
                printf_console("++++++++++++++++ [ WARNING ] +++++++++++++++++++\n");
                printf_console("+                                              \n");
                printf_console("+    POTENTIAL SUSPEND TIME VIOLATION          \n");
                printf_console("+    Suspend watchdog indicates you took:      \n");
                printf_console("+        [ %f ] seconds to suspend             \n", elapsedTime);
                printf_console("+                                              \n");
                printf_console("++++++++++++++++ [ WARNING ] +++++++++++++++++++\n");
            }
#endif

            //internal spin till the suspend is over
            suspendValue = atomic_load_explicit(&m_Suspended, memory_order_acquire);
            while (suspendValue > 0)
            {
                AtomicList::Relax();
                suspendValue = atomic_load_explicit(&m_Suspended, memory_order_acquire);
            }

            //The suspend is finished, so if we are the main thread and there is a resume callback, call it
            //Then reset for a potential new suspend
            if (Thread::CurrentThreadIsMainThread() && m_ResumeCallback != NULL)
            {
                m_ResumeCallback(midLoad);
            }
            m_UserNotified = false;
        }
    }
}

#endif //SUPPORT_APPLICATION_SUSPENSION
