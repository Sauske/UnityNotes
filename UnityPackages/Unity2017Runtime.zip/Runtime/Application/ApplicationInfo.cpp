#include "UnityPrefix.h"
#include "Runtime/Application/ApplicationInfo.h"
#include "Runtime/Misc/PlayerSettings.h"
#include "Runtime/Utilities/RuntimeStatic.h"

#if UNITY_EDITOR
#include "Editor/Src/EditorUserBuildSettings.h"
#endif

RuntimeStatic<ApplicationInfo> s_ApplicationInfo(kMemManager);

ApplicationInfo& GetApplicationInfo()
{
    return *s_ApplicationInfo;
}

#if (PLATFORM_ANDROID || PLATFORM_IPHONE || PLATFORM_TVOS || (PLATFORM_OSX && !UNITY_EDITOR))
// Handled in platform code
#else

#if !UNITY_TIZEN

core::string ApplicationInfo::GetApplicationIdentifier()
{
#if UNITY_EDITOR
    return GetPlayerSettings().GetEditorOnly().GetApplicationIdentifier(GetEditorUserBuildSettings().GetActiveBuildTargetGroup());
#else
    // bundleIdentifier was renamed to applicationIdentifier and moved from PlayerSettings to EditorOnlyPlayerSettings,
    // all platforms which use it implement ApplicationInfo::GetApplicationIdentifier in their custom ApplicationInfo file.
    return "";
#endif
}

#endif

core::string ApplicationInfo::GetVersion()
{
    return GetPlayerSettings().GetApplicationVersion();
}

core::string ApplicationInfo::GetInstallerName()
{
    return "";
}

ApplicationInfo::InstallMode ApplicationInfo::GetInstallMode()
{
#if UNITY_EDITOR
    return Editor;
#else
    return InstallModeUnknown;
#endif
}

ApplicationInfo::SandboxType ApplicationInfo::GetSandboxType()
{
#if UNITY_EDITOR
    return NotSandboxed;
#elif PLATFORM_METRO
    return Sandboxed;
#else
    return SandboxTypeUnknown;
#endif
}

#endif
