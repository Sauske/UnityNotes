#include "UnityPrefix.h"
#include "Runtime/Scripting/ScriptingExportUtility.h"
#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/ScriptingBackend/ScriptingApi.h"
#include "Runtime/Input/TimeManager.h"
#include "Runtime/Utilities/RuntimeStatic.h"
#include "Runtime/Application/AdsIdHandler.h"
#include "Runtime/Jobs/BackgroundJobQueue.h"
#include "Runtime/Testing/Faking.h"

static const int s_CachedValueTimeoutInSec = (2 * 60);

RuntimeStatic<AdsIdHandler> s_AdsIdHandler(kMemManager);

AdsIdHandler& GetAdsIdHandler()
{
    return *s_AdsIdHandler;
}

AdsIdHandler::AdsIdHandler()
    :  m_TrackingEnabled(false), m_Timestamp(0),
    m_IsCachedValueValid(false), m_AsyncAdsIdFetchJobStarted(false),
    m_State(kStateNotReady)
{}

bool AdsIdHandler::RequestAdsIdAsync(ScriptingObjectPtr doneDelegate)
{
    AddAdsIdDelegate(doneDelegate);
    if (FetchCachedAdsId())
        InvokeAllAdsIdDelegate();

    return (m_State != kStateError);
}

bool AdsIdHandler::RequestAdsIdAsync(IAdsIdListener& listener)
{
    AddAdsIdListeners(listener);
    if (FetchCachedAdsId())
        InvokeAllAdsIdListeners();

    return (m_State != kStateError);
}

bool AdsIdHandler::IsCachedAdsIdExpired()
{
    if (m_IsCachedValueValid)
    {
        float currentTimeStamp = GetTimeSinceStartup();
        if ((currentTimeStamp - m_Timestamp) > s_CachedValueTimeoutInSec)
            m_IsCachedValueValid = false;
    }
    return !m_IsCachedValueValid;
}

bool AdsIdHandler::FetchCachedAdsId()
{
    if (!IsCachedAdsIdExpired())
        return true;
    return FetchAdsId();
}

void AdsIdHandler::AddAdsIdDelegate(ScriptingObjectPtr doneDelegate)
{
    ScriptingGCHandle delegate(doneDelegate, GCHANDLE_STRONG);
    m_AdsIdDelegates.push_back(delegate);
}

void AdsIdHandler::AddAdsIdListeners(IAdsIdListener& listener)
{
    Mutex::AutoLock lock(m_AdsInfoMutex);
    m_AdsIdListeners.push_back(&listener);
}

void AdsIdHandler::InvokeAdsIdDoneDelegate(ScriptingGCHandle doneDelegate)
{
    ScriptingObjectPtr delegate = doneDelegate.Resolve();
    if (delegate != SCRIPTING_NULL)
    {
        ScriptingInvocation invokeMethod(delegate, "Invoke");
        invokeMethod.AddString(m_AdsId.c_str());
        invokeMethod.AddBoolean(m_TrackingEnabled);
        invokeMethod.AddString(m_ErrorMsg.c_str());
        ScriptingExceptionPtr exception = SCRIPTING_NULL;
        invokeMethod.Invoke(&exception);
        if (exception != SCRIPTING_NULL)
            Scripting::LogException(exception, InstanceID_None);
    }
}

void AdsIdHandler::InvokeAllAdsIdDelegate()
{
    AdsIdDelegates::iterator end = m_AdsIdDelegates.end();
    for (AdsIdDelegates::iterator it = m_AdsIdDelegates.begin(); it != end; it++)
    {
        InvokeAdsIdDoneDelegate(*it);
        it->ReleaseAndClear();
    }
    m_AdsIdDelegates.clear();
}

void AdsIdHandler::InvokeAllAdsIdListeners()
{
    Mutex::AutoLock lock(m_AdsInfoMutex);
    AdsIdListeners::iterator end = m_AdsIdListeners.end();
    for (AdsIdListeners::iterator it = m_AdsIdListeners.begin(); it != end; it++)
        (*it)->OnAdsIdRequestDone(m_AdsId, m_TrackingEnabled, m_ErrorMsg);

    m_AdsIdListeners.clear();
}

void AdsIdHandler::InvokeAllDelegateAndListeners()
{
    GetBackgroundJobQueue().ScheduleMainThreadJob(ExecuteOnMainThreadAdsIdJobDoneStatic, this);
    InvokeAllAdsIdListeners();
}

// JobQueue
void AdsIdHandler::ExecuteOnMainThreadAdsIdJobDoneStatic(AdsIdHandler* context)
{
    context->InvokeAllAdsIdDelegate();
}

void AdsIdHandler::ScheduleJobToFetchAsyncAdsId()
{
    m_AsyncAdsIdFetchJobStarted = true;
    GetBackgroundJobQueue().ScheduleJob(ExecuteAsyncFetchAdsIdJobStatic, this);
}

// JobQueue
void AdsIdHandler::ExecuteAsyncFetchAdsIdJobStatic(AdsIdHandler* context)
{
    context->ExecuteAsyncFetchAdsIdJob();
}

void AdsIdHandler::ExecuteAsyncFetchAdsIdJob()
{
    m_AsyncAdsIdFetchJobStarted = false;
    FetchAsyncAdsId();
    if (m_AdsId.empty())
        m_IsCachedValueValid = false;
    else
    {
        m_IsCachedValueValid = true;
        m_Timestamp = GetTimeSinceStartup();
        InvokeAllDelegateAndListeners();
    }
}

void AdsIdHandler::HandleAdsIdAsyncStatus(bool connected)
{
    Mutex::AutoLock lock(m_AdsInfoMutex);
    if (connected)
    {
        m_State = kStateConnected;
        ScheduleJobToFetchAsyncAdsId();
        return;
    }
    m_State = kStateNotReady;
}

void AdsIdHandler::SetStateError(core::string& errorMsg)
{
    m_State = kStateError;
    m_ErrorMsg = errorMsg;
}

void AdsIdHandler::SetCachedAdsId(const core::string& adsId, bool trackingEnabled)
{
    m_AdsId = adsId;
    m_TrackingEnabled = trackingEnabled;
}

#if defined(PLATFORM_SUPPORTS_ADS_ID)
// Handled in platform code
#else

bool AdsIdHandler::FetchAdsId()
{
    __FAKEABLE_METHOD__(AdsIdHandler, FetchAdsId, ());
    m_State = kStateError;
    return false;
}

void AdsIdHandler::FetchAsyncAdsId()
{
    __FAKEABLE_METHOD__(AdsIdHandler, FetchAsyncAdsId, ());
    m_State = kStateError;
}

#endif
