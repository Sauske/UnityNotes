#ifndef __APPLICATION_SUSPENDER_H
#define __APPLICATION_SUSPENDER_H

#if SUPPORT_APPLICATION_SUSPENSION

#include "Runtime/PluginInterface/PluginInterface.h"
#include "Runtime/Threads/Thread.h"
#include "Runtime/Utilities/Singleton.h"
#include "Runtime/Profiler/TimeHelper.h"

typedef void (UNITY_INTERFACE_API * UserSuspensionNotificationCallback)(bool midLoad);
typedef void (UNITY_INTERFACE_API * ApplicationSuspendCallback)(bool midLoad);
typedef void (UNITY_INTERFACE_API * ApplicationResumeCallback)(bool midLoad);

typedef bool (UNITY_INTERFACE_API * UserReadyForSuspendCallback)();

//The ApplicationSuspender is a singleton class designed to allow different platforms to flexibly control suspend states.
//It allows the platform to provide platform specific callbacks to add on top of the basic mechanic of suspending the game
//The ApplicationSuspender has two main ways of interacting with it.
//Suspend & Resume are the first which simply tell the ApplicationSuspender to start either suspending or resuming the app and can be called from any thread.
//SuspendPointHook is the other, this function is basically a hook to be added in to the code anywhere the game should check for for the suspended state.
//On most threads it will likely be only added in and called once a frame, though it could be added in to potential blocking areas of code such as loading,
//allowing the suspension to interrupt and stall the loading where it is safe to do so, making it more responsive. This can be called from any thread that needs suspending.
//
//A few points to be careful of, if you provide any callbacks you must be adding suspend hooks into the main thread. Also resume calls need to come from a
//thread that doesn't get suspended or the calls will never get made.

class ApplicationSuspender
{
public:
    ApplicationSuspender();

    void Suspend();
    void Resume();

    void Initialize();
    void CleanUp();

    void SetUserSuspensionNotificationCallback(UserSuspensionNotificationCallback userNotificationCallback) { m_UserNotificationCallback = userNotificationCallback; }

    void SetSuspendCallback(ApplicationSuspendCallback suspendCallback) { m_SuspendCallback = suspendCallback; }
    void SetResumeCallback(ApplicationResumeCallback resumeCallback) { m_ResumeCallback = resumeCallback; }

    void SetUserReadyToSuspendCallback(UserReadyForSuspendCallback userReadyCallback) { m_IsUserReadyForSuspension = userReadyCallback;  }

    void SetSuspendTimeOut(float suspendTimeOut) { m_SuspendTimeOut = suspendTimeOut;  }

    void SuspendPoint(bool midLoad);

    static ApplicationSuspender& GetInstance();

    static void SuspendPointHook(bool midLoad) { ApplicationSuspender::GetInstance().SuspendPoint(midLoad); }

private:
    UserSuspensionNotificationCallback m_UserNotificationCallback;

    ApplicationSuspendCallback m_SuspendCallback;
    ApplicationResumeCallback m_ResumeCallback;

    UserReadyForSuspendCallback m_IsUserReadyForSuspension;

    bool m_UserNotified;
    atomic_word m_Suspended;

    TimeFormat m_SuspendStartTime;
    float m_SuspendTimeOut;
};

#endif //SUPPORT_APPLICATION_SUSPENSION

#endif // __APPLICATION_SUSPENDER_H
