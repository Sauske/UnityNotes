#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS_WITH_FAKES

#include "Runtime/Application/AdsIdHandler.h"
#include "Runtime/Testing/Testing.h"
#include "Runtime/Testing/Faking.h"

UNIT_TEST_SUITE(AdsIdHandlerTests)
{
    struct FakeIAdsIdListener : public IAdsIdListener
    {
        void OnAdsIdRequestDone(const core::string& adsId, bool trackingEnabled, const core::string& errorMsg)
        {
            __FAKEABLE_METHOD__(FakeIAdsIdListener, OnAdsIdRequestDone, (adsId, trackingEnabled, errorMsg));
        }
    };

    struct Fixture
    {
        FAKE_METHOD(AdsIdHandler, FetchAdsId, bool());
        FAKE_METHOD(AdsIdHandler, FetchAsyncAdsId, void());

        FAKE_METHOD(FakeIAdsIdListener, OnAdsIdRequestDone, void(const core::string&, bool, const core::string&));

        bool m_FetchResponse;
        core::string m_FetchErrorMsg;
        core::string m_FetchAdsId;
        bool m_FetchAdsTracking;
        FakeIAdsIdListener m_FakeIAdsIdListener;
        AdsIdHandler m_AdsIdHandler;


        Fixture() :
            m_FetchResponse(false), m_FetchAdsTracking(false)
        {
            AdsIdHandler_FetchAdsId.Calls(this, &Fixture::FetchAdsId);
            ResetData();
        }

        bool FetchAdsId(AdsIdHandler* _this)
        {
            if (!m_FetchErrorMsg.empty())
                _this->SetStateError(m_FetchErrorMsg);
            else
                _this->SetCachedAdsId(m_FetchAdsId, m_FetchAdsTracking);
            return m_FetchResponse;
        }

        void ResetData()
        {
            m_FetchErrorMsg = "";
            m_FetchResponse = true;
            m_FetchAdsId = "FetchedAdsId";
            m_FetchAdsTracking = false;
        }

        bool RequestAdsIdAsync()
        {
            return m_AdsIdHandler.RequestAdsIdAsync(m_FakeIAdsIdListener);
        }
    };

    TEST_FIXTURE(Fixture, RequestAdsIdAsync_OnErrorResultIsFalse)
    {
        m_FetchErrorMsg = "FetchError";

        bool result = RequestAdsIdAsync();

        CHECK(!result);
    }

    TEST_FIXTURE(Fixture, RequestAdsIdAsync_OnSuccessResultIsTrue)
    {
        bool result = RequestAdsIdAsync();

        CHECK(result);
    }

    TEST_FIXTURE(Fixture, RequestAdsIdAsync_PassesTrackingStateAndAdsIdToHandle)
    {
        m_FetchAdsTracking = true;
        RequestAdsIdAsync();

        CHECK(FakeIAdsIdListener_OnAdsIdRequestDone.WasCalled());
        CHECK_EQUAL(m_FetchAdsId, FakeIAdsIdListener_OnAdsIdRequestDone.LastCallArguments().a1.Get());
        CHECK(FakeIAdsIdListener_OnAdsIdRequestDone.LastCallArguments().a2.Get());
    }
}

#endif
