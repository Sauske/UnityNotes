#pragma once

#include "Runtime/Camera/RenderLoops/GlobalLayeringData.h"
#include "Runtime/Geometry/AABB.h"
#include "Runtime/Utilities/HashFunctions.h"

class Renderer;
class SortingGroup;
namespace Unity
{ class Component; }

struct SortingGroupData
{
    AABB aabb;
    UInt32 layerAndOrder;

    SortingGroupData() {}
    SortingGroupData(AABB otherAabb, UInt32 otherLayerAndOrder)
        : aabb(otherAabb)
        , layerAndOrder(otherLayerAndOrder)
    {
    }
};
typedef dynamic_array<SortingGroupData> SortingGroupDataArray;

SortingGroup* FindEnabledAncestorSortingGroup(Unity::Component* component);
void UpdateSortingGroupStatus(SortingGroup* sortingGroup);
void UpdateSortingGroupStatusForRenderer(Renderer* renderer);
void ClearSortingGroupStatusForRenderer(Renderer* renderer);
void UpdateParentSortingGroupRecursive(SortingGroup* sortingGroup);
