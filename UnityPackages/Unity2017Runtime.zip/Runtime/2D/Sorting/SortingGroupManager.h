#pragma once

#include "Configuration/UnityConfigure.h"
#include "Runtime/2D/Sorting/SortingGroup.h"
#include "Runtime/2D/Sorting/SortingGroupUtils.h"

class SortingGroupManager
{
public:
    SortingGroupManager();
    ~SortingGroupManager();

    void Update();

    void AddSortingGroup(SortingGroup* sortingGroup);
    void RemoveSortingGroup(SortingGroup* sortingGroup);
    void NeedsSorting(ListNode<SortingGroup>& sortingGroupNode);
    void SetSortingGroupNeedsSorting(UInt32 sortingGroupIdx);

    void CopyTo(SortingGroupDataArray& dest);

private:
    typedef dynamic_array<SortingGroup*> CachedSortingGroupArray;

    CachedSortingGroupArray m_SortingGroups;
    SortingGroupDataArray m_DataArray;

    typedef List<ListNode<SortingGroup> > SortingGroupList;
    SortingGroupList m_SortingGroupList;
};

void InitializeSortingGroupManager();
void CleanupSortingGroupManager();
SortingGroupManager& GetSortingGroupManager();
