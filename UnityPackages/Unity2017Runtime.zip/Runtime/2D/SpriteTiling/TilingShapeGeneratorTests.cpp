#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "Runtime/Testing/TestFixtures.h"
#include "Runtime/Testing/Testing.h"
#include "Runtime/2D/SpriteTiling/TilingShapeGenerator.h"
#include "Runtime/Geometry/Polygon2D.h"
#include "Runtime/Jobs/JobTypes.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Testing/ParametricTest.h"

#include "Runtime/2D/SpriteTiling/TilingShapeGeneratorTests_ExpectedData.inc.h"

struct GenerateTilingAreaInfo;
void PrepareTilingSegment(const SpriteTilingProperty&property, const Polygon2D&originalPath, Polygon2D(&tileSegment)[9]);
void GenerateTilingAreaJob(GenerateTilingAreaInfo *data, unsigned index);

UNIT_TEST_SUITE(TilingShapeGenerator)
{
    struct PrepareTilingSegmentTestData
    {
        SpriteTilingProperty tilingProperty;
        int expectedCount[9];
        Polygon2D path;
    };

    void PrepareTilingSegmentGroupDataCases(Testing::TestCaseEmitter<PrepareTilingSegmentTestData>& testCase)
    {
        SpriteTilingProperty tilingProperty(
            Vector4f(1, 1, 1, 1), Vector2f::zero, Vector2f::one * 3, Vector2f::one * 3, kSpriteDrawModeSimple, false, 0
            );
        {
            PrepareTilingSegmentTestData testData =
            {
                tilingProperty,
                {4, 0, 0, 0, 0, 0, 0, 0, 0},
                Polygon2D().Default()
            };
            Vector2f path[4] = {Vector2f(0.1f, 0.1f), Vector2f(0.1f, 0.9f), Vector2f(0.9f, 0.9f), Vector2f(0.9f, 0.1f)};
            testData.path.GetPath(0).assign(&path[0], &path[4]);
            testCase.WithName("VerifyPathInSegment0_GroupedCorrectly").WithValues(testData);
        }

        {
            PrepareTilingSegmentTestData testData =
            {
                tilingProperty,
                {0, 0, 0, 0, 4, 0, 0, 0, 0},
                Polygon2D().Default()
            };
            Vector2f path[4] = {Vector2f(1.1f, 1.1f), Vector2f(1.1f, 1.9f), Vector2f(1.9f, 1.9f), Vector2f(1.9f, 1.1f)};
            testData.path.GetPath(0).assign(&path[0], &path[4]);
            testCase.WithName("VerifyPathInSegment5_GroupedCorrectly").WithValues(testData);
        }

        {
            PrepareTilingSegmentTestData testData =
            {
                tilingProperty,
                {4, 4, 4, 4, 4, 4, 4, 4, 4},
                Polygon2D().Default()
            };
            Vector2f path[4] = {Vector2f(0, 0), Vector2f(0, 3), Vector2f(3, 3), Vector2f(3, 0)};
            testData.path.GetPath(0).assign(&path[0], &path[4]);
            testCase.WithName("VerifyPathInMultipleSegments_GroupedCorrectly").WithValues(testData);
        }
    }

    PARAMETRIC_TEST(PrepareTilingSegmentVerifyPathGroupedCorrectly, (const PrepareTilingSegmentTestData testData), PrepareTilingSegmentGroupDataCases)
    {
        Polygon2D results[9];
        for (int i = 0; i < 9; ++i)
            results[i].Clear();
        PrepareTilingSegment(testData.tilingProperty, testData.path, results);
        for (int i = 0; i < 9; ++i)
        {
            CHECK_EQUAL(testData.expectedCount[i], results[i].GetTotalPointCount());
        }
    }

    struct GenerateTilingShapeTestData
    {
        SpriteTilingProperty tilingProperty;
        const Vector2f* path;
        size_t pathPointCount;
        const float* expectedData;
        size_t expectedPointCount;
    };

    void GenerateTilingShapeGenerationDataCases(Testing::TestCaseEmitter<GenerateTilingShapeTestData>& testCase)
    {
        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.0f, 0.0f, 0.0f, 0.0f), Vector2f::zero, Vector2f::one, Vector2f::one * 5, kSpriteDrawModeTiled, false, 0.5f),
                kGenerateTilingShape_WithNoBorderTileModeSize5_PathInsideSprite_PathData,
                sizeof(kGenerateTilingShape_WithNoBorderTileModeSize5_PathInsideSprite_PathData) / sizeof(*kGenerateTilingShape_WithNoBorderTileModeSize5_PathInsideSprite_PathData),
                kGenerateTilingShape_WithNoBorderTileModeSize5_PathInsideSprite_ExpectedData,
                sizeof(kGenerateTilingShape_WithNoBorderTileModeSize5_PathInsideSprite_ExpectedData) / sizeof(*kGenerateTilingShape_WithNoBorderTileModeSize5_PathInsideSprite_ExpectedData)
            };
            testCase.WithName("VerifyNoBorderTileModeSize5_PathInsideSprite").WithValues(testData);
        }

        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.0f, 0.0f, 0.0f, 0.0f), Vector2f::zero, Vector2f::one, Vector2f::one, kSpriteDrawModeTiled, false, 0.5f),
                kGenerateTilingShape_WithNoBorderTileMode_PathOutSideSprite_PathData,
                sizeof(kGenerateTilingShape_WithNoBorderTileMode_PathOutSideSprite_PathData) / sizeof(*kGenerateTilingShape_WithNoBorderTileMode_PathOutSideSprite_PathData),
                kGenerateTilingShape_WithNoBorderTileMode_PathOutSideSprite_ExpectedData,
                sizeof(kGenerateTilingShape_WithNoBorderTileMode_PathOutSideSprite_ExpectedData) / sizeof(*kGenerateTilingShape_WithNoBorderTileMode_PathOutSideSprite_ExpectedData)
            };
            testCase.WithName("VerifyNoBorderTileMode_PathOutsideSprite").WithValues(testData);
        }

        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.0f, 0.0f, 0.0f, 0.0f), Vector2f::zero, Vector2f::one, Vector2f::one, kSpriteDrawModeTiled, false, 0.5f),
                kGenerateTilingShape_WithNoBorderTileMode_PathData,
                sizeof(kGenerateTilingShape_WithNoBorderTileMode_PathData) / sizeof(*kGenerateTilingShape_WithNoBorderTileMode_PathData),
                kGenerateTilingShape_WithNoBorderTileMode_ExpectedData,
                sizeof(kGenerateTilingShape_WithNoBorderTileMode_ExpectedData) / sizeof(*kGenerateTilingShape_WithNoBorderTileMode_ExpectedData)
            };
            testCase.WithName("VerifyNoBorderTileMode").WithValues(testData);
        }

        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.97f, 1.0f, 1.0f, 1.0f), Vector2f::one * 0.5f, Vector2f::one * 3, Vector2f::one * 5, kSpriteDrawModeTiled, false, 0.5f),
                kGenerateTilingShape_WithBorderTileModeSize5_PathInMultipleTileSegment_PathData,
                sizeof(kGenerateTilingShape_WithBorderTileModeSize5_PathInMultipleTileSegment_PathData) / sizeof(*kGenerateTilingShape_WithBorderTileModeSize5_PathInMultipleTileSegment_PathData),
                kGenerateTilingShape_WithBorderTileModeSize5_PathInMultipleTileSegment_ExpectedData,
                sizeof(kGenerateTilingShape_WithBorderTileModeSize5_PathInMultipleTileSegment_ExpectedData) / sizeof(*kGenerateTilingShape_WithBorderTileModeSize5_PathInMultipleTileSegment_ExpectedData)
            };
            testCase.WithName("VerifyBorderTileModeSize5_PathInMultipleTileSegment").WithValues(testData);
        }

        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.97f, 1.0f, 1.0f, 1.0f), Vector2f::one * 0.5f, Vector2f::one * 3, Vector2f::one * 5, kSpriteDrawModeSliced, false, 0.5f),
                kGenerateTilingShape_WithBorderSliceModeSize5_PathInMultipleTileSegment_PathData,
                sizeof(kGenerateTilingShape_WithBorderSliceModeSize5_PathInMultipleTileSegment_PathData) / sizeof(*kGenerateTilingShape_WithBorderSliceModeSize5_PathInMultipleTileSegment_PathData),
                kGenerateTilingShape_WithBorderSliceModeSize5_PathInMultipleTileSegment_ExpectedData,
                sizeof(kGenerateTilingShape_WithBorderSliceModeSize5_PathInMultipleTileSegment_ExpectedData) / sizeof(*kGenerateTilingShape_WithBorderSliceModeSize5_PathInMultipleTileSegment_ExpectedData)
            };
            testCase.WithName("VerifyBorderSliceModeSize5_PathInMultipleTileSegment").WithValues(testData);
        }

        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.156250f, 0.181641f, 0.0f, 0.0f), Vector2f::zero, Vector2f::one, Vector2f::one * 5, kSpriteDrawModeTiled, false, 0.5f),
                kGenerateTilingShape_WithLeftBottomBorderOnlyTileModeSize5_PathData,
                sizeof(kGenerateTilingShape_WithLeftBottomBorderOnlyTileModeSize5_PathData) / sizeof(*kGenerateTilingShape_WithLeftBottomBorderOnlyTileModeSize5_PathData),
                kGenerateTilingShape_WithLeftBottomBorderOnlyTileModeSize5_ExpectedData,
                sizeof(kGenerateTilingShape_WithLeftBottomBorderOnlyTileModeSize5_ExpectedData) / sizeof(*kGenerateTilingShape_WithLeftBottomBorderOnlyTileModeSize5_ExpectedData)
            };
            testCase.WithName("VerifyLeftBottomBorderOnlyTileModeSize5").WithValues(testData);
        }

        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.156250f, 0.181641f, 0.0f, 0.0f), Vector2f::zero, Vector2f::one, Vector2f::one * 5, kSpriteDrawModeSliced, false, 0.5f),
                kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathData,
                sizeof(kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathData) / sizeof(*kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathData),
                kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_ExpectedData,
                sizeof(kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_ExpectedData) / sizeof(*kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_ExpectedData)
            };
            testCase.WithName("VerifyLeftBottomBorderOnlySliceModeSize5").WithValues(testData);
        }

        {
            GenerateTilingShapeTestData testData =
            {
                SpriteTilingProperty(Vector4f(0.156250f, 0.181641f, 0.0, 0.0), Vector2f::zero, Vector2f::one, Vector2f::one * 5, kSpriteDrawModeTiled, false, 0.5f),
                kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathOutsideSprite_PathData,
                sizeof(kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathOutsideSprite_PathData) / sizeof(*kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathOutsideSprite_PathData),
                kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathOutsideSprite_ExpectedData,
                sizeof(kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathOutsideSprite_ExpectedData) / sizeof(*kGenerateTilingShape_WithLeftBottomBorderOnlySliceModeSize5_PathOutsideSprite_ExpectedData)
            };
            testCase.WithName("VerifyLeftBottomBorderOnlySliceModeSize5_PathOutsideSprite").WithValues(testData);
        }
    }

    PARAMETRIC_TEST(GenerateTilingShapeVerifyGeneration, (const GenerateTilingShapeTestData testData), GenerateTilingShapeGenerationDataCases)
    {
        Polygon2D polygon2D;
        polygon2D.SetPoints(testData.path, testData.pathPointCount);
        Polygon2D result;
        JobFence fence;
        ScheduleGenerateTilingShape(fence, testData.tilingProperty, 0.0025f, 3, polygon2D, result);
        SyncFence(fence);

        int matched = 0;
        int totalPoints = 0;
        for (int i = 0; i < result.GetPathCount(); ++i)
        {
            const Polygon2D::TPath& t = result.GetPath(i);
            for (int j = 0; j < t.size(); ++j)
            {
                Vector2f v(testData.expectedData[totalPoints * 2], testData.expectedData[totalPoints * 2 + 1]);
                if (CompareApproximately(v, t[j]))
                    ++matched;

                ++totalPoints;
            }
        }
        CHECK_EQUAL(testData.expectedPointCount / 2, totalPoints);
        CHECK_EQUAL(testData.expectedPointCount / 2, matched);
    }
}


#endif // ENABLE_UNIT_TESTS
