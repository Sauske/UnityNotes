#include "UnityPrefix.h"
#include "Runtime/2D/SpriteTiling/SpriteTiling.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Math/Simd/vec-math.h"
#include "Runtime/Graphics/SpriteFrame.h"
#include "Runtime/Graphics/Mesh/SharedMeshData.h"
#include "Runtime/Graphics/SpriteUtility.h"

PROFILER_INFORMATION(gGet9SliceRenderDataJob, "Sprite.Get9SliceRenderDataJob", kProfilerRender);
PROFILER_INFORMATION(gGetSourceAndDestinationRect, "Sprite.GetSourceAndDestinationRect", kProfilerRender);
PROFILER_INFORMATION(gGetSpriteTileVertexAndIndexCount, "Sprite.GetSpriteTileVertexAndIndexCount", kProfilerRender);

static void Generate9SliceRenderDataJob(SpriteTilingJobData* jobData);
void GetSpriteTileVertexAndIndexCount(const math::float1& adaptiveTilingThreshold, const SpriteDrawMode drawMode, const bool adaptiveTiling, const NineSliceRectData rectData[9], const int rectDataCount, int& outIndexCount, int& outVertexCount);
void GenerateSpriteTileMesh(SpriteTilingJobData& jobData);

bool ScheduleSpriteTilingJob(JobFence& jobFence,
    SharedMeshData* spriteRenderData,
    const Vector2f spriteRendererSize,
    const SpriteDrawMode spriteRendererDrawMode,
    const bool adaptiveTiling,
    const float adaptiveTilingThreshold,
    const Sprite* sprite)
{
    using namespace math;

    float unitToPixel = 1.0f / sprite->GetPixelsToUnits();
    Vector2f spriteSize = sprite->GetSize();
    Vector4f uvs;

    float2 sizeP = vload2f(spriteSize.GetPtr());
    float4 spriteBordersInUnit = vload4f(sprite->GetBorder().GetPtr()) * unitToPixel;
    float2 spriteSizeInUnit = sizeP * unitToPixel;
    float2 startPoint = vload2f(sprite->GetPivotInPixels().GetPtr());
    float2 tileSize = vload2f(spriteRendererSize.GetPtr());
    // convert sprite pivot to 9 slice space
    startPoint = tileSize * -startPoint / sizeP;

    SpriteTilingJobData* jobData = UNITY_NEW(SpriteTilingJobData, kMemTempJobAlloc);
    {
        PROFILER_AUTO(gGetSourceAndDestinationRect, NULL);
        GetSourceAndDestinationRect(spriteBordersInUnit, startPoint, tileSize, spriteSizeInUnit, jobData->rectData, jobData->rectDataCount);
    }


    int totalIndexCount = 0, totalVertexCount = 0;
    float1 tilingThreshold = float1(adaptiveTilingThreshold);
    {
        PROFILER_AUTO(gGetSpriteTileVertexAndIndexCount, NULL);
        GetSpriteTileVertexAndIndexCount(tilingThreshold, spriteRendererDrawMode, adaptiveTiling, jobData->rectData, jobData->rectDataCount, totalIndexCount, totalVertexCount);
    }

    const int kMaxVertexCount = std::numeric_limits<UInt16>::max();
    const int kMaxIndexCount = kMaxVertexCount * 3;

    {
        // Get UVs of max/min vertices in case texture is packed into atlas
        Vector2f spritePivot = sprite->GetPivot();
        Vector3f vertices[] =
        {
            -Vector3f(spriteSize.x * spritePivot.x, spriteSize.y * spritePivot.y, 0) * unitToPixel,
            Vector3f(spriteSize.x - spriteSize.x * spritePivot.x, spriteSize.y - spriteSize.y * spritePivot.y, 0) * unitToPixel
        };
        Vector2f tempUVs[2];

        StrideIterator<Vector3f> vertexIt(vertices, sizeof(Vector3f));
        StrideIterator<Vector2f> uvIt(tempUVs, sizeof(Vector2f));
        StrideIterator<Vector2f> uvEnd(&tempUVs[2], sizeof(Vector2f));
        const SpriteRenderData& renderData = sprite->GetRenderData();
        RecalculateUVs(uvIt, uvEnd, vertexIt, *renderData.texture, spritePivot, sprite->GetRect(), renderData.uvTransform, renderData.textureRect, renderData.textureRectOffset, (SpritePackingRotation)renderData.settings.packingRotation, renderData.downscaleMultiplier);
        uvs = Vector4f(uvIt[0].x, uvIt[0].y, uvIt[1].x, uvIt[1].y);
    }

    if (totalVertexCount >= kMaxVertexCount || totalIndexCount >= kMaxIndexCount || totalVertexCount <= 0 || totalIndexCount <= 0)
    {
        if (totalVertexCount != 0 && totalIndexCount != 0)
            ErrorStringMsg("Cannot generate 9 slice most likely because the size is too big. Requires %d vertices and %d indices", totalVertexCount, totalIndexCount);

        SetSpriteMeshVertexCount(spriteRenderData, 4);
        SetSpriteMeshIndexCount(spriteRenderData, 6);

        StrideIterator<Vector3f> vertexBuffer = spriteRenderData->GetVertexData().MakeStrideIterator<Vector3f>(kShaderChannelVertex);
        StrideIterator<Vector2f> uvBuffer = spriteRenderData->GetVertexData().MakeStrideIterator<Vector2f>(kShaderChannelTexCoord0);
        UInt16* indexBuffer = reinterpret_cast<UInt16*>(&spriteRenderData->GetIndexBuffer()[0]);

        vertexBuffer[0] = Vector3f(startPoint.x, startPoint.y, 0);
        vertexBuffer[1] = Vector3f(startPoint.x, startPoint.y + tileSize.y, 0);
        vertexBuffer[2] = Vector3f(startPoint.x + tileSize.x, startPoint.y + tileSize.y, 0);
        vertexBuffer[3] = Vector3f(startPoint.x + tileSize.x, startPoint.y, 0);
        uvBuffer[0] = Vector2f(uvs.x, uvs.y);
        uvBuffer[1] = Vector2f(uvs.x, uvs.w);
        uvBuffer[2] = Vector2f(uvs.z, uvs.w);
        uvBuffer[3] = Vector2f(uvs.z, uvs.y);
        indexBuffer[0] = 0;
        indexBuffer[1] = 1;
        indexBuffer[2] = 3;
        indexBuffer[3] = 1;
        indexBuffer[4] = 2;
        indexBuffer[5] = 3;
        SubMesh subMesh;
        subMesh.vertexCount = 4;
        subMesh.indexCount = 6;
        subMesh.topology = kPrimitiveTriangles;
        spriteRenderData->GetSubMeshes().clear();
        spriteRenderData->GetSubMeshes().push_back(subMesh);
        SAFE_RELEASE(spriteRenderData);
        UNITY_DELETE(jobData, kMemTempJobAlloc);
        return false;
    }

    jobData->spriteSizeInUnit = spriteSizeInUnit;
    jobData->spriteUV = vload4f(uvs.GetPtr());

    jobData->adaptiveTiling = adaptiveTiling;
    jobData->adaptiveTilingThreshold = tilingThreshold;
    jobData->spriteRenderData = spriteRenderData;
    jobData->drawMode = spriteRendererDrawMode;

    SetSpriteMeshVertexCount(spriteRenderData, totalVertexCount);
    SetSpriteMeshIndexCount(spriteRenderData, totalIndexCount);

    // create a submesh for it
    SubMesh subMesh;
    subMesh.vertexCount = totalVertexCount;
    subMesh.indexCount = totalIndexCount;
    subMesh.topology = kPrimitiveTriangles;
    spriteRenderData->GetSubMeshes().clear();
    spriteRenderData->GetSubMeshes().push_back(subMesh);

    ScheduleJob(jobFence, Generate9SliceRenderDataJob, jobData);
    return true;
}

static void Generate9SliceRenderDataJob(SpriteTilingJobData* jobData)
{
    PROFILER_AUTO(gGet9SliceRenderDataJob, NULL);
    GenerateSpriteTileMesh(*jobData);
    SAFE_RELEASE(jobData->spriteRenderData);
    UNITY_DELETE(jobData, kMemTempJobAlloc);
}

void GetSourceAndDestinationRect(
    const math::float4& spriteBordersInUnit,
    const math::float2& tileStartPoint,
    const math::float2& tileSize,
    const math::float2& spriteSizeInUnit,
    NineSliceRectData outRectData[9],
    int& outRectDataCount
    )
{
    using namespace math;
    outRectDataCount = 0;

    float2 minTileAreaDimension = spriteBordersInUnit.xy + spriteBordersInUnit.zw;
    float2 flip = select(float2(1, 1), float2(-1, -1), tileSize < float2(ZERO));
    float2 tileAreaDimension = abs(tileSize);
    float2_storage scaleFactor = select(float2(1, 1), tileAreaDimension / minTileAreaDimension, tileAreaDimension < minTileAreaDimension);

    //source is at x, dest is at y
    float2 width[3] =
    {
        float2(spriteBordersInUnit.x, spriteBordersInUnit.x * scaleFactor.x),
        float2(spriteSizeInUnit.x, tileAreaDimension.x) - float2(minTileAreaDimension.x),
        float2(spriteBordersInUnit.z, spriteBordersInUnit.z * scaleFactor.x)
    };

    float2 height[3] =
    {
        float2(spriteBordersInUnit.y, spriteBordersInUnit.y * scaleFactor.y),
        float2(spriteSizeInUnit.y, tileAreaDimension.y) - float2(minTileAreaDimension.y),
        float2(spriteBordersInUnit.w, spriteBordersInUnit.w * scaleFactor.y)
    };

    float2 rectPosX = float2(ZERO);
    int xRects = 0;
    float sourcePosX[3], sourceSizeX[3];
    float destPosX[3], destSizeX[3];
    int xTileSegment[3];
    for (int j = 0; j < 3; ++j)
    {
        if (any(width[j] <= float2(ZERO)))
        {
            rectPosX += select(width[j], float2(ZERO), width[j] < float2(ZERO));
            continue;
        }
        sourcePosX[xRects] = rectPosX.x;
        sourceSizeX[xRects] = width[j].x;
        destPosX[xRects] = rectPosX.y;
        destSizeX[xRects] = width[j].y;
        rectPosX += width[j];
        xTileSegment[xRects] = j;
        ++xRects;
    }

    float2 rectPosY = float2(ZERO);
    for (int i = 0; i < 3; ++i)
    {
        if (any(height[i] <= float2(ZERO)))
        {
            rectPosY += select(height[i], float2(ZERO), height[i] < float2(ZERO));
            continue;
        }
        Vector2f rectPosYVector;
        vstore2f(rectPosYVector.GetPtr(), rectPosY);
        Vector2f heightVector;
        vstore2f(heightVector.GetPtr(), height[i]);
        for (int j = 0; j < xRects; ++j)
        {
            NineSliceRectData& rectData = outRectData[outRectDataCount];
            rectData.sourceRectPos = float2(sourcePosX[j], rectPosYVector.x);
            rectData.sourceRectSize = float2(sourceSizeX[j], heightVector.x);
            rectData.destRectSize = float2(destSizeX[j], heightVector.y);
            rectData.destRectPos = float2(destPosX[j], rectPosYVector.y) + tileStartPoint  + select(float2(ZERO), tileSize, flip < float2(ZERO));
            rectData.tileSegment = (NineSliceRectData::TileSegment)(NineSliceRectData::kTileSegmentBottomLeft + i * 3 + xTileSegment[j]);
            ++outRectDataCount;
        }
        rectPosY += height[i];
    }
}

void GetSpriteTileVertexAndIndexCount(const math::float1& adaptiveTilingThreshold, const SpriteDrawMode drawMode, const bool adaptiveTiling, const NineSliceRectData rectData[9], const int rectDataCount, int& outIndexCount, int& outVertexCount)
{
    using namespace math;

    outVertexCount = outIndexCount = 0;
    bool needsTiling = (drawMode == kSpriteDrawModeTiled);
    for (int i = 0; i < rectDataCount; ++i)
    {
        const NineSliceRectData& it = rectData[i];
        const float2 total = it.destRectSize / it.sourceRectSize;

        if (needsTiling)
        {
            float2 parts = ceil(total);
            if (adaptiveTiling)
            {
                float2 remaining = total - floor(total);

                // Only tile if the scale size exceed threshold.
                parts = max(float2(1, 1), floor(total) + select(float2(ZERO), float2(1, 1), remaining > (adaptiveTilingThreshold * it.sourceRectSize)));
            }
            float partsxy = parts.x * parts.y;
            outVertexCount += partsxy * 4;
            outIndexCount += partsxy * 6;
        }
        else
        {
            // no tiling, so it's just a quad
            outVertexCount += 4;
            outIndexCount += 6;
        }
    }
}

void GenerateSpriteTileMesh(SpriteTilingJobData& jobData)
{
    using namespace math;

    int vertexBufferIndex = 0, indexBufferIndex = 0;
    const float4 sizeNormalized = float1(1) / float4(jobData.spriteSizeInUnit, jobData.spriteSizeInUnit);
    StrideIterator<Vector3f> vertexBuffer = jobData.spriteRenderData->GetVertexData().MakeStrideIterator<Vector3f>(kShaderChannelVertex);
    StrideIterator<Vector2f> uvBuffer = jobData.spriteRenderData->GetVertexData().MakeStrideIterator<Vector2f>(kShaderChannelTexCoord0);
    UInt16* indexBuffer = reinterpret_cast<UInt16*>(&jobData.spriteRenderData->GetIndexBuffer()[0]);

    size_t vertexAllocated = jobData.spriteRenderData->GetVertexCount();
    size_t indexAllocated = jobData.spriteRenderData->GetTotalIndexCount();

    float4 uvXYXY = float4(jobData.spriteUV.xyxy);
    float4 uvZWZW = float4(jobData.spriteUV.zwzw);
    for (int i = 0; i < jobData.rectDataCount; ++i)
    {
        const float2& sourceRectSize = jobData.rectData[i].sourceRectSize;
        const float2& sourceRectPos = jobData.rectData[i].sourceRectPos;
        const float2& destRectPos = jobData.rectData[i].destRectPos;
        float xyTileCount[2];
        float4 size;

        {
            float2 sizeFloat2;
            GetTilingIterationData(jobData.rectData[i], jobData.drawMode, jobData.adaptiveTiling, jobData.adaptiveTilingThreshold, sizeFloat2, xyTileCount);
            size = float4(sizeFloat2, sizeFloat2);
        }

        float partsxy = xyTileCount[0] * xyTileCount[1];
        if ((vertexBufferIndex + partsxy * 4) > vertexAllocated || (indexBufferIndex + partsxy * 6) > indexAllocated)
        {
            ErrorStringMsg("Only allocated %d,%d but needs %d, %d for Sprite tiling generation", vertexAllocated, indexAllocated, (vertexBufferIndex + partsxy * 4), indexBufferIndex + partsxy * 6);
            return;
        }

        const float4 uv = lerp(uvXYXY, uvZWZW, float4(sourceRectPos, sourceRectPos + sourceRectSize) * sizeNormalized);
        float uvFloat[4];
        vstore4f(uvFloat, uv);

        float4 start = float4(destRectPos, destRectPos);

        int px = 0, py = 0;
        while (xyTileCount[1] > py)
        {
            float addY = (xyTileCount[1] - py > 1.0f || jobData.adaptiveTiling) ? 1.0f : xyTileCount[1] - py;
            const float uvTop = Lerp(uvFloat[1], uvFloat[3], addY);

            px = 0;
            while (xyTileCount[0] > px)
            {
                float addX = (xyTileCount[0] - px > 1.0f || jobData.adaptiveTiling) ? 1.0f : xyTileCount[0] - px;
                const float uvRight = Lerp(uvFloat[0], uvFloat[2], addX);

                float4 resultCombine = start + size * float4(px, py, px + addX, py);

                float result[4];
                vstore4f(result, resultCombine);
                vertexBuffer[vertexBufferIndex].x = result[0]; vertexBuffer[vertexBufferIndex].y  = result[1];
                vertexBuffer[vertexBufferIndex + 1].x = result[2]; vertexBuffer[vertexBufferIndex + 1].y  = result[3];

                uvBuffer[vertexBufferIndex] = Vector2f(uvFloat[0], uvFloat[1]);
                uvBuffer[vertexBufferIndex + 1] = Vector2f(uvRight, uvFloat[1]);

                resultCombine = start + size * float4(px + addX, py + addY, px, py + addY);
                vstore4f(result, resultCombine);
                vertexBuffer[vertexBufferIndex + 2].x = result[0]; vertexBuffer[vertexBufferIndex + 2].y  = result[1];
                vertexBuffer[vertexBufferIndex + 3].x = result[2]; vertexBuffer[vertexBufferIndex + 3].y  = result[3];

                uvBuffer[vertexBufferIndex + 2] = Vector2f(uvRight, uvTop);
                uvBuffer[vertexBufferIndex + 3] = Vector2f(uvFloat[0], uvTop);

                vertexBuffer[vertexBufferIndex].z = vertexBuffer[vertexBufferIndex + 1].z = vertexBuffer[vertexBufferIndex + 2].z = vertexBuffer[vertexBufferIndex + 3].z = 0;

                indexBuffer[indexBufferIndex] = vertexBufferIndex;
                indexBuffer[indexBufferIndex + 1] = vertexBufferIndex + 2;
                indexBuffer[indexBufferIndex + 2] = vertexBufferIndex + 1;
                indexBuffer[indexBufferIndex + 3] = vertexBufferIndex;
                indexBuffer[indexBufferIndex + 4] = vertexBufferIndex + 3;
                indexBuffer[indexBufferIndex + 5] = vertexBufferIndex + 2;
                vertexBufferIndex += 4;
                indexBufferIndex += 6;

                ++px;
            }
            ++py;
        }
    }
}

void GetTilingIterationData(const NineSliceRectData& rectData,
    const SpriteDrawMode drawMode,
    const bool adaptiveTiling,
    const float adaptiveTilingThreshold,
    math::float2& size,
    float xyTileCount[2])
{
    using namespace math;

    const float2& sourceRectSize = rectData.sourceRectSize;
    const float2& destRectSize = rectData.destRectSize;

    if (drawMode == kSpriteDrawModeSliced)
    {
        size = destRectSize;
        xyTileCount[0] = 1;
        xyTileCount[1] = 1;
    }
    else if (adaptiveTiling)
    {
        float2 total = destRectSize / sourceRectSize;
        float2 remaining = total - floor(total);

        // Only tile if the scale size exceed threshold.
        float2 parts = max(float2(1, 1), floor(total) + select(float2(ZERO), float2(1, 1), remaining > (adaptiveTilingThreshold * sourceRectSize)));
        size = destRectSize / parts;
        vstore2f(xyTileCount, parts);
    }
    else
    {
        float2 total = destRectSize / sourceRectSize;
        size = sourceRectSize;
        vstore2f(xyTileCount, total);
    }
}
