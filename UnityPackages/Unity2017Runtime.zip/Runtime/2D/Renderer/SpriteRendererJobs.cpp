#include "UnityPrefix.h"
#include "SpriteRendererJobs.h"
#include "Runtime/Camera/BaseRenderer.h"
#include "Runtime/Camera/RenderNodeQueue.h"
#include "Runtime/GfxDevice/GeometryJob.h"
#include "Runtime/GfxDevice/BatchRendering.h"
#include "Runtime/GfxDevice/GfxDevice.h"
#include "Runtime/Graphics/Mesh/DynamicVBO.h"
#include "Runtime/Graphics/Mesh/MeshVertexFormat.h"
#include "Runtime/Graphics/Mesh/SharedMeshData.h"
#include "Runtime/Graphics/SpriteUtility.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Camera/RenderNodeQueuePrepareContext.h"
#include "Runtime/Camera/SceneNode.h"
#include "Runtime/Graphics/Mesh/SpriteRenderer.h"
#include "Runtime/Graphics/DrawUtil.h"
#include "Runtime/Camera/Renderqueue.h"
#include "Runtime/GfxDevice/InstancedRendering.h"
#include "Runtime/Camera/BaseRenderer.h"
#include "Runtime/GfxDevice/InstancingBatcher.h"
#include "Runtime/Graphics/Mesh/Mesh.h"
#include "Runtime/Graphics/SpriteMaskUtility.h"

PROFILER_INFORMATION(gSpriteRendererPrepareNode, "SpriteRenderer.PrepareNode", kProfilerRender)
PROFILER_INFORMATION(gSpriteRenderProfile, "SpriteRenderer.Render", kProfilerRender)
PROFILER_INFORMATION(gSpriteRenderMultipleProfile, "SpriteRenderer.RenderMultiple", kProfilerRender)

static SHADERPROP(RendererColor);
static SHADERPROP(Flip);
/*

Single node render
- not transform or initialize any channels,
- just set the flip and the color into the shader
* we have to put it into some sheet
* but we can't put it into the CustomProps because we don't know in advance
  how it will be batched or not.

Dynamic Batching
- Since we are transforming the vertices we might as well
- do the flip
- fill in the color
- set the flip and the color of the shader props to 1 & white respectively
* we don't put color and flips into customPropSheet since that will auto break batch
* we will pre-transform the vertices and shove the color into the vertex color channel

For instancing
- we should batch all of the sprites of the same texture together
- means we need to make flip and color the as instanced props
* we don't put color and flips into customPropSheet since that will auto break batch
* we put the color and flips into the instanced props built-in array

How does this work when we open up the Sprite Renderer and Shaders
- Unity provides the vertices & UV0: because we calculate that.
- Unity also provides MainTex because that's mandatory
- We provide API for the users to write to any of the other channels (via MemBuffer).
- we have a way to associate additional maps for each sprite
- because unlike mesh, the sprite is defined by the texture itself. whereas on the mesh, the texture is merely a surface property
- so we will auto fill a list of tex sampler2D when the maps are available
- we also need to provide a way to 'extend' the SpriteRenderer editor for additional per-renderer parameters

Phase 1
- Switch to SharedRenderData
- Make sure we support single, dynamic batch, instancing well

Phase 2
- add support for multiple maps and auto binding
- expose internal channels via MemBuffer
- upgrade Sprite editor with shader driven per-renderer data

where does per-renderer data go? ->CustomProps
* but because we are re-using the same material for all sprites, we are forced to change the MainTex on the customProps
** also because we don't generate material per texture (unlike mesh material)

what are the options
- make a material for every texture imported as sprite
-- lots of messy stuff, how does it work with atlasing?
- another property sheet for the material
-- now does it break batch?

ok, so for unknown props
- per-renderer -> custom props
-- they should break batch and instancing
- instanced -> custom props
-- they shouldn't break instancing but break batch

Todo for Phase 1:
- restore NEON fast paths for TransformVertex
- clean up/refactor InstancePropInfo.cpp
- Rename SpriteRendererJobs to SpriteRendering.cpp

*/
void DrawSpriteRawFromNodeQueue(const RenderNodeQueue& queue, UInt32 nodeID, ShaderChannelMask shaderChannels, int subsetIndex)
{
    GfxDevice& device = GetGfxDevice();
    const RenderNode& node = queue.GetNode(nodeID);

    const SpriteRenderingData* spriteRenderingData = static_cast<const SpriteRenderingData*>(node.rendererSpecificData);
    SharedMeshData* primaryMeshData = const_cast<SharedMeshData*>(spriteRenderingData->renderData);

    size_t indexCount = primaryMeshData->GetTotalIndexCount();
    size_t vertexCount = primaryMeshData->GetVertexCount();
    const ShaderChannelMask availableChannels = primaryMeshData->GetVertexData().GetChannelMask();
    VertexChannelsLayout channelsLayout = primaryMeshData->GetVertexData().GetChannelsLayout();

    // We may need to add defaults for missing channels
    GfxTransformVerticesFlags transformFlags = kGfxTransformVerticesFlagNone | kGfxTransformVerticesFlagSprites;

    // Figure out which channels are required by the GfxDevice but missing from the input mesh
    ShaderChannelMask missingChannels = (shaderChannels & ~availableChannels) & GetGraphicsCaps().requiredShaderChannels;
    missingChannels |= VERTEX_FORMAT1(Color);   // Required by some Surface shaders where Color is always inserted (TransformSprite).;
    transformFlags |= kGfxTransformVerticesFlagAddDefaultColor;

    // Turn the missing channels into transform vertices flags
    if (missingChannels & VERTEX_FORMAT1(Normal))
        transformFlags |= kGfxTransformVerticesFlagAddDefaultNormal;
    if (missingChannels & VERTEX_FORMAT1(Tangent))
        transformFlags |= kGfxTransformVerticesFlagAddDefaultTangent;

    VertexBufferData vbData;
    GetVertexBufferData(primaryMeshData, vbData, primaryMeshData->GetVertexCount());
    const Mesh::IndexContainer& indexBuffer = primaryMeshData->GetIndexBuffer();
    const UInt16* indices = reinterpret_cast<const UInt16*>(indexBuffer.begin());

    VertexChannelsInfo channels;
    size_t stride = BuildSingleStreamChannelInfo(availableChannels, channelsLayout, missingChannels, VertexLayouts::kVertexChannelsDefault, channels.channels);
    VertexDeclaration* vertDecl = GetSpriteVertexFormat(shaderChannels).GetVertexFormat()->GetVertexDeclaration(shaderChannels, NULL, true);

    DynamicVBOChunkHandle vboChunk;
    DynamicVBO& vbo = device.GetDynamicVBO();
    if (!vbo.GetChunk(stride, vertexCount, indexCount, kPrimitiveTriangles, &vboChunk))
        return;

    Matrix4x4f mat(Matrix4x4f::kIdentity);
    if (spriteRenderingData->flipX)
        transformFlags |= kGfxTransformVerticesFlagSpritesFlipX;    // mat[0] *= -1.0f;
    if (spriteRenderingData->flipY)
        transformFlags |= kGfxTransformVerticesFlagSpritesFlipY;    // mat[5] *= -1.0f;
    UInt32 color = GetSpriteDeviceColor(spriteRenderingData->color).AsUInt32();
    color = ModifyColorForSpriteMaskRenderMode(color, spriteRenderingData->maskInteraction);

    size_t outIndexCount = TransformIndices(reinterpret_cast<UInt16*>(vboChunk.ibPtr), indices, 0, indexCount, 0, 0, false);
    size_t outVertexCount = TransformVertices(vboChunk.vbPtr, mat, vbData, 0, vertexCount, availableChannels, transformFlags, color);
    vbo.ReleaseChunk(vboChunk, outVertexCount, outIndexCount);

    if (node.rendererData.m_CustomProperties)
        device.SetShaderPropertiesShared(*node.rendererData.m_CustomProperties);

    if (spriteRenderingData->maskInteraction != kMaskInteraction_None)
        SetupMaskingStencilState(device, SpriteRenderer::s_MaskInteraction[spriteRenderingData->maskInteraction]);

    vbo.DrawChunk(vboChunk, shaderChannels, availableChannels, vertDecl);
}

#if GFX_ENABLE_DRAW_CALL_BATCHING

bool RenderDynamicBatchSprite(const RenderNodeQueue& queue, BatchInstanceData const* instances, size_t count, size_t maxVertices, size_t maxIndices, ShaderChannelMask shaderChannels, ShaderChannelMask availableChannels, const VertexChannelsLayout& channelsLayout)
{
    if (count < 1)
        return false;

    GfxDevice& device = GetGfxDevice();
    bool dynamicBatchingStarted = false;

    // We may need to add defaults for missing channels
    ShaderChannelMask missingChannels = kShaderChannelMaskNothing;
    GfxTransformVerticesFlags addDefaultFlags = kGfxTransformVerticesFlagNone;

    // Figure out which channels are required by the GfxDevice but missing from the input mesh
    missingChannels = (shaderChannels & ~availableChannels) & GetGraphicsCaps().requiredShaderChannels;

    // Turn the missing channels into transform vertices flags
    if (HasFlag(missingChannels, kShaderChannelMaskNormal))
        addDefaultFlags |= kGfxTransformVerticesFlagAddDefaultNormal;
    if (HasFlag(missingChannels, kShaderChannelMaskColor))
        addDefaultFlags |= kGfxTransformVerticesFlagAddDefaultColor;
    if (HasFlag(missingChannels, kShaderChannelMaskTangent))
        addDefaultFlags |= kGfxTransformVerticesFlagAddDefaultTangent;

    for (BatchInstanceData const* it = instances; it < instances + count; ++it)
    {
        const RenderNode& node = queue.GetNode(it->nodeID);
        const SpriteRenderingData* addData = static_cast<const SpriteRenderingData*>(node.rendererSpecificData);
        SharedMeshData* mesh = const_cast<SharedMeshData*>(addData->renderData);

        VertexBufferData vbData;
        GetVertexBufferData(mesh, vbData, mesh->GetVertexCount());
        const Mesh::IndexContainer& indexBuffer = mesh->GetIndexBuffer();
        const UInt16* indices = reinterpret_cast<const UInt16*>(indexBuffer.begin());

        if (!dynamicBatchingStarted)
        {
            // Build channel info and vertex declaration
            VertexChannelsInfo channels;
            size_t stride = BuildSingleStreamChannelInfo(availableChannels, channelsLayout, missingChannels, VertexLayouts::kVertexChannelsDefault, channels.channels);
            //@TODO: This can't be done on job!!!
            MeshVertexFormat* vertexFormat = GetMeshVertexFormatManager().GetMeshVertexFormat(channels);
            VertexDeclaration* vertDecl = vertexFormat->GetVertexDeclaration(shaderChannels);

            device.BeginDynamicBatching(shaderChannels, availableChannels, stride, vertDecl, maxVertices, maxIndices, kPrimitiveTriangles);
            dynamicBatchingStarted = true;
        }

        // now tweak the flags and color
        GfxTransformVerticesFlags finalFlags = addDefaultFlags | kGfxTransformVerticesFlagSprites;
        if (addData->flipX)
            finalFlags |= kGfxTransformVerticesFlagSpritesFlipX;
        if (addData->flipY)
            finalFlags |= kGfxTransformVerticesFlagSpritesFlipY;
        UInt32 color = GetSpriteDeviceColor(addData->color).AsUInt32();
        color = ModifyColorForSpriteMaskRenderMode(color, addData->maskInteraction);

        size_t vCount = mesh->GetVertexCount();
        size_t iCount = mesh->GetTotalIndexCount();
        device.DynamicBatchMesh(node.rendererData.m_TransformInfo.worldMatrix, vbData, 0, vCount, indices, iCount, finalFlags, color);
    }

    if (dynamicBatchingStarted)
    {
        device.EndDynamicBatching(kNoScaleTransform);
    }

    return true;
}

static bool CanUseDynamicBatching(const SharedMeshData& sharedMesh, UInt32 dynamicBatchChannels, int vertexCount)
{
    if (sharedMesh.GetIndexBuffer().empty() ||
        vertexCount > kDynamicBatchingVerticesThreshold ||
        vertexCount * BitsInMask(dynamicBatchChannels) > kDynamicBatchingVertsByChannelThreshold)
        return false;
    return true;
}

#if GFX_SUPPORTS_INSTANCING

static bool SpriteMeshExtractor(void* rendererData, ShaderChannelMask channels, int /*subsetIndex*/, MeshBuffers& buffers, DrawBuffersRange& drawRange, InstanceID& rendererInstanceID, InstanceID& meshInstanceID)
{
    rendererInstanceID = meshInstanceID = InstanceID_None;
    const SpriteRenderingData* renderingData = static_cast<const SpriteRenderingData*>(rendererData);
    DebugAssert(renderingData != NULL);
    const bool useSpriteVertDecl = false; // instancing requires regular vert decl.
    return ExtractSpriteMeshBuffersAndDrawRange(renderingData->renderData, renderingData->renderingData, channels, buffers, drawRange, useSpriteVertDecl);
}

#endif

// this is batching in CPU, so we need to make sure that we are either all in stream0
// or we respect the hot/cold split.
void DrawSpriteBatchedFromNodeQueue(const RenderNodeQueue& queue, const RenderMultipleData& renderData, ShaderChannelMask channels)
{
    Assert(renderData.extraArgs != NULL);
#if GFX_SUPPORTS_INSTANCING
    if (renderData.extraArgs->instancingBatcher != NULL)
    {
        renderData.extraArgs->instancingBatcher->RenderInstances(queue, renderData.instances, renderData.count, channels, SpriteMeshExtractor);
        return;
    }
#endif

    Assert(renderData.count > 0);
    GfxDevice& device = GetGfxDevice();

    {
        const RenderNode& customPropsNode = queue.GetNode(renderData.instances[0].nodeID);
        const bool hasCustomProps = (customPropsNode.rendererData.m_CustomProperties != NULL);
        if (hasCustomProps)
            device.SetShaderPropertiesShared(*customPropsNode.rendererData.m_CustomProperties);

        ShaderPropertySheet colorFlipSheet(kMemTempAlloc);
        colorFlipSheet.ReservePropertyCount(2);
        colorFlipSheet.SetVector(kSLPropRendererColor, Vector4f(1.0f, 1.0f, 1.0f, 1.0f));
        colorFlipSheet.SetVector(kSLPropFlip, Vector4f(1.0f, 1.0f, 0, 0));
        device.SetShaderPropertiesCopied(colorFlipSheet);
    }

    ShaderChannelMask dynamicBatchChannels = FillGapsInColdShaderChannels(channels);

    BatchInstanceData const* instancesEnd = renderData.instances + renderData.count;
    for (BatchInstanceData const* iBatchBegin = renderData.instances; iBatchBegin != instancesEnd;)
    {
        const RenderNode& node = queue.GetNode(iBatchBegin->nodeID);
        const SpriteRenderingData* spriteRenderingData = static_cast<const SpriteRenderingData*>(node.rendererSpecificData);
        Assert(spriteRenderingData != NULL);
        const SharedMeshData* primaryMeshData = spriteRenderingData->renderData;
        const SpriteMaskInteraction maskInteraction = spriteRenderingData->maskInteraction;

        BatchInstanceData const* iBatchEnd = iBatchBegin + 1;
        size_t batchVertexCount = primaryMeshData->GetVertexCount();
        size_t batchIndexCount = primaryMeshData->GetTotalIndexCount();

        // By default dynamic batching is enabled for Sprites. Disabled only when in Graphics Jobs or Applied pass is multi-pass.
        if (renderData.extraArgs->enableSpritesBatching)
        {
            ASSERT_RUNNING_ON_MAIN_THREAD;

            if (CanUseDynamicBatching(*primaryMeshData, dynamicBatchChannels, batchVertexCount) && batchIndexCount < kDynamicBatchingIndicesThreshold)
            {
                PROFILER_AUTO(gSpriteRenderMultipleProfile, NULL)

                const ShaderChannelMask availableChannels = primaryMeshData->GetVertexData().GetChannelMask() & dynamicBatchChannels;
                VertexChannelsLayout channelsLayout = primaryMeshData->GetVertexData().GetChannelsLayout();

                for (; iBatchEnd != instancesEnd; ++iBatchEnd)
                {
                    const RenderNode& nextNode = queue.GetNode(iBatchEnd->nodeID);
                    const SpriteRenderingData& nextAddData = *static_cast<const SpriteRenderingData*>(nextNode.rendererSpecificData);

                    const SpriteMaskInteraction nextMaskInteraction = nextAddData.maskInteraction;
                    if (nextMaskInteraction != maskInteraction)
                        break;

                    const SharedMeshData* nextMesh = nextAddData.renderData;
                    Assert(nextMesh);

                    UInt32 requiredVertexCount = batchVertexCount + nextMesh->GetVertexCount();
                    UInt32 requiredIndexCount = batchIndexCount + nextMesh->GetTotalIndexCount();

                    if (requiredVertexCount > kDynamicBatchingTotalVerticesThreshold)
                        break;

                    if (requiredIndexCount > kDynamicBatchingIndicesThreshold)
                        break;

                    if (!IsColdVertexDataInSameFormat(*nextMesh, dynamicBatchChannels, channelsLayout))
                        break;

                    const ShaderChannelMask nextAvailableChannels = nextMesh->GetVertexData().GetChannelMask() & dynamicBatchChannels;
                    if (availableChannels != nextAvailableChannels)
                        break;

                    batchVertexCount = requiredVertexCount;
                    batchIndexCount = requiredIndexCount;
                }

                if (maskInteraction != kMaskInteraction_None)
                    SetupMaskingStencilState(device, SpriteRenderer::s_MaskInteraction[maskInteraction]);

                // Skip batch if batchVertexCount == 0 or batchIndexCount == 0
                if (batchVertexCount == 0 || batchIndexCount == 0 || RenderDynamicBatchSprite(queue, iBatchBegin, iBatchEnd - iBatchBegin, batchVertexCount, batchIndexCount, channels, availableChannels, channelsLayout))
                    iBatchBegin = iBatchEnd;

                GPU_TIMESTAMP();
            }
        }

        // old-school rendering for anything left
        for (; iBatchBegin != iBatchEnd; ++iBatchBegin)
        {
            DebugAssert(node.executeCallback);
            SetupObjectMatrix(node.rendererData.m_TransformInfo.worldMatrix, node.rendererData.m_TransformInfo.transformType);
            node.executeCallback(queue, iBatchBegin->nodeID, channels, iBatchBegin->subsetIndex);
        }
        Assert(iBatchBegin == iBatchEnd); // everything was rendered successfully
    }
}

#endif

void CleanupDrawSpriteRawFromNodeQueue(RenderNodeQueue& queue, UInt32 nodeID)
{
    const RenderNode& node = queue.GetNode(nodeID);
    const SpriteRenderingData& spriteRenderingData = *static_cast<const SpriteRenderingData*>(node.rendererSpecificData);
    if (spriteRenderingData.renderData)
        spriteRenderingData.renderData->Release();
    if (spriteRenderingData.renderingData)
        spriteRenderingData.renderingData->Release();
}

template<bool kExecuteMultiThreaded>
static void PrepareSpriteRenderNodes(RenderNodeQueuePrepareThreadContext& perThreadContext)
{
    PROFILER_AUTO(gSpriteRendererPrepareNode, NULL)

    const IndexList visibleList = perThreadContext.visibleRenderers;
    const SceneNode* sceneNodes = perThreadContext.rendererCullData.nodes;
    PerThreadPageAllocator& allocator = perThreadContext.additionalDataAllocator;
    UInt32 outputIndex = perThreadContext.outputIndex;

    for (; perThreadContext.inputIndex < visibleList.size; perThreadContext.inputIndex++)
    {
        UInt32 index = perThreadContext.inputIndex;
        int renderIndex = visibleList[index];
        const SceneNode& sceneNode = sceneNodes[renderIndex];
        SpriteRenderer* renderer = static_cast<SpriteRenderer*>(sceneNode.renderer);
        if (kRendererSprite != renderer->GetRendererType())
            break;

        if (sceneNode.disable)
            continue;

        renderer->PrepareCachedSprite<kExecuteMultiThreaded>(perThreadContext);
        Sprite* sprite = renderer->GetSpriteUsedForRendering();
        if (sprite == NULL)
            continue;

        if (!renderer->PrepareRenderingDataIfNeeded(kExecuteMultiThreaded))
        {
            if (kExecuteMultiThreaded)
                QueuePrepareNodeToMainThread(perThreadContext);
            continue;
        }

        // Handle Destroyed Sprite Object.
        const SpriteRenderData* renderData = renderer->GetRenderData();
        const SharedMeshData* sharedMeshData = renderData->AcquireReadOnlyData();
        if (sharedMeshData->GetSubMeshes().size() != 1 || sharedMeshData->GetTotalIndexCount() == 0)
        {
            SAFE_RELEASE(sharedMeshData);
            WarningString("Incomplete mesh data in Sprite. Please reimport or recreate the Sprite.");
            continue; // there must be exactly 1
        }
        if (sharedMeshData->GetVertexCount() == 0 || sharedMeshData->GetTotalIndexCount() == 0)
        {
            SAFE_RELEASE(sharedMeshData);
            continue;
        }

        RenderNode& node = perThreadContext.outputNodes[outputIndex];

        const TransformInfo& transformInfo = renderer->GetTransformInfoExpectUpToDate();
        BaseRenderer::FlattenCommonData(*renderer, transformInfo, 0.0f, node);

        if (perThreadContext.sharedContext->flags & kExtractProbes)
            BaseRenderer::FlattenProbeData(*renderer, transformInfo, perThreadContext.sharedContext->lightProbeContext, node);

        if (!BaseRenderer::FlattenSharedMaterialData<kExecuteMultiThreaded>(*renderer, allocator, node))
        {
            QueuePrepareNodeToMainThread(perThreadContext);
            continue;
        }

        node.smallMeshIndex = sprite->GetInternalSpriteID();
        node.rendererSpecificData = allocator.Allocate<SpriteRenderingData>();
        SpriteRenderingData* spriteRenderingData = (SpriteRenderingData*)node.rendererSpecificData;
        spriteRenderingData->renderingData = renderData->AcquireRenderingData();
        spriteRenderingData->renderData = sharedMeshData;
        spriteRenderingData->color = renderer->GetColor();
        spriteRenderingData->flipX = renderer->GetFlipX();
        spriteRenderingData->flipY = renderer->GetFlipY();
        spriteRenderingData->maskInteraction = renderer->GetMaskInteraction();

#if GFX_ENABLE_DRAW_CALL_BATCHING
        node.batchingFlags = kBatchingFlagAllowBatching | kBatchingFlagAllowInstancing;
        node.executeBatchedCallback = DrawSpriteBatchedFromNodeQueue;
#else
        node.executeBatchedCallback = NULL;
#endif
        node.executeCallback = DrawSpriteRawFromNodeQueue;
        node.cleanupCallback = CleanupDrawSpriteRawFromNodeQueue;

        outputIndex++;
    }

    perThreadContext.outputIndex = outputIndex;
}

void SetupSpriteRendererPrepareCallbacks()
{
    RegisterPrepareRenderNodesCallback(kRendererSprite, PrepareSpriteRenderNodes<false>, PrepareSpriteRenderNodes<true>);
}

bool ExtractSpriteMeshBuffersAndDrawRange(const SharedMeshData* renderData, SharedMeshRenderingData* renderingData, ShaderChannelMask wantedChannels, MeshBuffers& buffers, DrawBuffersRange& drawRange, bool useSpriteVertDecl)
{
    if (renderingData->GetMeshVertexFormat() == NULL || renderData->GetVertexData().GetVertexCount() == 0)
        return false; // we don't have a mesh yet

    buffers.indexBuffer = renderingData->GetIndexBuffer();
    if (buffers.indexBuffer == NULL)
        return false;

    buffers.vertexStreamCount = 0;

    for (int s = 0; s < kMaxVertexStreams; ++s)
    {
        if (!renderingData->GetVertexStreams()[s].buffer)
            break;

        buffers.vertexStreams[s] = renderingData->GetVertexStreams()[s];
        buffers.vertexStreamCount++;
    }

    GfxDevice& device = GetGfxDevice();

    const ShaderChannelMask availableChannels = renderingData->GetMeshVertexFormat()->GetAvailableChannels();
    const ShaderChannelMask missingChannels = (wantedChannels & ~availableChannels) & GetGraphicsCaps().requiredShaderChannels;
    const size_t vertexCount = renderData->GetVertexCount();

    // now we add the default missing channels
    UInt8 defaultStreamIndices[kGfxDefaultVertexBufferCount] = {};
    for (ShaderChannelIterator it; it.AnyRemaining(missingChannels); ++it)
    {
        if (missingChannels & it.GetMask())
        {
            GfxDefaultVertexBufferType type = GetDefaultVertexBufferTypeForChannel(it.GetChannel(), true);
            UInt8& defaultStreamIndex = defaultStreamIndices[type];
            if (defaultStreamIndex == 0)
            {
                defaultStreamIndex = buffers.vertexStreamCount++;
                buffers.vertexStreams[defaultStreamIndex] = device.GetDefaultVertexBuffer(type, vertexCount);
            }
        }
    }

    if (buffers.vertexStreamCount == 0)
        return false;

    buffers.vertexDecl = renderingData->GetMeshVertexFormat()->GetVertexDeclaration(wantedChannels, NULL, useSpriteVertDecl);
    drawRange = renderData->GetSubMeshes()[0].ToDrawBuffersRange(false); // sprite rendering won't have tessellation
    return true;
}
