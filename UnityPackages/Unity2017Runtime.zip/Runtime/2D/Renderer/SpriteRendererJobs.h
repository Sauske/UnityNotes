#pragma once
#include "Runtime/Math/Vector4.h"
#include "Runtime/Math/Color.h"
#include "Runtime/GfxDevice/GfxDeviceTypes.h"
#include "Runtime/2D/Common/SpriteTypes.h"

class RenderNodeQueue;
class SharedMeshData;
class SharedMeshRenderingData;
struct DrawBuffersRange;
struct MeshBuffers;
struct RenderMultipleData;

struct SpriteRenderingData
{
    SharedMeshRenderingData* renderingData;
    const SharedMeshData* renderData;
    ColorRGBAf color;
    bool flipX;
    bool flipY;
    SpriteMaskInteraction maskInteraction;
};

bool ExtractSpriteMeshBuffersAndDrawRange(const SharedMeshData* renderData, SharedMeshRenderingData* renderingData, ShaderChannelMask wantedChannels, MeshBuffers& buffer, DrawBuffersRange& drawRange, bool useSpriteVertDecl = true);
void SetupSpriteRendererPrepareCallbacks();
void DrawSpriteRawFromNodeQueue(const RenderNodeQueue& queue, UInt32 nodeID, ShaderChannelMask channels, int subsetIndex);
void CleanupDrawSpriteRawFromNodeQueue(RenderNodeQueue& queue, UInt32 nodeID);
#if GFX_ENABLE_DRAW_CALL_BATCHING
void DrawSpriteBatchedFromNodeQueue(const RenderNodeQueue& queue, const RenderMultipleData& renderData, ShaderChannelMask channels);
#endif
