#pragma once
#include "SpriteAtlasTypes.h"
#if UNITY_EDITOR
#include "Editor/Src/2D/SpriteAtlas/SpriteAtlas_EditorTypes.h"
#endif

class SpriteAtlas : public NamedObject
{
public:
    REGISTER_CLASS(SpriteAtlas);
    DECLARE_OBJECT_SERIALIZE();

    SpriteAtlas(MemLabelId label, ObjectCreationMode mode);

    void AwakeFromLoad(AwakeFromLoadMode mode);
    void CheckConsistency();
    void Reset();

    SpritesList& GetSprites();
    void GetSpritesByName(SpritesList& sprites, const core::string& spriteName, bool firstOnly);
    const SpriteAtlasData* GetRuntimeRenderData(const Sprite* sprite) const;
    const core::string& GetTag() const { return m_Tag; }
    bool IsVariant() const { return m_IsVariant; }
    bool IsMaster() const { return !m_IsVariant; }
    bool CanBindTo(const Sprite* sprite) const;

private:

    RuntimeSpriteRenderDataMap m_RenderDataMap;
    SpritesList m_PackedSprites;
    dynamic_array<core::string> m_PackedSpriteNamesToIndex;
    core::string m_Tag;
    bool m_IsVariant;

    const RuntimeSpriteRenderDataMap* GetSpriteRenderDataMap() const;

#if UNITY_EDITOR
public:

    void MainThreadCleanup();
    virtual void SetName(char const* name);

    // Cached textures
    void GetPackedTextures(TextureList& textureList);
    void GetPackedAlphaTextures(TextureList& textureList);

    bool Contains(const PPtr<Object>& packableObject) const;
    void Add(const SpriteAtlasEditorData::ObjectArray& objects);
    void Add(const PPtr<Object>& packableObject);
    void Remove(const SpriteAtlasEditorData::ObjectArray& objects);
    void Remove(const PPtr<Object>& packableObject);
    void Remove(int index);

    // Before pack
    bool IsPackingRequired() const;
    void ReconcilePackedSprites();
    void PrePack(const BuildTargetPlatform& destinationPlatform);
    void GroupSprites(const BuildTargetPlatform& destinationPlatform = kBuildNoTargetPlatform);
    bool ValidateSize(const BuildTargetPlatform& destinationPlatform);

    // After pack
    void PopulatePackedTexturesAndRenderData(
        const TextureList& textures,
        const TextureList& alphaTextures,
        const BuildTargetPlatform platform,
        SpriteRenderDataMap& renderDatas);
    void PackAsVariant(const BuildTargetPlatform platform);
    void FinalizePack();

    bool IsValidVariant() const { return IsVariant() && m_MasterAtlas.IsValid(); }
    void SetIsVariant(bool value);
    void CopyMasterAtlasSetting();
    void SetMasterAtlas(const PPtr<SpriteAtlas>& master);
    PPtr<SpriteAtlas> GetMasterSpriteAtlas() const { return m_MasterAtlas; }

    bool GetIsReadableForPacking() const;
    UInt32 GetCompressionQuality(const BuildTargetPlatform& destinationPlatform) const;
    UInt32 GetMaxTextureSize(const BuildTargetPlatform& destinationPlatform) const;
    void SetMaxTextureSize(const BuildTargetPlatform& destinationPlatform, UInt32 newSize);
    bool GetOverridden(const BuildTargetPlatform& destinationPlatform) const;
    bool GetUseCrunchedCompression(const BuildTargetPlatform& destinationPlatform) const;
    TextureFormat GetDesiredFormat(const BuildTargetPlatform& destinationPlatform) const;
    TextureFormat DetermineFormatFromTextureCompression(const BuildTargetPlatform& destinationPlatform) const;

    Hash128 GetCurrentPackingHash() const { return m_EditorData.currentPackingHash; }
    UInt32 GetTotalSpriteSurfaceArea() { return m_EditorData.totalSpriteSurfaceArea; }
    const core::string& GetHashString() const { return m_EditorData.hashString; }
    const SortedSpriteToPack& GetSortedSpriteToPack() const { return m_EditorData.sortedSpriteToPack; }
    const SpriteRenderDataKeyList& GetPackedSpriteRenderDataKeys() const { return m_EditorData.packedSpriteRenderDataKeys; }
    const SpriteAtlasEditorData::ObjectArray& GetInputPackables() const { return m_EditorData.packables; }

    const SpriteAtlasEditorData::PackingParameters& GetPackingParameters();
    void SetPackingParameters(const SpriteAtlasEditorData::PackingParameters& params);
    const SpriteAtlasEditorData::TextureSettings& GetTextureSettings();
    void SetTextureSettings(const SpriteAtlasEditorData::TextureSettings& settings);
    bool GetPlatformSettings(const core::string& buildTarget, TextureImporterPlatformSettings& settings) const;
    bool GetPlatformSettings(const BuildTargetPlatform& destinationPlatform, TextureImporterPlatformSettings& settings) const;
    const std::vector<TextureImporterPlatformSettings>& GetAllPlatformSettings() const;
    void SetPlatformSettings(const TextureImporterPlatformSettings& settings);

    TextureFormat GetFormat() const { return m_EditorData.finalFormat; }
    UInt32 GetAnisoLevel() const { return m_EditorData.textureSettings.anisoLevel; }
    TextureFilterMode GetFilterMode() const { return m_EditorData.textureSettings.filterMode; }
    bool GetGenerateMipMaps() const { return m_EditorData.textureSettings.generateMipMaps; }
    bool GetUseSRBG() const { return m_EditorData.textureSettings.sRGB; }

    UInt32 GetPadding() const { return m_EditorData.packingParameters.padding; }
    UInt32 GetBlockOffset() const { return m_EditorData.packingParameters.blockOffset; }
    bool GetAllowAlphaSplitting() const { return m_EditorData.packingParameters.allowAlphaSplitting; }
    bool GetEnableRotation() const { return m_EditorData.packingParameters.enableRotation; }
    bool GetEnableTightPacking() const { return m_EditorData.packingParameters.enableTightPacking; }

    GET_SET_COMPARE_DIRTY(float, VariantMultiplier, m_EditorData.variantMultiplier);
    GET_SET_COMPARE_DIRTY(bool, BindAsDefault, m_EditorData.bindAsDefault);

private:

    struct Texture2DHashFunc
    {
        inline size_t operator()(const PPtr<Texture2D>& key) const
        {
            core::hash<InstanceID> hasher;
            return hasher(key.GetInstanceID());
        }
    };

    typedef core::hash_map<PPtr<Texture2D>, PPtr<Texture2D>, Texture2DHashFunc> TextureToTextureMap;

    SpriteAtlasEditorData m_EditorData;
    PPtr<SpriteAtlas> m_MasterAtlas;

    // Editor version's
    void AwakeFromLoad_Editor(AwakeFromLoadMode mode);
    void CheckConsistency_Editor();
    void Reset_Editor();
    void VerifyVariantStatus();
    void CleanupPackedState();

    void CalculateCurrentPackingHash(const BuildTargetPlatform& destinationPlatform);
    void GenerateScaledTextureFromMasterPackedTexture(
        const TextureList& masterPackedTextures,
        const float ratio,
        const BuildTargetPlatform platform,
        TextureList& variantTextures,
        TextureToTextureMap& texturesMap);
#endif
};
