#include "UnityPrefix.h"
#include "SpriteAtlas.h"

IMPLEMENT_REGISTER_CLASS(SpriteAtlas, 0x28F3FDEF);
IMPLEMENT_OBJECT_SERIALIZE(SpriteAtlas);
INSTANTIATE_TEMPLATE_TRANSFER(SpriteAtlas)

SpriteAtlas::SpriteAtlas(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode), m_RenderDataMap(label), m_Tag(""), m_IsVariant(false)
{
}

template<class TransferFunction>
void SpriteAtlas::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);

    TRANSFER_EDITOR_ONLY(m_EditorData);
    TRANSFER_EDITOR_ONLY(m_MasterAtlas);

    TRANSFER(m_PackedSprites);
    TRANSFER(m_PackedSpriteNamesToIndex);
    transfer.Align();

#if UNITY_EDITOR
    if (transfer.IsSerializingForGameRelease())
    {
        if (m_EditorData.cachedData.IsValid())
            TRANSFER_WITH_NAME(m_EditorData.cachedData->frames, "m_RenderDataMap");
        else
            TRANSFER(m_RenderDataMap);
    }

#else
    TRANSFER(m_RenderDataMap);
#endif

    TRANSFER(m_Tag);
    TRANSFER(m_IsVariant);
    transfer.Align();
}

void SpriteAtlas::ThreadedCleanup()
{}

void SpriteAtlas::AwakeFromLoad(AwakeFromLoadMode mode)
{
    Super::AwakeFromLoad(mode);

#if UNITY_EDITOR
    AwakeFromLoad_Editor(mode);
#endif
}

void SpriteAtlas::CheckConsistency()
{
    Super::CheckConsistency();

#if UNITY_EDITOR
    CheckConsistency_Editor();
#endif
}

void SpriteAtlas::Reset()
{
    Super::Reset();

#if UNITY_EDITOR
    Reset_Editor();
#endif
}

SpritesList& SpriteAtlas::GetSprites()
{
    return m_PackedSprites;
}

void SpriteAtlas::GetSpritesByName(SpritesList& sprites, const core::string& spriteName, bool firstOnly)
{
    for (size_t i = 0; i < m_PackedSpriteNamesToIndex.size(); ++i)
    {
        if (m_PackedSpriteNamesToIndex[i] == spriteName)
        {
            sprites.push_back(m_PackedSprites[i]);
            if (firstOnly)
                break;
        }
    }
}

const SpriteAtlasData* SpriteAtlas::GetRuntimeRenderData(const Sprite* sprite) const
{
    const RuntimeSpriteRenderDataMap* renderDataMap = GetSpriteRenderDataMap();
    RuntimeSpriteRenderDataMap::const_iterator it = renderDataMap->find(sprite->GetRenderDataKey());
    if (it != renderDataMap->end())
        return &it->second;
    return NULL;
}

bool SpriteAtlas::CanBindTo(const Sprite* sprite) const
{
    return GetRuntimeRenderData(sprite) != NULL;
}

const RuntimeSpriteRenderDataMap* SpriteAtlas::GetSpriteRenderDataMap() const
{
#if UNITY_EDITOR
    if (m_EditorData.cachedData.IsValid())
        return &m_EditorData.cachedData->frames;
#endif
    return &m_RenderDataMap;
}
