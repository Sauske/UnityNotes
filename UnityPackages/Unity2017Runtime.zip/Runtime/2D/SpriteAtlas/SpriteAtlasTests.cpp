#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS && UNITY_EDITOR

#include "SpriteAtlas.h"
#include "Runtime/Testing/Testing.h"
#include "Runtime/Testing/TestFixtures.h"
#include "Runtime/Graphics/SpriteFrame.h"
#include "Runtime/Graphics/Texture2D.h"
#include "Runtime/Graphics/Mesh/Mesh.h"
#include "Runtime/Shaders/Shader.h"

UNIT_TEST_SUITE(SpriteAtlas)
{
    class SpriteAtlasTestFixture : public TestFixtureBase
    {
    public:
        SpriteAtlasTestFixture()
            : m_SpriteAtlas(NewTestObject<SpriteAtlas>()),
            m_Sprite1(NewTestObject<Sprite>()),
            m_Sprite2(NewTestObject<Sprite>()),
            m_Texture1(NewTestObject<Texture2D>()),
            m_Texture2(NewTestObject<Texture2D>()),
            m_Mesh(NewTestObject<Mesh>()),
            m_Shader(NewTestObject<Shader>())
        {
            m_Mesh->SetName("the_mesh");
            m_Shader->SetName("the_shader");
        }

        SpriteAtlas* m_SpriteAtlas;
        Sprite* m_Sprite1;
        Sprite* m_Sprite2;
        Texture2D* m_Texture1;
        Texture2D* m_Texture2;
        Mesh* m_Mesh;
        Shader* m_Shader;
    };

    TEST_FIXTURE(SpriteAtlasTestFixture, AddInvalidObjectType_ProducesWarning_ExemptThemFromAdded)
    {
        dynamic_array<PPtr<Object> > objectList(kMemTempAlloc);
        objectList.push_back(m_Sprite1);
        objectList.push_back(m_Texture1);
        objectList.push_back(m_Mesh);
        objectList.push_back(m_Shader);

        EXPECT(Warning, "Attempted to add invalid object into a Sprite Atlas. the_mesh was a Mesh");
        EXPECT(Warning, "Attempted to add invalid object into a Sprite Atlas. the_shader was a Shader");
        m_SpriteAtlas->Add(objectList);

        CHECK_EQUAL(2, m_SpriteAtlas->GetInputPackables().size());
        CHECK(m_SpriteAtlas->Contains(m_Sprite1));
        CHECK(m_SpriteAtlas->Contains(m_Texture1));
        CHECK(!m_SpriteAtlas->Contains(m_Mesh));
        CHECK(!m_SpriteAtlas->Contains(m_Shader));
    }

    TEST_FIXTURE(SpriteAtlasTestFixture, Remove_AffectAllDuplicatedEntries)
    {
        dynamic_array<PPtr<Object> > objectList(kMemTempAlloc);
        objectList.push_back(m_Sprite1);
        objectList.push_back(m_Texture1);
        objectList.push_back(m_Sprite2);
        objectList.push_back(m_Texture2);
        objectList.push_back(m_Sprite1);

        m_SpriteAtlas->Add(objectList);

        dynamic_array<PPtr<Object> > removeList(kMemTempAlloc);
        removeList.push_back(m_Sprite1);

        m_SpriteAtlas->Remove(removeList);

        CHECK_EQUAL(3, m_SpriteAtlas->GetInputPackables().size());
        CHECK(!m_SpriteAtlas->Contains(m_Sprite1));
    }

    TEST_FIXTURE(TestFixtureBase, AssigningAMaster_TagWillChangedToMasterTag)
    {
        SpriteAtlas* master = NewTestObject<SpriteAtlas>();
        SpriteAtlas* variant = NewTestObject<SpriteAtlas>();
        master->SetName("master");
        variant->SetName("variant");

        variant->SetIsVariant(true);
        variant->SetMasterAtlas(master);

        CHECK_EQUAL("master", variant->GetTag());
    }

    TEST_FIXTURE(TestFixtureBase, AssigningMasterToAMaster_ProduceWarning)
    {
        SpriteAtlas* spriteAtlas = NewTestObject<SpriteAtlas>();
        SpriteAtlas* anotherSpriteAtlas = NewTestObject<SpriteAtlas>();

        EXPECT(Warning, "Cannot set a master to this atlas because it was not set as a variant atlas.");
        anotherSpriteAtlas->SetMasterAtlas(spriteAtlas);
    }

    TEST_FIXTURE(TestFixtureBase, AssigningItselfAsMaster_ProduceWarning)
    {
        SpriteAtlas* spriteAtlas = NewTestObject<SpriteAtlas>();

        EXPECT(Warning, "Cannot set itself as the master atlas.");
        spriteAtlas->SetIsVariant(true);
        spriteAtlas->SetMasterAtlas(spriteAtlas);
    }

    TEST_FIXTURE(TestFixtureBase, AssigningAVariantAsMaster_ProduceWarning)
    {
        SpriteAtlas* variantSpriteAtlas = NewTestObject<SpriteAtlas>();
        SpriteAtlas* toAssignSpriteAtlas = NewTestObject<SpriteAtlas>();

        variantSpriteAtlas->SetIsVariant(true);
        toAssignSpriteAtlas->SetIsVariant(true);

        EXPECT(Warning, "Cannot set a variant atlas as a master atlas.");
        toAssignSpriteAtlas->SetMasterAtlas(variantSpriteAtlas);
    }
}

#endif
