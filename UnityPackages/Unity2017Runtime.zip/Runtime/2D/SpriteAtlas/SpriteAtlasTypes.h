#pragma once
#include "Runtime/Graphics/SpriteFrame.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Utilities/HashStringFunctions.h"
#include "Runtime/Utilities/Hash128.h"
#include "Runtime/Core/Containers/hash_map.h"

struct SpriteRenderDataKeyHash
{
    inline size_t operator()(SpriteRenderDataKey key) const
    {
        Hash128 hash;
        SpookyHash::Hash128(&key, sizeof(key), &hash.hashData.u64[0], &hash.hashData.u64[1]);

        return hash.PackToUInt32();
    }
};

struct SpriteAtlasData
{
    DECLARE_SERIALIZE(SpriteAtlasData)

    PPtr<Texture2D> texture;
    PPtr<Texture2D> alphaTexture;

    Rectf           textureRect;       // In pixels (texture space). Invalid if packingMode is Tight.
    Vector2f        textureRectOffset; // In pixels (texture space). Invalid if packingMode is Tight.
    Vector2f        atlasRectOffset;
    Vector4f        uvTransform;       // Xmul, Xadd, Ymul, Yadd
    float           downscaleMultiplier;  // Sprite atlas's variant multiplier
    UInt32          settingsRaw;
};

typedef dynamic_array<PPtr<Sprite> > SpritesList;
typedef core::hash_map<SpriteRenderDataKey, SpriteAtlasData, SpriteRenderDataKeyHash> RuntimeSpriteRenderDataMap;

template<class TransferFunction>
void SpriteAtlasData::Transfer(TransferFunction& transfer)
{
    TRANSFER(texture);
    TRANSFER(alphaTexture);
    TRANSFER(textureRect);
    TRANSFER(textureRectOffset);
    TRANSFER(atlasRectOffset);
    TRANSFER(uvTransform);
    TRANSFER(downscaleMultiplier);
    TRANSFER(settingsRaw);
}

typedef UNITY_VECTOR_SET (kMemSpriteAtlas, PPtr<SpriteAtlas>) SpriteAtlasSet;
typedef UNITY_VECTOR_SET (kMemSpriteAtlas, core::string) TagsSet;
typedef core::hash_map<core::string, SpriteAtlasSet> TagToSpriteAtlasArray;
typedef core::hash_map<core::string, SpritesList> TagToSpriteArray;
