#pragma once
#include "Runtime/2D/SpriteAtlas/SpriteAtlasTypes.h"
#include "Runtime/BaseClasses/GameManager.h"
#include "Runtime/Graphics/SpriteFrame.h"
#include "Runtime/SceneManager/UnitySceneHandle.h"
#include "Runtime/Utilities/dynamic_array.h"

class SpriteAtlasManager
{
public:
    SpriteAtlasManager(MemLabelId label);
    virtual ~SpriteAtlasManager();

    void Update();

    // When Sprite Awake, it might not have SpriteAtlas bound, this is the method to check for late bound atlas
    // If there has nothing, Manager will initiate mono callback to see if user planned to load it later in scene.
    const SpriteAtlas* GetAtlas(const PPtr<Sprite>& sprite);

    // Explicitly bind a SpriteAtlas to all its packed Sprites.
    // Manager will then remember this SpriteAtlas.
    void Register(PPtr<SpriteAtlas> spriteAtlas);

    void AllowRequesting(bool allow) { m_AllowRequesting = allow; }

#if UNITY_EDITOR
    void OnExitPlayMode();
#endif

private:
    TagToSpriteAtlasArray m_Atlases;
    TagToSpriteArray m_RequestingSprites;
    TagsSet m_RequestingTags;
    bool m_ShouldRequest;
    bool m_ShouldCleanup;
    bool m_AllowRequesting;

    void AddRequestingSprite(PPtr<Sprite> sprite);
    void RequestAtlasViaScript();
    void CleanupInvalidAtlases();
};

SpriteAtlasManager& GetSpriteAtlasManager();
SpriteAtlasManager* GetSpriteAtlasManagerPtr();
