#include "UnityPrefix.h"
#include "Runtime/2D/SpriteAtlas/SpriteAtlasManager.h"
#include "Runtime/2D/SpriteAtlas/SpriteAtlas.h"
#include "Runtime/BaseClasses/ManagerContext.h"
#include "Runtime/Core/Callbacks/GlobalCallbacks.h"
#include "Runtime/Core/Callbacks/PlayerLoopCallbacks.h"
#include "Runtime/Graphics/Mesh/SpriteRenderer.h"
#include "Runtime/Graphics/SpriteFrame.h"
#include "Runtime/Scripting/ScriptingInvocation.h"
#include "Runtime/Scripting/ScriptingExportUtility.h"
#include "Runtime/Utilities/RuntimeStatic.h"

#if UNITY_EDITOR
#include "Runtime/BaseClasses/IsPlaying.h"
#include "Editor/Src/2D/SpriteAtlas/SpriteAtlasPackingUtilities.h"
#include "Editor/Src/EditorUserBuildSettings.h"
#endif

static RuntimeStatic<SpriteAtlasManager, true> g_SpriteAtlasManager(kMemSpriteAtlas, "Managers", "SpriteAtlasManager");

SpriteAtlasManager& GetSpriteAtlasManager()
{
    return *g_SpriteAtlasManager;
}

SpriteAtlasManager* GetSpriteAtlasManagerPtr()
{
    return g_SpriteAtlasManager;
}

#if UNITY_EDITOR
static void OnEnterPlayModePreAwakeStatic()
{
    if (GetEditorUserBuildSettingsPtr())
        CollectAllSpriteAtlasesAndPack(GetEditorUserBuildSettingsPtr()->GetActiveBuildTarget(), true);
}

static void OnExitPlayModeStatic()
{
    if (GetSpriteAtlasManagerPtr())
        GetSpriteAtlasManagerPtr()->OnExitPlayMode();
}

#endif

SpriteAtlasManager::SpriteAtlasManager(MemLabelId label)
    : m_Atlases(label), m_RequestingSprites(label), m_ShouldRequest(false), m_ShouldCleanup(false), m_AllowRequesting(true)
{
#if UNITY_EDITOR
    GlobalCallbacks::Get().enterPlayModePreAwake.Register(OnEnterPlayModePreAwakeStatic);
    GlobalCallbacks::Get().exitPlayModeBeforeAwakeInEditMode.Register(OnExitPlayModeStatic);
#endif

    REGISTER_PLAYERLOOP_CALL(EarlyUpdate, SpriteAtlasManagerUpdate,
    {
        GetSpriteAtlasManager().Update();
    });
}

SpriteAtlasManager::~SpriteAtlasManager()
{
#if UNITY_EDITOR
    GlobalCallbacks::Get().enterPlayModePreAwake.Unregister(OnEnterPlayModePreAwakeStatic);
    GlobalCallbacks::Get().exitPlayModeBeforeAwakeInEditMode.Unregister(OnExitPlayModeStatic);
#endif
}

void SpriteAtlasManager::Update()
{
    if (m_ShouldCleanup)
    {
        CleanupInvalidAtlases();
        m_ShouldCleanup = false;
    }
    if (m_ShouldRequest)
    {
        RequestAtlasViaScript();
    }
}

const SpriteAtlas* SpriteAtlasManager::GetAtlas(const PPtr<Sprite>& sprite)
{
    typedef UNITY_VECTOR_SET (kMemTempAlloc, PPtr<SpriteAtlas>) SpriteAtlasSetTemp;
    SpriteAtlasSetTemp availableSpriteAtlases;

    for (dynamic_array<core::string>::iterator itTag = sprite->GetAtlasTags().begin(); itTag != sprite->GetAtlasTags().end(); ++itTag)
    {
        TagToSpriteAtlasArray::const_iterator it = m_Atlases.find(*itTag);
        if (it != m_Atlases.end())
        {
            const SpriteAtlasSet& atlases = it->second;
            for (SpriteAtlasSet::const_iterator itAtlas = atlases.begin(); itAtlas != atlases.end(); ++itAtlas)
                if (itAtlas->IsValid())
                    availableSpriteAtlases.push_unsorted(*itAtlas);
                else
                    m_ShouldCleanup = true;
        }
    }
    availableSpriteAtlases.sort_clear_duplicates();
    if (availableSpriteAtlases.empty())
    {
        // Fail to match any available SpriteAtlas. Wait for user's action.
        AddRequestingSprite(sprite);
        return NULL;
    }
    else
    {
        if (availableSpriteAtlases.size() > 1)
        {
            core::string allAtlasesNames;
            for (SpriteAtlasSetTemp::const_iterator it = availableSpriteAtlases.begin(); it != availableSpriteAtlases.end(); ++it)
                allAtlasesNames += core::string((*it)->GetTag()) + ",";
            WarningString(FormatOrdered("Sprite {0} matches more than one atlases ({1}). Default to first atlas.", sprite->GetName(), allAtlasesNames.c_str(), NULL));
        }

        return *availableSpriteAtlases.begin();
    }
}

void SpriteAtlasManager::Register(PPtr<SpriteAtlas> spriteAtlas)
{
    if (spriteAtlas.IsNull())
        return;

    // Add it to the late bound atlases temporary stored by this manager.
    TagToSpriteAtlasArray::iterator it = m_Atlases.find(spriteAtlas->GetTag());
    if (it != m_Atlases.end())
    {
        it->second.push_unsorted(spriteAtlas);
        it->second.sort_clear_duplicates();
    }
    else
    {
        SpriteAtlasSet atlases;
        atlases.push_unsorted(spriteAtlas);
        m_Atlases[spriteAtlas->GetTag()] = atlases;
    }

    TagToSpriteArray::iterator itRequestingSprites = m_RequestingSprites.find(spriteAtlas->GetTag());
    if (itRequestingSprites != m_RequestingSprites.end())
    {
        SpritesList& sprites = itRequestingSprites->second;
        for (SpritesList::iterator it = sprites.begin(); it != sprites.end(); ++it)
        {
            if ((*it).IsValid())
                (*it)->BindAtlas(spriteAtlas);
        }
        m_RequestingSprites.erase(spriteAtlas->GetTag());
    }
}

// In the situation of late binding, Sprite always Awake without any SpriteAtlas to bound to.
// Their tags will then put to waiting list for user to take action.
void SpriteAtlasManager::AddRequestingSprite(PPtr<Sprite> sprite)
{
#if UNITY_EDITOR
    if (!IsWorldPlaying())
        return;
#endif
    if (!m_AllowRequesting)
        return;

    const dynamic_array<core::string>& tags = sprite->GetAtlasTags();
    for (dynamic_array<core::string>::const_iterator itTag = tags.begin(); itTag != tags.end(); ++itTag)
    {
        const core::string& tag = *itTag;
        TagToSpriteArray::iterator itRequestingSprites = m_RequestingSprites.find(tag);
        if (itRequestingSprites != m_RequestingSprites.end())
        {
            itRequestingSprites->second.push_back(sprite);
        }
        else
        {
            SpritesList spriteList;
            spriteList.push_back(sprite);
            m_RequestingSprites[tag] = spriteList;

            if (m_RequestingTags.find(*itTag) == m_RequestingTags.end())
                m_RequestingTags.push_unsorted(*itTag);
            m_ShouldRequest = true;
        }
    }
}

void SpriteAtlasManager::RequestAtlasViaScript()
{
#if UNITY_EDITOR
    if (!IsWorldPlaying())
        return;
#endif
    if (m_RequestingTags.size() > 0)
    {
        m_RequestingTags.sort_clear_duplicates();
        bool listenedTo = false;
        for (TagsSet::iterator it = m_RequestingTags.begin(); it != m_RequestingTags.end(); ++it)
        {
            ScriptingExceptionPtr exception = SCRIPTING_NULL;
            ScriptingInvocation invocation(GetCoreScriptingClasses().requestAtlas);
            invocation.AddString(*it);

            invocation.logException = false;
            listenedTo = invocation.Invoke<bool>(&exception);

            if (exception)
            {
                Scripting::LogException(exception, InstanceID_None, "Sprite Atlas : Exception triggering SpriteAtlasManager.atlasRequested callback.");
                break;
            }
            else if (!listenedTo)
            {
                WarningString(FormatOrdered("SpriteAtlasManager.atlasRequested wasn't listened to while {0} requested.", it->c_str(), NULL));
                break;
            }
        }
        if (listenedTo)
            m_RequestingTags.clear();

        m_ShouldRequest = false;
    }
}

void SpriteAtlasManager::CleanupInvalidAtlases()
{
    for (TagToSpriteAtlasArray::iterator it = m_Atlases.begin(); it != m_Atlases.end(); ++it)
    {
        SpriteAtlasSet& atlases = it->second;
        for (SpriteAtlasSet::iterator itAtlas = atlases.begin(); itAtlas != atlases.end();)
        {
            if (itAtlas->IsNull())
                itAtlas = atlases.erase(itAtlas);
            else
                ++itAtlas;
        }
        if (atlases.empty())
            m_Atlases.erase(it);
    }
}

#if UNITY_EDITOR
void SpriteAtlasManager::OnExitPlayMode()
{
    m_Atlases.clear();
    m_RequestingTags.clear();
    m_RequestingSprites.clear();
}

#endif
