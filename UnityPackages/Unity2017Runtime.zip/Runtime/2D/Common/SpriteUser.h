#pragma once

#include "Runtime/Utilities/NonCopyable.h"
#include "Runtime/BaseClasses/BaseObject.h"
#include "Runtime/Camera/RenderNodeQueuePrepareContext.h"
#include "Runtime/Graphics/Renderer.h"

// Common class for renderers using single sprite as primary asset. SpriteRenderer, SpriteMask etc..
class EXPORT_COREMODULE SpriteUser
{
public:

    // On Delete/Update Sprites
    virtual void OnDeleteSprite() = 0;
    virtual void OnChangeSprite() = 0;

    // Renderer Update
    template<bool kExecuteMultiThreaded>
    void PrepareCachedSprite(RenderNodeQueuePrepareThreadContext& perThreadContext);

protected:

    SpriteUser()
        : m_CachedSpritePtr(NULL)
        , m_SpriteNode(this)
#if UNITY_EDITOR
        , m_CachedSpriteUpdateRequired(false)
#endif
    {
    }

    virtual ~SpriteUser()
    {
    }

    // Handle CachedPtr
    FORCE_INLINE Sprite* GetCachedSpritePtr() const { return m_CachedSpritePtr; }
    FORCE_INLINE Sprite* GetCachedSpritePtr() { return m_CachedSpritePtr; }
    FORCE_INLINE bool IsCachedSpritePtrValid() const { return m_CachedSpritePtr != NULL; }
    FORCE_INLINE void SetCachedSpritePtr(Sprite* sprite) { m_CachedSpritePtr = sprite; }
    FORCE_INLINE void RemoveSpriteUserNode() { m_SpriteNode.RemoveFromList(); }
    FORCE_INLINE void AddSpriteUserNode()
    {
        if (m_CachedSpritePtr)
            m_CachedSpritePtr->AddSpriteUser(m_SpriteNode);
    }

#if UNITY_EDITOR
    // Set Cached Sprite Update.
    void SetCachedSpriteUpdateRequired(const bool value) { m_CachedSpriteUpdateRequired = value; }
#endif

    // On Update.
    virtual void UpdateCachedSprite(const bool updateAABB) = 0;

private:

    Sprite* m_CachedSpritePtr;
    ListNode<SpriteUser> m_SpriteNode;

#if UNITY_EDITOR
    bool m_CachedSpriteUpdateRequired;
#endif
};

// Only required for Editor where we need to update Sprite in case of Atlas use.
template<bool kExecuteMultiThreaded>
void SpriteUser::PrepareCachedSprite(RenderNodeQueuePrepareThreadContext& perThreadContext)
{
#if UNITY_EDITOR
    if (m_CachedSpriteUpdateRequired)
    {
        if (kExecuteMultiThreaded)
        {
            QueuePrepareNodeToMainThread(perThreadContext);
        }
        else
        {
            UpdateCachedSprite(false);
        }
    }
#endif
}
