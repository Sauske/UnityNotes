#include "UnityPrefix.h"
#include "Runtime/2D/Common/ScriptBindings/SpritesMarshalling.h"

namespace SpritesBindings
{
#if !ENABLE_DOTNET
    void GetPhysicsShape(Sprite* sprite, int shapeIdx, ScriptingObjectPtr physicsShapeList, ScriptingExceptionPtr* exception)
    {
        const std::vector<dynamic_array<Vector2f> >& physicsShapes = sprite->GetPhysicsShape();
        if ((shapeIdx < 0) || (shapeIdx >= physicsShapes.size()))
        {
            *exception = Scripting::CreateOutOfRangeException("Index (%d) is out of bounds (0-%d)", shapeIdx, physicsShapes.size() - 1);
            return;
        }

        const dynamic_array<Vector2f>& physicsShape = physicsShapes[shapeIdx];
        FillScriptingListFromSimpleObjects(physicsShapeList, GetCoreScriptingClasses().vector2, physicsShape);
    }

#else
    ScriptingArrayPtr GetPhysicsShape(Sprite* sprite, int shapeIdx, ScriptingExceptionPtr* exception)
    {
        const std::vector<dynamic_array<Vector2f> >& physicsShapes = sprite->GetPhysicsShape();
        if ((shapeIdx < 0) || (shapeIdx >= physicsShapes.size()))
        {
            *exception = Scripting::CreateOutOfRangeException("Index (%d) is out of bounds (0-%d)", shapeIdx, physicsShapes.size() - 1);
            return SCRIPTING_NULL;
        }

        const dynamic_array<Vector2f>& physicsShape = physicsShapes[shapeIdx];
        return CreateScriptingArray<Vector2f>(physicsShape.begin(), physicsShape.size(), GetCoreScriptingClasses().vector2);
    }

#endif

    void OverridePhysicsShapeCount(Sprite* sprite, int physicsShapeCount)
    {
        if (sprite->CanAccessFromScript(false))
        {
            sprite->SetPhysicsShapesCount(physicsShapeCount);
        }
        else
        {
            ErrorStringMsg("Not allowed to override physics shape on sprite '%s'", sprite->GetName());
        }
    }

    void OverridePhysicsShape(Sprite* sprite, ScriptingArrayPtr physicsShapeArray, int idx, ScriptingExceptionPtr* exception)
    {
        if (sprite->CanAccessFromScript(false))
        {
            int count = GetScriptingArraySize(physicsShapeArray);
            if (count > 2)
            {
                dynamic_array<Vector2f> physicsShape(kMemTempAlloc);
                ScriptingArrayToDynamicArray<Vector2f>(physicsShapeArray, physicsShape);
                sprite->SetPhysicsShape(physicsShape, idx);
            }
            else
            {
                *exception = Scripting::CreateArgumentException("Physics Shape at %d has less than 3 vertices (%d).", idx, count);
            }
        }
        else
        {
            ErrorStringMsg("Not allowed to override physics shape on sprite '%s'", sprite->GetName());
        }
    }
}
