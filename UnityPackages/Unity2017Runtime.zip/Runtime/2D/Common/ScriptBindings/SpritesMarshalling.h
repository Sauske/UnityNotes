#pragma once

#include "Runtime/Graphics/SpriteFrame.h"
#include "Runtime/Math/Vector2.h"
#include "Runtime/Scripting/ScriptingTypes.h"
#include "Runtime/Scripting/Marshalling/Marshalling.h"

namespace SpritesBindings
{
#if !ENABLE_DOTNET
    void GetPhysicsShape(Sprite* sprite, int shapeIdx, ScriptingObjectPtr physicsShapeList, ScriptingExceptionPtr* exception);
#else
    ScriptingArrayPtr GetPhysicsShape(Sprite* sprite, int shapeIdx, ScriptingExceptionPtr* exception);
#endif

    void OverridePhysicsShapeCount(Sprite* sprite, int physicsShapesCount);
    void OverridePhysicsShape(Sprite* sprite, ScriptingArrayPtr physicsShapeArray, int idx, ScriptingExceptionPtr* exception);
}
