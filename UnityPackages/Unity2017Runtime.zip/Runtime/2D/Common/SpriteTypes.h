#pragma once
#include "Runtime/Math/Vector2.h"
#include "Runtime/Math/Vector3.h"
#include "Runtime/Scripting/BindingsDefs.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Utilities/GUID.h"

enum SpritePackingMode
{
    kSPMTight = 0,
    kSPMRectangle
};

enum SpriteMeshType
{
    kSpriteMeshTypeFullRect = 0,
    kSpriteMeshTypeTight = 1
};

enum SpritePackingRotation
{
    kSPRNone = 0,
    kSPRFlipHorizontal,
    kSPRFlipVertical,
    kSPRRotate180,
    kSPRAny = 4
};

enum SpriteRenderDataMode
{
    kSpriteRenderDataModeAutoDetect,
    kSpriteRenderDataModeAtlas,
    kSpriteRenderDataModeNotAtlas
};

enum SpriteMaskInteraction
{
    kMaskInteraction_None = 0,
    kMaskInteraction_SpriteVisibleInsideMask,
    kMaskInteraction_SpriteVisibleOutsideMask,
    kMaskInteraction_Count
};

struct SpriteSettings
{
#if PLATFORM_ARCH_BIG_ENDIAN
    UInt32 reserved        : 25;
    UInt32 meshType        :  1; // SpriteMeshType
    UInt32 packingRotation :  4; // SpritePackingRotation
    UInt32 packingMode     :  1; // SpritePackingMode
    UInt32 packed          :  1; // bool
#else
    UInt32 packed          :  1; // bool
    UInt32 packingMode     :  1; // SpritePackingMode
    UInt32 packingRotation :  4; // SpritePackingRotation
    UInt32 meshType        :  1; // SpriteMeshType
    UInt32 reserved        : 25;
#endif
};

static const float kInvalidSpriteOffset = -1.0f;
typedef std::pair<UnityGUID, SInt64> SpriteRenderDataKey;

BIND_MANAGED_TYPE_NAME(SpriteMaskInteraction, UnityEngine_SpriteMaskInteraction);
