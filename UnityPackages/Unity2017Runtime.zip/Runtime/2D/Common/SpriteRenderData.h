#pragma once
#include "Configuration/UnityConfigure.h"
#include "SpriteTypes.h"
#include "Runtime/BaseClasses/ObjectDefines.h"
#include "Runtime/Graphics/Mesh/SharedMeshData.h"
#include "Runtime/Graphics/Texture2D.h"
#include "Runtime/Math/Rect.h"
#include "Runtime/Math/Vector2.h"
#include "Runtime/Math/Vector3.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Serialize/SwapEndianArray.h"
#include "Runtime/Graphics/Mesh/SharedMeshRenderingData.h"

class Sprite;

struct SpriteRenderData
{
public:
    DECLARE_SERIALIZE(SpriteRenderData)

    SpriteRenderData();
    ~SpriteRenderData();
    SpriteRenderData(const SpriteRenderData& other);
    SpriteRenderData& operator=(const SpriteRenderData& other);

    PPtr<Texture2D>           texture;
    PPtr<Texture2D>           alphaTexture;
    Rectf                     textureRect;       // In pixels (texture space). Invalid if packingMode is Tight.
    Vector2f                  textureRectOffset; // In pixels (texture space). Invalid if packingMode is Tight.
    Vector2f                  atlasRectOffset;
    Vector4f                  uvTransform; // Xmul, Xadd, Ymul, Yadd
    float                     downscaleMultiplier; // Sprite atlas's variant multiplier
    union
    {
        SpriteSettings settings;
        UInt32 settingsRaw;
    };

    void GenerateQuadMesh(const Rectf& rect, const Vector2f& rectOffset, float pixelsToUnits);
    void GenerateFullMesh(const Rectf& rect, const Vector2f& rectOffset, float pixelsToUnits, float spriteTessellationDetail, unsigned int extrude, Rectf* meshRect, bool polygonMode, std::vector<dynamic_array<Vector2f> >* customOutlines = NULL);
    void CalculateUVsIfNeeded(bool force, const Vector2f& sourcePivot, const Rectf& sourceRect);
    void CopySharedDataFrom(const SpriteRenderData& src);

    // Mesh API
    void SetVertices(const Vector2f* data, size_t count, const Sprite& sprite);
    void SetIndices(const UInt16* data, size_t count);

    // Shared data API as const, be aware that the 'Acquire' methods increment the shared mesh data's reference count so the calling code is responsible for releasing.
    SharedMeshData* AcquireWritableData();
    const SharedMeshData* AcquireReadOnlyData() const;
    SharedMeshRenderingData* AcquireRenderingData() const { m_SharedRenderingData->AddRef(); return m_SharedRenderingData; }

    bool HasMeshData() const { return m_SharedMeshData && m_SharedMeshData->GetVertexCount() > 0;  }

    void PrepareRenderingDataIfNeeded();
    void SetDirty() { m_UvCalculationPending = true; m_PreparePending = true; }
    bool IsPrepared() const { return m_SharedRenderingData != NULL && !m_PreparePending && !m_UvCalculationPending; }

    void MainThreadCleanup();
    void UnloadRenderingData();

private:
    void UnshareData();
    void UnshareRenderingData();

    SharedMeshData* m_SharedMeshData;
    SharedMeshRenderingData* m_SharedRenderingData;
    bool m_UvCalculationPending;
    bool m_PreparePending;
};
