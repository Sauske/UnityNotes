#include "UnityPrefix.h"
#include "SpriteRenderData.h"
#include "Runtime/Graphics/SpriteFrame.h"
#include "Runtime/Graphics/SpriteUtility.h"
#include "Runtime/GfxDevice/GfxDevice.h"
#include "Runtime/GfxDevice/GfxBuffer.h"
#include "Runtime/Graphics/Mesh/MeshVertexFormat.h"
#include "Runtime/Utilities/vector_utility.h"
#include "Runtime/Graphics/SpriteUtility.h"

SpriteRenderData::SpriteRenderData()
    : textureRectOffset(0, 0)
    , atlasRectOffset(kInvalidSpriteOffset, kInvalidSpriteOffset)
    , settingsRaw(0)
    , uvTransform(1, 0, 1, 0)
    , downscaleMultiplier(1.0f)
    , m_SharedMeshData(NULL)
    , m_SharedRenderingData(NULL)
    , m_UvCalculationPending(true)
    , m_PreparePending(true)
{
    m_SharedMeshData = UNITY_NEW(SharedMeshData, kMemSprites)(kMemSprites);
    m_SharedRenderingData = UNITY_NEW(SharedMeshRenderingData, kMemSprites) (kMemSprites);
}

SpriteRenderData::~SpriteRenderData()
{
    MainThreadCleanup();
}

void SpriteRenderData::MainThreadCleanup()
{
    if (m_SharedRenderingData)
    {
        m_SharedRenderingData->Unload();
    }
    SAFE_RELEASE(m_SharedMeshData);
    SAFE_RELEASE(m_SharedRenderingData);
}

void SpriteRenderData::UnloadRenderingData()
{
    UnshareRenderingData();
    if (m_SharedRenderingData)
        m_SharedRenderingData->Unload();
    m_PreparePending = true;
    m_UvCalculationPending = true;
}

SpriteRenderData::SpriteRenderData(const SpriteRenderData& other)
    : texture(other.texture)
    , alphaTexture(other.alphaTexture)
    , textureRect(other.textureRect)
    , textureRectOffset(other.textureRectOffset)
    , atlasRectOffset(other.atlasRectOffset)
    , settingsRaw(other.settingsRaw)
    , uvTransform(other.uvTransform)
    , downscaleMultiplier(other.downscaleMultiplier)
    , m_SharedMeshData(other.m_SharedMeshData)
    , m_SharedRenderingData(other.m_SharedRenderingData)
    , m_UvCalculationPending(other.m_UvCalculationPending)
    , m_PreparePending(other.m_PreparePending)
{
    if (m_SharedMeshData)
        m_SharedMeshData->AddRef();
    if (m_SharedRenderingData)
        m_SharedRenderingData->AddRef();
}

SpriteRenderData& SpriteRenderData::operator=(const SpriteRenderData& other)
{
    if (this != &other)
    {
        texture = other.texture;
        alphaTexture = other.alphaTexture;
        textureRect = other.textureRect;
        textureRectOffset = other.textureRectOffset;
        atlasRectOffset = other.atlasRectOffset;
        settingsRaw = other.settingsRaw;
        uvTransform = other.uvTransform;
        downscaleMultiplier = other.downscaleMultiplier;
        m_UvCalculationPending = other.m_UvCalculationPending;
        m_PreparePending = other.m_PreparePending;

        if (other.m_SharedMeshData)
            other.m_SharedMeshData->AddRef();
        if (other.m_SharedRenderingData)
            other.m_SharedRenderingData->AddRef();
        SAFE_RELEASE(m_SharedMeshData);
        SAFE_RELEASE(m_SharedRenderingData);
        m_SharedMeshData = other.m_SharedMeshData;
        m_SharedRenderingData = other.m_SharedRenderingData;
    }

    return *this;
}

void SpriteRenderData::PrepareRenderingDataIfNeeded()
{
    ASSERT_RUNNING_ON_MAIN_THREAD;

    if (true == m_PreparePending)
    {
        UnshareRenderingData();
        if (m_SharedRenderingData)
            m_SharedRenderingData->Unload();

        // now convert everything from SharedData to this rendering data.
        const SharedMeshData* sharedData = AcquireReadOnlyData();
        GfxDevice& device = GetUncheckedGfxDevice();

        const StreamInfoArray& streams = sharedData->GetVertexData().GetStreams();
        const size_t vertexCount = sharedData->GetVertexCount();
        const UInt8* buffer = sharedData->GetVertexData().GetDataPtr();

        UInt8 vertexStreamCount = 0;
        for (int s = 0; s < kMaxVertexStreams; ++s)
        {
            const StreamInfo& streamInfo = streams[s];
            if (streamInfo.channelMask != 0 && vertexCount > 0)
            {
                VertexStreamSource& uploadedStream = m_SharedRenderingData->GetVertexStreams()[s];
                if (uploadedStream.buffer == NULL)
                {
                    GfxBufferDesc vbDesc(vertexCount * streamInfo.stride, kGfxBufferTargetVertex, kGfxBufferModeImmutable, kGfxBufferLabelDefault);
                    uploadedStream.buffer = device.CreateBuffer(vbDesc, buffer + streamInfo.offset, kGfxUpdateBufferAcquiredPointer);
                    #if GFX_HAS_OBJECT_LABEL
                    device.SetBufferName(uploadedStream.buffer, "Sprite-Mesh-VB");
                    #endif
                }
                else
                {
                    device.UpdateBuffer(
                        uploadedStream.buffer,
                        buffer + streamInfo.offset,
                        kGfxUpdateBufferAcquiredPointer);
                }

                uploadedStream.stride = streamInfo.stride;
                vertexStreamCount++;
            }
            else
                m_SharedRenderingData->UnloadVertexStream(s);
        }

        m_SharedRenderingData->SetMeshVertexFormat(GetMeshVertexFormatManager().GetMeshVertexFormat(sharedData->GetVertexData().GetChannels()));

        if (m_SharedMeshData->GetTotalIndexCount() > 0)
        {
            const void* srcIndices = array_data_or_null_if_empty(m_SharedMeshData->GetIndexBuffer());
            int indexCount = m_SharedMeshData->GetTotalIndexCount();

            GfxBufferDesc ibDesc(indexCount * sizeof(UInt16), kGfxBufferTargetIndex, kGfxBufferModeImmutable, kGfxBufferLabelDefault);
            m_SharedRenderingData->CreateOrUpdateIndexBuffer(ibDesc, srcIndices, kGfxUpdateBufferAcquiredPointer);
            #if GFX_HAS_OBJECT_LABEL
            device.SetBufferName(m_SharedRenderingData->GetIndexBuffer(), "Sprite-Mesh-IB");
            #endif
        }
        else
            m_SharedRenderingData->UnloadIndexBuffer();

        SAFE_RELEASE(sharedData);
        m_PreparePending = false;
    }
}

void SpriteRenderData::GenerateFullMesh(const Rectf& rect, const Vector2f& rectOffset, float pixelsToUnits, float spriteTessellationDetail, unsigned int extrude, Rectf* meshRect, bool polygonMode, std::vector<dynamic_array<Vector2f> >* customOutlines /*= NULL*/)
{
    SharedMeshData* sharedMeshData = AcquireWritableData();

    GenerateSpriteOutline(texture, pixelsToUnits, rect, rectOffset,
        spriteTessellationDetail, kSpriteDefaultAlphaTolerance, true, extrude, kPathEmbed, polygonMode,
        customOutlines, sharedMeshData, meshRect, &uvTransform);

    // Fall back to a quad when we fail to generate mesh, probably due to all the pixels are transparent.
    if (sharedMeshData->GetTotalIndexCount() == 0)
    {
        sharedMeshData->GetSubMeshes().clear();
        GenerateQuadMesh(rect, rectOffset, pixelsToUnits);
    }


    SAFE_RELEASE(sharedMeshData);
    m_PreparePending = true;
    m_UvCalculationPending = true;
}

void SpriteRenderData::GenerateQuadMesh(const Rectf& rect, const Vector2f& rectOffset, float pixelsToUnits)
{
    const float halfW = rect.width * 0.5f;
    const float halfH = rect.height * 0.5f;

    uvTransform.x = (pixelsToUnits);
    uvTransform.y = (rect.x + halfW + rectOffset.x);
    uvTransform.z = (pixelsToUnits);
    uvTransform.w = (rect.y + halfH + rectOffset.y);

    const Vector2f uv(0.0f, 0.0f); // BUGFIX 582080: UVs calculated on Awake

    SharedMeshData* sharedMeshData = AcquireWritableData();

    SetSpriteMeshVertexCount(sharedMeshData, 4);
    SetSpriteMeshIndexCount(sharedMeshData, 6);

    StrideIterator<Vector3f> vertices = sharedMeshData->GetVertexData().MakeStrideIterator<Vector3f>(kShaderChannelVertex);
    StrideIterator<Vector2f> vertsUvs = sharedMeshData->GetVertexData().MakeStrideIterator<Vector2f>(kShaderChannelTexCoord0);

    vertices[0] = Vector3f((-halfW - rectOffset.x) / pixelsToUnits, (halfH - rectOffset.y) / pixelsToUnits, 0.0f);
    vertsUvs[0] = uv;
    vertices[1] = Vector3f((halfW - rectOffset.x) / pixelsToUnits, (halfH - rectOffset.y) / pixelsToUnits, 0.0f);
    vertsUvs[1] = uv;
    vertices[2] = Vector3f((-halfW - rectOffset.x) / pixelsToUnits, (-halfH - rectOffset.y) / pixelsToUnits, 0.0f);
    vertsUvs[2] = uv;
    vertices[3] = Vector3f((halfW - rectOffset.x) / pixelsToUnits, (-halfH - rectOffset.y) / pixelsToUnits, 0.0f);
    vertsUvs[3] = uv;

    UInt16* indices = reinterpret_cast<UInt16*>(&sharedMeshData->GetIndexBuffer()[0]);
    indices[0] = 0;
    indices[1] = 1;
    indices[2] = 2;
    indices[3] = 2;
    indices[4] = 1;
    indices[5] = 3;

    // create a submesh for it
    SubMesh subMesh;
    subMesh.vertexCount = 4;
    subMesh.indexCount = 6;
    subMesh.topology = kPrimitiveTriangles;
    AssertMsg(sharedMeshData->GetSubMeshes().size() == 0, "There must not be another submesh, probably sprite initialized twice.");
    sharedMeshData->GetSubMeshes().push_back(subMesh);

    SAFE_RELEASE(sharedMeshData);
    m_PreparePending = true;
    m_UvCalculationPending = true;
}

void SpriteRenderData::CalculateUVsIfNeeded(bool force, const Vector2f& sourcePivot, const Rectf& sourceRect)
{
    ASSERT_RUNNING_ON_MAIN_THREAD;

    if ((!m_UvCalculationPending && !force) || !texture.IsValid())
        return;

    SharedMeshData* sharedMeshData = AcquireWritableData();
    StrideIterator<Vector3f> pos = sharedMeshData->GetVertexData().MakeStrideIterator<Vector3f>(kShaderChannelVertex);
    StrideIterator<Vector2f> uvStart = sharedMeshData->GetVertexData().MakeStrideIterator<Vector2f>(kShaderChannelTexCoord0);
    StrideIterator<Vector2f> uvEnd = sharedMeshData->GetVertexData().MakeEndIterator<Vector2f>(kShaderChannelTexCoord0);

    RecalculateUVs(
        uvStart,
        uvEnd,
        pos,
        *texture,
        sourcePivot,
        sourceRect,
        uvTransform,
        textureRect,
        this->textureRectOffset,
        (SpritePackingRotation)settings.packingRotation,
        downscaleMultiplier);

    SAFE_RELEASE(sharedMeshData);

    m_PreparePending = true;
    m_UvCalculationPending = false;
}

void SpriteRenderData::CopySharedDataFrom(const SpriteRenderData& srcRD)
{
    const SharedMeshData* srcSRD = srcRD.AcquireReadOnlyData();
    if (srcSRD == NULL)
        return;
    SAFE_RELEASE(m_SharedMeshData);
    m_SharedMeshData = UNITY_NEW(SharedMeshData, kMemSprites)(*srcSRD);
    SAFE_RELEASE(srcSRD);

    m_PreparePending = true;
    m_UvCalculationPending = false;
}

const SharedMeshData* SpriteRenderData::AcquireReadOnlyData() const
{
    AssertMsg(m_SharedMeshData != NULL, "Shared Mesh Data is Null");
    m_SharedMeshData->AddRef();
    return m_SharedMeshData;
}

SharedMeshData* SpriteRenderData::AcquireWritableData()
{
    AssertMsg(m_SharedMeshData != NULL, "Shared Mesh Data is Null");
    UnshareData();
    m_SharedMeshData->AddRef();
    return m_SharedMeshData;
}

void SpriteRenderData::UnshareData()
{
#if ENABLE_MULTITHREADED_CODE
    if (m_SharedMeshData && m_SharedMeshData->GetRefCount() != 1)
    {
        // Someone else holds a reference to the data and expects it to be immutable.
        // Create our own copy before we make any changes to it.
        SharedMeshData* newSharedData = UNITY_NEW(SharedMeshData, kMemSprites)(*m_SharedMeshData);
        SAFE_RELEASE(m_SharedMeshData);
        m_SharedMeshData = newSharedData;
    }
#endif
}

void SpriteRenderData::UnshareRenderingData()
{
#if ENABLE_MULTITHREADED_CODE
    if (m_SharedRenderingData && m_SharedRenderingData->GetRefCount() != 1)
    {
        // Someone else holds a reference to the data and expects it to be immutable.
        // Create our own copy before we make any changes to it.
        SharedMeshRenderingData* newSharedData = UNITY_NEW(SharedMeshRenderingData, kMemVertexData) (kMemVertexData);
        SAFE_RELEASE(m_SharedRenderingData);
        m_SharedRenderingData = newSharedData;
    }
#endif
}

void SpriteRenderData::SetVertices(const Vector2f* data, size_t count, const Sprite& sprite)
{
    const float pixelsToUnits = 1.0f / sprite.GetPixelsToUnits();
    const Vector2f& pivot = sprite.GetPivotInPixels();

    SharedMeshData* sharedMeshData = AcquireWritableData();
    SetSpriteMeshVertexCount(sharedMeshData, count);
    StrideIterator<Vector3f> vertices = sharedMeshData->GetVertexData().MakeStrideIterator<Vector3f>(kShaderChannelVertex);

    for (size_t i = 0; i < count; ++i)
    {
        vertices[i] = Vector3f((data[i].x - pivot.x) * pixelsToUnits, (data[i].y - pivot.y) * pixelsToUnits, 0.0f);
    }

    if (sharedMeshData->GetSubMeshes().size() > 0)
        sharedMeshData->GetSubMeshes()[0].vertexCount = count;

    SAFE_RELEASE(sharedMeshData);
    m_PreparePending = true;
    m_UvCalculationPending = true;
}

void SpriteRenderData::SetIndices(const UInt16* data, size_t count)
{
    SharedMeshData* sharedMeshData = AcquireWritableData();
    SetSpriteMeshIndexCount(sharedMeshData, count);

    if (count > 0)
    {
        UInt16* indices = reinterpret_cast<UInt16*>(&sharedMeshData->GetIndexBuffer()[0]);
        memcpy(indices, data, count * sizeof(UInt16));
    }

    if (sharedMeshData->GetSubMeshes().size() > 0)
        sharedMeshData->GetSubMeshes()[0].indexCount = count;

    SAFE_RELEASE(sharedMeshData);
    m_PreparePending = true;
}

INSTANTIATE_TEMPLATE_TRANSFER(SpriteRenderData);

//////////////////////////////////////////////////////////////////////////
// Is only used for Backward Compatibility. Not to be used elsewhere.

struct SpriteVertex
{
    DECLARE_SERIALIZE_NO_PPTR(SpriteVertex)

    Vector3f pos;
    Vector2f uv;
};

template<class TransferFunction>
void SpriteVertex::Transfer(TransferFunction& transfer)
{
    // 2014.01.21 - v2: UVs don't get stored
    //              v1: Original implementation
    transfer.SetVersion(2);

    TRANSFER(pos);
    if (transfer.IsOldVersion(1))
        TRANSFER(uv);
}

//////////////////////////////////////////////////////////////////////////

template<class TransferFunction>
void SpriteRenderData::Transfer(TransferFunction& transfer)
{
    transfer.SetVersion(2);

    TRANSFER(texture);
    TRANSFER(alphaTexture);

    if (transfer.IsReading() || transfer.IsWriting())
        UnshareData();

    if (transfer.ConvertEndianess() && transfer.IsWriting())
    {
        m_SharedMeshData->GetVertexData().SwapEndianess();
        SwapEndianArray(m_SharedMeshData->GetIndexBuffer().begin(), kMesh16BitIndexSize, m_SharedMeshData->GetTotalIndexCount());
    }

    transfer.Transfer(m_SharedMeshData->GetSubMeshes(), "m_SubMeshes", kHideInEditorMask);

    // In 5.6 we introduced storing Sprite Data in VertexData structure. (Previously just dynamic_arrays)
    // To provide backward-compatibility, check if m_SubMeshes is not read and read as dynamic_arrays.
    if (transfer.IsVersionSmallerOrEqual(1) && transfer.IsReading() && !transfer.DidReadLastProperty())
    {
        dynamic_array<SpriteVertex> spriteVertices(kMemTempAlloc);
        dynamic_array<UInt16> spriteIndices(kMemTempAlloc);
        TRANSFER_WITH_NAME(spriteVertices, "vertices");
        TRANSFER_WITH_NAME(spriteIndices, "indices");

        UInt32 vertexCount = spriteVertices.size();
        UInt32 indexCount = spriteIndices.size();

        if (vertexCount && indexCount)
        {
            SetSpriteMeshIndexCount(m_SharedMeshData, indexCount);
            SetSpriteMeshVertexCount(m_SharedMeshData, vertexCount);

            SharedMeshData::IndexContainer& indices = m_SharedMeshData->GetIndexBuffer();
            memcpy(indices.begin(), spriteIndices.begin(), indexCount * sizeof(UInt16));

            StrideIterator<Vector3f> dstPos = m_SharedMeshData->GetVertexData().MakeStrideIterator<Vector3f>(kShaderChannelVertex);
            StrideIterator<Vector2f> dstUv0 = m_SharedMeshData->GetVertexData().MakeStrideIterator<Vector2f>(kShaderChannelTexCoord0);

            dynamic_array<SpriteVertex>::const_iterator vertItr = spriteVertices.begin();
            for (; vertItr != spriteVertices.end(); ++vertItr, ++dstPos, ++dstUv0)
            {
                *dstPos = (*vertItr).pos;
                *dstUv0 = (*vertItr).uv;
            }

            // Add a Submesh.
            SubMesh subMesh;
            subMesh.vertexCount = vertexCount;
            subMesh.indexCount = indexCount;
            subMesh.topology = kPrimitiveTriangles;
            m_SharedMeshData->GetSubMeshes().clear();
            m_SharedMeshData->GetSubMeshes().push_back(subMesh);
        }
    }
    else
    {
        transfer.Transfer(m_SharedMeshData->GetIndexBuffer(), "m_IndexBuffer", kHideInEditorMask);
        transfer.Transfer(m_SharedMeshData->GetVertexData(), "m_VertexData", kHideInEditorMask);
    }

    if (transfer.ConvertEndianess() && transfer.IsWriting())
    {
        m_SharedMeshData->GetVertexData().SwapEndianess();
        SwapEndianArray(m_SharedMeshData->GetIndexBuffer().begin(), kMesh16BitIndexSize, m_SharedMeshData->GetTotalIndexCount());
    }

    transfer.Align();
    TRANSFER(textureRect);
    TRANSFER(textureRectOffset);
    TRANSFER(atlasRectOffset);
    TRANSFER(settingsRaw);
    TRANSFER(uvTransform);
    TRANSFER(downscaleMultiplier);
}
