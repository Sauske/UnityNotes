#include "UnityPrefix.h"
#include "StackAllocator.h"

#include "Runtime/Allocator/MemoryManager.h"
#include "Runtime/Profiler/MemoryProfiler.h"
#include "Runtime/Profiler/Profiler.h"
#if DEBUG_STACK_LEAK
#include "Runtime/Diagnostics/Stacktrace.h"
#endif

PROFILER_WARNING(gTempAllocOverflow, "TempAlloc.Overflow", kProfilerInternal);

StackAllocator::StackAllocator(size_t blockSize, MemLabelId fallbackMemLabel, const char* name)
    : BaseAllocator(name)
    , m_Block(NULL)
    , m_BlockSize(blockSize)
    , m_RequestedBlockSize(blockSize)
    , m_FallbackLabel(fallbackMemLabel)
    , m_LastAlloc(NULL)
{
#if ENABLE_MEMORY_MANAGER
    m_Block = MemoryManager::LowLevelAllocate(m_BlockSize);
#else
    m_Block = malloc(m_BlockSize);
#endif

    m_TotalReservedBytes = blockSize;
}

StackAllocator::~StackAllocator()
{
    // Temporarily comment out this assert to keep ABV green. Will turn it back on when leaks in user code are eliminated.
    //Assert(m_LastAlloc == NULL);

#if ENABLE_MEMORY_MANAGER
    MemoryManager::LowLevelFree(m_Block, m_BlockSize);
#else
    free(m_Block);
#endif
}

void* StackAllocator::Allocate(size_t size, int align)
{
    //1 byte alignment doesn't work for webgl; this is a fix(ish)....
#if UNITY_NO_UNALIGNED_MEMORY_ACCESS
    if (align % 8 != 0)
        align = 8;
#endif

    const size_t alignmask = align - 1;

    // Make header size a multiple
    size_t alignedHeaderSize = (GetHeaderSize() + alignmask) & ~alignmask;
    size_t paddedSize = (size + alignedHeaderSize + alignmask) & ~alignmask;

    void* ptr;
    void* freePtr = AlignPtr(GetBlockFreePtr(), align);
    size_t usedSize = static_cast<char*>(freePtr) - static_cast<char*>(m_Block);
    if (usedSize < m_BlockSize && (m_BlockSize - usedSize) >= paddedSize)
    {
        // User ptr
        ptr = static_cast<char*>(freePtr) + alignedHeaderSize;

        // Header
        Header* h = GetHeader(ptr);
        h->size = size;
        h->deleted = 0;
        h->prevPtr = m_LastAlloc;
#if DEBUG_STACK_LEAK
        GetStacktrace(h->callstack, 20, 5);
#endif

        m_LastAlloc = ptr;

        RegisterAllocationData(size, GetHeaderSize());
    }
    else
    {
        PROFILER_AUTO(gTempAllocOverflow, NULL);

        // Spilled over. We have to allocate the memory default alloc
        BaseAllocator* allocator = GetMemoryManager().GetAllocator(m_FallbackLabel);
        align = MaxAlignment(align, kDefaultMemoryAlignment);
        ptr = allocator->Allocate(size, align);
    }

    return ptr;
}

void* StackAllocator::Reallocate(void* p, size_t size, int align)
{
#if UNITY_NO_UNALIGNED_MEMORY_ACCESS
    // The passed in align parameter is not always sufficient for webgl.
    // Enforce 8 byte alignment.
    if (align % 8 != 0)
        align = 8;
#endif

    if (p == NULL)
        return Allocate(size, align);

    void* freePtr = AlignPtr(GetBlockFreePtr(), align);
    size_t usedSize = static_cast<char*>(freePtr) - static_cast<char*>(m_Block);
    size_t freeSize = usedSize <= m_BlockSize ? m_BlockSize - usedSize : 0;

    void* newPtr = NULL;

    if (InBlock(p))
    {
        size_t oldSize = GetPtrSize(p);
        if ((p == m_LastAlloc || oldSize >= size) &&
            AlignPtr(p, align) == p &&
            oldSize + freeSize > size)
        {
            // just expand the top allocation of the stack to the realloc amount
            newPtr = p;

            Header* h = GetHeader(p);
            h->size = size;
            RegisterDeallocationData(oldSize, 0);
            RegisterAllocationData(size, 0);
        }
        else
        {
            newPtr = Allocate(size, align);
            if (newPtr != NULL)
                memcpy(newPtr, p, std::min(size, oldSize));
            Deallocate(p);
        }
    }
    else
    {
        PROFILER_AUTO(gTempAllocOverflow, NULL);

        BaseAllocator* allocator = GetMemoryManager().GetAllocator(m_FallbackLabel);
        align = MaxAlignment(align, kDefaultMemoryAlignment);
        newPtr = allocator->Reallocate(p, size, align);
    }

    return newPtr;
}

bool StackAllocator::TryDeallocate(void* p)
{
    if (p == NULL)
        return true;

    if (p == m_LastAlloc)
    {
        const bool isDeleted = IsDeleted(p);
        AssertMsg(!isDeleted, "Trying to free already freed memory in StackAllocator!");
        RegisterDeallocationData(GetPtrSize(p), GetHeaderSize());
        SetDeleted(p);
        do
        {
            m_LastAlloc = GetPrevAlloc(m_LastAlloc);
        }
        while (m_LastAlloc != NULL && IsDeleted(m_LastAlloc));
    }
    else if (InBlock(p))
    {
        const bool isDeleted = IsDeleted(p);
        AssertMsg(!isDeleted, "Trying to free already freed memory in StackAllocator!");
        RegisterDeallocationData(GetPtrSize(p), GetHeaderSize());
        SetDeleted(p);
    }
    else
    {
        BaseAllocator* allocator = GetMemoryManager().GetAllocator(m_FallbackLabel);
        allocator->Deallocate(p);
    }

    return true;
}

void StackAllocator::SetRequestedSize(size_t size)
{
    //  If stack is empty, set its new size immediately
    if (!m_LastAlloc)
        SetBlockSize(size);
    m_RequestedBlockSize = size;
}

void StackAllocator::FrameMaintenance(bool cleanup)
{
    //  Only do the free/alloc work if its required
    if (m_RequestedBlockSize != m_BlockSize)
    {
        // We should only resize if the stack allocator is empty
        if (m_LastAlloc != NULL)
            return;

        SetBlockSize(m_RequestedBlockSize);
    }
}

bool StackAllocator::IsOverflowAllocation(const void* p) const
{
    // Pointer in block is checked by Contains in the .h file. Only if it is an overflow allocation, this is called
    BaseAllocator* allocator = GetMemoryManager().GetAllocator(m_FallbackLabel);
    return allocator->Contains(p);
}

void StackAllocator::FreeAllAllocations()
{
    // if there are no current block allocations, nothing else to do
    if (m_LastAlloc == NULL)
        return;

    // step back through the stack, deleting every block that isn't already
    // deleted.
    const void* ptr = m_LastAlloc;
    while (ptr != NULL)
    {
        if (!IsDeleted(ptr))
        {
            RegisterDeallocationData(GetPtrSize(ptr), GetHeaderSize());
            SetDeleted(ptr);
        }
        ptr = GetPrevAlloc(ptr);
    }

    // mark stack as now empty
    m_LastAlloc = NULL;
}

void StackAllocator::SetBlockSize(size_t blockSize)
{
    Assert(GetAllocatedMemorySize() == 0);

#if ENABLE_MEMORY_MANAGER
    m_Block = MemoryManager::LowLevelReallocate(m_Block, blockSize, m_BlockSize);
#else
    m_Block = realloc(m_Block, m_BlockSize);
#endif
    m_BlockSize = blockSize;
    m_TotalReservedBytes = blockSize;
}

#if USE_MEMORY_DEBUGGING || ENABLE_MEM_PROFILER
void StackAllocator::WalkAllocations(BaseAllocator::WalkAllocationsCallback callback) const
{
    const void* ptr = m_LastAlloc;
    while (ptr != NULL)
    {
        const Header* h = GetHeader(ptr);
        if (!h->deleted)
        {
            callback(ptr, h->size,
#if DEBUG_STACK_LEAK
                h->callstack, 20
#else
                NULL, 0
#endif
                );
        }
        ptr = h->prevPtr;
    }
}

#endif
