#include "UnityPrefix.h"
#include "PageAllocator.h"
#include "Runtime/Utilities/MemoryUtilities.h"

AtomicPageAllocator::AtomicPageAllocator(const char* subSystemName, MemLabelRef label)
    : m_Memlabel(label)
{
    m_SubSystemName = subSystemName;
    m_ActivePages = 0;
}

AtomicPageAllocator::~AtomicPageAllocator()
{
    Clear();
}

void AtomicPageAllocator::Clear()
{
    for (int i = 0; i < m_ActivePages; i++)
        UNITY_FREE(m_Memlabel, m_Pages[i]);
    m_ActivePages = 0;
}

void* AtomicPageAllocator::AllocatePage(size_t pageSize)
{
    int currentPage = atomic_fetch_add_explicit(&m_ActivePages, 1, ::memory_order_relaxed);

    if (currentPage >= PerThreadPageAllocator::kPageCount)
    {
        FatalErrorMsg("%s Page Allocator out of memory. Maximum allowed memory: %s", m_SubSystemName, FormatBytes(PerThreadPageAllocator::kMaxMem).c_str());
        return NULL;
    }

    // Align to cacheline size so that if sub-allocations are aligned,
    // we can guarantee minimum cacheline reads.
    void* page = UNITY_MALLOC_ALIGNED(m_Memlabel, pageSize, PLATFORM_CPU_CACHE_LINE_SIZE);
    m_Pages[currentPage] = page;
    return page;
}

PerThreadPageAllocator::PerThreadPageAllocator()
    : m_Start(NULL), m_Offset(0), m_Allocator(NULL), m_CurrentPageSize(0)
{}

PerThreadPageAllocator::PerThreadPageAllocator(AtomicPageAllocator& pageAllocator)
    : m_Start(NULL), m_Offset(0), m_Allocator(NULL), m_CurrentPageSize(0)
{
    Initialize(pageAllocator);
}

void PerThreadPageAllocator::AcquireNewPage(size_t pageSize)
{
    m_Offset = 0;
    m_Start = (UInt8*)m_Allocator->AllocatePage(pageSize);
    m_CurrentPageSize = pageSize;
}

void PerThreadPageAllocator::Initialize(AtomicPageAllocator& pageAllocator)
{
    m_Allocator = &pageAllocator;
    AcquireNewPage(kPageSize);
}
