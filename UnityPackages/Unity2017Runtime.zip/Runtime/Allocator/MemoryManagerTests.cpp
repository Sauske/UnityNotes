#include "UnityPrefix.h"
#include "Runtime/Allocator/MemoryManager.h"

#if ENABLE_UNIT_TESTS && ENABLE_MEMORY_MANAGER

#include "Runtime/Testing/Testing.h"
#include "Runtime/Testing/MultiThreadedTestFixture.h"

#include "Runtime/Allocator/DynamicHeapAllocator.h"
#include "Runtime/Allocator/DualThreadAllocator.h"
#include "Runtime/Allocator/BucketAllocator.h"
#include "Runtime/Allocator/ThreadsafeLinearAllocator.h"
#include "Runtime/Allocator/UnityDefaultAllocator.h"
#include "Runtime/Threads/Thread.h"


INTEGRATION_TEST_SUITE(MemoryManager)
{
    struct VirtualTestStructA
    {
        VirtualTestStructA() { ptrA = UNITY_MALLOC(kMemDefault, 1024 * 1024); }
        virtual ~VirtualTestStructA() { UNITY_FREE(kMemDefault, ptrA); }
        void* ptrA;
    };
    struct VirtualTestStructB : public VirtualTestStructA
    {
        VirtualTestStructB() { ptrB = UNITY_MALLOC(kMemDefault, 1024 * 1024); }
        virtual ~VirtualTestStructB() { UNITY_FREE(kMemDefault, ptrB); }
        void* ptrB;
    };
    struct TestStruct
    {
        TestStruct() { ptr = UNITY_MALLOC(kMemDefault, 1024 * 1024); }
        ~TestStruct() { UNITY_FREE(kMemDefault, ptr); }
        void* ptr;
    };

#if ENABLE_MEM_PROFILER && !PLATFORM_PS4
    TEST(MemoryManager_NewDelete)
    {
        // an allocation on the main thread will clear anything pending in DelayedPointerDeletionManager
        TestStruct* test = UNITY_NEW(TestStruct, kMemDefault);
        UNITY_DELETE(test, kMemDefault);

        size_t memoryBefore = GetMemoryManager().GetAllocator(kMemDefault)->GetAllocatedMemorySize();

        test = UNITY_NEW(TestStruct, kMemDefault);
        // less or equal, since some platforms have larger default alignment that sizeof(void*)
        CHECK(memoryBefore + sizeof(TestStruct) + 1024 * 1024 <= GetMemoryManager().GetAllocator(kMemDefault)->GetAllocatedMemorySize());
        UNITY_DELETE(test, kMemDefault);

        CHECK_EQUAL(memoryBefore, GetMemoryManager().GetAllocator(kMemDefault)->GetAllocatedMemorySize());

        VirtualTestStructA* testA = (VirtualTestStructA*)UNITY_NEW(VirtualTestStructB, kMemDefault);
        UNITY_DELETE(testA, kMemDefault);

        CHECK_EQUAL(memoryBefore, GetMemoryManager().GetAllocator(kMemDefault)->GetAllocatedMemorySize());

        /*  This will fail the tests because of theFatalError in out of mem - but good for testing the OOM message
            void* outofmem = UNITY_MALLOC(kMemDefault,((size_t)-1) - 1024); // has to be room for headers etc
            CHECK_EQUAL((int)outofmem, 0);
            CHECK_EQUAL(memoryBefore, GetMemoryManager().GetAllocator(kMemDefault)->GetAllocatedMemorySize());
            UNITY_FREE(kMemDefault, outofmem);*/
    }
#endif // ENABLE_MEM_PROFILER

#if SUPPORT_THREADS
    class NewDeleteThreadedTestFixture : public MultiThreadedTestFixture
    {
    public:
        NewDeleteThreadedTestFixture()
            : MultiThreadedTestFixture(4)
            , m_memoryBefore(0)
        {
        }

    private:
        virtual void Before()
        {
            m_memoryBefore = GetMemoryManager().GetAllocatedMemory(kMemDefault);
        }

        virtual void ThreadFunc(size_t threadIdx)
        {
            for (int i = 0; i < 100; ++i)
            {
                VirtualTestStructA* ptr = UNITY_NEW(VirtualTestStructA, kMemDefault);
                UNITY_DELETE(ptr, kMemDefault);
            }
        }

        virtual void After()
        {
            const size_t memoryAfter = GetMemoryManager().GetAllocatedMemory(kMemDefault);
            CHECK_EQUAL(m_memoryBefore, memoryAfter);
        }

    private:
        size_t m_memoryBefore;
    };

    TEST_FIXTURE(NewDeleteThreadedTestFixture, NewDeleteThreaded)
    {
        Run();
    }
#endif

    TEST(MemoryManager_CanAllocate)
    {
        UnityDefaultAllocator<LowLevelAllocator>* testAlloc = new UnityDefaultAllocator<LowLevelAllocator>("TestAlloc");
        MemLabelId testAllocLabel = GetMemoryManager().AddCustomAllocator(testAlloc);
        void* ptr = GetMemoryManager().Allocate(1024, 1, testAllocLabel);

        int requestedSize = testAlloc->GetAllocatedMemorySize();
        int overhead = testAlloc->GetBookKeepingMemorySize();
        int overheadSize = testAlloc->GetOverheadSize(ptr);

        CHECK_EQUAL(1024, requestedSize);
        int page4size = 1 << (8 - StaticLog2<kDefaultMemoryAlignment>::value);
        CHECK_EQUAL(overheadSize + (128 + 1 + 128 + 1 + 32 + 1 + page4size + 1) * sizeof(int*), overhead);

        GetMemoryManager().Deallocate(ptr);

        requestedSize = testAlloc->GetAllocatedMemorySize();
        overhead = testAlloc->GetBookKeepingMemorySize();

        CHECK_EQUAL(0, requestedSize);
        CHECK_EQUAL(0, overhead);

        GetMemoryManager().RemoveCustomAllocator(testAllocLabel);
    }

    TEST(MemoryManager_CanAllocateWithSize0)
    {
        int oldRequestedSize = GetMemoryManager().GetTotalAllocatedMemory();
        void* ptr = GetMemoryManager().Allocate(0, kDefaultMemoryAlignment, kMemDefault);
        GetMemoryManager().Deallocate(ptr);

        int requestedSize = GetMemoryManager().GetTotalAllocatedMemory();

        CHECK_EQUAL(oldRequestedSize, requestedSize);
    }

    TEST(MemoryManager_CanAllocateAligned)
    {
        BaseAllocator* testAlloc = new UnityDefaultAllocator<LowLevelAllocator>("TestAlloc");
        MemLabelId testAllocLabel = GetMemoryManager().AddCustomAllocator(testAlloc);
        for (int i = 0; i < 100; i++)
        {
            int size = 1024 + ((i * 20457) & 1023);
            int align = 1 << (1 + ((i * 3) & 7));
            void* ptr = GetMemoryManager().Allocate(size, align, testAllocLabel);
            ((int*)ptr)[0] = 0x89ABCDEF;
            int requestedSize = testAlloc->GetAllocatedMemorySize();

            CHECK_EQUAL(size, requestedSize);
            CHECK_EQUAL(0, ((intptr_t)ptr) & (align - 1));

            int newsize = 1024 + ((i * 236047) & 1023);
            ptr = GetMemoryManager().Reallocate(ptr, newsize, align, testAllocLabel);

            requestedSize = testAlloc->GetAllocatedMemorySize();

            CHECK_EQUAL(0x89ABCDEF, ((int*)ptr)[0]);
            CHECK_EQUAL(newsize, requestedSize);
            CHECK_EQUAL(0, ((intptr_t)ptr) & (align - 1));

            GetMemoryManager().Deallocate(ptr);

            requestedSize = testAlloc->GetAllocatedMemorySize();

            CHECK_EQUAL(0, requestedSize);
        }
        int requestedSize = testAlloc->GetAllocatedMemorySize();
        int overhead = testAlloc->GetBookKeepingMemorySize();

        CHECK_EQUAL(0, requestedSize);
        CHECK_EQUAL(0, overhead);

        GetMemoryManager().RemoveCustomAllocator(testAllocLabel);
    }

    TEST(MemoryManager_CanTempAllocate)
    {
        GetMemoryManager().FrameMaintenance();
        void* fillptr = UNITY_MALLOC(kMemTempAlloc, 128);
        for (int i = 0; i < 1000; i++)
        {
            void* ptr = UNITY_MALLOC_ALIGNED(kMemTempAlloc, 128, 16);
            UNITY_FREE(kMemTempAlloc, ptr);
        }

        void** ptrArray = (void**)UNITY_MALLOC(kMemTempAlloc, 256 * sizeof(void*));
        for (int i = 0; i < 256; i++)
        {
            ptrArray[i] = UNITY_MALLOC_ALIGNED(kMemTempAlloc, 16 * 1024, 32);
        }

        for (int i = 0; i < 256; i++)
        {
            UNITY_FREE(kMemTempAlloc, ptrArray[i]);
        }
        UNITY_FREE(kMemTempAlloc, fillptr);
        UNITY_FREE(kMemTempAlloc, ptrArray);
        GetMemoryManager().FrameMaintenance();
    }


    TEST(MemoryManager_DynamicHeapReallocate)
    {
        DynamicHeapAllocator<LowLevelAllocator>* testAlloc = new DynamicHeapAllocator<LowLevelAllocator>(100 * 1024, 0, true, NULL, "TestAlloc");
        MemLabelId testAllocLabel = GetMemoryManager().AddCustomAllocator(testAlloc);
        void* ptr = GetMemoryManager().Allocate(1024, 1, testAllocLabel); // This will allocate 1056 bytes in tlsf.

        // Reported by tlsf:
#if USE_MEMORY_DEBUGGING && PLATFORM_ARCH_64
        static const size_t kExpected1024Bytes = 1056;
#else
        static const size_t kExpected1024Bytes = 1040;
#endif
        CHECK_EQUAL(100 * 1024, testAlloc->GetReservedMemorySize());
        CHECK_EQUAL(kExpected1024Bytes, testAlloc->GetAllocatedMemorySize());

        void* ptr2 = UNITY_MALLOC(testAllocLabel, 50 * 1024);
        CHECK_EQUAL(100 * 1024, testAlloc->GetReservedMemorySize());
        memset(ptr2, 0x3B, 50 * 1024);
        void* ptr3 = UNITY_REALLOC(testAllocLabel, ptr2, 100 * 1024);
        CHECK_EQUAL(200 * 1024, testAlloc->GetReservedMemorySize());
        for (int i = 0; i < 1024; i++)
            CHECK_EQUAL(0x3B, ((char*)ptr3)[i]);
        for (int i = 49 * 1024; i < 50 * 1024; i++)
            CHECK_EQUAL(0x3B, ((char*)ptr3)[i]);
        memset(ptr3, 0x4C, 100 * 1024);
        void* ptr4 = UNITY_REALLOC(testAllocLabel, ptr3, 101 * 1024);
        CHECK_EQUAL(201 * 1024, testAlloc->GetReservedMemorySize());
        for (int i = 0; i < 1024; i++)
            CHECK_EQUAL(0x4C, ((char*)ptr4)[i]);
        for (int i = 99 * 1024; i < 100 * 1024; i++)
            CHECK_EQUAL(0x4C, ((char*)ptr4)[i]);

        CHECK_EQUAL(kExpected1024Bytes + 101 * 1024, testAlloc->GetAllocatedMemorySize());

        GetMemoryManager().Deallocate(ptr4);
        GetMemoryManager().Deallocate(ptr);

        // empty pools are freed, so no memory should be left
        CHECK_EQUAL(0, testAlloc->GetReservedMemorySize());
        CHECK_EQUAL(0, testAlloc->GetAllocatedMemorySize());

        GetMemoryManager().RemoveCustomAllocator(testAllocLabel);
    }
}


// TODO: move to new file once alignment macros and utilities are collected into a common place -scobi 28-dec-15
UNIT_TEST_SUITE(AlignUtilities)
{
    TEST(AlignOfFromPtrMatchesAlignOfForType)
    {
        bool* boolPtr = NULL;
        CHECK_EQUAL(ALIGN_OF(bool), GetTypeAlignmentFromPointer(boolPtr));

        UInt8* uint8Ptr = NULL;
        CHECK_EQUAL(ALIGN_OF(UInt8), GetTypeAlignmentFromPointer(uint8Ptr));
        SInt8* sint8Ptr = NULL;
        CHECK_EQUAL(ALIGN_OF(SInt8), GetTypeAlignmentFromPointer(sint8Ptr));

        UInt16* uint16Ptr = NULL;
        CHECK_EQUAL(ALIGN_OF(UInt16), GetTypeAlignmentFromPointer(uint16Ptr));
        SInt16* sint16Ptr = NULL;
        CHECK_EQUAL(ALIGN_OF(SInt16), GetTypeAlignmentFromPointer(sint16Ptr));

        UInt32* uint32Ptr = NULL;
        CHECK_EQUAL(ALIGN_OF(UInt32), GetTypeAlignmentFromPointer(uint32Ptr));
        SInt32* sint32Ptr = NULL;
        CHECK_EQUAL(ALIGN_OF(SInt32), GetTypeAlignmentFromPointer(sint32Ptr));

        UInt64* uint64Ptr = NULL;
        CHECK_EQUAL(ALIGN_OF(UInt64), GetTypeAlignmentFromPointer(uint64Ptr));
        SInt64* sint64Ptr = NULL;
        CHECK_EQUAL(ALIGN_OF(SInt64), GetTypeAlignmentFromPointer(sint64Ptr));

        float* floatPtr = NULL;
        CHECK_EQUAL(ALIGN_OF(float), GetTypeAlignmentFromPointer(floatPtr));
        double* doublePtr = NULL;
        CHECK_EQUAL(ALIGN_OF(double), GetTypeAlignmentFromPointer(doublePtr));
    }
}


#endif // ENABLE_UNIT_TESTS && ENABLE_MEMORY_MANAGER
