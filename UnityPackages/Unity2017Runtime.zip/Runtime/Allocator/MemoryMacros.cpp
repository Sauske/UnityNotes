#include "UnityPrefix.h"
#include "Runtime/Allocator/MemoryMacros.h"
#include "Runtime/Allocator/MemoryManager.h"
#include "Runtime/Allocator/BaseAllocator.h"
#include "Runtime/Profiler/MemoryProfiler.h"

#if ENABLE_MEM_PROFILER

#if ENABLE_AUTO_SCOPED_ROOT

bool push_allocation_root(MemLabelId label, bool forcePush)
{
    return GetMemoryProfiler() ? GetMemoryProfiler()->PushAllocationRoot(label, forcePush) : false;
}

void  pop_allocation_root()
{
    GetMemoryProfiler()->PopAllocationRoot();
}

AllocationRootWithSalt get_current_allocation_root_reference_internal()
{
    return GetMemoryProfiler() ? GetMemoryProfiler()->GetCurrentRootReference() : AllocationRootWithSalt::kNoRoot;
}

#endif

AllocationRootWithSalt get_root_reference(void* ptr, MemLabelRef label)
{
    AssertMsg(GetMemoryManager().GetAllocator(label) && GetMemoryManager().GetAllocator(label)->GetProfilerHeader(ptr)
        , "Pointer must be allocated with allocator that supports headers");
    return GetMemoryManager().GetAllocator(label)->GetProfilerHeader(ptr)->rootReference;
}

void retain_root_reference(AllocationRootWithSalt root)
{
    AllocationRootReference* rootRef = GetMemoryProfiler()->GetAllocationRoot(root);
    if (rootRef)
        rootRef->Retain();
}

void release_root_reference(AllocationRootWithSalt root)
{
    AllocationRootReference* rootRef = GetMemoryProfiler()->GetAllocationRoot(root);
    if (rootRef)
        rootRef->Release();
}

void transfer_ownership(void* source, MemLabelRef label, AllocationRootWithSalt newRootRef)
{
    BaseAllocator* alloc = GetMemoryManager().GetAllocator(label);
    size_t size = alloc->GetRequestedPtrSize(source);
    GetMemoryProfiler()->TransferOwnership(source, size, label, newRootRef);
}

AllocationRootWithSalt assign_allocation_root(void* root, size_t size, MemLabelRef label, const char* areaName, const char* objectName)
{
    return GetMemoryProfiler()->RegisterRootAllocation(root, size, label, areaName, objectName);
}

#endif

void ValidateAllocatorIntegrity(MemLabelId label)
{
#if ENABLE_MEMORY_MANAGER
    GetMemoryManager().GetAllocator(label)->CheckIntegrity();
#endif
}
