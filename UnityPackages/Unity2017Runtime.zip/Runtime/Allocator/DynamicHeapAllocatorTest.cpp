#include "UnityPrefix.h"
#include "Runtime/Allocator/DynamicHeapAllocator.h"

#if ENABLE_UNIT_TESTS
#if ENABLE_MEMORY_MANAGER && USE_MEMORY_DEBUGGING

#include "Runtime/Testing/Testing.h"

UNIT_TEST_SUITE(DynamicHeapAllocator)
{
    void*   expectedPtr = NULL;
    size_t  expectedSize = 0;

    void validateAllocation(const void* ptr, size_t size, void* const* callstack, size_t maxCallstackSize)
    {
        CHECK_EQUAL(expectedSize, size);
        CHECK_EQUAL(expectedPtr, ptr);
    }

    TEST(WalkTlsfHeapAllocations)
    {
        DynamicHeapAllocator<LowLevelAllocator> alloc(4 * 1024 * 1024, 1024, true, NULL, "TlsfHeapAlloc");

        expectedSize = 64;
        expectedPtr = alloc.Allocate(expectedSize, 4);
        alloc.WalkAllocations(&validateAllocation);

        expectedSize = 128;
        expectedPtr = alloc.Reallocate(expectedPtr, expectedSize, 4);
        alloc.WalkAllocations(&validateAllocation);

        alloc.Deallocate(expectedPtr);
    }

    TEST(WalkLargellocations)
    {
        DynamicHeapAllocator<LowLevelAllocator> alloc(4 * 1024 * 1024, 1024, true, NULL, "LargeAlloc");

        expectedSize = 1 * 1024 * 1024;
        expectedPtr = alloc.Allocate(expectedSize, 8);
        alloc.WalkAllocations(&validateAllocation);

        expectedSize = 2 * 1024 * 1024;
        expectedPtr = alloc.Reallocate(expectedPtr, expectedSize, 8);
        alloc.WalkAllocations(&validateAllocation);

        alloc.Deallocate(expectedPtr);
    }

    TEST(WalkLargellocationsWithPadding)
    {
        DynamicHeapAllocator<LowLevelAllocator> alloc(4 * 1024 * 1024, 1024, true, NULL, "LargeAllocPadding");

        expectedSize = 2 * 1024 * 1024;
        expectedPtr = alloc.Allocate(expectedSize, 1024);
        alloc.WalkAllocations(&validateAllocation);

        expectedSize = 3 * 1024 * 1024;
        expectedPtr = alloc.Reallocate(expectedPtr, expectedSize, 16 * 1024);
        alloc.WalkAllocations(&validateAllocation);

        alloc.Deallocate(expectedPtr);
    }
}

#endif // ENABLE_MEMORY_MANAGER && USE_MEMORY_DEBUGGING
#endif // ENABLE_UNIT_TESTS
