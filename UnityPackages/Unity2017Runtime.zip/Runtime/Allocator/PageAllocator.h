#pragma once

#include "Runtime/Threads/ExtendedAtomicOps.h"
class AtomicPageAllocator;

/*

Purpose:
    Very fast small (less than kPageSize = 32kb) allocations.
    Memory is automatically tracked and deallocated by the AtomicPageAllocator when its destructor is invoked.

    PerThreadPageAllocator always holds onto a single page, when the page is full it grabs a new one from AtomicPageAllocator.
    PerThreadPageAllocator allocations is just a couple instructions, no TLS, no atomics.
    Allocating a new page goes through MemoryManager but with tons of small allocations should happen not very often.

{
    AtomicPageAllocator allocator;
    {
        PerThreadPageAllocator perThreadAllocator(&allocator);

        // Allocates small allocations very efficiently.
        perThreadAllocator.Allocate<int>(15);

        // NOTE: Allocated memory is owned by allocator
        // Thus perThreadAllocator going out of scope here will NOT deallocate.
    }
    // Note AtomicPageAllocator goes out of scope and now all allocations will be deallocated.
}

*/

// Create a single AtomicPageAllocator
// Create one PerThreadPageAllocator per thread.
// Allocate through PerThreadPageAllocator for fast small allocations, with guarantee that those allocations don't trash each others cache lines.
// NOTE: allocations larger than kPageSize will allocate a single block for that allocation, and waste remaining free space in the previous block

class PerThreadPageAllocator
{
public:
    enum
    {
        kMaxMem = 1024 * 1024 * 256,
        kPageSize = 32 * 1024,
        kPageCount = kMaxMem / kPageSize
    };

    PerThreadPageAllocator();
    PerThreadPageAllocator(AtomicPageAllocator& pageAllocator);

    void Initialize(AtomicPageAllocator& pageAllocator);

    // Currently all allocations are void* size aligned... (Might make sense to align 16 byte)
    inline void* AllocateInternal(UInt32 size)
    {
        const UInt32 alignmentMask = sizeof(void*) - 1;
        size = (size + alignmentMask) & ~alignmentMask;

        if (m_Offset + size > m_CurrentPageSize)
            AcquireNewPage(std::max(size, (UInt32)kPageSize));

        void* ptr = m_Start + m_Offset;
        m_Offset += size;
        return ptr;
    }

    inline void* AllocateAndCopy(void* data, UInt32 size)
    {
        void* ptr = AllocateInternal(size);
        memcpy(ptr, data, size);
        return ptr;
    }

    template<class T>
    inline T* Allocate(UInt32 count)
    {
        return reinterpret_cast<T*>(AllocateInternal(sizeof(T) * count));
    }

    template<class T>
    inline T* Allocate()
    {
        return reinterpret_cast<T*>(AllocateInternal(sizeof(T)));
    }

private:

    void AcquireNewPage(size_t pageSize);

    UInt8*                  m_Start;
    UInt32                  m_Offset;
    UInt32                  m_CurrentPageSize;
    AtomicPageAllocator*    m_Allocator;
};


class AtomicPageAllocator
{
public:

    AtomicPageAllocator(const char* subSystemName, MemLabelRef label);
    ~AtomicPageAllocator();

    void Clear();

    void* AllocatePage(size_t pageSize);

private:
    MemLabelId      m_Memlabel;
    const char*     m_SubSystemName;
    void*           m_Pages[PerThreadPageAllocator::kPageCount];
    volatile int    m_ActivePages;
};
