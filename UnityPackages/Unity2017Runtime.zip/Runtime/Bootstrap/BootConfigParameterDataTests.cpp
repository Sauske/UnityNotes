#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS
#include "Runtime/Testing/Testing.h"
#include "BootConfigParameterData.h"
#include <stdlib.h>

UNIT_TEST_SUITE(BootConfigParameterData)
{
    REFLECTABLE_ENUM(BootConfigParameterTestEnum,
        Value1,
        Value2,
        Value3,
        Value4,
        Value5,
        Value6,
        );

    template<typename T>
    struct ParameterFixture
    {
        ParameterFixture(T _defaultValue)
            : defaultValue(_defaultValue)
            , parameter(config, "parameter", defaultValue)
        {
        }

        void CheckParameterValue(T expected)
        {
            CHECK_EQUAL(expected, static_cast<T>(parameter));
        }

        void CheckParameterNull()
        {
            CHECK_NULL(static_cast<T>(parameter));
        }

        const T                      defaultValue;
        BootConfig::Data             config;
        BootConfig::ParameterData<T> parameter;
    };

    struct EnumParameterFixture : ParameterFixture<BootConfigParameterTestEnum>
    {
        EnumParameterFixture() : ParameterFixture<BootConfigParameterTestEnum>(BootConfigParameterTestEnum::Value5) {}
    };

    TEST_FIXTURE(EnumParameterFixture, Enum_ReturnDefaultValue_ForNonExistentKey)
    {
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(EnumParameterFixture, Enum_ReturnDefaultValue_ForKeyWithNoValue)
    {
        config.Append("parameter");
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(EnumParameterFixture, Enum_ReturnDefaultValue_ForKeyWithInvalidValue)
    {
        config.Append("parameter", "can't parse this");
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(EnumParameterFixture, Enum_MatchesValue_ForExistingKey)
    {
        config.Append("parameter", "value3");
        CheckParameterValue(BootConfigParameterTestEnum::Value3);
    }

    struct UInt32ParameterFixture : ParameterFixture<UInt32>
    {
        UInt32ParameterFixture() : ParameterFixture<UInt32>(363446717) {}
    };

    TEST_FIXTURE(UInt32ParameterFixture, UInt32_ReturnDefaultValue_ForNonExistentKey)
    {
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(UInt32ParameterFixture, UInt32_ReturnDefaultValue_ForKeyWithNoValue)
    {
        config.Append("parameter");
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(UInt32ParameterFixture, UInt32_ReturnDefaultValue_ForKeyWithInvalidValue)
    {
        config.Append("parameter", "can't parse this");
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(UInt32ParameterFixture, UInt32_MatchesValue_ForExistingKey)
    {
        config.Append("parameter", "2064142063");
        CheckParameterValue(2064142063);
    }

    struct UInt64ParameterFixture : ParameterFixture<UInt64>
    {
        UInt64ParameterFixture() : ParameterFixture<UInt64>(7254700626004459871L) {}
    };

    TEST_FIXTURE(UInt64ParameterFixture, UInt64_ReturnDefaultValue_ForNonExistentKey)
    {
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(UInt64ParameterFixture, UInt64_ReturnDefaultValue_ForKeyWithNoValue)
    {
        config.Append("parameter");
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(UInt64ParameterFixture, UInt64_ReturnDefaultValue_ForKeyWithInvalidValue)
    {
        config.Append("parameter", "can't parse this");
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(UInt64ParameterFixture, UInt64_MatchesValue_ForExistingKey)
    {
        config.Append("parameter", "4781200341985000519");
        CheckParameterValue(4781200341985000519);
    }

    struct SInt32ParameterFixture : ParameterFixture<SInt32>
    {
        SInt32ParameterFixture() : ParameterFixture<SInt32>(-363446717) {}
    };

    TEST_FIXTURE(SInt32ParameterFixture, SInt32_ReturnDefaultValue_ForNonExistentKey)
    {
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(SInt32ParameterFixture, SInt32_ReturnDefaultValue_ForKeyWithNoValue)
    {
        config.Append("parameter");
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(SInt32ParameterFixture, SInt32_ReturnDefaultValue_ForKeyWithInvalidValue)
    {
        config.Append("parameter", "can't parse this");
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(SInt32ParameterFixture, SInt32_MatchesValue_ForExistingKey)
    {
        config.Append("parameter", "-2064142063");
        CheckParameterValue(-2064142063);
    }

    struct SInt64ParameterFixture : ParameterFixture<SInt64>
    {
        SInt64ParameterFixture() : ParameterFixture<SInt64>(-7254700626004459871L) {}
    };

    TEST_FIXTURE(SInt64ParameterFixture, SInt64_ReturnDefaultValue_ForNonExistentKey)
    {
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(SInt64ParameterFixture, SInt64_ReturnDefaultValue_ForKeyWithNoValue)
    {
        config.Append("parameter");
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(SInt64ParameterFixture, SInt64_ReturnDefaultValue_ForKeyWithInvalidValue)
    {
        config.Append("parameter", "can't parse this");
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(SInt64ParameterFixture, SInt64_MatchesValue_ForExistingKey)
    {
        config.Append("parameter", "-4781200341985000519");
        CheckParameterValue(-4781200341985000519);
    }

    struct BoolParameterFalseFixture : ParameterFixture<bool>
    {
        BoolParameterFalseFixture() : ParameterFixture<bool>(false) {}
    };

    TEST_FIXTURE(BoolParameterFalseFixture, Bool_WithFalseAsDefault_ReturnDefaultValue_ForNonExistentKey)
    {
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(BoolParameterFalseFixture, Bool_WithFalseAsDefault_ReturnTrue_ForKeyWithNoValue)
    {
        config.Append("parameter");
        CheckParameterValue(true);
    }

    TEST_FIXTURE(BoolParameterFalseFixture, Bool_WithFalseAsDefault_ReturnDefaultValue_ForKeyWithInvalidValue)
    {
        config.Append("parameter", "can't parse this");
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(BoolParameterFalseFixture, Bool_WithFalseAsDefault_ReturnsTrue_ForExistingKeyWithValueTrue)
    {
        config.Append("parameter", "true");
        CheckParameterValue(true);
    }

    TEST_FIXTURE(BoolParameterFalseFixture, Bool_WithFalseAsDefault_ReturnsTrue_ForExistingKeyWithValueYes)
    {
        config.Append("parameter", "yes");
        CheckParameterValue(true);
    }

    TEST_FIXTURE(BoolParameterFalseFixture, Bool_WithFalseAsDefault_ReturnsTrue_ForExistingKeyWithValueOne)
    {
        config.Append("parameter", "1");
        CheckParameterValue(true);
    }

    struct BoolParameterTrueFixture : ParameterFixture<bool>
    {
        BoolParameterTrueFixture() : ParameterFixture<bool>(true) {}
    };

    TEST_FIXTURE(BoolParameterTrueFixture, Bool_WithTrueAsDefault_ReturnDefaultValue_ForNonExistentKey)
    {
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(BoolParameterTrueFixture, Bool_WithTrueAsDefault_ReturnTrue_ForKeyWithNoValue)
    {
        config.Append("parameter");
        CheckParameterValue(true);
    }

    TEST_FIXTURE(BoolParameterTrueFixture, Bool_WithTrueAsDefault_ReturnDefaultValue_ForKeyWithInvalidValue)
    {
        config.Append("parameter", "can't parse this");
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(BoolParameterTrueFixture, Bool_WithTrueAsDefault_ReturnsFalse_ForExistingKeyWithValueFalse)
    {
        config.Append("parameter", "false");
        CheckParameterValue(false);
    }

    TEST_FIXTURE(BoolParameterTrueFixture, Bool_WithTrueAsDefault_ReturnsFalse_ForExistingKeyWithValueNo)
    {
        config.Append("parameter", "no");
        CheckParameterValue(false);
    }

    TEST_FIXTURE(BoolParameterTrueFixture, Bool_WithTrueAsDefault_ReturnsFalse_ForExistingKeyWithValueZero)
    {
        config.Append("parameter", "0");
        CheckParameterValue(false);
    }

    struct StringParameterFixture : ParameterFixture<const char*>
    {
        StringParameterFixture() : ParameterFixture<const char*>("<default>") {}
    };

    TEST_FIXTURE(StringParameterFixture, String_ReturnDefaultValue_ForNonExistentKey)
    {
        CheckParameterValue(defaultValue);
    }

    TEST_FIXTURE(StringParameterFixture, String_ReturnNull_ForKeyWithNoValue)
    {
        config.Append("parameter");
        CheckParameterNull();
    }

    TEST_FIXTURE(StringParameterFixture, String_MatchesValue_ForExistingKey)
    {
        config.Append("parameter", "random string 448056701");
        CheckParameterValue("random string 448056701");
    }
}

#endif
