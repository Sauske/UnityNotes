#pragma once

#include "BootConfigParameterData.h"
#include "Runtime/Utilities/Annotations.h"

namespace BootConfig
{
    static const char* const kFilename = "boot.config";

    void Init(char const* parameters[], size_t parametersLength);
    void InitFromString(char const* parameters[], size_t parametersLength, const char* contents);
    bool InitFromFile(char const* parameters[], size_t parametersLength, const char* filename);

    TAKES_PRINTF_ARGS(3, 4)
    bool InitFromFileFormatted(char const* parameters[], size_t parametersLength, const char* format, ...);

    bool HasKey(const char* key);
    const char* GetValue(const char* key, size_t index = 0);
    bool CheckKeyValuePairExists(const char* key, const char* value);

    const Data& GetGlobalConfig();

    template<typename T>
    class Parameter : public ParameterData<T>
    {
    public:
        Parameter(const char* name, T defalutValue) : ParameterData<T>(GetGlobalConfig(), name, defalutValue) {}
    };
}
