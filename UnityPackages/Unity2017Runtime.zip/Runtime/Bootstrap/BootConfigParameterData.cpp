#include "UnityPrefix.h"
#include "BootConfigParameterData.h"
#include "Runtime/Utilities/Word.h"

namespace BootConfig
{
    template<> const char* ParameterParser<const char*>::Parse(const char* value, const char* defaultValue) const
    {
        return value;
    }

    template<> bool ParameterParser<bool>::Parse(const char* value, bool defaultValue) const
    {
        if (!value)
            return true;

        if (StrIEquals("true", value) || StrIEquals("yes", value) || StrIEquals("1", value))
            return true;
        if (StrIEquals("false", value) || StrIEquals("no", value) || StrIEquals("0", value))
            return false;
        return defaultValue;
    }

    template<typename T>
    static T ParseWithScanf(const char* format, const char* value, T defaultValue)
    {
        T result;
        if (value && sscanf(value, format, &result) == 1)
            return result;
        return defaultValue;
    }

    template<> UInt32 ParameterParser<UInt32>::Parse(const char* value, UInt32 defaultValue) const
    {
        return ParseWithScanf("%u", value, defaultValue);
    }

    template<> SInt32 ParameterParser<SInt32>::Parse(const char* value, SInt32 defaultValue) const
    {
        return ParseWithScanf("%d", value, defaultValue);
    }

    template<> UInt64 ParameterParser<UInt64>::Parse(const char* value, UInt64 defaultValue) const
    {
        return ParseWithScanf("%llu", value, defaultValue);
    }

    template<> SInt64 ParameterParser<SInt64>::Parse(const char* value, SInt64 defaultValue) const
    {
        return ParseWithScanf("%lld", value, defaultValue);
    }
}
