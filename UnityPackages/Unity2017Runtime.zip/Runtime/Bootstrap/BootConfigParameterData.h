#pragma once

#include "BootConfigData.h"
#include "Runtime/Utilities/EnumTraits.h"
#include "Runtime/Utilities/ReflectableEnum.h"

namespace BootConfig
{
    template<typename T>
    class ParameterParser
    {
    public:
        T Parse(const char* value, T defaultValue) const;
    };

    template<typename T>
    class ParameterData
    {
    public:
        ParameterData(const Data& data, const char* name, T defaultValue)
            : m_Data(data)
            , m_Name(name)
            , m_DefaultValue(defaultValue)
            , m_Parser()
        {
        }

        const char* GetValue() const
        {
            return m_Data.GetValue(m_Name);
        }

        operator T() const
        {
            if (!m_Data.HasKey(m_Name))
                return m_DefaultValue;
            return m_Parser.Parse(m_Data.GetValue(m_Name), m_DefaultValue);
        }

    private:
        const Data& m_Data;
        const char* m_Name;
        const T     m_DefaultValue;
        const ParameterParser<T> m_Parser;
    };

    // ReflectableEnum (default)
    template<typename T> T ParameterParser<T>::Parse(const char* value, T defaultValue) const
    {
        if (!value)
            return defaultValue;

        T result = EnumTraits::FromIntUnchecked<T>(0);
        if (EnumTraits::TryFromString<T>(value, true, result))
            return result;

        return defaultValue;
    }

    // string
    template<> const char* ParameterParser<const char*>::Parse(const char* value, const char* defaultValue) const;

    // bool
    template<> bool ParameterParser<bool>::Parse(const char* value, bool defaultValue) const;

    // Numbers
    template<> UInt32 ParameterParser<UInt32>::Parse(const char* value, UInt32 defaultValue) const;
    template<> SInt32 ParameterParser<SInt32>::Parse(const char* value, SInt32 defaultValue) const;
    template<> UInt64 ParameterParser<UInt64>::Parse(const char* value, UInt64 defaultValue) const;
    template<> SInt64 ParameterParser<SInt64>::Parse(const char* value, SInt64 defaultValue) const;
}
