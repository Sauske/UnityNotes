#include "UnityPrefix.h"

// --------------------------------------------------------------------
// This class is used by BootConfig which is instantiated before
// the engine. When changing the code you need to take this into
// consideration - the implications of not having an initialized
// memory manager or any other unity subsystem.
// --------------------------------------------------------------------
#include "BootConfigData.h"

#include "Runtime/Logging/LogAssert.h"
#include "Runtime/Utilities/NonCopyable.h"
#include "Runtime/Utilities/Word.h"
#include <string.h>
#include <ctype.h>
#include <stdio.h>

namespace BootConfig
{
    struct Data::KeyEntry : NonCopyable
    {
        struct Value : NonCopyable
        {
            Value* nextPtr;
            char*  str;
        };

        KeyEntry* nextPtr;
        Value*    valuePtr;
        char*     str;
    };

namespace
{
    template<typename T> T* Allocate(const char* const str, const size_t len)
    {
        // allocate enough space to hold both struct and the string
        T* result = static_cast<T*>(malloc(sizeof(T) + len + 1));
        memset(result, 0, sizeof(T));
        // append string data at the end of the struct
        result->str = reinterpret_cast<char*>(result) + sizeof(T);
        memcpy(result->str, str, len);
        result->str[len] = '\0';
        return result;
    }

    template<typename T> T* DeallocateItem(T* item)
    {
        T* nextItem = item->nextPtr;
        item->~T();
        free(item);
        return nextItem;
    }

    Data::KeyEntry::Value* Deallocate(Data::KeyEntry::Value* item)
    {
        if (!item)
            return NULL;
        return DeallocateItem(item);
    }

    Data::KeyEntry* Deallocate(Data::KeyEntry* item)
    {
        if (!item)
            return NULL;
        while ((item->valuePtr = Deallocate(item->valuePtr)))
            ;
        return DeallocateItem(item);
    }

    bool Matches(const char* const str1, const char* const str2, const size_t str2Length)
    {
        // str2 may not be null terminated
        return StrNICmp(str1, str2, str2Length) == 0 && str1[str2Length] == 0;
    }

    template<typename T> T FindPtr(T linkPtrAddr, const char* const str, const size_t strLength)
    {
        while (*linkPtrAddr && !Matches((*linkPtrAddr)->str, str, strLength))
            linkPtrAddr = &(*linkPtrAddr)->nextPtr;
        return linkPtrAddr;
    }

    template<typename T> T FindPtr(T linkPtrAdd, const size_t index)
    {
        for (int i = 0; *linkPtrAdd && i < index; ++i)
            linkPtrAdd = &(*linkPtrAdd)->nextPtr;
        return linkPtrAdd;
    }

    template<typename T> T FindLastPtr(T linkPtrAdd)
    {
        while (*linkPtrAdd)
            linkPtrAdd = &(*linkPtrAdd)->nextPtr;
        return linkPtrAdd;
    }

    template<typename T> size_t CountItems(T linkPtrAdd)
    {
        size_t count = 0;
        for (; *linkPtrAdd; linkPtrAdd = &(*linkPtrAdd)->nextPtr)
            count++;
        return count;
    }
}

    Data::Data()
        : m_Data(NULL)
    {
    }

    Data::~Data()
    {
        while ((m_Data = Deallocate(m_Data)))
            ;
    }

    bool Data::HasKey(const char* const key) const
    {
        return *FindPtr(&m_Data, key, strlen(key)) != NULL;
    }

    const char* Data::GetKey(size_t index) const
    {
        const KeyEntry* const keyEntry = *FindPtr(&m_Data, index);
        return keyEntry ? keyEntry->str : NULL;
    }

    const char* Data::GetValue(const char* const key, const size_t index) const
    {
        const KeyEntry* const keyEntry = *FindPtr(&m_Data, key, strlen(key));
        if (!keyEntry)
            return NULL;
        KeyEntry::Value* valuePtr = *FindPtr(&keyEntry->valuePtr, index);
        return valuePtr ? valuePtr->str : NULL;
    }

    size_t Data::GetValues(const char* const key, const char* values[], const size_t valuesLength) const
    {
        const KeyEntry* const keyEntry = *FindPtr(&m_Data, key, strlen(key));
        if (!keyEntry)
            return 0;

        const KeyEntry::Value* valuePtr = *FindPtr(&keyEntry->valuePtr, 0);
        for (int i = 0; i < valuesLength; ++i)
        {
            values[i] = valuePtr->str;
            if (!(valuePtr = valuePtr->nextPtr))
                return i + 1;
        }
        return valuesLength;
    }

    size_t Data::GetKeyCount() const
    {
        return CountItems(&m_Data);
    }

    size_t Data::GetValueCount(const char* const key) const
    {
        const KeyEntry* const keyEntry = *FindPtr(&m_Data, key, strlen(key));
        if (!keyEntry)
            return 0;
        return CountItems(&keyEntry->valuePtr);
    }

    void Data::Append(const char* const key, const char* const value)
    {
        Append(key, key ? strlen(key) : 0, value, value ? strlen(value) : 0);
    }

    void Data::Set(const char* const key, const char* const value)
    {
        Set(key, key ? strlen(key) : 0, value, value ? strlen(value) : 0);
    }

    void Data::Append(const char* const key, const size_t keyLength, const char* const value, const size_t valueLength)
    {
        if (!key)
            return;

        KeyEntry** keySlot = FindPtr(&m_Data, key, keyLength);
        if (!*keySlot)
            *keySlot = Allocate<KeyEntry>(key, keyLength);

        if (!value)
            return;

        KeyEntry::Value** valueSlot = FindLastPtr(&(*keySlot)->valuePtr);
        *valueSlot = Allocate<KeyEntry::Value>(value, valueLength);
    }

    void Data::Set(const char* const key, const size_t keyLength, const char* const value, const size_t valueLength)
    {
        if (!key)
            return;

        KeyEntry** keySlot = FindPtr(&m_Data, key, keyLength);
        if (!*keySlot)
            *keySlot = Allocate<KeyEntry>(key, keyLength);

        while ((*keySlot)->valuePtr)
            (*keySlot)->valuePtr = Deallocate((*keySlot)->valuePtr);

        if (!value)
            return;

        KeyEntry::Value** valueSlot = FindLastPtr(&(*keySlot)->valuePtr);
        *valueSlot = Allocate<KeyEntry::Value>(value, valueLength);
    }

namespace
{
    const char kKeyDelim[] = "=";
    const char kValueDelim[] = "\n";

    bool IsCommandLineKey(const char* str)
    {
        return str && str[0] == '-' && !isdigit(str[1]) && str[1] != '\0';
    }

    bool IsBlank(const char c)
    {
        return c && (c == ' ' || c == '\t');
    }

    bool IsLineBreak(const char c)
    {
        return c && isspace(c) && !IsBlank(c);
    }

    bool IsBlankOrLineBreak(const char c)
    {
        return c && isspace(c);
    }

    bool IsValueDelimiter(const char c)
    {
        return !c || IsLineBreak(c);
    }

    bool IsKeyDelimiter(const char c)
    {
        return IsValueDelimiter(c) ||  c == '=';
    }

    bool ContainsKeyDelimiter(const char* str, size_t strLen)
    {
        for (int i = 0; i < strLen; ++i)
            if (IsKeyDelimiter(str[i]))
                return true;
        return false;
    }

    bool ContainsValueDelimiter(const char* str, size_t strLen)
    {
        for (int i = 0; i < strLen; ++i)
            if (IsValueDelimiter(str[i]))
                return true;
        return false;
    }
}

    void Data::Init(char const* parameters[], size_t parametersLength)
    {
        const char* key = ""; // stuff things without key into an empty string key slot
        for (int pos = 0; pos < parametersLength; ++pos)
        {
            for (; pos < parametersLength && !IsCommandLineKey(parameters[pos]); ++pos)
                Append(key, parameters[pos]);
            if (pos == parametersLength)
                break;
            key = &parameters[pos][1];
            Set(key);
        }
    }

    void Data::InitFromString(char const* parameters[], size_t parametersLength, const char* contents)
    {
        for (int pos = 0; contents[pos];)
        {
            // trim & search for key delimiter
            for (; IsBlankOrLineBreak(contents[pos]); ++pos)
                ;
            size_t keyStart = pos, keyEnd = pos;
            for (; !IsKeyDelimiter(contents[pos]); ++pos)
                if (!IsBlank(contents[pos]))
                    keyEnd = pos + 1;
            if (!contents[pos])
            {
                if (keyStart != keyEnd)
                    Append(&contents[keyStart], keyEnd - keyStart, NULL, 0);
                return;
            }

            // trim & search for value delimiter
            for (++pos; IsBlank(contents[pos]); ++pos)
                ;
            size_t valueStart = pos, valueEnd = pos;
            for (; !IsValueDelimiter(contents[pos]); ++pos)
                if (!IsBlank(contents[pos]))
                    valueEnd = pos + 1;
            if (contents[pos])
                ++pos;

            Append(&contents[keyStart], keyEnd - keyStart, &contents[valueStart], valueEnd - valueStart);
        }
        Init(parameters, parametersLength);
    }

    static FILE* fopenPortable(const char* filename, const char* mode)
    {
#if PLATFORM_WIN
        int filenameWLength = 2 * sizeof(wchar_t) * (strlen(filename) + 1);
        wchar_t* filenameW = static_cast<wchar_t*>(malloc(filenameWLength));
        int newLength = MultiByteToWideChar(CP_UTF8, 0, filename, -1, filenameW, filenameWLength);
        Assert(newLength > 0);

        int modeWLength = 2 * sizeof(wchar_t) * (strlen(mode) + 1);
        wchar_t* modeW = static_cast<wchar_t*>(malloc(modeWLength));
        newLength = MultiByteToWideChar(CP_UTF8, 0, mode, -1, modeW, modeWLength);
        Assert(newLength > 0);

        FILE* fd = _wfopen(filenameW, modeW);

        free(filenameW);
        free(modeW);

        return fd;
#else
        return fopen(filename, mode);
#endif
    }

    bool Data::InitFromFile(char const* parameters[], size_t parametersLength, const char* filename)
    {
        FILE* fd = fopenPortable(filename, "rb");
        if (!fd) // missing file
            return false;

        fseek(fd, 0, SEEK_END);
        size_t len = ftell(fd);
        fseek(fd, 0, SEEK_SET);

        char* contents;
        ALLOC_TEMP_AUTO(contents, len + 1);
        contents[len] = '\0';
        fread(contents, len, 1, fd);
        fclose(fd);

        InitFromString(parameters, parametersLength, contents);
        return true;
    }

    bool Data::SaveToFile(const char* filename) const
    {
        FILE* fd = fopenPortable(filename, "wb");
        if (!fd)
            return false;

        for (KeyEntry* key = m_Data; key; key = key->nextPtr)
        {
            const size_t keyLen = strlen(key->str);
            Assert(!ContainsKeyDelimiter(key->str, keyLen));
            if (!key->valuePtr)
            {
                fwrite(key->str, keyLen, 1, fd);
                fwrite(kKeyDelim, sizeof(kKeyDelim) - 1, 1, fd);
                fwrite(kValueDelim, sizeof(kValueDelim) - 1, 1, fd);
            }
            for (KeyEntry::Value* val = key->valuePtr; val; val = val->nextPtr)
            {
                const size_t valLen = strlen(val->str);
                Assert(!ContainsValueDelimiter(val->str, valLen));
                fwrite(key->str, keyLen, 1, fd);
                fwrite(kKeyDelim, sizeof(kKeyDelim) - 1, 1, fd);
                fwrite(val->str, valLen, 1, fd);
                fwrite(kValueDelim, sizeof(kValueDelim) - 1, 1, fd);
            }
        }
        fclose(fd);
        return true;
    }
}
