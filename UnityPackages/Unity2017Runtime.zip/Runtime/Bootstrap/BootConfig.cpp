#include "UnityPrefix.h"

#include "BootConfig.h"
#include "BootConfigData.h"
#include <stdarg.h>

namespace BootConfig
{
namespace Internal
{
    BootConfig::Data s_Data;

    BootConfig::Data& GetGlobalConfig()
    {
        return s_Data;
    }
}

    const Data& GetGlobalConfig()
    {
        return BootConfig::Internal::GetGlobalConfig();
    }
}

void BootConfig::Init(char const* parameters[], size_t parametersLength)
{
    BootConfig::Internal::GetGlobalConfig().Init(parameters, parametersLength);
}

void BootConfig::InitFromString(char const* parameters[], size_t parametersLength, const char* contents)
{
    BootConfig::Internal::GetGlobalConfig().InitFromString(parameters, parametersLength, contents);
}

bool BootConfig::InitFromFile(char const* parameters[], size_t parametersLength, const char* filename)
{
    if (!BootConfig::Internal::GetGlobalConfig().InitFromFile(parameters, parametersLength, filename))
        return false;
    return true;
}

bool BootConfig::InitFromFileFormatted(char const * parameters[], size_t parametersLength, const char * format, ...)
{
    va_list args;
    va_start(args, format);
    const int filenameLength = vsnprintf(NULL, 0, format, args) + 1;
    va_end(args);

    AssertMsg(filenameLength > 0, "BootConfig - Invalid filename format or format arguments");
    if (filenameLength <= 0)
        return false;

    va_start(args, format);
    char* filename = static_cast<char*>(alloca(filenameLength));
    vsnprintf(filename, filenameLength, format, args);
    va_end(args);

    return InitFromFile(parameters, parametersLength, filename);
}

bool BootConfig::HasKey(const char* key)
{
    return BootConfig::Internal::GetGlobalConfig().HasKey(key);
}

const char* BootConfig::GetValue(const char* key, size_t index)
{
    return BootConfig::Internal::GetGlobalConfig().GetValue(key, index);
}

bool BootConfig::CheckKeyValuePairExists(const char* key, const char* value)
{
    const char* valueFromKey = GetValue(key);
    if (valueFromKey != NULL)
    {
        if (StrICmp(valueFromKey, value) == 0)
            return true;
    }
    return false;
}
