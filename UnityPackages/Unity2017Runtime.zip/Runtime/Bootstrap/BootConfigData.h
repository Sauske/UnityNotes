#pragma once

#include "Runtime/Misc/AllocatorLabels.h"
#include "Runtime/Utilities/NonCopyable.h"

namespace BootConfig
{
// TODO: document file format
// --------------------------------------------------------------------
// BootConfig multimap - each key may point to multiple values
// Implementation is not thread safe and based on linked lists
// Not intended to be used with large collections
//
// Characteristics:
//  One allocation per inserted string with no additional allocations
//  Key insertion order is preserved
//
// This class is used by BootConfig which is instantiated before
// the engine. When changing the code you need to take this into
// consideration - the implications of not having an initialized
// memory manager or any other unity subsystem.
// --------------------------------------------------------------------
    class Data : NonCopyable
    {
    public:
        Data();
        ~Data();

        void Init(char const* parameters[], size_t parametersLength);
        void InitFromString(char const* parameters[], size_t parametersLength, const char* contents);
        bool InitFromFile(char const* parameters[], size_t parametersLength, const char* filename);

        bool SaveToFile(const char* filename) const;

        // strings returned are only valid as long as they part of this map
        const char* GetKey(size_t index) const;
        const char* GetValue(const char* key, size_t index = 0) const;
        size_t GetValues(const char* key, const char* values[], size_t values_len) const;

        bool HasKey(const char* key) const;

        size_t GetKeyCount() const;
        size_t GetValueCount(const char* key) const;

        void Append(const char* key, const char* value = NULL);
        void Append(const char* key, size_t keyLength, const char* value, size_t valueLength);

        void Set(const char* key, const char* value = NULL);
        void Set(const char* key, size_t keyLength, const char* value, size_t valueLength);

        struct KeyEntry;

    private:
        KeyEntry*   m_Data;
    };
}
