#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS
#include "Runtime/Testing/Faking.h"
#include "Runtime/Testing/Testing.h"
#include "BootConfigData.h"
#include <stdlib.h>

#if PLATFORM_WIN
#include "PlatformDependent/Win/WinUnicode.h"
#endif

struct BootConfigFixture
{
    BootConfig::Data config;

    BootConfigFixture()
    {
    }
};


UNIT_TEST_SUITE(BootConfigData)
{
    // GetKey
    TEST_FIXTURE(BootConfigFixture, GetFirstKey_MatchesKeyName_ForOneAddedKey)
    {
        config.Append("key", "value1");
        CHECK(config.HasKey("key"));
    }

    TEST_FIXTURE(BootConfigFixture, GetFirstKey_MatchesKeyName_ForOneAddedKeyWithoutValue)
    {
        config.Append("key", NULL);
        CHECK_EQUAL("key", config.GetKey(0));
    }

    TEST_FIXTURE(BootConfigFixture, GetFirstKey_MatchesKeyName_ForOneAddedKeyWithEmptyStringValue)
    {
        config.Append("key", "");
        CHECK_EQUAL("key", config.GetKey(0));
    }

    TEST_FIXTURE(BootConfigFixture, GetSecondKey_MatchesKeyName_ForOneAddedKey)
    {
        config.Append("key", "value1");
        CHECK_NULL(config.GetKey(1));
    }

    TEST_FIXTURE(BootConfigFixture, GetSecondKey_ReturnNull__ForOneAddedKeyWithoutValue)
    {
        config.Append("key", NULL);
        CHECK_NULL(config.GetKey(1));
    }

    TEST_FIXTURE(BootConfigFixture, GetSecondKey_ReturnNull__ForOneAddedKeyWithEmptyStringValue)
    {
        config.Append("key", "");
        CHECK_NULL(config.GetKey(1));
    }

    // GetKeyCount
    TEST_FIXTURE(BootConfigFixture, GetKeyCount_ReturnZero_ForEmptyBootConfig)
    {
        CHECK_EQUAL(0, config.GetKeyCount());
    }

    TEST_FIXTURE(BootConfigFixture, GetKeyCount_ReturnOne_ForOneAddedKey)
    {
        config.Append("key", "value1");
        CHECK_EQUAL(1, config.GetKeyCount());
    }

    TEST_FIXTURE(BootConfigFixture, GetKeyCount_ReturnOne_ForOneAddedKeyWithoutValue)
    {
        config.Append("key", NULL);
        CHECK_EQUAL(1, config.GetKeyCount());
    }

    TEST_FIXTURE(BootConfigFixture, GetKeyCount_ReturnOne_ForOneAddedKeyWithEmptyStringValue)
    {
        config.Append("key", "");
        CHECK_EQUAL(1, config.GetKeyCount());
    }

    // GetValue
    TEST_FIXTURE(BootConfigFixture, GetValue_ReturnNull_ForNonExistentKey)
    {
        CHECK_NULL(config.GetValue("key"));
        CHECK_NULL(config.GetValue("key", 4721));
    }

    TEST_FIXTURE(BootConfigFixture, GetValue_ReturnNull_ForNonExistentValues)
    {
        config.Append("key", "value0");
        config.Append("key", "value1");
        CHECK_NULL(config.GetValue("key", 2));
        CHECK_NULL(config.GetValue("key", 4721));
    }

    TEST_FIXTURE(BootConfigFixture, GetValue_ReturnNull_ForKeyWithoutValue)
    {
        config.Append("key", NULL);
        CHECK_NULL(config.GetValue("key", 0));
    }

    TEST_FIXTURE(BootConfigFixture, GetValue_ReturnOnenEmptyString_ForKeyWithEmptyStringValue)
    {
        config.Append("key", "");
        CHECK_EQUAL("", config.GetValue("key", 0));
        CHECK_NULL(config.GetValue("key", 1));
    }

    TEST_FIXTURE(BootConfigFixture, GetValue_ReturnOneMatchingString_ForKeyWithOneValue)
    {
        config.Append("key", "value1");
        CHECK_EQUAL("value1", config.GetValue("key", 0));
        CHECK_NULL(config.GetValue("key", 1));
    }

    TEST_FIXTURE(BootConfigFixture, GetValue_ReturnTwoMatchingStrings_ForKeyWithTwoValues)
    {
        config.Append("key", "value1");
        config.Append("key", "value2");
        CHECK_EQUAL("value1", config.GetValue("key", 0));
        CHECK_EQUAL("value2", config.GetValue("key", 1));
        CHECK_NULL(config.GetValue("key", 2));
    }

    TEST_FIXTURE(BootConfigFixture, GetValue_ReturnOneEmptyString_ForKeyWithOneEmptyStringValue)
    {
        config.Append("key", "");
        CHECK_EQUAL("", config.GetValue("key", 0));
        CHECK_NULL(config.GetValue("key", 2));
    }

    TEST_FIXTURE(BootConfigFixture, GetValue_ReturnTwoEmptyStrings_ForKeyWithTwoEmptyStringValues)
    {
        config.Append("key", "");
        config.Append("key", "");
        CHECK_EQUAL("", config.GetValue("key", 0));
        CHECK_EQUAL("", config.GetValue("key", 1));
        CHECK_NULL(config.GetValue("key", 2));
    }

    TEST_FIXTURE(BootConfigFixture, GetValue_ReturnMatchingValue_ForKeyThatOnlyDifferInCasing)
    {
        config.Append("key", "value0");
        config.Append("key", "value1");
        config.Append("key", "value2");
        CHECK_EQUAL("value0", config.GetValue("KEY", 0));
        CHECK_EQUAL("value1", config.GetValue("kEY", 1));
        CHECK_EQUAL("value2", config.GetValue("KEy", 2));
    }

    // GetValueCount
    TEST_FIXTURE(BootConfigFixture, GetValueCount_ReturnZero_ForNonExistentKey)
    {
        CHECK_EQUAL(0, config.GetValueCount("key"));
    }

    TEST_FIXTURE(BootConfigFixture, GetValueCount_ReturnZero_ForKeyWithoutValue)
    {
        config.Append("key", NULL);
        CHECK_EQUAL(0, config.GetValueCount("key"));
    }

    TEST_FIXTURE(BootConfigFixture, GetValueCount_ReturnOne_ForKeyWithOneEmptyStringValues)
    {
        config.Append("key", "");
        CHECK_EQUAL(1, config.GetValueCount("key"));
    }

    TEST_FIXTURE(BootConfigFixture, GetValueCount_ReturnTwo_ForKeyWithTwoEmptyStringValues)
    {
        config.Append("key", "");
        config.Append("key", "");
        CHECK_EQUAL(2, config.GetValueCount("key"));
    }

    // HasKey
    TEST_FIXTURE(BootConfigFixture, HasKey_IsTrue_ForKeyWithoutValue)
    {
        config.Append("key", NULL);
        CHECK(config.HasKey("key"));
    }

    TEST_FIXTURE(BootConfigFixture, HasKey_IsTrue_ForKeyWithEmptyStringValue)
    {
        config.Append("key", "");
        CHECK(config.HasKey("key"));
    }

    TEST_FIXTURE(BootConfigFixture, HasKey_IsTrue_ForKeyWithOneValue)
    {
        config.Append("key", "value1");
        CHECK(config.HasKey("key"));
    }

    TEST_FIXTURE(BootConfigFixture, HasKey_IsTrue_ForKeyWithMultipleValues)
    {
        config.Append("key", "value1");
        config.Append("key", "value2");
        CHECK(config.HasKey("key"));
    }

    TEST_FIXTURE(BootConfigFixture, HasKey_IsTrue_ForKeysThatOnlyDifferInCasing)
    {
        config.Append("key1");
        config.Append("Key2");
        config.Append("keY3");

        CHECK(config.HasKey("kEy1"));
        CHECK(config.HasKey("KEY1"));
        CHECK(config.HasKey("kEy2"));
        CHECK(config.HasKey("KEY2"));
        CHECK(config.HasKey("kEy3"));
        CHECK(config.HasKey("KEY3"));
    }

    // Append
    TEST_FIXTURE(BootConfigFixture, Append_AddsValueToExisitingKeyThatOnlyDifferInCasing)
    {
        config.Append("key", "value0");
        config.Append("Key", "value1");
        config.Append("keY", "value2");

        CHECK_EQUAL("value0", config.GetValue("key", 0));
        CHECK_EQUAL("value1", config.GetValue("key", 1));
        CHECK_EQUAL("value2", config.GetValue("key", 2));
        CHECK_EQUAL(3, config.GetValueCount("key"));
    }

    TEST_FIXTURE(BootConfigFixture, Append_DoesNotAddValuesToPartiallyMatchingKeys)
    {
        config.Append("key1", "key1value1");
        config.Append("key", "keyvalue1");
        config.Append("key2", "key2value1");
        config.Append("key1", "key1value2");
        config.Append("key", "keyvalue2");
        config.Append("key2", "key2value2");

        CHECK_EQUAL(2, config.GetValueCount("key"));
        CHECK_EQUAL(2, config.GetValueCount("key1"));
        CHECK_EQUAL(2, config.GetValueCount("key2"));
    }

    // Set
    TEST_FIXTURE(BootConfigFixture, Set_WithValue_OverridesPreExistingKeyValues)
    {
        config.Append("key", "value0");
        config.Append("key", "value1");
        config.Set("key", "newvalue0");
        CHECK_EQUAL("newvalue0", config.GetValue("key", 0));
        CHECK_NULL(config.GetValue("key", 1));
    }

    TEST_FIXTURE(BootConfigFixture, Set_WithoutValue_RemovesPreExistingValues)
    {
        config.Append("key", "value0");
        config.Append("key", "value1");
        config.Set("key");
        CHECK(config.HasKey("key"));
        CHECK_NULL(config.GetValue("key", 0));
    }

    // InitFromString
    TEST_FIXTURE(BootConfigFixture, InitFromString_CanParseKeysWithSingleValue)
    {
        const char testStr[] =
            "1 = value1 \n\
             2 = value2 \n\
             3 = value3 \n\
             4 = value4 \n\
             5 = value5";

        config.InitFromString(NULL, 0, testStr);
        CHECK_EQUAL("value1", config.GetValue("1"));
        CHECK_EQUAL("value2", config.GetValue("2"));
        CHECK_EQUAL("value3", config.GetValue("3"));
        CHECK_EQUAL("value4", config.GetValue("4"));
        CHECK_EQUAL("value5", config.GetValue("5"));
    }

    TEST_FIXTURE(BootConfigFixture, InitFromString_CanParseKeysWithMultipleValues)
    {
        const char testStr[] =
            "1 = value10 \n\
             1 = value11 \n\
             2 = value20 \n\
             2 = value21 \n\
             3 = value30 \n\
             3 = value31 \n\
             4 = value40 \n\
             4 = value41 \n\
             5 = value50 \n\
             5 = value51";

        config.InitFromString(NULL, 0, testStr);
        CHECK_EQUAL("value10", config.GetValue("1", 0));
        CHECK_EQUAL("value11", config.GetValue("1", 1));
        CHECK_EQUAL("value20", config.GetValue("2", 0));
        CHECK_EQUAL("value21", config.GetValue("2", 1));
        CHECK_EQUAL("value30", config.GetValue("3", 0));
        CHECK_EQUAL("value31", config.GetValue("3", 1));
        CHECK_EQUAL("value40", config.GetValue("4", 0));
        CHECK_EQUAL("value41", config.GetValue("4", 1));
        CHECK_EQUAL("value50", config.GetValue("5", 0));
        CHECK_EQUAL("value51", config.GetValue("5", 1));
    }

    TEST_FIXTURE(BootConfigFixture, InitFromString_SkipsEmptyLines)
    {
        const char testStr[] =
            "1 = value1 \n\n\n\
             2 = value2 \n\n\n\
             3 = value3 \n\n\n\
             4 = value4 \n\n\n\
             5 = value5 \n\n\n";

        config.InitFromString(NULL, 0, testStr);
        CHECK_EQUAL("value1", config.GetValue("1"));
        CHECK_EQUAL("value2", config.GetValue("2"));
        CHECK_EQUAL("value3", config.GetValue("3"));
        CHECK_EQUAL("value4", config.GetValue("4"));
        CHECK_EQUAL("value5", config.GetValue("5"));
        CHECK(!config.HasKey(""));
    }

    TEST_FIXTURE(BootConfigFixture, InitFromString_CanAddEmptyStringKeyValues)
    {
        const char testStr[] =
            "1 = value1 \n\
               = empty0 \n\
             2 = value2 \n\
               = empty1";

        config.InitFromString(NULL, 0, testStr);
        CHECK_EQUAL("empty0", config.GetValue("", 0));
        CHECK_EQUAL("empty1", config.GetValue("", 1));
        CHECK_EQUAL("value1", config.GetValue("1"));
        CHECK_EQUAL("value2", config.GetValue("2"));
    }

    TEST_FIXTURE(BootConfigFixture, InitFromString_CanAddKeysWithEmptyValue)
    {
        const char testStr[] =
            "1 = value1 \n\
             empty =    \n\
             2 = value2 \n\
             empty =    \n\
             3 = value3 \n\
             empty =";

        config.InitFromString(NULL, 0, testStr);
        CHECK_EQUAL("", config.GetValue("empty", 0));
        CHECK_EQUAL("", config.GetValue("empty", 1));
        CHECK_EQUAL("", config.GetValue("empty", 2));
        CHECK_EQUAL("value1", config.GetValue("1"));
        CHECK_EQUAL("value2", config.GetValue("2"));
        CHECK_EQUAL("value3", config.GetValue("3"));
    }

    // Init
    TEST_FIXTURE(BootConfigFixture, Init_TreatsInitialValuesAsValuesThatBelongToAnEmptyKey)
    {
        const char* testParams[] =
        {
            "no_key_value1", "no_key_value2"
        };
        size_t testParamsLength = sizeof(testParams) / sizeof(*testParams);
        config.Init(testParams, testParamsLength);
        CHECK_EQUAL("no_key_value1", config.GetValue("", 0));
        CHECK_EQUAL("no_key_value2", config.GetValue("", 1));
        CHECK_NULL(config.GetValue("", 2));
    }

    TEST_FIXTURE(BootConfigFixture, Init_TreatsDashPrefixedStringsAsKeys)
    {
        const char* testParams[] =
        {
            "-key1", "-key2"
        };
        size_t testParamsLength = sizeof(testParams) / sizeof(*testParams);
        config.Init(testParams, testParamsLength);
        CHECK(config.HasKey("key1"));
        CHECK(config.HasKey("key2"));
    }

    TEST_FIXTURE(BootConfigFixture, Init_TreatsNonDashPrefixedStringsAfterKeyAsValues)
    {
        const char* testParams[] =
        {
            "-key", "key_value1", "key_value2"
        };
        size_t testParamsLength = sizeof(testParams) / sizeof(*testParams);
        config.Init(testParams, testParamsLength);
        CHECK_EQUAL("key_value1", config.GetValue("key", 0));
        CHECK_EQUAL("key_value2", config.GetValue("key", 1));
    }

    TEST_FIXTURE(BootConfigFixture, Init_TreatsNegativeNumbersAsValues)
    {
        const char* testParams[] =
        {
            "-key", "-1", "-2"
        };
        size_t testParamsLength = sizeof(testParams) / sizeof(*testParams);
        config.Init(testParams, testParamsLength);
        CHECK_EQUAL("-1", config.GetValue("key", 0));
        CHECK_EQUAL("-2", config.GetValue("key", 1));
    }

    TEST_FIXTURE(BootConfigFixture, Init_TreatsSingleDashAsValue)
    {
        const char* testParams[] =
        {
            "-key", "-"
        };
        size_t testParamsLength = sizeof(testParams) / sizeof(*testParams);
        config.Init(testParams, testParamsLength);
        CHECK_EQUAL("-", config.GetValue("key", 0));
    }

    TEST_FIXTURE(BootConfigFixture, Init_OverridesPreExistingKey)
    {
        const char* testParams[] =
        {
            "-key"
        };
        size_t testParamsLength = sizeof(testParams) / sizeof(*testParams);
        config.Append("key", "value");
        config.Init(testParams, testParamsLength);
        CHECK_NULL(config.GetValue("key", 0));
    }

    TEST_FIXTURE(BootConfigFixture, Init_AppendsInitialValuesToEmptyKey)
    {
        const char* testParams[] =
        {
            "value2"
        };
        size_t testParamsLength = sizeof(testParams) / sizeof(*testParams);
        config.Append("", "value1");
        config.Init(testParams, testParamsLength);
        CHECK_EQUAL("value2", config.GetValue("", 1));
    }

    TEST_FIXTURE(BootConfigFixture, Init_LastKeyOverridesPreviousKey)
    {
        const char* testParams[] =
        {
            "-key", "value1",
            "-key", "value2"
        };
        size_t testParamsLength = sizeof(testParams) / sizeof(*testParams);
        config.Init(testParams, testParamsLength);
        CHECK_EQUAL("value2", config.GetValue("key", 0));
    }
}

REGRESSION_TEST_SUITE(BootConfigData)
{
    TEST_FIXTURE(BootConfigFixture, InitFromString_WithRandomStringData_DoesntCrash)
    {
        srand(73);
        char testString[16384];
        for (int i = 0; i < sizeof(testString) - 1; ++i)
            testString[i] = (rand() & 0x7e) + 1;
        testString[sizeof(testString) - 1] = 0;

        config.InitFromString(NULL, 0, testString);
    }
}

#include "Runtime/Utilities/PathNameUtility.h"
#include "Runtime/Misc/SystemInfo.h"
#include <stdlib.h>
#include <stdio.h>

INTEGRATION_TEST_SUITE(BootConfigData)
{
    // TODO: Add integrations tests (using fakes?) testing disk full and filesystem corruption situations

    TEST_FIXTURE(BootConfigFixture, InitFromFile_WithInvalidFileName_ReturnFalse)
    {
        CHECK(!config.InitFromFile(NULL, 0, "/invald_file_name_2251"));
    }

    static core::string GetWritableTestFilePath(const core::string& filename)
    {
#if PLATFORM_PSVITA
        // On Vita there is no writable file system that apps can trivially access so GetTemporaryCachePath() quite rightly errors and returns
        // an empty string. On PC-connected dev-kits we can write to "host0:\" which is the PC file system that the dev-kit is connected to.
        return AppendPathName("host0:/", filename);
#else
        return AppendPathName(systeminfo::GetTemporaryCachePath(), filename);
#endif
    }

    TEST_FIXTURE(BootConfigFixture, InitFromFile_WithValidFile_LoadsAllKeysAndValues)
    {
        core::string filename = GetWritableTestFilePath("BootConfig.test");
        {
            const char fileData[] =
                "1 = value1 \n\
                 2 = value2 \n\
                 3 = value3 \n\
                 4 = value4 \n\
                 5 = value5";

#if PLATFORM_WIN
            core::wstring filenameW;
            ConvertUTF8ToWideString(filename, filenameW);
            FILE* fd = _wfopen(filenameW.c_str(), L"wb");
#else
            FILE* fd = fopen(filename.c_str(), "wb");
#endif
            CHECK_MSG(fd, Format("Unable to write test file '%s'", filename.c_str()).c_str());
            if (!fd)
                return;
            fwrite(fileData, sizeof(fileData), 1, fd);
            fclose(fd);

            config.InitFromFile(NULL, 0, filename.c_str());
            CHECK_EQUAL("value1", config.GetValue("1"));
            CHECK_EQUAL("value2", config.GetValue("2"));
            CHECK_EQUAL("value3", config.GetValue("3"));
            CHECK_EQUAL("value4", config.GetValue("4"));
            CHECK_EQUAL("value5", config.GetValue("5"));
        }
        remove(filename.c_str());
    }

    TEST(SaveToFile_WithValidFileName_StoresAllKeysAndValuesToDisk)
    {
        core::string filename = GetWritableTestFilePath("BootConfig.test");
        {
            BootConfig::Data config;
            config.Append("", "origvalue1");
            config.Append("key1", "key1_origvalue1");
            config.Append("key1", "key1_origvalue2");
            config.Append("key1", "key1_origvalue3");
            config.Append("key2", "key2_origvalue1");
            bool result = config.SaveToFile(filename.c_str());
            CHECK_MSG(result, Format("Unable to write test file '%s'", filename.c_str()).c_str());
            if (!result)
                return;
        }
        {
            BootConfig::Data config;
            config.InitFromFile(NULL, 0, filename.c_str());
            CHECK_EQUAL("origvalue1", config.GetValue("", 0));
            CHECK_NULL(config.GetValue("", 1));
            CHECK_EQUAL("key1_origvalue1", config.GetValue("key1", 0));
            CHECK_EQUAL("key1_origvalue2", config.GetValue("key1", 1));
            CHECK_EQUAL("key1_origvalue3", config.GetValue("key1", 2));
            CHECK_NULL(config.GetValue("key1", 3));
            CHECK_EQUAL("key2_origvalue1", config.GetValue("key2", 0));
            CHECK_NULL(config.GetValue("key2", 1));
        }
        remove(filename.c_str());
    }
}

#endif
