using JamSharp.Runtime;
using static JamSharp.Runtime.BuiltinRules;
using External.Jamplus.builds.bin.modules;
using External.Jamplus.builds.bin;

namespace Runtime.AI
{
    [OriginalJamFile("Runtime/AI/AIModule.jam")]
    class AIModule : ConvertedJamFile
    {
        internal static void TopLevel()
        {
            RegisterRuleWithReturnValue("AIModule_ReportCpp", AIModule_ReportCpp);
            RegisterRuleWithReturnValue("AIModule_ReportCs", AIModule_ReportCs);
            RegisterRuleWithReturnValue("AIModule_ReportBindings", AIModule_ReportBindings);
            RegisterRuleWithReturnValue("AIModule_ReportIncludes", AIModule_ReportIncludes);
        }

        static JamList AIModule_ReportCpp()
        {
            JamList runtimeFiles = Projects.Jam.Rules.UnityRules.Unity_Glob($"{Vars.TOP}/Runtime/AI", JamList("cpp", "h", "jam"), Vars.TOP);
            JamList recastFiles = JamList(
                    "Recast/Include/Recast.h",
                    "Recast/Include/RecastAlloc.h",
                    "Recast/Include/RecastAssert.h",
                    "Recast/Source/Recast.cpp",
                    "Recast/Source/RecastAlloc.cpp",
                    "Recast/Source/RecastArea.cpp",
                    "Recast/Source/RecastContour.cpp",
                    "Recast/Source/RecastFilter.cpp",
                    "Recast/Source/RecastMesh.cpp",
                    "Recast/Source/RecastMeshDetail.cpp",
                    "Recast/Source/RecastRasterization.cpp",
                    "Recast/Source/RecastRegion.cpp");

            return JamList(runtimeFiles, Combine("External/Recast/", recastFiles));
        }

        static JamList AIModule_ReportCs()
        {
            JamList managedFiles = Projects.Jam.Rules.UnityRules.Unity_Glob($"{Vars.TOP}/Runtime/AI/Managed", "cs", Vars.TOP);

            return managedFiles;
        }

        static JamList AIModule_ReportBindings()
        {
            JamList bindingFiles = Projects.Jam.Rules.UnityRules.Unity_Glob($"{Vars.TOP}/Runtime/AI/ScriptBindings", "bindings", Vars.TOP);

            return bindingFiles;
        }

        static JamList AIModule_ReportIncludes()
        {
            return "External/Recast/Recast/Include";
        }
    }
}
