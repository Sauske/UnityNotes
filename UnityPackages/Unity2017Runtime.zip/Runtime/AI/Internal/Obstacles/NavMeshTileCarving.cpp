#include "UnityPrefix.h"
#include "NavMeshCarveTypes.h"
#include "NavMeshTileCarving.h"
#include "DynamicMesh.h"
#include "HullAvoidance.h"
#include "../NavMesh/NavMesh.h"
#include "../NavMeshBindingTypes.h"
#include "../MathUtil.h"
#include "Runtime/Geometry/AABB.h"
#include "Runtime/Geometry/Intersection.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Utilities/Align.h"
#include "Runtime/Math/Matrix3x3.h"
#include "Runtime/Profiler/Profiler.h"

PROFILER_INFORMATION(gNavMeshCarveHullsPrepare, "Carving.ConvexHulls", kProfilerAI)
PROFILER_INFORMATION(gNavMeshCarveProjectVertices, "Carving.ProjectVertices", kProfilerAI)
PROFILER_INFORMATION(gNavMeshCarveBuildBVTree, "Carving.BuildBVTree", kProfilerAI)
PROFILER_INFORMATION(gNavMeshTileToDynamicMesh, "DynamicMesh.TileToDynamicMesh", kProfilerAI)
PROFILER_INFORMATION(gNavMeshDynamicMeshToTile, "DynamicMesh.DynamicMeshToTile", kProfilerAI)
PROFILER_INFORMATION(gNavMeshWriteDetailMesh, "DynamicMesh.WriteDetailMesh", kProfilerAI)
PROFILER_INFORMATION(gNavMeshClipDetailMesh, "DynamicMesh.ClipDetailMesh", kProfilerAI)

const float MAGIC_EDGE_DISTANCE = 1e-2f; // Same as used in detour navmesh builder.

typedef VertexWelder<64> DetailVertexWelder;

struct ClippedDetailMesh
{
    explicit ClippedDetailMesh(MemLabelId label)
        : polyIndex(0)
        , vertices(label)
        , triangles(label)
    {}
    int polyIndex;
    dynamic_array<Vector3f> vertices;
    dynamic_array<unsigned short> triangles;
};

struct DetailMeshBVNode
{
    Vector3f min, max;
    int idx;
};

struct DetailMeshPoly
{
    int vertBase;
    int vertCount;
    int triBase;
    int triCount;
    int bvBase;
    int bvCount;
};

struct DetailMesh
{
    explicit DetailMesh(MemLabelId label)
        : vertices(label)
        , triangles(label)
        , polys(label)
        , bvNodes(label)
    {}
    dynamic_array<Vector3f> vertices;
    dynamic_array<unsigned short> triangles;
    dynamic_array<DetailMeshPoly> polys;
    dynamic_array<DetailMeshBVNode> bvNodes;
};

static void UnpackDetailMesh(DetailMesh& detailMesh, const NavMeshTile* tile, const Vector3f& tileOffset);
static bool BuildDetailHulls(DynamicMesh::DetailHullContainer& hulls,
    const DynamicMesh::Hull& hull, const MinMaxAABB& bounds,
    const DetailMesh& detailMesh, const NavMeshTile* tile, const Vector3f& tileOffset, float quantSize);
static void ProjectNewVerticesToDetailMesh(DynamicMesh& mesh, const DetailMesh& detailMesh);
static void RequirementsForDetailMeshMixed(int* detailVertCount, int* detailTriCount
    , const DynamicMesh& mesh, const NavMeshTile* sourceTile
    , const dynamic_array<ClippedDetailMesh*>& clipped);
static void WriteDetailMeshMixed(NavMeshPolyDetail* detail, Vector3f* dverts, NavMeshPolyDetailIndex* dtris
    , const DynamicMesh& mesh, const NavMeshTile* sourceTile, const Vector3f& tileOffset, const dynamic_array<ClippedDetailMesh*>& clipped
    , const int detailTriCount, const int detailVertCount);
static void ClipDetailMeshes(dynamic_array<ClippedDetailMesh*>& clipped, const DynamicMesh& mesh, const DetailMesh& detailMesh, const NavMeshTile* sourceTile, const Vector3f& tileOffset, const float quantFactor);
static unsigned char* DynamicMeshToTile(int* dataSize, const DynamicMesh& mesh, const dynamic_array<ClippedDetailMesh*>& clipped,
    const NavMeshTile* sourceTile, const Vector3f& tileOffset);

static inline Vector3f TileMidpoint(const NavMeshDataHeader* tileHeader);
static bool CalculateBoxHull(DynamicMesh::Hull& carveHull, const NavMeshCarveShape& shape, const Vector3f& tileOffset,
    const float carveDepth, const float carveWidth);
static bool CalculateCapsuleHull(DynamicMesh::Hull& carveHull, const NavMeshCarveShape& shape, const Vector3f& tileOffset,
    const float carveDepth, const float carveWidth);
static void SimplifyPolyline(Vertex2Array& hull, float thr);
static void OffsetPolygon(Vertex2Array& dest, const Vertex2Array& poly, const float offset);
static bool PatchMeshTilePointers(NavMeshTile* tile, const unsigned char* data, const int dataSize);
static void TileToDynamicMesh(const NavMeshTile* tile, DynamicMesh& mesh, const Vector3f& tileOffset);


// Replaces a single tile in the detour navmesh with a carved tile.
CarveResultStatus CarveNavMeshTile(unsigned char** tileData, int* tileDataSize,
    const unsigned char* sourceData, int sourceDataSize,
    const NavMeshCarveShape* shapes, int shapeCount,
    float carveDepth, float carveWidth, float quantSize,
    const Vector3f& position, const Quaternionf& rotation)
{
    Assert(sourceData != NULL);
    Assert(sourceDataSize > 0);

    *tileData = NULL;
    *tileDataSize = 0;

    if (shapeCount == 0)
    {
        return kRestoreTile;
    }

    NavMeshTile tile;
    if (!PatchMeshTilePointers(&tile, sourceData, sourceDataSize))
    {
        // remove tile altogether if we cannot patch source data pointers
        return kRemoveTile;
    }

    Assert(tile.header != NULL);

    const Vector3f tileOffset = 0.5f * (Vector3f(tile.header->bmin) + Vector3f(tile.header->bmax));

    PROFILER_BEGIN(gNavMeshCarveBuildBVTree, NULL);

    DetailMesh detailMesh(kMemTempAlloc);
    UnpackDetailMesh(detailMesh, &tile, tileOffset);

    PROFILER_END(gNavMeshCarveBuildBVTree);

    PROFILER_BEGIN(gNavMeshCarveHullsPrepare, NULL);

    Matrix4x4f mat;
    mat.SetTRInverse(position, rotation);

    DynamicMesh::Hull hull(kMemTempAlloc);
    hull.reserve(32);
    DynamicMesh::DetailHullContainer carveHulls;
    for (int i = 0; i < shapeCount; ++i)
    {
        NavMeshCarveShape localShape;
        localShape.shape = shapes[i].shape;
        localShape.center = mat.MultiplyPoint3(shapes[i].center);
        localShape.extents = shapes[i].extents;
        localShape.xAxis = mat.MultiplyVector3(shapes[i].xAxis);
        localShape.yAxis = mat.MultiplyVector3(shapes[i].yAxis);
        localShape.zAxis = mat.MultiplyVector3(shapes[i].zAxis);
        TransformAABBSlow(shapes[i].bounds, mat, localShape.bounds);

        bool validHull = false;

        if (localShape.shape == kObstacleShapeCapsule)
        {
            validHull = CalculateCapsuleHull(hull, localShape, tileOffset, carveDepth, carveWidth);
        }
        else if (localShape.shape == kObstacleShapeBox)
        {
            validHull = CalculateBoxHull(hull, localShape, tileOffset, carveDepth, carveWidth);
        }

        if (!validHull)
            continue;

        // Find potentially intersecting polygons and create new cutter
        // based on the intersection points in detail mesh.

        MinMaxAABB localBounds = localShape.bounds;
        localBounds.m_Min -= tileOffset;
        localBounds.m_Max -= tileOffset;
        // Expand by agent size
        // bounds are extended so that corners can be offset up to (and a little over) a factor of sqrt(2)
        const float scaleExtents = 1.415f;

        localBounds.m_Min += Vector3f(-carveWidth, -carveDepth, -carveWidth) * scaleExtents;
        localBounds.m_Max += Vector3f(carveWidth, 0, carveWidth) * scaleExtents;

        DynamicMesh::DetailHullContainer detailHulls;
        validHull = BuildDetailHulls(detailHulls, hull, localBounds, detailMesh, &tile, tileOffset, quantSize);

        if (validHull)
            carveHulls.insert(carveHulls.end(), detailHulls.begin(), detailHulls.end());
    }

    PROFILER_END(gNavMeshCarveHullsPrepare); // gNavMeshCarveHullsPrepare

    // The vertex quantization factor needs to match the tile size
    // in order to not get any gaps at tile boundaries.
    // As long as the divider is large enough and divisible by 2
    // (because tileOffset is at tile center during carving),
    // things should work fine.
    const float quantFactor = quantSize;

    DynamicMesh dynamicMesh(quantFactor);
    TileToDynamicMesh(&tile, dynamicMesh, tileOffset);

    // Restore if nothing was clipped
    if (!dynamicMesh.ClipPolys(carveHulls))
        return kRestoreTile;

    // Remove if nothing is left
    if (dynamicMesh.PolyCount() == 0)
        return kReplaceTile;

    PROFILER_BEGIN(gNavMeshCarveProjectVertices, NULL);
    // Project new vertices to detail meshes.

    ProjectNewVerticesToDetailMesh(dynamicMesh, detailMesh);

    PROFILER_END(gNavMeshCarveProjectVertices); // gNavMeshCarveProjectVertices

    dynamicMesh.FindNeighbors();

    // Clip the detail traingles of the original polygons to match each new polygon.
    dynamic_array<ClippedDetailMesh*> clipped(kMemTempAlloc);
    clipped.resize_initialized(dynamicMesh.PolyCount(), NULL);
    ClipDetailMeshes(clipped, dynamicMesh, detailMesh, &tile, tileOffset, quantFactor);

    *tileData = DynamicMeshToTile(tileDataSize, dynamicMesh, clipped, &tile, tileOffset);

    for (int i = 0; i < clipped.size(); i++)
    {
        if (clipped[i] != NULL)
            UNITY_DELETE(clipped[i], kMemTempAlloc);
    }

    return kReplaceTile;
}

static bool PatchMeshTilePointers(NavMeshTile* tile, const unsigned char* data, const int dataSize)
{
    NavMeshDataHeader* header = (NavMeshDataHeader*)data;
    tile->header = NULL;

    if (header->magic != kNavMeshMagic)
        return false;
    if (header->version != kNavMeshVersion)
        return false;

    tile->header = header;

    // Patch header pointers.
    const int headerSize = Align4(sizeof(NavMeshDataHeader));
    const int vertsSize = Align4(sizeof(Vector3f) * header->vertCount);
    const int polysSize = Align4(sizeof(NavMeshPoly) * header->polyCount);
    const int detailMeshesSize = Align4(sizeof(NavMeshPolyDetail) * header->detailMeshCount);
    const int detailVertsSize = Align4(sizeof(Vector3f) * header->detailVertCount);
    const int detailTrisSize = Align4(sizeof(NavMeshPolyDetailIndex) * 4 * header->detailTriCount);
    const int bvtreeSize = Align4(sizeof(NavMeshBVNode) * header->bvNodeCount);

    const unsigned char* d = data + headerSize;
    tile->verts = (Vector3f*)d; d += vertsSize;
    tile->polys = (NavMeshPoly*)d; d += polysSize;
    tile->detailMeshes = (NavMeshPolyDetail*)d; d += detailMeshesSize;
    tile->detailVerts = (Vector3f*)d; d += detailVertsSize;
    tile->detailTris = (NavMeshPolyDetailIndex*)d; d += detailTrisSize;
    tile->bvTree = (NavMeshBVNode*)d; //d += bvtreeSize;

    // If there are no items in the bvtree, reset the tree pointer.
    if (!bvtreeSize)
        tile->bvTree = NULL;

    return true;
}

// TODO: make the clipping functions in dynamic mesh more generic.
// Clip the convex polygon 'poly' by the half-space defined by 'plane'
static int SplitPolyByPlane(dynamic_array<Vector3f>& inside, const dynamic_array<Vector3f>& poly, const Plane& plane)
{
    const size_t vertexCount = poly.size();

    // Worst case number of vertices is kNumVerts + hull clipping planes
    DebugAssert(vertexCount < 32);
    float dist[32];

    // Compute signed distance to plane for each vertex
    float minDistance, maxDistance;
    minDistance = maxDistance = dist[0] = plane.GetDistanceToPoint(poly[0]);
    for (size_t iv = 1; iv < vertexCount; ++iv)
    {
        const Vector3f& v = poly[iv];
        const float distance = plane.GetDistanceToPoint(v);
        dist[iv] = distance;
        minDistance = std::min(minDistance, distance);
        maxDistance = std::max(maxDistance, distance);
    }

    // Trivially accept
    if (maxDistance <= 0)
    {
        return -1;
    }

    // Trivially reject
    if (minDistance > 0)
    {
        return 1;
    }

    // Split
    inside.resize_uninitialized(0);

    Vector3f prevVert = poly[vertexCount - 1];
    float prevDist = dist[vertexCount - 1];

    for (size_t iv = 0; iv < vertexCount; ++iv)
    {
        const Vector3f& currVert = poly[iv];
        const float currDist = dist[iv];

        if (currDist < 0 && prevDist > 0)
        {
            const float absDist = -currDist;
            const float w = absDist / (absDist + prevDist);
            inside.emplace_back_uninitialized() = Lerp(currVert, prevVert, w);
        }
        else if (currDist > 0 && prevDist < 0)
        {
            const float absDist = -prevDist;
            const float w = absDist / (absDist + currDist);
            inside.emplace_back_uninitialized() = Lerp(prevVert, currVert, w);
        }

        if (currDist <= 0)
        {
            inside.push_back(currVert);
        }

        prevVert = currVert;
        prevDist = currDist;
    }

    return 0;
}

static void HullPolygonIntersection(dynamic_array<Vector3f>& inside, const dynamic_array<Plane>& hull, dynamic_array<Vector3f>& temp)
{
    const size_t planeCount = hull.size();

    for (size_t ic = 0; ic < planeCount; ++ic)
    {
        const Plane& plane = hull[ic];
        int result = SplitPolyByPlane(temp, inside, plane);
        if (result == 0)
        {
            inside = temp;
        }
        else if (result == 1)
        {
            inside.resize_uninitialized(0);
            return;
        }
    }
}

struct DetailNodeXSorter
{
    bool operator()(const DetailMeshBVNode& ra, const DetailMeshBVNode& rb) const
    {
        const float a = (ra.min.x + ra.max.x) * 0.5f;
        const float b = (rb.min.x + rb.max.x) * 0.5f;
        return a < b;
    }
};

struct DetailNodeYSorter
{
    bool operator()(const DetailMeshBVNode& ra, const DetailMeshBVNode& rb) const
    {
        const float a = (ra.min.y + ra.max.y) * 0.5f;
        const float b = (rb.min.y + rb.max.y) * 0.5f;
        return a < b;
    }
};

struct DetailNodeZSorter
{
    bool operator()(const DetailMeshBVNode& ra, const DetailMeshBVNode& rb) const
    {
        const float a = (ra.min.z + ra.max.z) * 0.5f;
        const float b = (rb.min.z + rb.max.z) * 0.5f;
        return a < b;
    }
};


inline bool OverlapBoundsXZ(const Vector3f& amin, const Vector3f& amax,
    const Vector3f& bmin, const Vector3f& bmax)
{
    if (amin.x > bmax.x || amax.x < bmin.x)
        return false;
    if (amin.z > bmax.z || amax.z < bmin.z)
        return false;
    return true;
}

inline int DetailLongestAxis(const Vector3f& v)
{
    int axis = 0;
    if (v[1] > v[axis])
        axis = 1;
    if (v[2] > v[axis])
        axis = 2;
    return axis;
}

static void Subdivide(dynamic_array<DetailMeshBVNode>& nodes,
    dynamic_array<DetailMeshBVNode>& items,
    int imin, int imax)
{
    int inum = imax - imin;

    DetailMeshBVNode& node = nodes.emplace_back_uninitialized();
    const int icur = nodes.size() - 1;

    // Update bounds
    node.min = items[imin].min;
    node.max = items[imin].max;
    for (int i = imin + 1; i < imax; ++i)
    {
        node.min = min(node.min, items[i].min);
        node.max = max(node.max, items[i].max);
    }

    if ((imax - imin) <= 1)
    {
        // Leaf, copy triangles.
        node.idx = items[imin].idx;
    }
    else
    {
        // Split remaining items along longest axis
        const int axis = DetailLongestAxis(node.max - node.min);
        if (axis == 0)
            std::sort(items.begin() + imin, items.begin() + imax, DetailNodeXSorter());
        else if (axis == 1)
            std::sort(items.begin() + imin, items.begin() + imax, DetailNodeYSorter());
        else
            std::sort(items.begin() + imin, items.begin() + imax, DetailNodeZSorter());
        int isplit = imin + inum / 2;

        // Left
        Subdivide(nodes, items, imin, isplit);
        // Right
        Subdivide(nodes, items, isplit, imax);

        int iescape = (nodes.size() - 1) - icur;
        // Negative index means escape.
        nodes[icur].idx = -iescape; // 'node' ref may be invalid because of realloc.
    }
}

static bool BuildBVTree(dynamic_array<DetailMeshBVNode>& nodes,
    const Vector3f* vertices,
    unsigned short* tris, int triCount)
{
    nodes.clear();

    // Build input items
    dynamic_array<DetailMeshBVNode> items(kMemTempAlloc);
    items.resize_uninitialized(triCount);
    for (int i = 0; i < triCount; i++)
    {
        const unsigned short* t = &tris[i * 4];
        DetailMeshBVNode& it = items[i];
        it.idx = i;
        // Calc triangle bounds.
        it.min = it.max = vertices[t[0]];
        it.min = min(it.min, vertices[t[1]]);
        it.max = max(it.max, vertices[t[1]]);
        it.min = min(it.min, vertices[t[2]]);
        it.max = max(it.max, vertices[t[2]]);
    }

    Subdivide(nodes, items, 0, triCount);

    return true;
}

struct QueryDetailBVTreeCallback
{
    virtual void process(const DetailMesh& detailMesh, const DetailMeshPoly& poly, const int* tris, int triCount) = 0;
};

static void QueryDetailBVTree(const DetailMesh& detailMesh, const DetailMeshPoly& poly,
    const Vector3f& queryMin, const Vector3f& queryMax,
    QueryDetailBVTreeCallback* callback)
{
    static const int BATCH_SIZE = 32;
    int batch[BATCH_SIZE];
    int batchCount = 0;

    // Clip all detail triangles against the polygon.
    if (poly.bvCount > 0)
    {
        const DetailMeshBVNode* nodes = &detailMesh.bvNodes[poly.bvBase];
        int n = 0;
        while (n < poly.bvCount)
        {
            const DetailMeshBVNode& node = nodes[n];

            const bool overlap = OverlapBoundsXZ(queryMin, queryMax, node.min, node.max);
            const bool isLeafNode = node.idx >= 0;

            if (isLeafNode && overlap)
            {
                if (batchCount + 1 > BATCH_SIZE)
                {
                    callback->process(detailMesh, poly, batch, batchCount);
                    batchCount = 0;
                }
                batch[batchCount++] = poly.triBase + node.idx;
            }

            if (overlap || isLeafNode)
            {
                n++;
            }
            else
            {
                const int escapeIndex = -node.idx;
                n += escapeIndex;
            }
        }
    }
    else
    {
        for (int j = 0; j < poly.triCount; j++)
        {
            if (batchCount + 1 > BATCH_SIZE)
            {
                callback->process(detailMesh, poly, batch, batchCount);
                batchCount = 0;
            }
            batch[batchCount++] = poly.triBase + j;
        }
    }

    if (batchCount > 0)
    {
        callback->process(detailMesh, poly, batch, batchCount);
        batchCount = 0;
    }
}

static void UnpackDetailMesh(DetailMesh& detailMesh, const NavMeshTile* tile, const Vector3f& tileOffset)
{
    // Unpack
    const int vertCount = tile->header->vertCount;
    const int polyCount = tile->header->polyCount;
    const int detailVertCount = tile->header->detailVertCount;
    const int detailTriCount = tile->header->detailTriCount;
    const int detailPolyCount = tile->header->detailMeshCount;

    Assert(polyCount == detailPolyCount);

    detailMesh.vertices.reserve(detailVertCount + vertCount);
    detailMesh.triangles.resize_uninitialized(detailTriCount * 4);
    detailMesh.polys.resize_uninitialized(detailPolyCount);

    int bvTriCount = 0;
    int maxTriCount = 0;
    static const int kBVTreeThreshold = 6;

    for (int i = 0; i < polyCount; i++)
    {
        const NavMeshPoly* p = &tile->polys[i];
        const NavMeshPolyDetail* pd = &tile->detailMeshes[i];

        DetailMeshPoly& poly = detailMesh.polys[i];

        poly.bvBase = 0;
        poly.bvCount = 0;

        poly.vertBase = detailMesh.vertices.size();
        poly.vertCount = p->vertCount + pd->vertCount;
        for (int j = 0; j < p->vertCount; j++)
        {
            detailMesh.vertices.push_back(tile->verts[p->verts[j]] - tileOffset);
        }
        for (int j = 0; j < pd->vertCount; j++)
        {
            detailMesh.vertices.push_back(tile->detailVerts[pd->vertBase + j] - tileOffset);
        }

        poly.triBase = pd->triBase;
        poly.triCount = pd->triCount;
        for (int j = 0; j < pd->triCount; ++j)
        {
            const NavMeshPolyDetailIndex* t = &tile->detailTris[(pd->triBase + j) * 4];
            detailMesh.triangles[(pd->triBase + j) * 4 + 0] = t[0];
            detailMesh.triangles[(pd->triBase + j) * 4 + 1] = t[1];
            detailMesh.triangles[(pd->triBase + j) * 4 + 2] = t[2];
            detailMesh.triangles[(pd->triBase + j) * 4 + 3] = t[3];
        }

        if (poly.triCount > kBVTreeThreshold)
        {
            bvTriCount += poly.triCount;
            maxTriCount = std::max(maxTriCount, poly.triCount);
        }
    }

    if (bvTriCount > 0)
    {
        // Build BV-tree for polys which have many detail triangles.
        detailMesh.bvNodes.reserve(bvTriCount * 2);

        dynamic_array<DetailMeshBVNode> nodes(kMemTempAlloc);
        nodes.reserve(maxTriCount);

        for (int i = 0; i < polyCount; i++)
        {
            DetailMeshPoly& poly = detailMesh.polys[i];
            if (poly.triCount > kBVTreeThreshold)
            {
                BuildBVTree(nodes, &detailMesh.vertices[poly.vertBase], &detailMesh.triangles[poly.triBase * 4], poly.triCount);
                const int nodeCount = nodes.size();
                if (nodeCount > 0)
                {
                    poly.bvBase = detailMesh.bvNodes.size();
                    poly.bvCount = nodeCount;
                    detailMesh.bvNodes.resize_uninitialized(poly.bvBase + nodeCount);
                    for (int j = 0; j < nodeCount; j++)
                        detailMesh.bvNodes[poly.bvBase + j] = nodes[j];
                }
            }
        }
    }
}

static void ClosestHeightToTriangleEdge(float* height, float* dmin,
    const Vector3f& samplePos,
    const Vector3f& va, const Vector3f& vb, const Vector3f& vc)
{
    float d, t;
    *dmin = FLT_MAX;
    d = SqrDistancePointSegment2D(&t, samplePos, va, vb);
    if (d < *dmin)
    {
        *height = va.y + (vb.y - va.y) * t;
        *dmin = d;
    }
    d = SqrDistancePointSegment2D(&t, samplePos, vb, vc);
    if (d < *dmin)
    {
        *height = vb.y + (vc.y - vb.y) * t;
        *dmin = d;
    }
    d = SqrDistancePointSegment2D(&t, samplePos, vc, va);
    if (d < *dmin)
    {
        *height = vc.y + (va.y - vc.y) * t;
        *dmin = d;
    }
}

static void PickDetailTriHeight(float* height, float* dmin,
    const Vector3f& samplePos,
    const Vector3f& va, const Vector3f& vb, const Vector3f& vc)
{
    float h = 0;
    if (ClosestHeightPointTriangle(&h, samplePos, va, vb, vc))
    {
        *height = h;
        *dmin = 0.0f;
    }
    if (*dmin > 0.0f)
    {
        float dist;
        ClosestHeightToTriangleEdge(&h, &dist, samplePos, va, vb, vc);
        if (dist < *dmin)
        {
            *height = h;
            *dmin = dist;
        }
    }
}

static float PickDetailPolyHeight(const DetailMesh& detailMesh, int polyIdx, const Vector3f& samplePos)
{
    struct PickHeightCallback : public QueryDetailBVTreeCallback
    {
        Vector3f samplePos;
        float height, dmin;

        explicit PickHeightCallback(const Vector3f& pos) :
            samplePos(pos), height(pos.y), dmin(FLT_MAX)
        {
        }

        virtual void process(const DetailMesh& detailMesh, const DetailMeshPoly& poly, const int* tris, int triCount)
        {
            for (int i = 0; i < triCount; i++)
            {
                const unsigned short* t = &detailMesh.triangles[tris[i] * 4];
                const Vector3f& va = detailMesh.vertices[poly.vertBase + t[0]];
                const Vector3f& vb = detailMesh.vertices[poly.vertBase + t[1]];
                const Vector3f& vc = detailMesh.vertices[poly.vertBase + t[2]];
                PickDetailTriHeight(&height, &dmin, samplePos, va, vb, vc);
            }
        }
    };

    const DetailMeshPoly& poly = detailMesh.polys[polyIdx];

    const Vector3f sampleExt(0.1f, 0, 0.1f);
    const Vector3f queryMin = samplePos - sampleExt;
    const Vector3f queryMax = samplePos + sampleExt;

    PickHeightCallback callback(samplePos);

    QueryDetailBVTree(detailMesh, poly, queryMin, queryMax, &callback);

    return callback.height;
}

static void ProjectNewVerticesToDetailMesh(DynamicMesh& mesh, const DetailMesh& detailMesh)
{
    const int vertCount = mesh.VertCount();
    const int polyCount = mesh.PolyCount();

    dynamic_array<int> vertexSourcePoly(kMemTempAlloc);
    vertexSourcePoly.resize_initialized(vertCount, -1);

    // Check which vertices have changed and store their original polygon too.
    // TODO: check if we need to store all source polys, now just projecting to the last one.
    for (int i = 0; i < polyCount; i++)
    {
        const DynamicMesh::Poly* p = mesh.GetPoly(i);
        if (p->m_Status != DynamicMesh::kOriginalPolygon)
        {
            const int sourcePolyIndex = *mesh.GetData(i);
            for (int j = 0; j < p->m_VertexCount; j++)
            {
                vertexSourcePoly[p->m_VertexIDs[j]] = sourcePolyIndex;
            }
        }
    }

    for (int i = 0; i < vertCount; i++)
    {
        const int ip = vertexSourcePoly[i];
        if (ip == -1)
            continue;
        Vector3f pos = mesh.GetVertex(i);
        pos.y = PickDetailPolyHeight(detailMesh, ip, pos);
        mesh.SetVertex(i, pos);
    }
}

static void CalcPolyDetailBounds(MinMaxAABB& bounds, const DetailMesh& detailMesh, const int ip)
{
    const DetailMeshPoly& poly = detailMesh.polys[ip];
    bounds.m_Min = bounds.m_Max = detailMesh.vertices[poly.vertBase];
    for (int i = 1; i < poly.vertCount; i++)
        bounds.Encapsulate(detailMesh.vertices[poly.vertBase + i]);
}

// Check if any vertex lies close to the boundary defined by bmin/bmax.
static bool HasBoundaryVertices(const Vertex2Array& verts, const Vector2f& bmin, const Vector2f& bmax)
{
    Assert(verts.size() > 0);

    Vector2f vmin, vmax;
    vmin.x = vmax.x = verts[0].x;
    vmin.y = vmax.y = verts[0].y;
    for (size_t i = 1; i < verts.size(); ++i)
    {
        vmin = min(vmin, verts[i]);
        vmax = max(vmax, verts[i]);
    }

    const Vector2f dmin = vmin - bmin;
    if (Sqr(dmin.x) < Sqr(MAGIC_EDGE_DISTANCE))
        return true;
    if (Sqr(dmin.y) < Sqr(MAGIC_EDGE_DISTANCE))
        return true;

    const Vector2f dmax = vmax - bmax;
    if (Sqr(dmax.x) < Sqr(MAGIC_EDGE_DISTANCE))
        return true;
    if (Sqr(dmax.y) < Sqr(MAGIC_EDGE_DISTANCE))
        return true;

    return false;
}

static bool BuildDetailHulls(DynamicMesh::DetailHullContainer& detailHulls,
    const DynamicMesh::Hull& hull, const MinMaxAABB& bounds,
    const DetailMesh& detailMesh, const NavMeshTile* tile, const Vector3f& tileOffset, float quantSize)
{
    struct ClipCallback : public QueryDetailBVTreeCallback
    {
        const DynamicMesh::Hull& m_Hull;
        dynamic_array<Vector3f>& m_Inside;
        dynamic_array<Vector3f>& m_Temp;
        dynamic_array<Vector2f>& m_Footprint;
        bool m_Hit;

        ClipCallback(const DynamicMesh::Hull& hull, dynamic_array<Vector3f>& inside, dynamic_array<Vector3f>& temp, dynamic_array<Vector2f>& footPrint)
            : m_Hull(hull)
            , m_Inside(inside)
            , m_Temp(temp)
            , m_Footprint(footPrint)
            , m_Hit(false)
        {
        }

        virtual void process(const DetailMesh& detailMesh, const DetailMeshPoly& poly, const int* tris, int triCount)
        {
            for (int i = 0; i < triCount; i++)
            {
                const unsigned short* t = &detailMesh.triangles[tris[i] * 4];
                m_Inside.resize_uninitialized(3);
                m_Inside[0] = detailMesh.vertices[poly.vertBase + t[0]];
                m_Inside[1] = detailMesh.vertices[poly.vertBase + t[1]];
                m_Inside[2] = detailMesh.vertices[poly.vertBase + t[2]];

                HullPolygonIntersection(m_Inside, m_Hull, m_Temp);
                if (m_Inside.empty())
                    continue;

                for (int i = 0; i < m_Inside.size(); ++i)
                {
                    Vector2f& v = m_Footprint.emplace_back_uninitialized();
                    v.x = m_Inside[i].x;
                    v.y = m_Inside[i].z;
                }
                m_Hit = true;
            }
        }
    };

    const int polyCount = tile->header->polyCount;

    dynamic_array<Vector3f> inside(kMemTempAlloc);
    dynamic_array<Vector3f> temp(kMemTempAlloc);
    dynamic_array<Vector2f> footPrint(kMemTempAlloc);
    inside.reserve(32);
    temp.reserve(32);
    footPrint.reserve(32);

    // Find polygons that potentially intersect with the cave hull.
    // We'll use detail mesh for this to capture all cases.
    // As we go we keep track of the polygons that were touched
    // as well as the vertices of the detail mesh intersection.
    // These intersection points will later be used to create a new infinite
    // carver which is actually used for carving.

    static const unsigned char kTouched = 1;
    static const unsigned char kVisited = 2;

    dynamic_array<unsigned char> visited(kMemTempAlloc);
    visited.resize_initialized(polyCount, 0);

    // TODO: we should be able to use BV-tree for this.
    size_t nTouched = 0;
    for (int ip = 0; ip < polyCount; ++ip)
    {
        MinMaxAABB polyBounds;
        CalcPolyDetailBounds(polyBounds, detailMesh, ip);
        if (!IntersectAABBAABB(bounds, polyBounds))
            continue;
        visited[ip] = kTouched;
        nTouched++;
    }

    dynamic_array<int> stack(kMemTempAlloc);
    detailHulls.reserve(nTouched);

    // Merge connecting regions.
    for (int ip = 0; ip < polyCount; ++ip)
    {
        if (visited[ip] != kTouched)
            continue;

        DynamicMesh::DetailHull detailHull;

        stack.resize_uninitialized(0);
        stack.push_back(ip);

        while (!stack.empty())
        {
            const int cur = stack.back();
            stack.pop_back();
            detailHull.polysIds.push_back(cur);
            const NavMeshPoly* poly = &tile->polys[cur];
            for (int j = 0; j < poly->vertCount; j++)
            {
                // Skip if no neighbour or if at tile border.
                if (poly->neis[j] == 0 || poly->neis[j] & 0x8000)
                    continue;
                int nei = (int)poly->neis[j] - 1;
                if (visited[nei] == kTouched)
                {
                    visited[nei] = kVisited;
                    stack.push_back(nei);
                }
            }
        }
        detailHulls.push_back(detailHull);
    }

    if (detailHulls.empty())
        return false;

    Vertex2Array convexHull(kMemTempAlloc);
    convexHull.reserve(32);

    const int detailHullCount = detailHulls.size();
    for (int hi = 0; hi < detailHullCount; hi++)
    {
        DynamicMesh::DetailHull& detailHull = detailHulls[hi];
        footPrint.resize_uninitialized(0);

        for (int i = 0; i < detailHull.polysIds.size(); i++)
        {
            const int ip = detailHull.polysIds[i];
            const DetailMeshPoly& dpoly = detailMesh.polys[ip];

            ClipCallback callback(hull, inside, temp, footPrint);
            QueryDetailBVTree(detailMesh, dpoly, bounds.m_Min, bounds.m_Max, &callback);

            if (!callback.m_Hit)
            {
                detailHull.polysIds[i] = detailHull.polysIds.back();
                detailHull.polysIds.pop_back();
                i--;
            }
        }

        // TODO: Optimization, if all the potentially intersecting polygons are flat, we could
        // just use the original hull.

        // Build carve hull from a convex hull of footprint.
        if (footPrint.empty())
        {
            detailHull.polysIds.resize_initialized(0);
            continue;
        }

        CalculateConvexHull(convexHull, footPrint);

        // Avoid simplifying the hull if it touches the tile boundary.
        Vector2f tileOffset2 = Vector2f(tileOffset.x, tileOffset.z);
        Vector2f bmin = Vector2f(tile->header->bmin.x, tile->header->bmin.z) - tileOffset2;
        Vector2f bmax = Vector2f(tile->header->bmax.x, tile->header->bmax.z) - tileOffset2;

        if (!HasBoundaryVertices(convexHull, bmin, bmax))
            SimplifyPolyline(convexHull, quantSize);

        if (convexHull.size() < 3)
        {
            detailHull.polysIds.resize_initialized(0);
            continue;
        }

        // Create hull planes from the polygon
        detailHull.hull.reserve(convexHull.size());
        detailHull.hull.resize_uninitialized(0);
        const int convexHullCount = convexHull.size();
        for (int i = 0; i < convexHullCount; i++)
        {
            Vector2f position2 = convexHull[i];
            Vector2f dir2 = convexHull[NextIndex(i, convexHullCount)] - position2;
            float len = Magnitude(dir2);
            if (len <= Vector2f::epsilon)
                continue;

            dir2 = dir2 / len;
            Vector3f position(position2.x, 0, position2.y);
            Vector3f normal(-dir2.y, 0, dir2.x);
            detailHull.hull.emplace_back_uninitialized().SetNormalAndPosition(normal, position);
        }
    }

    return true;
}

static void HullFromPoly(dynamic_array<Plane>& hull, const dynamic_array<Vector3f>& poly)
{
    const int vertCount = poly.size();
    hull.resize_uninitialized(vertCount);
    for (int i = 0; i < vertCount; i++)
    {
        Vector3f position = poly[i];
        Vector3f dir = poly[NextIndex(i, vertCount)] - position;
        Vector3f normal(-dir.z, 0, dir.x);
        normal = NormalizeSafe(normal);
        hull[i].SetNormalAndPosition(normal, position);
    }
}

static void ClipDetailMeshes(dynamic_array<ClippedDetailMesh*>& clipped,
    const DynamicMesh& mesh, const DetailMesh& detailMesh,
    const NavMeshTile* tile,
    const Vector3f& tileOffset,
    const float quantFactor)
{
    PROFILER_AUTO(gNavMeshClipDetailMesh, NULL)

    struct ClipCallback : public QueryDetailBVTreeCallback
    {
        ClippedDetailMesh& dmesh;
        dynamic_array<Plane>& hull;
        DetailVertexWelder& welder;
        dynamic_array<Vector3f>& inside;
        dynamic_array<Vector3f>& temp;

        ClipCallback(ClippedDetailMesh& dmeshIn, dynamic_array<Plane>& hullIn, DetailVertexWelder& welderIn,
                     dynamic_array<Vector3f>& insideIn, dynamic_array<Vector3f>& tempIn) :
            dmesh(dmeshIn),
            hull(hullIn),
            welder(welderIn),
            inside(insideIn),
            temp(tempIn)
        {
        }

        virtual void process(const DetailMesh& detailMesh, const DetailMeshPoly& poly, const int* tris, int triCount)
        {
            for (int i = 0; i < triCount; i++)
            {
                const unsigned short* t = &detailMesh.triangles[tris[i] * 4];
                inside.resize_uninitialized(3);
                inside[0] = detailMesh.vertices[poly.vertBase + t[0]];
                inside[1] = detailMesh.vertices[poly.vertBase + t[1]];
                inside[2] = detailMesh.vertices[poly.vertBase + t[2]];

                HullPolygonIntersection(inside, hull, temp);

                const int vertexCount = inside.size();
                if (vertexCount < 3) continue;

                int v0 = welder.AddUnique(inside[0]);
                int v1 = welder.AddUnique(inside[1]);
                for (int i = 2; i < vertexCount; i++)
                {
                    int v2 = welder.AddUnique(inside[i]);

                    float triArea2 = TriArea2D(inside[0], inside[i - 1], inside[i]);
                    if (triArea2 < MAGIC_EDGE_DISTANCE * MAGIC_EDGE_DISTANCE)
                    {
                        v1 = v2;
                        continue;
                    }

                    if (v0 != v1 && v1 != v2 && v2 != v0)
                    {
                        dmesh.triangles.push_back((unsigned short)v0);
                        dmesh.triangles.push_back((unsigned short)v1);
                        dmesh.triangles.push_back((unsigned short)v2);
                    }
                    v1 = v2;
                }
            }
        }
    };


    const Vector3f queryPadding(quantFactor * 2.0f, 0, quantFactor * 2.0f);

    const int polyCount = mesh.PolyCount();

    dynamic_array<Plane> hull(kMemTempAlloc);
    dynamic_array<Vector3f> verts(kMemTempAlloc);
    dynamic_array<Vector3f> inside(kMemTempAlloc);
    dynamic_array<Vector3f> temp(kMemTempAlloc);
    hull.reserve(8);
    verts.reserve(8);
    inside.reserve(32);
    temp.reserve(32);
    DetailVertexWelder welder(kMemTempAlloc, NULL, quantFactor);

    for (int i = 0; i < polyCount; i++)
    {
        const DynamicMesh::Poly* p = mesh.GetPoly(i);
        // Process only new polygons
        if (p->m_Status == DynamicMesh::kOriginalPolygon)
            continue;
        const int ip = *mesh.GetData(i);
        const DetailMeshPoly& dpoly = detailMesh.polys[ip];

        // If the detail mesh does not have any extra vertices,
        // no need to clip, just retriangulate later.
        if (dpoly.vertCount == p->m_VertexCount)
            continue;

        // Build clip hull from the polygons
        verts.resize_uninitialized(p->m_VertexCount);
        for (int j = 0; j < p->m_VertexCount; j++)
            verts[j] = mesh.GetVertex(p->m_VertexIDs[j]);
        HullFromPoly(hull, verts);

        // Build query box from the polygon.
        Vector3f queryMin, queryMax;
        queryMin = queryMax = verts[0];
        const int vertsCount = verts.size();
        for (int j = 0; j < vertsCount; j++)
        {
            queryMin = min(queryMin, verts[j]);
            queryMax = max(queryMax, verts[j]);
        }
        queryMin -= queryPadding;
        queryMax += queryPadding;

        clipped[i] = UNITY_NEW(ClippedDetailMesh, kMemTempAlloc)(kMemTempAlloc);
        ClippedDetailMesh* dmesh = clipped[i];
        dmesh->polyIndex = i;

        welder.SetVertexArray(&dmesh->vertices);
        welder.Reset();

        // Clip all detail triangles against the polygon.
        ClipCallback callback(*dmesh, hull, welder, inside, temp);
        QueryDetailBVTree(detailMesh, dpoly, queryMin, queryMax, &callback);

        // Offset dmesh back to tile location.
        const int vertCount = dmesh->vertices.size();
        for (int j = 0; j < vertCount; j++)
            dmesh->vertices[j] += tileOffset;

        if (dmesh->vertices.size() < 3 || dmesh->triangles.size() < 3)
            UNITY_DELETE(clipped[i], kMemTempAlloc);
    }
}

static inline bool AreColinear(const Vector3f& v, const Vector3f& u, const float cosAngleAccept)
{
    DebugAssert(IsNormalized(v));
    DebugAssert(IsNormalized(u));
    return Abs(Dot(v, u)) > cosAngleAccept;
}

static float DistancePointSegmentSqr(const Vector2f& pt, const Vector2f& s1, const Vector2f& s2)
{
    Vector2f ds = s2 - s1;
    Vector2f dp = pt - s1;
    float den = Dot(ds, ds);
    if (den == 0)
        return Dot(dp, dp);
    float t = Dot(ds, dp) / den;
    t = clamp01(t);
    Vector2f diff = t * ds - dp;
    return Dot(diff, diff);
}

static void SimplifyPolyline(Vertex2Array& hull, float thr)
{
    size_t i = 0;
    size_t count = hull.size();
    while (i < count && count > 2)
    {
        Vector2f pa = hull[PrevIndex(i, count)];
        Vector2f pb = hull[i];
        Vector2f pc = hull[NextIndex(i, count)];
        if (DistancePointSegmentSqr(pb, pa, pc) < thr * thr)
        {
            hull.erase(hull.begin() + i);
            count--;
        }
        else
        {
            i++;
        }
    }
}

static void OffsetPolygon(Vertex2Array& dest, const Vertex2Array& poly, const float offset)
{
    const int count = poly.size();
    dest.resize_uninitialized(0);
    dest.reserve(count);
    for (int i = 0; i < count; i++)
    {
        const Vector2f curr = poly[i];
        const Vector2f prev = poly[PrevIndex(i, count)];
        const Vector2f next = poly[NextIndex(i, count)];
        const Vector2f diffa = NormalizeSafe(curr - prev);
        const Vector2f diffb = NormalizeSafe(next - curr);

        // Calculate offset vectors based on neighbor segment directions.
        // Scale the offsets to maintain constant line width.
        const Vector2f dla(-diffa.y, diffa.x);
        const Vector2f dlb(-diffb.y, diffb.x);

        // More than 90.1 degree turn, add 2 points.
        // Use slack so that about 90 degree corners won't get beveled (common case with box obstacle).
        const float dot = Dot(diffa, diffb);
        const float kCos90p1 = -0.00174542f;
        if (dot < kCos90p1)
        {
            // This is poorman's approximation of a bevel which is offset
            // so that it approximates a circle. Consider 2 cases below.
            //   B._____   A._____.B
            // A.´          |     |
            //  |  x----    |  x  |
            //  |  |        |  |  |
            // A correct version likely needs asin () & co, not used for speed reasons.
            const Vector2f pos = curr + diffa * (0.25f + Abs(dot) * 0.75f) * offset;
            dest.push_back(pos + dla * offset);
            dest.push_back(pos + dlb * offset);
        }
        else
        {
            Vector2f dm = (dla + dlb) * 0.5f;
            float dmr2 = Dot(dm, dm);
            if (dmr2 > 0.0f)
                dm *= 1.0f / dmr2;
            dest.push_back(curr + dm * offset);
        }
    }
}

static bool CalculateCarveHullFromPoints(DynamicMesh::Hull& carveHull, const NavMeshCarveShape& shape,
    const Vector3f& tileOffset, const float carveDepth, const float carveWidth,
    const Vector3f* points, int pointCount)
{
    // Calcualte convex hull of the obstacle on XZ plane
    carveHull.resize_uninitialized(0);
    Vertex2Array projectedPoints(kMemTempAlloc);
    Vertex2Array hull(kMemTempAlloc);
    Vertex2Array hullOffset(kMemTempAlloc);
    projectedPoints.resize_uninitialized(pointCount);
    hull.reserve(pointCount + 1);
    hullOffset.reserve(pointCount + 1);

    for (int i = 0; i < pointCount; i++)
        projectedPoints[i] = Vector2f(points[i].x, points[i].z);

    CalculateConvexHull(hull, projectedPoints);
    SimplifyPolyline(hull, carveWidth * 0.1f);
    OffsetPolygon(hullOffset, hull, carveWidth);

    // Bail out if hull has been degerated.
    // It is possible that SimplifyPolyline will simplify the obstacle down to a line,
    // OffsetPolygon can take care of that. This is should only happen when the obstacle
    // degenerates to a point.
    if (hullOffset.size() < 3)
        return false;

    int hullCount = hullOffset.size();
    for (int i = 0; i < hullCount; i++)
    {
        Vector2f pt = hullOffset[i];
        Vector2f dir = hullOffset[NextIndex(i, hullCount)] - pt;
        Vector3f position(pt.x, 0, pt.y);
        Vector3f normal(-dir.y, 0, dir.x);
        normal = NormalizeSafe(normal);
        carveHull.emplace_back_uninitialized().SetNormalAndPosition(normal, position);
    }

    // Calculate approximate up axis.
    // The approx normal is chosen so that it is visually plausible, i.e. prefer larger extents.
    const Vector3f zero(0.0f, 0.0f, 0.0f);
    Vector3f yAxis = zero;
    yAxis += shape.xAxis * shape.xAxis.y * std::max(shape.extents.y, shape.extents.z);
    yAxis += shape.yAxis * shape.yAxis.y * std::max(shape.extents.z, shape.extents.x);
    yAxis += shape.zAxis * shape.zAxis.y * std::max(shape.extents.x, shape.extents.y);
    yAxis = NormalizeSafe(yAxis);

    const Vector3f worldYAxis(0.0f, 1.0f, 0.0f);
    if (CompareApproximately(yAxis, zero))
        yAxis = worldYAxis;

    float distMin = FLT_MAX, distMax = -FLT_MAX;
    for (int i = 0; i < pointCount; i++)
    {
        float dist = Dot(points[i], yAxis);
        distMin = std::min(distMin, dist);
        distMax = std::max(distMax, dist);
    }

    // Add top/bottom caps
    carveHull.emplace_back_uninitialized().SetNormalAndPosition(-yAxis, yAxis * (distMin - carveDepth));
    carveHull.emplace_back_uninitialized().SetNormalAndPosition(yAxis, yAxis * distMax);

    // The aabb top/bottom planes if needed
    const float cosAngleConsiderAxisAligned = Cos(Deg2Rad(10.0f));   // Consider colinear if within 10 degrees
    bool isAlmostAxisAlignedY = AreColinear(yAxis, worldYAxis, cosAngleConsiderAxisAligned);
    if (!isAlmostAxisAlignedY)
    {
        const Vector3f min = shape.bounds.m_Min - tileOffset;
        const Vector3f max = shape.bounds.m_Max - tileOffset;
        carveHull.emplace_back_uninitialized().SetNormalAndPosition(-worldYAxis, min - carveDepth * Vector3f::yAxis);
        carveHull.emplace_back_uninitialized().SetNormalAndPosition(worldYAxis, max);
    }
    return true;
}

// Compute the set of planes defining an extruded bounding box.
// Bounding box is represented by transform and size.
// Extrusion is based on 'carveWidth' horizontally and 'carveDepth' vertically down.
// Everyting is translated relative to 'tileOffset'.
static bool CalculateBoxHull(DynamicMesh::Hull& carveHull, const NavMeshCarveShape& shape, const Vector3f& tileOffset,
    const float carveDepth, const float carveWidth)
{
    // Calculate obstacle vertices.
    Vector3f box[8];
    for (int i = 0; i < 8; ++i)
    {
        box[i] = shape.center - tileOffset;
        box[i] += shape.xAxis * ((i & 1) ? shape.extents.x : -shape.extents.x);
        box[i] += shape.yAxis * ((i & 2) ? shape.extents.y : -shape.extents.y);
        box[i] += shape.zAxis * ((i & 4) ? shape.extents.z : -shape.extents.z);
    }

    return CalculateCarveHullFromPoints(carveHull, shape, tileOffset, carveDepth, carveWidth, box, 8);
}

static bool CalculateCapsuleHull(DynamicMesh::Hull& carveHull, const NavMeshCarveShape& shape, const Vector3f& tileOffset,
    const float carveDepth, const float carveWidth)
{
    // TODO: it should be possible to optimize the hull shape a bit more by
    // creating the capsule data in 2D, and add min/max points.
    // See how a 2D capsule is drawn in NavMeshVisulization.cpp

    float radius = 0, height = 0;
    FitCapsuleToExtents(&radius, &height, shape.extents);

    // Calculate obstacle vertices.
    static const int kDivs = 8;
    Vector3f cylinder[(kDivs + kDivs + 1) * 2];
    int n = 0;
    // Scale for "outer" polygon, the polygon is created so that the cylinder circle is inscribing the polygon.
    const float radiusScale = 1.0f / Cos(kPI * 2.0f / (float)kDivs * 0.5f);
    // We have 8 divs effectively in other direction too.
    const float h = 0.7071067812f * radius * radiusScale;
    const float r = radius * radiusScale;
    Vector3f center = shape.center - tileOffset;
    for (int i = 0; i < kDivs; ++i)
    {
        const float angle = (float)i / (float)kDivs * kPI * 2.0f;
        const float dx = Cos(angle);
        const float dz = Sin(angle);
        const Vector3f ax = shape.xAxis * dx;
        const Vector3f az = shape.zAxis * dz;
        cylinder[n++] = center + ax * r + az * r - shape.yAxis * height;
        cylinder[n++] = center + ax * r + az * r + shape.yAxis * height;
        cylinder[n++] = center + ax * h + az * h - shape.yAxis * (height + h);
        cylinder[n++] = center + ax * h + az * h + shape.yAxis * (height + h);
    }

    // Capsule tips
    cylinder[n++] = center - shape.yAxis * (height + r);
    cylinder[n++] = center + shape.yAxis * (height + r);

    return CalculateCarveHullFromPoints(carveHull, shape, tileOffset, carveDepth, carveWidth, cylinder, n);
}

// Set flags on polygon edges colinear to tile edges.
// Flagged edges are considered when dynamically stitching neighboring tiles.
static void WritePortalFlags(const Vector3f* verts, NavMeshPoly* polys, const int polyCount, const NavMeshDataHeader* sourceHeader)
{
    const Vector3f& bmax = sourceHeader->bmax;
    const Vector3f& bmin = sourceHeader->bmin;
    for (int ip = 0; ip < polyCount; ++ip)
    {
        NavMeshPoly& poly = polys[ip];
        for (int iv = 0; iv < poly.vertCount; ++iv)
        {
            // Skip already connected edges
            if (poly.neis[iv] != 0)
                continue;

            const Vector3f& vert = verts[poly.verts[iv]];
            const int ivn = (iv + 1 == poly.vertCount) ? 0 : iv + 1;
            const Vector3f& nextVert = verts[poly.verts[ivn]];

            //
            //       z+
            //    o---->o
            //    ^     |
            // x- |     | x+
            //    |     v
            //    o<----o
            //       z-

            const float dx = nextVert.x - vert.x;
            const float dz = nextVert.z - vert.z;

            unsigned short nei = 0;
            if (dz < 0.0f && std::max(Abs(vert.x - bmax.x), Abs(nextVert.x - bmax.x)) < MAGIC_EDGE_DISTANCE)
                nei = kNavMeshExtLink | 0; // x+ portal
            else if (dx > 0.0f && std::max(Abs(vert.z - bmax.z), Abs(nextVert.z - bmax.z)) < MAGIC_EDGE_DISTANCE)
                nei = kNavMeshExtLink | 2; // z+ portal
            else if (dz > 0.0f && std::max(Abs(vert.x - bmin.x), Abs(nextVert.x - bmin.x)) < MAGIC_EDGE_DISTANCE)
                nei = kNavMeshExtLink | 4; // x- portal
            else if (dx < 0.0f && std::max(Abs(vert.z - bmin.z), Abs(nextVert.z - bmin.z)) < MAGIC_EDGE_DISTANCE)
                nei = kNavMeshExtLink | 6; // z- portal

            poly.neis[iv] = nei;
        }
    }
}

static int SimplePolygonTriangulation(NavMeshPolyDetail* dtl, NavMeshPolyDetailIndex* dtris, int detailTriBase, const int polygonVertexCount)
{
    dtl->vertBase = 0;
    dtl->vertCount = 0;
    dtl->triBase = (unsigned int)detailTriBase;
    dtl->triCount = (NavMeshPolyDetailIndex)(polygonVertexCount - 2);

    // Triangulate polygon (local indices).
    for (int j = 2; j < polygonVertexCount; ++j)
    {
        NavMeshPolyDetailIndex* t = &dtris[4 * detailTriBase];
        t[0] = 0;
        t[1] = (NavMeshPolyDetailIndex)(j - 1);
        t[2] = (NavMeshPolyDetailIndex)j;
        // Bit for each edge that belongs to poly boundary.
        t[3] = (1 << 2);
        if (j == 2)
            t[3] |= (1 << 0);
        if (j == polygonVertexCount - 1)
            t[3] |= (1 << 4);
        detailTriBase++;
    }
    return detailTriBase;
}

static unsigned char GetEdgeFlags(const Vector3f& va, const dynamic_array<Vector3f>& poly)
{
    // Return mask indicating which edges the vertex touches.
    static const float thrSqr = Sqr(MAGIC_EDGE_DISTANCE);
    const int npoly = poly.size();
    unsigned char flags = 0;
    for (int i = 0, j = npoly - 1; i < npoly; j = i++)
    {
        float t;
        if (SqrDistancePointSegment2D(&t, va, poly[j], poly[i]) < thrSqr)
            flags |= (1 << j);
    }
    return flags;
}

static unsigned char GetTriFlags(const unsigned char va, const unsigned char vb, const unsigned char vc)
{
    unsigned char flags = 0;
    if ((va & vb) != 0)
        flags |= 1 << 0;
    if ((vb & vc) != 0)
        flags |= 1 << 2;
    if ((vc & va) != 0)
        flags |= 1 << 4;
    return flags;
}

// Converts detour navmesh tile to dynamic mesh format
static void TileToDynamicMesh(const NavMeshTile* tile, DynamicMesh& mesh, const Vector3f& tileOffset)
{
    PROFILER_AUTO(gNavMeshTileToDynamicMesh, NULL)
    Assert(tile != NULL);
    Assert(tile->header != NULL);

    const int vertCount = tile->header->vertCount;
    const int polyCount = tile->header->polyCount;
    mesh.Reserve(vertCount, polyCount);

    for (int iv = 0; iv < vertCount; ++iv)
    {
        mesh.AddVertex(tile->verts[iv] - tileOffset);
    }

    for (int ip = 0; ip < polyCount; ++ip)
    {
        const NavMeshPoly& srcPoly = tile->polys[ip];
        mesh.AddPolygon(srcPoly.verts, ip, srcPoly.vertCount);
    }
}

// Create tile in the format understood by the detour runtime.
// Polygons are converted from the dynamic mesh 'mesh'.
static unsigned char* DynamicMeshToTile(int* dataSize, const DynamicMesh& mesh, const dynamic_array<ClippedDetailMesh*>& clipped,
    const NavMeshTile* sourceTile, const Vector3f& tileOffset)
{
    PROFILER_AUTO(gNavMeshDynamicMeshToTile, NULL)

    // Determine data size
    DebugAssert(sourceTile);
    const int vertCount = mesh.VertCount();
    const int polyCount = mesh.PolyCount();
    const NavMeshDataHeader* sourceHeader = sourceTile->header;

    const int totVertCount = vertCount;
    const int totPolyCount = polyCount;

    int detailVertCount = 0;
    int detailTriCount = 0;
    RequirementsForDetailMeshMixed(&detailVertCount, &detailTriCount, mesh, sourceTile, clipped);

    const unsigned int headSize = Align4(sizeof(NavMeshDataHeader));
    const unsigned int vertSize = Align4(totVertCount * sizeof(Vector3f));
    const unsigned int polySize = Align4(totPolyCount * sizeof(NavMeshPoly));
    const unsigned int detailMeshesSize = Align4(polyCount * sizeof(NavMeshPolyDetail));
    const unsigned int detailVertsSize = Align4(detailVertCount * sizeof(Vector3f));
    const unsigned int detailTrisSize = Align4(detailTriCount * 4 * sizeof(NavMeshPolyDetailIndex));
    const unsigned int bvTreeSize = 0;

    const int newSize = headSize + vertSize + polySize +
        detailTrisSize + detailVertsSize + detailMeshesSize + bvTreeSize;

    unsigned char* newTile = (unsigned char*)UNITY_MALLOC(kMemAI, newSize);
    if (newTile == NULL)
    {
        *dataSize = 0;
        return NULL;
    }
    *dataSize = newSize;
    memset(newTile, 0, newSize);

    // Serialize in the detour recognized format
    int offset = 0;
    NavMeshDataHeader* header = (NavMeshDataHeader*)(newTile + offset); offset += headSize;
    Vector3f* verts = (Vector3f*)(newTile + offset); offset += vertSize;
    NavMeshPoly* polys = (NavMeshPoly*)(newTile + offset); offset += polySize;
    NavMeshPolyDetail* detail = (NavMeshPolyDetail*)(newTile + offset); offset += detailMeshesSize;
    Vector3f* dverts = (Vector3f*)(newTile + offset); offset += detailVertsSize;
    NavMeshPolyDetailIndex* dtris = (NavMeshPolyDetailIndex*)(newTile + offset); offset += detailTrisSize;
    /*NavMeshBVNode* bvtree = (NavMeshBVNode*)(newTile+offset);*/ offset += bvTreeSize;
    DebugAssert(offset == newSize);

    for (int iv = 0; iv < vertCount; ++iv)
    {
        // TODO: apply tile offset earlier, after carving. Now needs to be handled all over the place.
        verts[iv] = mesh.GetVertex(iv) + tileOffset;
    }

    for (int ip = 0; ip < polyCount; ++ip)
    {
        const DynamicMesh::Poly* p = mesh.GetPoly(ip);
        const int sourcePolyIndex = *mesh.GetData(ip);
        const NavMeshPoly& srcPoly = sourceTile->polys[sourcePolyIndex];

        NavMeshPoly& poly = polys[ip];
        memcpy(poly.verts, p->m_VertexIDs, kNavMeshVertsPerPoly * sizeof(UInt16));
        memcpy(poly.neis, p->m_Neighbours, kNavMeshVertsPerPoly * sizeof(UInt16));
        unsigned char area = srcPoly.area;
        poly.flags = 1 << area;
        poly.area = area;
        poly.vertCount = p->m_VertexCount;
    }

    // Set external portal flags
    WritePortalFlags(verts, polys, polyCount, sourceHeader);

    WriteDetailMeshMixed(detail, dverts, dtris, mesh, sourceTile, tileOffset, clipped,
        detailTriCount, detailVertCount);

    // Copy values from source
    memcpy(header, sourceHeader, sizeof(*header));

    // (re)set new tile values
    header->polyCount = totPolyCount;
    header->vertCount = totVertCount;
    header->detailMeshCount = polyCount;
    header->detailVertCount = detailVertCount;
    header->detailTriCount = detailTriCount;
    header->bvNodeCount = 0;                   // Fixme: bv-tree

    return newTile;
}

// Find vertex and triangle count needed for regular detailmesh
static void RequirementsForDetailMeshMixed(int* detailVertCount, int* detailTriCount,
    const DynamicMesh& mesh, const NavMeshTile* sourceTile, const dynamic_array<ClippedDetailMesh*>& clipped)
{
    int vertCount = 0;
    int triCount = 0;

    // Collect sizes needed for detail mesh
    const int polyCount = mesh.PolyCount();
    for (int ip = 0; ip < polyCount; ++ip)
    {
        const DynamicMesh::Poly* p = mesh.GetPoly(ip);
        const int sourcePolyIndex = *mesh.GetData(ip);

        if (p->m_Status == DynamicMesh::kOriginalPolygon)
        {
            // When preserving polygon detail mesh just add the source counts
            const NavMeshPolyDetail& sourceDetail = sourceTile->detailMeshes[sourcePolyIndex];
            vertCount += sourceDetail.vertCount;
            triCount += sourceDetail.triCount;
        }
        else
        {
            if (clipped[ip] != NULL)
            {
                vertCount += clipped[ip]->vertices.size();
                triCount += clipped[ip]->triangles.size() / 3;
            }
            else
            {
                // Simple triangulation needs n-2 triangles but no extra detail vertices
                triCount += p->m_VertexCount - 2;
            }
        }
    }
    *detailVertCount = vertCount;
    *detailTriCount = triCount;
}

// Mix preserved detail mesh for untouched polygons with simple triangulation for generated polygons
static void WriteDetailMeshMixed(NavMeshPolyDetail* detail, Vector3f* dverts, NavMeshPolyDetailIndex* dtris
    , const DynamicMesh& mesh, const NavMeshTile* sourceTile, const Vector3f& tileOffset, const dynamic_array<ClippedDetailMesh*>& clipped
    , const int detailTriCount, const int detailVertCount)
{
    PROFILER_AUTO(gNavMeshWriteDetailMesh, NULL)

    int detailVertBase = 0;
    int detailTriBase = 0;

    dynamic_array<unsigned char> edgeFlags(kMemTempAlloc);
    dynamic_array<Vector3f> poly(kMemTempAlloc);
    poly.reserve(kNavMeshVertsPerPoly);

    const int polyCount = mesh.PolyCount();
    for (int ip = 0; ip < polyCount; ++ip)
    {
        NavMeshPolyDetail& dtl = detail[ip];
        const DynamicMesh::Poly* p = mesh.GetPoly(ip);

        if (p->m_Status == DynamicMesh::kOriginalPolygon)
        {
            // Fill in the original detail mesh for this polygon
            const int sourcePolyIndex = *mesh.GetData(ip);
            const NavMeshPolyDetail& sourceDetail = sourceTile->detailMeshes[sourcePolyIndex];
            dtl.vertBase = detailVertBase;
            dtl.vertCount = sourceDetail.vertCount;
            dtl.triBase = detailTriBase;
            dtl.triCount = sourceDetail.triCount;

            // copy source detail vertices and triangles
            memcpy(&dverts[detailVertBase], &sourceTile->detailVerts[sourceDetail.vertBase], sizeof(Vector3f) * sourceDetail.vertCount);
            memcpy(&dtris[4 * detailTriBase], &sourceTile->detailTris[4 * sourceDetail.triBase], 4 * sizeof(NavMeshPolyDetailIndex) * sourceDetail.triCount);

            detailVertBase += sourceDetail.vertCount;
            detailTriBase += sourceDetail.triCount;
        }
        else
        {
            if (clipped[ip] != NULL)
            {
                poly.resize_initialized(p->m_VertexCount);
                for (int j = 0; j < p->m_VertexCount; j++)
                    poly[j] = tileOffset + mesh.GetVertex(p->m_VertexIDs[j]);

                // TODO: check vertex count so that detail vertex index won't overflow.
                // TODO: locate and remap polygon vertices to reduce space (now stores poly vertes too).
                ClippedDetailMesh* clip = clipped[ip];
                const int vertCount = clip->vertices.size();
                const int triCount = clip->triangles.size() / 3;

                dtl.vertBase = detailVertBase;
                dtl.vertCount = vertCount;
                dtl.triBase = detailTriBase;
                dtl.triCount = triCount;

                // Copy vertices
                for (int j = 0; j < vertCount; j++)
                    dverts[detailVertBase + j] = clip->vertices[j];

                // Calculate edge flags.
                edgeFlags.resize_uninitialized(vertCount);
                for (int j = 0; j < vertCount; j++)
                    edgeFlags[j] = GetEdgeFlags(clip->vertices[j], poly);

                // Copy triangles.
                for (int j = 0; j < triCount; j++)
                {
                    NavMeshPolyDetailIndex* t = &dtris[4 * (detailTriBase + j)];
                    t[0] = p->m_VertexCount + (NavMeshPolyDetailIndex)clip->triangles[j * 3 + 0];
                    t[1] = p->m_VertexCount + (NavMeshPolyDetailIndex)clip->triangles[j * 3 + 1];
                    t[2] = p->m_VertexCount + (NavMeshPolyDetailIndex)clip->triangles[j * 3 + 2];
                    t[3] = GetTriFlags(edgeFlags[clip->triangles[j * 3 + 0]],
                            edgeFlags[clip->triangles[j * 3 + 1]],
                            edgeFlags[clip->triangles[j * 3 + 2]]);
                }

                detailVertBase += vertCount;
                detailTriBase += triCount;
            }
            else
            {
                detailTriBase = SimplePolygonTriangulation(&dtl, dtris, detailTriBase, p->m_VertexCount);
            }
        }
    }
    DebugAssert(detailTriBase == detailTriCount);
    DebugAssert(detailVertBase == detailVertCount);
}

// Creates debug wire frame mesh of carve hull.
void CalculateHullWireMesh(dynamic_array<Vector3f>& lines, const NavMeshCarveShape& shape,
    const float carveDepth, const float carveWidth)
{
#if UNITY_EDITOR
    DynamicMesh::Hull hull;
    hull.reserve(32);
    bool validHull = false;
    const Vector3f zero(0.0f, 0.0f, 0.0f);
    if (shape.shape == kObstacleShapeCapsule)
    {
        validHull = CalculateCapsuleHull(hull, shape, zero, carveDepth, carveWidth);
    }
    else if (shape.shape == kObstacleShapeBox)
    {
        validHull = CalculateBoxHull(hull, shape, zero, carveDepth, carveWidth);
    }

    if (!validHull)
        return;

    // The quad size is used to create a big quad which will be clipped by the hull planes,
    // use bounding box as a starting point.
    const float quadSize = Magnitude(shape.bounds.m_Max - shape.bounds.m_Min) * 4.0f;

    DynamicMesh::Polygon inside(kMemTempAlloc);
    DynamicMesh::Polygon temp(kMemTempAlloc);
    inside.reserve(32);
    temp.reserve(32);

    const Vector3f worldXAxis(1.0f, 0.0f, 0.0f);
    const Vector3f worldZAxis(0.0f, 0.0f, 1.0f);

    // Build polygon outlines from hull planes.
    int planeCount = hull.size();
    for (int i = 0; i < planeCount; i++)
    {
        Plane plane = hull[i];
        Vector3f planeCenter = shape.center - plane.normal * plane.GetDistanceToPoint(shape.center);
        Vector3f xAxis, yAxis, zAxis;
        yAxis = plane.normal;
        if (Abs(yAxis.z) < Abs(yAxis.y))
        {
            zAxis = NormalizeSafe(Cross(worldXAxis, yAxis), worldZAxis);
            xAxis = NormalizeSafe(Cross(yAxis, zAxis), worldXAxis);
        }
        else
        {
            xAxis = NormalizeSafe(Cross(yAxis, worldZAxis), worldXAxis);
            zAxis = NormalizeSafe(Cross(xAxis, yAxis), worldZAxis);
        }

        // Create big quad and clip it with all other hull planes to get the hull side for current polygon.
        inside.resize_uninitialized(0);
        inside.push_back(planeCenter - xAxis * quadSize - zAxis * quadSize);
        inside.push_back(planeCenter + xAxis * quadSize - zAxis * quadSize);
        inside.push_back(planeCenter + xAxis * quadSize + zAxis * quadSize);
        inside.push_back(planeCenter - xAxis * quadSize + zAxis * quadSize);

        for (int j = 0; j < planeCount; j++)
        {
            if (i == j)
                continue;           // Skip self
            int result = SplitPolyByPlane(temp, inside, hull[j]);
            if (result == 0)
            {
                inside = temp;
            }
            else if (result == 1)
            {
                inside.resize_uninitialized(0);
                break;
            }
        }

        int insideCount = inside.size();
        for (int j = 0; j < insideCount; j++)
        {
            lines.push_back(inside[j]);
            lines.push_back(inside[NextIndex(j, insideCount)]);
        }
    }
#endif
}
