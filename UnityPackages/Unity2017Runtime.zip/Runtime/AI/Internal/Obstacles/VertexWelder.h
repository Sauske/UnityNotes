#pragma once

#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Logging/LogAssert.h"
#include "Runtime/Math/Vector3.h"

// Note BucketCount must be pow2!
template<int BucketCount>
class VertexWelder
{
    static inline int hash(int x, int y, int z)
    {
        const unsigned int h1 = 0x8da6b343; // Large multiplicative constants;
        const unsigned int h2 = 0xd8163841; // here arbitrarily chosen primes
        const unsigned int h3 = 0xcb1ab31f;
        unsigned int n = h1 * x + h2 * y + h3 * z;
        return (int)(n & (BucketCount - 1));
    }

    const float m_weldThr;
    dynamic_array<Vector3f>* m_verts;
    dynamic_array<int> m_next;
    int m_first[BucketCount];

    inline float GetCellSize() const
    {
        return m_weldThr * 10.0f;
    }

    VertexWelder() {}
public:
    VertexWelder(MemLabelId label, dynamic_array<Vector3f>* verts, const float weldThr)
        : m_weldThr(weldThr), m_verts(verts), m_next(label)
    {
        Assert(weldThr > 0.0f);
        if (verts != NULL)
            Assert(verts->empty());
        for (int i = 0; i < BucketCount; i++)
            m_first[i] = -1;
    }

    void SetVertexArray(dynamic_array<Vector3f>* verts)
    {
        Assert(verts != NULL);
        Assert(verts->empty());
        m_verts = verts;
    }

    void Reset()
    {
        if (m_verts != NULL)
            Assert(m_verts->empty());
        for (int i = 0; i < BucketCount; i++)
            m_first[i] = -1;
        m_next.resize_initialized(0);
    }

    int Push(const Vector3f& pt)
    {
        const float cellSize = GetCellSize();
        dynamic_array<Vector3f>& verts = *m_verts;
        // Add vertex
        const int x = FloorfToInt(pt.x / cellSize);
        const int y = FloorfToInt(pt.y / cellSize);
        const int z = FloorfToInt(pt.z / cellSize);
        const int h = hash(x, y, z);
        verts.push_back(pt);
        m_next.push_back(-1);
        // The external array must be kept in sync with m_next.
        // Only this method should add stuff to verts when using the welder.
        Assert(verts.size() == m_next.size());
        int idx = verts.size() - 1;
        m_next[idx] = m_first[h];
        m_first[h] = idx;

        return idx;
    }

    int AddUnique(const Vector3f& pt)
    {
        dynamic_array<Vector3f>& verts = *m_verts;

        // Try to find vertex
        const float weldThr = m_weldThr;
        const float cellSize = GetCellSize();
        int minx = FloorfToInt((pt.x - weldThr) / cellSize);
        int maxx = FloorfToInt((pt.x + weldThr) / cellSize);
        int miny = FloorfToInt((pt.y - weldThr) / cellSize);
        int maxy = FloorfToInt((pt.y + weldThr) / cellSize);
        int minz = FloorfToInt((pt.z - weldThr) / cellSize);
        int maxz = FloorfToInt((pt.z + weldThr) / cellSize);
        int bestIndex = -1;
        float bestDistSq = weldThr * weldThr;
        for (int z = minz; z <= maxz; z++)
        {
            for (int y = miny; y <= maxy; y++)
            {
                for (int x = minx; x <= maxx; x++)
                {
                    int h = hash(x, y, z);
                    for (int i = m_first[h]; i != -1; i = m_next[i])
                    {
                        float distSq = SqrMagnitude(verts[i] - pt);
                        if (distSq < bestDistSq)
                        {
                            bestDistSq = distSq;
                            bestIndex = i;
                        }
                    }
                }
            }
        }

        if (bestIndex != -1)
            return bestIndex;

        return Push(pt);
    }
};
