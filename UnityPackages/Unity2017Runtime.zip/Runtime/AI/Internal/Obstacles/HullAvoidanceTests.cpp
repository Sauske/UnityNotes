#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS
#include "Runtime/Testing/Testing.h"
#include "./HullAvoidance.h"
#include "Runtime/Math/Quaternion.h"

UNIT_TEST_SUITE(HullAvoidanceTests)
{
    struct HullAvoidanceTestFixture
    {
        HullAvoidanceTestFixture()
        {
            m_AxisAlignedUnitBox.push_back(Vector3f(-1, -1, -1));
            m_AxisAlignedUnitBox.push_back(Vector3f(-1, -1, 1));
            m_AxisAlignedUnitBox.push_back(Vector3f(-1, 1, -1));
            m_AxisAlignedUnitBox.push_back(Vector3f(-1, 1, 1));
            m_AxisAlignedUnitBox.push_back(Vector3f(1, -1, -1));
            m_AxisAlignedUnitBox.push_back(Vector3f(1, -1, 1));
            m_AxisAlignedUnitBox.push_back(Vector3f(1, 1, -1));
            m_AxisAlignedUnitBox.push_back(Vector3f(1, 1, 1));

            // Rotate aligned box to 'stand on tip'
            const Quaternionf rotation(-0.325f, 0.0f, 0.325f, 0.888f);
            for (int i = 0; i < 8; ++i)
            {
                m_RotatedUnitBox.push_back(RotateVectorByQuat(rotation, m_AxisAlignedUnitBox[i]));
            }
        }

        dynamic_array<Vector3f> m_AxisAlignedUnitBox;
        dynamic_array<Vector3f> m_RotatedUnitBox;
    };

    struct Hull2DTestFixture
    {
        Hull2DTestFixture()
        {
            FLOAT_EPSILON = 1e-4f;

            m_Triangle.push_back(Vector2f(1, 0));
            m_Triangle.push_back(Vector2f(1, 1));
            m_Triangle.push_back(Vector2f(2, 0));

            m_Square.push_back(Vector2f(-0.5f, -0.5f));
            m_Square.push_back(Vector2f(-0.5f, -1.5f));
            m_Square.push_back(Vector2f(-1.5f, -1.5f));
            m_Square.push_back(Vector2f(-1.5f, -0.5f));
        }

        float FLOAT_EPSILON;
        Vertex2Array m_Triangle;
        Vertex2Array m_Square;
    };

    TEST_FIXTURE(HullAvoidanceTestFixture, CalculateCylinderCollisionHull_Empty)
    {
        const float cylinderMinY = 2.0f;
        const float cylinderMaxY = 3.0f;

        Vector3f result[12];
        int vertexCount = CalculateClippedBoxConvexHull(result, m_RotatedUnitBox.data(),
                cylinderMinY, cylinderMaxY);
        CHECK_EQUAL(0, vertexCount);
    }

    TEST_FIXTURE(HullAvoidanceTestFixture, CalculateCylinderCollisionHull_Triangle)
    {
        const float cylinderMinY = sqrtf(3.0f) - 0.5f;
        const float cylinderMaxY = cylinderMinY + 1.0f;

        Vector3f result[12];
        int vertexCount = CalculateClippedBoxConvexHull(result, m_RotatedUnitBox.data(),
                cylinderMinY, cylinderMaxY);
        CHECK_EQUAL(3, vertexCount);
    }

    TEST_FIXTURE(HullAvoidanceTestFixture, CalculateCylinderCollisionHull_Hexagon)
    {
        const float cylinderMinY = 0.3f;
        const float cylinderMaxY = cylinderMinY + 1.0f;

        Vector3f result[12];
        int vertexCount = CalculateClippedBoxConvexHull(result, m_RotatedUnitBox.data(),
                cylinderMinY, cylinderMaxY);
        CHECK_EQUAL(9, vertexCount);
    }

    TEST_FIXTURE(HullAvoidanceTestFixture, CalculateCylinderCollisionHull_Dodecagon)
    {
        const float cylinderMinY = -0.3f;
        const float cylinderMaxY = 0.3f;

        Vector3f result[12];
        int vertexCount = CalculateClippedBoxConvexHull(result, m_RotatedUnitBox.data(),
                cylinderMinY, cylinderMaxY);
        CHECK_EQUAL(12, vertexCount);
    }

    TEST_FIXTURE(HullAvoidanceTestFixture, AlignedCylinderOverlapsOrientedBox_NoOverlapAbove)
    {
        const float radius = 0.5f;
        const float cylinderMinY = 3.0f;
        const Vector3f cylinderPosition = Vector3f::zero;

        float penetration = 0.0f;
        bool overlap = AlignedCylinderOverlapsOrientedBox(&penetration, m_RotatedUnitBox.data(),
                cylinderPosition, radius, cylinderMinY, cylinderMinY + 1.0f);
        CHECK(!overlap);
        CHECK_CLOSE(0.0f, penetration, 1e-3f);
    }

    TEST_FIXTURE(HullAvoidanceTestFixture, AlignedCylinderOverlapsOrientedBox_NoOverlap)
    {
        const float radius = 0.5f;
        const float cylinderMinY = 1.2f;
        const Vector3f cylinderPosition = Vector3f(1.0f, 0.0f, 1.0f);

        float penetration = 0.0f;
        bool overlap = AlignedCylinderOverlapsOrientedBox(&penetration, m_RotatedUnitBox.data(),
                cylinderPosition, radius, cylinderMinY, cylinderMinY + 1.0f);
        CHECK(!overlap);
        CHECK_CLOSE(0.0f, penetration, 1e-3f);
    }

    TEST_FIXTURE(HullAvoidanceTestFixture, AlignedCylinderOverlapsOrientedBox_Overlap)
    {
        const float radius = 0.2f;
        const float cylinderMinY = sqrtf(3.0f) - 0.5f;
        const Vector3f cylinderPosition = Vector3f(0.5f, 0.0f, 0.5f);

        float penetration = 0.0f;
        bool overlap = AlignedCylinderOverlapsOrientedBox(&penetration, m_RotatedUnitBox.data(),
                cylinderPosition, radius, cylinderMinY, cylinderMinY + 1.0f);
        CHECK(overlap);
        CHECK_CLOSE(radius, penetration, 1e-3f);
    }

    TEST_FIXTURE(HullAvoidanceTestFixture, CalculatePointsFromClippedBox_AxisAlignedBoxInsideSlab)
    {
        Vertex2Array points;
        CalculatePointsFromClippedBox(points, m_AxisAlignedUnitBox.data(), -1.1f, 1.1f);
        CHECK_EQUAL(8, points.size());
    }

    TEST_FIXTURE(HullAvoidanceTestFixture, CalculatePointsFromClippedBox_AxisAlignedBoxOutsideSlab)
    {
        Vertex2Array points;
        CalculatePointsFromClippedBox(points, m_AxisAlignedUnitBox.data(), 1.1f, 10.0f);
        CHECK_EQUAL(0, points.size());
    }

    TEST_FIXTURE(HullAvoidanceTestFixture, CalculatePointsFromClippedBox_AxisAlignedBoxCutBySlab)
    {
        Vertex2Array points;
        CalculatePointsFromClippedBox(points, m_AxisAlignedUnitBox.data(), -0.5f, 0.5f);
        CHECK_EQUAL(8, points.size());
    }

    TEST_FIXTURE(HullAvoidanceTestFixture, CalculatePointsFromClippedBox_RotatedBoxCutBySlab)
    {
        Vertex2Array points;
        CalculatePointsFromClippedBox(points, m_RotatedUnitBox.data(), -0.5f, 0.5f);
        CHECK_EQUAL(12, points.size());
    }

    TEST_FIXTURE(HullAvoidanceTestFixture, CalculateConvexHullFromPoints_EmptySet)
    {
        Vertex2Array points;
        Vertex2Array hull;

        CalculateConvexHull(hull, points);
        CHECK_EQUAL(0, hull.size());
    }

    TEST_FIXTURE(HullAvoidanceTestFixture, CalculateConvexHullFromPoints_Triangle)
    {
        Vertex2Array points;
        points.push_back(Vector2f(0, 0));
        points.push_back(Vector2f(0, 2));
        points.push_back(Vector2f(2, 0));
        points.push_back(Vector2f(0.5, 0.5));
        Vertex2Array hull;

        CalculateConvexHull(hull, points);
        CHECK_EQUAL(3, hull.size());
    }

    TEST_FIXTURE(Hull2DTestFixture, OverlapCircleHull_Disjoint)
    {
        float penetration = 0.0f;
        bool overlap = CircleHullOverlap(&penetration, m_Triangle, Vector2f(0, 1), 0.5f);
        CHECK(!overlap);
    }

    TEST_FIXTURE(Hull2DTestFixture, OverlapCircleHull_Inside)
    {
        float penetration = 0.0f;
        bool overlap = CircleHullOverlap(&penetration, m_Triangle, Vector2f(1.0f, 0.5f), 0.1f);
        CHECK(overlap);
    }

    TEST_FIXTURE(Hull2DTestFixture, OverlapCircleHull_OverlapCorner)
    {
        float penetration = 0.0f;
        bool overlap = CircleHullOverlap(&penetration, m_Triangle, Vector2f(1, 2), 0.9f);
        CHECK(!overlap);
    }

    TEST_FIXTURE(Hull2DTestFixture, OverlapCircleHull_NoOverlapCorner)
    {
        float penetration = 0.0f;
        bool overlap = CircleHullOverlap(&penetration, m_Triangle, Vector2f(1, 2), 1.1f);
        CHECK(overlap);
    }

    TEST_FIXTURE(Hull2DTestFixture, OverlapCircleHull_OverlapTriangleEdge)
    {
        float penetration = 0.0f;
        bool overlap = CircleHullOverlap(&penetration, m_Triangle, Vector2f(1.5f, 0.5f), 0.1f);
        CHECK(overlap);
    }

    TEST_FIXTURE(Hull2DTestFixture, OverlapCircleHull_OverlapSquareEdge)
    {
        float penetration = 0.0f;
        bool overlap = CircleHullOverlap(&penetration, m_Square, Vector2f(-1.7f, -1.0f), 0.5f);
        CHECK(overlap);
    }

    TEST_FIXTURE(Hull2DTestFixture, OverlapCircleHull_NoOverlapSquareEdge)
    {
        float penetration = 0.0f;
        bool overlap = CircleHullOverlap(&penetration, m_Square, Vector2f(-2.1f, -1.0f), 0.5f);
        CHECK(!overlap);
    }
}

#endif
