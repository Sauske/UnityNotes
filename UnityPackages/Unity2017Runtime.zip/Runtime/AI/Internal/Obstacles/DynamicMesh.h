#pragma once

#include "Runtime/Math/Vector3.h"
#include "Runtime/Geometry/Plane.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Logging/LogAssert.h"
#include "VertexWelder.h"
#include <vector>

// TODO handle T-junctions (produced by merging / culling degenerate polys).
// TODO optimize using bv-tree to collect source polygons for carving

class DynamicMesh
{
public:

    enum
    {
        kNumVerts = 6
    };
    enum PolyStatus
    {
        kOriginalPolygon = 0,
        kGeneratedPolygon = 1
    };
    struct Poly
    {
        UInt16 m_Neighbours[kNumVerts];
        UInt16 m_VertexIDs[kNumVerts];
        UInt8 m_VertexCount;
        UInt8 m_Status;
    };

    typedef int DataType;
    typedef dynamic_array<Plane> Hull;
    typedef UNITY_VECTOR (kMemTempAlloc, Hull) HullContainer;
    typedef dynamic_array<Vector3f> Polygon;
    typedef UNITY_VECTOR (kMemTempAlloc, Polygon) PolygonContainer;

    struct DetailHull
    {
        DetailHull() : hull(kMemTempAlloc) , polysIds(kMemTempAlloc) {}
        Hull hull;
        dynamic_array<int> polysIds;    // Polygon ids to carve
    };
    typedef UNITY_VECTOR (kMemTempAlloc, DetailHull) DetailHullContainer;

    explicit DynamicMesh(const float quantFactor);
    inline size_t PolyCount() const;
    inline size_t VertCount() const;
    inline Vector3f GetVertex(size_t i) const;
    inline const Poly* GetPoly(size_t i) const;
    inline const DataType* GetData(size_t i) const;

    void MergePolygons();
    void FindNeighbors();
    bool ClipPolys(const HullContainer& carveHulls);
    bool ClipPolys(const DetailHullContainer& carveHulls);

    void Reserve(const int vertexCount, const int polygonCount);
    void AddVertex(const Vector3f& v);
    inline void SetVertex(size_t i, const Vector3f& v);
    void AddPolygon(const UInt16* vertexIDs, const DataType& data, size_t vertexCount);
    void AddPolygon(const Polygon& vertices, const DataType& data);

private:
    struct Edge
    {
        UInt16 v1, v2, p1, p2, c1, c2;
    };
    typedef dynamic_array<Edge> EdgeList;

    void AddPolygon(const Polygon& vertices, const DataType& data, const UInt32 status);
    Poly CreatePolygon(const Polygon& vertices, const UInt32 status);
    void RemovePolygonUnordered(size_t i);
    void CollapsePolygonUnordered(size_t i);
    void CollapseEdge(int va, int vb);

    void Intersection(Polygon& inside, const Hull& carveHull, Polygon& temp, unsigned char* usedEdges) const;

    void FromPoly(Polygon& result, const Poly& poly) const;
    void BuildEdgeConnections(EdgeList& edges) const;
    void Subtract(PolygonContainer& result, const Polygon& outer, Polygon& inner, Polygon& tri, const unsigned char* usedEdges, const Hull& hull) const;
    void ConnectPolygons();
    void RemoveDegeneratePolygons();
    void RemoveDegenerateEdges();
    void RemoveUnusedVertices();
    void MergePolygons(PolygonContainer& polys) const;
    bool MergePolygons(Polygon& merged, const Polygon& p1, const Polygon& p2) const;

    dynamic_array<Poly> m_Polygons;
    dynamic_array<Vector3f> m_Vertices;
    dynamic_array<DataType> m_Data;

    typedef VertexWelder<2048> DynMeshVertexWelder;
    DynMeshVertexWelder m_Welder;

    const float m_QuantFactor;
};

inline size_t DynamicMesh::PolyCount() const
{
    return m_Polygons.size();
}

inline size_t DynamicMesh::VertCount() const
{
    return m_Vertices.size();
}

inline Vector3f DynamicMesh::GetVertex(size_t i) const
{
    return m_Vertices[i];
}

inline void DynamicMesh::SetVertex(size_t i, const Vector3f& v)
{
    m_Vertices[i] = v;
}

inline const DynamicMesh::Poly* DynamicMesh::GetPoly(size_t i) const
{
    return &m_Polygons[i];
}

inline const DynamicMesh::DataType* DynamicMesh::GetData(size_t i) const
{
    return &m_Data[i];
}
