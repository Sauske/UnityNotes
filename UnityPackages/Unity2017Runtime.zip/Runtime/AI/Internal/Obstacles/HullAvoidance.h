#pragma once


#include "Runtime/Math/Vector2.h"
#include "Runtime/Math/Vector3.h"
#include "Runtime/Utilities/dynamic_array.h"

#if PLATFORM_WEBGL
#include <values.h> // FLT_MAX
#endif

int CalculateExpandedClippedBoxConvexHull(Vector2f* segments2d, Vector2f* corners2d, const Vector3f* boxVertices,
    float slabMinY, float slabMaxY, float radius);

int CalculateClippedBoxConvexHull(Vector3f* hullVertices, const Vector3f* boxVertices, float slabMinY, float slabMaxY);

// returns true if y-axis aligned cylinder overlaps oriented box
// in case of overlap the 'penetration' is positive.
// in case of no overlap the 'penetration' is set to 0.
bool AlignedCylinderOverlapsOrientedBox(
    float* penetration, const Vector3f* boxVertices, const Vector3f& cylinderPosition,
    float cylinderRadius, float cylinderMinY, float cylinderMaxY);

// returns true if y-axis aligned cylinder overlaps oriented capsule
// in case of overlap the 'penetration' is positive.
// in case of no overlap the 'penetration' is set to 0.
bool AlignedCylinderOverlapsOrientedCapsule(
    float* penetration, const Vector3f& capsuleCenter, const Vector3f& capsuleExtents, const Vector3f& capsuleAxis,
    const Vector3f& cylinderPosition, float cylinderRadius, float cylinderMinY, float cylinderMaxY);

int CalculateClippedCapsule(
    Vector2f* points, float* radius,
    const Vector3f& capsuleCenter, const Vector3f& capsuleExtents, const Vector3f& capsuleAxis,
    float slabMinY, float slabMaxY);


typedef dynamic_array<Vector2f> Vertex2Array;

void CalculatePointsFromClippedBox(Vertex2Array& points, const Vector3f* box, float slabMinY, float slabMaxY);

void CalculateConvexHull(Vertex2Array& hull, Vertex2Array& points);

bool CircleHullOverlap(float* penetration, const Vertex2Array& hull, const Vector2f& circlePosition, float circleRadius);

void FitCapsuleToExtents(float* radius, float* height, const Vector3f& capsuleExtents);
void CalcCapsuleWorldExtents(Vector3f* worldExtents, const Vector3f& localExtents, const Vector3f& xAxis, const Vector3f& yAxis, const Vector3f& zAxis);
void CalcBoxWorldExtents(Vector3f* worldExtents, const Vector3f& localExtents, const Vector3f& xAxis, const Vector3f& yAxis, const Vector3f& zAxis);

void CalculateOrientedBoxCorners(Vector3f* cornerVertices, const Vector3f& position, const Vector3f& extents,
    const Vector3f& xAxis, const Vector3f& yAxis, const Vector3f& zAxis);
