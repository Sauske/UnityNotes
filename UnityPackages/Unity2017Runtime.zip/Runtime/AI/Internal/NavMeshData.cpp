#include "UnityPrefix.h"
#include "NavMeshData.h"
#include "NavMeshManager.h"
#include "NavMesh/NavMeshSwapEndian.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include <string.h> // memset
#if UNITY_EDITOR
#include "Editor/Src/AI/Internal/Visualization/NavMeshBuildDebugManager.h"
#include "Runtime/Serialize/PersistentManager.h"
#endif

template<class TransferFunction> inline
void TransferMeshDataByteSwap(TransferFunction& transfer, dynamic_array<UInt8>& data)
{
    if (transfer.IsWriting())
    {
        dynamic_array<UInt8> copy = data;
        if (!copy.empty())
        {
            ErrorIf(!NavMeshDataSwapEndian(&copy[0], copy.size()));
            ErrorIf(!NavMeshHeaderSwapEndian(&copy[0]));
        }
        transfer.Transfer(copy, "m_MeshData");
        return;
    }

    transfer.Transfer(data, "m_MeshData");

    if (transfer.IsReading() && !data.empty())
    {
        ErrorIf(!NavMeshDataSwapEndian(&data[0], data.size()));
        ErrorIf(!NavMeshHeaderSwapEndian(&data[0]));
    }
}

template<class TransferFunction>
void NavMeshTileData::Transfer(TransferFunction& transfer)
{
    if (!transfer.ConvertEndianess())
    {
        TRANSFER(m_MeshData);
    }
    else
    {
        TransferMeshDataByteSwap(transfer, m_MeshData);
    }

    TRANSFER(m_Hash);
}

// Legacy baked agent settings - added in 5.0 - replaced by storing NavMeshBuildSettings
struct NavMeshParams
{
    DECLARE_SERIALIZE(NavMeshParams)
    float walkableHeight;
    float walkableRadius;
    float walkableClimb;
    float cellSize;
};

template<class TransferFunction>
void NavMeshParams::Transfer(TransferFunction& transfer)
{
    TRANSFER(walkableHeight);
    TRANSFER(walkableRadius);
    TRANSFER(walkableClimb);
    TRANSFER(cellSize);
}

NavMeshData::NavMeshData(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
{
    m_SourceBounds = AABB::zero;
    m_Rotation = Quaternionf::identity();
    m_Position = Vector3f(0, 0, 0);
    m_AgentTypeID = 0;
}

void NavMeshData::ThreadedCleanup()
{
}

void NavMeshData::InitializeClass()
{
#if UNITY_EDITOR
    GetPersistentManager().AddNonTextSerializedType(TypeOf<NavMeshData>());
#endif
}

void NavMeshData::CleanupClass()
{
}

void NavMeshData::MainThreadCleanup()
{
#if UNITY_EDITOR
    NavMeshBuildDebugManager::Get().ClearDebugDraw(this);
#endif

    GetNavMeshManager().PurgeData(this);
    Super::MainThreadCleanup();
}

void NavMeshData::UpdateTiles(const dynamic_array<int>& removeTileIDs, NavMeshTileDataVector& newTiles, dynamic_array<int>& newTileIDs)
{
    newTileIDs.clear();

    // We do all this dance so that the data pointers of NavMeshTileData does not change.

    // Transfer ownership of the tile data to a temp array.
    NavMeshTileDataVector stash;
    stash.resize(m_NavMeshTiles.size());
    for (int i = 0; i < m_NavMeshTiles.size(); i++)
    {
        stash[i].m_MeshData.swap(m_NavMeshTiles[i].m_MeshData);
        stash[i].m_Hash = m_NavMeshTiles[i].m_Hash;

#if UNITY_EDITOR
        stash[i].m_DebugData.swap(m_NavMeshTiles[i].m_DebugData);
#endif
    }

    // Clear out the removed tiles.
    for (int i = 0; i < removeTileIDs.size(); i++)
    {
        int idx = removeTileIDs[i];
        NavMeshTileData& data = stash[idx];
        data.m_Hash = Hash128();
        data.m_MeshData.clear();

#if UNITY_EDITOR
        data.m_DebugData.clear();
#endif
    }

    // Reallocate new tile data array, we do this only once (after transferring the ownership),
    // so that the tile data pointers don't change.
    int newCount = m_NavMeshTiles.size() - removeTileIDs.size() + newTiles.size();
    Assert(newCount >= 0);
    m_NavMeshTiles.resize(newCount);

    // Transfer ownership of data from stash, and compact array as we go.
    int idx = 0;
    for (int i = 0; i < stash.size(); i++)
    {
        if (stash[i].m_MeshData.empty())
            continue;
        m_NavMeshTiles[idx].m_MeshData.swap(stash[i].m_MeshData);
        m_NavMeshTiles[idx].m_Hash = stash[i].m_Hash;

#if UNITY_EDITOR
        m_NavMeshTiles[idx].m_DebugData.swap(stash[i].m_DebugData);
#endif
        idx++;
    }

    // Transfer ownership of the new tile data
    // Add new tiles (not using m_NavMeshTiles.emplace_back_uninitialized() here to make sure pointers don't change).
    for (int i = 0; i < newTiles.size(); i++)
    {
        m_NavMeshTiles[idx].m_MeshData.swap(newTiles[i].m_MeshData);
        m_NavMeshTiles[idx].m_Hash = newTiles[i].m_Hash;

#if UNITY_EDITOR
        m_NavMeshTiles[idx].m_DebugData.swap(newTiles[i].m_DebugData);
#endif

        newTileIDs.push_back(idx);
        idx++;
    }
    Assert(idx <= newCount);

    m_NavMeshTiles.resize(idx);
    newTiles.clear();
}

void NavMeshData::AwakeFromLoad(AwakeFromLoadMode mode)
{
    Super::AwakeFromLoad(mode);
}

template<class TransferFunction>
void NavMeshData::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);
    transfer.SetVersion(2);

#if UNITY_EDITOR
    // Don't allow editing navmesh data in editor inspector
    // hide the byte data for tiles, it's typically large arrays of unreadable data - slowing down the editor when viewed.
    transfer.Transfer(m_NavMeshTiles, "m_NavMeshTiles", kHideInEditorMask | kNotEditableMask);
    transfer.Transfer(m_NavMeshBuildSettings, "m_NavMeshBuildSettings", kNotEditableMask);
    transfer.Transfer(m_Heightmaps, "m_Heightmaps", kNotEditableMask);
    transfer.Transfer(m_HeightMeshes, "m_HeightMeshes", kNotEditableMask);
    transfer.Transfer(m_OffMeshLinks, "m_OffMeshLinks", kNotEditableMask);
#else
    TRANSFER(m_NavMeshTiles);
    TRANSFER(m_NavMeshBuildSettings);
    TRANSFER(m_Heightmaps);
    TRANSFER(m_HeightMeshes);
    TRANSFER(m_OffMeshLinks);
#endif

    TRANSFER(m_SourceBounds);
    TRANSFER(m_Rotation);
    TRANSFER(m_Position);
    TRANSFER(m_AgentTypeID);

    if (transfer.IsOldVersion(1))
    {
        NavMeshParams params;
        transfer.Transfer(params, "m_NavMeshParams");
        m_NavMeshBuildSettings.agentHeight = params.walkableHeight;
        m_NavMeshBuildSettings.agentRadius = params.walkableRadius;
        m_NavMeshBuildSettings.agentClimb = params.walkableClimb;
        m_NavMeshBuildSettings.cellSize = params.cellSize;
    }
}

IMPLEMENT_REGISTER_CLASS(NavMeshData, 238);
IMPLEMENT_OBJECT_SERIALIZE(NavMeshData);
