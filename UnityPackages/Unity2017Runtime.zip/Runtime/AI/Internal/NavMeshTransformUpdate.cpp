#include "UnityPrefix.h"
#include "NavMeshTransformUpdate.h"
#include "Components/NavMeshAgent.h"
#include "Components/NavMeshObstacle.h"
#include "Crowd/CrowdManager.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Transform/TransformHierarchy.h"
#include "Runtime/Transform/TransformChangeDispatch.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Math/DeprecatedConversion.h"
#include "Runtime/Threads/Thread.h"
#include "Runtime/Utilities/sort_indices.h"
#include "Runtime/Utilities/algorithm_utility.h"
#include "Runtime/Threads/Thread.h"

PROFILER_INFORMATION(gSynchronizeSimulationToAgentTransforms, "SynchronizeSimulationToAgentTransforms", kProfilerAI);
PROFILER_INFORMATION(gSynchronizeAgentTransformsToSimulation, "SynchronizeAgentTransformsToSimulation", kProfilerAI);
PROFILER_INFORMATION(gNavMeshAgentsTransform, "Components.NavMeshAgent.Transform", kProfilerAI);
PROFILER_INFORMATION(gNavMeshAgentsSendMessage, "Components.NavMeshAgent.SendMessage", kProfilerAI);

struct NavMeshAgentUpdateTransformJobData
{
    NavMeshAgent** m_AgentBase;
    TransformAccess* m_TransformAccessBase;
    int* m_HasChanged;
    int m_Count;
    float m_DeltaTime;

    // Assumes the transform access elements are sorted by hierarchy
    static int Prepare(int itemCount, int desiredJobCount, NavMeshAgentUpdateTransformJobData* jobData, NavMeshAgent** agents, TransformAccess* tas, int* outHasChanged, float deltaTime)
    {
        Assert(desiredJobCount <= itemCount);
        Assert(is_sorted(tas, tas + itemCount));
        int jobCount = 0;
        for (int begin = 0; begin < itemCount && jobCount < desiredJobCount; ++jobCount)
        {
            int end = begin + (itemCount - begin) / (desiredJobCount - jobCount);

            // It is not allowed to split a transform hierarchy between different jobs when writing.
            // So here we increase the element count while the hierarchy is the same
            while (end < itemCount && tas[end].hierarchy == tas[end - 1].hierarchy)
                end++;

            NavMeshAgentUpdateTransformJobData& data = jobData[jobCount];
            data.m_AgentBase = agents + begin;
            data.m_TransformAccessBase = tas + begin;
            data.m_HasChanged = outHasChanged + begin;
            data.m_Count = (end - begin);
            data.m_DeltaTime = deltaTime;

            begin = end;
        }
        return jobCount;
    }

    static void Job(NavMeshAgentUpdateTransformJobData* jobData, unsigned int i)
    {
        PROFILER_AUTO(gNavMeshAgentsTransform, NULL);

        NavMeshAgentUpdateTransformJobData& data = jobData[i];
        NavMeshAgent** agentBase = data.m_AgentBase;
        TransformAccess* transformAccessBase = data.m_TransformAccessBase;
        int* hasChanged = data.m_HasChanged;
        float deltaTime = data.m_DeltaTime;

        const int count = data.m_Count;
        for (int i = 0; i < count; ++i)
        {
            hasChanged[i] = agentBase[i]->UpdateTransformAccess(deltaTime, transformAccessBase[i]);
        }
    }
};

struct NavMeshAgentMoveJobData
{
    NavMeshAgentMoveJobData(CrowdManager* c) : crowd(c) {}

    CrowdManager* crowd;

    // Displace agents according to position change, constrain by navmesh
    static void Job(NavMeshAgentMoveJobData* jobData, UInt32 jobIndex, const TransformAccessReadOnly* transforms, const TransformChangeSystemMask* changeMasks, unsigned count)
    {
        UNUSED(changeMasks);

        CrowdManager* crowd = jobData->crowd;
        for (size_t i = 0; i < count; ++i)
        {
            TransformAccessReadOnly transformAccess = transforms[i];
            const NavMeshAgent& agent = GetTransformComponentMainThread(transformAccess).GetComponent<NavMeshAgent>();
            if (!agent.GetUpdatePosition())
                continue;

            // Displace transform position along the negative up axis of the navmesh to find ground position.
            float baseOffset = agent.GetBaseOffset();
            math::float3 upAxis = Vector3fTofloat3(agent.GetInternalUpAxis());
            math::float3x3 gsm = CalculateGlobalSM(transformAccess, CalculateGlobalRotation(transformAccess));
            math::float3 offset = baseOffset * gsm.m1.y * upAxis;
            math::float3 groundPos = CalculateGlobalPosition(transformAccess) - offset;

            CrowdRef crowdRef = agent.GetCrowdRef();
            crowd->MoveAgent(crowdRef, jobIndex, float3ToVector3f(groundPos));
        }
    }
};

struct NavMeshAgentScaleJobData
{
    // Change the agent dimensions according to scale parameter
    static void Job(NavMeshAgentScaleJobData*, UInt32 jobIndex, const TransformAccessReadOnly* transforms, const TransformChangeSystemMask* changeMasks, unsigned count)
    {
        UNUSED(jobIndex);
        UNUSED(changeMasks);

        for (size_t i = 0; i < count; ++i)
        {
            TransformAccessReadOnly transformAccess = transforms[i];
            NavMeshAgent& agent = GetTransformComponentMainThread(transformAccess).GetComponent<NavMeshAgent>();
            agent.UpdateActiveAgentParameters();
        }
    }
};

void SynchronizeSimulationToAgentTransforms(CrowdManager* crowd)
{
    // Adjust simulated agents match modified transforms
    PROFILER_AUTO(gSynchronizeSimulationToAgentTransforms, NULL);
    AssertMsg(Thread::CurrentThreadIsMainThread(), "SynchronizeSimulationToAgentTransforms: Transform sync must happen on the main thread");

    TransformChangeDispatch& dispatch = GetTransformChangeDispatch();

    NavMeshAgentMoveJobData moveData(crowd);
    dispatch.GetAndClearChangedAsBatchedJobs(NavMeshAgent::s_MoveInterest.Mask(), NavMeshAgentMoveJobData::Job, &moveData);

    NavMeshAgentScaleJobData scaleData;
    dispatch.GetAndClearChangedAsBatchedJobs(NavMeshAgent::s_ScaleInterest.Mask(), NavMeshAgentScaleJobData::Job, &scaleData);
}

void SynchronizeSimulationToSingleAgentMove(CrowdManager* crowd, const NavMeshAgent* agent)
{
    // Adjust simulated agents match modified transforms
    PROFILER_AUTO(gSynchronizeSimulationToAgentTransforms, NULL);
    AssertMsg(Thread::CurrentThreadIsMainThread(), "SynchronizeSimulationToAgentTransforms: Transform sync must happen on the main thread");

    TransformAccessReadOnly ta = agent->GetComponent<Transform>().GetTransformAccess();
    TransformChangeSystemMask changeMask = NavMeshAgent::s_MoveInterest.Mask();
    NavMeshAgentMoveJobData moveData(crowd);
    NavMeshAgentMoveJobData::Job(&moveData, 0, &ta, &changeMask, 1);
}

void SynchronizeAgentTransformsToSimulation(dynamic_array<NavMeshAgent*>& agents, float dt)
{
    // Update all NavMeshAgent transforms and collect changeMask
    PROFILER_AUTO(gSynchronizeAgentTransformsToSimulation, NULL);
    AssertMsg(Thread::CurrentThreadIsMainThread(), "SynchronizeAgentTransformsToSimulation: Transform sync must happen on the main thread");

    const int n = agents.size();

    dynamic_array<UInt32> indices(kMemTempAlloc);
    dynamic_array<Transform*> transforms(kMemTempAlloc);
    dynamic_array<TransformAccess> tas(kMemTempAlloc);
    dynamic_array<NavMeshAgent*> sortedAgents(kMemTempAlloc);
    dynamic_array<int> hasChanged(kMemTempAlloc);

    indices.resize_uninitialized(n);
    transforms.resize_uninitialized(n);
    tas.resize_uninitialized(n);
    sortedAgents.resize_uninitialized(n);
    hasChanged.resize_uninitialized(n);

    for (size_t i = 0; i < n; ++i)
    {
        Transform* t = &agents[i]->GetComponent<Transform>();
        transforms[i] = t;
        tas[i] = t->GetTransformAccess();
        indices[i] = i;
    }

    sort_indices(tas.begin(), indices.begin(), n);
    apply_indices(indices.begin(), transforms.begin(), n);
    apply_indices(indices.begin(), tas.begin(), n);
    apply_indices(indices.begin(), agents.begin(), sortedAgents.begin(), n);

    const int kMaxJobs = 16;
    NavMeshAgentUpdateTransformJobData jobData[kMaxJobs] = {{}};
    int desiredJobCount = std::min(1 + n / 10, kMaxJobs);

    int jobCount = NavMeshAgentUpdateTransformJobData::Prepare(n, desiredJobCount, jobData, sortedAgents.begin(), tas.begin(), hasChanged.begin(), dt);

    JobFence fence;
    ScheduleJobForEach(fence, NavMeshAgentUpdateTransformJobData::Job, jobData, jobCount, kHighJobPriority);
    SyncFence(fence);

    // Send the messages. This must be removed once the 'kTransformChanged' message is removed.
    PROFILER_BEGIN(gNavMeshAgentsSendMessage, NULL);
    for (size_t i = 0; i < n; ++i)
    {
        if (hasChanged[i])
        {
            transforms[i]->QueueChanges();
#if UNITY_EDITOR
            transforms[i]->SetDirty();
#endif
        }
    }

    // Flush the changes caused by applying the transform message
    TransformChangeDispatch& dispatch = GetTransformChangeDispatch();
    dispatch.CheckAndClearChanged(NavMeshAgent::s_MoveInterest);
    PROFILER_END(gNavMeshAgentsSendMessage);
}

void SynchronizeObstaclesToTransforms()
{
    // Flag all NavMeshObstacle components with transform changes.
    AssertMsg(Thread::CurrentThreadIsMainThread(), "SynchronizeObstaclesToTransforms: Transform sync must happen on the main thread");

    TransformChangeDispatch& dispatch = GetTransformChangeDispatch();
    dynamic_array<TransformAccessReadOnly> outTransforms;

    // We execute this on the main thread because we're only setting an integer on the obstacle components
    // the overhead of using the job-system is likely bigger
    const size_t count = dispatch.GetAndClearChangedTransforms(NavMeshObstacle::s_NavMeshObstacleTRSInterest, outTransforms);
    for (size_t i = 0; i < count; ++i)
    {
        TransformAccessReadOnly transformAccess = outTransforms[i];
        NavMeshObstacle& obstacle = GetTransformComponentMainThread(transformAccess).GetComponent<NavMeshObstacle>();

        // TODO: Ideally we should dirty T,R,S independently
        // The transform change dispatch might provide this information in the future
        obstacle.SetTRSDirty();
    }
}
