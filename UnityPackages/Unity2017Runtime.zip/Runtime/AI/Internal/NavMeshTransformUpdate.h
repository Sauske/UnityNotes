#pragma once
#include "Runtime/Utilities/dynamic_array.h"

class CrowdManager;
class NavMeshAgent;

void SynchronizeSimulationToSingleAgentMove(CrowdManager* crowd, const NavMeshAgent* agent);
void SynchronizeSimulationToAgentTransforms(CrowdManager* crowd);
void SynchronizeAgentTransformsToSimulation(dynamic_array<NavMeshAgent*>& agents, float dt);

void SynchronizeObstaclesToTransforms();
