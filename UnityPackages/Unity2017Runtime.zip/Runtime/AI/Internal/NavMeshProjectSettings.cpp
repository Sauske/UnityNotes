#include "UnityPrefix.h"
#include "NavMeshProjectSettings.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/BaseClasses/ManagerContext.h"
#include "NavMeshManager.h"
#include "NavMeshBuildSettings.h"

const char* NavMeshProjectSettings::s_WarningCostLessThanOne = "Setting a NavMeshArea cost less than one can give unexpected results.";
const char* NavMeshProjectSettings::s_WarningUsingObsoleteAreaName = "The area name 'Default' is obsolete, please use 'Walkable' instead.";
static const char* kDefaultAgentTypeName = "Humanoid";

#define ASSERT_SETTINGS_SIZES() \
AssertFormatMsg (m_Settings.size () == m_SettingNames.size (), "The number of settings (%d) is out of sync with the number of setting names (%d).", m_Settings.size (), m_SettingNames.size ());


NavMeshProjectSettings::NavMeshProjectSettings(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
{
}

void NavMeshProjectSettings::ThreadedCleanup()
{
}

void NavMeshProjectSettings::Reset()
{
    Super::Reset();

    m_Areas[kWalkable].name = "Walkable";
    m_Areas[kWalkable].cost = 1.0f;

    m_Areas[kNotWalkable].name = "Not Walkable";
    m_Areas[kNotWalkable].cost = 1.0f;

    m_Areas[kJump].name = "Jump";
    m_Areas[kJump].cost = 2.0f;

    for (int i = kBuiltinAreaCount; i < kAreaCount; ++i)
        m_Areas[i].cost = 1.0f;

    // Create default agent with special id=0.
    m_Settings.resize(1);
    m_Settings[0].agentClimb = 0.75f;
    m_SettingNames.resize(1);
    m_SettingNames[0] = core::string(kDefaultAgentTypeName);

    m_LastAgentTypeID = 0xcb1ab31f;
}

template<class TransferFunction>
void NavMeshProjectSettings::NavMeshAreaData::Transfer(TransferFunction& transfer)
{
    transfer.Transfer(name, "name");
    transfer.Transfer(cost, "cost");
}

#if UNITY_EDITOR
namespace DataV1
{
    static const int kBuiltinAreaCount = 3;

    struct NavMeshLayerData
    {
        DECLARE_SERIALIZE(NavMeshLayerData)
        enum
        {
            kEditNone = 0,
            kEditName = 1,
            kEditCost = 2
        };
        core::string name;
        float cost;
        int editType;
    };

    template<class TransferFunction>
    void NavMeshLayerData::Transfer(TransferFunction& transfer)
    {
        TransferMetaFlags nameFlag = (editType & kEditName) ? kNoTransferFlags : kNotEditableMask;
        TransferMetaFlags costFlag = (editType & kEditCost) ? kNoTransferFlags : kNotEditableMask;
        transfer.Transfer(name, "name", nameFlag);
        transfer.Transfer(cost, "cost", costFlag);
        transfer.Transfer(editType, "editType", kNotEditableMask | kHideInEditorMask);
    }
}
#endif

template<class TransferFunction>
void NavMeshProjectSettings::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);

    transfer.SetVersion(2);

#if UNITY_EDITOR
    if (transfer.IsOldVersion(1))
    {
        for (int i = 0; i < kAreaCount; ++i)
        {
            char name[64];
            if (i < DataV1::kBuiltinAreaCount)
                sprintf(name, "Built-in Layer %d", i);
            else
                sprintf(name, "User Layer %d", i - DataV1::kBuiltinAreaCount);
            DataV1::NavMeshLayerData data;
            transfer.Transfer(data, name);
            m_Areas[i].name = data.name;
            m_Areas[i].cost = data.cost;
        }

        // Convert old "Default" to "Walkable".
        if (m_Areas[kWalkable].name.compare("Default") == 0)
            m_Areas[kWalkable].name = "Walkable";

        return;
    }
#endif

    if (!transfer.IsRemapPPtrTransfer())
    {
        std::vector<NavMeshAreaData> areas;
        for (int i = 0; i < kAreaCount; i++)
            areas.push_back(m_Areas[i]);

        TRANSFER(areas);

        if (transfer.DidReadLastProperty())
        {
            for (int i = 0; i < kAreaCount; i++)
                m_Areas[i] = areas[i];
        }

        // Convert old "Default" to "Walkable".
        if (m_Areas[kWalkable].name.compare("Default") == 0)
            m_Areas[kWalkable].name = "Walkable";
    }

    TRANSFER(m_LastAgentTypeID);
    TRANSFER(m_Settings);
    TRANSFER(m_SettingNames);

    // Make sure we have a default type.
    if (!transfer.IsRemapPPtrTransfer())
    {
        if (m_SettingNames.empty())
            m_SettingNames.resize(1);
        if (m_SettingNames[0].empty())
            m_SettingNames[0] = core::string(kDefaultAgentTypeName);

        if (m_Settings.empty() || m_Settings[0].agentTypeID != kDefaultAgentTypeID)
        {
            NavMeshBuildSettings settings;
            settings.agentClimb = 0.75f;
            m_Settings.insert(m_Settings.begin(), settings);
        }
    }
}

void NavMeshProjectSettings::SetAreaCost(unsigned int index, float cost)
{
    if (index >= kAreaCount)
    {
        ErrorString("Index out of bounds");
        return;
    }
#if UNITY_EDITOR
    if (cost < 1.0f)
    {
        WarningString(s_WarningCostLessThanOne);
    }
#endif
    m_Areas[index].cost = cost;
    GetNavMeshManager().UpdateAllNavMeshAgentCosts(index, cost);

    SetDirty();
}

float NavMeshProjectSettings::GetAreaCost(unsigned int index) const
{
    if (index >= kAreaCount)
    {
        ErrorString("Index out of bounds");
        return 0.0f;
    }
    return m_Areas[index].cost;
}

void NavMeshProjectSettings::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);

    // When the user changes the cost in the inspector
    if (UNITY_EDITOR && (awakeMode & kDidLoadFromDisk) == 0)
    {
        for (int i = 0; i < kAreaCount; ++i)
            GetNavMeshManager().UpdateAllNavMeshAgentCosts(i, m_Areas[i].cost);
    }
}

int NavMeshProjectSettings::GetAreaFromName(const core::string& areaName) const
{
    for (int i = 0; i < kAreaCount; ++i)
    {
        if (m_Areas[i].name.compare(areaName) == 0)
        {
            return i;
        }
    }

    // The walkable area type got changed from "Default" to "Walkable" in 5.0.
    // If using old data, still accept "Default" as walkable.
    if (areaName.compare("Default") == 0)
    {
        WarningString(s_WarningUsingObsoleteAreaName);
        return kWalkable;
    }

    return -1;
}

std::vector<core::string> NavMeshProjectSettings::GetAreaNames() const
{
    std::vector<core::string> areas;
    for (int i = 0; i < kAreaCount; ++i)
    {
        if (m_Areas[i].name.length() != 0)
        {
            areas.push_back(m_Areas[i].name);
        }
    }
    return areas;
}

void NavMeshProjectSettings::CheckConsistency()
{
#if UNITY_EDITOR
    for (int i = 0; i < kAreaCount; ++i)
    {
        if (m_Areas[i].cost < 1.0f)
        {
            WarningString(s_WarningCostLessThanOne);
            return;
        }
    }

    for (int i = 0; i < m_Settings.size(); ++i)
    {
        NavMeshBuildSettings& bs = m_Settings[i];
        bs.agentRadius = std::max(bs.agentRadius, NavMeshBuildSettings::kMinAgentRadius);
        bs.agentHeight = std::max(bs.agentHeight, NavMeshBuildSettings::kMinAgentHeight);
        bs.agentClimb  = std::max(bs.agentClimb, NavMeshBuildSettings::kMinAgentHeight);
    }
#endif
}

static bool IsUsedAgentTypeID(const std::vector<NavMeshBuildSettings>& settings, int id)
{
    if (id == NavMeshProjectSettings::kDefaultAgentTypeID || id == NavMeshProjectSettings::kInvalidAgentTypeID)
        return true;

    for (int i = 0; i < settings.size(); i++)
    {
        if (settings[i].agentTypeID == id)
            return true;
    }
    return false;
}

static bool IsUsedName(std::vector<core::string>& names, const core::string& name)
{
    for (int i = 0; i < names.size(); i++)
    {
        if (names[i].compare(name) == 0)
            return true;
    }
    return false;
}

int NavMeshProjectSettings::GetUnusedAgentTypeID()
{
    int id;
    do
    {
        // Quick and dirty generator from Numerical Recipes
        m_LastAgentTypeID = 1664525 * m_LastAgentTypeID + 1013904223;
        id = m_LastAgentTypeID;
    }
    while (IsUsedAgentTypeID(m_Settings, id));

    return id;
}

const NavMeshBuildSettings& NavMeshProjectSettings::CreateSettings()
{
    ASSERT_SETTINGS_SIZES();
    NavMeshBuildSettings settings;
    settings.agentTypeID = GetUnusedAgentTypeID();
    m_Settings.push_back(settings);

    int idx = 0;
    core::string name("New Agent");
    while (IsUsedName(m_SettingNames, name))
        name = Format("New Agent %d", ++idx);

    m_SettingNames.push_back(name);
    SetDirty();

    return m_Settings[m_Settings.size() - 1];
}

void NavMeshProjectSettings::UpdateSettings(const NavMeshBuildSettings& settings)
{
    ASSERT_SETTINGS_SIZES();
    for (size_t i = 0; i < m_Settings.size(); ++i)
    {
        if (m_Settings[i].agentTypeID == settings.agentTypeID)
        {
            m_Settings[i] = settings;
            SetDirty();
            return;
        }
    }
}

void NavMeshProjectSettings::RemoveSettings(int agentTypeID)
{
    ASSERT_SETTINGS_SIZES();
    if (agentTypeID == kDefaultAgentTypeID)
    {
        ErrorString("Default Agent type cannot be removed");
        return;
    }

    for (size_t i = 0; i < m_Settings.size(); ++i)
    {
        if (m_Settings[i].agentTypeID == agentTypeID)
        {
            m_Settings.erase(m_Settings.begin() + i);
            m_SettingNames.erase(m_SettingNames.begin() + i);
            SetDirty();
            return;
        }
    }
}

const NavMeshBuildSettings* NavMeshProjectSettings::GetSettingsByID(int agentTypeID) const
{
    ASSERT_SETTINGS_SIZES();
    for (size_t i = 0; i < m_Settings.size(); ++i)
    {
        if (m_Settings[i].agentTypeID == agentTypeID)
            return &m_Settings[i];
    }
    return NULL;
}

int NavMeshProjectSettings::GetSettingsCount() const
{
    ASSERT_SETTINGS_SIZES();
    return static_cast<int>(m_Settings.size());
}

const NavMeshBuildSettings* NavMeshProjectSettings::GetSettingsByIndex(int index) const
{
    ASSERT_SETTINGS_SIZES();
    if (index < 0 || index >= m_Settings.size())
        return NULL;
    return &m_Settings[index];
}

void NavMeshProjectSettings::SetSettingsNameForID(int agentTypeID, const core::string& name)
{
    ASSERT_SETTINGS_SIZES();
    for (size_t i = 0; i < m_Settings.size(); ++i)
    {
        if (m_Settings[i].agentTypeID == agentTypeID)
        {
            m_SettingNames[i] = name;
            SetDirty();
            return;
        }
    }
}

const core::string* NavMeshProjectSettings::GetSettingsNameFromID(int agentTypeID) const
{
    ASSERT_SETTINGS_SIZES();
    for (size_t i = 0; i < m_Settings.size(); ++i)
    {
        if (m_Settings[i].agentTypeID == agentTypeID)
            return &m_SettingNames[i];
    }
    return NULL;
}

IMPLEMENT_REGISTER_CLASS(NavMeshProjectSettings, 126);
IMPLEMENT_OBJECT_SERIALIZE(NavMeshProjectSettings);
GET_MANAGER(NavMeshProjectSettings)
