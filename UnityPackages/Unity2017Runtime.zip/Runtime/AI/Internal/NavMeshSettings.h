#pragma once

#include "NavMeshData.h"
#include "Runtime/BaseClasses/GameManager.h"
#if UNITY_EDITOR
#include "NavMeshBuildSettings.h"
#endif

class NavMeshSettings : public LevelGameManager
{
    REGISTER_CLASS(NavMeshSettings);
    DECLARE_OBJECT_SERIALIZE();
public:
    NavMeshSettings(MemLabelId label, ObjectCreationMode mode);

    virtual void MainThreadCleanup();

    virtual void AwakeFromLoad(AwakeFromLoadMode mode);
    virtual void Reset();

    static void InitializeClass();
    static void CleanupClass();

    virtual bool ShouldWriteForBuild() const { return m_NavMeshData.IsValid(); }
    NavMeshData* GetNavMeshData() { return m_NavMeshData; }

#if UNITY_EDITOR
    inline NavMeshBuildSettings& GetNavMeshBuildSettings() { return m_BuildSettings; }
    void SetNavMeshData(NavMeshData* navMeshData) { m_NavMeshData = navMeshData; SetDirty(); }
private:
    NavMeshBuildSettings m_BuildSettings;
#endif

private:
    PPtr<NavMeshData> m_NavMeshData;
};

NavMeshSettings& GetNavMeshSettings();
