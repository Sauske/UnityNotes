#pragma once

#include <map>
#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Geometry/AABB.h"
#include "Runtime/Math/Vector3.h"

// Pointer to terrain data
struct HeightmapData
{
    DECLARE_SERIALIZE(HeightmapData)

    Vector3f position;
    PPtr<Object> terrainData;
};

template<class TransferFunction>
void HeightmapData::Transfer(TransferFunction& transfer)
{
    TRANSFER(position);
    TRANSFER(terrainData);
}

typedef dynamic_array<HeightmapData> HeightmapDataVector;


// Height Mesh BV-tree node
struct HeightMeshBVNode
{
    DECLARE_SERIALIZE(HeightMeshBVNode)

    Vector3f min, max;
    int i, n;
};

template<class TransferFunction>
void HeightMeshBVNode::Transfer(TransferFunction& transfer)
{
    TRANSFER(min);
    TRANSFER(max);
    TRANSFER(i);
    TRANSFER(n);
}

// Data describing a height triangle mesh.
struct HeightMeshData
{
    DECLARE_SERIALIZE(HeightMeshData)
    dynamic_array<Vector3f> m_Vertices;
    dynamic_array<int> m_Indices;
    dynamic_array<HeightMeshBVNode> m_Nodes;
    AABB m_Bounds;
};

template<class TransferFunction>
void HeightMeshData::Transfer(TransferFunction& transfer)
{
    TRANSFER(m_Vertices);
    TRANSFER(m_Indices);
    TRANSFER(m_Bounds);
    TRANSFER(m_Nodes);
}

typedef UNITY_VECTOR (kMemAI, HeightMeshData) HeightMeshDataVector;

class HeightMeshQuery
{
public:
    HeightMeshQuery();
    virtual ~HeightMeshQuery();

    // Does the HeightMeshQuery contain any height data
    inline bool HasHeightData() const;

    // Sets the y-component to match the height data.
    bool SetPositionHeight(Vector3f* position) const;

    void AddHeightData(int index, float searchRadius, float verticalOffset, const HeightMeshDataVector* heightMeshes, const HeightmapDataVector* heightMaps);
    void RemoveHeightData(int index);

#if UNITY_EDITOR
    void GetHeightMeshData(dynamic_array<const HeightMeshDataVector*>& allHeightMeshes) const;
#endif

private:
    bool GetTerrainHeight(const Vector3f& position, float* height) const;
    bool GetGeometryHeight(const Vector3f& position, float* height) const;

    struct HeightData
    {
        const HeightMeshDataVector* m_HeightMeshes;
        const HeightmapDataVector* m_HeightMaps;
        float searchRadius;
        float verticalOffset;
    };
    typedef UNITY_MAP (kMemAI, int, HeightData) HeightMeshDataMap;

    HeightMeshDataMap m_HeightData;
};

inline bool HeightMeshQuery::HasHeightData() const
{
    return !m_HeightData.empty();
}

// Builds BV-tree for mesh. Note: the function re-arranges indices.
bool BuildBVTree(const dynamic_array<Vector3f>& vertices, dynamic_array<int>& indices, dynamic_array<HeightMeshBVNode>& nodes, const int trisPerNode);
