#include "UnityPrefix.h"
#include "HeightMeshQuery.h"
#include "../MathUtil.h"
#include "Runtime/Interfaces/ITerrainManager.h"


HeightMeshQuery::HeightMeshQuery()
{
}

HeightMeshQuery::~HeightMeshQuery()
{
}

void HeightMeshQuery::AddHeightData(int index, float searchRadius, float verticalOffset, const HeightMeshDataVector* heightMeshes, const HeightmapDataVector* heightMaps)
{
    if (heightMeshes->empty() && heightMaps->empty())
        return;

    Assert(m_HeightData.find(index) == m_HeightData.end());
    HeightData& data = m_HeightData[index];

    data.m_HeightMeshes = heightMeshes;
    data.m_HeightMaps = heightMaps;
    data.searchRadius = std::max(0.001f, searchRadius);
    data.verticalOffset = verticalOffset;
}

void HeightMeshQuery::RemoveHeightData(int index)
{
    HeightMeshDataMap::iterator found = m_HeightData.find(index);
    if (found == m_HeightData.end())
        return;

    m_HeightData.erase(found);
}

#if UNITY_EDITOR
void HeightMeshQuery::GetHeightMeshData(dynamic_array<const HeightMeshDataVector*>& allHeightMeshes) const
{
    HeightMeshDataMap::const_iterator it = m_HeightData.begin();
    const HeightMeshDataMap::const_iterator end = m_HeightData.end();
    for (; it != end; ++it)
    {
        const HeightMeshDataVector* heightMeshes = it->second.m_HeightMeshes;
        if (heightMeshes != NULL)
        {
            allHeightMeshes.push_back(heightMeshes);
        }
    }
}

#endif

bool HeightMeshQuery::SetPositionHeight(Vector3f* position) const
{
    if (m_HeightData.empty())
        return false;

    const Vector3f rayStart = *position;

    float geometryHeight, terrainHeight;
    const bool bGeometryHit = GetGeometryHeight(rayStart, &geometryHeight);
    const bool bTerrainHit = GetTerrainHeight(rayStart, &terrainHeight);

    if (bGeometryHit && bTerrainHit)
    {
        float geomDist = Abs(rayStart.y - geometryHeight);
        float terrainDist = Abs(rayStart.y - terrainHeight);
        if (geomDist < terrainDist)
            position->y = geometryHeight;
        else
            position->y = terrainHeight;

        return true;
    }

    if (bGeometryHit)
    {
        position->y = geometryHeight;
        return true;
    }

    if (bTerrainHit)
    {
        position->y = terrainHeight;
        return true;
    }

    return false;
}

static int ClipPoly(const Vector3f* in, int count, Vector3f* out, const Vector3f& normal, float pd)
{
    Assert(count <= 6);
    float d[6];
    for (int i = 0; i < count; ++i)
        d[i] = Dot(in[i], normal) + pd;

    int m = 0;
    for (int i = 0, j = count - 1; i < count; j = i, ++i)
    {
        bool ina = d[j] >= 0;
        bool inb = d[i] >= 0;
        if (ina != inb)
        {
            float s = d[j] / (d[j] - d[i]);
            out[m] = in[j] + (in[i] - in[j]) * s;
            m++;
        }
        if (inb)
        {
            out[m] = in[i];
            m++;
        }
    }
    return m;
}

static bool ClosestHeightPointTriangle(float* hitHeight, const Vector3f& rayStart, const float radius,
    const Vector3f& va, const Vector3f& vb, const Vector3f& vc)
{
    // Clipping a triangle by four planes we need room for a final worst case of 7 vertices.
    Vector3f pointsA[7];
    Vector3f pointsB[6];
    int countA = 0, countB = 0;

    pointsA[0] = va;
    pointsA[1] = vb;
    pointsA[2] = vc;
    countA = 3;

    countB = ClipPoly(pointsA, countA, pointsB, Vector3f(1, 0, 0), -(rayStart.x - radius));
    if (countB < 3)
        return false;
    countA = ClipPoly(pointsB, countB, pointsA, Vector3f(-1, 0, 0), rayStart.x + radius);
    if (countA < 3)
        return false;
    countB = ClipPoly(pointsA, countA, pointsB, Vector3f(0, 0, 1), -(rayStart.z - radius));
    if (countB < 3)
        return false;
    countA = ClipPoly(pointsB, countB, pointsA, Vector3f(0, 0, -1), rayStart.z + radius);
    if (countA < 3)
        return false;

    float maxY = pointsA[0].y;
    for (int i = 1; i < countA; i++)
        maxY = std::max(maxY, pointsA[i].y);

    *hitHeight = maxY;

    return true;
}

bool HeightMeshQuery::GetGeometryHeight(const Vector3f& rayStart, float* height) const
{
    Assert(height != NULL);

    Vector3f rayMin(rayStart.x, -std::numeric_limits<float>::infinity(), rayStart.z);
    Vector3f rayMax(rayStart.x, rayStart.y, rayStart.z);

    HeightMeshDataMap::const_iterator it = m_HeightData.begin();
    const HeightMeshDataMap::const_iterator end = m_HeightData.end();
    for (; it != end; ++it)
    {
        const HeightMeshDataVector* heightMeshes = it->second.m_HeightMeshes;
        if (heightMeshes == NULL)
            continue;
        const float searchRadius = it->second.searchRadius;
        const float verticalOffset = it->second.verticalOffset;

        rayMin.x = rayStart.x - searchRadius;
        rayMin.z = rayStart.z - searchRadius;
        rayMax.y = rayStart.y + verticalOffset;
        rayMax.x = rayStart.x + searchRadius;
        rayMax.z = rayStart.z + searchRadius;

        for (int i = 0; i < heightMeshes->size(); i++)
        {
            const HeightMeshData& mesh = (*heightMeshes)[i];

            // Check first if the ray hits the mesh bounds.
            const Vector3f bmin = mesh.m_Bounds.CalculateMin();
            const Vector3f bmax = mesh.m_Bounds.CalculateMax();

            if (!OverlapBounds(rayMin, rayMax, bmin, bmax))
                continue;

            if (mesh.m_Nodes.size())
            {
                // Use BV-tree to speed up triangle lookup
                int n = 0;
                while (n < mesh.m_Nodes.size())
                {
                    const HeightMeshBVNode& node = mesh.m_Nodes[n];

                    const bool overlap = OverlapBounds(rayMin, rayMax, node.min, node.max);
                    const bool isLeafNode = node.i >= 0;

                    if (isLeafNode && overlap)
                    {
                        const int j0 = node.i * 3;
                        const int j1 = (node.i + node.n) * 3;
                        for (int j = j0; j < j1; j += 3)
                        {
                            const Vector3f& va = mesh.m_Vertices[mesh.m_Indices[j + 0]];
                            const Vector3f& vb = mesh.m_Vertices[mesh.m_Indices[j + 1]];
                            const Vector3f& vc = mesh.m_Vertices[mesh.m_Indices[j + 2]];

                            float hitHeight;
                            if (ClosestHeightPointTriangle(&hitHeight, rayStart, searchRadius, va, vb, vc))
                            {
                                if (hitHeight > rayMin.y && hitHeight < rayMax.y)
                                {
                                    rayMin.y = hitHeight;
                                }
                            }
                        }
                    }

                    if (overlap || isLeafNode)
                    {
                        n++;
                    }
                    else
                    {
                        const int escapeIndex = -node.i;
                        n += escapeIndex;
                    }
                }
            }
            else
            {
                // Test triangles
                for (int j = 0; j < mesh.m_Indices.size(); j += 3)
                {
                    const Vector3f& va = mesh.m_Vertices[mesh.m_Indices[j + 0]];
                    const Vector3f& vb = mesh.m_Vertices[mesh.m_Indices[j + 1]];
                    const Vector3f& vc = mesh.m_Vertices[mesh.m_Indices[j + 2]];
                    float hitHeight;
                    if (ClosestHeightPointTriangle(&hitHeight, rayStart, searchRadius, va, vb, vc))
                    {
                        if (hitHeight > rayMin.y && hitHeight < rayMax.y)
                        {
                            rayMin.y = hitHeight;
                        }
                    }
                }
            }
        }
    }

    if (rayMin.y == -std::numeric_limits<float>::infinity())
    {
        *height = rayStart.y;
        return false;
    }

    *height = rayMin.y;
    return true;
}

bool HeightMeshQuery::GetTerrainHeight(const Vector3f& rayStart, float* height) const
{
    Assert(height != NULL);

    ITerrainManager* terrain = GetITerrainManager();
    if (terrain == NULL)
        return false;

    const float upperBound = rayStart.y;
    float lowerBound = -std::numeric_limits<float>::infinity();

    HeightMeshDataMap::const_iterator it = m_HeightData.begin();
    const HeightMeshDataMap::const_iterator end = m_HeightData.end();
    for (; it != end; ++it)
    {
        const HeightmapDataVector* heightMaps = it->second.m_HeightMaps;
        if (heightMaps == NULL)
            continue;

        const float verticalOffset = it->second.verticalOffset;
        const Vector3f rayMax(rayStart.x, rayStart.y + verticalOffset, rayStart.z);

        for (size_t i = 0; i < heightMaps->size(); ++i)
        {
            const HeightmapData& heightmapData = (*heightMaps)[i];
            InstanceID instanceID = heightmapData.terrainData.GetInstanceID();

            // Warning - it's safe to call this only if we have no script callbacks
            // something we cannot assert here!
            const Object* terrainData = Object::IDToPointerNoThreadCheck(instanceID);

            float terrainHeight;
            bool hitTerrain = terrain->GetInterpolatedHeight(terrainData, heightmapData.position, rayMax, terrainHeight);
            if (hitTerrain && terrainHeight > lowerBound && terrainHeight < upperBound)
                lowerBound = terrainHeight;
        }
    }

    if (lowerBound == -std::numeric_limits<float>::infinity())
    {
        *height = rayStart.y;
        return false;
    }

    *height = lowerBound;
    return true;
}

struct NodeXSorter
{
    bool operator()(const HeightMeshBVNode& ra, const HeightMeshBVNode& rb) const
    {
        const float a = (ra.min.x + ra.max.x) * 0.5f;
        const float b = (rb.min.x + rb.max.x) * 0.5f;
        return a < b;
    }
};

struct NodeYSorter
{
    bool operator()(const HeightMeshBVNode& ra, const HeightMeshBVNode& rb) const
    {
        const float a = (ra.min.y + ra.max.y) * 0.5f;
        const float b = (rb.min.y + rb.max.y) * 0.5f;
        return a < b;
    }
};

struct NodeZSorter
{
    bool operator()(const HeightMeshBVNode& ra, const HeightMeshBVNode& rb) const
    {
        const float a = (ra.min.z + ra.max.z) * 0.5f;
        const float b = (rb.min.z + rb.max.z) * 0.5f;
        return a < b;
    }
};

inline int LongestAxis(const Vector3f& v)
{
    int axis = 0;
    if (v[1] > v[axis])
        axis = 1;
    if (v[2] > v[axis])
        axis = 2;
    return axis;
}

static void Subdivide(dynamic_array<HeightMeshBVNode>& items, int imin, int imax, int trisPerNode,
    dynamic_array<HeightMeshBVNode>& nodes, dynamic_array<int>& outTris,
    const dynamic_array<int>& inTris)
{
    int inum = imax - imin;

    HeightMeshBVNode& node = nodes.emplace_back_uninitialized();
    const int icur = nodes.size() - 1;

    // Update bounds
    node.min = items[imin].min;
    node.max = items[imin].max;
    for (int i = imin + 1; i < imax; ++i)
    {
        node.min = min(node.min, items[i].min);
        node.max = max(node.max, items[i].max);
    }

    if (inum <= trisPerNode)
    {
        // Leaf, copy triangles.
        node.i = outTris.size() / 3;
        node.n = inum;
        for (int i = imin; i < imax; ++i)
        {
            const int* src = &inTris[items[i].i * 3];
            outTris.push_back(src[0]);
            outTris.push_back(src[1]);
            outTris.push_back(src[2]);
        }
    }
    else
    {
        // Split remaining items along longest axis
        const int axis = LongestAxis(node.max - node.min);
        if (axis == 0)
            std::sort(items.begin() + imin, items.begin() + imax, NodeXSorter());
        else if (axis == 1)
            std::sort(items.begin() + imin, items.begin() + imax, NodeYSorter());
        else
            std::sort(items.begin() + imin, items.begin() + imax, NodeZSorter());
        int isplit = imin + inum / 2;

        // Left
        Subdivide(items, imin, isplit, trisPerNode, nodes, outTris, inTris);
        // Right
        Subdivide(items, isplit, imax, trisPerNode, nodes, outTris, inTris);

        int iescape = (nodes.size() - 1) - icur;
        // Negative index means escape.
        nodes[icur].i = -iescape;   // 'node' ref may be invalid because of realloc.
    }
}

bool BuildBVTree(const dynamic_array<Vector3f>& vertices, dynamic_array<int>& indices, dynamic_array<HeightMeshBVNode>& nodes, const int trisPerNode)
{
    const int triCount = indices.size() / 3;

    nodes.clear();

    // Build input items
    dynamic_array<HeightMeshBVNode> items;
    items.resize_uninitialized(triCount);
    for (int i = 0; i < triCount; i++)
    {
        const int* t = &indices[i * 3];
        HeightMeshBVNode& it = items[i];
        it.i = i;
        // Calc triangle bounds.
        it.min = it.max = vertices[t[0]];
        it.min = min(it.min, vertices[t[1]]);
        it.max = max(it.max, vertices[t[1]]);
        it.min = min(it.min, vertices[t[2]]);
        it.max = max(it.max, vertices[t[2]]);
    }

    dynamic_array<int> sourceIndices;
    sourceIndices.resize_uninitialized(indices.size());
    std::copy(indices.begin(), indices.end(), sourceIndices.begin());
    indices.resize_initialized(0);

    Subdivide(items, 0, triCount, trisPerNode, nodes, indices, sourceIndices);

    return true;
}
