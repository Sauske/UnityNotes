#include "UnityPrefix.h"
#include "PathUtil.h"
#include <cstring>

// Finds the furthest intersection point on the paths 'a' and 'b'
// i.e. finds the maximum index ia, for which a(ia) == b(ib).
// returns true unless no intersection is found.
inline bool FindFurthestIntersectionIndices(const NavMeshPolyRef* a, const NavMeshPolyRef* b, const int na, const int nb, int* ia, int* ib)
{
    for (int i = na - 1; i >= 0; --i)
    {
        for (int j = nb - 1; j >= 0; --j)
        {
            if (a[i] == b[j])
            {
                *ia = i;
                *ib = j;
                return true;
            }
        }
    }
    return false;
}

bool ReplacePathStart(dynamic_array<NavMeshPolyRef>& path, const NavMeshPolyRef* start, int nstart)
{
    const int npath = path.size();
    int ipath, istart;
    if (!FindFurthestIntersectionIndices(path.begin(), start, npath, nstart, &ipath, &istart))
        return false;

    // the result may only grow before the elements are moved in-place.
    const int nres = istart + (npath - ipath);
    if (nres > npath)
        path.resize_uninitialized(nres);

    // move elements in place
    memmove(&path[istart], &path[ipath], sizeof(NavMeshPolyRef) * (npath - ipath));
    memcpy(&path[0], start, sizeof(NavMeshPolyRef) * istart);

    // shrink result to fit
    path.resize_uninitialized(nres);
    return true;
}

bool ReplacePathStartReverse(dynamic_array<NavMeshPolyRef>& path, const NavMeshPolyRef* start, int nstart)
{
    const int npath = path.size();
    int ipath, istart;
    if (!FindFurthestIntersectionIndices(path.begin(), start, npath, nstart, &ipath, &istart))
        return false;

    // the pivot index for the reversed start segment
    const int istartrev = nstart - 1 - istart;

    // the result may only grow before the elements are moved in-place.
    const int nres = istartrev + (npath - ipath);
    if (nres > npath)
        path.resize_uninitialized(nres);

    // move elements in place
    memmove(&path[istartrev], &path[ipath], sizeof(NavMeshPolyRef) * (npath - ipath));
    for (int i = 0; i < istartrev; ++i)
        path[i] = start[nstart - 1 - i];

    // shrink result to fit
    path.resize_uninitialized(nres);
    return true;
}
