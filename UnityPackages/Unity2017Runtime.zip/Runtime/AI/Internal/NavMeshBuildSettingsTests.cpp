#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS
#include "Runtime/Testing/Testing.h"
#include "./NavMeshBuildSettings.h"
#include <string.h>

UNIT_TEST_SUITE(NavMeshBuildSettings)
{
    TEST(NoGarbageInPaddingAfterConstruction)
    {
        char mem_garbage[sizeof(NavMeshBuildSettings)];
        memset(mem_garbage, 0xab, sizeof(NavMeshBuildSettings));

        char mem_zero[sizeof(NavMeshBuildSettings)];
        memset(mem_zero, 0, sizeof(NavMeshBuildSettings));

        NavMeshBuildSettings* settings_garbage = new(mem_garbage)NavMeshBuildSettings();
        NavMeshBuildSettings* settings_zero = new(mem_zero)NavMeshBuildSettings();

        CHECK_EQUAL(0, memcmp(settings_garbage, settings_zero, sizeof(NavMeshBuildSettings)));
    }
}

#endif
