//
// Copyright (c) 2009-2010 Mikko Mononen memon@inside.org
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

// The original source code has been modified by Unity Technologies

#include "UnityPrefix.h"
#include "./CrowdManager.h"
#include "./CrowdTypes.h"
#include "./CrowdUpdate.h"
#include "./ObstacleAvoidanceQuery.h"
#include "./ProximityGrid.h"
#include "../MathUtil.h"
#include "../NavMesh/NavMesh.h"
#include "../NavMesh/NavMeshQuery.h"
#include "../NavMesh/QueryFilter.h"
#include "../Obstacles/HullAvoidance.h"
#include "../HeightMesh/HeightMeshQuery.h"

#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Jobs/JobSystem.h"
#include "Runtime/Logging/LogAssert.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Geometry/Plane.h"

#define MULTITHREADED_CROWD_UPDATE ENABLE_MULTITHREADED_CODE

PROFILER_INFORMATION(gNavMeshProximityCollect, "Crowd.Proximity.Collect", kProfilerAI)
PROFILER_INFORMATION(gNavMeshCorners, "Crowd.Corners", kProfilerAI)
PROFILER_INFORMATION(gNavMeshValidatePath, "Crowd.ValidatePath", kProfilerAI)
PROFILER_INFORMATION(gNavMeshRepathTrigger, "Crowd.RepathTrigger", kProfilerAI)
PROFILER_INFORMATION(gNavMeshMovement, "Crowd.Movement", kProfilerAI)
PROFILER_INFORMATION(gNavMeshCollision, "Crowd.Collision", kProfilerAI)
PROFILER_INFORMATION(gNavMeshAvoidance, "Crowd.Avoidance", kProfilerAI)
PROFILER_INFORMATION(gNavMeshIntegrate, "Crowd.Integrate", kProfilerAI)
PROFILER_INFORMATION(gNavMeshSteering, "Crowd.Steering", kProfilerAI)
PROFILER_INFORMATION(gNavMeshOffMeshTrigger, "Crowd.OffMeshLinkTrigger", kProfilerAI)
PROFILER_INFORMATION(gNavMeshOffMeshMovement, "Crowd.OffMeshLinkMovement", kProfilerAI)
PROFILER_INFORMATION(gNavMeshHeightMesh, "Crowd.HeightMesh", kProfilerAI)

static const float CROWD_SEPARATION_WEIGHT = 0.7f;
static const float CROWD_SEPARATION_SCALE = 2.5f;
static const int CROWD_MAX_NEIS = 64;

struct CrowdInfo
{
    UpdateCrowdInfo             rangeInfo[CrowdManager::kMaxCrowdJobs];
    NavMeshQuery*               navMeshQuery[CrowdManager::kMaxCrowdJobs];
    ReadonlyCrowdInfo           readOnlyCrowdInfo;
    CrowdManager*               crowd;
    float                       deltaTime;
};

void CollectNeighbourObstacles(CrowdAgent& agent, const ReadonlyCrowdInfo& crowdInfo)
{
    // Get agent properties on the stack
    Vector3f agentPosition;
    Vector3f agentVelocity;
    agentPosition = agent.npos;
    agentVelocity = agent.vel;
    const float agentRadius = agent.params.radius;
    const int agentPriority = agent.params.priority;

    const float queryRad = agentRadius + agent.params.maxSpeed * crowdInfo.avoidancePredictionTime;
    float bounds[4];
    bounds[0] = agentPosition[0] - queryRad;
    bounds[1] = agentPosition[2] - queryRad;
    bounds[2] = agentPosition[0] + queryRad;
    bounds[3] = agentPosition[2] + queryRad;

    CrowdRef refs[CROWD_MAX_NEIS];
    int nids = crowdInfo.proximityGrid->QueryItems(bounds, refs, CROWD_MAX_NEIS);

    Vector3f cullDir(0.0f, 0.0f, 0.0f);
    bool cullObstacleBehind = SqrMagnitude(agent.dvel) > 0.01f;
    if (cullObstacleBehind)
    {
        cullDir = Normalize(agent.dvel);
    }

    int found = 0;
    CrowdNeighbour neis[CROWD_MAX_NEIS];
    for (int i = 0; i < nids; ++i)
    {
        CrowdRef otherRef = refs[i];
        Vector3f otherPosition;
        Vector3f otherVelocity;
        float otherRadius;

        unsigned int salt = 0, index = 0, type = 0;
        CrowdManager::DecodeCrowdId(&salt, &index, &type, otherRef);

        if (type == kCrowdAgent)
        {
            // Neighbour is an agent
            // TODO: Assert index, salt?
            const CrowdAgent& other = crowdInfo.agentBase[index];
            Assert(other.active == 1);
            // Ignore self and agents of lesser importance
            if (&other == &agent || other.params.priority < agentPriority)
                continue;

            otherPosition = other.npos;
            otherVelocity = other.vel;
            otherRadius = other.params.radius;
        }
        else if (type == kCrowdObstacle)
        {
            // Neighbour is obstacle
            // TODO: Assert index, salt?
            const Obstacle& obstacle = crowdInfo.obstacleBase[index];
            Assert(obstacle.type != kObstacleTypeUnused);

            otherPosition = obstacle.position;
            otherVelocity = obstacle.velocity;

            // Consider optimizing away 'sqrt' for axis-aligned case.
            otherRadius = Sqrt(Sqr(obstacle.worldExtents[0]) + Sqr(obstacle.worldExtents[2]));
        }
        else
        {
            ErrorStringMsg("CollectNeighbourObstacles. Unknown neighbour type %i", (int)type);
            continue;
        }

        // Skip obstacles behind.
        if (cullObstacleBehind)
        {
            // Cull obstacle that are far behind the agent.
            // The range ensures that in crowded situations we still
            // have enough neighbours to resolve collisions.
            Vector3f diff = otherPosition - agentPosition;
            float dist = Dot(cullDir, diff);
            if (dist < -(agentRadius + otherRadius))
                continue;
        }

        // Rank the neighbours based on how quickly they can collide with each other.
        // We assume that the agent is moving in "all directions" at maximum speed.
        // The idea with ranking is that we try to keep as conherent neighborhood as possible
        // but at the same time we should react to obstacles that are quickly moving towards us.
        const float dist = Distance(otherPosition, agentPosition);
        const float sep = dist - otherRadius - agentRadius;

        // Check how quickly the agents can reach each other assuming they can move into any direction.
        const float speed = agent.params.maxSpeed + Magnitude(otherVelocity);
        const float toi = sep / speed;

        if (toi > crowdInfo.avoidancePredictionTime)
            continue;

        neis[found].ref = otherRef;
        neis[found].dist = toi;
        found++;
    }

    const int nneis = std::min(found, (int)CrowdAgent::kMaxNeighbours);

    // Partial sort the found neighbours on the stack
    CrowdNeighbour sorted[CrowdAgent::kMaxNeighbours];
    std::partial_sort_copy(neis, neis + found, sorted, sorted + nneis);

    // Assign neighbours to agent
    memcpy(agent.neis, sorted, nneis * sizeof(CrowdNeighbour));
    agent.nneis = nneis;
}

// Scan the beginning of the current path for non-passable polygons
// if all polygons are passable : return true
// else : continue scanning looking for a next passable polygon
//   if no next passable polygon is found : keep the passable polygons - but fail if only one polygon is left.
//   else : path reconnection is attempted
//     if successful reconnection : accept reconnected path and return true
//     else : keep the passable polygons - but fail if only one polygon is left.

static bool ValidateOrReconnectPath(NavMeshQuery* query, CrowdAgent& ag, const QueryFilter& filter,
    NavMeshPolyRef* newRef, Vector3f* newPos)
{
    const int kMaxScanFirst = 8;
    const int kMaxScanNext = 20;
    const int kMaxReplanPath = 128;

    const NavMesh* navMesh = query->GetAttachedNavMesh();
    const NavMeshPolyRef* path = ag.corridor.GetPath();
    const int npath = ag.corridor.GetPathCount();
    Assert(npath > 0);

    Vector3f currentPos = ag.npos;
    Vector3f targetPos = ag.corridor.GetTarget();

    NavMeshPolyRef currentRef = path[0];

    *newRef = currentRef;
    *newPos = ag.npos;

    // Preserve the partial state of the path
    const bool wasPathPartial = ag.corridor.IsPathPartial();

    // Reuse same extents as when adding agent
    const float queryRange = ag.params.radius;
    const Vector3f ext(20.0f * queryRange, 15.0f * queryRange, 20.0f * queryRange);

    // Verify current position
    if (!filter.PassFilter(navMesh->GetPolyFlags(currentRef)))
    {
        // Remap current position
        query->FindNearestPoly(currentPos, ext, &filter, &currentRef, newPos);
        *newRef = currentRef;

        if (!currentRef)
            return false;

        ag.npos = *newPos;
    }

    AssertMsg(filter.PassFilter(navMesh->GetPolyFlags(currentRef)), "Expected NavMeshAgent current polygon to be valid and walkable");

    if (ag.state == kCrowdAgentState_Passive)
    {
        AssertFormatMsg(1 == npath, "A passive NavMeshAgent is expected to have no path. But this one has %i polygons", npath);
        ag.corridor.Reset(currentRef, *newPos);
        return true;
    }

    // Scan the 'kMaxScanFirst' polys for non-passable poly
    int nvalid = 0;
    int end = std::min(kMaxScanFirst, npath);
    for (; nvalid < end; ++nvalid)
    {
        if (!filter.PassFilter(navMesh->GetPolyFlags(path[nvalid])))
            break;
    }

    // Passes all polys encountered during scan
    if (nvalid == end)
        return true;

    // Scan the next 'kMaxScanNext' polys. Looking for the first passable poly reference
    int nextStart = nvalid + 1;
    end = std::min(nextStart + kMaxScanNext, npath);
    for (; nextStart < end; ++nextStart)
    {
        if (filter.PassFilter(navMesh->GetPolyFlags(path[nextStart])))
            break;
    }

    Vector3f endPos = targetPos;
    NavMeshPolyRef endRef = 0;

    // No passable polygons were found
    if (nextStart == end)
    {
        // Path end not found - accept for now if we still have some valid path
        if (end < npath)
            return nvalid > 1;

        // All references are invalid until the end of the path.
        // Remap end position to match end poly
        query->FindNearestPoly(targetPos, ext, &filter, &endRef, &endPos);

        // Path end not remapped - accept for now if we still have some valid path
        if (!endRef)
            return nvalid > 1;

        // The path end was succesfully remapped
        nextStart = npath - 1;
    }
    else
    {
        endRef = path[nextStart];
    }

    Assert(filter.PassFilter(navMesh->GetPolyFlags(endRef)));

    NavMeshStatus status;
    NavMeshPolyRef res[kMaxReplanPath];
    int nres = 0;

    status = query->InitSlicedFindPath(currentRef, endRef, currentPos, endPos, &filter);

    if (!NavMeshStatusFailed(status))
        status = query->UpdateSlicedFindPath(kMaxReplanPath, NULL);

    if (!NavMeshStatusFailed(status))
        status = query->FinalizeSlicedFindPath(&nres);

    if (NavMeshStatusDetail(status, kNavMeshPartialResult))
        return false;

    if (!NavMeshStatusFailed(status))
        status = query->GetPath(res, &nres, kMaxReplanPath);

    if (NavMeshStatusFailed(status))
        return false;

    AssertMsg(nres > 0, "Expected replacement path");

    // Allocate temporary path to join new beginning and old end
    const int nrem = npath - 1 - nextStart;
    int npath2 = nres + nrem;
    dynamic_array<NavMeshPolyRef> path2(kMemTempAlloc);
    path2.resize_uninitialized(npath2);

    // Copy in valid start part of the path
    memcpy(&path2[0], res, nres * sizeof(NavMeshPolyRef));

    // Copy in the remaining part of the path. It could be valid or invalid
    if (nrem)
    {
        memcpy(&path2[nres], path + nextStart + 1, nrem * sizeof(NavMeshPolyRef));
    }

    if (npath2 < kMaxScanFirst && (ag.params.updateFlags & kCrowdAutoRepath))
    {
        // If the last poly in the path has changed we trigger a path replan
        const NavMeshPolyRef lastPolyRef = path2[npath2 - 1];
        if (ag.corridor.GetLastPoly() != lastPolyRef)
            ag.repath = true;
    }

    ag.corridor.SetCorridor(endPos, query, path2.begin(), npath2, wasPathPartial);

    return true;
}

// Heaviside step function for integers 'i2' relative to 'i1'
// using half-maximum convention.
static inline float StepH(int i1, int i2)
{
    if (i1 == i2)
        return 0.5f;
    return (i2 > i1) ? 1.0f : 0.0f;
}

static float GetDistanceToGoal(const CrowdAgent& ag, const float range)
{
    if (!ag.ncorners)
        return std::min(Distance(ag.npos, ag.corridor.GetTarget()), range);

    if (0 != (ag.cornerFlags[ag.ncorners - 1] & kStraightPathEnd))
        return std::min(Distance(ag.npos, ag.cornerVerts[(ag.ncorners - 1)]), range);

    return range;
}

static inline Vector3f LimitMoveTowards(const Vector3f& src, const Vector3f& target, float maxMove)
{
    Vector3f delta = target - src;
    const float deltaSqr = SqrMagnitude(delta);
    if (deltaSqr <= maxMove * maxMove)
    {
        return target;
    }
    return src + delta * (maxMove / Sqrt(deltaSqr));
}

static inline Vector3f SafeDirection(const Vector3f& sourcePosition, const Vector3f& targetPosition)
{
    Vector3f dir = targetPosition - sourcePosition;

    const float sqrLen = SqrMagnitude(dir);
    if (sqrLen == 0.0f)
        return dir;

    const float norm = 1.0f / Sqrt(sqrLen);
    return dir * norm;
}

static bool TriggerOffmeshConnection(const CrowdAgent& ag, float dt)
{
    if (!ag.ncorners)
        return false;

    if ((ag.cornerFlags[ag.ncorners - 1] & kStraightPathOffMeshConnection) == 0)
        return false;

    // Agent - connection proximity. In terms of agent radius
    const float triggerRadiusSq = Sqr(2.25f * ag.params.radius);
    const float distSq = SqrDistance(ag.npos, ag.cornerVerts[(ag.ncorners - 1)]);
    if (distSq < triggerRadiusSq)
        return true;

    // Agent move delta vs distance to connection
    const float moveSq = dt * dt * SqrMagnitude(ag.vel);
    if (distSq < moveSq)
        return true;

    return false;
}

static Vector3f CalcStraightSteerDirection(const CrowdAgent& ag)
{
    if (ag.state != kCrowdAgentState_Walking)
    {
        return Vector3f(0.0f, 0.0f, 0.0f);
    }
    else if (ag.ncorners)
    {
        return SafeDirection(ag.npos, ag.cornerVerts[0]);
    }
    else if (ag.corridor.GetPathCount() > 0)
    {
        return SafeDirection(ag.npos, ag.corridor.GetTarget());
    }
    else
    {
        return Vector3f(0.0f, 0.0f, 0.0f);
    }
}

static inline float Between(const float t, const float t0, const float t1)
{
    const float dt = t1 - t0;
    if (dt == 0.0f)
        return 1.0f;
    return (t - t0) / dt;
}

static void UpdateProximityCollectMultiThreaded(const UpdateCrowdInfo& range, const ReadonlyCrowdInfo& crowdInfo, NavMeshQuery* query)
{
    PROFILER_AUTO(gNavMeshProximityCollect, NULL);

    // Get nearby navmesh segments and agents to collide with.
    const int nagents = range.updateAgentCount;
    for (int i = 0; i < nagents; ++i)
    {
        CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
        Assert(ag.active == 1);
        if (ag.state == kCrowdAgentState_OffMesh || (ag.params.updateFlags & kCrowdObstacleAvoidance) == 0)
        {
            ag.nneis = 0;
            continue;
        }
        CollectNeighbourObstacles(ag, crowdInfo);
    }

    for (int i = 0; i < nagents; ++i)
    {
        CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
        Assert(ag.active == 1);
        if (ag.state == kCrowdAgentState_OffMesh || (ag.params.updateFlags & kCrowdObstacleAvoidance) == 0)
            continue;

        // TODO: This logic needs more testing.
        // - the idea is to skip avoiding the wall segments when approach end of path or an offmesh link
        // - avoiding wall segments in such cases cause the agent to slow down, which is not desired
        // - we should only avoid close to the end of the path, the previous logic here skipping avoidance
        //   too much, which caused the agent to run against walls
        // Old logic:
        //      if (ag.corridor.GetLastPoly () == ag.corridor.GetFirstPoly ()
        //          || (ag.ncorners && (ag.cornerFlags[0] & (kStraightPathEnd|kStraightPathOffMeshConnection)) != 0))


        // TODO: this 0.5 scaling factor is quite arbitrary, just trying to shrink the area effect of skipping walls.
        const float agentRange = ag.params.radius + crowdInfo.avoidancePredictionTime * ag.params.maxSpeed * 0.5f;

        // Ignore boundaries when approaching offmeshlink or path end.
        Vector3f nextCornerPos;
        bool nextCornerIsEnd = false;
        if (ag.ncorners > 0)
        {
            nextCornerIsEnd = (ag.cornerFlags[0] & (kStraightPathEnd | kStraightPathOffMeshConnection)) != 0;
            nextCornerPos = ag.cornerVerts[0];
        }
        else
        {
            nextCornerIsEnd = true;
            nextCornerPos = ag.corridor.GetTarget();
        }
        if (nextCornerIsEnd && Distance(ag.npos, nextCornerPos) < agentRange)
        {
            ag.boundary.Reset();
            continue;
        }

        // Only update the collision boundary when moving to next polygon or after small distance has been traveled.
        const float updateThr = agentRange * 0.25f;
        if (ag.boundary.GetCenterRef() != ag.corridor.GetFirstPoly() || SqrDistance(ag.npos, ag.boundary.GetCenter()) > Sqr(updateThr))
        {
            const QueryFilter& filter = crowdInfo.filterBase[range.updateAgentIDs[i]];
            ag.boundary.Update(ag.corridor.GetFirstPoly(), ag.npos, agentRange, query, &filter);
        }
    }
}

static void UpdateValidatePathMultithreaded(const UpdateCrowdInfo& range, const ReadonlyCrowdInfo& crowdInfo, NavMeshQuery* query)
{
    PROFILER_AUTO(gNavMeshValidatePath, NULL);

    const int nagents = range.updateAgentCount;

    for (int i = 0; i < nagents; ++i)
    {
        const int agentIndex = range.updateAgentIDs[i];
        CrowdAgent& ag = range.agentBase[agentIndex];
        Assert(ag.active == 1);

        if (ag.state == kCrowdAgentState_OffMesh)
            continue;

        const QueryFilter& filter = crowdInfo.filterBase[agentIndex];
        Vector3f newPos;
        NavMeshPolyRef newRef = 0;
        if (!ValidateOrReconnectPath(query, ag, filter, &newRef, &newPos))
        {
            if (newRef == 0)
                ag.corridor.Invalidate();
            else
                ag.corridor.Reset(newRef, newPos);

            ag.repath = true;
            ag.boundary.Reset();
            ag.ncorners = 0;
            ag.nneis = 0;
            ag.pendingRequest = false;
            ag.reqPoly = 0;
            ag.state = kCrowdAgentState_Passive;
            ag.remainingDistance = -1.0f;
            ag.dvel.SetZero();
        }
    }
}

static void UpdateCornersMultithreaded(const UpdateCrowdInfo& range, const ReadonlyCrowdInfo& crowdInfo, NavMeshQuery* query)
{
    PROFILER_AUTO(gNavMeshCorners, NULL);

    const int nagents = range.updateAgentCount;

    for (int i = 0; i < nagents; ++i)
    {
        CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
        Assert(ag.active == 1);

        if (ag.state != kCrowdAgentState_Walking)
            continue;

        const QueryFilter& filter = crowdInfo.filterBase[range.updateAgentIDs[i]];

        // Find corners for steering

        // Internally the corner finding method includes the current agent
        // position and also strips away positions 'close to' the beginning.
        // This means that querying for a least 3 corners ('maxCorners') is
        // necessary to obtain one corner safely when an agent is 'close to'
        // the first corner on its path.
        NavMeshStatus status = ag.corridor.FindCorners((Vector3f*)ag.cornerVerts, ag.cornerFlags, ag.cornerPolys, &ag.ncorners,
                CrowdAgent::kMaxCorners, query);

        ag.remainingDistance = CalculateKnownPathLength(ag.npos, ag.ncorners, ag.cornerFlags, ag.cornerVerts, &ag.corridor);

        if (ag.ncorners == 0)
        {
            continue;
        }

        if (ag.ncorners == 1 && NavMeshStatusDetail(status, kNavMeshPartialResult))
        {
            ag.corridor.SetPathValid(false);
            continue;
        }

        // Check to see if the corner after the next corner is directly visible, and short cut to there.
        const float MIN_DISTANCE_SQR = Sqr(0.01f);
        const Vector3f& corridorStartPos = ag.corridor.GetPos();
        Vector3f target;
        if (ag.ncorners == 1)
        {
            // skip if next corner too close
            target = ag.cornerVerts[0];
            if (SqrDistance(target, corridorStartPos) < MIN_DISTANCE_SQR)
                continue;
        }
        else
        {
            // skip if next corner too close
            target = ag.cornerVerts[1];
            if (SqrDistance(target, corridorStartPos) < MIN_DISTANCE_SQR)
                continue;

            // skip if short-cut is obstructed
            NavMeshRaycastResult result;
            const NavMeshPolyRef corridorStartPoly = ag.corridor.GetFirstPoly();
            query->Raycast(corridorStartPoly, corridorStartPos, target, &filter, &result, NULL, NULL, 0);
            const float costShortCut = result.totalCost;
            if (costShortCut < 1.0f)
                continue;

            // skip if short-cut is more expensive
            query->Raycast(corridorStartPoly, corridorStartPos, ag.cornerVerts[0], &filter, &result, NULL, NULL, 0);
            const float costLeg1 = result.totalCost;
            query->Raycast(ag.cornerPolys[0], ag.cornerVerts[0], target, &filter, &result, NULL, NULL, 0);
            const float costLeg2 = result.totalCost;
            if (costShortCut >= costLeg1 + costLeg2)
                continue;
        }

        ag.corridor.OptimizePathVisibility(target, query, &filter);
    }
}

static void UpdateMoveRequestsSingleThreaded(const UpdateCrowdInfo& range, const ReadonlyCrowdInfo& crowdInfo, CrowdManager* crowd, float dt)
{
    const int nagents = range.updateAgentCount;
    Assert(nagents == crowdInfo.activeAgentCount);

    for (int i = 0; i < nagents; ++i)
    {
        CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
        Assert(ag.active == 1);
        if (ag.repath)
        {
            const CrowdRef agentRef = CrowdManager::EncodeCrowdId(ag.salt, (int)(&ag - range.agentBase), kCrowdAgent);
            crowd->RequestMoveTarget(agentRef, ag.reqWorldPos);
            ag.repath = false;
        }
    }

    // Update async move requests (pathfinding)
    crowd->UpdateMoveRequest();

    // Optimize path topology.
    crowd->UpdateTopologyOptimization(dt);

    // Insert agents into proximity grid
    crowd->UpdateProximityGrid();
}

/// Occupied references are central [crowd->OccupyRef ()]
/// Thus this can't be multithreaded yet until we fix that.
static void UpdateEnterOffMeshSingleThreaded(const UpdateCrowdInfo& range, const ReadonlyCrowdInfo& crowdInfo, CrowdManager* crowd, float dt)
{
    PROFILER_AUTO(gNavMeshOffMeshTrigger, NULL)

    const int nagents = range.updateAgentCount;
    Assert(nagents == crowdInfo.activeAgentCount);

    // Trigger off-mesh connections (depends on corners).
    for (int i = 0; i < nagents; ++i)
    {
        CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
        Assert(ag.active == 1);

        if (ag.state == kCrowdAgentState_OffMesh)
            continue;

        if (TriggerOffmeshConnection(ag, dt))
        {
            ag.state = kCrowdAgentState_Waiting_OffMesh;
        }
        else
        {
            if (ag.state == kCrowdAgentState_Waiting_OffMesh) // Was waiting, got pushed off. Walk back.
            {
                ag.state = kCrowdAgentState_Walking;
            }
        }
        if (ag.state == kCrowdAgentState_Waiting_OffMesh)
        {
            // Prepare to off-mesh connection.
            const NavMeshPolyRef offMeshLinkPolyRef = ag.cornerPolys[ag.ncorners - 1];
            if (crowd->IsRefOccupied(offMeshLinkPolyRef))
                continue;

            // Adjust the path over the off-mesh connection.
            CrowdAgentAnimation& anim = range.animBase[range.updateAgentIDs[i]];
            Vector3f linkStart, linkEnd;
            NavMeshQuery* query = crowd->GetNavMeshQuery();

            if (!ag.corridor.MoveOverOffmeshConnection(offMeshLinkPolyRef, ag.npos, linkStart, linkEnd, query))
            {
                ag.corridor.SetPathValid(false);
                continue;
            }

            // We use the result from corner calculation for starting point here instead of 'linkStart'
            // it's more flexible for wide links
            anim.startPos = ag.cornerVerts[ag.ncorners - 1];

            // TODO: for optimal movement across wide links we should acquire an additional corner vertex
            // i.e. not terminate the path corners on entering link
            // for now we move towards the midpoint on wide links
            anim.endPos = linkEnd;

            crowd->OccupyRef(offMeshLinkPolyRef);
            anim.initPos = ag.npos;
            anim.polyRef = offMeshLinkPolyRef;
            anim.s = 0.0f;
            anim.smax = Distance(anim.startPos, anim.endPos);

            ag.state = kCrowdAgentState_OffMesh;
            ag.ncorners = 0;
            ag.nneis = 0;
        }
    }
}

static void UpdateSteeringMultithreaded(const UpdateCrowdInfo& range, const ReadonlyCrowdInfo& crowdInfo, const float dt)
{
    PROFILER_AUTO(gNavMeshSteering, NULL);

    // Calculate steering.
    const int nagents = range.updateAgentCount;
    for (int i = 0; i < nagents; ++i)
    {
        CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
        Assert(ag.active == 1);
        ag.braking = false;

        if (ag.state != kCrowdAgentState_Walking)
        {
            ag.desiredSpeed = 0;
            ag.dvel.SetZero();
            continue;
        }

        // Calculate steering direction.
        Vector3f dvel = CalcStraightSteerDirection(ag);

        // Calculate speed scale, which tells the agent to slowdown at the end of the path.
        if (ag.stopExplicit || ag.state == kCrowdAgentState_Waiting_OffMesh)
            ag.desiredSpeed = 0;
        else
            ag.desiredSpeed = ag.params.maxSpeed;

        if (ag.remainingDistance < ag.params.stoppingDistance && (ag.ncorners > 0 || ag.corridor.GetPathCount() > 1))
        {
            Assert(ag.remainingDistance >= 0.0f);
            ag.desiredSpeed = 0;
        }


        if (ag.params.updateFlags & kCrowdAutoBraking)
        {
            const float slowDownRadius = 2 * ag.params.radius;
            const float dist = GetDistanceToGoal(ag, slowDownRadius);

            const float speedSqr = SqrMagnitude(ag.vel);
            const float speed = Sqrt(speedSqr);
            const float ds = speed * dt;
            if ((dist < ds + 1e-4f && dist < slowDownRadius) || (slowDownRadius < ds && GetDistanceToGoal(ag, ds) < ds))
            {
                // Avoid overshooting (high speed or low frame-rate)
                ag.desiredSpeed = 0;
                ag.corridor.SetToEnd();
                ag.npos = ag.corridor.GetPos();

                ag.vel.SetZero();
                ag.boundary.Reset();
                ag.braking = true;
            }
            else if (dist < slowDownRadius && dist * ag.params.maxSpeed < slowDownRadius * speed)
            {
                // if inside slowdown range and outside speed envelope
                // Lower the speed linearly over the remaining distance
                // such that the speed is zero at the end position.

                Assert(dist > 0.0f);  // should be handled in the above if

                ag.desiredSpeed = speed - dt * speedSqr / (2.0f * dist);
                ag.boundary.Reset();
                ag.braking = true;
            }
        }

        dvel = dvel * ag.desiredSpeed;

        // Separation
        {
            const float separationDist = ag.params.radius * CROWD_SEPARATION_SCALE;
            Assert(separationDist > 0.0f);
            const float invSeparationDist = 1.0f / separationDist;

            float w = 0;
            Vector3f disp(0.0f, 0.0f, 0.0f);

            const int nneis = ag.nneis;
            for (int j = 0; j < nneis; ++j)
            {
                const CrowdRef neiRef = ag.neis[j].ref;
                if (CrowdManager::GetCrowdRefType(neiRef) != kCrowdAgent)
                    continue;
                const int otherIndex = CrowdManager::GetCrowdRefIndex(neiRef);

                const CrowdAgent& nei = crowdInfo.agentBase[otherIndex];
                Assert(nei.params.priority >= ag.params.priority);

                Vector3f diff = ag.npos - nei.npos;

                const float distSqr = SqrMagnitude(diff);
                if (distSqr < 0.00001f)
                    continue;
                if (distSqr > Sqr(separationDist))
                    continue;
                const float dist = Sqrt(distSqr);
                const float weight = CROWD_SEPARATION_WEIGHT * (1.0f - Sqr(dist * invSeparationDist));
                const float pri = 2.0f * StepH(ag.params.priority, nei.params.priority);

                disp = disp + diff * (pri * weight / dist);

                w += 1.0f;
            }

            if (w > 0.0001f)
            {
                // Adjust desired velocity.
                dvel = dvel + (disp * 1.0f / w);
                // Clamp desired velocity to desired speed.
                const float speedSqr = SqrMagnitude(dvel);
                const float desiredSqr = Sqr(ag.desiredSpeed);
                if (speedSqr > desiredSqr)
                    dvel = dvel * (desiredSqr / speedSqr);
            }
        }

        // Set the desired velocity.
        ag.dvel = dvel;
    }
}

static bool HasNeighbor(const CrowdAgent& ag, const CrowdRef ref)
{
    for (int i = 0; i < ag.nneis; i++)
        if (ag.neis[i].ref == ref)
            return true;
    return false;
}

static void UpdateAvoidanceMultiThreaded(const UpdateCrowdInfo& range, const ReadonlyCrowdInfo& crowdInfo
    , ObstacleAvoidanceQuery& obstacleQuery, const NavMesh* navmesh)
{
    PROFILER_AUTO(gNavMeshAvoidance, NULL);

    // Velocity planning.
    const int nagents = range.updateAgentCount;
    for (int i = 0; i < nagents; ++i)
    {
        CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
        Assert(ag.active == 1);
        const CrowdRef agentRef = CrowdManager::EncodeCrowdId(ag.salt, (int)(&ag - range.agentBase), kCrowdAgent);

        if (ag.state == kCrowdAgentState_OffMesh)
            continue;

        if ((ag.params.updateFlags & kCrowdObstacleAvoidance) == 0)
        {
            // If not using velocity planning, new velocity is directly the desired velocity.
            ag.nvel = ag.dvel;
            continue;
        }

        const NavMeshTile* tile = navmesh->GetTileByRef(ag.corridor.GetFirstPoly());
        const Quaternionf rot = tile ? tile->rotation : Quaternionf::identity();

        obstacleQuery.Reset(ag.npos, rot, ag.params.radius, ag.params.height);

        // Add neighbours as obstacles.
        const int nneis = ag.nneis;
        for (int j = 0; j < nneis; ++j)
        {
            const CrowdRef otherRef = ag.neis[j].ref;
            const int otherIndex = CrowdManager::GetCrowdRefIndex(otherRef);
            const int otherType = CrowdManager::GetCrowdRefType(otherRef);

            if (otherType == kCrowdAgent)
            {
                // Neighbour is an agent
                const CrowdAgent& nei = crowdInfo.agentBase[otherIndex];
                Assert(nei.active == 1);
                float weight = StepH(ag.params.priority, nei.params.priority);
                // If the neighbour is not avoiding the agent, make the agent avoid fully.
                if (!HasNeighbor(nei, agentRef))
                    weight = 1.0f; // Avoid completely, no reciprocality.

                // Ignore that links can have rotation - agents on links don't avoid.
                const NavMeshTile* otherTile = navmesh->GetTileByRef(nei.corridor.GetFirstPoly());
                const Quaternionf otherRot = otherTile ? otherTile->rotation : Quaternionf::identity();

                if (CompareApproximately(rot, otherRot))
                {
                    // When the agents are moving in same plane we can reduce the collision shape to a circle.
                    // Ignore if agents don't overlap along the plane normal - e.g. moving on different floors.
                    Vector3f otherWorldUpAxis = RotateVectorByQuat(otherRot, Vector3f(0, 1, 0));
                    Vector3f delta = nei.npos - ag.npos;
                    float dist = Dot(delta, otherWorldUpAxis);
                    if (dist > ag.params.height || dist < -nei.params.height)
                        continue;
                    obstacleQuery.AddCircle(nei.npos, nei.params.radius, weight, nei.vel, nei.dvel);
                }
                else
                {
                    // When agents are moving on surfaces with diffent orientations treat others as regular obstacles.
                    float capHalfHeight = 0.5f * nei.params.height;
                    Vector3f capWorldUpAxis = RotateVectorByQuat(otherRot, Vector3f(0, 1, 0));
                    Vector3f capExtents(nei.params.radius, capHalfHeight, nei.params.radius);
                    Vector3f capCenter = nei.npos + capWorldUpAxis * capHalfHeight;
                    obstacleQuery.AddCapsule(capCenter, capExtents, capWorldUpAxis, nei.vel);
                }
            }
            else if (otherType == kCrowdObstacle)
            {
                // Neighbour is obstacle
                const Obstacle& obstacle = crowdInfo.obstacleBase[otherIndex];
                Assert(obstacle.type != kObstacleTypeUnused);

                if (obstacle.type == kObstacleTypeCylinder)
                {
                    obstacleQuery.AddCapsule(obstacle.position, obstacle.extents, obstacle.yAxis,
                        obstacle.velocity);
                }
                else if (obstacle.type == kObstacleTypeOBB)
                {
                    obstacleQuery.AddBox(obstacle.position, obstacle.extents,
                        obstacle.xAxis, obstacle.yAxis, obstacle.zAxis,
                        obstacle.velocity);
                }
            }
        }

        // Append neighbour segments as obstacles.
        for (int j = 0; j < ag.boundary.GetSegmentCount(); ++j)
        {
            obstacleQuery.AddBoundarySegment(ag.boundary.GetSegmentStart(j), ag.boundary.GetSegmentEnd(j));
        }

        // Sample new safe velocity.
        const ObstacleAvoidanceParams* params = &crowdInfo.obstacleAvoidanceParams[ag.params.obstacleAvoidanceType];
        CrowdAgentDebugInfo* debugInfo = NULL;
#if UNITY_EDITOR
        debugInfo = ag.debugInfo;
#endif
        Vector3f result;
        obstacleQuery.SampleVelocityAdaptive(result, ag.vel, ag.dvel, ag.params.radius, ag.params.height,
            ag.desiredSpeed, crowdInfo.avoidancePredictionTime, params, debugInfo);
        ag.nvel = result;
    }
}

static void UpdateIntegrateMultithreaded(const UpdateCrowdInfo& range, const float dt)
{
    PROFILER_AUTO(gNavMeshIntegrate, NULL);
    // Integrate.
    const int nagents = range.updateAgentCount;
    for (int i = 0; i < nagents; ++i)
    {
        CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
        Assert(ag.active == 1);
        // store old position - for actual velocity calculation
        ag.avel = ag.npos;

        if (ag.state == kCrowdAgentState_OffMesh)
            continue;

        // update position
        ag.npos = ag.npos + ag.vel * dt;

        if (ag.braking)
        {
            if (SqrMagnitude(ag.dvel) > SqrMagnitude(ag.vel))
            {
                // if speeding up while in braking mode
                // limit dvel by acceleration.
                const float maxDelta = ag.params.maxAcceleration * dt;
                ag.vel = LimitMoveTowards(ag.vel, ag.dvel, maxDelta);
                ag.dvel = ag.vel;
                ag.nvel = ag.vel;
            }
            else
            {
                // otherwise accept dvel.
                ag.nvel = ag.dvel;
                ag.vel = ag.dvel;
            }
        }
        else
        {
            const float maxDelta = ag.params.maxAcceleration * dt;
            ag.vel = LimitMoveTowards(ag.vel, ag.nvel, maxDelta);
        }
    }
}

// Make parallel by moving iter-loop out of here
static void UpdateCollisionSingleThreaded(const UpdateCrowdInfo& range, const ReadonlyCrowdInfo& crowdInfo, const NavMesh* navmesh)
{
    PROFILER_AUTO(gNavMeshCollision, NULL);

    const int nagents = range.updateAgentCount;
    Assert(nagents == crowdInfo.activeAgentCount);

    // Handle collisions.
    static const float COLLISION_RESOLVE_FACTOR = 0.7f;

    for (int iter = 0; iter < 4; ++iter)
    {
        for (int i = 0; i < nagents; ++i)
        {
            CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
            Assert(ag.active == 1);
            const int idx0 = &ag - crowdInfo.agentBase;

            if (ag.state == kCrowdAgentState_OffMesh)
                continue;

            ag.disp.SetZero();

            float w = 0.0f;

            const int nneis = ag.nneis;
            if (!nneis)
                continue;

            const NavMeshTile* tile = navmesh->GetTileByRef(ag.corridor.GetFirstPoly());
            const Quaternionf rot = tile ? Inverse(tile->rotation) : Quaternionf::identity();

            for (int j = 0; j < nneis; ++j)
            {
                const int otherIndex = CrowdManager::GetCrowdRefIndex(ag.neis[j].ref);
                const int otherType = CrowdManager::GetCrowdRefType(ag.neis[j].ref);

                if (otherType == kCrowdAgent)
                {
                    // Neighbour is an agent
                    const CrowdAgent& nei = crowdInfo.agentBase[otherIndex];
                    Assert(nei.active == 1);

                    const float obstacleRadius = nei.params.radius;
                    const int idx1 = &nei - crowdInfo.agentBase;

                    Vector3f diff = ag.npos - nei.npos;

                    float dist = SqrMagnitude(diff);
                    float radiusSum = ag.params.radius + obstacleRadius;
                    if (dist > Sqr(radiusSum))
                        continue;
                    dist = Sqrt(dist);
                    float pen = radiusSum - dist;
                    if (dist < 0.0001f)
                    {
                        // Agents on top of each other, try to choose diverging separation directions.
                        if (idx0 > idx1)
                            diff  = Vector3f(-ag.dvel[2], 0, ag.dvel[0]);
                        else
                            diff = Vector3f(ag.dvel[2], 0, -ag.dvel[0]);
                        pen = 0.01f;
                    }
                    else
                    {
                        Assert(nei.params.priority >= ag.params.priority);
                        const float pri = StepH(ag.params.priority, nei.params.priority);
                        pen = pri * pen * COLLISION_RESOLVE_FACTOR / dist;
                    }

                    ag.disp = ag.disp + diff * pen;
                    w += 1.0f;
                }
                else if (otherType == kCrowdObstacle)
                {
                    // Neighbour is obstacle
                    const Obstacle& obstacle = crowdInfo.obstacleBase[otherIndex];
                    Assert(obstacle.type != kObstacleTypeUnused);

                    Vector3f xAxis = RotateVectorByQuat(rot, obstacle.xAxis);
                    Vector3f yAxis = RotateVectorByQuat(rot, obstacle.yAxis);
                    Vector3f zAxis = RotateVectorByQuat(rot, obstacle.zAxis);
                    Vector3f pos = RotateVectorByQuat(rot, obstacle.position - ag.npos);

                    const Vector3f zero(0.0f, 0.0f, 0.0f);

                    float penetration = 0.0f;

                    if (obstacle.type == kObstacleTypeCylinder)
                    {
                        AlignedCylinderOverlapsOrientedCapsule(&penetration, pos, obstacle.extents, yAxis, zero, ag.params.radius, 0.0f, ag.params.height);
                    }
                    else if (obstacle.type == kObstacleTypeOBB)
                    {
                        Vector3f boxCorners[8];
                        CalculateOrientedBoxCorners(boxCorners, pos, obstacle.extents, xAxis, yAxis, zAxis);
                        AlignedCylinderOverlapsOrientedBox(&penetration, boxCorners, zero, ag.params.radius, 0.0f, ag.params.height);
                    }

                    if (penetration > 0.0f)
                    {
                        Vector3f dir = -pos;
                        const float dist = Magnitude(dir);

                        // use x-axis as normal in case objects are coincident
                        Vector3f normal = Vector3f(1.0f, 0.0f, 0.0f);
                        if (dist > 0.0001f)
                            normal = dir * (1.0f / dist);

                        ag.disp = ag.disp + normal * (COLLISION_RESOLVE_FACTOR * penetration);
                        w += 1.0f;
                    }
                }
            }

            if (w > 0.0001f)
            {
                ag.disp = ag.disp * (1.0f / w);
            }
        }

        for (int i = 0; i < nagents; ++i)
        {
            CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
            Assert(ag.active == 1);
            if (ag.state == kCrowdAgentState_OffMesh)
                continue;
            ag.npos = ag.npos + ag.disp;
        }
    }
}

static void UpdateMoveOffMeshSingleThreaded(const UpdateCrowdInfo& range, const ReadonlyCrowdInfo& crowdInfo, CrowdManager* crowd, const float dt)
{
    PROFILER_AUTO(gNavMeshOffMeshMovement, NULL);

    const int nagents = range.updateAgentCount;
    Assert(nagents == crowdInfo.activeAgentCount);

    for (int i = 0; i < nagents; ++i)
    {
        CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
        Assert(ag.active == 1);
        if (ag.stopExplicit)
            continue;

        CrowdAgentAnimation& anim = range.animBase[range.updateAgentIDs[i]];
        if (anim.polyRef == 0 || (ag.params.updateFlags & kCrowdAutoTraverseOffMeshLink) == 0)
            continue;

        Assert(ag.state == kCrowdAgentState_OffMesh);

        anim.s += 2.0f * ag.params.maxSpeed * dt;

        // Update position
        const float sa = std::min(ag.params.radius * 2.25f, anim.smax * 0.15f);
        const float sb = anim.smax;

        Vector3f moveDir;
        if (anim.s < sa)
        {
            // Move to animation start position.
            const float u = Between(anim.s, 0.0f, sa);
            ag.npos = Lerp(anim.initPos, anim.startPos, u);
            moveDir = SafeDirection(anim.initPos, anim.startPos);
        }
        else if (anim.s < sb)
        {
            // Animate over the link.
            const float u = Between(anim.s, sa, sb);
            ag.npos = Lerp(anim.startPos, anim.endPos, u);
            moveDir = SafeDirection(anim.startPos, anim.endPos);
        }
        else
        {
            // Finalise.
            NavMeshQuery* query = crowd->GetNavMeshQuery();
            const QueryFilter& filter = crowdInfo.filterBase[range.updateAgentIDs[i]];

            crowd->CompleteOffMeshLink(&ag, false);

            // The lerp can potentially overshoot, and we wish to keep the speed consistent.
            // Handle the movement beyond the off-mesh link as movement along the navmesh,
            // constrain the final position on navmesh.
            const float u = Between(anim.s, sa, sb);
            ag.npos = Lerp(anim.startPos, anim.endPos, u);
            ag.corridor.MovePosition(ag.npos, query, &filter);
            ag.npos = ag.corridor.GetPos();

            moveDir = SafeDirection(anim.endPos, ag.npos);
        }
        // Update velocity to match movement along the link.
        moveDir = moveDir * ag.params.maxSpeed;
        ag.vel = moveDir;
        ag.nvel = moveDir;
    }
}

static void UpdateRepathTriggerMultiThreaded(const UpdateCrowdInfo& range, const ReadonlyCrowdInfo& crowdInfo, NavMeshQuery* query)
{
    PROFILER_AUTO(gNavMeshRepathTrigger, NULL);

    const int nagents = range.updateAgentCount;

    for (int i = 0; i < nagents; ++i)
    {
        CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
        Assert(ag.active == 1);

        if (ag.state == kCrowdAgentState_OffMesh)
            continue;

        if (ag.requested && (ag.params.updateFlags & kCrowdAutoRepath))
        {
            const PathCorridor& cor = ag.corridor;

            if (!cor.IsPathValid())
            {
                ag.repath = true;
            }
            else if (cor.IsPathPartial() && cor.IsPathStale())
            {
                if (ag.ncorners && (ag.cornerFlags[0] & kStraightPathEnd))
                {
                    const float distSq = SqrDistance(ag.npos, ag.cornerVerts[0]);
                    const float triggerRadiusSq = Sqr(ag.params.radius);
                    if (distSq < triggerRadiusSq)
                        ag.repath = true;
                }
            }
        }
    }
}

static void UpdateHeightMultiThreaded(const UpdateCrowdInfo& range, const ReadonlyCrowdInfo& crowdInfo, const NavMesh* navmesh)
{
    // No need to batch-process agents if height data isn't present
    if (!crowdInfo.heightMeshQuery->HasHeightData())
        return;

    PROFILER_AUTO(gNavMeshHeightMesh, NULL);

    const int nagents = range.updateAgentCount;

    for (int i = 0; i < nagents; ++i)
    {
        CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
        Assert(ag.active == 1);
        if (ag.state != kCrowdAgentState_OffMesh)
            crowdInfo.heightMeshQuery->SetPositionHeight(&ag.npos);
    }
}

static void UpdateAgentVelocityMultiThreaded(const UpdateCrowdInfo& range, const float dt)
{
    Assert(dt > 0);
    const float dt1 = 1.0f / dt;
    const int nagents = range.updateAgentCount;
    for (int i = 0; i < nagents; ++i)
    {
        CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
        Assert(ag.active == 1);
        ag.avel = ag.npos - ag.avel;
        ag.avel = ag.avel * dt1;
    }
}

static void UpdateMoveMultiThreaded(const UpdateCrowdInfo& range, const ReadonlyCrowdInfo& crowdInfo, NavMeshQuery* query)
{
    PROFILER_AUTO(gNavMeshMovement, NULL);

    const int nagents = range.updateAgentCount;

    for (int i = 0; i < nagents; ++i)
    {
        CrowdAgent& ag = range.agentBase[range.updateAgentIDs[i]];
        Assert(ag.active == 1);
        if (ag.state == kCrowdAgentState_OffMesh)
        {
            ag.remainingDistance = std::numeric_limits<float>::infinity();
            continue;
        }

        const QueryFilter& filter = crowdInfo.filterBase[range.updateAgentIDs[i]];

        // Move along navmesh.
        ag.corridor.MovePosition(ag.npos, query, &filter);

        // Get valid constrained position back.
        ag.npos = ag.corridor.GetPos();

        // If passive we reset the corridor
        // this prevents the agent from builing up a path by being pushed around by e.g. collision
        if (ag.state == kCrowdAgentState_Passive)
            ag.corridor.Reset(ag.corridor.GetFirstPoly(), ag.corridor.GetPos());

        ag.corridor.FindCorners((Vector3f*)ag.cornerVerts, ag.cornerFlags, ag.cornerPolys, &ag.ncorners,
            CrowdAgent::kMaxCorners, query);

        ag.remainingDistance = CalculateKnownPathLength(ag.npos, ag.ncorners, ag.cornerFlags, ag.cornerVerts, &ag.corridor);
    }
}

// Calculate the XZ AABB spanned by a moving AABB.
void CalculateRangeBounds(float time, float bounds[4], const Vector3f& pos, const Vector3f& vel, const Vector3f& extents)
{
    float xfut = pos.x + vel.x * time;
    float zfut = pos.z + vel.z * time;
    bounds[0] = std::min(pos.x, xfut) - extents.x;
    bounds[1] = std::min(pos.z, zfut) - extents.z;
    bounds[2] = std::max(pos.x, xfut) + extents.x;
    bounds[3] = std::max(pos.z, zfut) + extents.z;
}

float CalculateKnownPathLength(const Vector3f& startPos, int ncorners, const unsigned char* cornerFlags, const Vector3f* cornerVerts, const PathCorridor* corridor)
{
    Assert(corridor);
    if (ncorners)
    {
        Assert(cornerFlags);
        Assert(cornerVerts);
        const int lastCorner = ncorners - 1;
        if (cornerFlags[lastCorner] & kStraightPathEnd)
        {
            float totalLength = 0.0f;
            Vector3f pos = startPos;
            for (int i = 0; i <= lastCorner; ++i)
            {
                const Vector3f nextPos = cornerVerts[i];
                totalLength += Distance(nextPos, pos);
                pos = nextPos;
            }
            return totalLength;
        }
        return std::numeric_limits<float>::infinity();
    }

    return Distance(startPos, corridor->GetTarget());
}

void UpdatePathJob(CrowdInfo* info, unsigned i)
{
    UpdateValidatePathMultithreaded(info->rangeInfo[i], info->readOnlyCrowdInfo, info->navMeshQuery[i]);
    UpdateRepathTriggerMultiThreaded(info->rangeInfo[i], info->readOnlyCrowdInfo, info->navMeshQuery[i]);
}

void UpdateProximityJob(CrowdInfo* info, unsigned i)
{
    UpdateProximityCollectMultiThreaded(info->rangeInfo[i], info->readOnlyCrowdInfo, info->navMeshQuery[i]);
}

void UpdateSteeringJob(CrowdInfo* info, unsigned i)
{
    UpdateCornersMultithreaded(info->rangeInfo[i], info->readOnlyCrowdInfo, info->navMeshQuery[i]);

    // Read global, Write Local (Depends on previous step)
    UpdateSteeringMultithreaded(info->rangeInfo[i], info->readOnlyCrowdInfo, info->deltaTime);
}

void UpdateAvoidanceJob(CrowdInfo* info, unsigned i)
{
    ObstacleAvoidanceQuery query;

    // Read global, Write Local (Depends on previous step)
    const NavMesh* navmesh = info->crowd->GetNavMeshQuery()->GetAttachedNavMesh();

    UpdateAvoidanceMultiThreaded(info->rangeInfo[i], info->readOnlyCrowdInfo, query, navmesh);

    // Read/Write Local
    UpdateIntegrateMultithreaded(info->rangeInfo[i], info->deltaTime);
}

void UpdateMoveJob(CrowdInfo* info, unsigned i)
{
    UpdateMoveMultiThreaded(info->rangeInfo[i], info->readOnlyCrowdInfo, info->navMeshQuery[i]);
    UpdateHeightMultiThreaded(info->rangeInfo[i], info->readOnlyCrowdInfo, info->crowd->GetNavMeshQuery()->GetAttachedNavMesh());
}

void UpdateVelocityJob(CrowdInfo* info, unsigned i)
{
    UpdateAgentVelocityMultiThreaded(info->rangeInfo[i], info->deltaTime);
}

int CalculateNumberOfJobs(const UpdateCrowdInfo& updateAllInfo)
{
#if MULTITHREADED_CROWD_UPDATE
    // main thread not included in threadcount
    const int workerCount = 1 + JobSystem::GetJobQueueThreadCount();
    if (workerCount < 2)
        return 1;

    // Scale job count by no of agents.
    const int wantedJobs = 1 + (updateAllInfo.updateAgentCount - 1) / 10;

    // Limit number of jobs by the number of workers
    const int maxJobCount = std::min<int>(4 * workerCount, CrowdManager::kMaxCrowdJobs);
    return clamp(wantedJobs, 1, maxJobCount);
#else
    return 1;
#endif
}

void PrepareJobData(const UpdateCrowdInfo& updateAllInfo, UpdateCrowdInfo* outRangeInfo, const int jobCount)
{
    Assert(jobCount > 0);
    const int activeAgentCount = updateAllInfo.updateAgentCount;

    // Initialize index ranges for the individual jobs
    int offset = 0;
    int remaining = activeAgentCount;
    for (int i = 0; i < jobCount; ++i)
    {
        UpdateCrowdInfo& info = outRangeInfo[i];
        info.agentBase = updateAllInfo.agentBase;
        info.animBase = updateAllInfo.animBase;

        const int count = remaining / (jobCount - i);
        info.updateAgentIDs = updateAllInfo.updateAgentIDs + offset;
        info.updateAgentCount = count;
        offset += count;
        remaining -= count;
    }
}

void CrowdUpdateMultiThreaded(const ReadonlyCrowdInfo& roInfo, UpdateCrowdInfo& updateAllInfo, CrowdManager* crowd, NavMeshQuery** queries, const float dt)
{
    // Update shared thread read-only data
    CrowdInfo crowdInfo;
    crowdInfo.deltaTime = dt;
    crowdInfo.crowd = crowd;
    crowdInfo.readOnlyCrowdInfo = roInfo;
    memcpy(crowdInfo.navMeshQuery, &queries[0], sizeof(crowdInfo.navMeshQuery));

    const int jobCount = CalculateNumberOfJobs(updateAllInfo);

    PrepareJobData(updateAllInfo, crowdInfo.rangeInfo, jobCount);

    JobFence fence;

    ScheduleJobForEach(fence, UpdatePathJob, &crowdInfo, jobCount, kHighJobPriority);
    SyncFence(fence);

    UpdateMoveRequestsSingleThreaded(updateAllInfo, roInfo, crowd, dt);

    ScheduleJobForEach(fence, UpdateProximityJob, &crowdInfo, jobCount, kHighJobPriority);
    SyncFence(fence);

    ScheduleJobForEach(fence, UpdateSteeringJob, &crowdInfo, jobCount, kHighJobPriority);
    SyncFence(fence);

    ScheduleJobForEach(fence, UpdateAvoidanceJob, &crowdInfo, jobCount, kHighJobPriority);
    SyncFence(fence);

    // Too hard and pointless to multithread
    UpdateCollisionSingleThreaded(updateAllInfo, roInfo, crowd->GetNavMeshQuery()->GetAttachedNavMesh());

    ScheduleJobForEach(fence, UpdateMoveJob, &crowdInfo, jobCount, kHighJobPriority);
    SyncFence(fence);

    // OffMeshLink occupation accesses global data
    UpdateEnterOffMeshSingleThreaded(updateAllInfo, roInfo, crowd, dt);

    // OffMeshLink occupation accesses global data
    UpdateMoveOffMeshSingleThreaded(updateAllInfo, roInfo, crowd, dt);

    ScheduleJobForEach(fence, UpdateVelocityJob, &crowdInfo, jobCount, kHighJobPriority);
    SyncFence(fence);
}
