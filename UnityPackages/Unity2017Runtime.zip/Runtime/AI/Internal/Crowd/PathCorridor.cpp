//
// Copyright (c) 2009-2010 Mikko Mononen memon@inside.org
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

// The original source code has been modified by Unity Technologies

#include "UnityPrefix.h"
#include "Runtime/Math/Vector3.h"
#include "PathCorridor.h"
#include "../MathUtil.h"
#include "../PathUtil.h"
#include "../NavMesh/NavMeshQuery.h"

#include <string.h>


PathCorridor::PathCorridor() :
    m_path(kMemAI),
    m_stateFlags(0),
    m_timeStamp(0),
    m_mesh(NULL)
{
}

PathCorridor::~PathCorridor()
{
}

void PathCorridor::ClearPath()
{
    m_path.resize_uninitialized(0);
}

void PathCorridor::Reset(NavMeshPolyRef ref, const Vector3f& pos)
{
    if (!ref)
    {
        Invalidate();
        return;
    }

    m_path.resize_uninitialized(1);
    m_path.front() = ref;
    m_pos = pos;
    m_target = pos;
    m_stateFlags = kPathCorridorValid;
    m_timeStamp = m_mesh->GetTimeStamp();
}

void PathCorridor::Invalidate()
{
    // Preserve the position and target
    m_path.resize_uninitialized(1);
    m_path.front() = 0;
    m_stateFlags = 0;
    m_timeStamp = m_mesh->GetTimeStamp();
}

void PathCorridor::SetToEnd()
{
    DebugAssert(!m_path.empty());

    m_pos = m_target;
    m_path.front() = m_path.back();
    m_path.resize_uninitialized(1);
}

NavMeshStatus PathCorridor::FindCorners(Vector3f* cornerVerts, unsigned char* cornerFlags,
    NavMeshPolyRef* cornerPolys, int* cornerCount, const int maxCorners,
    const NavMeshQuery* navquery) const
{
    DebugAssert(!m_path.empty());

    const float kMinTargetDistSq = 0.0001f;

    int ncorners = 0;
    NavMeshStatus status = navquery->FindStraightPath(m_pos, m_target, m_path.begin(), m_path.size(),
            cornerVerts, cornerFlags, cornerPolys, &ncorners, maxCorners);
    if (!ncorners)
    {
        *cornerCount = 0;
        return kNavMeshSuccess;
    }

    // Prune points in the beginning of the path which are too close.
    int prune;
    for (prune = 0; prune < ncorners; ++prune)
    {
        if ((cornerFlags[prune] & kStraightPathOffMeshConnection) || SqrDistance2D(cornerVerts[prune], m_pos) > kMinTargetDistSq)
            break;
    }
    ncorners -= prune;
    if (prune && ncorners)
    {
        memmove(cornerFlags, cornerFlags + prune, sizeof(unsigned char) * ncorners);
        memmove(cornerPolys, cornerPolys + prune, sizeof(NavMeshPolyRef) * ncorners);
        memmove(cornerVerts, cornerVerts + prune, sizeof(Vector3f) * ncorners);
    }

    // Prune points after an off-mesh connection.
    for (prune = 0; prune < ncorners; ++prune)
    {
        if (cornerFlags[prune] & kStraightPathOffMeshConnection)
        {
            ncorners = prune + 1;
            break;
        }
    }

    *cornerCount = ncorners;

    if (NavMeshStatusDetail(status, kNavMeshPartialResult))
        return kNavMeshSuccess | kNavMeshPartialResult;

    return kNavMeshSuccess;
}

void PathCorridor::OptimizePathVisibility(const Vector3f& next, const NavMeshQuery* navquery, const QueryFilter* filter)
{
    const int kMaxResults = 32;
    NavMeshPolyRef res[kMaxResults];
    int nres = 0;
    NavMeshRaycastResult result;
    navquery->Raycast(m_path.front(), m_pos, next, filter, &result, res, &nres, kMaxResults);
    if (nres > 1 && result.t > 0.99f)
    {
        ReplacePathStart(m_path, res, nres);
    }
}

bool PathCorridor::OptimizePathTopology(NavMeshQuery* navquery, const QueryFilter* filter)
{
    if (m_path.size() < 3)
        return false;

    const int kMaxIterations = 8;
    const int kMaxResults = 8;

    NavMeshPolyRef res[kMaxResults];
    int nres = 0;

    NavMeshStatus status = navquery->InitSlicedFindPath(m_path.front(), m_path.back(), m_pos, m_target, filter);

    if (!NavMeshStatusFailed(status))
        status = navquery->UpdateSlicedFindPath(kMaxIterations, NULL);

    if (!NavMeshStatusSucceed(status)) // dont accept kNavMeshInProgress
        return false;

    status = navquery->FinalizeSlicedFindPathPartial(&nres, m_path.begin(), m_path.size());
    if (!NavMeshStatusSucceed(status))
        return false;

    status = navquery->GetPath(res, &nres, kMaxResults);
    if (!NavMeshStatusSucceed(status))
        return false;

    return ReplacePathStart(m_path, res, nres);
}

bool PathCorridor::MoveOverOffmeshConnection(NavMeshPolyRef offMeshConRef, const Vector3f& currentPos,
    Vector3f& startPos, Vector3f& endPos,
    const NavMeshQuery* navquery)
{
    DebugAssert(navquery);
    DebugAssert(!m_path.empty());

    // Advance the path up to and over the off-mesh connection.
    NavMeshPolyRef prevRef = 0, polyRef = m_path.front(), nextRef = 0;
    int npos = 0;
    int npath = m_path.size();
    while (npos < npath && polyRef != offMeshConRef)
    {
        prevRef = polyRef;
        polyRef = m_path[npos];
        if (npos + 1 < npath)
            nextRef = m_path[npos + 1];
        npos++;
    }
    if (npos == npath)
    {
        // Could not find offMeshConRef
        return false;
    }

    // Prune path
    m_path.erase(m_path.begin(), m_path.begin() + npos);

    const NavMesh* nav = navquery->GetAttachedNavMesh();
    DebugAssert(nav);

    const OffMeshConnection* conn = nav->GetOffMeshConnection(polyRef);
    if (conn == NULL)
        return false;

    if (conn->width > 0.0f)
    {
        // Handle wide link
        NavMeshStatus status = nav->GetNearestOffMeshConnectionEndPoints(prevRef, polyRef, nextRef, currentPos, &startPos, &endPos);
        if (NavMeshStatusSucceed(status))
        {
            m_pos = endPos;
            return true;
        }
    }
    else
    {
        NavMeshStatus status = nav->GetOffMeshConnectionEndPoints(prevRef, polyRef, &startPos, &endPos);
        if (NavMeshStatusSucceed(status))
        {
            m_pos = endPos;
            return true;
        }
    }

    return false;
}

// TODO : notify callers  - return  success/failure
void PathCorridor::MovePosition(const Vector3f& newPos, const NavMeshQuery* navquery, const QueryFilter* filter)
{
    DebugAssert(!m_path.empty());

    if (SqrDistance2D(newPos, m_pos) == 0.0f)
        return;

    // Move along navmesh and update new position.
    Vector3f result;
    const int kMaxVisited = 16;
    NavMeshPolyRef visited[kMaxVisited];
    int nvisited = 0;
    NavMeshStatus status = navquery->MoveAlongSurface(m_path.front(), m_pos, newPos, filter,
            &result, visited, &nvisited, kMaxVisited);

    if (NavMeshStatusSucceed(status))
    {
        ReplacePathStartReverse(m_path, visited, nvisited);

        // Adjust the position to stay on top of the navmesh.
        navquery->ProjectToPoly(&m_pos, m_path.front(), result);
    }
}

bool PathCorridor::UpdateTargetPosition(const NavMeshPolyRef ref, const Vector3f& target)
{
    if (ref != GetLastPoly() || IsPathStale())
        return false;

    m_target = target;
    return true;
}

void PathCorridor::SetCorridor(const Vector3f& target, const NavMeshQuery* navquery, const NavMeshPolyRef* path, const int npath, bool partialPath)
{
    DebugAssert(npath > 0);

    // Reserving room for extra polygons allows us to subsequently extend the path a bit,
    // e.g. from a thread/job, without allocating memory and possibly locking.
    const unsigned int kExtraCapacity = 16;
    const unsigned int cap = kExtraCapacity + kExtraCapacity * ((npath + kExtraCapacity - 1) / kExtraCapacity);
    m_path.reserve(cap);

    m_target = target;
    m_path.assign(path, path + npath);
    m_stateFlags = kPathCorridorValid;
    SetPathPartial(partialPath);

    // Adjust the position to stay on top of the navmesh.
    navquery->ProjectToPoly(&m_target, m_path.back(), target);
}

void PathCorridor::SetStateFlag(bool setFlag, unsigned char stateFlag)
{
    if (setFlag)
        m_stateFlags |= stateFlag;
    else
        m_stateFlags &= ~stateFlag;
}

bool PathCorridor::IsPathStale() const
{
    return m_timeStamp == 0 || m_timeStamp != m_mesh->GetTimeStamp();
}

void PathCorridor::SetPathValid(bool inbool)
{
    SetStateFlag(inbool, kPathCorridorValid);
}

void PathCorridor::SetPathPartial(bool inbool)
{
    SetStateFlag(inbool, kPathCorridorPartial);
}

void PathCorridor::SetPathStale(bool inbool)
{
    if (inbool)
        m_timeStamp = 0;
    else
        m_timeStamp = m_mesh->GetTimeStamp();
}
