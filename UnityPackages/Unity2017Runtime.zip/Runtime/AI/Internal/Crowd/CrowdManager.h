//
// Copyright (c) 2009-2010 Mikko Mononen memon@inside.org
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

// The original source code has been modified by Unity Technologies

#pragma once

#include "ObstacleAvoidanceQuery.h"
#include "CrowdTypes.h"
#include "PathRequest.h"
#include "Runtime/Utilities/dynamic_array.h"

#include <set>


class ProximityGrid;
class PathQueryInfo;
class HeightMeshQuery;
struct CrowdAgentAnimation;
struct Obstacle;
struct CrowdAgent;
struct CrowdAgentParams;
struct CrowdAgentDebugInfo;

class CrowdManager
{
public:

    CrowdManager();
    ~CrowdManager();

    enum { kMaxCrowdJobs = 16 };

    bool Init(const int maxAgents);
    bool SetNavMesh(const NavMesh* nav, const HeightMeshQuery* heightMeshQuery, const int nodePoolSize);
    void SetHeightMeshQuery(const HeightMeshQuery* heightMeshQuery)
    {
        m_HeightMeshQuery = heightMeshQuery;
    }

    void Purge();

    inline static void DecodeCrowdId(unsigned int* salt, unsigned int* index, unsigned int* type, CrowdRef ref)
    {
        *salt  = (unsigned int)((ref >> (kCrowdRefTypeBits + kCrowdRefIndexBits)) & kCrowdRefSaltMask);
        *index = (unsigned int)((ref >> kCrowdRefTypeBits) & kCrowdRefIndexMask);
        *type  = (unsigned int)(ref & kCrowdRefTypeMask);
    }

    inline static CrowdRef EncodeCrowdId(unsigned int salt, unsigned int index, unsigned int type)
    {
        return ((CrowdRef)salt  << (kCrowdRefTypeBits + kCrowdRefIndexBits)) |
            ((CrowdRef)index << kCrowdRefTypeBits) |
            (CrowdRef)type;
    }

    // Decodes a ref salt.
    inline static unsigned int GetCrowdRefSalt(CrowdRef ref)
    {
        return (unsigned int)((ref >> (kCrowdRefTypeBits + kCrowdRefIndexBits)) & kCrowdRefSaltMask);
    }

    inline static unsigned int GetCrowdRefIndex(CrowdRef ref)
    {
        return (unsigned int)((ref >> kCrowdRefTypeBits) & kCrowdRefIndexMask);
    }

    inline static unsigned int GetCrowdRefType(CrowdRef ref)
    {
        return (unsigned int)(ref & kCrowdRefTypeMask);
    }

    const CrowdAgent* GetAgentByRef(const CrowdRef agentRef) const;
    CrowdRef GetAgentRef(const CrowdAgent* agent) const;
    const CrowdAgentAnimation* GetAgentAnimation(const CrowdRef agentRef) const;
    void SetAgentAnimationPolyRef(const CrowdRef agentRef, NavMeshPolyRef polyRef);

    CrowdRef AddAgent(const Vector3f& pos, unsigned int areaMask, int typeID, const CrowdAgentParams* params);
    void UpdateAgentParameters(const CrowdRef agentRef, const CrowdAgentParams* params);
    void UpdateAgentFilter(const CrowdRef agentRef, unsigned int areaMask, int typeID);
    void UpdateAgentVelocity(const CrowdRef agentRef, const Vector3f& vel);
    void RemoveAgent(const CrowdRef agentRef);

    void FindNearestPoly(CrowdAgent* agent, const Vector3f& worldPos, NavMeshPolyRef* ref, Vector3f* pos) const;
    bool RequestMoveTarget(const CrowdRef agentRef, const Vector3f& pos);
    bool HasPath(const CrowdRef agentRef) const;
    Vector3f GetMoveTarget(const CrowdRef agentRef);
    void StopExplicit(const CrowdRef agentRef, bool stop);
    bool GetStopExplicit(const CrowdRef agentRef) const;

    void MoveAgent(const CrowdRef agentRef, const Vector3f& newPos);
    void MoveAgent(const CrowdRef agentRef, int jobIndex, const Vector3f& pos);

    bool IsRefOccupied(const NavMeshPolyRef ref) const;
    void OccupyRef(const NavMeshPolyRef ref);
    void ResetAgentPath(const CrowdRef agentRef);
    void SetAgentPath(const CrowdRef agentRef, const Vector3f& sourcePos, const Vector3f& targetPos, const NavMeshPolyRef* polygons, int polygonCount, bool partialPath);

    void Update(const float dt, CrowdAgentDebugInfo* agentDebugInfos, int agentDebugInfoCount);

    Vector3f GetSteerTarget(const CrowdRef agentRef) const;
    Vector3f GetWorldUpAxis(const CrowdRef agentRef) const;

    const NavMeshQuery* GetNavMeshQuery() const { return m_NavQuery; }
    NavMeshQuery* GetNavMeshQuery() { return m_NavQuery; }
    const ProximityGrid* GetProximityGrid() const { return m_Grid; }

    CrowdRef AddObstacle();
    void RemoveObstacle(const CrowdRef obstacleRef);
    const Obstacle* GetObstacleByRef(const CrowdRef obstacleRef) const;
    CrowdRef GetObstacleRef(const Obstacle* obstacle) const;

    void SetObstaclePositionAndVelocity(const CrowdRef obstacleRef, const Vector3f& position, const Vector3f& velocity);
    void SetObstacleCylinder(const CrowdRef obstacleRef, const Vector3f& extents, const Vector3f& xAxis, const Vector3f& yAxis, const Vector3f& zAxis);
    void SetObstacleBox(const CrowdRef obstacleRef, const Vector3f& extents, const Vector3f& xAxis, const Vector3f& yAxis, const Vector3f& zAxis);

    float CalculateRemainingPath(const CrowdRef agentRef) const;
    void UpdateFilterCost(int areaIndex, float areaCost);
    void InitializeAgentFilter(const CrowdRef agentRef, const float* areaCost, int areaCount);

    void UpdateAgentFilterCost(const CrowdRef agentRef, int areaIndex, float areaCost);
    void CompleteOffMeshLink(const CrowdRef agentRef);
    const QueryFilter* GetAgentFilter(const CrowdRef agentRef) const;

    void LogPathInfo(bool state) { m_LogPathInfo = state; }
    int GetPathInfoCount() const { return (int)m_PathInfos.size(); }
    const PathQueryInfo* GetPathInfo(int idx) const { return m_PathInfos[idx]; }

    void UpdateTopologyOptimization(const float dt);
    void UpdateMoveRequest();
    void UpdateProximityGrid();

    void SetPathfindingIterationsPerFrame(int it) { m_PathfindingIterationsPerFrame = it; }
    void SetAvoidancePredictionTime(float t) { m_AvoidancePredictionTime = t; }

    void CompleteOffMeshLink(CrowdAgent* agent, bool moveAgent);

    void SetObstacleAvoidanceParams(const int idx, const ObstacleAvoidanceParams* params);
    const ObstacleAvoidanceParams* GetObstacleAvoidanceParams(const int idx) const;

    CrowdAgent* GetMutableAgentByRef(const CrowdRef agentRef);
    Obstacle* GetMutableObstacleByRef(const CrowdRef obstacleRef);
    inline int GetAgentIndex(const CrowdAgent* agent) const { return (int)(agent - &m_Agents[0]); }
    inline int GetObstacleIndex(const Obstacle* obstacle) const { return (int)(obstacle - &m_Obstacles[0]); }

private:
    enum MoveRequestState
    {
        MR_INVALID,
        MR_REQUESTING,
        MR_PROCESSING
    };

    void MarkPathStale(CrowdAgent* agent);

    const QueryFilter* GetAgentFilter(const CrowdAgent* agent) const;
    void UpdateProximityGridCellSize(ProximityGrid* grid, const int addAgentCount, const int addObstacleCount) const;
    void InsertActiveAgentsIntoProximityGrid(ProximityGrid* grid, const int addAgentCount, const int addObstacleCount) const;
    bool RequestMoveTarget(CrowdAgent* agent, const Vector3f& pos);
    bool HasPath(const CrowdAgent* agent) const;

    bool ReserveAgents(int agentCount);
    bool ReserveObstacles(int obstacleCount);
    void ResizeProximityGrid();

    void UpdateAgentFilterCost(CrowdAgent* agent, int areaIndex, float areaCost);
    void UpdateActiveAgentIDs();
    void UpdateActiveObstacleIDs();

private:

    enum { kMaxObstacleAvoidanceParams = 5 };

    NavMeshQuery* m_JobNavMeshQuery[kMaxCrowdJobs];

    int m_MaxAgents;
    int m_NextFreeAgent;
    int m_ActiveAgentCount;

    int m_MaxObstacles;
    int m_NextFreeObstacle;
    int m_ActiveObstacleCount;

    QueryFilter* m_SharedFilter;
    dynamic_array<CrowdAgent> m_Agents;
    dynamic_array<CrowdAgentAnimation> m_AgentAnims;
    dynamic_array<QueryFilter> m_AgentFilters;
    dynamic_array<NavMeshPolyRef> m_PathResult;
    dynamic_array<Obstacle> m_Obstacles;
    dynamic_array<int> m_MoveRequestQueue;
    dynamic_array<int> m_ActiveAgentIDs;
    dynamic_array<int> m_ActiveObstacleIDs;
    dynamic_array<PathQueryInfo*> m_PathInfos;

    PathRequest m_PathRequest;
    ObstacleAvoidanceParams m_ObstacleQueryParams[kMaxObstacleAvoidanceParams];
    ProximityGrid* m_Grid;
    std::set<NavMeshPolyRef> m_Occupied;

    bool m_LogPathInfo;

    float m_AvoidancePredictionTime;
    int m_PathfindingIterationsPerFrame;

    unsigned int m_PathRequestRef;
    int m_MoveRequestQueueCount;

    NavMeshQuery* m_NavQuery;
    const HeightMeshQuery* m_HeightMeshQuery;
};
