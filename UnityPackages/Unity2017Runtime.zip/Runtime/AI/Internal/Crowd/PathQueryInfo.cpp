//
// Copyright (c) 2009-2010 Mikko Mononen memon@inside.org
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

// The original source code has been modified by Unity Technologies

#include "UnityPrefix.h"
#include "PathQueryInfo.h"
#include "../MathUtil.h"
#include "../NavMesh/NavMeshQuery.h"
#include "../NavMesh/NavMeshNode.h"
#include "Runtime/Utilities/dynamic_array.h"

#include <new>
#include <float.h>
#include <string.h>

PathQueryInfo::PathQueryInfo()
    : m_Info(0)
{
}

PathQueryInfo::~PathQueryInfo()
{
    Purge();
}

void PathQueryInfo::Purge()
{
    if (m_Info)
    {
        UNITY_FREE(kMemAI, m_Info->nodeParents);
        UNITY_FREE(kMemAI, m_Info->nodePositions);
        UNITY_DELETE(m_Info, kMemAI);
    }
}

void PathQueryInfo::Set(NavMeshPolyRef startRef, NavMeshPolyRef endRef,
    const Vector3f& startPos, const Vector3f& endPos,
    const NavMeshQuery* navquery)
{
    // Preserve idx if possible.
    CrowdRef agentRef = m_Info ? m_Info->agentRef : 0;

    Purge();

    m_Info = UNITY_NEW(Info, kMemAI) ();
    m_Info->agentRef = agentRef;
    m_Info->startRef = startRef;
    m_Info->endRef = endRef;
    m_Info->startPos = startPos;
    m_Info->endPos = endPos;
    m_Info->nodeParents = NULL;
    m_Info->nodePositions = NULL;
    m_Info->nnodes = 0;

    const NavMeshNodePool* pool = navquery->GetNodePool();
    if (!pool)
        return;

    // Count number of active nodes.
    int nnodes = 0;
    for (int i = 0; i < pool->GetHashSize(); ++i)
    {
        for (NavMeshNodeIndex j = pool->GetFirst(i); j != kNavMeshNodeNullIndex; j = pool->GetNext(j))
        {
            const NavMeshNode* node = pool->GetNodeAtIdx(j + 1);
            if (!node || node->flags == NavMeshNode::kNew)
                continue;
            nnodes++;
        }
    }
    if (nnodes == 0)
        return;

    m_Info->nnodes = nnodes;
    m_Info->nodeParents = (int*)UNITY_MALLOC(kMemAI, sizeof(int) * nnodes);
    m_Info->nodePositions = (Vector3f*)UNITY_MALLOC(kMemAI, sizeof(Vector3f) * nnodes);

    dynamic_array<int> remap(kMemTempAlloc);
    remap.resize_uninitialized(nnodes);

    int n = 0;

    // Store node vertices
    n = 0;
    for (int i = 0; i < pool->GetHashSize(); ++i)
    {
        for (NavMeshNodeIndex j = pool->GetFirst(i); j != kNavMeshNodeNullIndex; j = pool->GetNext(j))
        {
            const NavMeshNode* node = pool->GetNodeAtIdx(j + 1);
            if (!node || node->flags == NavMeshNode::kNew)
                continue;
            remap[n] = j + 1;
            m_Info->nodePositions[n] = node->pos;
            n++;
        }
    }

    // Store node parents
    n = 0;
    for (int i = 0; i < pool->GetHashSize(); ++i)
    {
        for (NavMeshNodeIndex j = pool->GetFirst(i); j != kNavMeshNodeNullIndex; j = pool->GetNext(j))
        {
            const NavMeshNode* node = pool->GetNodeAtIdx(j + 1);
            if (!node || node->flags == NavMeshNode::kNew)
                continue;
            m_Info->nodeParents[n] = -1;
            if (node->pidx)
            {
                for (int k = 0; k < nnodes; k++)
                {
                    if (remap[k] == node->pidx)
                    {
                        m_Info->nodeParents[n] = k;
                        break;
                    }
                }
            }
            n++;
        }
    }
}

void PathQueryInfo::SetAgentRef(CrowdRef agentRef)
{
    if (m_Info)
        m_Info->agentRef = agentRef;
}

void PathQueryInfo::CopyFrom(const PathQueryInfo& info)
{
    Purge();
    if (!info.IsValid())
        return;

    m_Info = UNITY_NEW(Info, kMemAI) ();
    m_Info->startRef = info.GetStartRef();
    m_Info->endRef = info.GetEndRef();
    m_Info->startPos = info.GetStartPos();
    m_Info->endPos = info.GetEndPos();
    int nnodes = info.GetNodeCount();
    if (nnodes > 0)
    {
        m_Info->nnodes = nnodes;
        m_Info->nodeParents = (int*)UNITY_MALLOC(kMemAI, sizeof(int) * nnodes);
        m_Info->nodePositions = (Vector3f*)UNITY_MALLOC(kMemAI, sizeof(Vector3f) * nnodes);
        memcpy(m_Info->nodeParents, info.GetNodeParents(), sizeof(int) * nnodes);
        memcpy(m_Info->nodePositions, info.GetNodePositions(), sizeof(Vector3f) * nnodes);
    }
}
