//
// Copyright (c) 2009-2010 Mikko Mononen memon@inside.org
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

// The original source code has been modified by Unity Technologies

#pragma once

#include "PathQueryInfo.h"
#include "../NavMesh/NavMesh.h"
#include "../NavMesh/NavMeshQuery.h"
#include "Runtime/Utilities/dynamic_array.h"


typedef unsigned int PathQueueRef;

class PathRequest
{
public:
    PathRequest();
    ~PathRequest();

    bool Init(const int pathSizeInc, const int maxSearchNodeCount, const NavMesh* nav);

    void Clear();

    void Update(const int maxIters, int* iterations = NULL);

    PathQueueRef Request(NavMeshPolyRef startRef, NavMeshPolyRef endRef,
        const Vector3f& startPos, const Vector3f& endPos,
        const QueryFilter* filter, bool logInfo);

    NavMeshStatus GetRequestStatus(PathQueueRef ref) const;
    int GetRequestPathSize(PathQueueRef ref) const;

    void SetStaleInProgress(PathQueueRef ref);

    NavMeshStatus GetPathResult(PathQueueRef ref, NavMeshPolyRef* path, int* pathSize, Vector3f* endPos,
        unsigned int* timeStamp, PathQueryInfo* pathInfo, const int maxPath);

    inline const NavMeshQuery* GetNavQuery() const { return m_Navquery; }

private:
    void Purge();

    struct PathQuery
    {
        PathQueueRef ref;
        // Path find start and end location.
        Vector3f startPos, endPos;
        NavMeshPolyRef startRef, endRef;
        // Result.
        dynamic_array<NavMeshPolyRef> path;
        int npath;
        int maxPath;
        // State.
        NavMeshStatus status;
        int keepAlive;
        unsigned int timeStamp;
        QueryFilter filter;
        // Debug
        bool logInfo;
        PathQueryInfo pathInfo;
    };

    PathQuery m_Request;
    PathQueueRef m_NextHandle;
    int m_PathSizeInc;
    NavMeshQuery* m_Navquery;
};
