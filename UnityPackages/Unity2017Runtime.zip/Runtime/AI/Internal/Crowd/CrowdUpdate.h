//
// Copyright (c) 2009-2010 Mikko Mononen memon@inside.org
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

// The original source code has been modified by Unity Technologies

#pragma once

class CrowdManager;
class NavMesh;
class PathCorridor;
class ProximityGrid;
class QueryFilter;
class HeightMeshQuery;
struct CrowdAgent;
struct CrowdAgentAnimation;
struct ObstacleAvoidanceParams;
struct Obstacle;

struct ReadonlyCrowdInfo
{
    const HeightMeshQuery*      heightMeshQuery;
    ObstacleAvoidanceParams*    obstacleAvoidanceParams;
    ProximityGrid*              proximityGrid;
    QueryFilter*                filterBase;
    CrowdAgent*                 agentBase;
    Obstacle*                   obstacleBase;
    int*                        activeAgentIDs;
    int*                        activeObstacleIDs;
    int                         activeAgentCount;
    int                         activeObstacleCount;
    float                       avoidancePredictionTime;
};

struct UpdateCrowdInfo
{
    CrowdAgent* agentBase;
    CrowdAgentAnimation* animBase;
    const int* updateAgentIDs;
    int updateAgentCount;
};

void CrowdUpdateMultiThreaded(const ReadonlyCrowdInfo& crowdInfo, UpdateCrowdInfo& fullRangeInfo, CrowdManager* crowd, NavMeshQuery** queries, const float dt);

// Helpers for update functions
void CalculateRangeBounds(float time, float bounds[4], const Vector3f& pos, const Vector3f& vel, const Vector3f& dimensions);
float CalculateKnownPathLength(const Vector3f& startPos, int ncorners, const unsigned char* cornerFlags, const Vector3f* cornerVerts, const PathCorridor* corridor);
