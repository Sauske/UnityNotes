#include "UnityPrefix.h"
#include "NavMeshSettings.h"
#include "NavMeshData.h"
#include "NavMeshManager.h"
#include "Runtime/BaseClasses/ManagerContext.h"
#include "Runtime/Core/Callbacks/GlobalCallbacks.h"
#include "Runtime/Misc/Player.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/SceneManager/SceneManager.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/Misc/GarbageCollectSharedAssetsMarking.h"

static void NavMeshLoadScene(const UnitySceneHandle sceneHandle, AwakeFromLoadQueue& awakeQueue, SceneManager::LoadingMode mode);
static void NavMeshUnloadScene(const UnitySceneHandle sceneID);
static void NavMeshGarbageCollect(GarbageCollectorThreadState& gcState);
static void NavMeshMergeScenes(UnityScene* src, UnityScene* dst);
static void NavMeshExitPlayMode();
static void NavMeshEditorTick();
static bool NavMeshIsEditModeUpdateNeeded();

NavMeshSettings::NavMeshSettings(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
{
}

void NavMeshSettings::MainThreadCleanup()
{
    Super::MainThreadCleanup();
}

void NavMeshSettings::InitializeClass()
{
    InitializeNavMeshManager();

    GlobalCallbacks::Get().didUnloadScene.Register(NavMeshUnloadScene);
    GlobalCallbacks::Get().sceneLoadedBeforeAwake.Register(NavMeshLoadScene);
    GlobalCallbacks::Get().garbageCollect.Register(NavMeshGarbageCollect);
    GlobalCallbacks::Get().didMergeScenes.Register(NavMeshMergeScenes);
#if UNITY_EDITOR
    GlobalCallbacks::Get().exitPlayModeBeforeAwakeInEditMode.Register(NavMeshExitPlayMode);
    GlobalCallbacks::Get().tickEditor.Register(NavMeshEditorTick);
#endif
}

void NavMeshSettings::CleanupClass()
{
    GlobalCallbacks::Get().didUnloadScene.Unregister(NavMeshUnloadScene);
    GlobalCallbacks::Get().sceneLoadedBeforeAwake.Unregister(NavMeshLoadScene);
    GlobalCallbacks::Get().garbageCollect.Unregister(NavMeshGarbageCollect);
    GlobalCallbacks::Get().didMergeScenes.Unregister(NavMeshMergeScenes);
#if UNITY_EDITOR
    GlobalCallbacks::Get().exitPlayModeBeforeAwakeInEditMode.Unregister(NavMeshExitPlayMode);
    GlobalCallbacks::Get().tickEditor.Unregister(NavMeshEditorTick);
#endif

    CleanupNavMeshManager();
}

void NavMeshSettings::AwakeFromLoad(AwakeFromLoadMode mode)
{
    Super::AwakeFromLoad(mode);
}

void NavMeshSettings::Reset()
{
    Super::Reset();

#if UNITY_EDITOR
    m_BuildSettings = NavMeshBuildSettings();
#endif
}

void NavMeshSettings::ThreadedCleanup()
{
}

template<class T>
void NavMeshSettings::Transfer(T& transfer)
{
    transfer.SetVersion(2);

    Super::Transfer(transfer);

    TRANSFER_EDITOR_ONLY(m_BuildSettings);
    TRANSFER(m_NavMeshData);
}

IMPLEMENT_REGISTER_CLASS(NavMeshSettings, 196);
IMPLEMENT_OBJECT_SERIALIZE(NavMeshSettings);
GET_MANAGER(NavMeshSettings)

static void NavMeshLoadScene(const UnitySceneHandle sceneHandle, AwakeFromLoadQueue& awakeQueue, SceneManager::LoadingMode mode)
{
    if (!IsAdditiveLoad(mode))
    {
        GetNavMeshManager().LoadNavMeshData(sceneHandle, GetNavMeshSettings().GetNavMeshData());
    }
    else
    {
        if (NavMeshSettings* queuedSettings = awakeQueue.GetManagerFromQueue<NavMeshSettings>())
        {
            GetNavMeshManager().LoadNavMeshData(sceneHandle, queuedSettings->GetNavMeshData());
        }
    }
}

static void NavMeshUnloadScene(const UnitySceneHandle sceneID)
{
    GetNavMeshManager().UnloadNavMeshData(sceneID);
}

static void NavMeshGarbageCollect(GarbageCollectorThreadState& gcState)
{
    const NavMeshManager& manager = GetNavMeshManager();
    const int count = manager.GetLoadedNavMeshDataCount();
    for (int i = 0; i < count; ++i)
    {
        const InstanceID id = manager.GetLoadedNavMeshData(i)->GetInstanceID();
        MarkInstanceIDAsRoot(id, gcState);
    }
}

static void NavMeshMergeScenes(UnityScene* src, UnityScene* dst)
{
    GetNavMeshManager().MergeNavMeshScenes(src, dst);
}

static void NavMeshExitPlayMode()
{
    GetNavMeshManager().ExitPlayMode();
}

#if UNITY_EDITOR

static void NavMeshEditorTick()
{
    GetNavMeshManager().EditorTick();
}

#endif
