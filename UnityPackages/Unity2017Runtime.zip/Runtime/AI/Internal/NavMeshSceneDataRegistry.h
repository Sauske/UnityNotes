#pragma once
#include "NavMeshData.h"
#include "Runtime/SceneManager/UnitySceneHandle.h"
#include "Runtime/Utilities/dynamic_array.h"

// Helper class for keeping track of references from scene -> navmeshdata
class NavMeshSceneDataRegistry
{
public:

    void RemoveOneScene(const UnitySceneHandle scene)
    {
        size_t size = m_SceneData.size();
        for (size_t i = 0; i < size; ++i)
        {
            if (m_SceneData[i].scene == scene)
            {
                m_SceneData[i--] = m_SceneData[--size];
                m_SceneData.pop_back();
                return;
            }
        }
    }

    void ChangeSceneOwner(const UnitySceneHandle src, const UnitySceneHandle dst)
    {
        size_t size = m_SceneData.size();
        for (size_t i = 0; i < size; ++i)
        {
            if (m_SceneData[i].scene == src)
                m_SceneData[i].scene = dst;
        }
    }

    void RemoveAllData(const NavMeshData* data)
    {
        size_t size = m_SceneData.size();
        for (size_t i = 0; i < size; ++i)
        {
            if (m_SceneData[i].data == data)
            {
                m_SceneData[i--] = m_SceneData[--size];
                m_SceneData.pop_back();
            }
        }
    }

    bool Contains(const int surfaceID) const
    {
        for (size_t i = 0; i < m_SceneData.size(); ++i)
        {
            if (m_SceneData[i].surfaceID == surfaceID)
                return true;
        }
        return false;
    }

    int GetSurfaceID(const NavMeshData* data) const
    {
        for (size_t i = 0; i < m_SceneData.size(); ++i)
        {
            if (m_SceneData[i].data == data)
                return m_SceneData[i].surfaceID;
        }
        return 0;
    }

    int GetSurfaceID(const UnitySceneHandle scene) const
    {
        for (size_t i = 0; i < m_SceneData.size(); ++i)
        {
            if (m_SceneData[i].scene == scene)
                return m_SceneData[i].surfaceID;
        }
        return 0;
    }

    void Add(const NavMeshData* data, int surfaceID, const UnitySceneHandle scene)
    {
        DebugAssert(data);
        DebugAssert(surfaceID);
        DebugAssert(scene != kInvalidUnitySceneHandle);
        // Data structure is overrepresented - for ease of lookup code
        // here we assert that data is new or associated to the same surfaceID
        DebugAssert(GetSurfaceID(data) == 0 || GetSurfaceID(data) == surfaceID);

        SceneData element = {data, scene, surfaceID};
        m_SceneData.push_back(element);
    }

private:
    struct SceneData
    {
        const NavMeshData* data;
        UnitySceneHandle scene;
        int surfaceID;
    };

    dynamic_array<SceneData> m_SceneData;
};
