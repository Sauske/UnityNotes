#pragma once
#include "NavMesh/NavMeshTypes.h"
#include "Runtime/Utilities/dynamic_array.h"

// Greedy substitution of 'path' with 'start'.
//
// Finds the highest indices in 'path' and 'start' pointing to the same polygon reference.
// Replaces the elements before the index in 'path' with the elements in 'start' before its index.
//
// Ex.  path :  1 2 3 4  ->  5 6 2 3 4
//      start:  5 6 2 7
//
// Does nothing if no common polygon reference exists ('path' and 'start' are disjoint)
bool ReplacePathStart(dynamic_array<NavMeshPolyRef>& path, const NavMeshPolyRef* start, int nstart);

// Greedy substitution of 'path' with 'start' - where 'start' is applied inverted.
//
// Finds the highest indices in 'path' and 'start' pointing to the same polygon reference.
// Replaces the elements before the index in 'path' with the elements in 'start' after its index.
//
// Ex.  path :  1 2 3 4  ->  7 2 3 4
//      start:  5 6 2 7
//
// Does nothing if no common polygon reference exists ('path' and 'start' are disjoint)
bool ReplacePathStartReverse(dynamic_array<NavMeshPolyRef>& path, const NavMeshPolyRef* start, int nstart);
