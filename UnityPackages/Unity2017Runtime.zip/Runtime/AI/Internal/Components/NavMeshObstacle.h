#pragma once

#include "Runtime/GameCode/Behaviour.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Math/Vector3.h"
#include "../NavMeshManager.h"
#include "../NavMeshBindingTypes.h"
#include "Runtime/Transform/TransformAccess.h"

struct NavMeshCarveShape;
class Matrix4x4f;

class NavMeshObstacle : public Behaviour
{
    REGISTER_CLASS(NavMeshObstacle);
    DECLARE_OBJECT_SERIALIZE();
public:
    NavMeshObstacle(MemLabelId label, ObjectCreationMode mode);
    // ~NavMeshObstacle (); declared by a macro

    virtual void AwakeFromLoad(AwakeFromLoadMode mode);

    static void InitializeClass();
    static void CleanupClass();

    inline void SetManagerHandle(int handle);

    void OnNavMeshCleanup();
    void OnNavMeshInitialize();

    void GetCarveShape(NavMeshCarveShape& shape) const;

    void UpdateState();

    inline bool GetCarving() const;
    void SetCarving(bool carve);

    inline bool GetCarveOnlyStationary() const;
    void SetCarveOnlyStationary(bool carveOnlyStationary);

    inline float GetMoveThreshold() const;
    void SetMoveThreshold(float moveThreshold);

    inline float GetTimeToStationary() const;
    void SetTimeToStationary(float time);

    inline Vector3f GetPosition() const;

    inline Vector3f GetVelocity() const;
    void SetVelocity(const Vector3f& value);

    inline Vector3f GetExtents() const;
    void SetExtents(const Vector3f& extents);

    inline Vector3f GetCenter() const;
    void SetCenter(const Vector3f& center);

    inline float GetRadius() const;
    void SetRadius(float value);

    inline float GetHeight() const;
    void SetHeight(float value);

    inline NavMeshObstacleShape GetShape() const;
    void SetShape(NavMeshObstacleShape shape);

    inline NavMeshObstacleState GetMoveState() const;

    void FitExtents();

    Vector3f GetWorldCenter() const;
    Vector3f GetWorldExtents() const;
    void GetWorldCenterAndAxes(Vector3f& center, Vector3f& xAxis, Vector3f& yAxis, Vector3f& zAxis) const;

    inline int GetVersionStamp() const;

    inline bool IsRegistered() const;

    static TransformChangeSystemHandle s_NavMeshObstacleTRSInterest;
    inline void SetTRSDirty() { m_Status |= (kHasMoved | kHasRotated | kHasScaled); }

protected:
    virtual void Reset();
    virtual void SmartReset();
    virtual void AddToManager();
    virtual void RemoveFromManager();
    virtual void CheckConsistency();
    virtual MessageIdentifier::OptimizedMessageMask CalculateSupportedMessages();

    void OnVelocityChanged(Vector3f* value);

private:

    bool HasMoved(const float linearThreshold) const;
    void SnapshotTransform();

    void AddToCarveSystem();
    void RemoveFromCarveSystem();

    static inline float EnsurePositive(float value);
    static inline Vector3f EnsurePositive(const Vector3f& value);

    static const Vector3f s_DefaultCylinderExtents;
    static const Vector3f s_DefaultBoxExtents;

    enum
    {
        kClean = 0,
        kHasMoved = 1 << 0,
        kHasRotated = 1 << 1,
        kHasScaled = 1 << 2,
        kForceUpdate = 1 << 3
    };

    int         m_ManagerHandle;

    NavMeshObstacleShape m_Shape; ///< enum { Capsule = 0, Box }
    Vector3f    m_Center;
    Vector3f    m_Extents;
    bool        m_Carve;
    bool        m_CarveOnlyStationary;
    float       m_MoveThreshold;
    float       m_TimeToStationary;

    Vector3f    m_Velocity;
    Vector3f    m_LastPosition;
    Quaternionf m_LastRotation;
    Vector3f    m_LastScale;
    float       m_LastSqrDiagonal;
    UInt32      m_Status;
    NavMeshObstacleState m_MoveState;
    float       m_StationaryTime;
    int         m_VersionStamp;

    friend void DrawNavMeshObstacle(const NavMeshObstacle& obstacle);
};

inline void NavMeshObstacle::SetManagerHandle(int handle)
{
    m_ManagerHandle = handle;
}

inline float NavMeshObstacle::EnsurePositive(float value)
{
    return std::max(0.00001F, value);
}

inline Vector3f NavMeshObstacle::EnsurePositive(const Vector3f& value)
{
    const Vector3f minSize(0.00001F, 0.00001F, 0.00001F);
    return max(minSize, value);
}

inline Vector3f NavMeshObstacle::GetPosition() const
{
    return GetComponent<Transform>().GetPosition();
}

inline Vector3f NavMeshObstacle::GetVelocity() const
{
    return m_Velocity;
}

inline Vector3f NavMeshObstacle::GetCenter() const
{
    return m_Center;
}

inline Vector3f NavMeshObstacle::GetExtents() const
{
    return m_Extents;
}

inline float NavMeshObstacle::GetRadius() const
{
    return m_Extents.x;
}

inline float NavMeshObstacle::GetHeight() const
{
    return m_Extents.y;
}

inline NavMeshObstacleShape NavMeshObstacle::GetShape() const
{
    return m_Shape;
}

inline NavMeshObstacleState NavMeshObstacle::GetMoveState() const
{
    return m_MoveState;
}

inline bool NavMeshObstacle::GetCarving() const
{
    return m_Carve;
}

inline bool NavMeshObstacle::GetCarveOnlyStationary() const
{
    return m_CarveOnlyStationary;
}

inline float NavMeshObstacle::GetMoveThreshold() const
{
    return m_MoveThreshold;
}

inline float NavMeshObstacle::GetTimeToStationary() const
{
    return m_TimeToStationary;
}

inline int NavMeshObstacle::GetVersionStamp() const
{
    return m_VersionStamp;
}

inline bool NavMeshObstacle::IsRegistered() const
{
    return m_ManagerHandle != -1;
}
