#include "UnityPrefix.h"
#include "NavMeshObstacle.h"

#include "../Obstacles/NavMeshCarving.h"
#include "../Obstacles/NavMeshTileCarving.h"
#include "../Obstacles/HullAvoidance.h"
#include "Runtime/BaseClasses/IsPlaying.h"
#include "Runtime/BaseClasses/MessageHandlerRegistration.h"
#include "Runtime/Geometry/AABBUtility.h"
#include "Runtime/Input/TimeManager.h"
#include "Runtime/Interfaces/IPhysics.h"
#include "Runtime/Math/Quaternion.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Transform/TransformChangeDispatch.h"
#include "Runtime/Utilities/ValidateArgs.h"

const Vector3f NavMeshObstacle::s_DefaultCylinderExtents = Vector3f(0.5f, 1.0f, 0.5f);
const Vector3f NavMeshObstacle::s_DefaultBoxExtents = Vector3f(0.5f, 0.5f, 0.5f);
static const float minMoveThreshold = 1e-5f;

TransformChangeSystemHandle NavMeshObstacle::s_NavMeshObstacleTRSInterest;

NavMeshObstacle::NavMeshObstacle(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
{
    m_ManagerHandle = -1;

    m_Shape = kObstacleShapeBox;
    m_Center.SetZero();
    m_Extents = Vector3f::one * 0.5f;
    m_Carve = true;
    m_CarveOnlyStationary = true;
    m_MoveThreshold = 0.1f;
    m_TimeToStationary = 0.5f;

    m_Velocity.SetZero();
    m_LastPosition.SetZero();
    m_LastRotation = Quaternionf::identity();
    m_LastScale = Vector3f::one;
    m_LastSqrDiagonal = 0.0f;
    m_Status = kForceUpdate;
    m_MoveState = kObstacleStationary;
    m_StationaryTime = 0.0f;
    m_VersionStamp = 0;

    Reset();
}

void NavMeshObstacle::ThreadedCleanup()
{
}

template<class TransferFunc>
void NavMeshObstacle::Transfer(TransferFunc& transfer)
{
    Super::Transfer(transfer);
    transfer.SetVersion(3);

    TRANSFER_ENUM(m_Shape);
    TRANSFER(m_Extents);
    TRANSFER(m_MoveThreshold);
    TRANSFER(m_Carve);
    TRANSFER(m_CarveOnlyStationary);
    transfer.Align();
    TRANSFER(m_Center);
    TRANSFER(m_TimeToStationary);

    if (transfer.IsOldVersion(1))
    {
        float radius;
        float height;
        transfer.Transfer(radius, "m_Radius");
        transfer.Transfer(height, "m_Height");
        m_Extents = Vector3f(radius, height * 0.5f, radius);
        // Cylinder used to have origin at bottom.
        m_Center.y = m_Extents.y;
        m_Shape = kObstacleShapeCapsule;
        m_CarveOnlyStationary = false;
    }
    else if (transfer.IsOldVersion(2))
    {
        Vector3f size;
        transfer.Transfer(size, "m_Size");
        if (m_Shape == kObstacleShapeCapsule)
        {
            m_Extents = Vector3f(size.x, size.y * 0.5f, size.z);
            // Cylinder used to have origin at bottom.
            m_Center.y = m_Extents.y;
        }
        else if (m_Shape == kObstacleShapeBox)
        {
            m_Extents = size * 0.5f;
        }
        m_CarveOnlyStationary = false;
    }
}

void NavMeshObstacle::CheckConsistency()
{
    if (m_Shape != kObstacleShapeBox)
        m_Shape = kObstacleShapeCapsule;

    m_Extents = EnsurePositive(m_Extents);
    m_MoveThreshold = std::max(0.0f, m_MoveThreshold);
    m_TimeToStationary = std::max(0.0f, m_TimeToStationary);
}

MessageIdentifier::OptimizedMessageMask NavMeshObstacle::CalculateSupportedMessages()
{
    return kDidVelocityChange.GetOptimizedMask();
}

void NavMeshObstacle::Reset()
{
    Super::Reset();

    m_Shape = kObstacleShapeBox;
    m_Extents = Vector3f(0.5f, 1.0f, 0.5f);
    m_Center.SetZero();

    m_TimeToStationary = 0.5f;
    m_MoveThreshold = 0.1f;
    m_CarveOnlyStationary = true;
    m_Carve = false;
}

static inline float Round(float a, float factor)
{
    return Roundf(a / factor) * factor;
}

// Resets the center and fits the extents for the selected shape (capsule/box)
// to match the GO's local renderer or mesh bounds (see CalculateLocalAABB).
// Falls back to defaults if no renderer/mesh.
void NavMeshObstacle::FitExtents()
{
    // Use roudning ro precent really small numbers popping up in the UI.
    static const float kRoundFactor = 0.001f;
    if (m_Shape == kObstacleShapeCapsule)
    {
        AABB aabb;
        if (GetGameObjectPtr() && CalculateLocalAABB(GetGameObject(), &aabb))
        {
            Vector3f extents = Round(aabb.GetExtent(), kRoundFactor);
            float radius = Round(std::max(extents.x, extents.z), kRoundFactor);
            float height = Round(extents.y, kRoundFactor);
            SetCenter(Round(aabb.GetCenter(), kRoundFactor));
            SetExtents(Vector3f(radius, height, radius));
        }
        else
        {
            SetCenter(Vector3f(0.0f, 0.0f, 0.0f));
            SetExtents(s_DefaultCylinderExtents);
        }
    }
    else if (m_Shape == kObstacleShapeBox)
    {
        AABB aabb;
        if (GetGameObjectPtr() && CalculateLocalAABB(GetGameObject(), &aabb))
        {
            SetCenter(Round(aabb.GetCenter(), kRoundFactor));
            SetExtents(Round(aabb.GetExtent(), kRoundFactor));
        }
        else
        {
            SetCenter(Vector3f(0.0f, 0.0f, 0.0f));
            SetExtents(s_DefaultBoxExtents);
        }
    }
    else
    {
        ErrorStringObject("Unknown NavMeshObstacle shape", this);
    }
}

void NavMeshObstacle::SmartReset()
{
    Super::SmartReset();
    FitExtents();
}

void NavMeshObstacle::AddToManager()
{
    TransformChangeDispatch& dispatch = GetTransformChangeDispatch();
    TransformAccess transformAccess = GetComponent<Transform>().GetTransformAccess();
    dispatch.SetSystemInterested(transformAccess, s_NavMeshObstacleTRSInterest, true);

    GetNavMeshManager().RegisterObstacle(*this, m_ManagerHandle);
    m_Status |= kForceUpdate;
}

void NavMeshObstacle::RemoveFromManager()
{
    TransformChangeDispatch& dispatch = GetTransformChangeDispatch();
    TransformAccess transformAccess = GetComponent<Transform>().GetTransformAccess();
    dispatch.SetSystemInterested(transformAccess, s_NavMeshObstacleTRSInterest, false);

    GetNavMeshManager().UnregisterObstacle(m_ManagerHandle);
}

void NavMeshObstacle::AwakeFromLoad(AwakeFromLoadMode mode)
{
    Super::AwakeFromLoad(mode);
    m_Status |= kForceUpdate;
}

void NavMeshObstacle::OnNavMeshCleanup()
{
}

void NavMeshObstacle::OnNavMeshInitialize()
{
}

void NavMeshObstacle::InitializeClass()
{
    s_NavMeshObstacleTRSInterest = GetTransformChangeDispatch().RegisterSystem(TransformChangeDispatch::kInterestedInGlobalTRS);
    // TODO: unregister currently doesn't work, the dispatch singleton is already cleaned up when this is.

    REGISTER_MESSAGE_PTR(kDidVelocityChange, OnVelocityChanged, Vector3f);
}

void NavMeshObstacle::CleanupClass()
{
    GetTransformChangeDispatch().UnregisterSystem(s_NavMeshObstacleTRSInterest);
}

void NavMeshObstacle::GetCarveShape(NavMeshCarveShape& shape) const
{
    shape.shape = m_Shape;
    shape.extents = GetWorldExtents();

    GetWorldCenterAndAxes(shape.center, shape.xAxis, shape.yAxis, shape.zAxis);

    Vector3f worldExtents;
    if (m_Shape == kObstacleShapeCapsule)
    {
        CalcCapsuleWorldExtents(&worldExtents, shape.extents, shape.xAxis, shape.yAxis, shape.zAxis);
    }
    else
    {
        CalcBoxWorldExtents(&worldExtents, shape.extents, shape.xAxis, shape.yAxis, shape.zAxis);
    }
    shape.bounds = MinMaxAABB(shape.center - worldExtents, shape.center + worldExtents);
}

bool NavMeshObstacle::HasMoved(const float linearThreshold) const
{
    if (m_Status == kClean)
        return false;

    if (m_Status & kForceUpdate)
        return true;

    const Transform& transform = GetComponent<Transform>();
    if (m_Status & kHasMoved)
    {
        const Vector3f position = transform.GetPosition();
        const float sqrDistance = SqrMagnitude(m_LastPosition - position);
        if (sqrDistance > linearThreshold * linearThreshold)
            return true;
    }

    // We don't store the extents as a vector - but rather a diagonal (scalar) - as a consequence
    // we over-estimate the extents (due to the Cauchy–Schwarz inequality) for rotation and scaling

    if (m_Status & kHasRotated)
    {
        // Given the extents of the object and the angle of rotation
        // trigger rebuild when the arc length of rotation exceeds the move-threshold
        const float angle = AngularDistance(m_LastRotation, transform.GetRotation());

        const float sqrMaxExtents = m_LastSqrDiagonal * SqrMagnitude(m_LastScale);
        float sqrArcLength = angle * angle * sqrMaxExtents;
        if (sqrArcLength > linearThreshold * linearThreshold)
            return true;
    }

    if (m_Status & kHasScaled)
    {
        const Vector3f scale = transform.GetWorldScaleLossy();

        float sqrScaleLength = m_LastSqrDiagonal * SqrMagnitude(m_LastScale - scale);
        if (sqrScaleLength > linearThreshold * linearThreshold)
            return true;
    }

    return false;
}

void NavMeshObstacle::SnapshotTransform()
{
    const Transform& transform = GetComponent<Transform>();
    m_LastPosition = transform.GetPosition();
    m_LastRotation = transform.GetRotation();
    m_LastScale = transform.GetWorldScaleLossy();
    m_LastSqrDiagonal = SqrMagnitude(GetWorldExtents());
    m_Status = kClean;
}

void NavMeshObstacle::UpdateState()
{
#if UNITY_EDITOR
    // Make sure the obstacles carves (if set so) when editing.
    if (!IsWorldPlaying())
    {
        if (HasMoved(minMoveThreshold))
        {
            m_MoveState = kObstacleStationary;
            m_StationaryTime = 0.0f;
            m_VersionStamp++;
            SnapshotTransform();
        }
        return;
    }
#endif

    if (m_Status & kForceUpdate)
    {
        m_VersionStamp++;
        SnapshotTransform();
    }

    const float deltaTime = GetDeltaTime();
    const float moveThr = std::max(minMoveThreshold, m_MoveThreshold);
    const float stationaryMoveThr = std::max(minMoveThreshold, m_MoveThreshold * 0.1f);

    if (m_CarveOnlyStationary)
    {
        if (m_MoveState == kObstacleStationary)
        {
            // Check for stationary->moving transition.
            if (HasMoved(moveThr))
            {
                m_MoveState = kObstacleMoving;
                m_StationaryTime = 0.0f;
                m_VersionStamp++;
                SnapshotTransform();
            }
        }
        else
        {
            // Check for moving->stationary transition.
            // Using much smalled threshold here so that .
            if (HasMoved(stationaryMoveThr))
            {
                m_StationaryTime = 0.0f;
                SnapshotTransform();
            }
            else
            {
                // If the obstacle has not moved for a while, change state to stationary.
                m_StationaryTime += deltaTime;
                if (m_StationaryTime > m_TimeToStationary)
                {
                    m_MoveState = kObstacleStationary;
                    m_VersionStamp++;
                }
            }
        }
    }
    else
    {
        // Update carving every time the obstacle has moved past a treshold.
        if (HasMoved(moveThr))
        {
            m_VersionStamp++;
            SnapshotTransform();
        }
        m_MoveState = kObstacleStationary;  // Always stationary
        m_StationaryTime = 0.0f;
    }
}

void NavMeshObstacle::SetCarving(bool carve)
{
    if (m_Carve == carve)
        return;
    m_Carve = carve;
    m_Status |= kForceUpdate;
    SetDirty();
}

void NavMeshObstacle::SetCarveOnlyStationary(bool carveOnlyStationary)
{
    if (m_CarveOnlyStationary == carveOnlyStationary)
        return;
    m_CarveOnlyStationary = carveOnlyStationary;
    m_Status |= kForceUpdate;
    SetDirty();
}

void NavMeshObstacle::SetMoveThreshold(float moveThreshold)
{
    if (m_MoveThreshold == moveThreshold)
        return;

    ABORT_INVALID_FLOAT(moveThreshold, moveThreshold, navmeshobstacle);
    m_MoveThreshold = moveThreshold;
    SetDirty();
}

void NavMeshObstacle::SetTimeToStationary(float time)
{
    if (m_TimeToStationary == time)
        return;

    ABORT_INVALID_FLOAT(time, time, navmeshobstacle);
    m_TimeToStationary = time;
    SetDirty();
}

void NavMeshObstacle::OnVelocityChanged(Vector3f* value)
{
    SetVelocity(*value);
}

void NavMeshObstacle::SetVelocity(const Vector3f& value)
{
    ABORT_INVALID_VECTOR3(value, velocity, navmeshobstacle);
    m_Velocity = value;
}

void NavMeshObstacle::SetCenter(const Vector3f& center)
{
    ABORT_INVALID_VECTOR3(center, center, navmeshobstacle)
    m_Center = center;
    m_Status |= kForceUpdate;
    SetDirty();
}

void NavMeshObstacle::SetExtents(const Vector3f& extents)
{
    ABORT_INVALID_VECTOR3(extents, extents, navmeshobstacle)
    m_Extents = extents;
    m_Status |= kForceUpdate;
    SetDirty();
}

void NavMeshObstacle::SetRadius(float value)
{
    ABORT_INVALID_FLOAT(value, radius, navmeshobstacle);

    const float positiveRadius = EnsurePositive(value);
    const Vector3f newExtents(positiveRadius, m_Extents.y, positiveRadius);
    SetExtents(newExtents);
}

void NavMeshObstacle::SetHeight(float value)
{
    ABORT_INVALID_FLOAT(value, height, navmeshobstacle);

    const float positiveHeight = EnsurePositive(value);
    const Vector3f newExtents(m_Extents.x, positiveHeight * 0.5f, m_Extents.z);
    SetExtents(newExtents);
}

void NavMeshObstacle::SetShape(NavMeshObstacleShape shape)
{
    if (m_Shape == shape)
        return;

    m_Shape = shape;
    FitExtents();
    m_Status |= kForceUpdate;
    SetDirty();
}

Vector3f NavMeshObstacle::GetWorldCenter() const
{
    return GetComponent<Transform>().TransformPoint(m_Center);
}

Vector3f NavMeshObstacle::GetWorldExtents() const
{
    const Transform& transform = GetComponent<Transform>();

    const Vector3f absScale = Abs(transform.GetWorldScaleLossy());
    if (m_Shape == kObstacleShapeCapsule)
    {
        const float scaledRadius = m_Extents.x * std::max(absScale.x, absScale.z);
        const float scaledHeight = m_Extents.y * absScale.y;
        return Vector3f(scaledRadius, scaledHeight, scaledRadius);
    }
    else
    {
        return Scale(m_Extents, absScale);
    }
}

void NavMeshObstacle::GetWorldCenterAndAxes(Vector3f& center, Vector3f& xAxis, Vector3f& yAxis, Vector3f& zAxis) const
{
    const Transform& transform = GetComponent<Transform>();

    center = transform.TransformPoint(m_Center);
    Quaternionf rotation = transform.GetRotation();

    Matrix3x3f rotationMatrix;
    QuaternionToMatrix(rotation, rotationMatrix);

    xAxis = rotationMatrix.GetColumn(0);
    yAxis = rotationMatrix.GetColumn(1);
    zAxis = rotationMatrix.GetColumn(2);
}

IMPLEMENT_REGISTER_CLASS(NavMeshObstacle, 208);
IMPLEMENT_OBJECT_SERIALIZE(NavMeshObstacle);
