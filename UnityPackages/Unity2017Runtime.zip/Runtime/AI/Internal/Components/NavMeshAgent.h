#pragma once

#include "../NavMeshBindingTypes.h"
#include "../Crowd/CrowdTypes.h"
#include "Runtime/GameCode/Behaviour.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Math/Vector2.h"
#include "Runtime/Transform/TransformAccess.h"

class NavMeshPath;
struct OffMeshLinkData;
struct NavMeshHit;

class NavMesh;
class CrowdManager;
class QueryFilter;
struct CrowdAgentParams;
struct CrowdAgent;


class NavMeshAgent : public Behaviour
{
    REGISTER_CLASS(NavMeshAgent);
    DECLARE_OBJECT_SERIALIZE();
public:
    NavMeshAgent(MemLabelId label, ObjectCreationMode mode);
    // ~NavMeshAgent (); declared by a macro

    static void InitializeClass();
    static void CleanupClass();

    virtual void AwakeFromLoad(AwakeFromLoadMode mode);
    virtual void CheckConsistency();

    inline bool InCrowdSystem() const;
    inline void SetManagerHandle(int handle);
    Vector3f GetDestination() const;
    bool SetDestination(const Vector3f& position);
    Vector3f GetPosition() const;
    void SetPosition(const Vector3f& position);

    int CalculatePolygonPath(const Vector3f& targetPosition, NavMeshPath* path) const;
    bool SetPath(const NavMeshPath* path);
    void CopyPath(NavMeshPath* path) const;
    void ResetPath();
    bool PathPending() const;
    bool HasPath() const;
    bool DistanceToEdge(NavMeshHit* hit) const;
    bool Raycast(const Vector3f& position, NavMeshHit* hitPos) const;
    float GetRemainingDistance() const;

    // Consider moving these to the 'NavMeshPath' class
    bool SamplePathPosition(int collisionMask, float maxDistance, NavMeshHit* hit) const;
    Vector3f GetEndPositionOfCurrentPath() const;
    bool IsPathValid() const;
    bool IsPathPartial() const;
    bool IsPathStale() const;
    NavMeshPathStatus GetPathStatus() const;

    UInt32 GetAreaMask() const         { return m_WalkableMask; }
    void SetAreaMask(UInt32 areaMask);

    void SetAreaCost(unsigned int areaIndex, float areaCost);
    float GetAreaCost(unsigned int areaIndex) const;

    inline ObstacleAvoidanceType GetObstacleAvoidanceType() const;
    void SetObstacleAvoidanceType(ObstacleAvoidanceType type);

    void SetAvoidancePriority(int value);
    inline int GetAvoidancePriority() const;

    inline float GetSpeed() const;
    void  SetSpeed(float value);

    inline float GetAngularSpeed() const;
    void  SetAngularSpeed(float value);

    inline float GetAcceleration() const;
    void  SetAcceleration(float value);

    inline float GetStoppingDistance() const;
    void SetStoppingDistance(float value);

    Vector3f GetVelocity() const;
    void SetVelocity(const Vector3f& vel);

    Vector3f GetSteeringTarget() const;
    Vector3f GetDesiredVelocity() const;

    bool IsOnOffMeshLink() const;
    void ActivateCurrentOffMeshLink(bool activated);
    bool GetCurrentOffMeshLinkData(OffMeshLinkData* data) const;
    bool GetNextOffMeshLinkData(OffMeshLinkData* data) const;
    bool SetOffMeshLinkDataFlags(OffMeshLinkData* data, const NavMeshPolyRef polyRef) const;
    Object* GetCurrentPolygonOwner() const;

    inline bool GetUpdatePosition() const;
    void SetUpdatePosition(bool updatePos);
    inline bool GetUpdateRotation() const;
    inline void SetUpdateRotation(bool inbool);
    inline bool GetUpdateUpAxis() const;
    inline void SetUpdateUpAxis(bool inbool);
    inline bool GetAutoTraverseOffMeshLink() const;
    void SetAutoTraverseOffMeshLink(bool inbool);
    inline bool GetAutoBraking() const;
    void SetAutoBraking(bool inbool);
    inline bool GetAutoRepath() const;
    void SetAutoRepath(bool inbool);

    inline float GetRadius() const;
    inline float GetHeight() const;
    inline float GetBaseOffset() const;

    void CalculateScaledRadiusAndHeight(float* radius, float* height) const;

    int GetAgentTypeID() const;
    void SetAgentTypeID(int value);
    void SetRadius(float value);
    void SetHeight(float value);
    void SetBaseOffset(float baseOffset);

    bool Warp(const Vector3f& newPosition);
    void Move(const Vector3f& motion);
    void Stop();
    void Resume();

    bool IsStopped() const;

    void CompleteOffMeshLink();

    bool UpdateTransformAccess(float dt, TransformAccess ta) const;

    Vector3f GetGroundPosition() const;
    NavMeshPolyRef GetInternalAnimationPolyRef() const;
    void SetInternalAnimationPolyRef(NavMeshPolyRef polyRef);
    void OnNavMeshAdded();
    inline void OnNavMeshCleanup();

    inline bool IsRegistered() const;
    inline CrowdRef GetCrowdRef() const;
    Vector3f GetInternalUpAxis() const;

    void UpdateActiveAgentParameters();

    static TransformChangeSystemHandle s_MoveInterest;
    static TransformChangeSystemHandle s_ScaleInterest;

protected:
    virtual void AddToManager();
    virtual void RemoveFromManager();
    virtual void Reset();
    virtual void SmartReset();

private:

    void AddToCrowdSystem();
    void RemoveFromCrowdSystem();

    void FillAgentParams(CrowdAgentParams& params) const;

    inline Vector3f GetGroundPositionFromTransform() const;
    void SetTransformFromGroundPosition() const;
    void SynchronizeSimulationIfMoved() const;

    int GetCurrentPolygonMask() const;

    const QueryFilter& GetFilter() const;
    const CrowdAgent* GetInternalAgent() const;
    static const NavMesh* GetInternalNavMesh();
    static CrowdManager* GetCrowdManager();

    int m_AgentTypeID;

    float           m_Radius;
    float           m_Height;
    float           m_BaseOffset;
    float           m_Speed;
    float           m_AngularSpeed;
    float           m_Acceleration;
    float           m_StoppingDistance;

    // Internal Crowd system agent index
    CrowdRef        m_AgentRef;
    InstanceID      m_OffMeshConnectionInstanceID;
    NavMeshPolyRef  m_OffMeshConnectionRef;
    // Persistent manager handle
    int             m_ManagerHandle;

    ObstacleAvoidanceType   m_ObstacleAvoidanceType; ///< enum { None = 0, Low Quality, Medium Quality, Good Quality, High Quality }
    UInt32          m_WalkableMask;
    int             m_AvoidancePriority;
    bool            m_AutoTraverseOffMeshLink;
    bool            m_AutoBraking;
    bool            m_AutoRepath;

    bool            m_UpdatePosition : 1;
    bool            m_UpdateRotation : 1;
    bool            m_UpdateUpAxis : 1;

    friend void DrawNavMeshAgent(const NavMeshAgent& agent);
};

inline CrowdRef NavMeshAgent::GetCrowdRef() const
{
    return m_AgentRef;
}

inline Vector3f NavMeshAgent::GetGroundPositionFromTransform() const
{
    const Transform& transform = GetComponent<Transform>();
    return transform.TransformPoint(Vector3f(0, -m_BaseOffset, 0));
}

inline bool NavMeshAgent::InCrowdSystem() const
{
    return m_AgentRef != 0;
}

inline void NavMeshAgent::SetManagerHandle(int handle)
{
    m_ManagerHandle = handle;
}

inline ObstacleAvoidanceType NavMeshAgent::GetObstacleAvoidanceType() const
{
    return m_ObstacleAvoidanceType;
}

inline int NavMeshAgent::GetAvoidancePriority() const
{
    return m_AvoidancePriority;
}

inline float NavMeshAgent::GetSpeed() const
{
    return m_Speed;
}

inline float NavMeshAgent::GetAngularSpeed() const
{
    return m_AngularSpeed;
}

inline float NavMeshAgent::GetAcceleration() const
{
    return m_Acceleration;
}

inline float NavMeshAgent::GetStoppingDistance() const
{
    return m_StoppingDistance;
}

inline bool NavMeshAgent::GetUpdatePosition() const
{
    return m_UpdatePosition;
}

inline void NavMeshAgent::SetUpdateRotation(bool inbool)
{
    m_UpdateRotation = inbool;
}

inline bool NavMeshAgent::GetUpdateRotation() const
{
    return m_UpdateRotation;
}

inline void NavMeshAgent::SetUpdateUpAxis(bool inbool)
{
    m_UpdateUpAxis = inbool;
}

inline bool NavMeshAgent::GetUpdateUpAxis() const
{
    return m_UpdateUpAxis;
}

inline bool NavMeshAgent::GetAutoTraverseOffMeshLink() const
{
    return m_AutoTraverseOffMeshLink;
}

inline bool NavMeshAgent::GetAutoBraking() const
{
    return m_AutoBraking;
}

inline bool NavMeshAgent::GetAutoRepath() const
{
    return m_AutoRepath;
}

inline float NavMeshAgent::GetRadius() const
{
    return m_Radius;
}

inline float NavMeshAgent::GetHeight() const
{
    return m_Height;
}

inline float NavMeshAgent::GetBaseOffset() const
{
    return m_BaseOffset;
}

inline void NavMeshAgent::OnNavMeshCleanup()
{
    RemoveFromCrowdSystem();
}

bool NavMeshAgent::IsRegistered() const
{
    return m_ManagerHandle != -1;
}
