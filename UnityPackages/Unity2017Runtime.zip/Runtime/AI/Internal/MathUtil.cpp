#include "UnityPrefix.h"
#include "MathUtil.h"
#include "Runtime/Math/Vector3.h"
#include <math.h>

float SqrDistancePointSegment2D(float* t, const Vector3f& pt, const Vector3f& s1, const Vector3f& s2)
{
    const float dsx = s2.x - s1.x;
    const float dsz = s2.z - s1.z;
    const float dpx = pt.x - s1.x;
    const float dpz = pt.z - s1.z;
    const float den = dsx * dsx + dsz * dsz;
    if (den == 0)
    {
        *t = 0;
        return dpx * dpx + dpz * dpz;
    }
    float tt = (dsx * dpx + dsz * dpz) / den;
    tt = FloatClamp(tt, 0.0f , 1.0f);
    const float x = tt * dsx - dpx;
    const float z = tt * dsz - dpz;
    *t = tt;
    return x * x + z * z;
}

float SqrDistancePointSegment(float* t, const Vector3f& pt, const Vector3f& s1, const Vector3f& s2)
{
    const Vector3f ds = s2 - s1;
    const Vector3f dp = pt - s1;
    const float den = Dot(ds, ds);
    if (den == 0)
    {
        *t = 0;
        return Dot(dp, dp);
    }
    float tt = Dot(ds, dp) / den;
    tt = FloatClamp(tt, 0.0f , 1.0f);
    const Vector3f v = tt * ds - dp;
    *t = tt;
    return Dot(v, v);
}

bool ClosestHeightPointTriangle(float* h, const Vector3f& p, const Vector3f& a, const Vector3f& b, const Vector3f& c)
{
    const Vector3f v0 = c - a;
    const Vector3f v1 = b - a;
    const Vector3f v2 = p - a;

    const float dot00 = Dot2D(v0, v0);
    const float dot01 = Dot2D(v0, v1);
    const float dot02 = Dot2D(v0, v2);
    const float dot11 = Dot2D(v1, v1);
    const float dot12 = Dot2D(v1, v2);

    // Compute barycentric coordinates
    const float invDenom = 1.0f / (dot00 * dot11 - dot01 * dot01);
    const float u = (dot11 * dot02 - dot01 * dot12) * invDenom;
    const float v = (dot00 * dot12 - dot01 * dot02) * invDenom;

    // The (sloppy) epsilon is needed to allow to get height of points which
    // are interpolated along the edges of the triangles.
    static const float EPS = 1e-4f;

    // If point lies inside the triangle, return interpolated ycoord.
    if (u >= -EPS && v >= -EPS && (u + v) <= 1.0f + EPS)
    {
        *h = a.y + v0.y * u + v1.y * v;
        return true;
    }

    return false;
}

bool IntersectSegmentPoly2D(float* tmin, float* tmax, int* segMin, int* segMax,
    const Vector3f& p0, const Vector3f& p1, const Vector3f* verts, int nverts)
{
    static const float EPS = 0.00000001f;

    float ttmin = 0;
    float ttmax = 1;
    int tSegMin = -1;
    int tSegMax = -1;

    const Vector3f dir = p1 - p0;

    int i = 0;
    for (int j = nverts - 1; i < nverts; j = i++)
    {
        const Vector3f edge = verts[i] - verts[j];
        const Vector3f diff = p0 - verts[j];

        const float n = Perp2D(edge, diff);
        const float d = Perp2D(dir, edge);
        if (fabsf(d) < EPS)
        {
            // S is nearly parallel to this edge
            if (n < 0)
                break;
            else
                continue;
        }
        const float t = n / d;
        if (d < 0)
        {
            // segment S is entering across this edge
            if (t > ttmin)
            {
                ttmin = t;
                tSegMin = j;
                // S enters after leaving polygon
                if (ttmin > ttmax)
                    break;
            }
        }
        else
        {
            // segment S is leaving across this edge
            if (t < ttmax)
            {
                ttmax = t;
                tSegMax = j;
                // S leaves before entering polygon
                if (ttmax < ttmin)
                    break;
            }
        }
    }

    *tmin = ttmin;
    *tmax = ttmax;
    *segMin = tSegMin;
    *segMax = tSegMax;

    return i == nverts;
}
