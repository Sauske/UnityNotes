#pragma once

#include "Crowd/CrowdTypes.h"
#include "NavMesh/FreeList.h"
#include "NavMeshBindingTypes.h"
#include "Runtime/SceneManager/UnitySceneHandle.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Utilities/vector_map.h"

class CrowdManager;
class HeightMeshQuery;
class NavMesh;
class NavMeshAgent;
class NavMeshBuildManager;
class NavMeshCarving;
class NavMeshData;
class NavMeshObstacle;
class NavMeshPath;
class NavMeshQuery;
class OffMeshLink;
class QueryFilter;
class UnityScene;
struct CrowdAgentDebugInfo;
struct NavMeshBuildSettings;
struct NavMeshHit;
struct NavMeshTileData;

struct TileLocation
{
    MinMaxAABB m_Bounds;
    int m_SurfaceID;
    int m_TileIndex;
};

// NavMeshManager is a singleton - persistent across scene-load.
//  Relays script API
//  References the active navmesh components
//  Loading/Unloading navmesh data
//  Schedules crowd/carving sub-system updates

class NavMeshManager
{
    struct SurfaceInstance;
public:

    struct Triangulation
    {
        dynamic_array<SInt32> areas;
        dynamic_array<SInt32> indices;
        dynamic_array<Vector3f> vertices;
    };

    NavMeshManager();
    ~NavMeshManager();

    // NavMeshModule callbacks - called from player loop
    void Update();
    void UpdatePostScript();

    // Script API
    bool Raycast(NavMeshHit* hit, const Vector3f& sourcePosition, const Vector3f& targetPosition, const QueryFilter& filter);
    bool DistanceToEdge(NavMeshHit* hit, const Vector3f& sourcePosition, const QueryFilter& filter);
    bool SamplePosition(NavMeshHit* hit, const Vector3f& sourcePosition, const QueryFilter& filter, float maxDistance);
    int CalculatePolygonPath(NavMeshPath* path, const Vector3f& sourcePosition, const Vector3f& targetPosition, const QueryFilter& filter);
    int CalculatePathCorners(Vector3f* corners, int maxCorners, const NavMeshPath& path) const;
    void Triangulate(NavMeshManager::Triangulation& triangulation) const;

    void SetAvoidancePredictionTime(float t);
    float GetAvoidancePredictionTime() const {return m_AvoidancePredictionTime; }
    void SetPathfindingIterationsPerFrame(int i);
    int GetPathfindingIterationsPerFrame() const {return m_PathfindingIterationsPerFrame; }

    void UpdateAllNavMeshAgentCosts(int areaIndex, float areaCost);
    void ExitPlayMode();

    // Component API
    void RegisterAgent(NavMeshAgent& agent, int& handle);
    void UnregisterAgent(int& handle);

    void RegisterObstacle(NavMeshObstacle& obstacle, int& handle);
    void UnregisterObstacle(int& handle);

    void RegisterOffMeshLink(OffMeshLink& link, int& handle);
    void UnregisterOffMeshLink(int& handle);

    // OffMeshLink runtime manipulation
    void SetOffMeshConnectionCostOverride(NavMeshPolyRef ref, float costOverride);
    void SetOffMeshConnectionActive(NavMeshPolyRef ref, bool active);
    Vector3f GetLinkQueryExtents(int agentTypeID) const;
    NavMeshPolyRef AddOffMeshConnection(const Vector3f& startPos, const Vector3f& endPos,
        InstanceID instanceID, bool twoWay, unsigned char areaType, int agentTypeID);
    void RemoveOffMeshConnection(const NavMeshPolyRef ref);
    bool GetOffMeshConnectionPositions(const NavMeshPolyRef ref, Vector3f* startPos, Vector3f* endPos) const;
    bool IsOffMeshConnectionOccupied(const NavMeshPolyRef ref) const;

    int GetUserID(const NavMeshPolyRef ref) const;
    int GetLinkUserID(int handle) const;
    bool SetLinkUserID(int handle, int userID);

    typedef int NavMeshLinkHandle;
    NavMeshLinkHandle AddLink(const NavMeshLinkData& link, const Vector3f& position, const Quaternionf& rotation);
    void RemoveLink(const NavMeshLinkHandle handle);
    bool IsValidLinkHandle(const NavMeshLinkHandle handle) const;

    // Subsystem accessors
    inline CrowdManager* GetCrowdManager();
    inline NavMeshCarving* GetCarvingSystem();
    inline NavMeshBuildManager* GetNavMeshBuildManager();
    inline const NavMeshQuery* GetInternalNavMeshQuery() const;
    inline const NavMesh* GetInternalNavMesh() const;
    inline const HeightMeshQuery* GetHeightMeshQuery() const;

    // Tile Data API
    void GetSourceTileDataBounds(dynamic_array<TileLocation>& locations) const;
    const NavMeshTileData* GetSourceTileData(int surfaceID, int tileIndex) const;
    const NavMeshBuildSettings& GetNavMeshBuildSettings(int surfaceID) const;
    void RemoveTile(int surfaceID, int tileIndex);
    void RestoreTile(int surfaceID, int tileIndex);
    void RemoveTiles(int surfaceID, const dynamic_array<int>& tileIndices);
    void ReplaceTile(int surfaceID, int tileIndex, unsigned char* tileData, int tileDataSize);

    void UpdateSurface(int surfaceID, const NavMeshBuildSettings& settings, const dynamic_array<int>& tileIndices);

    void LoadNavMeshData(const UnitySceneHandle sceneID, const NavMeshData* navMeshData);
    void UnloadNavMeshData(const UnitySceneHandle sceneID);
    void MergeNavMeshScenes(UnityScene* src, UnityScene* dst);

    int LoadData(const NavMeshData* navMeshData);
    int LoadData(const NavMeshData* navMeshData, const Vector3f& position, const Quaternionf& rotation);
    bool IsValidSurfaceID(int surfaceID) const;
    bool SetSurfaceUserID(int surfaceID, int userID);
    int GetSurfaceUserID(int surfaceID) const;
    void UnloadData(int surfaceID);
    void GetSurfaceIDsFromData(dynamic_array<int>& surfaceIDs, const NavMeshData* navMeshData) const;
    void PurgeData(const NavMeshData* navMeshData);
    void Cleanup();
    void CleanupIfNoData();

#if UNITY_EDITOR
    void EditorTick();
    bool RequestAgentDebugInfo(const CrowdRef agentRef);
    const CrowdAgentDebugInfo* GetAgentDebugInfo(const CrowdRef agentRef) const;
    bool HasPendingAgentDebugInfo() const;
#endif
    int GetLoadedNavMeshDataCount() const;
    const NavMeshData* GetLoadedNavMeshData(int i) const;

private:
    void UpdateNavMeshObstacles();
    void InitializeNavMeshSystems();
    int LoadDataInternal(const NavMeshData* navMeshData, const Vector3f& position, const Quaternionf& rotation);
    void UpdateCarvingImmediately(int surfaceID);

    bool InitializeCrowdSystem();
    void InitializeCarvingSystem();

    Vector3f GetQueryExtents(int agentTypeID) const;
    bool MapPosition(NavMeshPolyRef* mappedPolyRef, Vector3f* mappedPosition, const Vector3f& position, const Vector3f& extents, const QueryFilter& filter) const;

    void NotifyNavMeshAdded();
    void NotifyNavMeshCleanup();
    void UpdateCrowdSystem();
    void UpdateCarving();
    void UpdateCarvingResults();
    void UpdateOffMeshLinks();
    void SyncTileIndicesFromNavMeshData(SurfaceInstance& instance, int surfaceID, const dynamic_array<int>& newTileIndices);

    void CleanupWithError(const char* message);

    float m_AvoidancePredictionTime;
    int m_PathfindingIterationsPerFrame;
    Vector3f m_LegacyQueryExtents;
    Vector3f m_LegacyLinkQueryExtents;


    struct NavMeshObstacleInfo
    {
        NavMeshObstacle* obstacle;
        int carveHandle;
        CrowdRef obstacleRef;
    };

    dynamic_array<NavMeshAgent*> m_Agents;
    dynamic_array<NavMeshObstacleInfo> m_ObstacleInfo;
    dynamic_array<OffMeshLink*> m_Links;

    struct NavMeshLinkInfo
    {
        inline NavMeshLinkInfo() : salt(1), polyRef(0) {}
        inline ~NavMeshLinkInfo() {}

        int salt;
        unsigned int next;
        NavMeshPolyRef polyRef;
    };
    FreeList<NavMeshLinkInfo> m_LinkInfo;

    CrowdManager* m_CrowdSystem;
    NavMeshCarving* m_CarvingSystem;
    NavMeshBuildManager* m_BuildManager;

#if UNITY_EDITOR
    static const int kDebugAgentCount = 10; // Max number of concurrent debug requests.
    CrowdRef m_CrowdAgentDebugRequest[kDebugAgentCount];
    int m_CrowdAgentDebugRequestCount;
    CrowdAgentDebugInfo* m_CrowdAgentDebugInfos;
#endif

    NavMesh* m_NavMesh;
    NavMeshQuery* m_NavMeshQuery;
    HeightMeshQuery* m_HeightMeshQuery;

    struct SurfaceInstance
    {
        const NavMeshData* m_NavMeshData;
        dynamic_array<NavMeshTileRef> m_AddedTileRefs;
        dynamic_array<NavMeshPolyRef> m_AutoOffMeshConnections;
        int m_UserID;
    };
    typedef UNITY_VECTOR_MAP (kMemAI, int, SurfaceInstance) NavMeshSurfaceInstanceMap;
    NavMeshSurfaceInstanceMap m_LoadedSurfaces;

    class NavMeshSceneDataRegistry* m_SceneDataRegistry;
};

inline CrowdManager* NavMeshManager::GetCrowdManager()
{
    return m_CrowdSystem;
}

inline NavMeshBuildManager* NavMeshManager::GetNavMeshBuildManager()
{
    return m_BuildManager;
}

inline const NavMeshQuery* NavMeshManager::GetInternalNavMeshQuery() const
{
    return m_NavMeshQuery;
}

inline const NavMesh* NavMeshManager::GetInternalNavMesh() const
{
    return m_NavMesh;
}

inline const HeightMeshQuery* NavMeshManager::GetHeightMeshQuery() const
{
    return m_HeightMeshQuery;
}

NavMeshManager& GetNavMeshManager();
void InitializeNavMeshManager();
void CleanupNavMeshManager();
