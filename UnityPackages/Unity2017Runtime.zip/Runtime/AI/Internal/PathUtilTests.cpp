#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS
#include "Runtime/Testing/Testing.h"
#include "./PathUtil.h"

UNIT_TEST_SUITE(NavMeshPathUtil)
{
    struct PathUtilFixture
    {
        PathUtilFixture()
        {
            originalPath.push_back(1);
            originalPath.push_back(2);
            originalPath.push_back(3);
            originalPath.push_back(4);
            path = originalPath;
        }

        dynamic_array<NavMeshPolyRef> originalPath;
        dynamic_array<NavMeshPolyRef> path;
    };

    TEST_FIXTURE(PathUtilFixture, Replace_EmptyWithNonEmpty_DoesNothing)
    {
        const NavMeshPolyRef start[] = {5, 6, 7, 8};
        path.clear();

        bool replaced = ReplacePathStart(path, start, ARRAY_SIZE(start));

        CHECK(!replaced);
        CHECK_EQUAL(0, path.size());
    }

    TEST_FIXTURE(PathUtilFixture, Replace_WithDisjointPath_DoesNothing)
    {
        const NavMeshPolyRef start[] = {5, 6, 7, 8};

        bool replaced = ReplacePathStart(path, start, ARRAY_SIZE(start));

        CHECK(!replaced);
        CHECK_EQUAL(originalPath.size(), path.size());
        CHECK_ARRAY_EQUAL(originalPath, path, path.size());
    }

    TEST_FIXTURE(PathUtilFixture, Replace_WithSameFirstElement_ReturnsOriginal)
    {
        const NavMeshPolyRef start[] = {1};

        bool replaced = ReplacePathStart(path, start, ARRAY_SIZE(start));

        CHECK(replaced);
        CHECK_EQUAL(originalPath.size(), path.size());
        CHECK_ARRAY_EQUAL(originalPath, path, path.size());
    }

    TEST_FIXTURE(PathUtilFixture, Replace_WithSameLastElement_ReturnsLastElement)
    {
        const NavMeshPolyRef start[] = {4};
        const NavMeshPolyRef expected[] = {4};

        bool replaced = ReplacePathStart(path, start, ARRAY_SIZE(start));

        CHECK(replaced);
        CHECK_EQUAL(ARRAY_SIZE(expected), path.size());
        CHECK_ARRAY_EQUAL(expected, path, path.size());
    }

    TEST_FIXTURE(PathUtilFixture, Replace_WithDifferentElements_CanGrow)
    {
        const NavMeshPolyRef start[] = {9, 8, 7, 6, 5, 4};
        const NavMeshPolyRef expected[] = {9, 8, 7, 6, 5, 4};

        bool replaced = ReplacePathStart(path, start, ARRAY_SIZE(start));

        CHECK(replaced);
        CHECK_EQUAL(ARRAY_SIZE(expected), path.size());
        CHECK_ARRAY_EQUAL(expected, path, path.size());
        CHECK(path.size() > originalPath.size());
    }

    TEST_FIXTURE(PathUtilFixture, Replace_WithCommonElementsNotAtExtremePositions_ReplacesElements)
    {
        const NavMeshPolyRef start[] = {5, 6, 2, 7};
        const NavMeshPolyRef expected[] = {5, 6, 2, 3, 4};

        bool replaced = ReplacePathStart(path, start, ARRAY_SIZE(start));

        CHECK(replaced);
        CHECK_EQUAL(ARRAY_SIZE(expected), path.size());
        CHECK_ARRAY_EQUAL(expected, path, path.size());
    }

    TEST_FIXTURE(PathUtilFixture, Replace_WithSameStartElements_ReturnsOriginal)
    {
        const NavMeshPolyRef start[] = {1, 2, 3};

        bool replaced = ReplacePathStart(path, start, ARRAY_SIZE(start));

        CHECK(replaced);
        CHECK_EQUAL(originalPath.size(), path.size());
        CHECK_ARRAY_EQUAL(originalPath, path, path.size());
    }

    TEST_FIXTURE(PathUtilFixture, Replace_WithNewStartElements_ExtendsPath)
    {
        const NavMeshPolyRef start[] = {10, 1};
        const NavMeshPolyRef expected[] = {10, 1, 2, 3, 4};

        bool replaced = ReplacePathStart(path, start, ARRAY_SIZE(start));

        CHECK(replaced);
        CHECK_EQUAL(ARRAY_SIZE(expected), path.size());
        CHECK_ARRAY_EQUAL(expected, path, path.size());
    }

    TEST_FIXTURE(PathUtilFixture, Replace_WithNewAndSameElements_PrependsAndShortensPath)
    {
        const NavMeshPolyRef start[] = {10, 3};
        const NavMeshPolyRef expected[] = {10, 3, 4};

        bool replaced = ReplacePathStart(path, start, ARRAY_SIZE(start));

        CHECK(replaced);
        CHECK_EQUAL(ARRAY_SIZE(expected), path.size());
        CHECK_ARRAY_EQUAL(expected, path, path.size());
    }

    // Reverse variant below

    TEST_FIXTURE(PathUtilFixture, ReplaceReverse_EmptyWithNonEmpty_DoesNothing)
    {
        const NavMeshPolyRef start[] = {5, 6, 7, 8};
        path.clear();

        bool replaced = ReplacePathStartReverse(path, start, ARRAY_SIZE(start));

        CHECK(!replaced);
        CHECK_EQUAL(0, path.size());
    }

    TEST_FIXTURE(PathUtilFixture, ReplaceReverse_WithDisjointPath_DoesNothing)
    {
        const NavMeshPolyRef start[] = {5, 6, 7, 8};

        bool replaced = ReplacePathStartReverse(path, start, ARRAY_SIZE(start));

        CHECK(!replaced);
        CHECK_EQUAL(originalPath.size(), path.size());
        CHECK_ARRAY_EQUAL(originalPath, path, path.size());
    }

    TEST_FIXTURE(PathUtilFixture, ReplaceReverse_WithSameFirstElement_ReturnsOriginal)
    {
        const NavMeshPolyRef start[] = {1};

        bool replaced = ReplacePathStartReverse(path, start, ARRAY_SIZE(start));

        CHECK(replaced);
        CHECK_EQUAL(originalPath.size(), path.size());
        CHECK_ARRAY_EQUAL(originalPath, path, path.size());
    }

    TEST_FIXTURE(PathUtilFixture, ReplaceReverse_WithSameLastElement_ReturnsLastElement)
    {
        const NavMeshPolyRef start[] = {4};
        const NavMeshPolyRef expected[] = {4};

        bool replaced = ReplacePathStartReverse(path, start, ARRAY_SIZE(start));

        CHECK(replaced);
        CHECK_EQUAL(ARRAY_SIZE(expected), path.size());
        CHECK_ARRAY_EQUAL(expected, path, path.size());
    }

    TEST_FIXTURE(PathUtilFixture, ReplaceReverse_WithDifferentElements_CanGrow)
    {
        const NavMeshPolyRef start[] = {1, 10, 11, 12, 13, 14};
        const NavMeshPolyRef expected[] = {14, 13, 12, 11, 10, 1, 2, 3, 4};

        bool replaced = ReplacePathStartReverse(path, start, ARRAY_SIZE(start));

        CHECK(replaced);
        CHECK_EQUAL(ARRAY_SIZE(expected), path.size());
        CHECK_ARRAY_EQUAL(expected, path, path.size());
        CHECK(path.size() > originalPath.size());
    }

    TEST_FIXTURE(PathUtilFixture, ReplaceReverse_WithCommonElementsNotAtExtremePositions_ReplacesElements)
    {
        const NavMeshPolyRef start[] = {5, 6, 2, 7};
        const NavMeshPolyRef expected[] = {7, 2, 3, 4};

        bool replaced = ReplacePathStartReverse(path, start, ARRAY_SIZE(start));

        CHECK(replaced);
        CHECK_EQUAL(ARRAY_SIZE(expected), path.size());
        CHECK_ARRAY_EQUAL(expected, path, path.size());
    }

    TEST_FIXTURE(PathUtilFixture, ReplaceReverse_WithSameStartElements_ShortensPath)
    {
        const NavMeshPolyRef start[] = {1, 2, 3};
        const NavMeshPolyRef expected[] = {3, 4};

        bool replaced = ReplacePathStartReverse(path, start, ARRAY_SIZE(start));

        CHECK(replaced);
        CHECK_EQUAL(ARRAY_SIZE(expected), path.size());
        CHECK_ARRAY_EQUAL(expected, path, path.size());
    }

    TEST_FIXTURE(PathUtilFixture, ReplaceReverse_WithNewStartElements_ExtendsPath)
    {
        const NavMeshPolyRef start[] = {1, 10};
        const NavMeshPolyRef expected[] = {10, 1, 2, 3, 4};

        bool replaced = ReplacePathStartReverse(path, start, ARRAY_SIZE(start));

        CHECK(replaced);
        CHECK_EQUAL(ARRAY_SIZE(expected), path.size());
        CHECK_ARRAY_EQUAL(expected, path, path.size());
    }

    TEST_FIXTURE(PathUtilFixture, ReplaceReverse_WithNewAndSameElements_PrependsAndShortensPath)
    {
        const NavMeshPolyRef start[] = {3, 10};
        const NavMeshPolyRef expected[] = {10, 3, 4};

        bool replaced = ReplacePathStartReverse(path, start, ARRAY_SIZE(start));

        CHECK(replaced);
        CHECK_EQUAL(ARRAY_SIZE(expected), path.size());
        CHECK_ARRAY_EQUAL(expected, path, path.size());
    }
}

#endif
