#include "UnityPrefix.h"
#include "RuntimeNavMeshBuilder.h"
#include "CreateNavMeshTileData.h"
#include "Runtime/AI/Internal/NavMeshBuildSettings.h"
#include "Runtime/AI/Internal/NavMeshData.h"
#include "Runtime/AI/Internal/NavMeshProjectSettings.h"
#include "Runtime/AI/Internal/Builder/RuntimeNavMeshBuilderTypes.h"
#include "Runtime/BaseClasses/IsPlaying.h"
#include "Runtime/Graphics/Mesh/Mesh.h"
#include "Runtime/Geometry/Intersection.h"
#include "Runtime/Utilities/StrideIterator.h"
#include "External/Recast/Recast/Include/Recast.h"
#include "External/Recast/Recast/Include/RecastAlloc.h"
#include "Runtime/Interfaces/ITerrainManager.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Utilities/Hash128.h"
#include "External/HashFunctions/SpookyV2.h"

#if UNITY_EDITOR
#include "Editor/Src/AI/Internal/Visualization/NavMeshBuildDebugManager.h"
#endif

#include "RecastDebugContext.h"
#include "Runtime/Profiler/Profiler.h"
PROFILER_INFORMATION(gRuntimeBuildData, "NavMesh.BuildNavMeshData", kProfilerAI)
PROFILER_INFORMATION(gRuntimeBuildUpdate, "NavMesh.UpdateNavMeshData", kProfilerAI)
PROFILER_INFORMATION(gRuntimeBuildCombine, "NavMesh.CombineTiles", kProfilerAI)
PROFILER_INFORMATION(gRuntimeBuildCreateData, "NavMesh.CreateData", kProfilerAI)
PROFILER_INFORMATION(gRuntimeBuildTileMesh, "NavMesh.TileMesh", kProfilerAI)
PROFILER_INFORMATION(gRuntimeBuildExtractTerrainMesh, "NavMesh.ExtractTerrainMesh", kProfilerAI)

PROFILER_INFORMATION(gRuntimeBuildMeshTriangles, "NavMesh.MeshTriangles", kProfilerAI)
PROFILER_INFORMATION(gRuntimeBuildRasterize, "NavMesh.Rasterize", kProfilerAI)

PROFILER_INFORMATION(gRuntimeBuildHashTile, "NavMesh.HashTile", kProfilerAI)
PROFILER_INFORMATION(gRuntimeBuildHashSource, "NavMesh.HashSource", kProfilerAI)

PROFILER_INFORMATION(gRuntimeBuildAcquire, "NavMesh.AcquireSharedMesh", kProfilerAI)
PROFILER_INFORMATION(gRuntimeBuildDebugDraw, "NavMesh.DebugDraw", kProfilerAI)
PROFILER_INFORMATION(gRuntimeBuildRelease, "NavMesh.ReleaseSharedMesh", kProfilerAI)
PROFILER_INFORMATION(gRuntimeBuildIntegrate, "NavMesh.Integrate", kProfilerAI)
PROFILER_INFORMATION(gRuntimeBuildIntegrateRemoveTiles, "NavMesh.Integrate.RemoveTiles", kProfilerAI)
PROFILER_INFORMATION(gRuntimeBuildIntegrateUpdateTiles, "NavMesh.Integrate.UpdateTiles", kProfilerAI)
PROFILER_INFORMATION(gRuntimeBuildIntegrateUpdateSurface, "NavMesh.Integrate.UpdateSurface", kProfilerAI)

PROFILER_INFORMATION(gRecastAlloc, "NavMesh.Recast.Alloc", kProfilerAI)
PROFILER_INFORMATION(gRecastFree, "NavMesh.Recast.Free", kProfilerAI)
PROFILER_INFORMATION(gNavMeshDestroyTempMesh, "NavMesh.DestroyTempMesh", kProfilerAI)

const MemLabelId jobAllocLabel = kMemAI;

// Internal build representation for navmesh sources - consider SoA layout
struct SharedMeshBuildSource
{
    // All: Out
    MinMaxAABB bounds;
    // All: In-Out
    Matrix4x4f transform;

    // All: In
    UInt8 areaTag;
    UInt8 shape;          // 'NavMeshBuildSourceShape' in a byte

    // Mesh: In
    AABB localBounds;
    SharedMeshData* sharedMeshData;

    // Primitives: In
    Vector3f size;
};

static bool CalculateTriangleData(NavMeshTriangleData* triangleData, const SharedMeshBuildSource& src);
static void RasterizeModifier(const SharedMeshBuildSource& src, const rcConfig& config, rcContext& context, rcCompactHeightfield& chf);
static void CreateCubeMesh(NavMeshTriangleData* triangleData, const Matrix4x4f& transform, const Vector3f& extents);
static void CreateSphereMesh(NavMeshTriangleData* triangleData, const Matrix4x4f& transform,
    const float radius, const int lats, const int longs);
static void CreateCapsuleMesh(NavMeshTriangleData* triangleData, const Matrix4x4f& transform,
    const float radius, const float halfHeight, const int lats, const int longs);

static bool BuildTileMesh(int ix, int iz, const SharedMeshBuildSource* sources, size_t nsources, const rcConfig& config,
    struct TileAllocations& mem);

static void CreateEmptyTile(int ix, int iz, const NavMeshBuildSettings& settings, NavMeshTileData* tileData);
static bool CreateTileData(int ix, int iz, const rcConfig& config, const NavMeshBuildSettings& settings,
    struct TileAllocations& mem, NavMeshTileData* tileData);

static bool ConstrainConfigBounds(rcConfig& cfg, int ix, int iz, const rcConfig& config);
static int CalculateTileIndices(dynamic_array<int>& tileXZ, const rcConfig& config);

static void TransformSources(dynamic_array<SharedMeshBuildSource>& bsources, const Vector3f& position, const Quaternionf& rotation);
static MinMaxAABB CombineAndCullBounds(dynamic_array<SharedMeshBuildSource>& bsources, const MinMaxAABB& bounds);

static void ConfigureConfig(rcConfig& config, const NavMeshBuildSettings& settings, const MinMaxAABB& bounds)
{
    memset(&config, 0, sizeof(config));

    rcVcopy(config.bmin, bounds.m_Min.GetPtr());
    rcVcopy(config.bmax, bounds.m_Max.GetPtr());
    config.bmax[1] += settings.agentHeight + 0.1f; // Make sure the agent can stand at the top.

    // Clamp voxel size to sane range.
    config.cs = std::max(0.01f, settings.cellSize);

    // Height needs more precision so that walkableClimb is not too prone to rasterization errors.
    config.ch = config.cs * 0.5f;

    // Some places inside Recast store height as a byte, make sure the ratio between
    // the agent height (plus climb) and cell height does not exceed this limit.
    if ((int)ceilf((settings.agentHeight + settings.agentClimb) / config.ch) > 255)
    {
        const float cellHeight = (settings.agentHeight + settings.agentClimb) / 255.0f;
        config.ch = cellHeight;
    }

    // Warn about too large vertical dimension and adjust the cell height to fit the whole world.
    float worldHeight = config.bmax[1] - config.bmin[1];
    int worldHeightVoxels = (int)ceilf(worldHeight / config.ch);
    if (worldHeightVoxels >= RC_SPAN_MAX_HEIGHT)
    {
        config.ch = worldHeight / (float)(RC_SPAN_MAX_HEIGHT);
    }

    config.walkableSlopeAngle = clamp(settings.agentSlope, 0.1f, 90.0f);
    config.walkableHeight = (int)floorf(settings.agentHeight / config.ch);
    config.walkableClimb = (int)ceilf(settings.agentClimb / config.ch);
    // Bias the conversion a little so that inputs which intent to match certain radius/cs ratio will be treated correctly.
    config.walkableRadius = std::max(0, (int)ceilf(settings.agentRadius / config.cs - config.cs * 0.01f));
    config.maxEdgeLen = 0;
    config.maxSimplificationError = 1.3f;

    // Recast assumes that walkableClimb is less than walkableHeight when neighbour cell access is calculated.
    // Step height is clamped to agent height on validation, but it might get equal or larger than agent height because or rounding.
    if (config.walkableClimb >= config.walkableHeight)
        config.walkableClimb = std::max(0, config.walkableHeight - 1);

    config.minRegionArea = (int)(settings.minRegionArea / (config.cs * config.cs));

    config.tileSize = settings.tileSize;
    config.mergeRegionArea = 400;
    config.maxVertsPerPoly = kNavMeshVertsPerPoly;
    config.detailSampleDist = config.cs * 6.0f;
    config.detailSampleMaxError = config.ch * 1.0f;

    rcCalcGridSize(config.bmin, config.bmax, config.cs, &config.width, &config.height);

    // Adjust for tile border
    config.borderSize = config.walkableRadius + 3;
    config.width  = config.tileSize + 2 * config.borderSize;
    config.height = config.tileSize + 2 * config.borderSize;
}

static void RasterizeModifier(const SharedMeshBuildSource& src, const rcConfig& config, rcContext& context, rcCompactHeightfield& chf)
{
    if (src.shape != kNavMeshBuildSourceModifierBox)
        return;

    if (config.bmin[0] > src.bounds.m_Max[0]
        ||  config.bmin[2] > src.bounds.m_Max[2]
        ||  config.bmax[0] < src.bounds.m_Min[0]
        ||  config.bmax[2] < src.bounds.m_Min[2])
        return;

    const Vector3f center = src.transform.GetPosition();
    const Vector3f axisX = src.transform.GetAxisX();
    const Vector3f axisY = src.transform.GetAxisY();
    const Vector3f axisZ = src.transform.GetAxisZ();
    const Vector3f extents = Abs(src.size) * 0.5f;

    float planes[6 * 4] =
    {
        axisX.x, axisX.y, axisX.z, -Dot(axisX, center) - extents.x,
        -axisX.x, -axisX.y, -axisX.z, -Dot(-axisX, center) - extents.x,
        axisY.x, axisY.y, axisY.z, -Dot(axisY, center) - extents.y,
        -axisY.x, -axisY.y, -axisY.z, -Dot(-axisY, center) - extents.y,
        axisZ.x, axisZ.y, axisZ.z, -Dot(axisZ, center) - extents.z,
        -axisZ.x, -axisZ.y, -axisZ.z, -Dot(-axisZ, center) - extents.z,
    };

    UInt8 area = RC_WALKABLE_AREA + src.areaTag;

    if (src.areaTag == NavMeshProjectSettings::kNotWalkable)
        area = RC_NULL_AREA;

    rcMarkConvexPolyhedraArea(&context, src.bounds.m_Min.GetPtr(), src.bounds.m_Max.GetPtr(),
        planes, 6, area, chf);
}

static bool PrepareMeshSource(const SharedMeshBuildSource& src, const rcConfig& config, rcContext& context,
    NavMeshTriangleData& triData, dynamic_array<UInt8>& triAreas)
{
    if (!CalculateTriangleData(&triData, src))
        return false;

    // ComputeNavMesh triangle area
    const int triangleCount = triData.indices.size() / 3;

    // Not walkable area has to be tagged specifically, since it will be filtered later
    if (src.areaTag == NavMeshProjectSettings::kNotWalkable)
    {
        triAreas.resize_initialized(triangleCount, RC_FORCE_UNWALKABLE_AREA);
    }
    else
    {
        triAreas.resize_initialized(triangleCount, 0);
        const int* indexData = (int*)&triData.indices[0];
        rcMarkWalkableTriangles(&context, config.walkableSlopeAngle, triData.vertices[0].GetPtr(), triData.vertices.size(), indexData, triangleCount, &triAreas[0]);

        // during voxelization we use RC_WALKABLE_AREA + type. After voxelization we transform it back into areaType bits.
        for (size_t i = 0; i < triAreas.size(); ++i)
        {
            if (triAreas[i] != RC_WALKABLE_AREA)
                continue;

            triAreas[i] = RC_WALKABLE_AREA + src.areaTag;
            Assert(triAreas[i] < RC_FORCE_UNWALKABLE_AREA);
        }
    }

    return true;
}

static void RasterizeMesh(const SharedMeshBuildSource& src, const rcConfig& config, rcContext& context, rcHeightfield& heightfield, NavMeshTriangleData* debugTriData, dynamic_array<UInt8>* debugTriAreas)
{
    PROFILER_AUTO(gRuntimeBuildRasterize, NULL);

    if (config.bmin[0] > src.bounds.m_Max[0]
        ||  config.bmin[2] > src.bounds.m_Max[2]
        ||  config.bmax[0] < src.bounds.m_Min[0]
        ||  config.bmax[2] < src.bounds.m_Min[2])
        return;

    NavMeshTriangleData triData;
    dynamic_array<UInt8> triAreas(kMemTempAlloc);

    if (!PrepareMeshSource(src, config, context, triData, triAreas))
        return;

    // Rasterize into the heightfield
    const int triangleCount = triData.indices.size() / 3;
    const int* indexData = (int*)&triData.indices[0];
    rcRasterizeTriangles(&context, triData.vertices[0].GetPtr(), triData.vertices.size(), indexData, &triAreas[0], triangleCount, heightfield, config.walkableClimb);

#if UNITY_EDITOR
    if (debugTriData)
    {
        if (triData.vertices.size() < UINT_MAX - debugTriData->vertices.size())
        {
            const size_t verticesBase = debugTriData->vertices.size();
            const size_t indicesBase = debugTriData->indices.size();
            debugTriData->vertices.insert(debugTriData->vertices.end(), triData.vertices.begin(), triData.vertices.end());
            debugTriData->indices.insert(debugTriData->indices.end(), triData.indices.begin(), triData.indices.end());
            for (int i = indicesBase; i < debugTriData->indices.size(); ++i)
            {
                debugTriData->indices[i] += verticesBase;
            }
        }
        else
        {
            ErrorStringMsg("Triangle data is too large to be appended to the NavMesh builder debug information.");
        }
    }
    if (debugTriAreas)
    {
        debugTriAreas->insert(debugTriAreas->end(), triAreas.begin(), triAreas.end());
    }
#endif
}

struct BuildNavMeshInfo
{
    BuildNavMeshInfo(MemLabelId label)
        : sources(label)
        , tileXZ(label)
        , removeTileIDs(label)
        , cancel(false)
    {
    }

    // Shared job input
    NavMeshBuildSettings settings;
    rcConfig config;
    dynamic_array<SharedMeshBuildSource> sources;
    Vector3f buildPosition;
    Quaternionf buildRotation;

    // Per job input
    dynamic_array<int> tileXZ;

    // Per job output
    NavMeshTileDataVector tiles;

    //NavMeshData* data;
    //AABB localBounds;
    JobFence fence;
    dynamic_array<int> removeTileIDs;
    bool cancel;
};

// Classify the tiles by finding hashes - returns the indices of old tiles to remove and new tiles to compute.
// The computed index arrays are both in ascending order.
// At this stage it's assumed that 'newTiles' contain the updated hashes.
static void ClassifyTilesToRemoveAndCompute(const NavMeshTileDataVector& oldTiles, const NavMeshTileDataVector& newTiles
    , dynamic_array<int>& removeOldIDs, dynamic_array<int>& computeTileIDs)
{
    const size_t oldCount = oldTiles.size();
    const size_t newCount = newTiles.size();

    // Identify removed tile ids (indices into the 'oldTiles' vector)
    for (size_t i = 0; i < oldCount; ++i)
    {
        size_t j = 0;
        while (j != newCount && newTiles[j].m_Hash != oldTiles[i].m_Hash)
            ++j;

        if (j == newCount)
            removeOldIDs.push_back(i);
    }

    // Identify added tile ids (indices into the 'newTiles' vector)
    for (size_t i = 0; i < newCount; ++i)
    {
        if (newTiles[i].m_Hash == Hash128())
            continue;

        size_t j = 0;
        while (j != oldCount && oldTiles[j].m_Hash != newTiles[i].m_Hash)
            ++j;

        if (j == oldCount)
            computeTileIDs.push_back(i);
    }
}

// In-place compact the tiles to compute and their xz locations - given a list of indices sorted in ascending order
static int CompactTilesAndLocations(const dynamic_array<int>& sortedIndices, NavMeshTileDataVector& tiles, dynamic_array<int>& tileXZ)
{
    const size_t count = sortedIndices.size();

    int iwrite = 0;
    for (size_t i = 0; i < count; ++i)
    {
        const int j = sortedIndices[i];

        AssertMsg(iwrite <= j, "CompactTilesAndLocations: Write index must be less than read index for in-place compact");

        if (iwrite < j)
        {
            tileXZ[2 * iwrite + 0] = tileXZ[2 * j + 0];
            tileXZ[2 * iwrite + 1] = tileXZ[2 * j + 1];
            tiles[iwrite].m_Hash = tiles[j].m_Hash;
        }
        iwrite++;
    }

    tiles.resize(iwrite);
    tileXZ.resize_uninitialized(2 * iwrite);

    return iwrite;
}

static void CalculateBuildSourceHash(const SharedMeshBuildSource& src, Hash128& hashInOut)
{
    PROFILER_AUTO(gRuntimeBuildHashSource, NULL)

    HashValue(src.transform, hashInOut);
    HashValue(src.areaTag, hashInOut);
    HashValue(src.shape, hashInOut);

    if (src.shape == kNavMeshBuildSourceMesh)
    {
        // Hash vertices
        const VertexData& vertexData = src.sharedMeshData->GetVertexData();
        StrideIterator<Vector3f> it = vertexData.MakeStrideIterator<Vector3f>(kShaderChannelVertex);
        StrideIterator<Vector3f> end = vertexData.MakeEndIterator<Vector3f>(kShaderChannelVertex);
        for (; it != end; ++it)
            HashValue(*it, hashInOut);

        // Hash indices
        const SharedMeshData::IndexContainer& indices = src.sharedMeshData->GetIndexBuffer();
        SpookyHash::Hash128(&indices[0], sizeof(indices[0]) * indices.size(), &hashInOut.hashData.u64[0], &hashInOut.hashData.u64[1]);
    }
    else
    {
        // src.shape == kNavMeshBuildSourceBox, src.shape == kNavMeshBuildSourceSphere, src.shape == kNavMeshBuildSourceCapsule
        HashValue(src.size, hashInOut);
    }
}

static void ComputeTileHashJob(struct BuildNavMeshInfo* info, unsigned int i)
{
    PROFILER_AUTO(gRuntimeBuildHashTile, NULL);

    // Initialize the null hash - can be skipped at a later stage
    info->tiles[i].m_Hash = Hash128();

    if (info->cancel)
        return;

    const int ix = info->tileXZ[2 * i + 0];
    const int iz = info->tileXZ[2 * i + 1];

    rcConfig cfg;
    if (!ConstrainConfigBounds(cfg, ix, iz, info->config))
        return;

    const Vector3f tileMin(cfg.bmin);
    const Vector3f tileMax(cfg.bmax);
    const MinMaxAABB tileBounds(tileMin, tileMax);

    Hash128 hash;
    HashValue(info->settings, hash);
    // Hash tile location
    HashValue(ix, hash);
    HashValue(iz, hash);
    // Hash potentially clamped tile bounds
    HashValue(tileMin, hash);
    HashValue(tileMax, hash);

    const size_t nsources = info->sources.size();
    bool hasSources = false;
    for (size_t k = 0; k < nsources; ++k)
    {
        const SharedMeshBuildSource& src = info->sources[k];
        if (IntersectAABBAABB(src.bounds, tileBounds))
        {
            CalculateBuildSourceHash(src, hash);
            hasSources = true;
        }
    }

    if (hasSources)
        info->tiles[i].m_Hash = hash;
}

static void ComputeTileMeshJob(struct BuildNavMeshInfo* info, unsigned int i)
{
    PROFILER_AUTO(gRuntimeBuildTileMesh, NULL);
    if (info->cancel)
        return;

    const int ix = info->tileXZ[2 * i + 0];
    const int iz = info->tileXZ[2 * i + 1];
    const rcConfig& config = info->config;
    const NavMeshBuildSettings& settings = info->settings;

    NavMeshTileData* tile = &info->tiles[i];
    Assert(tile != NULL);

    TileAllocations mem;
    const bool tileMeshOK = BuildTileMesh(ix, iz, info->sources.begin(), info->sources.size(), config, mem);

#if UNITY_EDITOR
    const NavMeshBuildDebugFlags debugFlags = info->settings.debug.GetFlags();
    if (debugFlags != kDebugNone)
    {
        NavMeshBuildDebugManager::SerializeBuildData(mem, debugFlags, tile->m_DebugData);
    }
    else
    {
        tile->m_DebugData.clear();
    }
#endif

    if (tileMeshOK && CreateTileData(ix, iz, config, settings, mem, tile))
        return;

    CreateEmptyTile(ix, iz, settings, tile);
}

// Calculate config to match a given tile - constrains bounds to world bounds
static bool ConstrainConfigBounds(rcConfig& cfg, int ix, int iz, const rcConfig& config)
{
    // Quantize world bounds
    float cs1 = 1.0f / config.cs;
    const int quantWorldMinX = (int)floorf(config.bmin[0] * cs1);
    const int quantWorldMinZ = (int)floorf(config.bmin[2] * cs1);
    const int quantWorldMaxX = (int)ceilf(config.bmax[0] * cs1);
    const int quantWorldMaxZ = (int)ceilf(config.bmax[2] * cs1);

    // Constraint to world bounds.
    const int minX = std::max(ix * config.tileSize, quantWorldMinX);
    const int minZ = std::max(iz * config.tileSize, quantWorldMinZ);
    const int maxX = std::min(ix * config.tileSize + config.tileSize, quantWorldMaxX);
    const int maxZ = std::min(iz * config.tileSize + config.tileSize, quantWorldMaxZ);

    // Skip if outside world bounds
    if (minX >= maxX || minZ >= maxZ)
        return false;

    // Patch config bounds for this tile
    cfg = config;

    // Keep vertical world bounds. Expand x,z by border size.
    cfg.bmin[0] = (minX - cfg.borderSize) * cfg.cs;
    cfg.bmin[2] = (minZ - cfg.borderSize) * cfg.cs;
    cfg.bmax[0] = (maxX + cfg.borderSize) * cfg.cs;
    cfg.bmax[2] = (maxZ + cfg.borderSize) * cfg.cs;

    cfg.width = (maxX - minX) + cfg.borderSize * 2;
    cfg.height = (maxZ - minZ) + cfg.borderSize * 2;
    return true;
}

// Build tile coordinate index list with x,z pairs
// Returns the number of tiles covered
static int CalculateTileIndices(dynamic_array<int>& tileXZ, const rcConfig& config)
{
    // Calculate the ranges for covered tiles
    const Vector3f worldMin(config.bmin);
    const Vector3f worldMax(config.bmax);
    const float tileSize = config.tileSize * config.cs;

    const int minX = (int)floorf(worldMin.x / tileSize);
    const int minZ = (int)floorf(worldMin.z / tileSize);
    const int maxX = (int)floorf(worldMax.x / tileSize);
    const int maxZ = (int)floorf(worldMax.z / tileSize);

    const int tileCount = (maxX - minX + 1) * (maxZ - minZ + 1);

    // Build tile coordinate list with x,z pairs
    tileXZ.resize_uninitialized(2 * tileCount);

    int k = 0;
    for (int iz = minZ; iz <= maxZ; ++iz)
    {
        for (int ix = minX; ix <= maxX; ++ix)
        {
            tileXZ[k++] = ix;
            tileXZ[k++] = iz;
        }
    }
    return tileCount;
}

static bool BuildTileMesh(int ix, int iz, const SharedMeshBuildSource* sources, size_t nsources, const rcConfig& config, struct TileAllocations& mem)
{
    rcConfig cfg;
    if (!ConstrainConfigBounds(cfg, ix, iz, config))
        return true;

    mem.m_ownsData = true;

    //  Step 1. create height field
    mem.m_polyMesh = rcAllocPolyMesh();
    if (!mem.m_polyMesh)
        return false;

    mem.m_detailMesh = rcAllocPolyMeshDetail();
    if (!mem.m_detailMesh)
        return false;

    mem.m_heightField = rcAllocHeightfield();
    if (!mem.m_heightField)
        return false;

    mem.m_cset = rcAllocContourSet();
    if (!mem.m_cset)
        return false;

    RecastDebugContext context(true);
    if (!rcCreateHeightfield(&context, *mem.m_heightField, cfg.width, cfg.height, cfg.bmin, cfg.bmax, cfg.cs, cfg.ch))
        return false;

    // Step 2. Rasterize all geometry
    for (size_t i = 0; i < nsources; ++i)
        RasterizeMesh(sources[i], cfg, context, *mem.m_heightField, &mem.m_triData, &mem.m_triAreas);

    // Step 3. Filter walkable surfaces.

    // Once all geometry is rasterized, we do initial pass of filtering to
    // remove unwanted overhangs caused by the conservative rasterization
    // as well as filter spans where the character cannot possibly stand.
    rcFilterForceUnwalkableArea(&context, *mem.m_heightField);
    rcFilterLowHangingWalkableObstacles(&context, cfg.walkableClimb, *mem.m_heightField);
    rcFilterLedgeSpans(&context, cfg.walkableHeight, cfg.walkableClimb, *mem.m_heightField);
    rcFilterWalkableLowHeightSpans(&context, cfg.walkableHeight, *mem.m_heightField);

    // Skip if tile is empty, i.e. it has no spans allocated
    if (mem.m_heightField->freelist == NULL)
        return true;

    // Step 4. Partition walkable surface to simple regions.

    // Compact the heightfield so that it is faster to handle from now on.
    // This will result more cache coherent data as well as the neighbours
    // between walkable cells will be calculated.
    mem.m_chf = rcAllocCompactHeightfield();
    if (!mem.m_chf)
        return false;

    if (!rcBuildCompactHeightfield(&context, cfg.walkableHeight, cfg.walkableClimb, *mem.m_heightField, *mem.m_chf))
        return false;

    for (size_t i = 0; i < nsources; ++i)
        RasterizeModifier(sources[i], cfg, context, *mem.m_chf);

    // Erode the walkable area by agent radius.
    if (!rcErodeWalkableArea(&context, cfg.walkableRadius, *mem.m_chf))
        return false;

    // Partition the walkable surface into non-overlapping regions (may contain holes, handled later in contour creation).
    if (!rcBuildLayerRegions(&context, *mem.m_chf, cfg.borderSize, cfg.minRegionArea))
        return false;

    // Step 5. Trace and simplify region contours.

    // Create contours.
    if (!rcBuildContours(&context, *mem.m_chf, cfg.maxSimplificationError, cfg.maxEdgeLen, *mem.m_cset))
        return false;

    // Skip if tile is empty.
    if (!mem.m_cset->nconts)
        return true;

    // Step 6. Build polygons mesh from contours.

    // Build polygon navmesh from the contours.
    if (!rcBuildPolyMesh(&context, *mem.m_cset, cfg.maxVertsPerPoly, *mem.m_polyMesh))
        return false;

    // Step 7. Set polygon flags.

    // Update poly flags from areas.
    for (int i = 0; i < mem.m_polyMesh->npolys; ++i)
    {
        unsigned int area = mem.m_polyMesh->areas[i] - RC_WALKABLE_AREA;
        Assert(area < 32);

        // store area in flags as walkable mask
        mem.m_polyMesh->flags[i] = 1 << area;
        mem.m_polyMesh->areas[i] = area;
    }

    // Step 8. Create detail mesh which allows to access approximate height on each polygon.

    if (!rcBuildPolyMeshDetail(&context, *mem.m_polyMesh, *mem.m_chf, cfg.detailSampleDist, cfg.detailSampleMaxError, *mem.m_detailMesh))
        return false;

    return true;
}

static void CreateEmptyTile(int ix, int iz, const NavMeshBuildSettings& settings, NavMeshTileData* tileData)
{
    tileData->m_MeshData.resize_initialized(sizeof(NavMeshDataHeader), 0);
    NavMeshDataHeader* header = (NavMeshDataHeader*)tileData->m_MeshData.begin();
    header->magic = kNavMeshMagic;
    header->version = kNavMeshVersion;
    header->x = ix;
    header->y = iz;
    header->agentTypeId = settings.agentTypeID;
}

static bool CreateTileData(int ix, int iz, const rcConfig& config, const NavMeshBuildSettings& settings,
    struct TileAllocations& mem, NavMeshTileData* tileData)
{
    PROFILER_AUTO(gRuntimeBuildCreateData, NULL);
    if (mem.m_polyMesh == NULL || mem.m_detailMesh == NULL)
        return false;

    NavMeshCreateParams params;
    memset(&params, 0, sizeof(params));

    // fill params
    params.verts = mem.m_polyMesh->verts;
    params.vertCount = mem.m_polyMesh->nverts;
    params.polys = mem.m_polyMesh->polys;
    params.polyAreas = mem.m_polyMesh->areas;
    params.polyFlags = mem.m_polyMesh->flags;
    params.polyCount = mem.m_polyMesh->npolys;
    params.nvp = mem.m_polyMesh->nvp;
    params.detailMeshes = mem.m_detailMesh->meshes;
    params.detailVerts = mem.m_detailMesh->verts;
    params.detailVertsCount = mem.m_detailMesh->nverts;
    params.detailTris = mem.m_detailMesh->tris;
    params.detailTriCount = mem.m_detailMesh->ntris;
    params.walkableHeight = settings.agentHeight;
    params.walkableRadius = settings.agentRadius;
    params.walkableClimb = settings.agentClimb;
    params.agentTypeId = settings.agentTypeID;
    params.tileX = ix;
    params.tileY = iz;
    params.bmin = Vector3f(mem.m_polyMesh->bmin);
    params.bmax = Vector3f(mem.m_polyMesh->bmax);
    params.cs = config.cs;
    params.ch = config.ch;
    params.buildBvTree = true;

    return CreateNavMeshTileData(&params, &tileData->m_MeshData);
}

static void* UnityRecastAlloc(int size, rcAllocHint /*hint*/)
{
    PROFILER_AUTO(gRecastAlloc, NULL);
    return UNITY_MALLOC_NULL(jobAllocLabel, size);
}

static void UnityRecastFree(void *ptr)
{
    PROFILER_AUTO(gRecastFree, NULL);
    UNITY_FREE(jobAllocLabel, ptr);
}

static MinMaxAABB CalculateBounds(const Matrix4x4f& mat, const Vector3f& size)
{
    const Vector3f extents = size * 0.5f;
    const Vector3f worldExtents = Abs(mat.GetAxisX() * extents.x) + Abs(mat.GetAxisY() * extents.y) + Abs(mat.GetAxisZ() * extents.z);
    const Vector3f min = mat.GetPosition() - worldExtents;
    const Vector3f max = mat.GetPosition() + worldExtents;
    return MinMaxAABB(min, max);
}

static void CreateCubeMesh(NavMeshTriangleData* triangleData, const Matrix4x4f& transform, const Vector3f& extents)
{
    // Create box mesh
    static const int indices[36] =
    {
        0, 1, 2, 3, 2, 1,
        4, 0, 6, 6, 0, 2,
        5, 1, 4, 4, 1, 0,
        7, 3, 1, 7, 1, 5,
        5, 4, 7, 7, 4, 6,
        7, 2, 3, 7, 6, 2
    };
    triangleData->vertices.resize_uninitialized(8);
    for (int i = 0; i < 8; i++)
    {
        const Vector3f pos((i & 1) == 0 ? extents.x : -extents.x, (i & 2) == 0 ? extents.y : -extents.y, (i & 4) == 0 ? extents.z : -extents.z);
        triangleData->vertices[i] = transform.MultiplyPoint3(pos);
    }
    triangleData->indices.assign(indices, indices + 36);
}

static void CreateSphereMesh(NavMeshTriangleData* triangleData, const Matrix4x4f& transform,
    const float radius, const int lats, const int longs)
{
    triangleData->vertices.resize_uninitialized(lats * longs);

    for (int i = 0; i < lats; i++)
    {
        float a = (float)i / (lats - 1) * kPI;
        float y  = radius * cosf(a);
        float yr =  radius * sinf(a);
        for (int j = 0; j < longs; j++)
        {
            float b = (float)(j - 1) / longs * kPI * 2.0f;
            float x = cosf(b);
            float z = sinf(b);
            Vector3f pos(x * yr, y, z * yr);
            triangleData->vertices[i * longs + j] = transform.MultiplyPoint3(pos);
        }
    }

    for (int i = 0; i < lats - 1; i++)
    {
        int i0 = i;
        int i1 = i + 1;
        for (int j = 0; j < longs; j++)
        {
            int j0 = j;
            int j1 = (j + 1) % longs;
            triangleData->indices.push_back(i0 * longs + j0);
            triangleData->indices.push_back(i0 * longs + j1);
            triangleData->indices.push_back(i1 * longs + j1);
            triangleData->indices.push_back(i0 * longs + j0);
            triangleData->indices.push_back(i1 * longs + j1);
            triangleData->indices.push_back(i1 * longs + j0);
        }
    }
}

static void CreateCapsuleMesh(NavMeshTriangleData* triangleData, const Matrix4x4f& transform,
    const float radius, const float halfHeight, const int lats, const int longs)
{
    const int hlats = (lats + 1) / 2;
    const float stemHalfHeight = std::max(0.0f, halfHeight - radius);

    triangleData->vertices.resize_uninitialized(hlats * 2 * longs);

    // Top
    for (int i = 0; i < hlats; i++)
    {
        const float a = (float)i / (hlats - 1) * kPI * 0.5f;
        const float y  = radius * cosf(a);
        const float yr =  radius * sinf(a);
        for (int j = 0; j < longs; j++)
        {
            const float b = (float)(j - 1) / longs * kPI * 2.0f;
            const float x = cosf(b);
            const float z = sinf(b);
            const Vector3f pos(x * yr, y + stemHalfHeight, z * yr);
            triangleData->vertices[i * longs + j] = transform.MultiplyPoint3(pos);
        }
    }

    // Bottom
    for (int i = hlats; i < hlats * 2; i++)
    {
        const float a = (float)(i - 1) / (hlats - 1) * kPI * 0.5f;
        const float y  = radius * cosf(a);
        const float yr =  radius * sinf(a);
        for (int j = 0; j < longs; j++)
        {
            const float b = (float)(j - 1) / longs * kPI * 2.0f;
            const float x = cosf(b);
            const float z = sinf(b);
            const Vector3f pos(x * yr, y - stemHalfHeight, z * yr);
            triangleData->vertices[i * longs + j] = transform.MultiplyPoint3(pos);
        }
    }

    for (int i = 0; i < hlats * 2 - 1; i++)
    {
        int i0 = i;
        int i1 = i + 1;
        for (int j = 0; j < longs; j++)
        {
            int j0 = j;
            int j1 = (j + 1) % longs;
            triangleData->indices.push_back(i0 * longs + j0);
            triangleData->indices.push_back(i0 * longs + j1);
            triangleData->indices.push_back(i1 * longs + j1);
            triangleData->indices.push_back(i0 * longs + j0);
            triangleData->indices.push_back(i1 * longs + j1);
            triangleData->indices.push_back(i1 * longs + j0);
        }
    }
}

static void ExtractTriangleIndices(Mesh::TemporaryIndexContainer& indices, const SharedMeshData* data)
{
    const SharedMeshData::SubMeshContainer& subMeshes = data->GetSubMeshes();
    for (size_t i = 0; i < subMeshes.size(); ++i)
    {
        // ignore unsupported submesh format
        (void)Mesh::AppendTriangles(indices, i, subMeshes, data);
    }
}

static bool CalculateTriangleData(NavMeshTriangleData* triangleData, const SharedMeshBuildSource& src)
{
    if (src.shape == kNavMeshBuildSourceMesh)
    {
        PROFILER_AUTO(gRuntimeBuildMeshTriangles, NULL);
        const VertexData& vertexData = src.sharedMeshData->GetVertexData();

        const size_t vertexCount = vertexData.GetVertexCount();

        if (vertexCount == 0)
            return false;

        triangleData->vertices.resize_uninitialized(vertexCount);

        // Transform all vertices
        dynamic_array<Vector3f>::iterator outIt = triangleData->vertices.begin();
        StrideIterator<Vector3f> it = vertexData.MakeStrideIterator<Vector3f>(kShaderChannelVertex);
        StrideIterator<Vector3f> end = vertexData.MakeEndIterator<Vector3f>(kShaderChannelVertex);
        for (; it != end; ++it, ++outIt)
            *outIt = src.transform.MultiplyPoint3(*it);

        triangleData->indices.clear();
        ExtractTriangleIndices(triangleData->indices, src.sharedMeshData);
    }
    else if (src.shape == kNavMeshBuildSourceBox)
    {
        const Vector3f extents = Abs(src.size) * 0.5f;
        CreateCubeMesh(triangleData, src.transform, extents);
    }
    else if (src.shape == kNavMeshBuildSourceSphere)
    {
        // TODO: calculate tesselation based on size.
        const Vector3f extents = Abs(src.size) * 0.5f;
        const float radius = std::max(std::max(extents.x, extents.y), extents.z);
        CreateSphereMesh(triangleData, src.transform, radius, 10, 20);
    }
    else if (src.shape == kNavMeshBuildSourceCapsule)
    {
        // TODO: calculate tesselation based on size.
        const Vector3f extents = Abs(src.size) * 0.5f;
        const float radius = std::max(extents.x, extents.z);
        const float halfHeight = extents.y;
        CreateCapsuleMesh(triangleData, src.transform, radius, halfHeight, 10, 20);
    }
    else
    {
        return false;
    }

    bool reverseWinding = src.transform.GetDeterminant() < 0;
    if (reverseWinding)
    {
        const int indexCount = triangleData->indices.size();
        for (int i = 0; i < indexCount; i += 3)
        {
            int i0 = triangleData->indices[i + 0];
            int i1 = triangleData->indices[i + 1];
            triangleData->indices[i + 0] = i1;
            triangleData->indices[i + 1] = i0;
        }
    }
    return true;
}

static void TransformSources(dynamic_array<SharedMeshBuildSource>& bsources, const Vector3f& position, const Quaternionf& rotation)
{
    Matrix4x4f worldToLocal;
    worldToLocal.SetTRInverse(position, rotation);

    // Transform sources to navmesh local space
    for (size_t i = 0; i < bsources.size(); ++i)
    {
        SharedMeshBuildSource& source = bsources[i];
        Matrix4x4f transform;
        MultiplyMatrices4x4(&worldToLocal, &source.transform, &transform);
        source.transform = transform;
    }

    // Transform the bounds
    for (size_t i = 0; i < bsources.size(); ++i)
    {
        SharedMeshBuildSource& src = bsources[i];

        // Translate the local bounds of mesh and convert to MinMaxAABB
        if (src.shape == kNavMeshBuildSourceMesh)
        {
            AABB transformedBounds;
            TransformAABBSlow(src.localBounds, src.transform, transformedBounds);
            src.bounds = MinMaxAABB(transformedBounds);
        }
        else if (src.shape == kNavMeshBuildSourceBox)
        {
            src.bounds = CalculateBounds(src.transform, src.size);
        }
        else if (src.shape == kNavMeshBuildSourceSphere)
        {
            // NOTE: assumes ext.x == ext.y == ext.z;
            src.bounds = CalculateBounds(src.transform, src.size);
        }
        else if (src.shape == kNavMeshBuildSourceCapsule)
        {
            // NOTE: should be possible to get tighter bounds.
            src.bounds = CalculateBounds(src.transform, src.size);
        }
        else if (src.shape == kNavMeshBuildSourceModifierBox)
        {
            src.bounds = CalculateBounds(src.transform, src.size);
        }
        else
        {
            ErrorStringMsg("RuntimeNavMeshBuilder. Unknown source type: %i\n", (int)src.shape);
            continue;
        }
    }
}

static MinMaxAABB CombineAndCullBounds(dynamic_array<SharedMeshBuildSource>& bsources, const MinMaxAABB& bounds)
{
    MinMaxAABB inputBounds;
    for (size_t i = 0; i < bsources.size(); ++i)
    {
        SharedMeshBuildSource& src = bsources[i];
        if (IntersectAABBAABB(src.bounds, bounds))
            inputBounds.Encapsulate(src.bounds);
        else
        {
            bsources.erase_swap_back(bsources.begin() + i);
            --i;
        }
    }
    MinMaxAABB combinedBounds;
    IntersectionAABBAABB(bounds, inputBounds, &combinedBounds);
    return combinedBounds;
}

BuildNavMeshInfo* CreateBuildNavMeshInfo()
{
    return UNITY_NEW(BuildNavMeshInfo, jobAllocLabel) (jobAllocLabel);
}

void Cancel(BuildNavMeshInfo* info)
{
    if (info)
    {
        info->cancel = true;
        SyncFence(info->fence);
    }
}

bool Done(const BuildNavMeshInfo* info)
{
    return (info == NULL) || IsFenceDone(info->fence);
}

float Progress(const BuildNavMeshInfo* info)
{
    if (!info)
        return 0.0f;

    const size_t count = info->tiles.size();
    if (count == 0)
        return 0.0f;

    const float norm = 1.0f / count;
    int computed = 0;

    for (size_t i = 0; i < count; ++i)
    {
        if (!info->tiles[i].m_MeshData.empty())
            computed++;
    }
    return computed * norm;
}

void DestroyBuildNavMeshInfo(BuildNavMeshInfo* info)
{
    if (info == NULL)
        return;

    SyncFence(info->fence);

    // Release shared data. Usually this has already happened
    // - but is needed when a build is purged before integration.
    ReleaseSharedMeshData(info);

    UNITY_DELETE(info, jobAllocLabel);
}

// Acquire data for async operations - should do very little work except extract info
void AcquireSharedMeshData(BuildNavMeshInfo* info, const NavMeshBuildSource* sources, size_t nsources,
    const Vector3f& position, const Quaternionf& rotation, const AABB& localBounds)
{
    PROFILER_AUTO(gRuntimeBuildAcquire, NULL);
    rcAllocSetCustom(UnityRecastAlloc, UnityRecastFree);

    Assert(info->sources.empty());
    info->sources.reserve(nsources);
    info->buildPosition = position;
    info->buildRotation = rotation;

    for (size_t i = 0; i < nsources; ++i)
    {
        const NavMeshBuildSource& source = sources[i];

        SharedMeshBuildSource src;
        memset(&src, 0, sizeof(src));

        if (source.shape == kNavMeshBuildSourceMesh)
        {
            PPtr<Mesh> mesh(source.instanceID);
            if (mesh.IsNull())
            {
                ErrorStringMsg("RuntimeNavMeshBuilder. Source Mesh missing at index: %i", (int)i);
                continue;
            }
            if (!mesh->GetIsReadable())
            {
#if !UNITY_EDITOR
                ErrorStringMsg("RuntimeNavMeshBuilder: Source mesh %s is skipped because it does not allow read access", mesh->GetName());
                continue;
#else
                if (IsWorldPlaying())
                {
                    ErrorStringObject(Format("RuntimeNavMeshBuilder: Source mesh %s does not allow read access. This will work in playmode in the editor but not in player", mesh->GetName()), mesh);
                }
#endif
            }
            src.localBounds = mesh->GetLocalAABB();
            src.sharedMeshData = mesh->AcquireSharedMeshData();
        }
        else if (source.shape == kNavMeshBuildSourceTerrain)
        {
            // Convert terrain to meshes for the time being
            PROFILER_AUTO(gRuntimeBuildExtractTerrainMesh, NULL);

            Matrix4x4f localToWorld;
            localToWorld.SetTR(position, rotation);
            AABB worldBounds;
            TransformAABBSlow(localBounds, localToWorld, worldBounds);

            if (ITerrainManager* terrain = GetITerrainManager())
            {
                const Vector3f terrainPosition = source.transform.GetPosition();
                const Object* terrainData = Object::IDToPointer(source.instanceID);
                dynamic_array<SharedMeshData*> patches(kMemTempAlloc);
                terrain->CreateSharedMeshDataPatches(terrainData, terrainPosition, patches, worldBounds);
                if (patches.empty())
                    continue;

                info->sources.reserve(info->sources.size() + patches.size() - 1);

                for (size_t j = 0; j < patches.size(); ++j)
                {
                    SharedMeshData* meshData = patches[j];
                    src.sharedMeshData = meshData;

                    AABB localAABB = meshData->GetSubMeshes()[0].localAABB;
                    localAABB.m_Center -= terrainPosition;

                    src.localBounds = localAABB;
                    src.transform = source.transform;
                    src.shape = kNavMeshBuildSourceMesh;
                    src.areaTag = (UInt8)source.areaType;
                    src.size = source.size;
                    info->sources.push_back(src);
                }
            }
            continue;
        }

        src.transform = source.transform;
        src.shape = source.shape;
        src.areaTag = (UInt8)source.areaType;
        src.size = source.size;
        info->sources.push_back(src);
    }
}

void ReleaseSharedMeshData(BuildNavMeshInfo* info)
{
    PROFILER_AUTO(gRuntimeBuildRelease, NULL);

    for (size_t i = 0; i < info->sources.size(); ++i)
    {
        const SharedMeshBuildSource& src = info->sources[i];
        if (src.sharedMeshData)
            src.sharedMeshData->Release();
    }
    info->sources.clear();
}

void ScheduleNavMeshDataUpdate(const NavMeshData* data, BuildNavMeshInfo* info,
    const NavMeshBuildSettings& settings, const AABB& localBuildBounds)
{
    PROFILER_AUTO(gRuntimeBuildUpdate, NULL);

    Assert(info->tiles.empty());
    Assert(info->removeTileIDs.empty());

    const Vector3f position = data->GetPosition();
    const Quaternionf rotation = data->GetRotation();

    TransformSources(info->sources, position, rotation);
    const MinMaxAABB buildBounds = MinMaxAABB(localBuildBounds);
    MinMaxAABB combinedBounds = CombineAndCullBounds(info->sources, buildBounds);

    if (!combinedBounds.IsValid())
    {
        const NavMeshTileDataVector& existingTiles = data->GetNavMeshTiles();
        info->removeTileIDs.resize_uninitialized(existingTiles.size());
        for (size_t i = 0; i < existingTiles.size(); ++i)
        {
            info->removeTileIDs[i] = i;
        }

        ClearFenceWithoutSync(info->fence);
        return;
    }

    rcConfig config;
    ConfigureConfig(config, settings, combinedBounds);

    info->settings = settings;
    info->config = config;

    const int tileCount = CalculateTileIndices(info->tileXZ, info->config);
    info->tiles.resize(tileCount);

    // Compute the hashes for all tiles
    JobFence hashFence;
    ScheduleJobForEach(hashFence, ComputeTileHashJob, info, tileCount, kHighJobPriority);
    SyncFence(hashFence);

    // Figure out what needs to be removed and what needs to be built
    const NavMeshTileDataVector& existingTiles = data->GetNavMeshTiles();
    dynamic_array<int> computeTileIDs(kMemTempAlloc);
    ClassifyTilesToRemoveAndCompute(existingTiles, info->tiles, info->removeTileIDs, computeTileIDs);
    int computeCount = CompactTilesAndLocations(computeTileIDs, info->tiles, info->tileXZ);

    if (computeCount > 0)
    {
        ScheduleJobForEach(info->fence, ComputeTileMeshJob, info, computeCount, ReleaseSharedMeshData, kHighJobPriority);
    }
    else
    {
        ReleaseSharedMeshData(info);
        ClearFenceWithoutSync(info->fence);
    }
}

#include "Runtime/AI/Internal/NavMeshManager.h"
void IntegrateNavMeshDataUpdate(NavMeshData* data, BuildNavMeshInfo* info, const AABB& localBounds)
{
    SyncFence(info->fence);

    // Skip if nothing changed
    if (info->removeTileIDs.empty() && info->tiles.empty())
        return;

    PROFILER_AUTO(gRuntimeBuildIntegrate, NULL);

    // Remove the usage of the data that is to be removed.
    NavMeshManager& manager = GetNavMeshManager();
    dynamic_array<int> surfaceInstanceIDs(kMemTempAlloc);
    manager.GetSurfaceIDsFromData(surfaceInstanceIDs, data);

    for (size_t i = 0; i < surfaceInstanceIDs.size(); ++i)
    {
        PROFILER_AUTO(gRuntimeBuildIntegrateRemoveTiles, NULL);
        manager.RemoveTiles(surfaceInstanceIDs[i], info->removeTileIDs);
    }

    dynamic_array<int> newTileIDs(kMemTempAlloc);
    // is data still valid ?!
    {
        PROFILER_AUTO(gRuntimeBuildIntegrateUpdateTiles, NULL);
        data->UpdateTiles(info->removeTileIDs, info->tiles, newTileIDs);
        data->SetSourceBounds(localBounds);
        data->SetNavMeshBuildSettings(info->settings);
    }

    for (size_t i = 0; i < surfaceInstanceIDs.size(); ++i)
    {
        // NOTE: No carving can be happening when doing this!!!
        PROFILER_AUTO(gRuntimeBuildIntegrateUpdateSurface, NULL);
        manager.UpdateSurface(surfaceInstanceIDs[i], info->settings, newTileIDs);
    }
}
