#include "UnityPrefix.h"
#include "Runtime/BaseClasses/GameObject.h"
#include "Runtime/Jobs/Internal/JobQueue.h"
#include "Runtime/Jobs/JobTypes.h"
#include "Runtime/Jobs/Jobs.h"

#include "MarkupLookup.h"
#include "NavMeshBuildManager.h"
#include "NavMeshBuildOperation.h"
#include "RuntimeNavMeshBuilder.h"
#include "Runtime/AI/Internal/NavMeshData.h"
#include "Runtime/AI/Internal/NavMeshManager.h"
#include "Runtime/Geometry/Intersection.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Graphics/RendererUpdateManager.h"
#include "Runtime/Graphics/Mesh/MeshRenderer.h"
#include "Runtime/Graphics/Mesh/Mesh.h"
#include "Runtime/BaseClasses/BaseObject.h"
#include "Runtime/Interfaces/IPhysics.h"
#include "Runtime/Camera/RendererScene.h"
#include "Runtime/Interfaces/ITerrainManager.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/TerrainPhysics/TerrainCollider.h"

void NavMeshBuildManager::UpdateAsyncOperations()
{
    Assert(Thread::CurrentThreadIsMainThread());
    // Check if async operations have been completed, integrate, trigger script callbacks and remove.
    // Note: script callback must happen on the main thread.

    // We use two passes here because invoking the coroutine can modify the container
    dynamic_array<NavMeshBuildOperation*> doneOperations(kMemTempAlloc);
    for (size_t i = 0; i < m_AsyncOperations.size(); ++i)
    {
        NavMeshBuildOperation* op = m_AsyncOperations[i];

        if (op->IsReadyToIntegrateToMainThread())
        {
            doneOperations.push_back(op);
            m_AsyncOperations.erase(m_AsyncOperations.begin() + i);
            i--;
        }
    }

    for (size_t i = 0; i < doneOperations.size(); ++i)
    {
        NavMeshBuildOperation* op = doneOperations[i];
        op->Integrate();
        op->InvokeCoroutine();
        op->Release();
    }
}

void NavMeshBuildManager::ReleaseAsyncOperations()
{
    for (size_t i = 0; i < m_AsyncOperations.size(); ++i)
    {
        NavMeshBuildOperation* op = m_AsyncOperations[i];
        op->CleanupCoroutine();
        op->Release();
    }
    m_AsyncOperations.clear();
}

void NavMeshBuildManager::Purge(const NavMeshData* data)
{
    for (size_t i = 0; i < m_AsyncOperations.size(); ++i)
        m_AsyncOperations[i]->Purge(data);
}

NavMeshBuildManager::~NavMeshBuildManager()
{
    if (m_JobQueue != NULL)
    {
        m_JobQueue->Shutdown(JobQueue::kShutdownWaitForAllJobs);
        UNITY_DELETE(m_JobQueue, kMemAI);
    }
    for (size_t i = 0; i < m_AsyncOperations.size(); i++)
    {
        NavMeshBuildOperation* op = m_AsyncOperations[i];
        op->Release();
    }
}

static void AsyncJob(void* userData)
{
    NavMeshBuildOperation* op = reinterpret_cast<NavMeshBuildOperation*>(userData);
    op->Schedule();
}

void NavMeshBuildManager::ExecuteAsync(NavMeshBuildOperation* op)
{
    Assert(Thread::CurrentThreadIsMainThread());
    if (m_JobQueue == NULL)
    {
        // NOTE: Cannot alloc in ctor, since the the JobQueue is not properly initialized at that time.
        m_JobQueue = UNITY_NEW(JobQueue(1, 64 * 1024, -1, JobQueue::kUseProfilerAndAllowMutexLocks, "NavMesh Builder", "Worker Thread"), kMemAI);
        m_JobQueue->SetThreadPriority(kBelowNormalPriority);
    }

    // Purge existing operation working on the data
    const NavMeshData* data = op->GetData();
    for (size_t i = 0; i < m_AsyncOperations.size(); ++i)
        m_AsyncOperations[i]->Purge(data);

    op->AddRef();
    m_AsyncOperations.push_back(op);
    m_JobQueue->ScheduleJob(AsyncJob, op, m_JobQueue->GetAnyJobGroupID(), JobQueue::kNormalJobPriority);
}

PROFILER_INFORMATION(gCollectSource, "CollectSources", kProfilerAI)
PROFILER_INFORMATION(gCollectSourceRenderers, "Renderers", kProfilerAI)
PROFILER_INFORMATION(gCollectSourceColliders, "Colliders", kProfilerAI)
PROFILER_INFORMATION(gCollectSourceTerrains, "Terrrains", kProfilerAI)
PROFILER_INFORMATION(gTransformColliders, "TransformColliders", kProfilerAI)
PROFILER_INFORMATION(gTransformRenderers, "TransformRenderers", kProfilerAI)

// Assumes exact type - no derived classes
static void GetActiveComponentsInChildren(const GameObject& go, const Unity::Type* type, dynamic_array<Unity::Component*>& result)
{
    if (!go.IsSelfActive())
        return;

    for (int i = 0; i < go.GetComponentCount(); ++i)
    {
        if (go.GetComponentTypeAtIndex(i) == type)
            result.push_back(&go.GetComponentAtIndex(i));
    }

    if (Transform* transform = go.QueryComponent<Transform>())
    {
        for (Transform::iterator i = transform->begin(); i != transform->end(); ++i)
        {
            const GameObject& child = (**i).GetGameObject();
            GetActiveComponentsInChildren(child, type, result);
        }
    }
}

struct ColliderCollector : public IPhysics::IUserCollect
{
    dynamic_array<Unity::Component*>* m_Colliders;

    virtual void OnFoundCollider(Unity::Component* collider)
    {
        m_Colliders->push_back(collider);
    }
};

bool NavMeshBuildManager::CollectSources(int includedLayerMask, const AABB& includedWorldBounds, const Transform* root, bool useBounds,
    NavMeshCollectGeometry geometry, int defaultAreaType, const NavMeshBuildMarkup* markups, const int markupsCount,
    dynamic_array<NavMeshBuildSource>& results)
{
    PROFILER_AUTO(gCollectSource, NULL);

    results.clear();

    MarkupLookup markupLookup(defaultAreaType);
    for (int i = 0; i < markupsCount; i++)
    {
        if (markups[i].ignoreFromBuild)
            markupLookup.AddIgnore(markups[i].instanceID);
        if (markups[i].overrideArea)
            markupLookup.AddAreaType(markups[i].instanceID, markups[i].area);
    }

    // The following timings were done on the Vikings village demo level.
    // NavMeshSurface size (200,30,130), center (-25,10,10)

    dynamic_array<Unity::Component*> colliders(kMemTempAlloc);
    if (geometry == PhysicsColliders)
    {
        IPhysics* physics = GetIPhysics();
        if (physics == NULL)
            return false;

        // Finding "infinity" bounds that work with physX is difficult - if the value is too big
        // nothing will be collected - here we choose a "large" constant that seems to work.
        AABB bounds = useBounds ? includedWorldBounds : AABB(Vector3f::zero, 1e10f * Vector3f::one);

        PROFILER_BEGIN(gCollectSourceColliders, NULL);

        if (root)
        {
            physics->GetColliderComponentsInChildren(root->GetGameObject(), false, false, colliders);
        }
        else
        {
            ColliderCollector collect;
            collect.m_Colliders = &colliders;
            physics->OverlapBoxUserCollect(bounds.m_Center, bounds.m_Extent, Quaternionf::identity(), includedLayerMask, QueryTriggerInteraction_UseGlobal, collect);
        }

        PROFILER_END(gCollectSourceColliders);

        PROFILER_BEGIN(gTransformColliders, NULL);

        dynamic_array<IPhysics::ColliderShape> shapes(kMemTempAlloc);
        for (size_t i = 0; i < colliders.size(); i++)
        {
            IPhysics::ColliderShape shape;
            if (!physics->GetCollisionShapeForCollider(colliders[i], shape))
                continue;

            const Unity::Component* component = shape.component;
            if (!component)
                continue;

            const GameObject& go = component->GetGameObject();
            if ((go.GetLayerMask() & (UInt32)includedLayerMask) == 0)
                continue;

            const Transform* transform = go.QueryComponent<Transform>();
            if (markupLookup.IgnoreFromBuild(transform))
                continue;

            const int area = markupLookup.GetAreaType(transform);

            NavMeshBuildSource& src = results.emplace_back_uninitialized();
            src.areaType = area;

            switch (shape.type)
            {
                case IPhysics::kColliderMesh:
                    src.shape = kNavMeshBuildSourceMesh;
                    src.transform.SetTRS(shape.position, shape.rotation, shape.size);
                    src.size.SetZero();
                    src.instanceID = shape.mesh->GetInstanceID();
                    src.componentID = component->GetInstanceID();
                    break;
                case IPhysics::kColliderBox:
                    src.shape = kNavMeshBuildSourceBox;
                    src.transform.SetTR(shape.position, shape.rotation);
                    src.size = shape.size;
                    src.instanceID = InstanceID_None;
                    src.componentID = component->GetInstanceID();
                    break;
                case IPhysics::kColliderSphere:
                    src.shape = kNavMeshBuildSourceSphere;
                    src.transform.SetTR(shape.position, shape.rotation);
                    src.size = shape.size;
                    src.instanceID = InstanceID_None;
                    src.componentID = component->GetInstanceID();
                    break;
                case IPhysics::kColliderCapsule:
                    src.shape = kNavMeshBuildSourceCapsule;
                    src.transform.SetTR(shape.position, shape.rotation);
                    src.size = shape.size;
                    src.instanceID = InstanceID_None;
                    src.componentID = component->GetInstanceID();
                    break;
                default:
                    src.shape = kNavMeshBuildSourceBox;
                    src.transform.SetTR(shape.position, shape.rotation);
                    src.size = shape.size;
                    src.instanceID = InstanceID_None;
                    src.componentID = component->GetInstanceID();
                    break;
            }
        }
        PROFILER_END(gTransformColliders);
    }
    else
    {
        PROFILER_BEGIN(gCollectSourceRenderers, NULL);

        // Render meshes
        dynamic_array<MeshRenderer*> meshRenderers(kMemTempAlloc);

        if (root == NULL)
        {
            // Note: fastest
            // 0.495ms, (C# 0.564ms)

            GetRendererUpdateManager().UpdateAll(GetRendererScene());
            RendererScene& scene = GetRendererScene();
            size_t rendererCount = scene.GetRendererNodeCount();
            meshRenderers.reserve(rendererCount);
            for (size_t i = 0; i < rendererCount; ++i)
            {
                const SceneNode& node = scene.GetRendererNode(i);

                Renderer* renderer = static_cast<Renderer*>(node.renderer);
                if (renderer == NULL)
                    continue;

                MeshRenderer* meshRenderer = dynamic_pptr_cast<MeshRenderer*>(renderer);
                if (meshRenderer == NULL)
                    continue;

                meshRenderers.push_back(meshRenderer);
            }
        }
        else
        {
            // Note: second fastest
            // 0.487ms (C# 0.549ms)
            dynamic_array<Unity::Component*>& comp = reinterpret_cast<dynamic_array<Unity::Component*>&>(meshRenderers);
            GetActiveComponentsInChildren(root->GetGameObject(), TypeOf<MeshRenderer>(), comp);
        }

        PROFILER_END(gCollectSourceRenderers);

        PROFILER_BEGIN(gTransformRenderers, NULL);
        for (size_t i = 0, ni = meshRenderers.size(); i < ni; i++)
        {
            const MeshRenderer* renderer = meshRenderers[i];
            if (!renderer->GetEnabled())
                continue;

            // Skip if no mesh.
            const Mesh* sharedMesh = renderer->GetSharedMesh();
            if (sharedMesh == NULL)
                continue;

            // Skip if layer doesn't match.
            const GameObject& go = renderer->GetGameObject();
            if ((go.GetLayerMask() & (UInt32)includedLayerMask) == 0)
                continue;

            const Transform* transform = go.QueryComponent<Transform>();
            if (markupLookup.IgnoreFromBuild(transform))
                continue;

            const int area = markupLookup.GetAreaType(transform);

            // Skip if the mesh is not inside query bounds.
            if (useBounds)
            {
                AABB worldBounds;
                meshRenderers[i]->GetWorldAABB(worldBounds);
                if (!IntersectAABBAABB(includedWorldBounds, worldBounds))
                    continue;
            }

            Matrix4x4f tm = transform->GetLocalToWorldMatrix();

            NavMeshBuildSource& src = results.emplace_back_uninitialized();
            src.areaType = area;
            src.shape = kNavMeshBuildSourceMesh;
            src.transform = tm;
            src.size.SetZero();
            src.instanceID = sharedMesh->GetInstanceID();
            src.componentID = renderer->GetInstanceID();
        }
        PROFILER_END(gTransformRenderers);
    }

    // Terrains
#if ENABLE_TERRAIN
    ITerrainManager* terrainManager = GetITerrainManager();
    if (terrainManager != NULL)
    {
        PROFILER_AUTO(gCollectSourceTerrains, NULL);

        const TerrainList& terrains = terrainManager->GetActiveTerrains();
        for (TerrainList::const_iterator it = terrains.begin(); it != terrains.end(); ++it)
        {
            Terrain* terrain = *it;

            const Object* terrainData = terrainManager->GetTerrainData(terrain);
            if (terrainData == NULL)
                continue;

            const Unity::Component* component = reinterpret_cast<Unity::Component*>(terrain);
            const GameObject& go = component->GetGameObject();

            if (geometry == PhysicsColliders)
            {
                // This needs special handling in a future where class ids are not central
                Unity::Component* collider = go.QueryComponent<TerrainCollider>();
                if (collider == NULL)
                    continue;

                // If the terrain collider is not found in the list of physics colliders collected above - then it's not enabled.
                // This seems to be the least intrusive way to test for a terrain collider being active, across modules.
                bool terrainColliderFound = std::find(colliders.begin(), colliders.end(), collider);
                if (!terrainColliderFound)
                    continue;
            }

            // Skip if layer doesn't match.
            if ((go.GetLayerMask() & (UInt32)includedLayerMask) == 0)
                continue;

            const Transform* transform = go.QueryComponent<Transform>();

            // If a root is provided - find it or ignore this terrain
            if (root != NULL)
            {
                const Transform* t = transform;
                while (t && t != root)
                    t = t->GetParent();

                if (t != root)
                    continue;
            }

            if (markupLookup.IgnoreFromBuild(transform))
                continue;

            const int area = markupLookup.GetAreaType(transform);

            // Skip if the mesh is not inside query bounds.
            if (useBounds)
            {
                AABB worldBounds(terrainManager->GetWorldAABB(terrain));
                if (!IntersectAABBAABB(includedWorldBounds, worldBounds))
                    continue;
            }

            Matrix4x4f tm;
            tm.SetTranslate(terrainManager->GetTerrainPosition(terrain));

            NavMeshBuildSource& src = results.emplace_back_uninitialized();
            src.areaType = area;
            src.shape = kNavMeshBuildSourceTerrain;
            src.transform = tm;
            src.size.SetZero();
            src.instanceID = terrainData->GetInstanceID();
            src.componentID = component->GetInstanceID();
        }
    }
#endif

    return true;
}

// Update existing navmesh data - only tiles affected by changes in input are recalculated
bool NavMeshBuildManager::UpdateNavMeshData(NavMeshData* data, const NavMeshBuildSettings& buildSettings,
    const NavMeshBuildSource* sources, size_t nsources, const AABB& localBounds)
{
    NavMeshBuildSettings validatedSettings;
    ValidateNavMeshBuildSettings(validatedSettings, NULL, buildSettings, localBounds);

    BuildNavMeshInfo* info = CreateBuildNavMeshInfo();
    AcquireSharedMeshData(info, sources, nsources, data->GetPosition(), data->GetRotation(), localBounds);

    ScheduleNavMeshDataUpdate(data, info, validatedSettings, localBounds);
    IntegrateNavMeshDataUpdate(data, info, localBounds);

    DestroyBuildNavMeshInfo(info);

    return true;
}

AsyncOperation* NavMeshBuildManager::UpdateNavMeshDataAsync(NavMeshData* data, const NavMeshBuildSettings& buildSettings,
    const NavMeshBuildSource* sources, size_t nsources, const AABB& localBounds)
{
    Assert(data);
    // Using 'new' here because AsyncOperation uses 'delete' on final deref in Release
    NavMeshBuildOperation* oper = UNITY_NEW(NavMeshBuildOperation, kMemAI)(kMemAI, data, buildSettings, sources, nsources, localBounds);

    NavMeshBuildManager* manager = GetNavMeshManager().GetNavMeshBuildManager();
    manager->ExecuteAsync(oper);

    return oper;
}
