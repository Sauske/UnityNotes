#pragma once

#include "NavMeshBindingTypes.h"
#include "Runtime/Serialize/SerializeUtility.h"

// Keep this struct in sync with the one defined in "RuntimeNavMeshBuilder.bindings"
struct NavMeshBuildDebugSettings
{
    DECLARE_SERIALIZE(NavMeshBuildDebugSettings)

    NavMeshBuildDebugSettings();

    inline NavMeshBuildDebugFlags GetFlags()
    {
        return static_cast<NavMeshBuildDebugFlags>(m_Flags);
    }

    UInt8 m_Flags;
};
