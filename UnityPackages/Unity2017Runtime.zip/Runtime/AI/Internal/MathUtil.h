#pragma once

#include "Runtime/Math/Vector3.h"

inline float Dot2D(const Vector3f& a, const Vector3f& b)
{
    return a.x * b.x + a.z * b.z;
}

inline float Distance(const Vector3f& a, const Vector3f& b)
{
    return Magnitude(b - a);
}

inline float SqrDistance(const Vector3f& a, const Vector3f& b)
{
    return SqrMagnitude(b - a);
}

inline float SqrDistance2D(const Vector3f& a, const Vector3f& b)
{
    Vector3f c = b - a;
    c.y = 0.0f;
    return SqrMagnitude(c);
}

inline float Perp2D(const Vector3f& u, const Vector3f& v)
{
    return u.z * v.x - u.x * v.z;
}

inline float TriArea2D(const Vector3f& a, const Vector3f& b, const Vector3f& c)
{
    const float abx = b.x - a.x;
    const float abz = b.z - a.z;
    const float acx = c.x - a.x;
    const float acz = c.z - a.z;
    return acx * abz - abx * acz;
}

inline bool OverlapBounds(const Vector3f& amin, const Vector3f& amax,
    const Vector3f& bmin, const Vector3f& bmax)
{
    bool overlap = true;
    overlap = (amin.x > bmax.x || amax.x < bmin.x) ? false : overlap;
    overlap = (amin.y > bmax.y || amax.y < bmin.y) ? false : overlap;
    overlap = (amin.z > bmax.z || amax.z < bmin.z) ? false : overlap;
    return overlap;
}

// Compiling to conditional move this is typically faster than modulus operator %
// in the general case where index and modulus is not known at compile-time
// The input index must be in the modulus range
static inline size_t NextIndex(size_t index, size_t modulus)
{
    DebugAssert(index < modulus);
    const size_t next = index + 1;
    return (next == modulus) ? 0 : next;
}

// Compiling to conditional move this is typically faster than modulus operator %
// in the general case where index and modulus is not known at compile-time
// The input index must be in the modulus range
static inline size_t PrevIndex(size_t index, size_t modulus)
{
    DebugAssert(index < modulus);
    return (index == 0) ? modulus - 1 : index - 1;
}

float SqrDistancePointSegment2D(float* t, const Vector3f& pt, const Vector3f& s1, const Vector3f& s2);

float SqrDistancePointSegment(float* t, const Vector3f& pt, const Vector3f& s1, const Vector3f& s2);

bool ClosestHeightPointTriangle(float* h, const Vector3f& p, const Vector3f& a, const Vector3f& b, const Vector3f& c);

bool IntersectSegmentPoly2D(float* tmin, float* tmax, int* segMin, int* segMax,
    const Vector3f& p0, const Vector3f& p1, const Vector3f* verts, int nverts);
