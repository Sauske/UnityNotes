#include "UnityPrefix.h"
#include "NavMeshBuildDebugSettings.h"

#include "Runtime/BaseClasses/ObjectDefines.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"

#include <float.h>

template<class TransferFunc>
void NavMeshBuildDebugSettings::Transfer(TransferFunc& transfer)
{
    TRANSFER(m_Flags);
    transfer.Align();
}

NavMeshBuildDebugSettings::NavMeshBuildDebugSettings()
    : m_Flags((UInt8)kDebugNone)
{
}

INSTANTIATE_TEMPLATE_TRANSFER(NavMeshBuildDebugSettings);
