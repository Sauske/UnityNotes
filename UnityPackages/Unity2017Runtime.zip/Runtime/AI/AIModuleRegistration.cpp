#include "UnityPrefix.h"
#include "Runtime/Modules/ModuleRegistration.h"

#define UNITY_MODULE_NAME    AI
#define UNITY_MODULE_STRIPPABLE
#define UNITY_MODULE_INCLUDE "Runtime/AI/AIModule.inc.h"
    #include "Runtime/Modules/ModuleTemplate.inc.h"
#undef UNITY_MODULE_NAME
#undef UNITY_MODULE_STRIPPABLE
#undef UNITY_MODULE_INCLUDE

UNITY_MODULE_INITIALIZE(AI)
{
}

UNITY_MODULE_CLEANUP(AI)
{
}
