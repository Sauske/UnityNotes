#pragma  once

#if PLATFORM_ANDROID

#include "JNI_Register.h"

#include "External/Tango/builds/gen/ApiFuncTangoClient.h"
#include "External/Tango/builds/gen/ApiFuncTango3dReconstruction.h"
#include "TangoImageData.h"
#include "TangoTypes.h"
#include "TangoImageBufferManager.h"
#include "TangoPointCloudManager.h"
#include "Runtime/Graphics/ScreenManager.h"

//
// Class to assist with connection with and configuration of Tango Service
//

namespace Tango
{
    class ImageBufferManager;
    class PointCloudManager;

    bool LoadTangoClientPlugin();
    bool LoadTango3dReconstructionPlugin();

    ::jobject & GetCallerActivity();

    ::TangoClientPlugin & GetTangoClientPlugin();
    bool IsClientPluginLoaded();

    ::Tango3dReconstructionPlugin & GetTango3dReconstructionPlugin();
    bool Is3dReconstructionPluginLoaded();

    // TangoExternal::TangoPointCloud and TangoExternal::TangoImage
    // are the only supported types.
    template<typename T> BufferManager<T>* GetManager();

    PointCloudManager* GetPointCloudManager();
    bool CreatePointCloudManager(int maxPointCloudElements);
    void FreePointCloudManager();
    bool UpdatePointCloud(const TangoExternal::TangoPointCloud* pointCloud);

    ImageBufferManager* GetImageBufferManager();
    bool CreateImageBufferManager();
    void FreeImageBufferManager();
    bool UpdateImageBuffer(const TangoExternal::TangoImage* imageBuffer, const TangoExternal::TangoCameraMetadata* metadata);
    UInt32 GetNumBytesForImageBuffer(const TangoExternal::TangoImage& imageBuffer);

    TangoExternal::TangoCoordinateFrameType UnityToTango(CoordinateFrame frame);
    CoordinateFrame TangoToUnity(TangoExternal::TangoCoordinateFrameType frame);
    PoseStatus TangoToUnity(TangoExternal::TangoPoseStatusType pose_status);
    TangoExternal::TangoUnity3DR_UpdateMethod UnityToTango(MeshReconstruction::UpdateMethod updateMethod);

    TangoExternal::TangoErrorType GetPoseAtTime(
        double timestamp,
        CoordinateFrame baseFrame,
        CoordinateFrame targetFrame,
        TangoExternal::TangoPoseData* poseDataOut);

    TangoExternal::TangoErrorType GetPoseAtTime(
        double timestamp,
        ScreenOrientation screenOrientation,
        CoordinateFrame baseFrame,
        CoordinateFrame targetFrame,
        TangoExternal::TangoPoseData* poseDataOut);

    bool IsFixedTangoCoordinateFrame(CoordinateFrame frame);

    // To produce camera poses in GetPostAtTime, we actually query the device
    // pose and then apply a delta transform to get to each camera's position
    // relative to the device. These delta transforms are all device specific,
    // but they don't change during the app lifetime so we only need to query
    // them once.
    void ComputeDeviceToCameraPoses();

    // Used to determine if a pose is valid at the timestamp. We
    // don't actually care about the pose itself.
    bool DeviceHasValidPoseAtTime(double timestamp);
} // namespace Tango

#endif
