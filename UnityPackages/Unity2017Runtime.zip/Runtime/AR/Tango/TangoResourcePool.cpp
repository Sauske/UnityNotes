#include "UnityPrefix.h"

#if PLATFORM_ANDROID

#include "TangoResourcePool.h"
#include "TangoMeshReconstructionTypes.h"

#ifdef UNITY_REGISTER_TANGO_RESOURCE_POOL
#   undef UNITY_REGISTER_TANGO_RESOURCE_POOL
#endif

namespace Tango
{
#define UNITY_REGISTER_TANGO_RESOURCE_POOL(T) \
    template<> RuntimeStatic<ResourcePool<T>, true> ResourcePool<T>::s_TangoResourcePoolInstance(kMemSpatialMapping)

    UNITY_REGISTER_TANGO_RESOURCE_POOL(MeshReconstruction::GenerationQuery);
    UNITY_REGISTER_TANGO_RESOURCE_POOL(MeshReconstruction::GenerationResult);
} // namespace Tango

#undef UNITY_REGISTER_TANGO_RESOURCE_POOL

#endif
