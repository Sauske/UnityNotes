#pragma once

#include "TangoSupport.h"
#include "Runtime/Threads/Semaphore.h"
#include "Runtime/Utilities/RuntimeStatic.h"

//
// Handles Tango-related callbacks from the Unity player loop
//

namespace Tango
{
    class EngineCallbackHandler
    {
    public:
        EngineCallbackHandler();

        ~EngineCallbackHandler();

        void OnTextureAvailable(TangoExternal::TangoCameraId cameraId);

        // Register and unregister for update loop callbacks. Safe to
        // call multiple times. Must be called on main thread.
        void RegisterUpdateLoop();
        void UnregisterUpdateLoop();

        static EngineCallbackHandler* GetInstance() { return s_Instance; }

    private:
        void EarlyUpdate();
        void BeforeRendering();

        Semaphore m_CameraImageReady;


        bool m_IsRegistered;

        static RuntimeStatic<EngineCallbackHandler> s_Instance;
    };
} // namespace Tango
