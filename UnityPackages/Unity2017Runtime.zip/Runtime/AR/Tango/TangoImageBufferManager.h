#pragma once

#include "TangoBufferManager.h"
#include "TangoImageData.h"

namespace Tango
{
    class ImageBufferManager : public BufferManager<ImageData>
    {
    public:

        ImageBufferManager(UInt32 numConsumers, MemLabelId memoryLabel);

    private:

        void CopyBuffer(
            ImageData* destinationBuffer,
            const ImageData* sourceBuffer) override;
    };
} // namespace Tango
