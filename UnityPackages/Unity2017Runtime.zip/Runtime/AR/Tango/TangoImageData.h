#pragma once

#include "External/Tango/builds/gen/ApiFuncTangoClient.h"

namespace Tango
{
    struct ImageData
    {
        TangoExternal::TangoImage image;
        TangoExternal::TangoCameraMetadata metadata;
    };
} // namespace Tango
