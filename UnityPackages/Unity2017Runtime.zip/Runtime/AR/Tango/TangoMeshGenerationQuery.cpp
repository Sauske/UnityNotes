#include "UnityPrefix.h"

#if PLATFORM_ANDROID

#include "TangoMeshGenerationQuery.h"
#include "TangoResourcePool.h"
#include "ARScriptingClasses.h"

namespace Tango
{
namespace MeshReconstruction
{
    void GenerationQuery::Reset()
    {
        onDataReady.ReleaseAndClear();
        memset(&jobFence, 0, sizeof(JobFence));
        ResourcePool<GenerationQuery>::GetInstance().Free(this);
    }
} // namespace Tango
} // namespace MeshReconstruction

#endif
