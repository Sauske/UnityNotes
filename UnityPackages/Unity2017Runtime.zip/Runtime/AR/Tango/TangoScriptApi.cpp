#include "UnityPrefix.h"
#include "TangoScriptApi.h"
#include "ARScriptingClasses.h"
#include "Runtime/Scripting/Scripting.h"
#include "Runtime/Scripting/ScriptingUtility.h"

#if PLATFORM_ANDROID
#   include "TangoDevice.h"
#   include "TangoSupport.h"
#   include "TangoMeshReconstructionServer.h"
#endif

namespace Tango
{
    // This function doesn't live behind the PLATFORM_ANDROID define
    // because it needs to exist on non-Android platforms. The bindings
    // generator can auto-generate stub methods for most things, but we
    // want to return a special ENUM in this case.
    CoordinateFrame DeviceScriptApi::GetBaseCoordinateFrame()
    {
#if PLATFORM_ANDROID
        if (GetDevice())
            return GetDevice()->GetBaseCoordinateFrame();
#endif

        return kTangoCoordinateFrameInvalid;
    }

#if PLATFORM_ANDROID
    DeviceScriptApi::PointerToLockcountMap DeviceScriptApi::s_PointClouds;
    DeviceScriptApi::PointerToLockcountMap DeviceScriptApi::s_ImageBuffers;

    void DeviceScriptApi::SetBaseCoordinateFrame(CoordinateFrame frame, ScriptingExceptionPtr* exception)
    {
        if (GetDevice())
        {
            if (!GetDevice()->SetBaseCoordinateFrame(frame))
            {
                *exception = Scripting::CreateArgumentException(
                        "%d is not a valid base CoordinateFrame.",
                        (int)frame);
            }
        }
    }

    static void CopyStringVectorToDynamicArray(
        const std::vector<core::string>& stringVector,
        dynamic_array<core::string>& output)
    {
        output.reserve(stringVector.size());
        for (size_t i = 0; i < stringVector.size(); ++i)
        {
            output.push_back(stringVector[i]);
        }
    }

    bool DeviceScriptApi::Connect(
        const std::vector<core::string>& boolKeys, const dynamic_array<bool>& boolValues,
        const std::vector<core::string>& intKeys, const dynamic_array<int>& intValues,
        const std::vector<core::string>& longKeys, const dynamic_array<SInt64>& longValues,
        const std::vector<core::string>& doubleKeys, const dynamic_array<double>& doubleValues,
        const std::vector<core::string>& stringKeys, const std::vector<core::string>& stringValues)
    {
        Device* tangoDevice = GetDevice();

        if (tangoDevice)
        {
            Config config;

            CopyStringVectorToDynamicArray(boolKeys, config.boolKeysVec);
            config.boolValuesVec = boolValues;
            CopyStringVectorToDynamicArray(intKeys, config.intKeysVec);
            config.intValuesVec = intValues;
            CopyStringVectorToDynamicArray(longKeys, config.longKeysVec);
            config.longValuesVec = longValues;
            CopyStringVectorToDynamicArray(doubleKeys, config.doubleKeysVec);
            config.doubleValuesVec = doubleValues;
            CopyStringVectorToDynamicArray(stringKeys, config.stringKeysVec);
            CopyStringVectorToDynamicArray(stringValues, config.stringValuesVec);

            return tangoDevice->Connect(config);
        }

        return false;
    }

    void DeviceScriptApi::Disconnect()
    {
        if (GetDevice())
            return GetDevice()->Disconnect();
    }

    bool DeviceScriptApi::TryGetHorizontalFov(float* fovOut)
    {
        if (GetDevice())
            return GetDevice()->GetHorizontalFov(fovOut);

        return false;
    }

    bool DeviceScriptApi::TryGetVerticalFov(float* fovOut)
    {
        if (GetDevice())
            return GetDevice()->GetVerticalFov(fovOut);

        return false;
    }

    void DeviceScriptApi::SetRenderMode(ARRenderMode mode)
    {
        if (GetDevice())
            GetDevice()->SetRenderMode(mode);
    }

    unsigned int DeviceScriptApi::GetDepthCameraRate()
    {
        if (GetDevice())
            return static_cast<unsigned int>(GetDevice()->GetDepthCameraFramerate());

        return 0;
    }

    void DeviceScriptApi::SetDepthCameraRate(unsigned int value)
    {
        if (GetDevice())
            GetDevice()->SetDepthCameraFramerate(value);
    }

    bool DeviceScriptApi::GetSynchronizeFramerateWithColorCamera()
    {
        if (GetDevice())
            return GetDevice()->GetSynchronizeFramerateWithColorCamera();

        return false;
    }

    void DeviceScriptApi::SetSynchronizeFramerateWithColorCamera(bool value)
    {
        if (GetDevice())
            GetDevice()->SetSynchronizeFramerateWithColorCamera(value);
    }

    void DeviceScriptApi::SetBackgroundMaterial(Material* material)
    {
        if (GetDevice())
            GetDevice()->SetBackgroundMaterial(material);
    }

    template<typename T>
    static inline T* ScriptingListResize(ScriptingObjectPtr list, UInt32 size, ScriptingClassPtr klass)
    {
        GenericListData& gld = ExtractManagedObjectData<GenericListData>(list);
        const int capacity = GetScriptingArraySize(gld.array);
        gld.size = size;

        if (capacity < gld.size)
            gld.array = CreateScriptingArray<T>(klass, gld.size);

        gld.version++;

        return Scripting::GetScriptingArrayStart<T>(gld.array);
    }

    bool DeviceScriptApi::TryGetLatestPointCloudInternal(ScriptingObjectPtr pointCloudData, UInt32* version, double* timestamp)
    {
        if (!GetDevice())
            return false;

        PointCloudManager* pointCloudManager = GetPointCloudManager();
        if (pointCloudManager == nullptr)
            return false;

        const TangoExternal::TangoPointCloud* rawPointCloud = pointCloudManager->AcquireLatestBuffer();
        if (rawPointCloud == nullptr)
            return false;

        PointCloudManager::AutoReadLock lock(*pointCloudManager, rawPointCloud);

        // Check if a pose exists at this time.
        if (!DeviceHasValidPoseAtTime(rawPointCloud->timestamp))
            return false;

        // Copy the points into scripting array
        Vector4f* managedPointData = ScriptingListResize<Vector4f>(
                pointCloudData,
                rawPointCloud->num_points,
                GetCoreScriptingClasses().vector4);

        // Store the point data
        UNITY_MEMCPY(managedPointData, rawPointCloud->points, sizeof(Vector4f) * rawPointCloud->num_points);

        *version = rawPointCloud->version;
        *timestamp = rawPointCloud->timestamp;

        return true;
    }

    static void FillPlaneInfos(const TangoExternal::TangoImage& image, ScriptingObjectPtr planeInfos)
    {
        // Fill out the PlaneInfo
        ImagePlaneInfo* managedPlaneInfos = ScriptingListResize<ImagePlaneInfo>(planeInfos, image.num_planes, GetARScriptingClasses().imageDataPlaneInfo);
        for (UInt32 i = 0; i < image.num_planes; ++i, ++managedPlaneInfos)
        {
            ImagePlaneInfo& planeInfo = *managedPlaneInfos;
            planeInfo.offset = image.plane_data[i] - image.plane_data[0];
            planeInfo.size = image.plane_size[i];
            planeInfo.rowStride = image.plane_row_stride[i];
            planeInfo.pixelStride = image.plane_pixel_stride[i];
        }
    }

    static void PopulateImageDataFields(
        const ImageData& imageData,
        ScriptingObjectPtr planeInfosOut,
        UInt32* widthOut,
        UInt32* heightOut,
        int* formatOut,
        SInt64* timestampOut,
        CameraMetadata& metadataOut)
    {
        const TangoExternal::TangoImage& image = imageData.image;
        *widthOut = image.width;
        *heightOut = image.height;
        *formatOut = image.format;
        *timestampOut = image.timestamp_ns;

        FillPlaneInfos(image, planeInfosOut);

        const TangoExternal::TangoCameraMetadata& metadata = imageData.metadata;
        metadataOut.timestamp_ns = metadata.timestamp_ns;
        metadataOut.frame_number = metadata.frame_number;
        metadataOut.exposure_duration_ns = metadata.exposure_duration_ns;
        metadataOut.sensitivity_iso = metadata.sensitivity_iso;
        metadataOut.lens_aperture = metadata.lens_aperture;
        metadataOut.color_correction_mode = metadata.color_correction_mode;
        UNITY_MEMCPY(metadataOut.color_correction_gains, metadata.color_correction_gains,
            sizeof(metadata.color_correction_gains));
        UNITY_MEMCPY(metadataOut.color_correction_transform, metadata.color_correction_transform,
            sizeof(metadata.color_correction_transform));
        UNITY_MEMCPY(metadataOut.sensor_neutral_color_point, metadata.sensor_neutral_color_point,
            sizeof(metadata.sensor_neutral_color_point));
    }

    bool DeviceScriptApi::TryGetLatestImageDataInternal(
        ScriptingObjectPtr imageDataOut,
        ScriptingObjectPtr planeInfosOut,
        UInt32* widthOut,
        UInt32* heightOut,
        SInt32* formatOut,
        SInt64* timestampOut,
        CameraMetadata& metadataOut)
    {
        if (!GetDevice())
            return false;

        ImageBufferManager* imageManager = GetImageBufferManager();
        if (imageManager == nullptr)
            return false;

        const ImageData* rawImageData = imageManager->AcquireLatestBuffer();
        if (rawImageData == nullptr)
            return false;

        ImageBufferManager::AutoReadLock lock(*imageManager, rawImageData);

        const TangoExternal::TangoImage& image = rawImageData->image;

        // Check if a pose exists at this time.
        const double timestamp = (double)image.timestamp_ns * 1e-9;
        if (!DeviceHasValidPoseAtTime(timestamp))
            return false;

        PopulateImageDataFields(
            *rawImageData,
            planeInfosOut,
            widthOut,
            heightOut,
            formatOut,
            timestampOut,
            metadataOut);

        // Copy the "plane data" into the array
        const UInt32 imageDataSize = GetNumBytesForImageBuffer(image);
        UInt8* managedImageData = ScriptingListResize<UInt8>(imageDataOut, imageDataSize, GetCommonScriptingClasses().byte);
        std::copy(image.plane_data[0], image.plane_data[0] + imageDataSize, managedImageData);

        return true;
    }

    bool DeviceScriptApi::GetIsServiceConnected()
    {
        if (GetDevice())
            return GetDevice()->IsServiceConnected();

        return false;
    }

    bool DeviceScriptApi::GetIsServiceAvailable()
    {
        return (GetDevice() != nullptr && GetTangoClientPlugin().pluginLoaded);
    }

    template<typename T> static inline double GetTimestamp(const T* buffer);
    template<> inline double GetTimestamp<TangoExternal::TangoPointCloud>(const TangoExternal::TangoPointCloud* pointCloud)
    {
        return pointCloud->timestamp;
    }

    template<> inline double GetTimestamp<ImageData>(const ImageData* imageData)
    {
        return static_cast<double>(imageData->image.timestamp_ns) * 1e-9;
    }

    template<typename T>
    T* DeviceScriptApi::AcquireLatestBuffer()
    {
        BufferManager<T>* manager = GetManager<T>();
        if (manager)
        {
            T* buffer = const_cast<T*>(manager->AcquireLatestBuffer());
            if (buffer)
            {
                // It's possible that the last buffer is old and there is
                // not really a valid one at this time. This check ensures we
                // also get a pose.
                if (!DeviceHasValidPoseAtTime(GetTimestamp<T>(buffer)))
                {
                    manager->ReleaseBuffer(buffer);
                    return nullptr;
                }

                PointerToLockcountMap& lockCountMap = GetPointerToLockcountMap<T>();
                PointerToLockcountMap::iterator iter = lockCountMap.find(buffer);
                if (iter == lockCountMap.end())
                {
                    lockCountMap[buffer] = 1;
                }
                else
                {
                    ++iter->second;
                }
            }

            return buffer;
        }

        return nullptr;
    }

    bool DeviceScriptApi::Internal_TryAcquireLatestPointCloud(
        UInt32* versionOut,
        double* timestampOut,
        UInt32* numPointsOut,
        void** pointsOut,
        void** nativePtrOut)
    {
        TangoExternal::TangoPointCloud* pointCloud =
            AcquireLatestBuffer<TangoExternal::TangoPointCloud>();

        *nativePtrOut = pointCloud;

        if (pointCloud)
        {
            *versionOut = pointCloud->version;
            *timestampOut = pointCloud->timestamp;
            *numPointsOut = pointCloud->num_points;
            *pointsOut = pointCloud->points;
        }

        return pointCloud != nullptr;
    }

    bool DeviceScriptApi::Internal_TryAcquireLatestImageBuffer(
        ScriptingObjectPtr planeInfosOut,
        UInt32* widthOut,
        UInt32* heightOut,
        int* formatOut,
        SInt64* timestampOut,
        void** planeDataOut,
        void** nativePtrOut,
        CameraMetadata& metadataOut)
    {
        ImageData* imageData =
            AcquireLatestBuffer<ImageData>();

        *nativePtrOut = imageData;

        if (imageData)
        {
            PopulateImageDataFields(
                *imageData,
                planeInfosOut,
                widthOut,
                heightOut,
                formatOut,
                timestampOut,
                metadataOut);

            *planeDataOut = imageData->image.plane_data[0];
        }

        return imageData != nullptr;
    }

    template<>
    DeviceScriptApi::PointerToLockcountMap& DeviceScriptApi::GetPointerToLockcountMap<TangoExternal::TangoPointCloud>()
    {
        return s_PointClouds;
    }

    template<>
    DeviceScriptApi::PointerToLockcountMap& DeviceScriptApi::GetPointerToLockcountMap<ImageData>()
    {
        return s_ImageBuffers;
    }

    // This is just so we can surface a useful exception message to the user
    template<typename T> static inline const char* GetBufferName();
    template<> inline const char* GetBufferName<TangoExternal::TangoPointCloud>() { return "a point cloud"; }
    template<> inline const char* GetBufferName<ImageData>() { return "an image buffer"; }

    template<typename T>
    void DeviceScriptApi::ReleaseBuffer(void* ptr, ScriptingExceptionPtr* exception)
    {
        T* buffer = static_cast<T*>(ptr);
        BufferManager<T>* manager = GetManager<T>();

        if (manager && buffer)
        {
            PointerToLockcountMap& lockCountMap = GetPointerToLockcountMap<T>();
            PointerToLockcountMap::iterator iter = lockCountMap.find(buffer);
            if (iter == lockCountMap.end())
            {
                *exception = Scripting::CreateInvalidOperationException(
                        "Tried to release %s that has not been acquired via script.",
                        GetBufferName<T>());
            }
            else
            {
                DebugAssert(iter->second > 0);
                manager->ReleaseBuffer(buffer);

                if (--iter->second == 0)
                    lockCountMap.erase(iter);
            }
        }
    }

    void DeviceScriptApi::Internal_ReleasePointCloud(void* ptr, ScriptingExceptionPtr* exception)
    {
        ReleaseBuffer<TangoExternal::TangoPointCloud>(ptr, exception);
    }

    void DeviceScriptApi::Internal_ReleaseImageBuffer(void* ptr, ScriptingExceptionPtr* exception)
    {
        ReleaseBuffer<ImageData>(ptr, exception);
    }

    bool InputTrackingScriptApi::Internal_TryGetPoseAtTime(
        double time,
        ScreenOrientation screenOrientation,
        CoordinateFrame baseFrame,
        CoordinateFrame targetFrame,
        PoseData& pose)
    {
        if (ARCore::ARCoreManager::GetInstance()->IsRunning())
        {
            bool success = ARCore::ARCoreManager::GetInstance()->GetPose(&pose);

            pose.status_code = success ? kTangoPoseValid : kTangoPoseInvalid;

            return success;
        }
        else if (GetDevice())
        {
            return GetDevice()->GetPoseAtTime(time, screenOrientation, baseFrame, targetFrame, &pose);
        }
        else
        {
            return false;
        }
    }

    void ServerScriptApi::Internal_ClearMeshes(void* server)
    {
        if (server)
            static_cast<MeshReconstruction::Server*>(server)->ClearReconstructedMeshes();
    }

    bool ServerScriptApi::Internal_GetEnabled(void* server)
    {
        if (server)
            return static_cast<MeshReconstruction::Server*>(server)->GetEnabled();

        return false;
    }

    void ServerScriptApi::Internal_SetEnabled(void* server, bool enabled)
    {
        if (server)
            static_cast<MeshReconstruction::Server*>(server)->SetEnabled(enabled);
    }

    void* ServerScriptApi::Internal_GetNativeReconstructionContextPtr(void* server)
    {
        if (server)
            return static_cast<MeshReconstruction::Server*>(server)->GetNativeReconstructionContext();

        return NULL;
    }

    int ServerScriptApi::Internal_GetNumGenerationRequests(void* server)
    {
        if (server)
            return static_cast<MeshReconstruction::Server*>(server)->GetNumGenerationRequests();

        return 0;
    }

    void* ServerScriptApi::Internal_Create(
        ScriptingObjectPtr self,
        const MeshReconstruction::Config& config,
        int* statusOut)
    {
        if (GetDevice())
        {
            MeshReconstruction::CreationStatus creationStatus;
            void* server = GetDevice()->CreateMeshReconstructionServer(self, config, &creationStatus);
            *statusOut = (int)creationStatus;
            return server;
        }

        return NULL;
    }

    void ServerScriptApi::Destroy(void* server)
    {
        AssertMsg(server, "Server should never be null.");
        if (GetDevice() && server)
        {
            return GetDevice()->DestroyMeshReconstructionServer(
                static_cast<MeshReconstruction::Server*>(server));
        }
    }

    void ServerScriptApi::DestroyThreaded(void* server)
    {
        AssertMsg(server, "Server should never be null.");
        if (GetDevice() && server)
        {
            GetDevice()->DestroyThreadedMeshReconstructionServer(
                static_cast<MeshReconstruction::Server*>(server));
        }
    }

    void ServerScriptApi::Internal_GetChangedSegments(void* server, ScriptingObjectPtr onSegmentChanged)
    {
        if (server)
            static_cast<MeshReconstruction::Server*>(server)->GetChangedSegments(onSegmentChanged);
    }

    void ServerScriptApi::Internal_GenerateSegmentAsync(
        void* server,
        const MeshReconstruction::GridIndex& gridIndex,
        MeshFilter* destinationMeshFilter,
        MeshCollider* destinationMeshCollider,
        ScriptingObjectPtr onSegmentReady,
        bool provideNormals,
        bool provideColors,
        bool providePhysics)
    {
        if (server)
        {
            static_cast<MeshReconstruction::Server*>(server)->GenerateSegmentAsync(
                gridIndex,
                destinationMeshFilter,
                destinationMeshCollider,
                onSegmentReady,
                provideNormals,
                provideColors,
                providePhysics);
        }
    }

#endif // PLATFORM_ANDROID
} // namespace Tango
