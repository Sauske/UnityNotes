#include "UnityPrefix.h"

#if PLATFORM_ANDROID

#include "Runtime/Dynamics/PhysXPrefix.h"
#include "External/PhysX3/builds/Include/geometry/PxTriangleMesh.h"

#include "TangoMeshGenerationResult.h"
#include "TangoResourcePool.h"

namespace Tango
{
namespace MeshReconstruction
{
// Most meshes have 0 - a few hundred triangles, so start with
// something big enough to cover most use cases.
    UInt32 GenerationResult::kInitialVertexBufferSize = 2000;
    UInt32 GenerationResult::kInitialIndexBufferSize = 1000 * 3;

    GenerationResult::GenerationResult()
        : vertices(kInitialVertexBufferSize, kMemSpatialMapping)
        , indices(kInitialIndexBufferSize, kMemSpatialMapping)
        , normals(kInitialVertexBufferSize, kMemSpatialMapping)
        , colors(kInitialVertexBufferSize, kMemSpatialMapping)
        , textureCoords(kInitialVertexBufferSize, kMemSpatialMapping)
        , physicsMesh(nullptr)
        , elapsedTime(0.0)
    {}

    void GenerationResult::Reset(bool releasePhysicsData)
    {
        // Release PhysX data if it wasn't consumed
        if (releasePhysicsData && physicsMesh != nullptr)
        {
            physicsMesh->release();
        }

        physicsMesh = nullptr;

        // Reset arrays (but don't deallocate)
        vertices.resize_uninitialized(0);
        indices.resize_uninitialized(0);
        normals.resize_uninitialized(0);
        colors.resize_uninitialized(0);
        textureCoords.resize_uninitialized(0);

        elapsedTime = 0.0;

        // Return to pool
        ResourcePool<GenerationResult>::GetInstance().Free(this);
    }
} // namespace Tango
} // namespace MeshReconstruction

#endif
