#include "UnityPrefix.h"

#if PLATFORM_ANDROID

#include "TangoSupport.h"
#include "TangoProfiler.h"
#include "TangoMeshReconstructionServerManager.h"
#include "TangoMeshReconstructionServer.h"
#include "TangoImageBufferManager.h"
#include "TangoPointCloudManager.h"

namespace Tango
{
namespace MeshReconstruction
{
    ServerManager::ServerManager()
        : m_pendingDeletes(kMemSpatialMapping)
    {}

    ServerManager::~ServerManager()
    {
        if (m_WorkerThread.IsRunning())
        {
            m_WorkerThread.SignalQuit();
            m_WorkerSemaphore.Signal();
            m_WorkerThread.WaitForExit(true);
        }

        // No need to lock any mutexes here because shutdown should happen
        // from the same thread that requests new servers. We also know
        // the worker thread has already been shutdown.
        for (Server* server : m_Servers)
        {
            server->Destroy();
        }
    }

    void ServerManager::SetColorCameraEnabled(bool isEnabled)
    {
        m_ColorGenerationFlags = SetOrClearFlags(m_ColorGenerationFlags, kIsColorCameraEnabled, isEnabled);
    }

    Server* ServerManager::CreateServer(ScriptingObjectPtr self, const Config& config, CreationStatus* statusOut)
    {
        Server* newServer = Server::Create(self, config, statusOut);

        if (newServer == nullptr)
            return nullptr;

        // We iterate over the hash table in a callback
        // from a separate thread so lock it here.
        {
            Mutex::AutoLock guard(m_ServerListMutex);
            m_Servers.push_back(newServer);

            if (config.generateColor)
            {
                m_ColorGenerationFlags = SetFlags(m_ColorGenerationFlags, kAtLeastOneServerNeedsColor);
            }
        }

        StartWorkerThreadIfNotRunning();

        return newServer;
    }

    void ServerManager::ProcessPendingDeletes()
    {
        // Called from the worker thread
        if (OPTIMIZER_UNLIKELY(m_pendingDeletes.size() > 0))
        {
            for (Server* serverToRemove : m_pendingDeletes)
            {
                serverToRemove->DestroyThreaded();
                ServerArray::iterator iter = std::find(m_Servers.begin(), m_Servers.begin() + m_Servers.size(), serverToRemove);
                m_Servers.erase_swap_back(iter);
            }

            m_pendingDeletes.clear();

            // Update color camera flag
            UpdateColorCameraFlag();
        }
    }

    void ServerManager::StartWorkerThreadIfNotRunning()
    {
        if (!m_WorkerThread.IsRunning())
        {
            m_WorkerThread.Run(StaticThreadEntry, this);
        }
    }

    void ServerManager::DestroyServer(Server* server)
    {
        Mutex::AutoLock lock(m_ServerListMutex);
        m_pendingDeletes.push_back(server);
    }

    void ServerManager::DestroyThreadedServer(Server* server)
    {
        Mutex::AutoLock lock(m_ServerListMutex);
        m_pendingDeletes.push_back(server);
    }

    const TangoExternal::TangoPoseData* ServerManager::GetPoseAtTime(
        double timestamp,
        CoordinateFrame targetFrame,
        TangoExternal::TangoPoseData* poseData)
    {
        TangoExternal::TangoCoordinateFramePair framePair =
        {
            UnityToTango(kTangoCoordinateFrameStartOfService),
            UnityToTango(targetFrame)
        };

        // The 3d reconstruction library can't handle a left-handed coordinate
        // system, so we query the native Tango pose directly. The conversion
        // back to Unity space is instead handled by the "external_T_tango"
        // configuration option.
        const TangoExternal::TangoErrorType poseError =
            Tango::GetTangoClientPlugin().GetPoseAtTime(timestamp, framePair, poseData);

        // It's possible for GetPoseAtTime to return success but have the pose be invalid.
        // The meaning is "we successfully determined that the pose is invalid"
        if (poseError != TangoExternal::TANGO_SUCCESS || poseData->status_code != TangoExternal::TANGO_POSE_VALID)
        {
#if UNITY_DEVELOPER_BUILD
            ErrorStringMsg("Could not find a valid pose at time "
                "%1f for camera %d.", timestamp, (int)targetFrame);
#endif

            return nullptr;
        }

        return poseData;
    }

    void ServerManager::SignalWorkerThread()
    {
        m_HasUpdatedColorImage = false;
        m_HasUpdatedPointCloud = false;
        m_WorkerSemaphore.Signal();
    }

    void* ServerManager::StaticThreadEntry(void* data)
    {
        ServerManager* self = reinterpret_cast<ServerManager*>(data);
        self->ThreadEntry();

        return nullptr;
    }

    void ServerManager::ThreadEntry()
    {
        ON_ENABLE_TANGO_PROFILING(Profiler profiler);
        ON_ENABLE_TANGO_PROFILING(profiler.Initialize("Tango", "Mesh Reconstruction Worker"));

        while (true)
        {
            m_WorkerSemaphore.WaitForSignal();
            if (m_WorkerThread.IsQuitSignaled())
            {
                break;
            }
            else
            {
                ON_ENABLE_TANGO_PROFILING(profiler.Update());

                ConstServerArray serversToUpdate;
                {
                    Mutex::AutoLock lock(m_ServerListMutex);
                    ProcessPendingDeletes();
                    for (const Server* server : m_Servers)
                    {
                        if (server->GetEnabled())
                        {
                            serversToUpdate.push_back(server);
                        }
                    }
                }

                UpdateGridIndices(serversToUpdate);
            }
        }

        ON_ENABLE_TANGO_PROFILING(profiler.Shutdown());
    }

    void ServerManager::UpdateColorCameraFlag()
    {
        m_ColorGenerationFlags = ClearFlags(m_ColorGenerationFlags, kAtLeastOneServerNeedsColor);
        for (const Server* server : m_Servers)
        {
            if (server->GetEnabled() && server->GetConfig().generateColor)
            {
                m_ColorGenerationFlags = SetFlags(m_ColorGenerationFlags, kAtLeastOneServerNeedsColor);
                break;
            }
        }
    }

    void ServerManager::UpdateServers(
        const ConstServerArray& servers,
        const TangoExternal::TangoPointCloud& pointCloud,
        const TangoExternal::TangoPoseData& pointCloudPose,
        const TangoExternal::TangoImage* imageBuffer,
        const TangoExternal::TangoPoseData* imagePose)
    {
        for (const Server* server : servers)
        {
            server->Update(pointCloud, pointCloudPose, imageBuffer, imagePose);
        }
    }

    const TangoExternal::TangoPointCloud* ServerManager::AcquirePointCloud()
    {
        PointCloudManager* manager = Tango::GetPointCloudManager();

        if (manager)
        {
            m_AcquiredPointCloud = manager->AcquireLatestBuffer();
            return m_AcquiredPointCloud;
        }

#if UNITY_DEVELOPER_BUILD
        ErrorString("Could not get latest point cloud.");
#endif

        return nullptr;
    }

    void ServerManager::ReleasePointCloud()
    {
        PointCloudManager* manager = GetPointCloudManager();

        if (manager && m_AcquiredPointCloud)
        {
            manager->ReleaseBuffer(m_AcquiredPointCloud);
        }

        m_AcquiredPointCloud = nullptr;
    }

    const ImageData* ServerManager::AcquireImageBuffer()
    {
        ImageBufferManager* manager = GetImageBufferManager();

        if (manager)
        {
            m_AcquiredImageBuffer = manager->AcquireLatestBuffer();
            return m_AcquiredImageBuffer;
        }

#if UNITY_DEVELOPER_BUILD
        ErrorString("Could not get latest image buffer.");
#endif

        return nullptr;
    }

    void ServerManager::ReleaseImageBuffer()
    {
        ImageBufferManager* manager = GetImageBufferManager();

        if (manager && m_AcquiredImageBuffer)
        {
            manager->ReleaseBuffer(m_AcquiredImageBuffer);
        }

        m_AcquiredImageBuffer = nullptr;
    }

    const TangoExternal::TangoPoseData* ServerManager::GetDepthPose(double timestamp)
    {
        return GetPoseAtTime(timestamp, kTangoCoordinateFrameCameraDepth, &m_PointCloudPose);
    }

    const TangoExternal::TangoPoseData* ServerManager::GetColorCameraPose(double timestamp)
    {
        return GetPoseAtTime(timestamp, kTangoCoordinateFrameCameraColor, &m_ColorCameraPose);
    }

    void ServerManager::UpdateGridIndices(const ConstServerArray& servers)
    {
        const TangoExternal::TangoPointCloud* pointCloud = AcquirePointCloud();

        if (pointCloud)
        {
            const TangoExternal::TangoPoseData* pointCloudPose = GetDepthPose(pointCloud->timestamp);

            if (pointCloudPose)
            {
                const TangoExternal::TangoImage* imageBuffer = nullptr;
                const TangoExternal::TangoPoseData* imagePose = nullptr;

                if (IsColorGenerationEnabled())
                {
                    const ImageData* imageData = AcquireImageBuffer();
                    if (imageData)
                    {
                        imageBuffer = &imageData->image;
                        imagePose = GetColorCameraPose(static_cast<double>(imageBuffer->timestamp_ns) * 1e-9);
                        if (imagePose == nullptr)
                        {
                            ReleaseImageBuffer();
                            imageBuffer = nullptr;
                        }
                    }
                }

                UpdateServers(servers, *pointCloud, *pointCloudPose, imageBuffer, imagePose);
            }
        }

        ReleaseImageBuffer();
        ReleasePointCloud();
    }

    void ServerManager::OnPointCloudAvailable(const TangoExternal::TangoPointCloud* tangoPointCloud)
    {
        // If color is enabled, then we need to have both a point cloud and
        // a color image before signaling the worker thread.
        if (m_HasUpdatedColorImage || !IsColorGenerationEnabled())
        {
            SignalWorkerThread();
        }
        else
        {
            m_HasUpdatedPointCloud = true;
        }
    }

    void ServerManager::OnImageAvailable(
        TangoExternal::TangoCameraId id)
    {
        if (id != TangoExternal::TANGO_CAMERA_COLOR)
            return;

        if (!IsColorGenerationEnabled())
            return;

        if (m_HasUpdatedPointCloud)
        {
            SignalWorkerThread();
        }
        else
        {
            m_HasUpdatedColorImage = true;
        }
    }
} // namespace MeshReconstruction
} // namespace Tango

#endif
