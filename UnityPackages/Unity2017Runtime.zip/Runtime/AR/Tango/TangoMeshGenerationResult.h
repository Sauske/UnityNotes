#pragma  once

#if PLATFORM_ANDROID

#include "Runtime/Math/Color.h"
#include "Runtime/Math/Vector2.h"
#include "Runtime/Math/Vector3.h"
#include "Runtime/Utilities/dynamic_array.h"

namespace physx
{
    class PxTriangleMesh;
}

namespace TangoExternal
{
    struct Tango3DR_Mesh;
}

namespace Tango
{
namespace MeshReconstruction
{
    struct GenerationResult
    {
    private:
        static UInt32 kInitialVertexBufferSize;
        static UInt32 kInitialIndexBufferSize;

    public:
        GenerationResult();

        // Releases platformData & (optionally) physicsMesh
        // and resizes all arrays to 0 (but does not release the memory).
        // This is so it can participate in a reusable pool
        // (see usage of ExtractPreallocatedMeshSegment)
        void Reset(bool releasePhysicsData);

        // Buffers for ExtractPreallocatedMeshSegment
        dynamic_array<Vector3f> vertices;
        dynamic_array<UInt32> indices;
        dynamic_array<Vector3f> normals;
        dynamic_array<ColorRGBA32> colors;
        dynamic_array<Vector2f> textureCoords;

        // The physx mesh with baked bv-tree acceleration structure
        physx::PxTriangleMesh* physicsMesh;
        double elapsedTime;
    };
} // namespace Tango
} // namespace MeshReconstruction

#endif
