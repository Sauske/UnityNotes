#include "UnityPrefix.h"

#if PLATFORM_ANDROID

#include "TangoImageBufferManager.h"
#include "TangoSupport.h"
#include "Runtime/Allocator/MemoryMacros.h"

namespace Tango
{
    template<>
    void* BufferManager<ImageData>::GetDataPtr(ImageData* buffer)
    {
        return buffer->image.plane_data[0];
    }

    template<>
    const void* BufferManager<ImageData>::GetDataPtr(const ImageData* buffer)
    {
        return buffer->image.plane_data[0];
    }

    template<>
    void BufferManager<ImageData>::SetDataPtr(ImageData* buffer, void* data)
    {
        buffer->image.plane_data[0] = static_cast<UInt8*>(data);
    }

    template<>
    UInt32 BufferManager<ImageData>::ComputeDataSize(const ImageData* buffer)
    {
        return GetNumBytesForImageBuffer(buffer->image);
    }

    void ImageBufferManager::CopyBuffer(
        ImageData* destinationBuffer,
        const ImageData* sourceBuffer)
    {
        const UInt32 sourceSize = ComputeDataSize(sourceBuffer);
        const UInt32 destinationSize = ComputeDataSize(destinationBuffer);

        const TangoExternal::TangoImage& srcImage = sourceBuffer->image;
        TangoExternal::TangoImage& dstImage = destinationBuffer->image;

        CopyMetadata(destinationBuffer, sourceBuffer);

        if (destinationSize < sourceSize)
        {
            // Reallocate
            UNITY_FREE(m_MemoryLabel, dstImage.plane_data[0]);
            dstImage.plane_data[0] = static_cast<UInt8*>(UNITY_MALLOC(m_MemoryLabel, sourceSize));
        }

        // Now make a copy of the actual data
        UNITY_MEMCPY(dstImage.plane_data[0], srcImage.plane_data[0], sourceSize);

        // Fix up pointers.
        for (UInt32 i = 1; i < srcImage.num_planes; ++i)
        {
            const UInt32 offset = srcImage.plane_data[i] - srcImage.plane_data[0];
            dstImage.plane_data[i] = dstImage.plane_data[0] + offset;
        }
    }

    template<>
    bool BufferManager<ImageData>::IsTimestampGreaterThanZero(
        const ImageData& imageData)
    {
        return imageData.image.timestamp_ns > 0;
    }

    template<>
    bool BufferManager<ImageData>::IsTimestampGreaterThan(
        const ImageData& lhs,
        const ImageData& rhs)
    {
        return lhs.image.timestamp_ns > rhs.image.timestamp_ns;
    }

    ImageBufferManager::ImageBufferManager(UInt32 numConsumers, MemLabelId memoryLabel)
        : BufferManager(numConsumers, memoryLabel)
    {
    }
} // namespace Tango

#endif
