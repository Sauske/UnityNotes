#include "UnityPrefix.h"

#if PLATFORM_ANDROID

#include <cstdlib>
#include "JNI_Register.h"
#include "NativeRuntimeException.h"
#include "TangoBinder.h"
#include "TangoDevice.h"
#include "TangoSupport.h"
#include "TangoEngineCallbackHandler.h"
#include "TangoProfiler.h"
#include "Runtime/Core/Callbacks/GlobalCallbacks.h"
#include "Runtime/SceneManager/SceneManager.h"
#include "Runtime/SceneManager/UnitySceneHandle.h"
#include "Runtime/Serialize/AwakeFromLoadQueue.h"

namespace Tango
{
    class BinderProfilerManager
    {
        struct ThreadIdProfilerPair
        {
            Thread::ThreadID threadId;
            Profiler* profiler;
        };

    public:
        BinderProfilerManager(MemLabelId memoryLabel)
            : m_MemoryLabel(memoryLabel)
            , m_Profilers(memoryLabel)
        {}

        ~BinderProfilerManager()
        {
            DeleteAll();
        }

        Profiler* GetOrCreateProfilerForCurrentThread()
        {
            const Thread::ThreadID threadId = Thread::GetCurrentThreadID();

            for (UInt32 i = 0; i < m_Profilers.size(); ++i)
            {
                if (m_Profilers[i].threadId == threadId)
                    return m_Profilers[i].profiler;
            }

            ThreadIdProfilerPair& pair = m_Profilers.emplace_back_uninitialized();
            pair.threadId = threadId;
            pair.profiler = UNITY_NEW(Profiler, m_MemoryLabel);

            return pair.profiler;
        }

        void DeleteAll()
        {
            for (UInt32 i = 0; i < m_Profilers.size(); ++i)
            {
                UNITY_DELETE(m_Profilers[i].profiler, m_MemoryLabel);
            }
            m_Profilers.clear();
        }

    private:

        MemLabelId m_MemoryLabel;
        dynamic_array<ThreadIdProfilerPair> m_Profilers;
    };

    static RuntimeStatic<Tango::BinderProfilerManager, true> s_ProfilerManager(kMemDefault);

    void UpdateBinderProfilerForCurrentThread()
    {
#if 0
        // This is disabled for now since there is no way to shutdown
        // the profilers for these threads properly.
        if (s_ProfilerManager)
        {
            Profiler* profiler = s_ProfilerManager->GetOrCreateProfilerForCurrentThread();
            profiler->EnsureInitialized("Tango", "Binder thread");
            profiler->Update();
        }
#endif
    }
} // namespace Tango

// We distribute the Tango Support library in APKs for projects that are marked as supporting Tango
static void InitializeTango(
    const UnitySceneHandle sceneHandle,
    AwakeFromLoadQueue& awakeQueue,
    SceneManager::LoadingMode mode)
{
    // If we've gotten this far, we were able to load the Tango client lib.
    // Even if mesh reconstruction is unavailable, we can still use a lot of
    // the Tango features, and the mesh reconstruction server manager will check
    // to make sure the 3dr plugin is available. It's safe to initialize Device.
    Tango::Device::Initialize();
}

//
// Functions called by JNI - defined in TangoSupport.java
//

void tangoCacheTangoObject(JNIEnv* env, jobject thiz, jobject tango)
{
    JNI_METHOD_IMPL(void);

    if (!Tango::IsClientPluginLoaded())
    {
        ErrorString("Tango service connected but Tango client library not loaded. Tango service unavailable.");
        return;
    }

    // Associate the service binder to the Tango service.
    Tango::GetTangoClientPlugin().CacheTangoObject(env, tango);

    Tango::Device::SignalConnectionRequestedThreaded();
}

void tangoOnCreate(JNIEnv* env, jobject thiz, jobject caller_activity, jobject callback)
{
    JNI_METHOD_IMPL(void);

    if (!Tango::LoadTangoClientPlugin())
    {
        ErrorString("Unable to load the Tango client library. Tango service unavailable.");
        return;
    }

    Tango::GetCallerActivity() = caller_activity;
    Tango::GetTangoClientPlugin().CacheJavaObjects(env, callback);
    GlobalCallbacks::Get().sceneLoadedBeforeAwake.Register(&InitializeTango);
}

void tangoOnPause(JNIEnv* env, jobject thiz)
{
    JNI_METHOD_IMPL(void);

    if (Tango::IsClientPluginLoaded())
    {
        // Disconnecting from the service, resets all configuration,
        // and disconnects all callbacks. If an application resumes
        // after disconnecting, it must re-register configuration and
        // callbacks with the service.

        Tango::GetTangoClientPlugin().Disconnect();
        Tango::FreePointCloudManager();
        Tango::FreeImageBufferManager();
    }

    Tango::Device::SignalDisconnectRequestedThreaded();

#if ENABLE_PROFILER
    if (Tango::s_ProfilerManager)
        Tango::s_ProfilerManager->DeleteAll();
#endif
}

void tangoOnImageAvailable(JNIEnv* env, jobject thiz, jobject image, jobject metadata, jint camera_id)
{
    JNI_METHOD_IMPL(void);
    Tango::GetTangoClientPlugin().JavaCallback_OnImageAvailable(env, camera_id, image, metadata);
}

void tangoOnPointCloudAvailable(JNIEnv* env, jobject thiz, jobject point_cloud)
{
    JNI_METHOD_IMPL(void);
    Tango::GetTangoClientPlugin().JavaCallback_OnPointCloudAvailable(env, point_cloud);
}

void tangoOnPoseAvailable(JNIEnv* env, jobject thiz, jobject pose)
{
    JNI_METHOD_IMPL(void);
    Tango::GetTangoClientPlugin().JavaCallback_OnPoseAvailable(env, pose);
}

void tangoOnTangoEvent(JNIEnv* env, jobject thiz, jobject event)
{
    JNI_METHOD_IMPL(void);
    Tango::GetTangoClientPlugin().JavaCallback_OnTangoEvent(env, event);
}

void tangoOnTextureAvailable(JNIEnv* env, jobject thiz, jint camera_id)
{
    JNI_METHOD_IMPL(void);
    Tango::GetTangoClientPlugin().JavaCallback_OnTextureAvailable(camera_id);
}

#endif
