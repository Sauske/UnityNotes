#pragma once

#include "TangoARRendering.h"
#include "TangoSupport.h"
#include "TangoMeshReconstructionServerManager.h"
#include "Runtime/AR/ARTypes.h"
#include "Runtime/Graphics/ScreenManager.h"
#include "Runtime/Scripting/ScriptingTypes.h"
#include "Runtime/Utilities/RuntimeStatic.h"
#include "TangoMeshReconstructionTypes.h"

class Vector2f;
class Vector3f;
class Plane;
class Material;

namespace Tango
{
    //
    // Class that abstracts a Tango device and services most Tango scripting APIs
    //

    class Device
    {
        friend class EngineCallbackHandler;

    public:
        Device();
        ~Device();

        // Returns a pose in Tango coordinates.
        bool GetPoseAtTime(
            double time,
            ScreenOrientation screenOrientation,
            CoordinateFrame base,
            CoordinateFrame target,
            PoseData* outPose) const;

        // Poses routed through the input system will be
        // relative to this "base frame".
        bool SetBaseCoordinateFrame(CoordinateFrame baseFrame);
        CoordinateFrame GetBaseCoordinateFrame() const;

        bool GetHorizontalFov(float* fovOut);

        bool GetVerticalFov(float* fovOut);

        int GetDepthCameraFramerate() const;
        void SetDepthCameraFramerate(int framerate);

        bool GetSynchronizeFramerateWithColorCamera() const;
        void SetSynchronizeFramerateWithColorCamera(bool synchronize);

        bool Connect(const Config &config);
        void Disconnect();

        MeshReconstruction::Server* CreateMeshReconstructionServer(
            ScriptingObjectPtr self,
            const MeshReconstruction::Config& config,
            MeshReconstruction::CreationStatus* statusOut);

        void DestroyMeshReconstructionServer(
            MeshReconstruction::Server* server);

        void DestroyThreadedMeshReconstructionServer(
            MeshReconstruction::Server* server);

        void SetRenderMode(ARRenderMode value);

        ARRenderMode GetRenderMode() const;

        void SetBackgroundMaterial(Material* backgroundMaterial);

        bool IsServiceConnected() const { return m_IsConnected; }

        double GetTimeForPose(double time) const;

        static Device* GetInstance() { return s_Instance; }

        static bool IsInitialized() { return s_IsInitialized; }

        static void Initialize();

        static void SignalConnectionRequestedThreaded();

        static void SignalDisconnectRequestedThreaded();

    private:

        const Config &GetConfiguration();

        void OnPointCloudAvailable(
            const TangoExternal::TangoPointCloud* pointCloud);

        void OnColorImageAvailable(
            TangoExternal::TangoCameraId id,
            const TangoExternal::TangoImage* buffer,
            const TangoExternal::TangoCameraMetadata* metadata);

        bool HasConfiguration() const;

        GLuint GetARTextureId() const;

        void SetDepthCameraFramerate(
            int framerate,
            TangoExternal::TangoConfig tangoConfig);

        static void OnPointCloudAvailableRouter(
            void* context,
            const TangoExternal::TangoPointCloud* pointCloud);

        static void OnImageAvailableRouter(
            void* context,
            TangoExternal::TangoCameraId id,
            const TangoExternal::TangoImage* image,
            const TangoExternal::TangoCameraMetadata* metadata);

        static void OnServiceConnectedMainThread(Device* self);

        static void OnServiceStopMainThread(Device* self);

    private:

        static RuntimeStatic<Device> s_Instance;

        ARRenderMode m_RenderMode;

        float(*m_PointDataUnity)[4];

        unsigned int m_MaxPointCloudElements;

        Config m_CurrentConfig;

        ARRendering m_ARRendering;

        int m_DepthCameraFramerate;

        bool m_HasConfiguration;

        CoordinateFrame m_BaseFrame;

        bool m_IsConnected;

        MeshReconstruction::ServerManager m_MeshReconstructionServerManager;

        core::string m_AreaDescriptionUUID;

        bool m_SetFramerateToCamerarate;

        float m_HorizontalFOV;
        float m_VerticalFOV;

        static bool s_IsInitialized;

        static bool s_ConnectionRequestedButNotHandled;

        static Mutex s_InitializationMutex;
    };

    Device* GetDevice();
} // namespace Tango
