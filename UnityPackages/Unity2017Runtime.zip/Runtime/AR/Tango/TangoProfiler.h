#pragma once

#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Threads/Thread.h"

#ifdef ON_ENABLE_TANGO_PROFILING
#   undef ON_ENABLE_TANGO_PROFILING
#endif

#if ENABLE_PROFILER
#   define ON_ENABLE_TANGO_PROFILING(x) x
#else
#   define ON_ENABLE_TANGO_PROFILING(x)
#endif

namespace Tango
{
    class Profiler
    {
    public:
        Profiler();
        ~Profiler();

        static void OnProfilerFrameChanged(UInt32 frameIndex, void* context);

        void Update();
        void Initialize(const char* groupname, const char* name);
        void EnsureInitialized(const char* groupname, const char* name);
        void Shutdown();

    private:
        int m_CurrentFrame;
        int m_NextFrame;
        bool m_IsInitialized;
        Thread::ThreadID m_ThreadId;
    };
} // namespace Tango
