#include "UnityPrefix.h"

#if PLATFORM_ANDROID

#include "DVMCalls.h"
#include "TangoBinder.h"
#include "TangoDevice.h"
#include "TangoProfiler.h"
#include "TangoEngineCallbackHandler.h"
#include "TangoImageBufferManager.h"
#include "TangoPointCloudManager.h"
#include "Runtime/Allocator/MemoryMacros.h"
#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/Math/Vector4.h"
#include "Runtime/Threads/Thread.h"
#include "Runtime/Jobs/BackgroundJobQueue.h"

namespace Tango
{
    RuntimeStatic<Device> Device::s_Instance(kMemDefault, RuntimeStatic<Device>::kManual);

    bool Device::s_IsInitialized = false;
    bool Device::s_ConnectionRequestedButNotHandled = false;
    Mutex Device::s_InitializationMutex;

    Device* GetDevice()
    {
        // Caller activity is only non-NULL if the Java layer calls tangoOnCreate().
        // And that only happens when Tango Support is set in the player config.
        if (GetCallerActivity() && Device::IsInitialized())
        {
            return Device::GetInstance();
        }
        else
        {
            return nullptr;
        }
    }

    void Device::OnPointCloudAvailableRouter(void* context, const TangoExternal::TangoPointCloud* pointCloud)
    {
        ON_ENABLE_TANGO_PROFILING(UpdateBinderProfilerForCurrentThread());

        Device::GetInstance()->OnPointCloudAvailable(pointCloud);
    }

    const int kDepthCameraUnset = -1;

    Device::Device()
        : m_RenderMode(kRenderModeStandardBackground)
        , m_PointDataUnity(nullptr)
        , m_MaxPointCloudElements(0)
        , m_DepthCameraFramerate(kDepthCameraUnset)
        , m_HasConfiguration(false)
        , m_AreaDescriptionUUID("")
        , m_SetFramerateToCamerarate(false)
        , m_IsConnected(false)
        , m_HorizontalFOV(0.0f)
        , m_VerticalFOV(0.0f)
        , m_BaseFrame(kTangoCoordinateFrameStartOfService)
    {
        // Set the static pointer to our instance of TangoARRendering so that callbacks can reference them
        ARRendering::s_Instance = &m_ARRendering;
    }

    Device::~Device()
    {
        delete[] m_PointDataUnity;
        s_IsInitialized = false;
    }

    // Allows script users to get the current rendering mode
    ARRenderMode Device::GetRenderMode() const
    {
        return m_RenderMode;
    }

    void Device::SetRenderMode(ARRenderMode value)
    {
        m_RenderMode = value;
    }

    // Returns a pose in Tango coordinates.
    bool Device::GetPoseAtTime(
        double time,
        ScreenOrientation screenOrientation,
        CoordinateFrame base,
        CoordinateFrame target,
        PoseData* outPose) const
    {
        const double poseTime = GetTimeForPose(time);

        TangoExternal::TangoPoseData pose;
        const TangoExternal::TangoErrorType retVal =
            Tango::GetPoseAtTime(poseTime, screenOrientation, base, target, &pose);

        if (retVal != TangoExternal::TANGO_SUCCESS)
            return false;

        outPose->translation_x = pose.translation[0];
        outPose->translation_y = pose.translation[1];
        outPose->translation_z = pose.translation[2];

        outPose->orientation_x = pose.orientation[0];
        outPose->orientation_y = pose.orientation[1];
        outPose->orientation_z = pose.orientation[2];
        outPose->orientation_w = pose.orientation[3];

        outPose->version = pose.version;
        outPose->timestamp = pose.timestamp;
        outPose->status_code = TangoToUnity(pose.status_code);
        outPose->frame = {TangoToUnity(pose.frame.base), TangoToUnity(pose.frame.target)};
        outPose->confidence = pose.confidence;
        outPose->accuracy = pose.accuracy;

        return true;
    }

    bool Device::SetBaseCoordinateFrame(CoordinateFrame baseFrame)
    {
#if PLATFORM_ANDROID
        if (IsFixedTangoCoordinateFrame(baseFrame))
        {
            m_BaseFrame = baseFrame;
            return true;
        }
        else
#endif
        {
            return false;
        }
    }

    Tango::CoordinateFrame Device::GetBaseCoordinateFrame() const
    {
        return m_BaseFrame;
    }

    static float CalculateVerticalFOVScale(const TangoExternal::TangoCameraIntrinsics &cameraIntrinsics)
    {
        float retVal = 1.0f;

        const int screenMaxDim = std::max<int>(GetScreenManager().GetWidth(), GetScreenManager().GetHeight());
        const int screenMinDim = std::min<int>(GetScreenManager().GetWidth(), GetScreenManager().GetHeight());

        if (((float)screenMinDim / (float)screenMaxDim) != ((float)cameraIntrinsics.height / (float)cameraIntrinsics.width))
        {
            retVal = (float)cameraIntrinsics.width / (float)screenMaxDim;
        }

        return retVal;
    }

    static float CalculateHorizontalFOVScale(const TangoExternal::TangoCameraIntrinsics &cameraIntrinsics)
    {
        float retVal = 1.0f;

        const int screenMaxDim = std::max<int>(GetScreenManager().GetWidth(), GetScreenManager().GetHeight());
        const int screenMinDim = std::min<int>(GetScreenManager().GetWidth(), GetScreenManager().GetHeight());

        if (((float)screenMinDim / (float)screenMaxDim) != ((float)cameraIntrinsics.height / (float)cameraIntrinsics.width))
        {
            retVal = (float)cameraIntrinsics.height / (float)screenMinDim;
        }

        return retVal;
    }

    bool Device::GetHorizontalFov(float* fovOut)
    {
        if (m_HorizontalFOV > 0.0f)
        {
            *fovOut = m_HorizontalFOV;
            return true;
        }

        TangoClientPlugin& clientPlugin = GetTangoClientPlugin();
        TangoExternal::TangoCameraIntrinsics cameraIntrinsics;

        if (clientPlugin.GetCameraIntrinsics(TangoExternal::TANGO_CAMERA_COLOR, &cameraIntrinsics) != TangoExternal::TANGO_SUCCESS)
            return false;

        m_HorizontalFOV = *fovOut = Rad2Deg(2.f * atan((float)cameraIntrinsics.width * CalculateHorizontalFOVScale(cameraIntrinsics) * 0.5f / (float)cameraIntrinsics.fx));

        return true;
    }

    bool Device::GetVerticalFov(float* fovOut)
    {
        if (m_VerticalFOV > 0.0f)
        {
            *fovOut = m_VerticalFOV;
            return true;
        }

        TangoClientPlugin& clientPlugin = GetTangoClientPlugin();

        TangoExternal::TangoCameraIntrinsics cameraIntrinsics;

        if (clientPlugin.GetCameraIntrinsics(TangoExternal::TANGO_CAMERA_COLOR, &cameraIntrinsics) != TangoExternal::TANGO_SUCCESS)
            return false;

        m_VerticalFOV = *fovOut = Rad2Deg(2.f * atan((float)cameraIntrinsics.height * CalculateVerticalFOVScale(cameraIntrinsics) * 0.5f / (float)cameraIntrinsics.fy));

        return true;
    }

    void Device::OnPointCloudAvailable(const TangoExternal::TangoPointCloud* pointCloud)
    {
        UpdatePointCloud(pointCloud);

        m_MeshReconstructionServerManager.OnPointCloudAvailable(pointCloud);
    }

    void Device::OnColorImageAvailable(
        TangoExternal::TangoCameraId id,
        const TangoExternal::TangoImage* buffer,
        const TangoExternal::TangoCameraMetadata* metadata)
    {
        UpdateImageBuffer(buffer, metadata);
        m_MeshReconstructionServerManager.OnImageAvailable(id);
    }

    void Device::OnImageAvailableRouter(
        void* context,
        TangoExternal::TangoCameraId id,
        const TangoExternal::TangoImage* image,
        const TangoExternal::TangoCameraMetadata* metadata)
    {
        ON_ENABLE_TANGO_PROFILING(UpdateBinderProfilerForCurrentThread());

        if (id == TangoExternal::TANGO_CAMERA_COLOR)
        {
            Device* self = static_cast<Device*>(context);
            self->OnColorImageAvailable(id, image, metadata);
        }
    }

    const Config& Device::GetConfiguration()
    {
        return m_CurrentConfig;
    }

    MeshReconstruction::Server* Device::CreateMeshReconstructionServer(
        ScriptingObjectPtr self,
        const MeshReconstruction::Config& config,
        MeshReconstruction::CreationStatus* statusOut)
    {
        bool colorCameraEnabled = false;
        m_CurrentConfig.TryGetConfigValue("config_enable_color_camera", colorCameraEnabled);

#if UNITY_DEVELOPER_BUILD
        if (config.generateColor && !colorCameraEnabled)
            WarningString("Tango Mesh Reconstruction Server asked to generate color information but color camera not enabled.");
#endif

        return m_MeshReconstructionServerManager.CreateServer(self, config, statusOut);
    }

    void Device::DestroyMeshReconstructionServer(MeshReconstruction::Server* server)
    {
        m_MeshReconstructionServerManager.DestroyServer(server);
    }

    void Device::DestroyThreadedMeshReconstructionServer(MeshReconstruction::Server* server)
    {
        m_MeshReconstructionServerManager.DestroyThreadedServer(server);
    }

    void Device::OnServiceConnectedMainThread(Device* self)
    {
        ASSERT_RUNNING_ON_MAIN_THREAD;

        if (self->HasConfiguration())
        {
            const Config& config = self->GetConfiguration();
            if (!self->Connect(config))
                ErrorString("Failed to set Tango configuration.");
        }
    }

    void Device::OnServiceStopMainThread(Device* self)
    {
        ASSERT_RUNNING_ON_MAIN_THREAD;

        self->m_IsConnected = false;
        EngineCallbackHandler::GetInstance()->UnregisterUpdateLoop();
    }

    void Device::Initialize()
    {
        ASSERT_RUNNING_ON_MAIN_THREAD;

        Mutex::AutoLock lock(s_InitializationMutex);

        s_Instance.EnsureInitialized();
        s_IsInitialized = true;

        // It's possible we've already had a request to connect
        // before the device could be initialized.
        if (s_ConnectionRequestedButNotHandled)
        {
            GetInstance()->OnServiceConnectedMainThread(GetInstance());
            s_ConnectionRequestedButNotHandled = false;
        }
    }

    void Device::SignalConnectionRequestedThreaded()
    {
        Mutex::AutoLock lock(s_InitializationMutex);

        // If we're already initialized, then we can go ahead
        // and schedule the connection on the main thread.
        // Otherwise, we have to remember that a connection
        // request was made and handle it in ::Initialize.

        if (IsInitialized())
        {
            GetBackgroundJobQueue().ScheduleMainThreadJob(
                &OnServiceConnectedMainThread,
                GetInstance());
        }
        else
        {
            s_ConnectionRequestedButNotHandled = true;
        }
    }

    void Device::SignalDisconnectRequestedThreaded()
    {
        Mutex::AutoLock lock(s_InitializationMutex);

        // If we're initialized, then schedule disconnect
        // on the main thread. Otherwise, we aren't connected.

        if (IsInitialized())
        {
            GetBackgroundJobQueue().ScheduleMainThreadJob(
                &OnServiceStopMainThread,
                GetInstance());
        }
    }

    bool Device::HasConfiguration() const
    {
        return m_HasConfiguration;
    }

    static void SetBoolValuesInTangoConfig(const dynamic_array<core::string> &keys, const dynamic_array<bool> &values, TangoExternal::TangoConfig &tangoConfig)
    {
        TangoClientPlugin &tangoClientPlugin = GetTangoClientPlugin();

        for (int i = 0; i < keys.size(); i++)
            tangoClientPlugin.SetTangoConfigField_Bool(tangoConfig, keys[i].c_str(), values[i]);
    }

    static void SetIntValuesInTangoConfig(const dynamic_array<core::string> &keys, const dynamic_array<int> &values, TangoExternal::TangoConfig &tangoConfig)
    {
        TangoClientPlugin &tangoClientPlugin = GetTangoClientPlugin();

        for (int i = 0; i < keys.size(); i++)
            tangoClientPlugin.SetTangoConfigField_Int32(tangoConfig, keys[i].c_str(), values[i]);
    }

    static void SetLongValuesInTangoConfig(const dynamic_array<core::string> &keys, const dynamic_array<SInt64> &values, TangoExternal::TangoConfig &tangoConfig)
    {
        TangoClientPlugin &tangoClientPlugin = GetTangoClientPlugin();

        for (int i = 0; i < keys.size(); i++)
            tangoClientPlugin.SetTangoConfigField_Int64(tangoConfig, keys[i].c_str(), values[i]);
    }

    static void SetDoubleValuesInTangoConfig(const dynamic_array<core::string> &keys, const dynamic_array<double> &values, TangoExternal::TangoConfig &tangoConfig)
    {
        TangoClientPlugin &tangoClientPlugin = GetTangoClientPlugin();

        for (int i = 0; i < keys.size(); i++)
            tangoClientPlugin.SetTangoConfigField_Double(tangoConfig, keys[i].c_str(), values[i]);
    }

    static void SetStringValuesInTangoConfig(const dynamic_array<core::string> &keys, const dynamic_array<core::string> &values, TangoExternal::TangoConfig &tangoConfig)
    {
        TangoClientPlugin &tangoClientPlugin = GetTangoClientPlugin();

        for (int i = 0; i < keys.size(); i++)
            tangoClientPlugin.SetTangoConfigField_String(tangoConfig, keys[i].c_str(), values[i].c_str());
    }

    static bool CheckRequiredPermissions(const Config &config)
    {
        bool colorCameraGranted = false;
        bool depthCameraGranted = false;
        bool cloudAreaDescriptionGranted = false;

        config.TryGetConfigValue("config_enable_color_camera", colorCameraGranted);
        config.TryGetConfigValue("config_enable_depth", depthCameraGranted);

        if ((colorCameraGranted || depthCameraGranted) && !DVM::CheckPermission("android.permission.CAMERA"))
        {
            ErrorString("Tango::Device::Connect - Could not connect to Tango (no Camera permission granted).");
            return false;
        }

        config.TryGetConfigValue("config_enable_color_camera", colorCameraGranted);

        if (cloudAreaDescriptionGranted && !DVM::CheckPermission("android.permission.ACCESS_FINE_LOCATION"))
        {
            ErrorString("Tango::Device::Connect - Could not connect to Tango (no Fine Location permission granted).");
            return false;
        }

        return true;
    }

    bool Device::Connect(const Config &config)
    {
        ASSERT_RUNNING_ON_MAIN_THREAD;

        TangoClientPlugin &tangoClientPlugin = GetTangoClientPlugin();
        TangoExternal::TangoConfig tangoConfig = tangoClientPlugin.GetConfig(TangoExternal::TANGO_CONFIG_DEFAULT);

        // Get the Tango config
        if (tangoConfig == nullptr)
            return false;
        if (!CheckRequiredPermissions(config))
            return false;

        // Set the key/value pairs into the Tango config
        SetBoolValuesInTangoConfig(config.boolKeysVec, config.boolValuesVec, tangoConfig);
        SetIntValuesInTangoConfig(config.intKeysVec, config.intValuesVec, tangoConfig);
        SetLongValuesInTangoConfig(config.longKeysVec, config.longValuesVec, tangoConfig);
        SetDoubleValuesInTangoConfig(config.doubleKeysVec, config.doubleValuesVec, tangoConfig);
        SetStringValuesInTangoConfig(config.stringKeysVec, config.stringValuesVec, tangoConfig);

        // Store the current configuration
        m_CurrentConfig = config;
        m_HasConfiguration = true;

        bool depthEnabled = false;
        config.TryGetConfigValue("config_enable_depth", depthEnabled);

        if (depthEnabled)
        {
            tangoClientPlugin.SetCallback_OnPointCloudAvailable(OnPointCloudAvailableRouter);

            int32_t maxPointCloudElements;
            TangoExternal::TangoErrorType retVal = tangoClientPlugin.GetTangoConfigField_Int32(tangoConfig, "max_point_cloud_elements", &maxPointCloudElements);

            if (retVal == TangoExternal::TANGO_SUCCESS)
            {
                // Allocate/reallocate the buffer that stores point data in Unity coordinates
                if (m_MaxPointCloudElements != maxPointCloudElements)
                {
                    delete[] m_PointDataUnity;
                    m_PointDataUnity = new float[maxPointCloudElements][4];
                }

                m_MaxPointCloudElements = maxPointCloudElements;

                if (!CreatePointCloudManager(m_MaxPointCloudElements))
                {
#if UNITY_DEVELOPER_BUILD
                    ErrorString("Could not instantiate point cloud manager. Point clouds will not be available.");
#endif
                }
            }
            else
            {
                FreePointCloudManager();
            }
        }
        else
        {
            FreePointCloudManager();
        }

        bool colorCameraEnabled = false;
        m_CurrentConfig.TryGetConfigValue("config_enable_color_camera", colorCameraEnabled);

        if (colorCameraEnabled)
        {
            m_ARRendering.Initialize();

            CreateImageBufferManager();

            const TangoExternal::TangoErrorType onImageAvailableRegistrationStatus =
                GetTangoClientPlugin().SetCallback_OnImageAvailable(
                    TangoExternal::TANGO_CAMERA_COLOR,
                    this,
                    OnImageAvailableRouter);

            m_MeshReconstructionServerManager.SetColorCameraEnabled(
                onImageAvailableRegistrationStatus == TangoExternal::TANGO_SUCCESS);

            if (onImageAvailableRegistrationStatus != TangoExternal::TANGO_SUCCESS)
            {
#if UNITY_DEVELOPER_BUILD
                ErrorStringMsg("Could not register OnImageAvailable callback. Error code %d",
                    (int)onImageAvailableRegistrationStatus);
#endif
            }
        }
        else
        {
            m_ARRendering.Shutdown();
        }

        // Connect to the Tango Service, the service will start running:

        const TangoExternal::TangoErrorType err = tangoClientPlugin.Connect(GetCallerActivity(), tangoConfig);
        m_IsConnected = (err == TangoExternal::TANGO_SUCCESS);

        if (err == TangoExternal::TANGO_SUCCESS)
        {
            // Now that we are connected try to set the depth camera rate
            if (depthEnabled && (GetDepthCameraFramerate() != kDepthCameraUnset))
            {
                SetDepthCameraFramerate(GetDepthCameraFramerate());
            }

            EngineCallbackHandler::GetInstance()->RegisterUpdateLoop();
        }
        else
        {
            EngineCallbackHandler::GetInstance()->UnregisterUpdateLoop();
            ErrorStringMsg("Failed to connect to the Tango service with error code: %d", err);
        }

        ComputeDeviceToCameraPoses();

        tangoClientPlugin.FreeConfig(tangoConfig);

        return true;
    }

    void Device::Disconnect()
    {
        TangoClientPlugin &tangoClientPlugin = GetTangoClientPlugin();
        tangoClientPlugin.Disconnect();
    }

    GLuint Device::GetARTextureId() const
    {
        return m_ARRendering.GetARTextureId();
    }

    int Device::GetDepthCameraFramerate() const
    {
        return m_DepthCameraFramerate;
    }

    void Device::SetDepthCameraFramerate(int framerate)
    {
        TangoClientPlugin &tangoClientPlugin = GetTangoClientPlugin();
        TangoExternal::TangoConfig tangoConfig = tangoClientPlugin.GetConfig(TangoExternal::TANGO_CONFIG_RUNTIME);

        SetDepthCameraFramerate(framerate, tangoConfig);
    }

    void Device::SetBackgroundMaterial(Material* backgroundMaterial)
    {
        m_ARRendering.SetBackgroundMaterial(backgroundMaterial);
    }

    double Device::GetTimeForPose(double time) const
    {
        if ((time == 0.0f) &&
            (GetRenderMode() == kRenderModeMaterialAsBackground) &&
            (m_ARRendering.IsLastCameraImageTimestampValid()))
        {
            return m_ARRendering.GetLastCameraImageTimestamp();
        }
        else
        {
            return time;
        }
    }

    void Device::SetDepthCameraFramerate(int framerate, TangoExternal::TangoConfig tangoConfig)
    {
        TangoClientPlugin &tangoClientPlugin = GetTangoClientPlugin();

        // Get the Tango config
        if (tangoConfig == nullptr)
            return;

        // Now that we are connected try to set the depth camera rate
        if (TangoExternal::TANGO_SUCCESS == tangoClientPlugin.SetTangoConfigField_Int32(tangoConfig, "config_runtime_depth_framerate", framerate))
        {
            const TangoExternal::TangoErrorType errorCode = tangoClientPlugin.SetRuntimeConfig(tangoConfig);
            if (TangoExternal::TANGO_SUCCESS == errorCode)
            {
                m_DepthCameraFramerate = framerate;
#if UNITY_DEVELOPER_BUILD
                LogStringMsg("Depth framerate set to : %i.", framerate);
#endif
            }
            else
            {
#if UNITY_DEVELOPER_BUILD
                ErrorStringMsg("SetRuntimeConfig returned error %d.", (int)errorCode);
#endif
            }
        }

        // Retrieve the depth camera rate since it isn't necessarily the value that is set
        if (TangoExternal::TANGO_SUCCESS != tangoClientPlugin.GetTangoConfigField_Int32(tangoConfig, "config_runtime_depth_framerate", (int*)&m_DepthCameraFramerate))
        {
            m_DepthCameraFramerate = 0;
#if UNITY_DEVELOPER_BUILD
            ErrorString("Depth framerate could not be read.");
#endif
        }
        else
        {
#if UNITY_DEVELOPER_BUILD
            LogStringMsg("Depth framerate read as : %i.", m_DepthCameraFramerate);
#endif
        }
    }

    bool Device::GetSynchronizeFramerateWithColorCamera() const
    {
        return m_SetFramerateToCamerarate;
    }

    void Device::SetSynchronizeFramerateWithColorCamera(bool synchronize)
    {
        m_SetFramerateToCamerarate = synchronize;
    }
} // namespace Tango

#endif
