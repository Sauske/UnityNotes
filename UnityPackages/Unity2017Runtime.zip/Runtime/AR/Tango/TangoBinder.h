#pragma once

#include <jni.h>
#include "TangoProfiler.h"

namespace Tango
{
    void UpdateBinderProfilerForCurrentThread();
} // namespace Tango

void tangoOnCreate(JNIEnv* env, jobject thiz, jobject caller_activity, jobject callback);
void tangoCacheTangoObject(JNIEnv* env, jobject thiz, jobject tango);
void tangoOnPause(JNIEnv* env, jobject thiz);

void tangoOnImageAvailable(JNIEnv* env, jobject thiz, jobject image, jobject metadata, jint camera_id);
void tangoOnPointCloudAvailable(JNIEnv* env, jobject thiz, jobject point_cloud);
void tangoOnPoseAvailable(JNIEnv* env, jobject thiz, jobject pose);
void tangoOnTangoEvent(JNIEnv* env, jobject thiz, jobject event);
void tangoOnTextureAvailable(JNIEnv* env, jobject thiz, jint camera_id);
