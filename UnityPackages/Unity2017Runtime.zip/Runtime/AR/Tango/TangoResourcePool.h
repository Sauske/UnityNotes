#pragma once

#include "Runtime/Utilities/ConcurrentFreeList.h"
#include "Runtime/Utilities/RuntimeStatic.h"

namespace Tango
{
    template<typename T>
    class ResourcePool : NonCopyable
    {
        template<typename V>
        struct Node : ConcurrentNode
        {
            V item;
        };

        // "s_Instance" is already a global scope variable
        static RuntimeStatic<ResourcePool<T>, true> s_TangoResourcePoolInstance;

        constexpr static UInt32 kItemOffset = offsetof(Node<T>, item);

    public:

        static inline ResourcePool<T>& GetInstance();

        ResourcePool(MemLabelId memoryLabel);

        // Retrieve a default-constructed T
        inline T* Allocate();

        // Returns T to the pool (no dtor called)
        inline void Free(T* ptr);

    private:

        ConcurrentFreeList<Node<T> > m_Pool;
    };

    template<typename T>
    inline ResourcePool<T>& ResourcePool<T>::GetInstance()
    {
        return *s_TangoResourcePoolInstance;
    }

    template<typename T>
    inline ResourcePool<T>::ResourcePool(MemLabelId memoryLabel)
        : m_Pool(2, memoryLabel)
    {}

    template<typename T>
    inline T* ResourcePool<T>::Allocate()
    {
        Node<T>* node = m_Pool.Allocate();
        T* item = &(node->item);
        return item;
    }

    template<typename T>
    inline void ResourcePool<T>::Free(T* ptr)
    {
        Node<T>* node = reinterpret_cast<Node<T>*>((char*)ptr - kItemOffset);
        m_Pool.Free(node);
    }
} // namespace Tango
