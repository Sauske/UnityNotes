#pragma  once

#if PLATFORM_ANDROID

#include "TangoMeshGenerationResult.h"
#include "TangoMeshGenerationQuery.h"
#include "TangoGridIndexHasher.h"
#include "TangoTypes.h"

#endif
