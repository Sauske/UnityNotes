#pragma once

#if PLATFORM_ANDROID

#include "TangoSupport.h"
#include "TangoGridIndexHasher.h"

#include "Runtime/Core/Containers/hash_map.h"
#include "Runtime/EventQueue/GlobalEventQueue.h"
#include "Runtime/PluginInterface/Headers/IUnityEventQueue.h"
#include "Runtime/Threads/Mutex.h"

namespace Tango
{
namespace MeshReconstruction
{
    struct GenerationQuery;
    struct GenerationResult;

    class Server
    {
    public:

        struct EventBase
        {
            const Server* context;
            int subscriberId;
        };

        struct GridIndicesChangedEvent : EventBase
        {
            void Destroy();

            TangoExternal::TangoUnity3DR_GridIndexArray updatedGridIndexArray;
            double timestamp;
        };

        struct DestroyThreadedEvent : EventBase
        {
            void Destroy() { ScriptingGCHandle::FromScriptingBackendNativeGCHandle(gcHandle).ReleaseAndClear(); }

            ScriptingBackendNativeGCHandle gcHandle;
        };

        struct SegmentProcessedEvent : EventBase
        {
            void Destroy();

            GenerationResult* result;
            GenerationQuery* query;
            bool wasConsumed = false;
        };

        void HandleEvent(const GridIndicesChangedEvent& event);
        void HandleEvent(const DestroyThreadedEvent& event);
        void HandleEvent(SegmentProcessedEvent& event);

        Server(
            ScriptingObjectPtr self,
            const Config& config,
            TangoExternal::Tango3DR_ReconstructionContext context);

        ~Server();

    public:

        GenerationResult* ExtractPreallocatedMeshSegment(const GenerationQuery& query);

        void Update(
            const TangoExternal::TangoPointCloud& pointCloud,
            const TangoExternal::TangoPoseData& pointCloudPose,
            const TangoExternal::TangoImage* image,
            const TangoExternal::TangoPoseData* imagePose) const;

        int GetId() { return m_EventSubscriberId; }
        template<typename T> inline T CreateEvent() const;

        // Public C# Script API
        static Server* Create(ScriptingObjectPtr self, const Config& config, CreationStatus* statusOut);
        void Destroy();
        void DestroyThreaded();
        void GenerateSegmentAsync(
            const MeshReconstruction::GridIndex& gridIndex,
            MeshFilter* destinationMeshFilter,
            MeshCollider* destinationMeshCollider,
            ScriptingObjectPtr onSegmentReady,
            bool provideNormals,
            bool provideColors,
            bool providePhysics);
        void GetChangedSegments(ScriptingObjectPtr scriptCallback);
        TangoExternal::Tango3DR_ReconstructionContext GetNativeReconstructionContext() const { return m_Context; }
        int GetNumGenerationRequests() const;
        bool GetEnabled() const { return m_Enabled; }
        void SetEnabled(bool enabled) { m_Enabled = enabled; }
        void ClearReconstructedMeshes();
        const Config& GetConfig() const { return m_Config; }

    private:

        struct SegmentInfo
        {
            GridIndex gridIndex;
            double lastUpdateTime = -1;
            double lastNotifyTime = -1;
        };

        static void ProcessExtractionJob(GenerationQuery* generationQuery);

        void Shutdown();

        // Event handling
        bool IsEventTargetSelf(const EventBase& event) const;

        void InvokeOnSegmentChanged(
            ScriptingObjectPtr onSegmentChanged,
            const GridIndex& gridIndex,
            SegmentChange changeType,
            double updateTime);

        void InvokeOnSegmentReady(const SegmentProcessedEvent& event);

        int m_NumSegmentsInFlight = 0;

        ScriptingGCHandle m_ManagedHandle;

        // the memory allocation system can give us a recycled memory addresses for objects of same types,
        // so we need an identifier other than pointer for verifying message targets.
        int m_EventSubscriberId;
        static int s_LastEventSubscriberId;

        UnityEventQueue::ClassBasedEventHandler<Server::GridIndicesChangedEvent, Server> m_GridIndicesChangedDelegate;
        UnityEventQueue::ClassBasedEventHandler<Server::SegmentProcessedEvent, Server> m_MeshSegmentProcessedDelegate;
        UnityEventQueue::ClassBasedEventHandler<Server::DestroyThreadedEvent, Server> m_DestroyThreadedDelegate;

        typedef core::hash_map<GridIndex, SegmentInfo, GridIndexHasher> SegmentInfoMap;
        SegmentInfoMap m_MeshSegmentInfos;

        TangoExternal::Tango3DR_ReconstructionContext m_Context = nullptr;
        Config m_Config;
        bool m_Enabled = true;
    };

    template<typename T>
    inline T Server::CreateEvent() const
    {
        T event;
        event.context = this;
        event.subscriberId = m_EventSubscriberId;

        return event;
    }
} // namespace MeshReconstruction
} // namespace Tango

REGISTER_EVENT_ID_WITH_CLEANUP(0x096958E43D694001ULL, 0x9D23DA01B65064F0ULL, Tango::MeshReconstruction::Server::GridIndicesChangedEvent);
REGISTER_EVENT_ID_WITH_CLEANUP(0xEBC6189E2BCC424FULL, 0x9C24A0D6C71A397EULL, Tango::MeshReconstruction::Server::DestroyThreadedEvent);
REGISTER_EVENT_ID_WITH_CLEANUP(0xAA86246F344E4EA2ULL, 0x9EB5A9119FD36346ULL, Tango::MeshReconstruction::Server::SegmentProcessedEvent);

#endif
