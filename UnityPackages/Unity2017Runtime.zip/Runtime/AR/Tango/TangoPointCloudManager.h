#pragma once

#include "External/Tango/builds/gen/ApiFuncTangoClient.h"
#include "TangoBufferManager.h"

namespace Tango
{
    class PointCloudManager : public BufferManager<TangoExternal::TangoPointCloud>
    {
    public:

        PointCloudManager(int maxPointCloudElements, UInt32 numConsumers, MemLabelId memoryLabel);

    private:

        void CopyBuffer(
            TangoExternal::TangoPointCloud* destinationBuffer,
            const TangoExternal::TangoPointCloud* sourceBuffer) override;

        UInt32 m_MaxPointCloudElements;
    };
} // namespace Tango
