#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS && PLATFORM_ANDROID
#include "Runtime/Testing/Testing.h"
#include "Runtime/Threads/Thread.h"
#include "Runtime/Threads/ExtendedAtomicOps.h"
#include "Runtime/Threads/Semaphore.h"
#include "Runtime/Math/Random/Random.h"
#include "Runtime/Input/TimeManager.h"
#include "Runtime/Utilities/RuntimeStatic.h"
#include "TangoResourcePool.h"

INTEGRATION_TEST_SUITE(TangoResourcePool)
{
    using namespace Tango;

    struct Fixture
    {
        void OnResourceCreated()
        {
            atomic_retain(&m_Count);
        }

        void OnResourceDestroyed()
        {
            atomic_release(&m_Count);
        }

        struct MyResource
        {
            void SetFixture(Fixture* fixture)
            {
                m_Fixture = fixture;
                m_Fixture->OnResourceCreated();
            }

            ~MyResource()
            {
                m_Fixture->OnResourceDestroyed();
            }

            Fixture* m_Fixture;
        };

        void AllocateResources(ResourcePool<MyResource>& resourcePool, int count)
        {
            for (int i = 0; i < count; ++i)
            {
                MyResource* resource = resourcePool.Allocate();
                resource->SetFixture(this);
                m_Resources.push_back(resource);
            }
        }

        void FreeResources(ResourcePool<MyResource>& resourcePool)
        {
            for (int i = 0; i < m_Resources.size(); ++i)
            {
                resourcePool.Free(m_Resources[i]);
            }
            m_Resources.clear();
        }

        struct ThreadData
        {
            ResourcePool<MyResource>* pool;
            Fixture* fixture;
            Thread* thread;
            Semaphore* quitSignal;
            volatile int acquired;
        };

        static void* ThreadEntry(void* data)
        {
            ThreadData* threadData = static_cast<ThreadData*>(data);

            atomic_pause();

            MyResource* resource = threadData->pool->Allocate();
            resource->SetFixture(threadData->fixture);
            atomic_retain(&threadData->acquired);

            threadData->quitSignal->WaitForSignal();

            threadData->pool->Free(resource);

            return nullptr;
        }

        dynamic_array<MyResource*> m_Resources;

        volatile int m_Count = 0;
    };

    TEST_FIXTURE(Fixture, CanCreateResourcesAndDestroyThem)
    {
        {
            ResourcePool<MyResource> resourcePool(kMemDefault);
            AllocateResources(resourcePool, 10);
            CHECK_EQUAL(10, m_Count);

            FreeResources(resourcePool);
            // Freeing a resource doesn't call its destructor,
            // so we should still get 10
            CHECK_EQUAL(10, m_Count);
        }

        // Now they should be gone
        CHECK_EQUAL(0, m_Count);
    }

    TEST_FIXTURE(Fixture, CanCreateResourcesAndDestroyThemMultithreaded)
    {
        {
            ResourcePool<MyResource> resourcePool(kMemDefault);
            const int numThreads = 10;
            Thread threads[numThreads];
            dynamic_array<ThreadData> threadDatas(numThreads, kMemDefault);

            for (int i = 0; i < numThreads; ++i)
            {
                ThreadData* threadData = &threadDatas[i];
                threadData->pool = &resourcePool;
                threadData->fixture = this;
                threadData->thread = &threads[i];
                threadData->acquired = 0;
                threadData->quitSignal = UNITY_NEW(Semaphore, kMemDefault);

                threads[i].Run(&ThreadEntry, threadData);
            }

            // Wait for all resources to be acquired
            int acquisitionCount = 0;
            while (acquisitionCount < numThreads)
            {
                atomic_pause();
                acquisitionCount = 0;
                for (int i = 0; i < numThreads; ++i)
                {
                    acquisitionCount += threadDatas[i].acquired;
                }
            }

            CHECK_EQUAL(numThreads, m_Count);

            for (int i = 0; i < numThreads; ++i)
            {
                threadDatas[i].quitSignal->Signal();
                threads[i].WaitForExit(true);
                UNITY_DELETE(threadDatas[i].quitSignal, kMemDefault);
            }
        }

        CHECK_EQUAL(0, m_Count);
    }
}

#endif
