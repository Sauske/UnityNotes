#pragma once

#include "Runtime/PluginInterface/Headers/IUnityInterface.h"
#include "Runtime/Scripting/BindingsDefs.h"
#include "Runtime/Scripting/ScriptingTypes.h"
#include "Runtime/Math/Quaternion.h"
#include "Runtime/Math/Vector3.h"

class MeshFilter;
class MeshCollider;

namespace Tango
{
    // This must correspond to the ReferenceFrame enum in Tango.bindings
    typedef enum CoordinateFrame
    {
        kTangoCoordinateFrameGlobalWGS84 = 0,
        kTangoCoordinateFrameAreaDescription,
        kTangoCoordinateFrameStartOfService,
        kTangoCoordinateFramePreviousDevicePose,
        kTangoCoordinateFrameDevice,
        kTangoCoordinateFrameIMU,
        kTangoCoordinateFrameDisplay,
        kTangoCoordinateFrameCameraColor,
        kTangoCoordinateFrameCameraDepth,
        kTangoCoordinateFrameCameraFisheye,
        kTangoCoordinateFrameUUID,
        kTangoCoordinateFrameInvalid,
        kTangoCoordinateFrameMaxCoordinateFrameType
    } CoordinateFrame;

    typedef enum PoseStatus
    {
        kTangoPoseInitializing = 0,
        kTangoPoseValid,
        kTangoPoseInvalid,
        kTangoPoseUnknown
    } PoseStatus;

    typedef struct CoordinateFramePair
    {
        CoordinateFrame baseFrame;
        CoordinateFrame targetFrame;
    } CoordinateFramePair;

    // This must correspond to TangoPoseData in Tango.bindings
    typedef struct PoseData
    {
        uint32_t version;
        double timestamp;
        double orientation_x;
        double orientation_y;
        double orientation_z;
        double orientation_w;
        double translation_x;
        double translation_y;
        double translation_z;
        PoseStatus status_code;
        CoordinateFramePair frame;
        uint32_t confidence;
        float accuracy;
    } PoseData;

    // This must correspond to ImageData.CameraMetadata in Tango.bindings
    typedef struct CameraMetadata
    {
        uint64_t timestamp_ns;
        uint64_t frame_number;
        uint64_t exposure_duration_ns;
        uint32_t sensitivity_iso;
        float lens_aperture;
        uint32_t color_correction_mode;
        float color_correction_gains[4];
        float color_correction_transform[9];
        float sensor_neutral_color_point[3];
    } CameraMetadata;

    typedef struct Config
    {
        dynamic_array<core::string> boolKeysVec;
        dynamic_array<bool> boolValuesVec;

        dynamic_array<core::string> intKeysVec;
        dynamic_array<int> intValuesVec;

        dynamic_array<core::string> longKeysVec;
        dynamic_array<SInt64> longValuesVec;

        dynamic_array<core::string> doubleKeysVec;
        dynamic_array<double> doubleValuesVec;

        dynamic_array<core::string> stringKeysVec;
        dynamic_array<core::string> stringValuesVec;

        bool TryGetConfigValue(const char* key, bool &value) const
        {
            bool found = false;

            for (int i = 0; i < boolKeysVec.size(); i++)
            {
                if (boolKeysVec[i].compare(key) == 0)
                {
                    value = boolValuesVec[i];
                    found = true;
                    break;
                }
            }

            return found;
        }
    } Config;

    // Must match enum in Runtime/AR/Tango/ScriptBindings/TangoInputTracking.cs
    typedef enum TrackingStateEventType
    {
        kTrackingAcquired = 0,
        kTrackingLost
    } TrackingStateEventType;

namespace MeshReconstruction
{
    class Server;

    // This must match MeshReconstructionServer.Status in TangoMeshReconstructionServer.cs
    typedef enum CreationStatus
    {
        kCreationStatusUnsupportedPlatform = 0,
        kCreationStatusOk = 1,
        kCreationStatusMissingLib = 2,
        kCreationStatusNullContext = 3,
        kCreationStatusFailedToSetDepthCalibration = 4
    } CreationStatus;

    // This must correspond to UpdateMethod in TangoMeshReconstructionServer.cs
    typedef enum UpdateMethod
    {
        kUpdateMethodTraversal = 0,
        kUpdateMethodProjective
    } UpdateMethod;

    // This must correspond to MeshReconstructionConfig in TangoMeshReconstructionServer
    typedef struct Config
    {
        double resolution;
        double minDepth;
        double maxDepth;
        int minNumVertices;
        bool useParallelIntegration;
        bool generateColor;
        bool useSpaceClearing;
        UpdateMethod updateMethod;
    } Config;

    typedef union GridIndex
    {
        int indices[3];

        struct
        {
            int i;
            int j;
            int k;
        };
    } GridIndex;

    // This must match the SegmentChange enum in TangoMeshReconstructionServer.cs
    typedef enum SegmentChange
    {
        kSegmentChangeAdded = 0,
        kSegmentChangeUpdated = 1
    } SegmentChange;
} // namespace MeshReconstruction
} // namespace Tango

BIND_MANAGED_TYPE_NAME(Tango::CoordinateFrame, UnityEngine_XR_Tango_CoordinateFrame);
BIND_MANAGED_TYPE_NAME(Tango::PoseStatus, UnityEngine_XR_Tango_PoseStatus);
BIND_MANAGED_TYPE_NAME(Tango::CoordinateFramePair, UnityEngine_XR_Tango_CoordinateFramePair);
BIND_MANAGED_TYPE_NAME(Tango::CameraMetadata, UnityEngine_XR_Tango_ImageData_CameraMetadata);
BIND_MANAGED_TYPE_NAME(Tango::PoseData, UnityEngine_XR_Tango_PoseData);
BIND_MANAGED_TYPE_NAME(Tango::Config, UnityEngine_XR_Tango_TangoConfig);
BIND_MANAGED_TYPE_NAME(Tango::TrackingStateEventType, UnityEngine_XR_Tango_TangoInputTracking_TrackingStateEventType);
BIND_MANAGED_TYPE_NAME(Tango::MeshReconstruction::UpdateMethod, UnityEngine_XR_Tango_UpdateMethod);
BIND_MANAGED_TYPE_NAME(Tango::MeshReconstruction::SegmentChange, UnityEngine_XR_Tango_SegmentChange);
BIND_MANAGED_TYPE_NAME(Tango::MeshReconstruction::Config, UnityEngine_XR_Tango_MeshReconstructionConfig);
BIND_MANAGED_TYPE_NAME(Tango::MeshReconstruction::GridIndex, UnityEngine_XR_Tango_GridIndex);
BIND_MANAGED_TYPE_NAME(Tango::MeshReconstruction::CreationStatus, UnityEngine_XR_Tango_MeshReconstructionServer_Status);
