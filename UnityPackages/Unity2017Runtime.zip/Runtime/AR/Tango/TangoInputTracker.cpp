#include "UnityPrefix.h"
#include "TangoInputTracker.h"

#if ENABLE_NEW_INPUT_SYSTEM

#include "ARScriptingClasses.h"
#include "Runtime/Utilities/RuntimeStatic.h"
#include "Runtime/VR/PluginInterface/Headers/IUnityVR.h"
#include "Modules/Input/InputSystem.h"
#include "Modules/Input/InputEventData.h"
#if PLATFORM_ANDROID
#   include "TangoSupport.h"
#   include "TangoTypes.h"
#   include "TangoDevice.h"
#endif

namespace Tango
{
    // Modeled after VRInputNew

    InputTracker::InputTracker()
        : m_InputDeviceId(kInvalidInputDeviceId)
        , m_TrackingStatesBitfield(0)
        , m_BaseFrame(kTangoCoordinateFrameStartOfService)
    {
    }

    void InputTracker::Open()
    {
        InputDeviceDescriptor deviceDescriptor;
        deviceDescriptor.interfaceName = "AR";
        deviceDescriptor.type = "Handheld";
        deviceDescriptor.product = "Tango";
        deviceDescriptor.manufacturer = "Google";
        deviceDescriptor.version = Format("%i", 1);

        ReportNewDeviceOrReconnect(m_InputDeviceId, deviceDescriptor);
    }

    void InputTracker::ReportNewDeviceOrReconnect(InputDeviceID& deviceId, const InputDeviceDescriptor& deviceDescriptor)
    {
        if (deviceId == kInvalidInputDeviceId)
        {
            deviceId = ReportNewInputDevice(deviceDescriptor);
            m_TrackingStatesBitfield = 0;
        }
        else
        {
            ReportInputDeviceReconnect(deviceId, GetInputEventTimeNow());
        }
    }

    void InputTracker::Close()
    {
        double time = GetInputEventTimeNow();

        if (m_InputDeviceId != kInvalidInputDeviceId)
        {
            ReportInputDeviceDisconnect(m_InputDeviceId, time);
            m_TrackingStatesBitfield = 0;
        }
    }

    bool InputTracker::SetBaseCoordinateFrame(CoordinateFrame baseFrame)
    {
#if PLATFORM_ANDROID
        if (IsFixedTangoCoordinateFrame(baseFrame))
        {
            m_BaseFrame = baseFrame;
            return true;
        }
        else
#endif
        {
            return false;
        }
    }
} // namespace Tango

#endif // ENABLE_NEW_INPUT_SYSTEM
