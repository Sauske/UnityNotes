#include "UnityPrefix.h"

#if PLATFORM_ANDROID

#include <android/log.h>
#include <cstdlib>

#include "TangoSupport.h"
#include "TangoMeshReconstructionServer.h"
#include "TangoMeshReconstructionServerManager.h"
#include "TangoDevice.h"
#include "TangoImageBufferManager.h"
#include "TangoPointCloudManager.h"
#include "Runtime/Graphics/ScreenManager.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Math/Simd/vec-types.h"
#include "Runtime/Math/Simd/vec-quat.h"
#include "Runtime/Math/Simd/vec-matrix.h"
#include "Runtime/Math/Simd/vec-affine.h"

namespace Tango
{
    PROFILER_INFORMATION(gTangoInternalGetPoseAtTime, "Tango.InternalGetPoseAtTime", kProfilerVR);
    PROFILER_INFORMATION(gTangoGetPoseAtTime, "Tango.GetPoseAtTime", kProfilerVR);

    // Replaces and maps to TangoSupportRotation so that we can avoid taking
    // a dependency on the Tango support library.
    typedef enum
    {
        /// Not apply any rotation.
        kRotationIgnored = -1,  // ROTATION_IGNORED.
        kRotation0 = 0,         // ROTATION_0, 0 degree rotation (natural orientation)
        kRotation90 = 1,        // ROTATION_90
        kRotation180 = 2,       // ROTATION_180
        kRotation270 = 3        // ROTATION_270
    } RotationTangoType;

    static const math::float3x3 kDeviceTUnityCamera(
        math::float3(1.f, 0.f, 0.f),
        math::float3(0.f, 1.f, 0.f),
        math::float3(0.f, 0.f, -1.f));

    static const math::float3x3 kTangoCameraTUnityCamera(
        math::float3(1.0f, 0.0f, 0.0f),
        math::float3(0.0f, -1.0f, 0.0f),
        math::float3(0.0f, 0.0f, 1.0f));

    static const math::float3x3 kUnityWorldTStartOfService(
        math::float3(1.0f, 0.0f, 0.0f),
        math::float3(0.0f, 0.0f, 1.0f),
        math::float3(0.0f, 1.0f, 0.0f));

    static const math::float3x3 kUnityWorldTIMU(
        math::float3(0.0f, -1.0f, 0.0f),
        math::float3(1.0f, 0.0f, 0.0f),
        math::float3(0.0f, 0.0f, -1.0f));

    static const math::float3x3 kUnityWorldTIMUInverse(
        math::float3(0.0f, 1.0f, 0.0f),
        math::float3(-1.0f, 0.0f, 0.0f),
        math::float3(0.0f, 0.0f, -1.0f));

    // Unity display rotation matrix, used in supporting auto-rotation feature.
    static const math::float3x3 kRotation90TDefaultUnity(
        math::float3(0.0f, 1.0f, 0.0f),
        math::float3(-1.0f, 0.0f, 0.0f),
        math::float3(0.0f, 0.0f, 1.0f));

    static const math::float3x3 kRotation180TDefaultUnity(
        math::float3(-1.0f, 0.0f, 0.0f),
        math::float3(0.0f, -1.0f, 0.0f),
        math::float3(0.0f, 0.0f, 1.0f));

    static const math::float3x3 kRotation270TDefaultUnity(
        math::float3(0.0f, -1.0f, 0.0f),
        math::float3(1.0f, 0.0f, 0.0f),
        math::float3(0.0f, 0.0f, 1.0f));

    static const math::float3x3 kIdentity = math::identity3x3f();

    static const CoordinateFrame kFirstCameraFrame = kTangoCoordinateFrameCameraColor;
    static const CoordinateFrame kLastCameraFrame = kTangoCoordinateFrameCameraFisheye;
    static const UInt32 kNumCameraFrames = kLastCameraFrame - kFirstCameraFrame + 1;

    static math::float3 s_DeviceToCameraTranslations[kNumCameraFrames];

    static inline bool IsScreenOrientationRotationIgnored(ScreenOrientation unityOrientation)
    {
        return (unityOrientation != kPortrait &&
                unityOrientation != kPortraitUpsideDown &&
                unityOrientation != kLandscapeLeft &&
                unityOrientation != kLandscapeRight);
    }

    // Replaces TangoSupportRotation so that we don't need to take a dependency on the support library.
    static inline RotationTangoType UnityToTango(ScreenOrientation unityOrientation)
    {
        switch (unityOrientation)
        {
            case kPortrait:
                return kRotation0;          // TangoExternal::ROTATION_0;
            case kPortraitUpsideDown:
                return kRotation180;        // TangoExternal::ROTATION_180;
            case kLandscapeLeft:
                return kRotation270;        // TangoExternal::ROTATION_270;
            case kLandscapeRight:
                return kRotation90;         // TangoExternal::ROTATION_90;
            default:
                return kRotationIgnored;    // TangoExternal::ROTATION_IGNORED;
        }
    }

    static inline math::float3x3 GetUnityTFrameTransform(CoordinateFrame frame)
    {
        switch (frame)
        {
            case kTangoCoordinateFrameDevice:
            case kTangoCoordinateFrameDisplay:
                return kDeviceTUnityCamera;

            case kTangoCoordinateFrameCameraFisheye:
            case kTangoCoordinateFrameCameraDepth:
            case kTangoCoordinateFrameCameraColor:
                return kTangoCameraTUnityCamera;

            case kTangoCoordinateFrameStartOfService:
            case kTangoCoordinateFrameAreaDescription:
                return kUnityWorldTStartOfService;

            default:
                return kUnityWorldTIMU;
        }
    }

    static inline math::float3x3 GetFrameTUnityTransform(CoordinateFrame frame)
    {
        // The implementation just happens to be the same as that of
        // GetUnityTFrameTransform, because
        //   Device_T_UnityCamera == UnityCamera_T_Device
        //   TangoCamera_T_UnityCamera == UnityCamera_T_TangoCamera
        //   StartOfService_T_UnityWorld == UnityWorld_T_StartOfService
        if (frame == kTangoCoordinateFrameGlobalWGS84 ||
            frame == kTangoCoordinateFrameAreaDescription ||
            frame == kTangoCoordinateFramePreviousDevicePose ||
            frame == kTangoCoordinateFrameIMU ||
            frame == kTangoCoordinateFrameUUID ||
            frame == kTangoCoordinateFrameInvalid ||
            frame == kTangoCoordinateFrameMaxCoordinateFrameType)
        {
            return kUnityWorldTIMUInverse;
        }

        return GetUnityTFrameTransform(frame);
    }

    // Uses Tango as the base engine if useTangoEngine is true, Unity otherwise.
    static inline math::float3x3 GetRotationMatrixFromDeviceToDisplay(
        CoordinateFrame frame,
        ScreenOrientation screenOrientationUnity)
    {
        int screenOrientationAsInt = static_cast<int>(UnityToTango(screenOrientationUnity));
        int sensorFrameRotationAsInt = static_cast<int>(kRotation0);

        screenOrientationAsInt -= sensorFrameRotationAsInt;
        if (screenOrientationAsInt <  0)
        {
            screenOrientationAsInt += 4;
        }

        switch (screenOrientationAsInt)
        {
            case kRotation90:
                return kRotation90TDefaultUnity;
            case kRotation180:
                return kRotation180TDefaultUnity;
            case kRotation270:
                return kRotation270TDefaultUnity;
            default:
                return kIdentity;
        }
    }

    PROFILER_INFORMATION(gUpdateImageBuffer, "Tango.UpdateImageBuffer", kProfilerVR);
    PROFILER_INFORMATION(gUpdatePointCloud, "Tango.UpdatePointCloud", kProfilerVR);
    PROFILER_INFORMATION(gGetPoseAtTime, "Tango.GetPoseAtTime", kProfilerVR);

    static TangoClientPlugin g_TangoClientPlugin;
    static Tango3dReconstructionPlugin g_Tango3dReconstructionPlugin;
    static jobject g_CallerActivity = nullptr;
    static PointCloudManager* g_PointCloudManager = nullptr;
    static ImageBufferManager* g_ImageBufferManager = nullptr;

    TangoExternal::TangoUnity3DR_UpdateMethod UnityToTango(MeshReconstruction::UpdateMethod updateMethod)
    {
        switch (updateMethod)
        {
            case MeshReconstruction::kUpdateMethodTraversal:
                return TangoExternal::TANGO_UNITY_3DR_TRAVERSAL_UPDATE;
            case MeshReconstruction::kUpdateMethodProjective:
                return TangoExternal::TANGO_UNITY_3DR_PROJECTIVE_UPDATE;
            default:
                return TangoExternal::TANGO_UNITY_3DR_TRAVERSAL_UPDATE;
        }
    }

    // Translate between the Tango coordinate frames and Unity's abstraction for them
    TangoExternal::TangoCoordinateFrameType UnityToTango(CoordinateFrame frame)
    {
        switch (frame)
        {
            case kTangoCoordinateFrameGlobalWGS84:
                return TangoExternal::TANGO_COORDINATE_FRAME_GLOBAL_WGS84;
            case kTangoCoordinateFrameAreaDescription:
                return TangoExternal::TANGO_COORDINATE_FRAME_AREA_DESCRIPTION;
            case kTangoCoordinateFrameStartOfService:
                return TangoExternal::TANGO_COORDINATE_FRAME_START_OF_SERVICE;
            case kTangoCoordinateFramePreviousDevicePose:
                return TangoExternal::TANGO_COORDINATE_FRAME_PREVIOUS_DEVICE_POSE;
            case kTangoCoordinateFrameDevice:
                return TangoExternal::TANGO_COORDINATE_FRAME_DEVICE;
            case kTangoCoordinateFrameIMU:
                return TangoExternal::TANGO_COORDINATE_FRAME_IMU;
            case kTangoCoordinateFrameDisplay:
                return TangoExternal::TANGO_COORDINATE_FRAME_DISPLAY;
            case kTangoCoordinateFrameCameraColor:
                return TangoExternal::TANGO_COORDINATE_FRAME_CAMERA_COLOR;
            case kTangoCoordinateFrameCameraDepth:
                return TangoExternal::TANGO_COORDINATE_FRAME_CAMERA_DEPTH;
            case kTangoCoordinateFrameCameraFisheye:
                return TangoExternal::TANGO_COORDINATE_FRAME_CAMERA_FISHEYE;
            case kTangoCoordinateFrameUUID:
                return TangoExternal::TANGO_COORDINATE_FRAME_UUID;
            case kTangoCoordinateFrameInvalid:
                return TangoExternal::TANGO_COORDINATE_FRAME_INVALID;
            case kTangoCoordinateFrameMaxCoordinateFrameType:  // Fallthrough.
            default:
                return TangoExternal::TANGO_MAX_COORDINATE_FRAME_TYPE;
        }
    }

    CoordinateFrame TangoToUnity(TangoExternal::TangoCoordinateFrameType frame)
    {
        switch (frame)
        {
            case TangoExternal::TANGO_COORDINATE_FRAME_GLOBAL_WGS84:
                return kTangoCoordinateFrameGlobalWGS84;
            case TangoExternal::TANGO_COORDINATE_FRAME_AREA_DESCRIPTION:
                return kTangoCoordinateFrameAreaDescription;
            case TangoExternal::TANGO_COORDINATE_FRAME_START_OF_SERVICE:
                return kTangoCoordinateFrameStartOfService;
            case TangoExternal::TANGO_COORDINATE_FRAME_PREVIOUS_DEVICE_POSE:
                return kTangoCoordinateFramePreviousDevicePose;
            case TangoExternal::TANGO_COORDINATE_FRAME_DEVICE:
                return kTangoCoordinateFrameDevice;
            case TangoExternal::TANGO_COORDINATE_FRAME_IMU:
                return kTangoCoordinateFrameIMU;
            case TangoExternal::TANGO_COORDINATE_FRAME_DISPLAY:
                return kTangoCoordinateFrameDisplay;
            case TangoExternal::TANGO_COORDINATE_FRAME_CAMERA_COLOR:
                return kTangoCoordinateFrameCameraColor;
            case TangoExternal::TANGO_COORDINATE_FRAME_CAMERA_DEPTH:
                return kTangoCoordinateFrameCameraDepth;
            case TangoExternal::TANGO_COORDINATE_FRAME_CAMERA_FISHEYE:
                return kTangoCoordinateFrameCameraFisheye;
            case TangoExternal::TANGO_COORDINATE_FRAME_UUID:
                return kTangoCoordinateFrameUUID;
            case TangoExternal::TANGO_COORDINATE_FRAME_INVALID:
                return kTangoCoordinateFrameInvalid;
            case TangoExternal::TANGO_MAX_COORDINATE_FRAME_TYPE:  // Fallthrough.
            default:
                return kTangoCoordinateFrameMaxCoordinateFrameType;
        }
    }

    PoseStatus TangoToUnity(TangoExternal::TangoPoseStatusType status)
    {
        switch (status)
        {
            case TangoExternal::TANGO_POSE_INITIALIZING:
                return kTangoPoseInitializing;
            case TangoExternal::TANGO_POSE_VALID:
                return kTangoPoseValid;
            case TangoExternal::TANGO_POSE_INVALID:
                return kTangoPoseInvalid;
            case TangoExternal::TANGO_POSE_UNKNOWN:  // Fall through.
            default:
                return kTangoPoseUnknown;
        }
    }

    bool LoadTangoClientPlugin()
    {
        return ::LoadTangoClientPlugin(&g_TangoClientPlugin);
    }

    bool LoadTango3dReconstructionPlugin()
    {
        return false;
    }

    jobject& GetCallerActivity()
    {
        return g_CallerActivity;
    }

    TangoClientPlugin& GetTangoClientPlugin()
    {
        return g_TangoClientPlugin;
    }

    bool IsClientPluginLoaded()
    {
        return g_TangoClientPlugin.pluginLoaded;
    }

    Tango3dReconstructionPlugin& GetTango3dReconstructionPlugin()
    {
        return g_Tango3dReconstructionPlugin;
    }

    template<>
    BufferManager<TangoExternal::TangoPointCloud>* GetManager()
    {
        return GetPointCloudManager();
    }

    template<>
    BufferManager<ImageData>* GetManager()
    {
        return GetImageBufferManager();
    }

    bool Is3dReconstructionPluginLoaded()
    {
        return g_Tango3dReconstructionPlugin.pluginLoaded;
    }

    PointCloudManager* GetPointCloudManager()
    {
        return g_PointCloudManager;
    }

    ImageBufferManager* GetImageBufferManager()
    {
        return g_ImageBufferManager;
    }

    bool CreateImageBufferManager()
    {
        if (g_ImageBufferManager)
        {
            FreeImageBufferManager();
        }

        const UInt32 numConsumers = 2;
        g_ImageBufferManager = UNITY_NEW(ImageBufferManager, kMemDefault)(numConsumers, kMemDefault);

        return g_ImageBufferManager != nullptr;
    }

    void FreeImageBufferManager()
    {
        UNITY_DELETE(g_ImageBufferManager, kMemDefault);
    }

    bool UpdateImageBuffer(
        const TangoExternal::TangoImage* imageBuffer,
        const TangoExternal::TangoCameraMetadata* metadata)
    {
        PROFILER_AUTO(gUpdateImageBuffer, nullptr);

        if (g_ImageBufferManager)
        {
            ImageData imageData;
            imageData.image = *imageBuffer;
            imageData.metadata = *metadata;

            g_ImageBufferManager->Update(&imageData);
            return true;
        }
        else
        {
            return false;
        }
    }

    UInt32 GetNumBytesForImageBuffer(const TangoExternal::TangoImage& image)
    {
        if (image.num_planes > 0)
        {
            // There is some tribal knowledge here.
            // Google claim the following:
            //  plane_data[0] always points to the start of the memory block
            //  plane_data[n] (n > 0) are not necessarily monotonic, so a
            //    pointer to the end of the memory is
            //    max(plane_data[n] + plane_size[n]), n > 0
            //
            // From Matt Thiffault on the Android platform team
            // "The Y plane is always guaranteed to come first and be non - interleaved.
            //  It's plane_data pointer should always have the lowest value.
            //  The interleaved UV plane in the backend of all the devices we've ever run on
            //  (Qualcomm) has actually always been a VU plane in memory despite the fact that
            //  Android gives us the U plane pointer first in the array. So U and V have no
            //  guaranteed order. And aren't required to be interleaved."

            const UInt8* begin = image.plane_data[0];
            const UInt8* end = NULL;
            for (UInt8 i = 0; i < image.num_planes; ++i)
            {
                end = std::max<const UInt8*>(image.plane_data[i] + image.plane_size[i], end);
            }

            AssertMsg(end >= begin, "TangoImage plane_data pointers are not in expected order.");

            return end - begin;
        }

        return 0;
    }

    bool CreatePointCloudManager(int maxPointCloudElements)
    {
        if (g_PointCloudManager)
        {
            // Free existing point cloud manager so that a new one can be created with the desired maximum points
            FreePointCloudManager();
        }

        g_PointCloudManager = UNITY_NEW(PointCloudManager, kMemDefault)(maxPointCloudElements, 2, kMemDefault);

        return g_PointCloudManager != nullptr;
    }

    void FreePointCloudManager()
    {
        UNITY_DELETE(g_PointCloudManager, kMemDefault);
    }

    bool UpdatePointCloud(const TangoExternal::TangoPointCloud* pointCloud)
    {
        PROFILER_AUTO(gUpdatePointCloud, nullptr);

        if (g_PointCloudManager)
        {
            g_PointCloudManager->Update(pointCloud);
            return true;
        }
        else
        {
            return false;
        }
    }

    TangoExternal::TangoErrorType GetPoseAtTime(
        double timestamp,
        ScreenOrientation screenOrientation,
        CoordinateFrame baseFrame,
        CoordinateFrame targetFrame,
        TangoExternal::TangoPoseData* poseDataOut)
    {
        PROFILER_AUTO(gTangoGetPoseAtTime, nullptr);

        // Base engine is Unity when !useTangoEngine.
        // Target engine is always Tango.
        const bool isBaseFixedFrame = IsFixedTangoCoordinateFrame(baseFrame);
        const bool isTargetFixedFrame = IsFixedTangoCoordinateFrame(targetFrame);
        const bool isScreenRotationIgnored = IsScreenOrientationRotationIgnored(screenOrientation);

        if (!isScreenRotationIgnored && (isBaseFixedFrame == isTargetFixedFrame))
        {
#if UNITY_DEVELOPER_BUILD
            ErrorStringMsg("Invalid frame pairs (%d, %d)", (int)baseFrame, (int)targetFrame);
#endif
            return TangoExternal::TANGO_INVALID;
        }

        // If the targetFrame is a camera, then actually query the device pose and then
        // apply a precomputed translational offset. This is because the actual
        // camera poses will have some additional rotation (because of their physical
        // mounting) and it varies between devices. For the purposes of this method,
        // all cameras should have the same orientation as the device. The only
        // difference is their translation.
        math::float3 frameOffset(math::ZERO);

        if (isBaseFixedFrame &&
            targetFrame >= kFirstCameraFrame &&
            targetFrame <= kLastCameraFrame)
        {
            frameOffset = s_DeviceToCameraTranslations[targetFrame - kFirstCameraFrame];
            targetFrame = kTangoCoordinateFrameDevice;
        }

        // Get the pose from TangoCore.
        TangoExternal::TangoCoordinateFramePair framePairTango =
        {
            UnityToTango(baseFrame),
            UnityToTango(targetFrame)
        };

        PROFILER_BEGIN(gGetPoseAtTime, nullptr);

        const TangoExternal::TangoErrorType getPoseResult =
            g_TangoClientPlugin.GetPoseAtTime(timestamp, framePairTango, poseDataOut);

        PROFILER_END(gGetPoseAtTime);

        // Return in case of error, or base engine is Tango.
        if (getPoseResult != TangoExternal::TANGO_SUCCESS ||
            (poseDataOut->status_code != TangoExternal::TANGO_POSE_VALID &&
             poseDataOut->status_code != TangoExternal::TANGO_POSE_INITIALIZING))
        {
            return getPoseResult;
        }

        // Do engine and screen orientation transforms.
        math::float3 poseDataPosition = math::float3(
                (float)poseDataOut->translation[0],
                (float)poseDataOut->translation[1],
                (float)poseDataOut->translation[2]);

        const math::float4 poseDataRotation = math::float4(
                (float)poseDataOut->orientation[0],
                (float)poseDataOut->orientation[1],
                (float)poseDataOut->orientation[2],
                (float)poseDataOut->orientation[3]);

        poseDataPosition += math::quatMulVec(poseDataRotation, frameOffset);

        const math::float3 scale3(1.f);
        math::affineX baseToTarget = math::affineCompose(poseDataPosition, poseDataRotation, scale3);

        // These matrices convert between Unity and Tango's coordinate system
        const math::float3x3 engineToBase(GetUnityTFrameTransform(baseFrame));
        const math::float3x3 targetToEngine(GetFrameTUnityTransform(targetFrame));

        // The final pose
        math::affineX engineBaseToEngineTarget(math::affineIdentity());

        if (isBaseFixedFrame && !isTargetFixedFrame && !isScreenRotationIgnored)
        {
            const math::float3x3 displayRotationMtx(
                GetRotationMatrixFromDeviceToDisplay(targetFrame, screenOrientation));

            engineBaseToEngineTarget.rs = math::mul(targetToEngine, displayRotationMtx);
            engineBaseToEngineTarget = math::mul(baseToTarget, engineBaseToEngineTarget);
            engineBaseToEngineTarget = math::mul(engineToBase, engineBaseToEngineTarget);
        }
        else if (!isBaseFixedFrame && isTargetFixedFrame && !isScreenRotationIgnored)
        {
            math::float3x3 displayRotationMtx;

            // Technically this function can fail, but we already know
            // GetRotationMatrixFromSensorToDisplay returns a non-singular matrix
            math::adjInverse(
                GetRotationMatrixFromDeviceToDisplay(baseFrame, screenOrientation),
                displayRotationMtx);

            engineBaseToEngineTarget = math::mul(baseToTarget, targetToEngine);
            engineBaseToEngineTarget = math::mul(engineToBase, engineBaseToEngineTarget);
            engineBaseToEngineTarget = math::mul(displayRotationMtx, engineBaseToEngineTarget);
        }
        else
        {
            engineBaseToEngineTarget = math::mul(baseToTarget, targetToEngine);
            engineBaseToEngineTarget = math::mul(engineToBase, engineBaseToEngineTarget);
        }

        // Put the matrix back into pose form.
        const math::float3& newPosition = engineBaseToEngineTarget.t;
        const math::float4 newRotation = math::matrixToQuat(engineBaseToEngineTarget.rs);

        poseDataOut->translation[0] = (double)newPosition.x;
        poseDataOut->translation[1] = (double)newPosition.y;
        poseDataOut->translation[2] = (double)newPosition.z;

        poseDataOut->orientation[0] = (double)newRotation.x;
        poseDataOut->orientation[1] = (double)newRotation.y;
        poseDataOut->orientation[2] = (double)newRotation.z;
        poseDataOut->orientation[3] = (double)newRotation.w;

        return getPoseResult;
    }

    TangoExternal::TangoErrorType GetPoseAtTime(
        double timestamp,
        CoordinateFrame baseFrame,
        CoordinateFrame targetFrame,
        TangoExternal::TangoPoseData* poseDataOut)
    {
        return GetPoseAtTime(
            timestamp,
            GetScreenManager().GetScreenOrientation(),
            baseFrame,
            targetFrame,
            poseDataOut);
    }

    bool IsFixedTangoCoordinateFrame(CoordinateFrame frame)
    {
        return (frame == kTangoCoordinateFrameGlobalWGS84 ||
                frame == kTangoCoordinateFrameAreaDescription ||
                frame == kTangoCoordinateFrameStartOfService);
    }

    void ComputeDeviceToCameraPoses()
    {
        // Query all cameras relative to the Device frame
        TangoExternal::TangoCoordinateFramePair framePair;
        framePair.base = UnityToTango(kTangoCoordinateFrameDevice);

        // A timestamp of 0.0 means "get the latest"
        double poseTimestamp = 0.0;

        for (UInt32 i = 0; i < kNumCameraFrames; ++i)
        {
            const CoordinateFrame targetFrameUnity = static_cast<CoordinateFrame>(i + kFirstCameraFrame);
            framePair.target = UnityToTango(targetFrameUnity);

            TangoExternal::TangoPoseData poseData;

            const TangoExternal::TangoErrorType getPoseResult =
                g_TangoClientPlugin.GetPoseAtTime(poseTimestamp, framePair, &poseData);

            if (getPoseResult == TangoExternal::TANGO_SUCCESS &&
                (poseData.status_code == TangoExternal::TANGO_POSE_INITIALIZING ||
                 poseData.status_code == TangoExternal::TANGO_POSE_VALID))
            {
                // After the first successful pose, use the same timestamp for
                // the rest of the cameras. This ensures we're using the same
                // reference time for each camera query.
                if (poseTimestamp == 0.0)
                {
                    poseTimestamp = poseData.timestamp;
                }

                s_DeviceToCameraTranslations[i] = math::float3(
                        (float)poseData.translation[0],
                        (float)poseData.translation[1],
                        (float)poseData.translation[2]);
            }
            else
            {
                s_DeviceToCameraTranslations[i] = math::float3(math::ZERO);

#if UNITY_DEVELOPER_BUILD
                ErrorStringMsg("Error %x-%x: "
                    "Could not get initial device-to-camera pose for frame pair (%d, %d) at timestamp %f. "
                    "Will report this Camera Pose as Device Pose.",
                    (int)getPoseResult, (int)poseData.status_code,
                    (int)framePair.base, (int)framePair.target, poseData.timestamp);
#endif
            }
        }
    }

    bool DeviceHasValidPoseAtTime(double timestamp)
    {
        TangoExternal::TangoPoseData poseData;

        TangoExternal::TangoCoordinateFramePair framePair =
        {
            UnityToTango(kTangoCoordinateFrameStartOfService),
            UnityToTango(kTangoCoordinateFrameDevice)
        };

        TangoExternal::TangoErrorType errorCode;
        {
            PROFILER_AUTO(gTangoInternalGetPoseAtTime, nullptr);
            errorCode =
                Tango::GetTangoClientPlugin().GetPoseAtTime(timestamp, framePair, &poseData);
        }

        if (errorCode == TangoExternal::TANGO_SUCCESS &&
            poseData.status_code == TangoExternal::TANGO_POSE_VALID)
        {
            return true;
        }
        else
        {
#if DEBUGMODE
            ErrorStringMsg("Could not get a pose for the latest image buffer at time %f. Error code %x-%x",
                timestamp, (int)errorCode, (int)poseData.status_code);
#endif
            return false;
        }
    }
} // namespace Tango

#endif
