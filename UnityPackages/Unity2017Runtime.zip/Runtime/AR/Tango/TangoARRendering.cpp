#include "UnityPrefix.h"

#if PLATFORM_ANDROID

#include "TangoARRendering.h"
#include "TangoBinder.h"
#include "TangoDevice.h"
#include "TangoProfiler.h"
#include "TangoEngineCallbackHandler.h"
#include "Runtime/AR/ARTypes.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Camera/Camera.h"
#include "Runtime/Camera/RenderManager.h"
#include "Runtime/GfxDevice/opengles/ApiConstantsGLES.h"
#include "Runtime/GfxDevice/opengles/ApiGLES.h"
#include "Runtime/Graphics/Texture2D.h"
#include "Runtime/Graphics/CommandBuffer/RenderingCommandBuffer.h"
#include "Runtime/Shaders/Material.h"

namespace Tango
{
    PROFILER_INFORMATION(gUpdateExternalTextureCallback, "Tango.UpdateExternalTextureCallback", kProfilerVR);
    PROFILER_INFORMATION(gTangoInternalUpdateExternalTexture, "Tango.InternalUpdateExternalTexture", kProfilerVR);

    ARRendering* ARRendering::s_Instance = nullptr;

    static void OnTextureAvailableRouter(void* context, TangoExternal::TangoCameraId cameraId)
    {
        // Let the main thread know that there is a new camera image
        EngineCallbackHandler::GetInstance()->OnTextureAvailable(cameraId);
    }

    ARRendering::ARRendering()
        : m_UnityARTexture(nullptr)
        , m_Initialized(false)
        , m_ExternalTextureUpdatedOnce(false)
        , m_GLARTextureId(GL_NONE)
        , m_LastCameraImageTimestamp(kUninitialized)
        , m_BackgroundMaterial(nullptr)
    {}

    ARRendering::~ARRendering()
    {
        Shutdown();
    }

    void ARRendering::SetBackgroundMaterial(Material *backgroundMaterial)
    {
        m_BackgroundMaterial = backgroundMaterial;
    }

    Material* ARRendering::GetBackgroundMaterial() const
    {
        return m_BackgroundMaterial;
    }

    bool ARRendering::Initialize()
    {
        if (m_Initialized)
        {
            // We may be initialized, but we need to
            // setup the callback into the tango service.
            return SetupTangoCamera();
        }

        m_Initialized = SetupARTexture();
        m_Initialized &= SetupTangoCamera();

        if (!m_Initialized)
            ErrorString("Tango::ARRendering::Initialize() failed.");

        return m_Initialized;
    }

    void ARRendering::Shutdown()
    {
        if (m_Initialized)
        {
            DestroySingleObject(m_UnityARTexture);
            m_UnityARTexture = nullptr;

            // Delete GL texture
            if (m_GLARTextureId != GL_NONE)
            {
                GetGfxDevice().InsertCustomMarkerCallback(
                    &ARRendering::DeleteExternalTextureCallback,
                    static_cast<int>(m_GLARTextureId));

                m_GLARTextureId = GL_NONE;
            }

            m_Initialized = false;
            m_ExternalTextureUpdatedOnce = false;
        }
    }

    GLuint ARRendering::GetARTextureId() const
    {
        return m_GLARTextureId;
    }

    double ARRendering::GetLastCameraImageTimestamp() const
    {
        return m_LastCameraImageTimestamp;
    }

    // Called during initialization to set up the GL and Unity AR texture resources
    bool ARRendering::SetupARTexture()
    {
        if (m_GLARTextureId != GL_NONE)
        {
            // We need to delete the GL texture on the graphics thread
            GetGfxDevice().InsertCustomMarkerCallback(&ARRendering::DeleteExternalTextureCallback, static_cast<int>(m_GLARTextureId));
        }

        GfxDevice& device = GetGfxDevice();
        device.InsertCustomMarkerCallback(&ARRendering::CreateExternalTextureCallback, 0);

        // We need to block until the graphics thread completes the callback
        device.WaitOnCPUFence(device.InsertCPUFence());

        if (m_GLARTextureId == GL_NONE)
            ErrorString("TangoARRendering::SetupARTexture() failed.");

        return (m_GLARTextureId != GL_NONE);
    }

    // Called from the callback handler for texture update in order to set shader parameters on the background material
    bool ARRendering::SetupARMaterial()
    {
        if (!m_BackgroundMaterial)
            return false;

        // Set the AR texture as the main texture of this material
        m_BackgroundMaterial->SetTexture(ShaderLab::Property("_MainTex"), m_UnityARTexture);

        return true;
    }

// Called during initialization to setup the callback function for color camera texture updates
    bool ARRendering::SetupTangoCamera()
    {
        TangoClientPlugin &tangoClientPlugin = GetTangoClientPlugin();
        TangoExternal::TangoErrorType err = tangoClientPlugin.SetCallback_OnTextureAvailable(
                TangoExternal::TangoCameraId::TANGO_CAMERA_COLOR,
                nullptr,
                &OnTextureAvailableRouter);

        return (err == TangoExternal::TANGO_SUCCESS);
    }

// Called from the graphics thread to create the GL texture that is the basis for the Unity AR texture
    void UNITY_INTERFACE_API ARRendering::CreateExternalTextureCallback(const int id)
    {
        s_Instance->m_GLARTextureId = gGL->GenTexture(GL_TEXTURE_EXTERNAL_OES);
    }

// Called from the graphics thread to destroy GL texture
    void UNITY_INTERFACE_API ARRendering::DeleteExternalTextureCallback(const int textureId)
    {
        GLuint glTexId = static_cast<GLuint>(textureId);
        gGL->DeleteTexture(glTexId);
    }

// Called by the OnTextureAvailable() callback to actually update the GL texture by calling a Tango API to do so.
// There is also some initialization here that is called after the first call to the Tango API since we need a valid
// GL texture before it can be completed.
    void ARRendering::UpdateExternalTextureCallback(const int textureId)
    {
        PROFILER_AUTO(gUpdateExternalTextureCallback, nullptr);

        GLuint glTexId = static_cast<GLuint>(textureId);

        // Prevent crash in case of a null background material.
        if (s_Instance->m_BackgroundMaterial == nullptr || glTexId == GL_NONE)
        {
            return;
        }

        // Update the screen orientation
        s_Instance->m_BackgroundMaterial->SetFloat(ShaderLab::Property("_ScreenOrientation"), GetScreenManager().GetScreenOrientation());

        bool success;
        {
            PROFILER_AUTO(gTangoInternalUpdateExternalTexture, nullptr);
            TangoClientPlugin &tangoClientPlugin = GetTangoClientPlugin();
            success = (TangoExternal::TANGO_SUCCESS == tangoClientPlugin.UpdateTextureExternalOes(
                           TangoExternal::TangoCameraId::TANGO_CAMERA_COLOR,
                           glTexId,
                           &s_Instance->m_LastCameraImageTimestamp));
        }

        if (!success)
        {
            return;
        }

        // Initialization code that requires a valid texture before it can be called
        if (!s_Instance->m_ExternalTextureUpdatedOnce)
        {
            // Destroy any previous Unity texture
            if (nullptr != s_Instance->m_UnityARTexture)
            {
                DestroySingleObject(s_Instance->m_UnityARTexture);
            }

            // Get camera info from Tango API to find out the size of the image coming out of the camera - we need it below
            TangoExternal::TangoCameraIntrinsics cameraIntrinsics;
            TangoClientPlugin &tangoClientPlugin = GetTangoClientPlugin();
            TangoExternal::TangoErrorType err = tangoClientPlugin.GetCameraIntrinsics(TangoExternal::TangoCameraId::TANGO_CAMERA_COLOR, &cameraIntrinsics);

            if (err == TangoExternal::TANGO_SUCCESS)
            {
                const float screenMaxDim = std::max<float>(GetScreenManager().GetWidth(), GetScreenManager().GetHeight());
                const float screenMinDim = std::min<float>(GetScreenManager().GetWidth(), GetScreenManager().GetHeight());
                float scale = 1.0f;

                // Only calculate scaling factor for phones with different aspect ratios for display and camera
                if ((screenMaxDim / screenMinDim) != ((float)cameraIntrinsics.width / (float)cameraIntrinsics.height))
                {
                    // This looks funny but it's due to the fact that the image dimensions assume landscape and
                    // the screen dimensions assume portrait
                    scale = screenMaxDim / (float)cameraIntrinsics.width;
                }

                // Set the scaling factor
                s_Instance->m_BackgroundMaterial->SetFloat(ShaderLab::Property("_HeightScale"), scale);

                // Create the Unity Texture2D object and initialize it with the native GL texture
                s_Instance->m_UnityARTexture = CreateObjectFromCode<Texture2D>();
                s_Instance->m_UnityARTexture->SetHideFlags(Object::kHideAndDontSave);
                const bool retVal = s_Instance->m_UnityARTexture->InitTexture(cameraIntrinsics.width, cameraIntrinsics.height, kTexFormatRGBA32, Texture2D::kFlagDontDestroyTexture, 1, -1, glTexId);

                s_Instance->m_UnityARTexture->SetWrapMode(kTexWrapClamp);
                s_Instance->m_UnityARTexture->SetFilterMode(kTexFilterNearest);

                // Setup the background material associated with the camera (if there is one)
                if (retVal)
                {
                    s_Instance->SetupARMaterial();
                }
            }

            s_Instance->m_ExternalTextureUpdatedOnce = true;
        }
    }
} // namespace Tango

#endif
