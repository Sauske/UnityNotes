#pragma once

#include "Runtime/Threads/AtomicOps.h"
#include "Runtime/Threads/Mutex.h"
#include "Runtime/Utilities/dynamic_array.h"

// A buffer manager for Tango data that is produced by
// one thread and consumed by multiple other threads.

namespace Tango
{
    template<typename T>
    class BufferManager
    {
    protected:

        // Computes the number of bytes to allocate for a given buffer
        // Should be implemented in specialization
        static UInt32 ComputeDataSize(const T* buffer);

        // Returns the pointer to the memory block represented by buffer
        // Should be implemented in specialization
        static void* GetDataPtr(T* buffer);
        static const void* GetDataPtr(const T* buffer);

        // Sets the data pointer to the memory block represented by buffer
        // Should be implemented in specialization
        static void SetDataPtr(T* buffer, void* ptr);

        virtual void CopyBuffer(T* destinationBuffer, const T* sourceBuffer) = 0;

        static bool IsTimestampGreaterThanZero(const T& buffer);
        static bool IsTimestampGreaterThan(const T& lhs, const T& rhs);

    protected:

        enum { kWriteLock = -1 };

        struct LockableBuffer : T
        {
            // lockCount == -1 => write lock by 1 producer
            // lockCount > 0   => read lock by lockCount consumers
            volatile int lockCount = 0;
        };

        dynamic_array<LockableBuffer> m_Storage;

    public:

        typedef T BufferType;

        // Useful for RAII
        struct AutoReadLock : NonCopyable
        {
            AutoReadLock(BufferManager<T>& manager, const T* buffer)
                : m_Manager(manager)
                , m_Buffer(buffer)
            {}

            ~AutoReadLock()
            {
                m_Manager.ReleaseBuffer(m_Buffer);
            }

        private:
            BufferManager<T>& m_Manager;
            const T* m_Buffer;
        };

    public:

        BufferManager(UInt32 numConsumers, MemLabelId memoryLabel);

        virtual ~BufferManager();

        inline void Update(const T* imageBuffer);

        inline const T* AcquireLatestBuffer();

        inline void ReleaseBuffer(const T* buffer);

    protected:

        // Copies the T from source to buffer without overwriting the pointer
        // to the actual data member.
        inline void CopyMetadata(T* destinationBuffer, const T* sourceBuffer);

        MemLabelId m_MemoryLabel;
    };

    template<typename T>
    inline void BufferManager<T>::CopyMetadata(T* destinationBuffer, const T* sourceBuffer)
    {
        // Keep the original data pointer
        void* data = GetDataPtr(destinationBuffer);

        // Copy metadata
        std::copy(sourceBuffer, sourceBuffer + 1, destinationBuffer);

        // Restore data pointer
        SetDataPtr(destinationBuffer, data);
    }

    template<typename T>
    inline const T* BufferManager<T>::AcquireLatestBuffer()
    {
        LockableBuffer* bestCandidate = nullptr;
        int bestLock = kWriteLock;

        do
        {
            bestCandidate = nullptr;

            for (auto& lockableBuffer : m_Storage)
            {
                const int lockCount = lockableBuffer.lockCount;

                // A timestamp of zero means we haven't used it yet
                if (IsTimestampGreaterThanZero(lockableBuffer) && lockCount != kWriteLock &&
                    (bestCandidate == nullptr || IsTimestampGreaterThan(lockableBuffer, *bestCandidate)))
                {
                    bestCandidate = &lockableBuffer;
                    bestLock = lockCount;
                }
            }
        }
        while (bestCandidate && !AtomicCompareExchange(&bestCandidate->lockCount, bestLock + 1, bestLock));

#if DEBUGMODE
        if (bestCandidate == nullptr)
        {
            ErrorString("Could not locate a valid front buffer.");
        }
#endif

        return bestCandidate;
    }

    template<typename T>
    inline void BufferManager<T>::ReleaseBuffer(const T* buffer)
    {
        if (OPTIMIZER_UNLIKELY(buffer == nullptr))
            return;

        // We expect N to be small, so a linear search will suffice
        for (auto& lockableBuffer : m_Storage)
        {
            if (&lockableBuffer == buffer)
            {
                // Since this method can be triggered from user script, we need
                // to account for the user calling ReleaseBuffer too many times
                int newCount, oldCount;
                do
                {
                    oldCount = lockableBuffer.lockCount;
                    newCount = std::max<int>(oldCount - 1, 0);
                }
                while (!AtomicCompareExchange(&lockableBuffer.lockCount, newCount, oldCount));

                return;
            }
        }
#if DEBUGMODE
        ErrorStringMsg("Could not locate provided buffer %p",
            (void*)buffer);
#endif
    }

    template<typename T>
    inline void BufferManager<T>::Update(const T* buffer)
    {
        for (auto& lockableBuffer : m_Storage)
        {
            // Look for a buffer with a lockCount of zero. Try to change it
            // to kWriteLock temporarily so no one else grabs it at the same time.
            if (AtomicCompareExchange(&lockableBuffer.lockCount, kWriteLock, 0))
            {
                CopyBuffer(&lockableBuffer, buffer);
                lockableBuffer.lockCount = 0;
                return;
            }
        }
#if UNITY_DEVELOPER_BUILD
        ErrorString("Could not find a backbuffer to write to. "
            "You may need to increase the number of consumers or you forgot to release a buffer.");
#endif
    }

    template<typename T>
    inline BufferManager<T>::~BufferManager()
    {
        for (UInt32 i = 0; i < m_Storage.size(); ++i)
        {
            UNITY_FREE(m_MemoryLabel, GetDataPtr(&m_Storage[i]));
        }
    }

    template<typename T>
    inline BufferManager<T>::BufferManager(UInt32 numConsumers, MemLabelId memoryLabel)
        : m_Storage(numConsumers + 1, memoryLabel)
        , m_MemoryLabel(memoryLabel)
    {
        for (auto& buffer : m_Storage)
        {
            memset(&buffer, 0, sizeof(LockableBuffer));
        }
    }
} // namespace Tango
