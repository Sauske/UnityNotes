#pragma once

#if PLATFORM_ANDROID

#include "External/Tango/builds/gen/ApiFuncTango3dReconstruction.h"
#include "TangoSupport.h"
#include "TangoMeshReconstructionTypes.h"
#include "Runtime/Threads/Thread.h"
#include "Runtime/Threads/Semaphore.h"
#include "Runtime/Threads/Mutex.h"
#include "Runtime/Utilities/EnumFlags.h"

namespace Tango
{
    class Device;

namespace MeshReconstruction
{
    class Server;

    class ServerManager
    {
        typedef dynamic_array<Server*> ServerArray;
        typedef dynamic_array<const Server*> ConstServerArray;

        enum ColorGenerationFlags
        {
            kClear = 0,
            kIsColorCameraEnabled = 1 << 0,
            kAtLeastOneServerNeedsColor = 1 << 1
        };
        ENUM_FLAGS_AS_MEMBER(ColorGenerationFlags);

    public:

        ServerManager();

        ~ServerManager();

        // Interface for depth-only vs color camera
        void OnPointCloudAvailable(
            const TangoExternal::TangoPointCloud* pointCloud);

        void OnImageAvailable(
            TangoExternal::TangoCameraId id);

        void SetColorCameraEnabled(bool isEnabled);

        //
        // Things that can be done from script
        //
        Server* CreateServer(ScriptingObjectPtr self, const Config& config, CreationStatus* statusOut);

        void DestroyServer(Server* server);

        void DestroyThreadedServer(Server* server);

    private:

        bool IsColorGenerationEnabled() const
        { return HasAllFlags(m_ColorGenerationFlags, kIsColorCameraEnabled | kAtLeastOneServerNeedsColor); }

        void UpdateColorCameraFlag();

        static void UpdateServers(
            const ConstServerArray& servers,
            const TangoExternal::TangoPointCloud& pointCloud,
            const TangoExternal::TangoPoseData& pointCloudPose,
            const TangoExternal::TangoImage* imageBuffer,
            const TangoExternal::TangoPoseData* imagePose);

        const TangoExternal::TangoPointCloud* AcquirePointCloud();
        void ReleasePointCloud();
        const ImageData* AcquireImageBuffer();
        void ReleaseImageBuffer();
        const TangoExternal::TangoPoseData* GetDepthPose(double timestamp);
        const TangoExternal::TangoPoseData* GetColorCameraPose(double timestamp);

        static const TangoExternal::TangoPoseData* GetPoseAtTime(
            double timestamp,
            CoordinateFrame targetFrame,
            TangoExternal::TangoPoseData* poseOut);

        void SignalWorkerThread();
        void UpdateGridIndices(const ConstServerArray& servers);
        void ProcessPendingDeletes();
        void StartWorkerThreadIfNotRunning();

        static void* StaticThreadEntry(void* data);
        void ThreadEntry();

        ServerArray m_Servers;

        ServerArray m_pendingDeletes;

        mutable Mutex m_ServerListMutex;

        Semaphore m_WorkerSemaphore;

        Thread m_WorkerThread;

        ColorGenerationFlags m_ColorGenerationFlags = kClear;

        bool m_HasUpdatedPointCloud = false;

        bool m_HasUpdatedColorImage = false;

        // Storage for data we only ever return as const pointers
        TangoExternal::TangoPoseData m_PointCloudPose;
        TangoExternal::TangoPoseData m_ColorCameraPose;
        const TangoExternal::TangoPointCloud* m_AcquiredPointCloud = nullptr;
        const ImageData* m_AcquiredImageBuffer = nullptr;
    };
} // namespace MeshReconstruction
} // namespace Tango

#endif
