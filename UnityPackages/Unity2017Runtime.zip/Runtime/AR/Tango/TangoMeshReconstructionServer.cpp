#include "UnityPrefix.h"

#if PLATFORM_ANDROID

#include "PlatformDependent/AndroidPlayer/Source/NativeRuntimeException.h"
#include "TangoMeshReconstructionServer.h"
#include "TangoMeshReconstructionTypes.h"
#include "TangoResourcePool.h"
#include "Runtime/Dynamics/PhysicsManager.h"
#include "Runtime/Dynamics/MeshCollider.h"
#include "Runtime/Graphics/Mesh/Mesh.h"
#include "Runtime/Graphics/Mesh/MeshFilter.h"
#include "Runtime/Input/TimeManager.h"
#include "Runtime/Math/Simd/vec-matrix.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Scripting/ScriptingTypes.h"
#include "Runtime/Utilities/RuntimeStatic.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "ARScriptingClasses.h"

namespace Tango
{
namespace MeshReconstruction
{
    PROFILER_INFORMATION(gTango3drUpdate, "Tango.3DR_Update", kProfilerVR);
    PROFILER_INFORMATION(gExtractPreallocatedMeshSegment, "Tango.3DR_ExtractMeshSegment", kProfilerVR);
    PROFILER_INFORMATION(gCheckForOrphanedVertices, "Tango.CheckVertices", kProfilerVR);
    PROFILER_INFORMATION(gRemapVertices, "Tango.RemapVertices", kProfilerVR);
    PROFILER_INFORMATION(gTransformNormals, "Tango.TransformNormals", kProfilerVR);

    // This is used to assign an identifier to each SurfaceObserver that can used to uniquely identify targets
    // of events sent through the GlobalEventQueue. Because Unity's memory manager can recycle memory, instance
    // pointers are insufficient to uniquely identify event targets, because we might have allocated a new object
    // at the same address as an old object with a pending event. This can actually be fairly common because of
    // the way that Unity's memory allocator works.
    int Server::s_LastEventSubscriberId = 1;

    // After extracting a mesh segment, we need to transform
    // the normals as they do not get post multiplied
    // by the requested external_T_tango matrix.
    // [1 0 0]
    // [0 0 1]
    // [0 1 0]
    static const math::float3x3 s_TangoToUnity(
        math::float3(1, 0, 0),
        math::float3(0, 0, 1),
        math::float3(0, 1, 0));


#if UNITY_DEVELOPER_BUILD
    static inline const char* ToTrueFalse(bool value)
    {
        return value ? "true" : "false";
    }

#endif

    Server::Server(
        ScriptingObjectPtr self,
        const Config& config,
        TangoExternal::Tango3DR_ReconstructionContext context)
        : m_ManagedHandle(self, GCHANDLE_WEAK)
        , m_Config(config)
        , m_Context(context)
    {
        DebugAssert(m_Context != nullptr);

        // If color generation was requested, we need to make sure the camera intrinsics
        // have been set. If we can't do it, we emit a warning but we can still generate
        // meshes.
        if (m_Config.generateColor)
        {
            TangoClientPlugin& clientPlugin = Tango::GetTangoClientPlugin();

            TangoExternal::TangoCameraIntrinsics cameraCalibration;

            const TangoExternal::TangoErrorType getCalibrationResult =
                clientPlugin.GetCameraIntrinsics(TangoExternal::TANGO_CAMERA_COLOR, &cameraCalibration);

            // Make sure we can access the color camera; otherwise, disable color generation.
            if (getCalibrationResult == TangoExternal::TANGO_SUCCESS)
            {
                Tango3dReconstructionPlugin& reconstructionPlugin = GetTango3dReconstructionPlugin();
                const TangoExternal::TangoUnity3DR_Status setCalibrationResult =
                    reconstructionPlugin.SetColorCalibration(m_Context, &cameraCalibration);

                m_Config.generateColor = (setCalibrationResult == TangoExternal::TANGO_UNITY_3DR_SUCCESS);

#if UNITY_DEVELOPER_BUILD
                if (setCalibrationResult != TangoExternal::TANGO_UNITY_3DR_SUCCESS)
                {
                    WarningStringMsg("Failed to set color camera calibration with error code %d. Disabling color.",
                        (int)setCalibrationResult);
                }
#endif
            }
            else
            {
                m_Config.generateColor = false;

#if UNITY_DEVELOPER_BUILD
                WarningStringMsg("Failed to get color camera calibration with error code %d. Disabling color.",
                    (int)getCalibrationResult);
#endif
            }
        }

        GlobalEventQueue::GetInstance().AddHandler(m_GridIndicesChangedDelegate.SetObject(this));
        GlobalEventQueue::GetInstance().AddHandler(m_DestroyThreadedDelegate.SetObject(this));
        GlobalEventQueue::GetInstance().AddHandler(m_MeshSegmentProcessedDelegate.SetObject(this));
    }

    Server::~Server()
    {
        if (m_Context)
        {
            Tango3dReconstructionPlugin& plugin = Tango::GetTango3dReconstructionPlugin();
            plugin.Destroy(m_Context);
        }

        m_Context = nullptr;
    }

    Server* Server::Create(ScriptingObjectPtr self, const Config& config, CreationStatus* statusOut)
    {
        if (!Is3dReconstructionPluginLoaded())
        {
            ErrorString("Mesh reconstruction requested but Tango 3d reconstruction plugin is not loaded. Mesh reconstruction unavailable.");
            *statusOut = kCreationStatusMissingLib;
            return nullptr;
        }

#if UNITY_DEVELOPER_BUILD
        LogStringMsg("Tango3drServer settings:\n"
            "\tuse_parallel_integration %s\n"
            "\tresolution %f\n"
            "\tgenerate_color %s\n"
            "\tmin_depth %f\n"
            "\tmax_depth %f\n"
            "\tuse_space_clearing %s\n"
            "\tmin_num_vertices to %d\n"
            "\tupdate_method %d\n",
            ToTrueFalse(config.useParallelIntegration),
            config.resolution,
            ToTrueFalse(config.generateColor),
            config.minDepth,
            config.maxDepth,
            ToTrueFalse(config.useSpaceClearing),
            config.minNumVertices,
            config.updateMethod);
#endif

        Tango3dReconstructionPlugin& reconstructionPlugin = Tango::GetTango3dReconstructionPlugin();
        TangoExternal::TangoUnity3DR_Config tangoConfig = reconstructionPlugin.Config_create();
        reconstructionPlugin.Config_setBool(tangoConfig, "use_parallel_integration", config.useParallelIntegration);
        reconstructionPlugin.Config_setDouble(tangoConfig, "resolution", config.resolution);
        reconstructionPlugin.Config_setBool(tangoConfig, "generate_color", config.generateColor);
        reconstructionPlugin.Config_setDouble(tangoConfig, "min_depth", config.minDepth);
        reconstructionPlugin.Config_setDouble(tangoConfig, "max_depth", config.maxDepth);
        reconstructionPlugin.Config_setBool(tangoConfig, "use_space_clearing", config.useSpaceClearing);
        reconstructionPlugin.Config_setInt32(tangoConfig, "min_num_vertices", config.minNumVertices);
        reconstructionPlugin.Config_setInt32(tangoConfig, "update_method", UnityToTango(config.updateMethod));

        // The 3d reconstruction takes a pose, but it doesn't handle
        // left handed coordinate systems. It will "kind of" work but
        // meshes tend to come out as blobs. So we'll pass the 3d
        // reconstruction lib a Tango pose, but tell it to use this
        // matrix when it writes out its verts.
        TangoExternal::TangoUnity3DR_Matrix3x3 unityToTango;
        memset(&unityToTango, 0, sizeof(TangoExternal::TangoUnity3DR_Matrix3x3));

        // Column major 3x3. We want this matrix:
        // [1 0 0]
        // [0 0 1]
        // [0 1 0]
        unityToTango.data[0] = 1.0;
        unityToTango.data[5] = 1.0;
        unityToTango.data[7] = 1.0;

        reconstructionPlugin.Config_setMatrix3x3(tangoConfig, "external_T_tango", &unityToTango);

        // The use of the above matrix reverses the meaning of "clockwise"
        reconstructionPlugin.Config_setBool(tangoConfig, "use_clockwise_winding_order", true);

        TangoExternal::Tango3DR_ReconstructionContext context = reconstructionPlugin.Create(tangoConfig);
        reconstructionPlugin.Config_destroy(tangoConfig);

        if (context == nullptr)
        {
            *statusOut = kCreationStatusNullContext;
            return nullptr;
        }

        // Tango docs say it is an error to use the projective update method
        // without also setting the depth camera intrinsics.
        if (config.updateMethod == kUpdateMethodProjective)
        {
            bool isOk = false;

            TangoClientPlugin& clientPlugin = Tango::GetTangoClientPlugin();

            TangoExternal::TangoCameraIntrinsics depthCameraCalibration;

            const TangoExternal::TangoErrorType getCalibrationResult =
                clientPlugin.GetCameraIntrinsics(TangoExternal::TANGO_CAMERA_DEPTH, &depthCameraCalibration);

            if (getCalibrationResult == TangoExternal::TANGO_SUCCESS)
            {
                const TangoExternal::TangoUnity3DR_Status setCalibrationResult =
                    reconstructionPlugin.SetDepthCalibration(context, &depthCameraCalibration);

                isOk = (setCalibrationResult == TangoExternal::TANGO_UNITY_3DR_SUCCESS);

#if UNITY_DEVELOPER_BUILD
                if (setCalibrationResult != TangoExternal::TANGO_UNITY_3DR_SUCCESS)
                {
                    ErrorStringMsg("Failed to set depth camera calibration with error code %d.",
                        (int)setCalibrationResult);
                }
#endif
            }
#if UNITY_DEVELOPER_BUILD
            else
            {
                ErrorStringMsg("Failed to get depth camera calibration with error code %d.",
                    (int)getCalibrationResult);
            }
#endif

            if (!isOk)
            {
                *statusOut = kCreationStatusFailedToSetDepthCalibration;
                reconstructionPlugin.Destroy(context);
                return nullptr;
            }
        }

        *statusOut = kCreationStatusOk;

        // All the possible ways to fail server creation have now passed.
        return UNITY_NEW(Server, kMemSpatialMapping)(self, config, context);
    }

    void Server::Shutdown()
    {
        if (m_GridIndicesChangedDelegate.GetHandler())
        {
            GlobalEventQueue::GetInstance().RemoveHandler(&m_GridIndicesChangedDelegate);
        }

        if (m_MeshSegmentProcessedDelegate.GetHandler())
        {
            GlobalEventQueue::GetInstance().RemoveHandler(&m_MeshSegmentProcessedDelegate);
        }
    }

    void Server::Destroy()
    {
        Shutdown();

        if (m_DestroyThreadedDelegate.GetHandler())
        {
            GlobalEventQueue::GetInstance().RemoveHandler(&m_DestroyThreadedDelegate);
        }

        m_ManagedHandle.ReleaseAndClear();

        // UNITY_DELETE will try to set thisPtr to NULL
        Server *thisPtr = this;
        UNITY_DELETE(thisPtr, kMemSpatialMapping);
    }

    void Server::GenerateSegmentAsync(
        const MeshReconstruction::GridIndex& gridIndex,
        MeshFilter* destinationMeshFilter,
        MeshCollider* destinationMeshCollider,
        ScriptingObjectPtr onSegmentReady,
        bool provideNormals,
        bool provideColors,
        bool providePhysics)
    {
        const SegmentInfoMap::iterator iter = m_MeshSegmentInfos.find(gridIndex);
        if (iter == m_MeshSegmentInfos.end())
        {
#if UNITY_DEVELOPER_BUILD
            ErrorStringMsg("Got request to generate unknown grid index (%d, %d, %d)",
                gridIndex.i,
                gridIndex.j,
                gridIndex.k);
#endif
            return;
        }

        GenerationQuery* generationQuery = ResourcePool<GenerationQuery>::GetInstance().Allocate();
        generationQuery->gridIndex = gridIndex;
        generationQuery->meshFilter = destinationMeshFilter;
        generationQuery->meshCollider = destinationMeshCollider;
        generationQuery->onDataReady.AcquireStrong(onSegmentReady);

        generationQuery->provideNormals = provideNormals;
        generationQuery->provideColors = provideColors;
        generationQuery->providePhysics = providePhysics;

        generationQuery->requestTime = GetTimeSinceStartup();
        generationQuery->context = this;

        ++m_NumSegmentsInFlight;

        ScheduleJob(generationQuery->jobFence, &ProcessExtractionJob, generationQuery);
    }

    void Server::ProcessExtractionJob(GenerationQuery* generationQuery)
    {
        Server* server = generationQuery->context;

        // Ask Tango to generate mesh segment
        GenerationResult* generationResult = server->ExtractPreallocatedMeshSegment(*generationQuery);

        // Generate physics data
        if (generationResult && generationQuery->providePhysics && generationResult->indices.size() >= 3)
        {
            const auto& vertices = generationResult->vertices;
            const auto& indices = generationResult->indices;
            AssertMsg(indices.size() % 3 == 0, "Number of indices must be a multiple of 3.");

            generationResult->physicsMesh = GetPhysicsManager().GetFastCooker().
                CookTriangleMeshAndInsertIntoPhysicsWorld(
                    vertices.data(), vertices.size(),
                    indices.data(), indices.size());
        }

        generationResult->elapsedTime = GetTimeSinceStartup() - generationQuery->requestTime;

        Server::SegmentProcessedEvent event = server->CreateEvent<Server::SegmentProcessedEvent>();
        event.result = generationResult;
        event.query = generationQuery;

        GlobalEventQueue::GetInstance().SendEvent(event);
    }

    void Server::GetChangedSegments(ScriptingObjectPtr onSegmentChanged)
    {
        // Run through all the segments and see which ones have changed since the last request
        for (auto& pair : m_MeshSegmentInfos)
        {
            const GridIndex& gridIndex = pair.first;
            SegmentInfo& info = pair.second;

            // New segment
            if (info.lastNotifyTime < 0)
            {
                InvokeOnSegmentChanged(onSegmentChanged, gridIndex, kSegmentChangeAdded, 0);
                info.lastNotifyTime = info.lastUpdateTime;
            }
            // Updated segment
            else if (info.lastUpdateTime > info.lastNotifyTime)
            {
                InvokeOnSegmentChanged(onSegmentChanged, gridIndex, kSegmentChangeUpdated, info.lastUpdateTime);
                info.lastNotifyTime = info.lastUpdateTime;
            }
        }
    }

    int Server::GetNumGenerationRequests() const
    {
        return m_NumSegmentsInFlight;
    }

    void Server::ClearReconstructedMeshes()
    {
        m_MeshSegmentInfos.clear();
        if (m_Context)
        {
            Tango3dReconstructionPlugin& plugin = Tango::GetTango3dReconstructionPlugin();
            plugin.Clear(m_Context);
        }
    }

    void Server::InvokeOnSegmentChanged(
        ScriptingObjectPtr onSegmentChanged,
        const GridIndex& gridIndex,
        SegmentChange changeType,
        double updateTime)
    {
        ScriptingInvocation invocation(GetARScriptingClasses().invokeSegmentChangedEvent);
        invocation.AddObject(onSegmentChanged);
        invocation.AddStruct((void*)&gridIndex);
        invocation.AddInt((int)changeType);
        invocation.AddDouble(updateTime);
        invocation.Invoke();
    }

    static void AddObjectToInvocation(ScriptingInvocation& invocation, Object* object)
    {
        if (object)
        {
            invocation.AddObject(
                Scripting::GetScriptingWrapperForInstanceID(object->GetInstanceID()));
        }
        else
        {
            invocation.AddNull();
        }
    }

    void Server::InvokeOnSegmentReady(const SegmentProcessedEvent& event)
    {
        GenerationQuery* generationQuery = event.query;
        GenerationResult* generationResult = event.result;

        ScriptingInvocation invocation(GetARScriptingClasses().invokeSegmentReadyEvent);
        invocation.AddObject(generationQuery->onDataReady.Resolve());
        invocation.AddStruct((void*)&generationQuery->gridIndex);
        AddObjectToInvocation(invocation, generationQuery->meshFilter);
        AddObjectToInvocation(invocation, generationQuery->meshCollider);
        invocation.AddBoolean(event.wasConsumed);
        invocation.AddDouble(generationResult->elapsedTime);
        invocation.Invoke();
    }

    // PhraseRecognizer::DestroyThreaded has some notes as to what this dance is about.
    void Server::DestroyThreaded()
    {
        ScriptingGCHandle strongGCHandle;

        if (m_ManagedHandle.HasTarget())
        {
            ScriptingObjectPtr managedObj = m_ManagedHandle.Resolve();
            strongGCHandle.AcquireStrong(managedObj);
        }

        DestroyThreadedEvent event = CreateEvent<DestroyThreadedEvent>();
        event.gcHandle = ScriptingGCHandle::ToScriptingBackendNativeGCHandle(strongGCHandle);

        GlobalEventQueue::GetInstance().SendEvent(event);
    }

    void Server::HandleEvent(const DestroyThreadedEvent& event)
    {
        if (IsEventTargetSelf(event))
        {
            Destroy();
        }
    }

    void Server::HandleEvent(SegmentProcessedEvent& event)
    {
        // This is the Tango version of SpatialMappingSystem::PropagateDataEvent

        if (IsEventTargetSelf(event))
        {
            GenerationQuery* generationQuery = event.query;
            GenerationResult* generationResult = event.result;

            if (m_NumSegmentsInFlight > 0)
            {
                --m_NumSegmentsInFlight;
            }
            else
            {
#if UNITY_DEVELOPER_BUILD
                ErrorStringMsg("Received SegmentProcessedEvent but m_NumSegmentsInFlight is %d",
                    m_NumSegmentsInFlight);
#endif
            }

            SyncFence(generationQuery->jobFence);

            if (generationResult)
            {
                if (generationQuery->meshFilter.IsValid() &&
                    (!generationQuery->providePhysics || generationQuery->meshCollider.IsValid()))
                {
                    const double startTime = GetTimeSinceStartup();

                    Mesh* mesh = generationQuery->meshFilter->GetInstantiatedMesh();

                    mesh->MarkDynamic();
                    mesh->Clear(false);
                    mesh->SetVertices(generationResult->vertices.begin(), generationResult->vertices.size());
                    mesh->SetIndices(generationResult->indices.begin(), generationResult->indices.size(), 0, kPrimitiveTriangles);

                    if (generationQuery->provideNormals)
                    {
                        mesh->SetNormals(generationResult->normals.begin(), generationResult->normals.size());
                    }

                    if (generationQuery->provideColors)
                    {
                        mesh->SetColors(generationResult->colors.begin(), generationResult->colors.size());
                    }

                    // Release existing physics mesh
                    if (mesh->m_CollisionMesh.m_NxTriangleMesh != nullptr)
                    {
                        GetIPhysics()->ReleaseNxTriangleMesh(
                            reinterpret_cast<PhysicsModuleMesh*>(mesh->m_CollisionMesh.m_NxTriangleMesh));
                    }

                    mesh->m_CollisionMesh.m_NxTriangleMesh = reinterpret_cast<PhysicsModuleMesh*>(generationResult->physicsMesh);
                    mesh->m_CollisionMesh.m_SharedPhysicsMeshDirty = false;

                    if (generationQuery->providePhysics && generationQuery->meshCollider.IsValid())
                    {
                        generationQuery->meshCollider->SetSharedMesh(mesh);
                    }

                    event.wasConsumed = true;

                    const double elapsedTime = GetTimeSinceStartup() - startTime;
                    generationResult->elapsedTime += elapsedTime;
                }
            }

            InvokeOnSegmentReady(event);
        }
    }

    template<typename T>
    static inline void RemapVertexData(const dynamic_array<UInt32>& newToOldVertexMap, T* vertexData)
    {
        const UInt32 newSize = newToOldVertexMap.size();
        dynamic_array<T> remappedData(newSize, kMemTempAlloc);
        for (UInt32 newIndex = 0; newIndex < newSize; ++newIndex)
        {
            const UInt32 oldIndex = newToOldVertexMap[newIndex];
            remappedData[newIndex] = vertexData[oldIndex];
        }
        std::copy(remappedData.begin(), remappedData.end(), vertexData);
    }

    GenerationResult* Server::ExtractPreallocatedMeshSegment(const GenerationQuery& generationQuery)
    {
        PROFILER_AUTO(gExtractPreallocatedMeshSegment, NULL);

        Tango3dReconstructionPlugin& plugin = Tango::GetTango3dReconstructionPlugin();

        GenerationResult* mesh = ResourcePool<GenerationResult>::GetInstance().Allocate();

        TangoExternal::TangoUnity3DR_Mesh tangoMesh;
        TangoExternal::TangoUnity3DR_Status extractionStatus;

        do
        {
            memset(&tangoMesh, 0, sizeof(TangoExternal::TangoUnity3DR_Mesh));

            tangoMesh.max_num_faces = mesh->indices.capacity() / 3;
            tangoMesh.faces = reinterpret_cast<TangoExternal::TangoUnity3DR_Face*>(mesh->indices.data());
            tangoMesh.max_num_vertices = mesh->vertices.capacity();
            tangoMesh.vertices = reinterpret_cast<TangoExternal::TangoUnity3DR_Vector3*>(mesh->vertices.data());

            if (generationQuery.provideNormals)
            {
                tangoMesh.normals = reinterpret_cast<TangoExternal::TangoUnity3DR_Vector3*>(mesh->normals.data());
            }

            if (generationQuery.provideColors)
            {
                tangoMesh.colors = reinterpret_cast<TangoExternal::TangoUnity3DR_Color*>(mesh->colors.data());
            }

            extractionStatus = plugin.ExtractPreallocatedMeshSegment(
                    m_Context,
                    generationQuery.gridIndex.indices,
                    &tangoMesh);

            if (extractionStatus == TangoExternal::TANGO_UNITY_3DR_INSUFFICIENT_SPACE)
            {
                mesh->indices.reserve(mesh->indices.capacity() * 3 / 2);
                mesh->vertices.reserve(mesh->vertices.capacity() * 3 / 2);
                mesh->normals.reserve(mesh->vertices.capacity());
                mesh->colors.reserve(mesh->vertices.capacity());
                // TODO: textureCoords
            }
        }
        while (extractionStatus == TangoExternal::TANGO_UNITY_3DR_INSUFFICIENT_SPACE);

        if (extractionStatus == TangoExternal::TANGO_UNITY_3DR_SUCCESS)
        {
            mesh->indices.resize_uninitialized(tangoMesh.num_faces * 3);

            // Tango often generates "orphaned" vertices, vertices that do not
            // belong to any triangle. This can cause problems so remap if necessary.
            PROFILER_BEGIN(gCheckForOrphanedVertices, NULL);

            dynamic_array<bool> isVertexUsed(tangoMesh.num_vertices, false, kMemTempAlloc);
            for (UInt32 i = 0; i < mesh->indices.size(); ++i)
            {
                const UInt32 vertexIndex = mesh->indices[i];
                isVertexUsed[vertexIndex] = true;
            }

            dynamic_array<UInt32> newToOldVertexMap(tangoMesh.num_vertices, kMemTempAlloc);
            dynamic_array<UInt32> oldToNewVertexMap(tangoMesh.num_vertices, kMemTempAlloc);
            UInt32 newIndex = 0;
            for (UInt32 oldIndex = 0; oldIndex < isVertexUsed.size(); ++oldIndex)
            {
                // Most vertices will be used, so hint that this is
                // a likely path.
                if (OPTIMIZER_LIKELY(isVertexUsed[oldIndex]))
                {
                    oldToNewVertexMap[oldIndex] = newIndex;
                    newToOldVertexMap[newIndex] = oldIndex;
                    ++newIndex;
                }
            }

            PROFILER_END(gCheckForOrphanedVertices);

            const UInt32 numUsedVertices = newIndex;

            if (numUsedVertices < tangoMesh.num_vertices)
            {
                PROFILER_AUTO(gRemapVertices, NULL);

                newToOldVertexMap.resize_uninitialized(numUsedVertices);

                RemapVertexData(newToOldVertexMap, mesh->vertices.begin());

                if (generationQuery.provideNormals)
                    RemapVertexData(newToOldVertexMap, mesh->normals.begin());

                if (generationQuery.provideColors)
                    RemapVertexData(newToOldVertexMap, mesh->colors.begin());

                // Finally, fix up the indices to point to the new values
                for (UInt32 i = 0; i < mesh->indices.size(); ++i)
                {
                    const UInt32 oldIndex = mesh->indices[i];
                    const UInt32 newIndex = oldToNewVertexMap[oldIndex];

                    mesh->indices[i] = newIndex;
                }
            }

            // Shrink original array
            mesh->vertices.resize_uninitialized(numUsedVertices);

            if (generationQuery.provideNormals)
            {
                mesh->normals.resize_uninitialized(numUsedVertices);

                PROFILER_AUTO(gTransformNormals, NULL);

                // Transform normals
                for (UInt32 i = 0; i < mesh->normals.size(); ++i)
                {
                    const math::float3 oldNormal = math::vload3f(mesh->normals[i].GetPtr());
                    const math::float3 newNormal = math::mul(s_TangoToUnity, oldNormal);
                    math::vstore3f(mesh->normals[i].GetPtr(), newNormal);
                }
            }

            if (generationQuery.provideColors)
                mesh->colors.resize_uninitialized(numUsedVertices);
        }

        return mesh;
    }

    void Server::HandleEvent(const GridIndicesChangedEvent& event)
    {
        if (IsEventTargetSelf(event))
        {
            const TangoExternal::TangoUnity3DR_GridIndexArray& gridIndexArray = event.updatedGridIndexArray;
            const GridIndex* gridIndex = reinterpret_cast<const GridIndex*>(gridIndexArray.indices);

            if (gridIndex)
            {
                const GridIndex* last = gridIndex + gridIndexArray.num_indices;

                while (gridIndex < last)
                {
                    SegmentInfo& info = m_MeshSegmentInfos[*gridIndex];
                    info.lastUpdateTime = event.timestamp;

                    ++gridIndex;
                }
            }
#if UNITY_DEVELOPER_BUILD
            else
            {
                ErrorString("Null grid index array found");
            }
#endif
        }
    }

    bool Server::IsEventTargetSelf(const EventBase& event) const
    {
        return (event.context == this && event.subscriberId == m_EventSubscriberId);
    }

    // Extract the changed indices and push them into the event queue for later processing.
    void Server::Update(
        const TangoExternal::TangoPointCloud& pointCloud,
        const TangoExternal::TangoPoseData& pointCloudPose,
        const TangoExternal::TangoImage* image,
        const TangoExternal::TangoPoseData* imagePose) const
    {
        Tango3dReconstructionPlugin& reconstructionPlugin =
            Tango::GetTango3dReconstructionPlugin();

        // It is an error to pass image information if the context does not support it.
        if (!m_Config.generateColor)
        {
            image = nullptr;
            imagePose = nullptr;
        }

        TangoExternal::TangoUnity3DR_GridIndexArray updatedGridIndexArray;
        memset(&updatedGridIndexArray, 0, sizeof(TangoExternal::TangoUnity3DR_GridIndexArray));
        {
            PROFILER_AUTO(gTango3drUpdate, NULL);

            const TangoExternal::TangoUnity3DR_Status updateStatus =
                reconstructionPlugin.Update(
                    m_Context,
                    &pointCloud,
                    &pointCloudPose,
                    image,
                    imagePose,
                    &updatedGridIndexArray);

            if (updateStatus != TangoExternal::TANGO_UNITY_3DR_SUCCESS)
            {
#if UNITY_DEVELOPER_BUILD
                ErrorStringMsg("TangoUnity3DR_update failed with error code %d",
                    (int)updateStatus);
#endif
                return;
            }
        }

        GridIndicesChangedEvent event = CreateEvent<GridIndicesChangedEvent>();
        event.updatedGridIndexArray = updatedGridIndexArray;
        event.timestamp = GetTimeSinceStartup();

        GlobalEventQueue::GetInstance().SendEvent(event);
    }

    void Server::GridIndicesChangedEvent::Destroy()
    {
        Tango3dReconstructionPlugin& reconstructionPlugin =
            Tango::GetTango3dReconstructionPlugin();

        reconstructionPlugin.GridIndexArray_destroy(&updatedGridIndexArray);
    }

    void Server::SegmentProcessedEvent::Destroy()
    {
        if (query)
        {
            query->Reset();
        }

        if (result)
        {
            const bool releasePhysicsData = !wasConsumed;
            result->Reset(releasePhysicsData);
        }
    }
} // namespace MeshReconstruction
} // namespace Tango

#endif
