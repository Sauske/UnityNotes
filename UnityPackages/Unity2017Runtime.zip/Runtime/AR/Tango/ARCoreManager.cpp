#include "UnityPrefix.h"

#if PLATFORM_ANDROID

#include "ARCoreManager.h"
#include "Runtime/AR/ARTypes.h"
#include "Runtime/GfxDevice/opengles/ApiConstantsGLES.h"
#include "Runtime/GfxDevice/opengles/ApiGLES.h"
#include "Runtime/Core/Callbacks/PlayerLoopCallbacks.h"
#include "Runtime/GfxDevice/GfxDevice.h"
#include "Runtime/Threads/Thread.h"

namespace ARCore
{
    RuntimeStatic<ARCoreManager> ARCoreManager::s_Instance(kMemDefault);

    ARCoreManager::ARCoreManager()
        : m_IsInitialied(false)
        , m_GLARTextureId(GL_NONE)
    {
        ASSERT_RUNNING_ON_MAIN_THREAD;
        REGISTER_PLAYERLOOP_CALL(EarlyUpdate, TangoUpdate, ARCoreManager::GetInstance()->FireEarlyUpdate());
    }

    ARCoreManager::~ARCoreManager()
    {
        ASSERT_RUNNING_ON_MAIN_THREAD;
        UNREGISTER_PLAYERLOOP_CALL(EarlyUpdate, TangoUpdate);
        m_IsInitialied = false;

        if (m_GLARTextureId != GL_NONE)
        {
            GetGfxDevice().InsertCustomMarkerCallback(&ARCoreManager::DeleteExternalTextureCallback,
                static_cast<int>(m_GLARTextureId));
            m_GLARTextureId = GL_NONE;
        }
    }

    bool ARCoreManager::Initialize(JavaVM* javaVM, jobject unityActivity)
    {
        if (m_IsInitialied)
        {
            return true;
        }

        if (!::LoadARCoreUnityPlugin(&g_ARCoreUnityPlugin, javaVM, unityActivity))
        {
            return false;
        }

        m_IsInitialied = true;
        return true;
    }

    void ARCoreManager::FireOnPause()
    {
        if (m_IsInitialied)
        {
            g_ARCoreUnityPlugin.OnPlayerPause();
        }
    }

    void ARCoreManager::FireOnResume()
    {
        if (m_IsInitialied)
        {
            g_ARCoreUnityPlugin.OnPlayerResume();
        }
    }

    void ARCoreManager::FireEarlyUpdate()
    {
        if (!m_IsInitialied)
        {
            return;
        }

        g_ARCoreUnityPlugin.OnEarlyUpdate();

        if (m_GLARTextureId == GL_NONE && !CreateExternalTexture())
        {
            return;
        }

        g_ARCoreUnityPlugin.OnBeforeRenderARBackground(static_cast<int>(m_GLARTextureId));
    }

    bool ARCoreManager::GetPose(Tango::PoseData* outPose) const
    {
        if (!m_IsInitialied)
        {
            return false;
        }

        float translation[3];
        float orientation[4];
        ARCoreExternal::ArCoreUnityDataStatus status;

        g_ARCoreUnityPlugin.GetPose(translation, orientation, &status);

        if (status != ARCoreExternal::ARCORE_UNITY_DATA_AVAILABLE)
            return false;

        outPose->translation_x = translation[0];
        outPose->translation_y = translation[1];
        outPose->translation_z = translation[2];

        outPose->orientation_x = orientation[0];
        outPose->orientation_y = orientation[1];
        outPose->orientation_z = orientation[2];
        outPose->orientation_w = orientation[3];

        return true;
    }

    bool ARCoreManager::IsRunning() const
    {
        return m_IsInitialied;
    }

    bool ARCoreManager::CreateExternalTexture()
    {
        GfxDevice& device = GetGfxDevice();
        device.InsertCustomMarkerCallback(&ARCoreManager::CreateExternalTextureCallback, 0);

        // We need to block until the graphics thread completes the callback
        device.WaitOnCPUFence(device.InsertCPUFence());

        if (m_GLARTextureId == GL_NONE)
        {
            ErrorString("ARCoreManager::CreateExternalTexture() failed.");
            return false;
        }

        return true;
    }

    void UNITY_INTERFACE_API ARCoreManager::CreateExternalTextureCallback(const int id)
    {
        s_Instance->m_GLARTextureId = gGL->GenTexture(GL_TEXTURE_EXTERNAL_OES);
    }

    void UNITY_INTERFACE_API ARCoreManager::DeleteExternalTextureCallback(const int textureId)
    {
        GLuint glTexId = static_cast<GLuint>(textureId);
        gGL->DeleteTexture(glTexId);
    }
} // namespace ARCore

#endif
