#pragma once

#include "TangoTypes.h"
#include "Runtime/AR/ARTypes.h"
#include "Runtime/Core/Containers/hash_map.h"
#include "Runtime/Core/Containers/String.h"
#include "Runtime/Graphics/Mesh/MeshFilter.h"
#include "Runtime/Graphics/ScreenManager.h"
#include "Runtime/Dynamics/MeshCollider.h"
#include "Runtime/Scripting/ScriptingTypes.h"
#include "Runtime/Scripting/BindingsDefs.h"
#include "Runtime/Shaders/Material.h"
#include <vector>

namespace Tango
{
    // Must match UnityEngine.XR.Tango.Image.PlaneInfo
    struct ImagePlaneInfo
    {
        SInt32 size;
        SInt32 rowStride;
        SInt32 pixelStride;
        UInt32 offset;
    };

    struct DeviceScriptApi
    {
        static CoordinateFrame GetBaseCoordinateFrame();
        static void SetBaseCoordinateFrame(CoordinateFrame frame, ScriptingExceptionPtr* exception);

        // Use of std::vector due to limitation in script bindings generator
        // "We cannot marshal string[] to dynamic_array<core::string> yet"
        static bool Connect(
            const std::vector<core::string>& boolKeys, const dynamic_array<bool>& boolValues,
            const std::vector<core::string>& intKeys, const dynamic_array<int>& intValues,
            const std::vector<core::string>& longKeys, const dynamic_array<SInt64>& longValues,
            const std::vector<core::string>& doubleKeys, const dynamic_array<double>& doubleValues,
            const std::vector<core::string>& stringKeys, const std::vector<core::string>& stringValues);
        static void Disconnect();
        static bool TryGetHorizontalFov(float* fovOut);
        static bool TryGetVerticalFov(float* fovOut);
        static void SetRenderMode(ARRenderMode mode);
        static unsigned int GetDepthCameraRate();
        static void SetDepthCameraRate(unsigned int value);
        static bool GetSynchronizeFramerateWithColorCamera();
        static void SetSynchronizeFramerateWithColorCamera(bool value);
        static void SetBackgroundMaterial(Material* material);
        static bool TryGetLatestPointCloudInternal(
            ScriptingObjectPtr pointCloudData,
            UInt32* version,
            double* timestamp);

        static bool TryGetLatestImageDataInternal(
            ScriptingObjectPtr imageDataOut,
            ScriptingObjectPtr planeInfosOut,
            UInt32* widthOut,
            UInt32* heightOut,
            SInt32* formatOut,
            SInt64* timestampNsOut,
            CameraMetadata& metadataOut);

        static bool GetIsServiceConnected();
        static bool GetIsServiceAvailable();

        static bool Internal_TryAcquireLatestPointCloud(
            UInt32* versionOut,
            double* timestampOut,
            UInt32* numPointsOut,
            void** pointsOut,
            void** nativePtrOut);

        static bool Internal_TryAcquireLatestImageBuffer(
            ScriptingObjectPtr planeInfosOut,
            UInt32* widthOut,
            UInt32* heightOut,
            int* formatOut,
            SInt64* timestampOut,
            void** planeDataOut,
            void** nativePtrOut,
            CameraMetadata& metadataOut);

        static void Internal_ReleasePointCloud(void* ptr, ScriptingExceptionPtr* exception);
        static void Internal_ReleaseImageBuffer(void* ptr, ScriptingExceptionPtr* exception);

    private:

        typedef core::hash_map<void*, UInt32> PointerToLockcountMap;
        static PointerToLockcountMap s_PointClouds;
        static PointerToLockcountMap s_ImageBuffers;

        // Specializations in cpp
        template<typename T> static PointerToLockcountMap& GetPointerToLockcountMap();

        // Implementation in cpp because all possible specializations are invoked there.
        template<typename T> static void ReleaseBuffer(void* ptr, ScriptingExceptionPtr* exception);
        template<typename T> static T* AcquireLatestBuffer();
    };

    struct InputTrackingScriptApi
    {
        static bool Internal_TryGetPoseAtTime(
            double time,
            ScreenOrientation screenOrientation,
            CoordinateFrame baseFrame,
            CoordinateFrame targetFrame,
            PoseData& pose);
    };

    struct ServerScriptApi
    {
        static void Internal_ClearMeshes(void* server);
        static bool Internal_GetEnabled(void* server);
        static void Internal_SetEnabled(void* server, bool enabled);
        static void* Internal_GetNativeReconstructionContextPtr(void* server);
        static int Internal_GetNumGenerationRequests(void* server);
        static void* Internal_Create(
            ScriptingObjectPtr self,
            const MeshReconstruction::Config& config,
            int* statusOut);
        static void Destroy(void* server);
        static void DestroyThreaded(void* server);
        static void Internal_GetChangedSegments(void* server, ScriptingObjectPtr onSegmentChanged);
        static void Internal_GenerateSegmentAsync(
            void* server,
            const MeshReconstruction::GridIndex& gridIndex,
            MeshFilter* destinationMeshFilter,
            MeshCollider* destinationMeshCollider,
            ScriptingObjectPtr onSegmentReady,
            bool provideNormals,
            bool provideColors,
            bool providePhysics);
    };
}

BIND_MANAGED_TYPE_NAME(Tango::DeviceScriptApi, UnityEngine_XR_Tango_TangoDevice);
BIND_MANAGED_TYPE_NAME(Tango::InputTrackingScriptApi, UnityEngine_XR_Tango_TangoInputTracking);
BIND_MANAGED_TYPE_NAME(Tango::ServerScriptApi, UnityEngine_XR_Tango_MeshReconstructionServer);
BIND_MANAGED_TYPE_NAME(Tango::ImagePlaneInfo, UnityEngine_XR_Tango_ImageData_PlaneInfo);
