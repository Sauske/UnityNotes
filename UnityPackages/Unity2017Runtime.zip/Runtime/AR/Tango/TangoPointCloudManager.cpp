#include "UnityPrefix.h"

#if PLATFORM_ANDROID

#include "TangoPointCloudManager.h"
#include "Runtime/Allocator/MemoryMacros.h"

namespace Tango
{
    static inline UInt32 ComputeDataSizeFromNumPoints(UInt32 numPointCloudElements)
    {
        return numPointCloudElements * sizeof(float) * 4;
    }

    template<>
    UInt32 BufferManager<TangoExternal::TangoPointCloud>::ComputeDataSize(const TangoExternal::TangoPointCloud* pointCloud)
    {
        return ComputeDataSizeFromNumPoints(pointCloud->num_points);
    }

    template<>
    void* BufferManager<TangoExternal::TangoPointCloud>::GetDataPtr(TangoExternal::TangoPointCloud* pointCloud)
    {
        return pointCloud->points;
    }

    template<>
    const void* BufferManager<TangoExternal::TangoPointCloud>::GetDataPtr(const TangoExternal::TangoPointCloud* pointCloud)
    {
        return pointCloud->points;
    }

    template<>
    void BufferManager<TangoExternal::TangoPointCloud>::SetDataPtr(TangoExternal::TangoPointCloud* pointCloud, void* data)
    {
        pointCloud->points = static_cast<float(*)[4]>(data);
    }

    PointCloudManager::PointCloudManager(int maxPointCloudElements, UInt32 numConsumers, MemLabelId memoryLabel)
        : BufferManager(numConsumers, memoryLabel)
        , m_MaxPointCloudElements(maxPointCloudElements)
    {
        const UInt32 numBytes = ComputeDataSizeFromNumPoints(m_MaxPointCloudElements);
        for (auto& pointCloud : m_Storage)
        {
            pointCloud.points = static_cast<float(*)[4]>(UNITY_MALLOC(m_MemoryLabel, numBytes));
        }
    }

    void PointCloudManager::CopyBuffer(
        TangoExternal::TangoPointCloud* destinationBuffer,
        const TangoExternal::TangoPointCloud* sourceBuffer)
    {
        const UInt32 sourceSize = ComputeDataSize(sourceBuffer);
        const UInt32 destinationSize = ComputeDataSizeFromNumPoints(m_MaxPointCloudElements);

        CopyMetadata(destinationBuffer, sourceBuffer);

        if (destinationSize < sourceSize)
        {
            m_MaxPointCloudElements = sourceBuffer->num_points;

#if DEBUGMODE
            ErrorStringMsg("Buffer size too small: %u < %u. Reallocating.",
                destinationSize, sourceSize);
#endif

            // Reallocate
            UNITY_FREE(m_MemoryLabel, destinationBuffer->points);
            const UInt32 numBytes = ComputeDataSize(destinationBuffer);
            destinationBuffer->points = static_cast<float(*)[4]>(UNITY_MALLOC(m_MemoryLabel, numBytes));
        }

        // Now make a copy of the actual data
        UNITY_MEMCPY(destinationBuffer->points, sourceBuffer->points, sourceSize);
    }

    template<>
    bool BufferManager<TangoExternal::TangoPointCloud>::IsTimestampGreaterThanZero(
        const TangoExternal::TangoPointCloud& pointCloud)
    {
        return pointCloud.timestamp > 0.0;
    }

    template<>
    bool BufferManager<TangoExternal::TangoPointCloud>::IsTimestampGreaterThan(
        const TangoExternal::TangoPointCloud& lhs,
        const TangoExternal::TangoPointCloud& rhs)
    {
        return lhs.timestamp > rhs.timestamp;
    }
} // namespace Tango

#endif
