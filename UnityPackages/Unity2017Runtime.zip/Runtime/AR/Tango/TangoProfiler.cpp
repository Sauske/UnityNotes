#include "UnityPrefix.h"

#if PLATFORM_ANDROID
#include "TangoProfiler.h"

namespace Tango
{
    Profiler::Profiler()
        : m_CurrentFrame(-1)
        , m_NextFrame(-1)
        , m_IsInitialized(false)
    {}

    Profiler::~Profiler()
    {
        AssertMsg(Thread::EqualsCurrentThreadIDForAssert(m_ThreadId) || !m_IsInitialized,
            "Deleting a Tango Profiler from a thread other than it was initialized from.");

        if (m_IsInitialized)
            Shutdown();
    }

#if ENABLE_PROFILER

    void Profiler::OnProfilerFrameChanged(UInt32 frameIndex, void* context)
    {
        Profiler* this_ = static_cast<Profiler*>(context);
        this_->m_NextFrame = static_cast<int>(frameIndex);
    }

    void Profiler::Update()
    {
        const int nextFrame = m_NextFrame;

        if (m_CurrentFrame != nextFrame)
        {
            if (m_CurrentFrame != -1)
            {
                // End the previous frame
                profiler_set_active_separate_thread(false);
                profiler_end_frame_separate_thread(nextFrame);
            }

            // Begin next frame
            m_CurrentFrame = nextFrame;
            profiler_start_new_frame_separate_thread(nextFrame);
            profiler_set_active_separate_thread(true);
        }
    }

    void Profiler::Initialize(const char* groupname, const char* name)
    {
        AssertMsg(m_IsInitialized == false, "Trying to initialize the Tango profiler twice.");

        m_CurrentFrame = m_NextFrame = -1;
        m_IsInitialized = true;
        m_ThreadId = Thread::GetCurrentThreadID();

        profiler_initialize_thread(groupname, name, Profiler::OnProfilerFrameChanged, this);
    }

    void Profiler::EnsureInitialized(const char* groupname, const char* name)
    {
        if (!m_IsInitialized)
        {
            Initialize(groupname, name);
        }
    }

    void Profiler::Shutdown()
    {
        AssertMsg(m_IsInitialized == true, "Trying to shutdown the Tango profiler before it is initialized.");
        AssertMsg(Thread::EqualsCurrentThreadIDForAssert(m_ThreadId), "Binder thread must be shutdown on same thread as it was initialized.");

        if (Thread::EqualsCurrentThreadID(m_ThreadId))
        {
            m_CurrentFrame = m_NextFrame = -1;
            m_IsInitialized = false;

            profiler_cleanup_thread();
        }
    }

#else

    void Profiler::OnProfilerFrameChanged(UInt32 frameIndex, void* context) {}
    void Profiler::Update() {}
    void Profiler::Initialize(const char* groupname, const char* name) {}
    void Profiler::EnsureInitialized(const char* groupname, const char* name) {}
    void Profiler::Shutdown() {}

#endif
} // namespace Tango
#endif
