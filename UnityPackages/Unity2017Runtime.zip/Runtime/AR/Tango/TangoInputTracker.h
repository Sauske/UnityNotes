#pragma once
#if ENABLE_NEW_INPUT_SYSTEM

#include "TangoTypes.h"
#include "Modules/Input/InputDeviceData.h"
#include "Runtime/Utilities/dynamic_array.h"

struct InputDeviceDescriptor;

namespace Tango
{
    class InputTracker
    {
    public:

        InputTracker();

        void Open();
        void Close();

        bool SetBaseCoordinateFrame(CoordinateFrame baseFrame);
        CoordinateFrame GetBaseCoordinateFrame() const { return m_BaseFrame; }

    private:

        InputDeviceID m_InputDeviceId;

        // A bit for each possible CoordinateFrame indicating whether
        // tracking is acquired (1) or lost (0).
        UInt32 m_TrackingStatesBitfield;

        CoordinateFrame m_BaseFrame;

        void ReportNewDeviceOrReconnect(InputDeviceID& deviceId, const InputDeviceDescriptor& deviceDescriptor);
    };
} // namespace Tango

#endif // ENABLE_NEW_INPUT_SYSTEM
