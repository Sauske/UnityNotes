#pragma  once

#if PLATFORM_ANDROID

#include "TangoTypes.h"
#include "Runtime/Utilities/HashFunctions.h"

namespace Tango
{
namespace MeshReconstruction
{
    struct GridIndexHasher
    {
        std::size_t operator()(const GridIndex& gridIndex) const
        {
            return ComputeHash32(&gridIndex, sizeof(GridIndex));
        }
    };

// A grid index is a triple of ints
    inline bool operator==(const GridIndex& a, const GridIndex& b)
    {
        return
            a.i == b.i &&
            a.j == b.j &&
            a.k == b.k;
    }
} // namespace MeshReconstruction
} // namespace Tango

#endif
