#pragma once

#include "Runtime/PluginInterface/PluginInterface.h"
#include "Runtime/Utilities/RuntimeStatic.h"
#include "External/Tango/builds/gen/ApiFuncARCoreUnity.h"
#include "Runtime/GfxDevice/opengles/ApiTypeGLES.h"
#include "Runtime/AR/Tango/TangoTypes.h"

//
// Manages the arcore plugin.
//

namespace ARCore
{
    class ARCoreManager
    {
    public:
        ARCoreManager();
        ~ARCoreManager();
        bool Initialize(JavaVM* javaVM, jobject unityActivity);
        void FireOnPause();
        void FireOnResume();
        void FireEarlyUpdate();
        bool GetPose(Tango::PoseData* outPose) const;
        bool IsRunning() const;
        static ARCoreManager* GetInstance() { return s_Instance; }

    private:
        bool CreateExternalTexture();
        static void UNITY_INTERFACE_API CreateExternalTextureCallback(const int id);
        static void UNITY_INTERFACE_API DeleteExternalTextureCallback(const int textureId);

        bool m_IsInitialied;
        GLuint m_GLARTextureId;
        ARCoreUnityPlugin g_ARCoreUnityPlugin;
        static RuntimeStatic<ARCoreManager> s_Instance;
    };
} // namespace ARCore
