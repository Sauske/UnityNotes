#pragma once

#include "TangoSupport.h"
#include "Runtime/GfxDevice/opengles/ApiTypeGLES.h"

class Camera;
class Texture2D;
class Material;

namespace Tango
{
//
// Class to assist with full-screen AR rendering to Tango devices
//
    class ARRendering
    {
        friend class Device;

    public:
        ARRendering();

        ~ARRendering();

        bool Initialize();

        GLuint GetARTextureId() const;

        double GetLastCameraImageTimestamp() const;

        bool IsLastCameraImageTimestampValid() const
        { return m_LastCameraImageTimestamp != kUninitialized; }

        // Called by the OnTextureAvailable() callback to actually update the GL texture by calling a Tango API to do so.
        // There is also some initialization here that is called after the first call to the Tango API since we need a valid
        // GL texture before it can be completed.
        static void UpdateExternalTextureCallback(const int textureId);

        static ARRendering* GetInstance() { return s_Instance; }

    private:

        void Shutdown();

        // Called during initialization to set up the GL and Unity AR texture resources
        bool SetupARTexture();

        // Called from the callback handler for texture update in order to set shader parameters on the background material
        bool SetupARMaterial();

        void SetBackgroundMaterial(Material *backgroundMaterial);

        Material* GetBackgroundMaterial() const;

        // Called during initialization to setup the callback function for color camera texture updates
        bool SetupTangoCamera();

        static void UNITY_INTERFACE_API CreateExternalTextureCallback(const int id);

        // Called from the graphics thread to destroy GL texture
        static void UNITY_INTERFACE_API DeleteExternalTextureCallback(const int textureId);

        Texture2D* m_UnityARTexture;

        GLuint m_GLARTextureId;

        bool m_Initialized;

        bool m_ExternalTextureUpdatedOnce;

        double m_LastCameraImageTimestamp;

        Material *m_BackgroundMaterial;

        static ARRendering* s_Instance;

        static constexpr float kUninitialized = -1.f;
    };
} // namespace Tango
