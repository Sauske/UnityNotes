#include "UnityPrefix.h"

#if PLATFORM_ANDROID

#include "TangoDevice.h"
#include "TangoEngineCallbackHandler.h"
#include "TangoARRendering.h"
#include "Runtime/AR/ARTypes.h"
#include "Runtime/Core/Callbacks/PlayerLoopCallbacks.h"
#include "Runtime/GfxDevice/GfxDevice.h"
#include "Runtime/Threads/Thread.h"

namespace Tango
{
    RuntimeStatic<EngineCallbackHandler> EngineCallbackHandler::s_Instance(kMemDefault);

    EngineCallbackHandler::EngineCallbackHandler()
        : m_IsRegistered(false)
    {
        // Wait until we're connected to Tango to register for callbacks.
    }

    EngineCallbackHandler::~EngineCallbackHandler()
    {
        UnregisterUpdateLoop();
    }

    void EngineCallbackHandler::RegisterUpdateLoop()
    {
        ASSERT_RUNNING_ON_MAIN_THREAD;

        if (m_IsRegistered == false)
        {
            REGISTER_PLAYERLOOP_CALL(FrameEvents, TangoBeginFrame, EngineCallbackHandler::GetInstance()->BeforeRendering());
        }

        m_IsRegistered = true;
    }

    void EngineCallbackHandler::UnregisterUpdateLoop()
    {
        ASSERT_RUNNING_ON_MAIN_THREAD;

        if (m_IsRegistered)
        {
            UNREGISTER_PLAYERLOOP_CALL(FrameEvents, TangoBeginFrame);
        }

        m_IsRegistered = false;
    }

    void EngineCallbackHandler::OnTextureAvailable(TangoExternal::TangoCameraId cameraId)
    {
        m_CameraImageReady.Signal();
    }

    void EngineCallbackHandler::BeforeRendering()
    {
        Device* tangoDevice = Device::GetInstance();

        if (tangoDevice->GetRenderMode() == kRenderModeMaterialAsBackground)
        {
            // We are throttled by Tango's camera update frequency when rendering in AR
            if (tangoDevice->GetSynchronizeFramerateWithColorCamera())
            {
                m_CameraImageReady.WaitForSignal();
            }

            GetGfxDevice().InsertCustomMarkerCallback(
                &ARRendering::UpdateExternalTextureCallback,
                static_cast<int>(tangoDevice->GetARTextureId()));
        }
    }
} // namespace Tango

#endif
