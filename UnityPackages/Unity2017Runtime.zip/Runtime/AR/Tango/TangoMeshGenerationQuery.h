#pragma once

#if PLATFORM_ANDROID

#include "TangoTypes.h"
#include "Runtime/BaseClasses/PPtr.h"
#include "Runtime/Dynamics/MeshCollider.h"
#include "Runtime/Graphics/Mesh/MeshFilter.h"
#include "Runtime/Scripting/ScriptingTypes.h"
#include "Runtime/Jobs/JobTypes.h"

namespace Tango
{
namespace MeshReconstruction
{
    class Server;

    // Mirror struct to TangoMeshGenerationRequest
    struct GenerationQuery
    {
        void Reset();

        GridIndex gridIndex;
        PPtr<MeshFilter> meshFilter;
        PPtr<MeshCollider> meshCollider;
        ScriptingGCHandle onDataReady;

        bool provideNormals;
        bool provideColors;
        bool providePhysics;

        Server* context;
        JobFence jobFence;
        double requestTime;
    };
} // namespace MeshReconstruction
} // namespace Tango

#endif
