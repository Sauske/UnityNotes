using JamSharp.Runtime;
using static JamSharp.Runtime.BuiltinRules;
using External.Jamplus.builds.bin.modules;
using External.Jamplus.builds.bin;

namespace Runtime.AR
{
    [OriginalJamFile("Runtime/AR/ARModule.jam")]
    class ARModule : ConvertedJamFile
    {
        internal static void TopLevel()
        {
            RegisterRuleWithReturnValue("ARModule_ReportCpp", ARModule_ReportCpp);
            RegisterRuleWithReturnValue("ARModule_ReportCs", ARModule_ReportCs);
            RegisterRuleWithReturnValue("ARModule_ReportIncludes", ARModule_ReportIncludes);
            RegisterRuleWithReturnValue("ARModule_ReportDependencies", ARModule_ReportDependencies);
            RegisterRule("ARModule_ReportPrebuiltLibraries", ARModule_ReportPrebuiltLibraries);
            RegisterRule("ARModule_ReportLinkFlags", ARModule_ReportLinkFlags);
        }

        static JamList ARModule_ReportCpp()
        {
            return JamList(
                JamExtensions.AllSourceFilesFrom("Runtime/AR"),
                JamExtensions.AllSourceFilesFrom(
                    "Runtime/AR/Tango"),
                JamExtensions.AllSourceFilesFrom("External/Tango/builds/gen"));
        }

        static JamList ARModule_ReportCs()
        {
            JamList csFiles = JamList();
            csFiles.Append(Projects.Jam.Rules.UnityRules.Unity_Glob($"{Vars.TOP}/Runtime/AR/Tango/ScriptBindings", "cs", Vars.TOP));
            csFiles.Append(Projects.Jam.Rules.UnityRules.Unity_Glob($"{Vars.TOP}/Runtime/AR/ScriptBindings", "cs", Vars.TOP));

            return csFiles;
        }

        static JamList ARModule_ReportIncludes()
        {
            return JamList("External/PhysX3/builds/Include", "External/Tango/builds/include");
        }

        static JamList ARModule_ReportDependencies()
        {
            return JamList(Projects.Jam.SetupRuntimeModules2.DefaultModuleDependencies(), "Physics", "Input", "JSONSerialize");
        }

        static void ARModule_ReportPrebuiltLibraries()
        {
        }

        static void ARModule_ReportLinkFlags()
        {
        }
    }
}
