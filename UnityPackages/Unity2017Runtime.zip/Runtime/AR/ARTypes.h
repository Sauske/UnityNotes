#pragma once

#include "Runtime/Scripting/BindingsDefs.h"

// Must match UnityEngine.XR.ARRenderMode in C# code
typedef enum ARRenderMode
{
    kRenderModeStandardBackground,
    kRenderModeMaterialAsBackground
} ARRenderMode;

BIND_MANAGED_TYPE_NAME(ARRenderMode, UnityEngine_XR_ARRenderMode);
