#include "UnityPrefix.h"
#include "Runtime/Modules/ModuleRegistration.h"

#ifdef UNITY_MODULE_INCLUDE
#   undef UNITY_MODULE_INCLUDE
#endif

#define UNITY_MODULE_NAME    AR
#define UNITY_MODULE_STRIPPABLE
#define UNITY_MODULE_INCLUDE "Runtime/AR/ARModule.inc.h"
    #include "Runtime/Modules/ModuleTemplate.inc.h"
#undef UNITY_MODULE_NAME
#undef UNITY_MODULE_STRIPPABLE
#undef UNITY_MODULE_INCLUDE

#if UNITY_EDITOR
void RegisterTangoPluginAsExtension();
void RegisterVuforiaPluginsAsExtensions();

#include "Editor/Src/AssetPipeline/UnityExtensions.h"

static void InitializeUnityARRuntime(const core::string& path, UnityExtensions::CallbackData* data)
{
    static const char* kARDllForPlayer = "Runtime/UnityEngine.AR.dll";

    // UnityEngine.AR.dll is used by any platform except Editor
    if (EndsWithCaseInsensitive(path, kARDllForPlayer))
    {
        data->SetCompatibleWithAnyPlatform(false);
        data->SetCompatibleWithPlatform(kBuild_Android, true);
        data->SetCompatibleWithEditor(false);
    }
    // UnityEngine.AR.dll is used only by Editor
    else
    {
        data->SetCompatibleWithAnyPlatform(false);
        data->SetCompatibleWithEditor(true);
    }
}

static void InitializeUnityAREditor(const core::string& path, UnityExtensions::CallbackData* data)
{
    data->SetCompatibleWithAnyPlatform(false);
    data->SetCompatibleWithEditor(true);
}

#endif

UNITY_MODULE_INITIALIZE(AR)
{
#if UNITY_EDITOR
    UnityExtensions::Get().Register("UnityEngine.AR.dll", InitializeUnityARRuntime, NULL);
    UnityExtensions::Get().Register("UnityEditor.AR.dll", InitializeUnityAREditor, NULL);

    RegisterTangoPluginAsExtension();
    RegisterVuforiaPluginsAsExtensions();
#endif
}

UNITY_MODULE_CLEANUP(AR)
{
}
