#pragma once

#include "Runtime/Mono/MonoScript.h"
#include "Runtime/Scripting/BindingsDefs.h"

struct EditorCurveBinding
{
    core::string         path;
    core::string         attribute; ///@TODO: Rename to propertyName, thats how it is called in C#
    const Unity::Type*  type;
    MonoScriptPPtr      script;
    bool                isPPtrCurve;
    bool                isPhantom;
    bool                isDiscreteCurve;

    EditorCurveBinding()
    {
        script = NULL;
        isPPtrCurve = false;
        type = 0;
        isPhantom = false;
        isDiscreteCurve = false;
    }

    EditorCurveBinding(const core::string& inPath, const Unity::Type* inTypeInfo, MonoScriptPPtr inScript, const core::string& inAttribute)
    {
        path = inPath;
        type = inTypeInfo;
        script = inScript;
        attribute = inAttribute;
        isPPtrCurve = false;
        isDiscreteCurve = false;
        isPhantom = false;
    }

    friend bool operator==(const EditorCurveBinding& lhs, const EditorCurveBinding& rhs)
    {
        return lhs.path == rhs.path && lhs.attribute == rhs.attribute && lhs.type == rhs.type
            && lhs.script == rhs.script && lhs.isPPtrCurve == rhs.isPPtrCurve && lhs.isDiscreteCurve == rhs.isDiscreteCurve;
    }
};

namespace UnityEditor
{
namespace Animation
{
    static EditorCurveBinding PPtrCurveBinding(const core::string& inPath, const Unity::Type* inTypeInfo, MonoScriptPPtr inScript, const core::string& inAttribute)
    {
        EditorCurveBinding binding = EditorCurveBinding(inPath, inTypeInfo, inScript, inAttribute);
        binding.isPPtrCurve = true;
        binding.isDiscreteCurve = true;
        return binding;
    }

    static EditorCurveBinding FloatCurveBinding(const core::string& inPath, const Unity::Type* inTypeInfo, MonoScriptPPtr inScript, const core::string& inAttribute)
    {
        EditorCurveBinding binding = EditorCurveBinding(inPath, inTypeInfo, inScript, inAttribute);
        binding.isPPtrCurve = false;
        binding.isDiscreteCurve = false;
        return binding;
    }

    static EditorCurveBinding DiscreteCurveBinding(const core::string& inPath, const Unity::Type* inTypeInfo, MonoScriptPPtr inScript, const core::string& inAttribute)
    {
        EditorCurveBinding binding = EditorCurveBinding(inPath, inTypeInfo, inScript, inAttribute);
        binding.isPPtrCurve = false;
        binding.isDiscreteCurve = true;
        return binding;
    }
}
}

BIND_MANAGED_TYPE_NAME(EditorCurveBinding, UnityEditor_EditorCurveBinding);
