#include "UnityPrefix.h"
#include "GenericAnimationBindingCache.h"
#include "AnimationClipBindings.h"
#include "Runtime/Mono/MonoBehaviour.h"
#include "Runtime/Mono/MonoTypeSignatures.h"
#include "Runtime/Serialize/TransferUtility.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/Interfaces/IAnimationBinding.h"
#include "Animator.h"
#include "Runtime/Utilities/RegisterRuntimeInitializeAndCleanup.h"
#include "AnimatorController.h"
#include "Runtime/Core/Callbacks/GlobalCallbacks.h"
#include "Runtime/Serialize/IterateTypeTree.h"
#include "Runtime/Scripting/ScriptingManager.h"
#include "Runtime/Transform/RectTransform.h"
#include "Runtime/Transform/TransformHierarchy.h"

#if ENABLE_DOTNET
#include "PlatformDependent/WinRT/AnimationBinderWinRT.h"
#endif

const static char* kIsActive = "m_IsActive";

//@TODO: Write test for Script Object reference animation (Follow MaterialObjectReferenceAnimation example)
//@TODO: Make sure that OnAnimationAwakeFromLoad is getting called


typedef UInt32 BindingHash;

namespace UnityEngine
{
namespace Animation
{
    bool IsMuscleBinding(const GenericBinding& binding)
    {
        return binding.GetType() == TypeOf<Animator>() && binding.customType == kBindMuscle;
    }

    struct CachedComponentBindings
    {
        ScriptingClassPtr            scriptingClass;
        const Unity::Type*           type;
        size_t                       bindingSize;
        CachedBinding*               bindings;
    };


    static GenericAnimationBindingCache* gGenericBindingCache = NULL;

    static CachedComponentBindings* GenerateComponentBinding(const Unity::Type* type, ScriptingObjectPtr scriptingInstance, ScriptingClassPtr scriptingClass, Object* targetObject);
    static const CachedBinding* FindBinding(const CachedComponentBindings& componentBinding, BindingHash attribute);
    static void DestroyBinding(CachedComponentBindings* binding);

    bool operator<(const CachedBinding& lhs, const CachedBinding& rhs)
    {
        return lhs.propertyHash < rhs.propertyHash;
    }

    static const Unity::Type* FloatBindTypeToUnityType(int bindType)
    {
        const Unity::Type* retValue;
        switch (bindType)
        {
            case kBindFloatToBool:
                retValue = TypeOf<bool>();
                break;
            case kBindFloat:
                retValue = TypeOf<float>();
                break;
            case kBindFloatToInt:
            case kBindDiscreteInt:
                retValue = TypeOf<int>();
                break;
            case kBindScriptObjectReference:
                DebugAssertMsg(false, "Script Object Reference is not a float bind type");
            default:
                retValue = NULL;
        }

        return retValue;
    }

    static const Unity::Type* BindCurve(const CachedComponentBindings& cachedBinding, const GenericBinding& inputBinding, Object* targetObject, void* targetPtr, BoundCurve& bound)
    {
        const CachedBinding* found = FindBinding(cachedBinding, inputBinding.attribute);
        if (found == NULL)
        {
            bound.targetType = kUnbound;
            return NULL;
        }

        bound.targetObject = targetObject;
        bound.targetPtr = reinterpret_cast<UInt8*>(targetPtr) + found->offset;
        bound.targetType = found->bindType;

        if (inputBinding.isPPtrCurve)
        {
            if (found->bindType == kBindScriptObjectReference)
                return found->objectReferenceType;
        }
        else
        {
            const Unity::Type* type = FloatBindTypeToUnityType(found->bindType);
            if (type != NULL)
                return type;
        }


        bound.targetObject = NULL;
        bound.targetPtr = NULL;
        bound.targetType = kUnbound;
        return NULL;
    }

#if ENABLE_DOTNET
    static const Unity::Type* BindCurve(const CachedComponentBindings& cachedBinding, const GenericBinding& inputBinding, Object* targetObject, ScriptingObjectPtr targetPtr, BoundCurve& bound)
    {
        const CachedBinding* found = FindBinding(cachedBinding, inputBinding.attribute);
        if (found == NULL)
        {
            bound.targetType = kUnbound;
            return NULL;
        }

        MonoBehaviour* beh = dynamic_pptr_cast<MonoBehaviour*>(targetObject);
        if (beh != NULL && WinRT::AnimationBindField(beh->GetInstance(), found->field, found->index, &bound.targetPtr, reinterpret_cast<int*>(&bound.targetType)))
            bound.targetObject = targetObject;
        else
        {
            bound.targetType = kUnbound;
            return NULL;
        }

        if (inputBinding.isPPtrCurve)
        {
            if (found->bindType == kBindScriptObjectReference)
                return found->objectReferenceType;
        }
        else
        {
            const Unity::Type* type = FloatBindTypeToUnityType(found->bindType);
            if (type != NULL)
                return type;
        }

        bound.targetObject = NULL;
        bound.targetPtr = NULL;
        bound.targetType = kUnbound;
        return NULL;
    }

#endif

    int GetTypeTreeBindType(const TypeTreeIterator& variable)
    {
        if (variable.MetaFlags() & kDontAnimate)
            return kUnbound;

        if (variable.Type() == CommonString(float))
            return kBindFloat;
        else if (variable.Type() == CommonString(bool) || (variable.Type() == CommonString(UInt8) && (variable.MetaFlags() & kTreatIntegerValueAsBoolean)))
            return kBindFloatToBool;
        else if (variable.Type() == CommonString(int))
            return kBindFloatToInt;
        else
            return kUnbound;
    }

    static bool IsTypeTreeChildOfRoot(const TypeTreeIterator& variable)
    {
        return !variable.Father().IsNull() && variable.Father().Father().IsNull();
    }

    static int GetAnimatablePropertyOffset(const TypeTreeIterator& variable, ScriptingObjectPtr scriptingInstance, int& bindType, const Unity::Type*& objectReferenceType)
    {
        objectReferenceType = NULL;
        bindType = kUnbound;

        Assert(!variable.IsNull());
        UInt32 byteOffset = variable.ByteOffset();

#if !ENABLE_DOTNET
        if (((byteOffset & TypeTree::kScriptingInstanceOffset) != 0) != (scriptingInstance != SCRIPTING_NULL))
            return -1;

        if (scriptingInstance)
        {
            bindType = GetTypeTreeBindType(variable);

            if (bindType == kBindFloat || bindType == kBindFloatToBool || bindType == kBindFloatToInt)
            {
                if (byteOffset == TypeTree::kByteOffsetUnset)
                    return -1;

                if (bindType == kBindFloatToInt)
                {
                    ScriptingClassPtr klass = scripting_object_get_class(scriptingInstance);
                    ScriptingFieldPtr field = scripting_class_get_field_from_name(klass, variable.Name().c_str());
                    if (field == SCRIPTING_NULL)
                        return -1;
                    ScriptingTypePtr fieldType = scripting_field_get_type(field);
                    int type = scripting_type_get_type(fieldType);
                    if (type == SCRIPTING_TYPE_VALUETYPE)
                    {
                        ScriptingClassPtr fieldTypeClass = scripting_class_from_type(fieldType);
                        if (scripting_class_is_enum(fieldTypeClass))
                        {
                            bindType = kBindDiscreteInt;
                        }
                    }
                }
                return byteOffset & TypeTree::kByteOffsetMask;
            }
            // Object references must be found via scripting API
            // We only support object references on the root level. (We could support structs (not classes) but it's additional code)
            else if (IsTypeTreeChildOfRoot(variable))
            {
                ScriptingClassPtr klass = scripting_object_get_class(scriptingInstance);
                ScriptingFieldPtr field = scripting_class_get_field_from_name(klass, variable.Name().c_str());
                if (field == SCRIPTING_NULL)
                    return -1;

                ScriptingTypePtr fieldType = scripting_field_get_type(field);
                int type = scripting_type_get_type(fieldType);
                if (type == SCRIPTING_TYPE_CLASS)
                {
                    ScriptingClassPtr fieldTypeClass = scripting_class_from_type(fieldType);
                    objectReferenceType = Scripting::GetTypeFromScriptingClass(fieldTypeClass);
                    if (objectReferenceType == NULL)
                        return -1;

                    // For now we require engine asset types.
                    // This is because we would have to pass the full managed type (instead of Unity::Type) to script API if we want exact type checking in the AnimationWindow.
                    if (objectReferenceType != TypeOf<Object>() && objectReferenceType != TypeOf<MonoBehaviour>())
                    {
                        bindType = kBindScriptObjectReference;
                        return scripting_field_get_offset(field);
                    }
                }
            }
            return -1;
        }
#else
        // keeps logic same with the old way (check history): if scriptingInstance present, returns -1 for non-Mono platforms
        if (scriptingInstance)
            return -1;
#endif
        else
        {
            if (byteOffset == TypeTree::kByteOffsetUnset)
                return -1;

            bindType = GetTypeTreeBindType(variable);
            if (bindType == kUnbound)
                return -1;

            return byteOffset & TypeTree::kByteOffsetMask;
        }
    }

    static void GetGenericAnimatablePropertiesRecurse(const TypeTreeIterator& type, core::string& path, ScriptingObjectPtr scriptingInstance, const EditorCurveBinding& baseBinding, std::vector<EditorCurveBinding>& outProperties)
    {
        size_t previousSize = path.size();
        if (!path.empty())
            path += '.';
        path += type.Name().c_str();

        const Unity::Type* objectReferenceType;
        int bindType;
        int offset = GetAnimatablePropertyOffset(type, scriptingInstance, bindType, objectReferenceType);
        if (offset != -1)
        {
            outProperties.push_back(baseBinding);
            outProperties.back().attribute = path;
            outProperties.back().isPPtrCurve = bindType == kBindScriptObjectReference;
            outProperties.back().isDiscreteCurve = bindType == kBindDiscreteInt;
        }

        for (TypeTreeIterator i = type.Children(); !i.IsNull(); i = i.Next())
        {
            GetGenericAnimatablePropertiesRecurse(i, path, scriptingInstance, baseBinding, outProperties);
        }

        path.resize(previousSize);
    }

    static void GetGenericAnimatableProperties(const Unity::Type* type, Object& targetObject, std::vector<EditorCurveBinding>& outProperties)
    {
        //@TODO: Use temp TypeTree mem?
        TypeTree typeTree;
        GenerateTypeTree(targetObject, typeTree);

        EditorCurveBinding baseBinding;
        baseBinding.type = type;

        MonoBehaviour* behaviour = dynamic_pptr_cast<MonoBehaviour*>(&targetObject);
        ScriptingObjectPtr scriptingInstance = SCRIPTING_NULL;
        if (behaviour)
        {
            scriptingInstance = behaviour->GetInstance();
            baseBinding.script = behaviour->GetScript();
        }

        // Create cached bindings (We don't want to include the root name, so iterate over the children directly)
        core::string path;
        for (TypeTreeIterator i = typeTree.Root().Children(); !i.IsNull(); i = i.Next())
            GetGenericAnimatablePropertiesRecurse(i, path, scriptingInstance, baseBinding, outProperties);
    }

    static const Unity::Type* FindGenericAnimatablePropertyTypeRecurse(const TypeTreeIterator& type, core::string& path, ScriptingObjectPtr scriptingInstance, const EditorCurveBinding& binding)
    {
        size_t previousSize = path.size();
        if (!path.empty())
            path += '.';
        path += type.Name().c_str();

        const Unity::Type* objectReferenceType;
        int bindType;
        int offset = GetAnimatablePropertyOffset(type, scriptingInstance, bindType, objectReferenceType);

        if (offset != -1)
        {
            if (path == binding.attribute)
            {
                if (bindType == kBindScriptObjectReference)
                {
                    return objectReferenceType;
                }
                else
                {
                    return FloatBindTypeToUnityType(bindType);
                }
            }
        }

        for (TypeTreeIterator i = type.Children(); !i.IsNull(); i = i.Next())
        {
            objectReferenceType = FindGenericAnimatablePropertyTypeRecurse(i, path, scriptingInstance, binding);
            if (objectReferenceType != NULL)
                return objectReferenceType;
        }

        path.resize(previousSize);
        return NULL;
    }

    static const Unity::Type* FindGenericAnimatablePropertyType(Object& targetObject, const EditorCurveBinding& binding)
    {
        TypeTree typeTree;
        GenerateTypeTree(targetObject, typeTree);

        MonoBehaviour* behaviour = dynamic_pptr_cast<MonoBehaviour*>(&targetObject);
        ScriptingObjectPtr scriptingInstance = SCRIPTING_NULL;
        if (behaviour)
            scriptingInstance = behaviour->GetInstance();

        core::string path;
        for (TypeTreeIterator i = typeTree.Root().Children(); !i.IsNull(); i = i.Next())
        {
            const Unity::Type* type = FindGenericAnimatablePropertyTypeRecurse(i, path, scriptingInstance, binding);
            if (type != NULL)
                return type;
        }

        return NULL;
    }

    static void GenerateBindingRecurse(const TypeTreeIterator& type, ScriptingObjectPtr scriptingInstance, mecanim::crc32 attributeHash, dynamic_array<CachedBinding>& bindings)
    {
        // Update hash recursively
        if (attributeHash.checksum() != 0)
            attributeHash.process_bytes(".", 1);
        attributeHash.process_bytes(type.Name().c_str(), type.Name().strlen());

        const Unity::Type* objectReferenceType;
        int bindType;
        int offset = GetAnimatablePropertyOffset(type, scriptingInstance, bindType, objectReferenceType);
        if (offset != -1)
        {
            CachedBinding& binding = bindings.emplace_back_uninitialized();
            binding.propertyHash = attributeHash.checksum();
            binding.offset = offset;
            binding.bindType = bindType;
            binding.objectReferenceType = objectReferenceType;
        }

        for (TypeTreeIterator i = type.Children(); !i.IsNull(); i = i.Next())
            GenerateBindingRecurse(i, scriptingInstance, attributeHash, bindings);
    }

    template<class T>
    bool has_duplicate_sorted(const T* begin, size_t count)
    {
        if (count == 0)
            return false;

        const T* previous = begin;
        const T* i = begin;
        const T* end = begin + count;
        i++;
        for (; i != end; ++i)
        {
            if (!(*previous < *i))
                return true;

            previous = i;
        }

        return false;
    }

    // Find a value in a sorted array
    // Returns NULL if there is no value in the array
    template<class T>
    const T* find_binary_search(const T* begin, size_t count, const T& value)
    {
        const T* found = std::lower_bound(begin, begin + count, value);
        if (found == begin + count || value < *found)
            return NULL;
        else
            return found;
    }

    static const CachedBinding* FindBinding(const CachedComponentBindings& componentBinding, BindingHash attribute)
    {
        CachedBinding proxy;
        proxy.propertyHash = attribute;

        return find_binary_search(componentBinding.bindings, componentBinding.bindingSize, proxy);
    }

    static void DestroyBinding(CachedComponentBindings* binding)
    {
        UNITY_FREE(kMemAnimation, binding);
    }

    static CachedComponentBindings* GenerateComponentBinding(const Unity::Type* type, ScriptingObjectPtr scriptingInstance, ScriptingClassPtr scriptingClass, Object* targetObject)
    {
        //@TODO: Use temp TypeTree mem?
        TypeTree typeTree;
        GenerateTypeTree(*targetObject, typeTree);

        dynamic_array<CachedBinding> bindings(kMemTempAlloc);

#if ENABLE_DOTNET
        if (type == TypeOf<MonoBehaviour>())
            WinRT::GenerateBindingRecurse(scriptingClass, mecanim::crc32(), bindings);
        else
        {
#endif

        // Create cached bindings (We don't want to include the root name, so iterate over the children directly)
        for (TypeTreeIterator i = typeTree.Root().Children(); !i.IsNull(); i = i.Next())
            GenerateBindingRecurse(i, scriptingInstance, mecanim::crc32(), bindings);

#if ENABLE_DOTNET
    }

#endif

        std::sort(bindings.begin(), bindings.end());

#if DEBUGMODE
        if (has_duplicate_sorted(bindings.begin(), bindings.size()))
        {
            ///@TODO: make a nice fullclassname...


            WarningStringMsg("Animation bindings for %s are not unique. Some properties might get bound incorrectly.", targetObject->GetTypeName());
        }
#endif

        size_t size = sizeof(CachedComponentBindings) + sizeof(CachedBinding) * bindings.size();
        mecanim::memory::InPlaceAllocator allocator(UNITY_MALLOC(kMemAnimation, size), size);

        CachedComponentBindings* binding = allocator.Construct<CachedComponentBindings>();

        binding->type = type;
        binding->scriptingClass = scriptingClass;
        binding->bindingSize = bindings.size();
        binding->bindings = allocator.ConstructArray<CachedBinding>(bindings.begin(), bindings.size());

        return binding;
    }

    void GenericAnimationBindingCache::DidReloadDomain()
    {
        if (gGenericBindingCache != NULL)
            Clear(gGenericBindingCache->m_Scripts);
    }

    void InitializeGenericAnimationBindingCache(void*)
    {
        mecanim::crc32::crc32_table_type::init_table();

        gGenericBindingCache = UNITY_NEW_AS_ROOT_NO_LABEL(GenericAnimationBindingCache, kMemAnimation, "AnimationBindingCache", "");

        GlobalCallbacks::Get().didReloadMonoDomain.Register(GenericAnimationBindingCache::DidReloadDomain);
    }

    void CleanupGenericAnimationBindingCache(void*)
    {
        UNITY_DELETE(gGenericBindingCache, kMemAnimation);

        GlobalCallbacks::Get().didReloadMonoDomain.Unregister(GenericAnimationBindingCache::DidReloadDomain);
    }

    static RegisterRuntimeInitializeAndCleanup s_RegisterBindingCache(InitializeGenericAnimationBindingCache, CleanupGenericAnimationBindingCache);

    GenericAnimationBindingCache& GetGenericAnimationBindingCache()
    {
        return *gGenericBindingCache;
    }

    GenericAnimationBindingCache::GenericAnimationBindingCache()
    {
        m_IsActiveHash = mecanim::processCRC32(kIsActive);
        m_Classes.resize_initialized(Unity::Type::GetTypeCount(), NULL);
        m_CustomBindingInterfaces.resize_initialized(kAllBindingCount, NULL);
    }

    GenericAnimationBindingCache::~GenericAnimationBindingCache()
    {
        Clear(m_Classes);
        Clear(m_Scripts);
    }

    void CreateTransformBinding(const core::string& path, int bindType, GenericBinding& outputBinding)
    {
        outputBinding.path = mecanim::processCRC32(path.c_str());
        outputBinding.attribute = bindType;
        outputBinding.typeID = TypeOf<Transform>()->GetPersistentTypeID();
        outputBinding.customType = kUnbound;
        outputBinding.isPPtrCurve = false;
        outputBinding.script = NULL;
    }

    bool IsDiscreteIntBinding(PPtr<MonoScript> script, const core::string& attribute,  const Unity::Type* type)
    {
        if (!script.IsValid())
            return false;

        if (type->IsDerivedFrom<MonoBehaviour>() == false)
            return false;

        ScriptingClassPtr klass = script->GetClass();
        if (klass == SCRIPTING_NULL)
            return false;

        ScriptingFieldPtr field = scripting_class_get_field_from_name(klass, attribute.c_str());
        if (field == SCRIPTING_NULL)
            return false;

        ScriptingTypePtr fieldType = scripting_field_get_type(field);
        int monoType = scripting_type_get_type(fieldType);
        if (monoType != SCRIPTING_TYPE_VALUETYPE)
            return false;

        ScriptingClassPtr fieldTypeClass = scripting_class_from_type(fieldType);
        return scripting_class_is_enum(fieldTypeClass);
    }

    void GenericAnimationBindingCache::CreateGenericBinding(const core::string& path, const Unity::Type* type, PPtr<MonoScript> script, const core::string& attribute, bool pptrCurve, GenericBinding& outputBinding) const
    {
        outputBinding.path = mecanim::processCRC32(path.c_str());
        outputBinding.attribute = mecanim::processCRC32(attribute.c_str());
        outputBinding.typeID = type->GetPersistentTypeID();
        outputBinding.customType = kUnbound;
        outputBinding.isPPtrCurve = pptrCurve;

        outputBinding.isIntCurve = !pptrCurve && IsDiscreteIntBinding(script, attribute, type);
        outputBinding.script = script;

        // Pre-bind muscle indices
        //@TODO: is this really worth doing? Maybe we should just make it more consistent?
        if (!pptrCurve)
        {
            if (type == TypeOf<Animator>())
            {
                mecanim::int32_t muscleIndex = mecanim::animation::FindMuscleIndex(outputBinding.attribute);
                if (muscleIndex != -1)
                {
                    outputBinding.attribute = muscleIndex;
                    outputBinding.customType = kBindMuscle;
                    return;
                }
            }
        }

        //case 818668: corrupted class ids (now NULL type) in curves cause crashes in IsDerivedFrom
        if (type == NULL)
            return;

        // Search custom bindings
        for (size_t i = 0; i < m_CustomBindings.size(); i++)
        {
            int customBindingType = m_CustomBindings[i].customBindingType;
            const IAnimationBinding* bindingInterface = m_CustomBindingInterfaces[customBindingType];
            if (type->IsDerivedFrom(m_CustomBindings[i].type) && bindingInterface->GenerateBinding(attribute, pptrCurve, outputBinding))
            {
                outputBinding.customType = customBindingType;
                return;
            }
        }
    }

    static inline MonoBehaviour* GetComponentWithScript(Transform& transform, PPtr<Object> target)
    {
        MonoScript* script = dynamic_instanceID_cast<MonoScript*>(target.GetInstanceID());
        return static_cast<MonoBehaviour*>(GetComponentWithScript(transform.GetGameObject(), TypeOf<MonoBehaviour>(), script));
    }

    const Unity::Type* GenericAnimationBindingCache::BindScript(const GenericBinding& inputBinding, Transform& transform, BoundCurve& bound)
    {
        MonoBehaviour* behaviour = GetComponentWithScript(transform, inputBinding.script);

        ScriptingObjectPtr instance = behaviour ? behaviour->GetInstance() : SCRIPTING_NULL;
        // No valid instance -> no bound curve
        if (instance == SCRIPTING_NULL)
        {
            bound.targetType = kUnbound;
            return NULL;
        }

        ScriptingClassPtr klass = behaviour->GetClass();

        // Find cached binding stored by ScriptingClassPtr
        CachedComponentBindings* bindings = NULL;
        for (size_t i = 0; i < m_Scripts.size(); i++)
        {
            if (m_Scripts[i]->scriptingClass == klass)
            {
                bindings = m_Scripts[i];
                break;
            }
        }

        // Create a new binding for this ScriptingClassPtr
        if (bindings == NULL)
        {
            bindings = GenerateComponentBinding(inputBinding.GetType(), instance, klass, behaviour);
            m_Scripts.push_back(bindings);
        }

        // Bind the specific curve
#if ENABLE_DOTNET
        return BindCurve(*bindings, inputBinding, behaviour, instance, bound);
#else
        return BindCurve(*bindings, inputBinding, behaviour, UnsafeExtractPointerFromScriptingObjectPtr(instance), bound);
#endif
    }

    const Unity::Type* GenericAnimationBindingCache::BindGenericComponent(const GenericBinding& inputBinding, Transform& transform, BoundCurve& bound)
    {
        Unity::Component* target = transform.GetGameObject().QueryComponentByType(inputBinding.GetType());
        if (target == NULL)
            return NULL;

        if (Unity::Type::GetTypeCount() > m_Classes.size())
            m_Classes.resize_initialized(Unity::Type::GetTypeCount(), NULL);

        RuntimeTypeIndex typeIndex = inputBinding.GetType()->GetRuntimeTypeIndex();
        if (m_Classes[typeIndex] == NULL)
            m_Classes[typeIndex] = GenerateComponentBinding(inputBinding.GetType(), SCRIPTING_NULL, SCRIPTING_NULL, target);

        return BindCurve(*m_Classes[typeIndex], inputBinding, target, target, bound);
    }

    Object* FindAnimatedObject(GameObject& root, const EditorCurveBinding& inputBinding)
    {
        Transform* transform = FindRelativeTransformWithPath(root.GetComponent<Transform>(), inputBinding.path.c_str());
        if (transform == NULL)
            return NULL;

        if (inputBinding.type == TypeOf<GameObject>())
        {
            return &transform->GetGameObject();
        }
        else if (inputBinding.type == TypeOf<MonoBehaviour>())
        {
            return GetComponentWithScript(*transform, inputBinding.script);
        }
        else
        {
            return transform->GetGameObject().QueryComponentByType(inputBinding.type);
        }
    }

    const Unity::Type* GenericAnimationBindingCache::BindPPtrGeneric(const GenericBinding& inputBinding, Transform& transform, BoundCurve& bound)
    {
        // custom binding
        if (inputBinding.customType != kUnbound)
            return BindCustom(inputBinding, transform, bound);
        // Script bindings
        else if (inputBinding.GetType() == TypeOf<MonoBehaviour>())
        {
            return BindScript(inputBinding, transform, bound);
        }
        // cant be bound
        else
            return NULL;
    }

    const Unity::Type* GenericAnimationBindingCache::BindCustom(const GenericBinding& inputBinding, Transform& transform, BoundCurve& bound) const
    {
        Assert(inputBinding.customType != kUnbound);

        Unity::Component* target;
        if (inputBinding.GetType() == TypeOf<MonoBehaviour>())
        {
            target = GetComponentWithScript(transform, inputBinding.script);
        }
        else
        {
            const Unity::Type* type = inputBinding.GetType();
            target = type != NULL ? transform.GetGameObject().QueryComponentByType(type) : NULL;
        }

        IAnimationBinding* customBinding = m_CustomBindingInterfaces[inputBinding.customType];
        if (customBinding != NULL && target != NULL)
        {
            BoundCurve tempBound;
            tempBound.targetType = inputBinding.customType;
            tempBound.customBinding = customBinding;
            tempBound.targetObject = target;

            const Unity::Type* type = customBinding->BindValue(*target, inputBinding, tempBound);
            if (type != NULL)
                bound = tempBound;

            return type;
        }

        return NULL;
    }

    const Unity::Type* GenericAnimationBindingCache::BindGeneric(const GenericBinding& inputBinding, Transform& transform, BoundCurve& bound)
    {
        // Custom binding
        if (inputBinding.customType != kUnbound)
            return BindCustom(inputBinding, transform, bound);
        // Bind game object active state
        else if (inputBinding.GetType() == TypeOf<GameObject>())
        {
            if (inputBinding.attribute == m_IsActiveHash && inputBinding.path != 0)
            {
                bound.targetPtr = NULL;
                bound.targetType = kBindGameObjectActive;
                bound.targetObject = transform.GetGameObjectPtr();
                return TypeOf<bool>();
            }

            return NULL;
        }
        // Custom animator bindings
        else if (inputBinding.GetType() == TypeOf<Animator>())
        {
            // We bind these in mecanim internally.
            return TypeOf<float>();
        }
        // Script bindings
        else if (inputBinding.GetType() == TypeOf<MonoBehaviour>())
        {
            return BindScript(inputBinding, transform, bound);
        }
        // Generic bindings
        else
        {
            return BindGenericComponent(inputBinding, transform, bound);
        }
    }

    void GenericAnimationBindingCache::RegisterIAnimationBinding(const Unity::Type* type, int customBindingType, IAnimationBinding* customBinding)
    {
        CustomBinding bind;
        bind.type = type;
        bind.customBindingType = customBindingType;
        m_CustomBindings.push_back(bind);

        Assert(m_CustomBindingInterfaces[customBindingType] == NULL);
        m_CustomBindingInterfaces[customBindingType] = customBinding;
    }

    core::string GenericAnimationBindingCache::SerializedPropertyPathToCurveAttribute(Object& target, const char* propertyPath) const
    {
        const Unity::Type* type = target.GetType();
        // Search custom bindings
        for (size_t i = 0; i < m_CustomBindings.size(); i++)
        {
            if (!type->IsDerivedFrom(m_CustomBindings[i].type))
                continue;

            int customBindingType = m_CustomBindings[i].customBindingType;
            const IAnimationBinding* customBinding = m_CustomBindingInterfaces[customBindingType];

            core::string attributeName = customBinding->SerializedPropertyPathToCurveAttribute(target, propertyPath);
            if (!attributeName.empty())
                return attributeName;
        }

        return core::string();
    }

    core::string GenericAnimationBindingCache::CurveAttributeToSerializedPath(GameObject& root, const EditorCurveBinding& binding) const
    {
        Transform* transform = FindRelativeTransformWithPath(root.GetComponent<Transform>(), binding.path.c_str());
        if (transform == NULL)
            return core::string();

        GenericBinding genericBinding;
        CreateGenericBinding(binding.path, binding.type, binding.script, binding.attribute, binding.isPPtrCurve, genericBinding);

        if (genericBinding.customType == kUnbound)
            return core::string();

        BoundCurve bound;
        if (BindCustom(genericBinding, *transform, bound) == NULL)
            return core::string();

        if (bound.customBinding != NULL)
            return bound.customBinding->CurveAttributeToSerializedPath(bound);
        else
            return core::string();
    }

    void GenericAnimationBindingCache::Clear(CachedComponentBindingArray& array)
    {
        for (size_t i = 0; i < array.size(); i++)
        {
            UNITY_FREE(kMemAnimation, array[i]);
        }
        array.clear();
    }

    InstanceID GetBoundCurveInstanceIDValue(const BoundCurve& bind)
    {
        UInt32 targetType = bind.targetType;

        if (targetType == kBindScriptObjectReference)
        {
#if !ENABLE_DOTNET
            ScriptingObjectPtr scriptValue = *reinterpret_cast<ScriptingObjectPtr*>(bind.targetPtr);
#else
            MonoBehaviour* script = dynamic_pptr_cast<MonoBehaviour*>(bind.targetObject);
            ScriptingObjectPtr scriptValue = WinRT::AnimationGetFieldObject(script, bind.targetPtr);
#endif
            return Scripting::GetInstanceIDFor(scriptValue);
        }
        else
        {
            return bind.customBinding->GetPPtrValue(bind);
        }
    }

    bool SetBoundCurveInstanceIDValue(const BoundCurve& bind, InstanceID value)
    {
        UInt32 targetType = bind.targetType;

        if (targetType == kBindScriptObjectReference)
        {
            bool didChange = false;
#if !ENABLE_DOTNET
            ScriptingObjectPtr scriptValue = Scripting::ScriptingWrapperFor(PPtr<Object>(value));
            //@TODO: Validate type is subclass
            ScriptingObjectPtr* targetPtr = reinterpret_cast<ScriptingObjectPtr*>(bind.targetPtr);
            didChange = *targetPtr != scriptValue;
            *targetPtr = scriptValue;
#else
            int originalValue = 0;
            MonoBehaviour* script = dynamic_pptr_cast<MonoBehaviour*>(bind.targetObject);
            ScriptingObjectPtr orig = WinRT::AnimationGetFieldObject(script, bind.targetPtr);
            if (orig != SCRIPTING_NULL)
            {
                Object *o = ScriptingObjectToObject<Object>(orig);
                if (o)
                    originalValue = o->GetInstanceID();
            }

            didChange = originalValue != value;
            if (didChange)
                WinRT::AnimationSetFieldObject(script, bind.targetPtr, Scripting::ScriptingWrapperFor(PPtr<Object>(value)));
#endif
            return didChange;
        }
        else
        {
            bind.customBinding->SetPPtrValue(bind, value);
            return false;
        }
    }

    bool SetBoundCurveFloatValue(const BoundCurve& bind, float value)
    {
        UInt32 targetType = bind.targetType;
        Assert(bind.targetType != kUnbound && bind.targetType != kBindTransformRotation && bind.targetType != kBindTransformPosition && bind.targetType != kBindTransformScale && bind.targetType != kBindTransformEuler);

        if (targetType == kBindFloat)
        {
            bool didChange = false;
#if !ENABLE_DOTNET
            float* targetPtr = reinterpret_cast<float*>(bind.targetPtr);
            didChange = *targetPtr != value;
            *targetPtr = value;
#else
            float oldValue = WinRT::AnimationGetFieldFloat(bind.targetObject, bind.targetPtr);
            didChange = WinRT::AnimationSetFieldFloat(bind.targetObject, bind.targetPtr, value);
            didChange = didChange && oldValue != value;
#endif
            return didChange;
        }
        else if (targetType == kBindFloatToBool)
        {
            bool didChange = false;
#if !ENABLE_DOTNET
            UInt8* targetPtr = reinterpret_cast<UInt8*>(bind.targetPtr);
            UInt8 newValue = AnimationFloatToBool(value);
            didChange = *targetPtr != newValue;
            *targetPtr = newValue;
#else
            bool oldValue = WinRT::AnimationGetFieldBool(bind.targetObject, bind.targetPtr);
            bool newValue = AnimationFloatToBool(value);
            didChange = WinRT::AnimationSetFieldBool(bind.targetObject, bind.targetPtr, newValue);
            didChange = didChange && oldValue != newValue;
#endif
            return didChange;
        }
        else if (targetType == kBindFloatToInt || targetType == kBindDiscreteInt)
        {
            bool didChange = false;
#if !ENABLE_DOTNET
            int* targetPtr = reinterpret_cast<int*>(bind.targetPtr);
            int newValue = AnimationFloatToInt(value);
            didChange = *targetPtr != newValue;
            *targetPtr = newValue;
#else
            int oldValue = WinRT::AnimationGetFieldInt(bind.targetObject, bind.targetPtr);
            int newValue = AnimationFloatToInt(value);
            didChange = WinRT::AnimationSetFieldInt(bind.targetObject, bind.targetPtr, newValue);
            didChange = didChange && oldValue != newValue;
#endif
            return didChange;
        }
        else if (targetType == kBindGameObjectActive)
        {
            GameObject* go = static_cast<GameObject*>(bind.targetObject);
            go->SetSelfActive(AnimationFloatToBool(value));
            return false;
        }
        else
        {
            bind.customBinding->SetFloatValue(bind, value);
            return false;
        }
    }

    float GetBoundCurveFloatValue(const BoundCurve& bind)
    {
        UInt32 targetType = bind.targetType;
        Assert(bind.targetType >= kMinSinglePropertyBinding);

        if (targetType == kBindFloat)
        {
#if !ENABLE_DOTNET
            return *reinterpret_cast<float*>(bind.targetPtr);
#else
            return WinRT::AnimationGetFieldFloat(bind.targetObject, bind.targetPtr);
#endif
        }
        else if (targetType == kBindFloatToBool)
        {
#if !ENABLE_DOTNET
            return AnimationBoolToFloat(*reinterpret_cast<UInt8*>(bind.targetPtr) != 0);
#else
            return AnimationBoolToFloat(WinRT::AnimationGetFieldBool(bind.targetObject, bind.targetPtr));
#endif
        }
        else if (targetType == kBindFloatToInt || targetType == kBindDiscreteInt)
        {
#if !ENABLE_DOTNET
            return AnimationIntToFloat(*reinterpret_cast<int*>(bind.targetPtr));
#else
            return AnimationIntToFloat(WinRT::AnimationGetFieldInt(bind.targetObject, bind.targetPtr));
#endif
        }
        else if (targetType == kBindGameObjectActive)
        {
            GameObject* go = static_cast<GameObject*>(bind.targetObject);
            return AnimationBoolToFloat(go->IsSelfActive());
        }
        else
            return bind.customBinding->GetFloatValue(bind);
    }

    void BoundCurveValueAwakeGeneric(Object& targetObject)
    {
        targetObject.AwakeFromLoad(kAnimationAwakeFromLoad);
        targetObject.SetDirty();
    }

#if UNITY_EDITOR

    static void ExtractGameObjectIsActiveBindings(std::vector<EditorCurveBinding>& outProperties)
    {
        AddBinding(outProperties, TypeOf<GameObject>(), kIsActive);
    }

    static void ExtractAllAnimatorBindings(Unity::Component& targetObject, std::vector<EditorCurveBinding>& attributes)
    {
        Animator& animator = static_cast<Animator&>(targetObject);
        if (animator.IsHuman())
        {
            for (int curveIter = 0; curveIter < mecanim::animation::s_ClipMuscleCurveCount; curveIter++)
                AddBinding(attributes, TypeOf<Animator>(), mecanim::animation::GetMuscleCurveName(curveIter).c_str());
        }

        if (animator.GetAnimatorController())
        {
            AnimatorControllerParameterVector parameters = animator.GetAnimatorController()->GetParameters();
            for (AnimatorControllerParameterVector::iterator it = parameters.begin(); it != parameters.end(); ++it)
            {
                if (it->GetType() == 1)
                    AddBinding(attributes, TypeOf<Animator>(), it->GetName());
            }
        }
    }

    static void ProcessRelativePath(GameObject& gameObject, GameObject& root, std::vector<EditorCurveBinding>& outProperties)
    {
        core::string path = CalculateTransformPath(gameObject.GetComponent<Transform>(), root.QueryComponent<Transform>());
        for (int i = 0; i < outProperties.size(); i++)
            outProperties[i].path = path;
    }

    void GenericAnimationBindingCache::GetComponentAnimatableProperties(GameObject& go, GameObject& root, const Unity::Type* componentType, std::vector<EditorCurveBinding>& outProperties)
    {
        Assert(outProperties.empty());

        Unity::Component* component = NULL;
        for (int i = 0; i < go.GetComponentCount(); ++i)
        {
            Unity::Component& goComponent = go.GetComponentAtIndex(i);
            if (goComponent.GetType() == componentType)
            {
                component = &goComponent;
                break;
            }
        }

        if (component)
        {
            GetComponentAnimatableProperties(*component, outProperties);
            ProcessRelativePath(go, root, outProperties);
        }
    }

    void GenericAnimationBindingCache::GetAllAnimatableProperties(GameObject& go, GameObject& root, std::vector<EditorCurveBinding>& outProperties)
    {
        Assert(outProperties.empty());

        if (&go != &root)
            ExtractGameObjectIsActiveBindings(outProperties);

        for (int i = 0; i < go.GetComponentCount(); i++)
        {
            Unity::Component& com = go.GetComponentAtIndex(i);
            const Unity::Type* type = com.GetType();

            // Duplicate components are not allowed, because we the binding system will not animate them anyway...
            bool isDuplicateComponent = false;
            if (type == TypeOf<MonoBehaviour>())
            {
                // We cannot just compare typeInfo for MonoBehaviour since every custom scripts will share the same.
                MonoBehaviour *monoBehaviour = static_cast<MonoBehaviour*>(&com);
                for (int j = 0; j < i; j++)
                {
                    Unity::Component& candidate = go.GetComponentAtIndex(j);
                    const Unity::Type* candidateType = candidate.GetType();

                    if (type == candidateType)
                    {
                        MonoBehaviour *candidateMonoBehaviour = static_cast<MonoBehaviour*>(&candidate);
                        if (monoBehaviour->GetScript() == candidateMonoBehaviour->GetScript())
                        {
                            isDuplicateComponent = true;
                            break;
                        }
                    }
                }
            }
            else
            {
                for (int j = 0; j < i; j++)
                    isDuplicateComponent |= type == go.GetComponentTypeAtIndex(j);
            }

            if (isDuplicateComponent)
                continue;

            GetComponentAnimatableProperties(com, outProperties);
        }

        ProcessRelativePath(go, root, outProperties);
    }

    void GenericAnimationBindingCache::GetComponentAnimatableProperties(Unity::Component& component, std::vector<EditorCurveBinding>& outProperties)
    {
        const Unity::Type* type = component.GetType();

        // Search custom bindings
        for (int c = 0; c < m_CustomBindings.size(); c++)
        {
            int customBindingType = m_CustomBindings[c].customBindingType;
            if (type->IsDerivedFrom(m_CustomBindings[c].type))
                m_CustomBindingInterfaces[customBindingType]->GetAllAnimatableProperties(component, outProperties);
        }

        if (type == TypeOf<Animator>())
            ExtractAllAnimatorBindings(component, outProperties);

        GetGenericAnimatableProperties(type, component, outProperties);
    }

    void GenericAnimationBindingCache::GetAnimatableProperties(MonoBehaviour &behaviour, std::vector<EditorCurveBinding>& outProperties)
    {
        Assert(outProperties.empty());

        const Unity::Type* type = behaviour.GetType();
        GetGenericAnimatableProperties(type, behaviour, outProperties);
    }

    static bool GetFloatValueAnimatorBinding(Transform& transform, const EditorCurveBinding& binding, float* value)
    {
        Animator* animator = transform.QueryComponent<Animator>();

        if (animator == NULL)
            return false;

        BindingHash hash = mecanim::processCRC32(binding.attribute.c_str());

        if (animator->GetMuscleValue(hash, value))
            return true;

        GetSetValueResult result = animator->GetFloat(hash, *value, true);
        return result == kGetSetSuccess;
    }

    static bool GetFloatValueTransformBinding(Transform& transform, const EditorCurveBinding& binding, float* value)
    {
        if (binding.attribute.empty())
            return false;

        int axis = -1;
        char lastCharacter = binding.attribute[binding.attribute.size() - 1];
        if (lastCharacter == 'w')
            axis = 3;
        else if (lastCharacter >= 'x' && lastCharacter <= 'z')
            axis = lastCharacter - 'x';
        else
            return false;

        if (BeginsWith(binding.attribute, "m_LocalPosition") && axis < 3)
        {
            *value = transform.GetLocalPosition()[axis];
            return true;
        }
        else if (BeginsWith(binding.attribute, "m_LocalScale") && axis < 3)
        {
            *value = transform.GetLocalScale()[axis];
            return true;
        }
        else if (BeginsWith(binding.attribute, "m_LocalRotation") && axis < 4)
        {
            *value = transform.GetLocalRotation()[axis];
            return true;
        }
        else if (BeginsWith(binding.attribute, "localEulerAngles") && axis < 3)
        {
            *value = transform.GetLocalEulerAngles()[axis];
            return true;
        }
        else
            return false;
    }

    const Unity::Type* GetFloatValueGenericBinding(GameObject& root, const EditorCurveBinding& binding, Transform* transform, float* value)
    {
        GenericBinding genericBinding;
        GetGenericAnimationBindingCache().CreateGenericBinding(binding.path, binding.type, binding.script, binding.attribute, binding.isPPtrCurve, genericBinding);

        BoundCurve bound;
        const Unity::Type* bindType = GetGenericAnimationBindingCache().BindGeneric(genericBinding, *transform, bound);
        if (bound.targetType == kUnbound)
            return NULL;

        *value = GetBoundCurveFloatValue(bound);

        return bindType;
    }

    const Unity::Type* GetFloatValue(GameObject& root, const EditorCurveBinding& binding, float* value)
    {
        *value = 0.0F;

        if (binding.isPPtrCurve)
            return NULL;

        Transform* transform = FindRelativeTransformWithPath(root.GetComponent<Transform>(), binding.path.c_str());
        if (transform == NULL)
            return NULL;

        // Transform has a special codepath for setting T/R/S as Vector3
        if (binding.type->IsDerivedFrom<Transform>())
            if (GetFloatValueTransformBinding(*transform, binding, value))
                return TypeOf<float>();

        // Animator bindings are handled through a special more integrated code path in mecanim
        if (binding.type == TypeOf<Animator>())
            if (GetFloatValueAnimatorBinding(*transform, binding, value))
                return TypeOf<float>();

        // No specialized path, go for generic
        return GetFloatValueGenericBinding(root, binding, transform, value);
    }

    const Unity::Type* GetPPtrValue(GameObject& root, const EditorCurveBinding& binding, InstanceID* instanceID)
    {
        *instanceID = InstanceID_None;

        if (!binding.isPPtrCurve)
            return NULL;

        Transform* transform = FindRelativeTransformWithPath(root.GetComponent<Transform>(), binding.path.c_str());
        if (transform == NULL)
            return NULL;

        GenericBinding genericBinding;
        GetGenericAnimationBindingCache().CreateGenericBinding(binding.path, binding.type, binding.script, binding.attribute, binding.isPPtrCurve, genericBinding);

        BoundCurve bound;
        const Unity::Type* boundType = GetGenericAnimationBindingCache().BindPPtrGeneric(genericBinding, *transform, bound);
        if (bound.targetType == kUnbound)
            return NULL;

        *instanceID = GetBoundCurveInstanceIDValue(bound);
        return boundType;
    }

    const Unity::Type* GetEditorCurveValueType(GameObject& root, const EditorCurveBinding& binding)
    {
        // Try if it's a PPtr curve
        int tempInstanceID;
        const Unity::Type* boundType = GetPPtrValue(root, binding, &tempInstanceID);
        if (boundType != NULL)
            return boundType;

        // Otherwise find the type of float curve it is
        float tempFloat;
        return GetFloatValue(root, binding, &tempFloat);
    }

    const Unity::Type* GetEditorCurveValueType(MonoBehaviour& behaviour, const EditorCurveBinding& binding)
    {
        return FindGenericAnimatablePropertyType(behaviour, binding);
    }

#endif
}
}
