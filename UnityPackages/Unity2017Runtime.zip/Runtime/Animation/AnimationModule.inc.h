UNITY_MODULE_CLASS(Animation)
UNITY_MODULE_CLASS(AnimationClip)
UNITY_MODULE_CLASS(RuntimeAnimatorController)
UNITY_MODULE_CLASS(AnimatorController)
UNITY_MODULE_CLASS(Animator)
UNITY_MODULE_CLASS(Avatar)
UNITY_MODULE_CLASS(AvatarMask)
UNITY_MODULE_CLASS(Motion)
UNITY_MODULE_CLASS(AnimatorOverrideController)

#if UNITY_EDITOR
UNITY_MODULE_CLASS(PreviewAnimationClip)
///@TODO: Lets remove those. It's been deprecated since Unity 1.6
UNITY_MODULE_CLASS(BaseAnimationTrack)
UNITY_MODULE_CLASS(NewAnimationTrack)
#endif
