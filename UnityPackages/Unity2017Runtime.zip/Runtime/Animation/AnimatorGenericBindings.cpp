#include "UnityPrefix.h"
#include "AnimatorGenericBindings.h"
#include "AnimationSetBinding.h"
#include "Runtime/mecanim/skeleton/skeleton.h"
#include "Runtime/mecanim/animation/animationset.h"
#include "Runtime/mecanim/animation/controller.h"
#include "Runtime/mecanim/statemachine/statemachine.h"
#include "Runtime/mecanim/animation/avatar.h"
#include "Runtime/Animation/MecanimUtility.h"
#include "Runtime/Animation/Animator.h"
#include "Runtime/Animation/AnimationUtility.h"
#include "Runtime/Graphics/Mesh/SkinnedMeshRenderer.h"
#include "Runtime/Graphics/Mesh/Mesh.h"
#include "GenericAnimationBindingCache.h"
#include "Runtime/Misc/BuildSettings.h"
#include "Runtime/BaseClasses/EventIDs.h"
#include "Runtime/Transform/TransformChangeDispatch.h"

#if ENABLE_DOTNET
#include "PlatformDependent/WinRT/AnimationBinderWinRT.h"
#endif

namespace UnityEngine
{
namespace Animation
{
    static void InitializeDefaultValues(const Animation::AnimatorGenericBindingConstant& genericBinding, const mecanim::animation::AvatarConstant* avatar, bool hasTransformHierarchy);

    size_t PPtrCurveIndexToIntValueIndex(size_t pptrIndex, const AnimatorGenericBindingConstant& bindings)
    {
        return pptrIndex + bindings.genericIntBindingsCount;
    }

    struct BoundTransform
    {
        BindingHash  pathHash;

        Transform*  transform;
        int         bindIndexForSkeleton;
    };

    mecanim::int32_t SkeletonFindNodeIndexByNameID(const mecanim::animation::AvatarConstant* avatar, mecanim::uint32_t aNameID)
    {
        mecanim::int32_t ret = -1;

        mecanim::int32_t i;
        for (i = 0; ret == -1 && i < (int)avatar->m_SkeletonNameIDCount; i++)
        {
            if (avatar->m_SkeletonNameIDArray[i] == aNameID)
            {
                ret = i;
            }
        }

        return ret;
    }

    void GenerateTransformBindingMapRecursive(Transform& transform, const mecanim::crc32& nameHash, dynamic_array<BoundTransform>& bindings, const mecanim::animation::AvatarConstant* avatar, bool hasTransformHierarchy)
    {
        const mecanim::skeleton::Skeleton* skeleton = avatar->m_AvatarSkeleton.Get();

        BoundTransform& binding = bindings.emplace_back_uninitialized();
        binding.pathHash = nameHash.checksum();
        binding.transform = &transform;

        if (hasTransformHierarchy)
        {
            // binding.pathHash : full path
            binding.bindIndexForSkeleton = skeleton ? mecanim::skeleton::SkeletonFindNode(skeleton, binding.pathHash) : -1;
        }
        else
        {
            // binding.pathHash : flattened path
            binding.bindIndexForSkeleton = SkeletonFindNodeIndexByNameID(avatar, binding.pathHash);
        }

        Transform::iterator end = transform.end();
        for (Transform::iterator i = transform.begin(); i != end; ++i)
        {
            Transform* child = *i;
            const char* name = child->GetName();

            mecanim::crc32 childNameHash = AppendPathToHash(nameHash, name);
            GenerateTransformBindingMapRecursive(*child, childNameHash, bindings, avatar, hasTransformHierarchy);
        }
    }

    int FindTransformBindingIndexByBindingHash(const dynamic_array<BoundTransform>& bindings, BindingHash pathHash)
    {
        for (size_t i = 0; i < bindings.size(); ++i)
        {
            if (bindings[i].pathHash == pathHash)
                return i;
        }

        return -1;
    }

    int FindTransformBindingIndexBySkeletonIndex(const dynamic_array<BoundTransform>& bindings, int skeletonIndex)
    {
        for (size_t i = 0; i < bindings.size(); ++i)
        {
            if (bindings[i].bindIndexForSkeleton == skeletonIndex)
                return i;
        }

        return -1;
    }

    mecanim::animation::ControllerBindingConstant *CreateControllerBindingConstant(const mecanim::animation::AnimationSet* animationSet, mecanim::ValueArrayConstant* valueArrayConstant, mecanim::uint32_t valueArrayConstantSize, const mecanim::animation::AvatarConstant* avatar, mecanim::memory::Allocator& alloc)
    {
        SETPROFILERLABEL(ControllerBindingConstant);

        mecanim::animation::ControllerBindingConstant* controllerBindingConstant = alloc.Construct<mecanim::animation::ControllerBindingConstant>();
        controllerBindingConstant->m_AnimationSet = animationSet;

        int skeletonCount = !avatar->m_AvatarSkeleton.IsNull() ? avatar->m_AvatarSkeleton->m_Count : 0;
        if (skeletonCount > 0)
            controllerBindingConstant->m_SkeletonTQSMap = alloc.ConstructArray<mecanim::animation::SkeletonTQSMap>(avatar->m_AvatarSkeleton->m_Count);

        controllerBindingConstant->m_DynamicValuesConstant = CreateValueArrayConstantCopy(valueArrayConstant, valueArrayConstantSize, alloc);
        controllerBindingConstant->m_DynamicValuesDefault = CreateValueArray(controllerBindingConstant->m_DynamicValuesConstant, alloc);

        return controllerBindingConstant;
    }

    void DestroyControllerBindingConstant(mecanim::animation::ControllerBindingConstant* controllerBindingConstant, mecanim::memory::Allocator& alloc)
    {
        if (controllerBindingConstant)
        {
            DestroyValueArray(controllerBindingConstant->m_DynamicValuesDefault, alloc);
            DestroyValueArrayConstant(controllerBindingConstant->m_DynamicValuesConstant, alloc);
            alloc.Deallocate(controllerBindingConstant->m_SkeletonTQSMap);
            alloc.Deallocate(controllerBindingConstant);
        }
    }

    static void BindControllerTQSMap(const AnimationSetBindings& animationSetBindings,
        const mecanim::skeleton::Skeleton& skeleton,
        int nonConstantTransformBindingCount,
        const int* genericTransformBindingToBindingCache,
        const BoundTransform* bindingCache,
        bool hasTransformHierarchy,
        mecanim::animation::SkeletonTQSMap *tqsMap)
    {
        if (tqsMap == NULL)
            return;

        int rotationCount = -1;
        int positionCount = -1;
        int scaleCount = -1;

        for (int transformIter = 0; transformIter < nonConstantTransformBindingCount; transformIter++)
        {
            const TransformBinding& transformBinding = animationSetBindings.transformBindings[transformIter];
            int targetType = transformBinding.bindType;

            if (targetType == kBindTransformScale)
                scaleCount++;
            else if (targetType == kBindTransformRotation || targetType == kBindTransformEuler)
                rotationCount++;
            else if (targetType == kBindTransformPosition)
                positionCount++;

            int skIndex = -1;
            if (hasTransformHierarchy)
            {
                int transformIndex = genericTransformBindingToBindingCache[transformIter];
                if (transformIndex == -1)
                    continue;
                skIndex = bindingCache[transformIndex].bindIndexForSkeleton;
            }
            else
                skIndex = SkeletonFindNode(&skeleton, transformBinding.path);

            if (skIndex == -1)
                continue;

            if (targetType == kBindTransformScale)
                tqsMap[skIndex].m_SIndex = scaleCount;
            else if (targetType == kBindTransformRotation || targetType == kBindTransformEuler)
                tqsMap[skIndex].m_QIndex = rotationCount;
            else if (targetType == kBindTransformPosition)
                tqsMap[skIndex].m_TIndex = positionCount;
        }
    }

    static void GetDefaultTransformValues(Transform& targetTransform, int bindType, float* defaults)
    {
        if (bindType == kBindTransformPosition)
        {
            Vector3f pos = targetTransform.GetLocalPosition();
            memcpy(defaults, &pos, sizeof(pos));
        }
        else if (bindType == kBindTransformRotation)
        {
            Quaternionf rot = targetTransform.GetLocalRotation();
            memcpy(defaults, &rot, sizeof(rot));
        }
        else if (bindType == kBindTransformScale)
        {
            Vector3f scale = targetTransform.GetLocalScale();
            memcpy(defaults, &scale, sizeof(scale));
        }
        else if (bindType == kBindTransformEuler)
        {
            Quaternionf rot = targetTransform.GetLocalRotation();
            Vector3f euler = QuaternionToEuler(rot) * Rad2Deg(1.0F);

            memcpy(defaults, &euler, sizeof(euler));
        }
        else
        {
            AssertString("Bad");
        }
    }

    static void GetDefaultSkeletonPoseValues(const math::trsX& x, int bindType, float* defaults)
    {
        if (bindType == kBindTransformPosition)
            math::vstore3f(defaults, x.t);
        else if (bindType == kBindTransformRotation)
            math::vstore4f(defaults, x.q);
        else if (bindType == kBindTransformEuler)
            math::vstore3f(defaults, math::quatToEuler(x.q));
        else if (bindType == kBindTransformScale)
            math::vstore3f(defaults, x.s);
        else
        {
            AssertString("Bad");
        }
    }

    static int CalculateTransformBindingSizeBasedOnConstantOptimization(const AnimationSetBindings& animationSet, dynamic_array<BoundTransform> const& transformBindingCache, const int* genericTransformBindingToBindingCache, const mecanim::animation::AvatarConstant* avatar, bool hasTransformHierarchy)
    {
        // Generate Constant Default values
        ATTRIBUTE_ALIGN(ALIGN4F) float values[4];
        const mecanim::skeleton::Skeleton* skeleton = hasTransformHierarchy ? NULL : avatar->m_AvatarSkeleton.Get();
        const mecanim::skeleton::SkeletonPose* defaultPose = hasTransformHierarchy ? NULL : avatar->m_AvatarSkeletonPose.Get();

        int highestMismatch = animationSet.transformBindingsNonConstantSize;

        int constantDefaultValueIndex = 0;
        for (size_t i = animationSet.transformBindingsNonConstantSize; i < animationSet.transformBindingsSize; i++)
        {
            const TransformBinding& transformBinding = animationSet.transformBindings[i];
            int count = GetCurveCountForBindingType(transformBinding.bindType);

            if (hasTransformHierarchy)
            {
                // If we can't write the value, then we don't need it to be sampled either...
                // Thus we can simply assume it matches.
                int transformIndex = genericTransformBindingToBindingCache[i];
                if (transformIndex == -1)
                {
                    constantDefaultValueIndex += count;
                    continue;
                }
                Transform* targetTransform = transformBindingCache[transformIndex].transform;
                GetDefaultTransformValues(*targetTransform, transformBinding.bindType, values);
            }
            else
            {
                // get the default value from skeleton
                int skeletonIndex = SkeletonFindNode(skeleton, transformBinding.path);
                if (skeletonIndex == -1)
                {
                    constantDefaultValueIndex += count;
                    continue;
                }
                GetDefaultSkeletonPoseValues(defaultPose->m_X[skeletonIndex], transformBinding.bindType, values);
            }

            for (int k = 0; k < count; k++)
            {
                float clipConstant = animationSet.constantCurveValues[constantDefaultValueIndex];

                if (!CompareApproximately(clipConstant, values[k], 0.00001F))
                {
                    // printf_console("mismatch index: %d type: %d clipconstant/instance: %f vs %f.\n", i, bindType, animationSet.constantCurveValues[constantDefaultValueIndex], values[k]);
                    highestMismatch = i + 1;
                }

                constantDefaultValueIndex++;
            }
        }

        Assert((size_t)constantDefaultValueIndex == animationSet.constantCurveValueCount);
        return highestMismatch;
    }

    static void InvalidateBoundCurveArray(BoundCurve *boundCurveArray, int boundCurveCount, Object *object)
    {
        for (int iter = 0; iter < boundCurveCount; iter++)
        {
            if (boundCurveArray[iter].targetObject == object)
            {
                boundCurveArray[iter] = BoundCurve();
            }
        }
    }

    static void InvalidateTransformArray(Transform **transformArray, int transformCount, Object *object, InstanceID animatorInstanceID)
    {
        for (int iter = 0; iter < transformCount; iter++)
        {
            if (transformArray[iter] == object)
            {
            #if UNITY_EDITOR
                Transform* transform = transformArray[iter];

                while (transform != NULL && transform->GetGameObjectInstanceID() != animatorInstanceID)
                {
                    transform = transform->GetParent();
                }

                if (transform != NULL)
                {
                    Animator* animator = transform->QueryComponent<Animator>();
                    if (animator)
                    {
                        animator->LogWarning(Format("Transform '%s' has been deleted", transformArray[iter]->GetName()));
                    }
                }
            #endif
                transformArray[iter] = 0;
            }
        }
    }

    void InvalidateAvatarBindingObject(AvatarBindingConstant* bindingConstant, Object *object)
    {
        InvalidateTransformArray(bindingConstant->skeletonBindings, bindingConstant->skeletonBindingsCount, object, bindingConstant->animatorInstanceId);
        for (mecanim::uint32_t i = 0; i < bindingConstant->exposedTransformCount; i++)
        {
            if (bindingConstant->exposedTransforms[i].transform == object)
                bindingConstant->exposedTransforms[i].transform = NULL;
        }
    }

    static void InvalidateGenericBindingObject(AnimatorGenericBindingConstant* bindingConstant, Object *object)
    {
        InvalidateBoundCurveArray(bindingConstant->transformBindings, bindingConstant->transformBindingsCount, object);
        InvalidateBoundCurveArray(bindingConstant->genericBindings, bindingConstant->genericBindingsCount, object);
        InvalidateBoundCurveArray(bindingConstant->genericPPtrBindings, bindingConstant->genericPPtrBindingsCount, object);
        InvalidateBoundCurveArray(bindingConstant->genericIntBindings, bindingConstant->genericIntBindingsCount, object);
    }

    static void GenericBindingCallback(void *userData, void *sender, int eventType)
    {
        if (eventType ==  kWillDestroyEvent)
        {
            InvalidateGenericBindingObject(reinterpret_cast<AnimatorGenericBindingConstant *>(userData), reinterpret_cast<Object *>(sender));
        }
    }

    void AvatarBindingCallback(void *userData, void *sender, int eventType)
    {
        if (eventType ==  kWillDestroyEvent)
        {
            InvalidateAvatarBindingObject(reinterpret_cast<AvatarBindingConstant *>(userData), reinterpret_cast<Object *>(sender));
        }
    }

    static void RegisterBoundCurveArray(BoundCurve *boundCurveArray, int boundCurveCount, AnimatorGenericBindingConstant* bindingConstant)
    {
        for (int iter = 0; iter < boundCurveCount; iter++)
        {
            if (boundCurveArray[iter].targetObject != 0)
            {
                if (!boundCurveArray[iter].targetObject->HasEvent(GenericBindingCallback, bindingConstant))
                {
                    boundCurveArray[iter].targetObject->AddEvent(GenericBindingCallback, bindingConstant);
                }
            }
        }
    }

    template<typename TYPE> static void RegisterTransformArray(Transform **transformArray, int transformCount, TYPE* bindingConstant, Object::EventCallback* callback)
    {
        for (int iter = 0; iter < transformCount; iter++)
        {
            if (transformArray[iter] != 0)
            {
                if (!transformArray[iter]->HasEvent(callback, bindingConstant))
                {
                    transformArray[iter]->AddEvent(callback, bindingConstant);
                }
            }
        }
    }

    void RegisterAvatarBindingObjects(AvatarBindingConstant* bindingConstant)
    {
        RegisterTransformArray(bindingConstant->skeletonBindings, bindingConstant->skeletonBindingsCount, bindingConstant, AvatarBindingCallback);
        for (mecanim::uint32_t i = 0; i < bindingConstant->exposedTransformCount; i++)
        {
            if (bindingConstant->exposedTransforms[i].transform &&
                !bindingConstant->exposedTransforms[i].transform->HasEvent(AvatarBindingCallback, bindingConstant))
                bindingConstant->exposedTransforms[i].transform->AddEvent(AvatarBindingCallback, bindingConstant);
        }
    }

    static void RegisterGenericBindingObjects(AnimatorGenericBindingConstant* bindingConstant)
    {
        RegisterBoundCurveArray(bindingConstant->transformBindings, bindingConstant->transformBindingsCount, bindingConstant);
        RegisterBoundCurveArray(bindingConstant->genericBindings, bindingConstant->genericBindingsCount, bindingConstant);
        RegisterBoundCurveArray(bindingConstant->genericPPtrBindings, bindingConstant->genericPPtrBindingsCount, bindingConstant);
        RegisterBoundCurveArray(bindingConstant->genericIntBindings, bindingConstant->genericIntBindingsCount, bindingConstant);
    }

    static void UnregisterBoundCurveArray(BoundCurve *boundCurveArray, int boundCurveCount, AnimatorGenericBindingConstant* bindingConstant)
    {
        for (int iter = 0; iter < boundCurveCount; iter++)
        {
            if (boundCurveArray[iter].targetObject != 0)
            {
                boundCurveArray[iter].targetObject->RemoveEvent(GenericBindingCallback, bindingConstant);
            }
        }
    }

    template<typename TYPE> static void UnregisterTransformArray(Transform **transformArray, int transformCount, TYPE* bindingConstant, Object::EventCallback* callback)
    {
        for (int iter = 0; iter < transformCount; iter++)
        {
            if (transformArray[iter] != 0)
            {
                transformArray[iter]->RemoveEvent(callback, bindingConstant);
            }
        }
    }

    void UnregisterAvatarBindingObjects(AvatarBindingConstant* bindingConstant)
    {
        UnregisterTransformArray(bindingConstant->skeletonBindings, bindingConstant->skeletonBindingsCount, bindingConstant, AvatarBindingCallback);
        for (mecanim::uint32_t i = 0; i < bindingConstant->exposedTransformCount; i++)
        {
            if (bindingConstant->exposedTransforms[i].transform != NULL)
                bindingConstant->exposedTransforms[i].transform->RemoveEvent(AvatarBindingCallback, bindingConstant);
        }
    }

    void UnregisterGenericBindingObjects(AnimatorGenericBindingConstant* bindingConstant)
    {
        UnregisterBoundCurveArray(bindingConstant->transformBindings, bindingConstant->transformBindingsCount, bindingConstant);
        UnregisterBoundCurveArray(bindingConstant->genericBindings, bindingConstant->genericBindingsCount, bindingConstant);
        UnregisterBoundCurveArray(bindingConstant->genericPPtrBindings, bindingConstant->genericPPtrBindingsCount, bindingConstant);
        UnregisterBoundCurveArray(bindingConstant->genericIntBindings, bindingConstant->genericIntBindingsCount, bindingConstant);
    }

    /*
        void SetJobFencesForAnimatorBindings (const AnimatorGenericBindingConstant& genericBindings, const AvatarBindingConstant& avatarBindings, const JobFence& fence)
        {
            // Generic transform bindings
            for(int i = 0; i < genericBindings.transformBindingsCount; i++)
            {
                Transform* transform = static_cast<Transform*> (genericBindings.transformBindings[i].targetObject);
                if (transform != 0)
                    transform->SetJobFence(fence);
            }

            // Human Skeleton bindings
            for(int i = 0; i < avatarBindings.skeletonBindingsCount; i++)
            {
                if (avatarBindings.skeletonBindings[i] != 0)
                    avatarBindings.skeletonBindings[i]->SetJobFence(fence);
            }

            // Exposed transforms
            for (int i = 0; i < avatarBindings.exposedTransformCount; i++)
            {
                if (avatarBindings.exposedTransforms[i].transform != NULL)
                    avatarBindings.exposedTransforms[i].transform->SetJobFence(fence);
            }
        }
    */
    static Transform *humanMark = reinterpret_cast<Transform *>(std::numeric_limits<size_t>::max());

    static void humanMarkUp(mecanim::skeleton::Skeleton const &sk, int nodeIndex, Transform** bindings)
    {
        if (nodeIndex != -1)
        {
            bindings[nodeIndex] = humanMark;

            humanMarkUp(sk, sk.m_Node[nodeIndex].m_ParentId, bindings);
        }
    }

    AvatarBindingConstant* CreateAvatarBindingConstant(Transform& root, mecanim::animation::AvatarConstant const* avatar, mecanim::memory::Allocator& allocator)
    {
        SETPROFILERLABEL(AvatarBindingConstant);

        // Generate binding cache
        dynamic_array<BoundTransform> transformBindingCache(kMemTempAlloc);

        const mecanim::skeleton::Skeleton* skeleton = avatar->m_AvatarSkeleton.Get();

        GenerateTransformBindingMapRecursive(root, mecanim::crc32(), transformBindingCache, avatar, true);

        AvatarBindingConstant* constant = allocator.Construct<AvatarBindingConstant>();
        constant->exposedTransformCount = 0;
        constant->exposedTransforms = NULL;
        constant->animatorInstanceId = root.GetGameObjectInstanceID();

        constant->skeletonBindingsCount = skeleton ? skeleton->m_Count : 0;
        constant->skeletonBindings = allocator.ConstructArray<Transform*>(constant->skeletonBindingsCount);
        constant->defaultSkeletonPose = constant->skeletonBindingsCount > 0 ? mecanim::skeleton::CreateSkeletonPose<math::trsX>(skeleton, allocator) : 0;

        // just bind what human will effectively affect
        if (constant->skeletonBindingsCount != 0)
        {
            memset(constant->skeletonBindings, 0, sizeof(Transform*) * constant->skeletonBindingsCount);

            if (avatar->m_HumanSkeletonIndexCount > 0)
            {
                humanMarkUp(*skeleton, avatar->m_HumanSkeletonIndexArray[0], constant->skeletonBindings);

                for (mecanim::uint32_t humanSkIndexIter = 0; humanSkIndexIter < avatar->m_HumanSkeletonIndexCount; humanSkIndexIter++)
                {
                    int humanSkIndex = avatar->m_HumanSkeletonIndexArray[humanSkIndexIter];

                    if (humanSkIndex != -1)
                    {
                        constant->skeletonBindings[humanSkIndex] = humanMark;
                    }
                }
            }
        }

        for (mecanim::uint32_t i = 0; i < transformBindingCache.size(); i++)
        {
            int skeletonIndex = transformBindingCache[i].bindIndexForSkeleton;

            if (skeletonIndex != -1)
            {
                if (constant->skeletonBindings[skeletonIndex] == humanMark)
                {
                    constant->skeletonBindings[skeletonIndex] = transformBindingCache[i].transform;
                }
            }
        }

        for (mecanim::uint32_t i = 0; i < constant->skeletonBindingsCount; ++i)
        {
            if (constant->skeletonBindings[i] == humanMark)
                constant->skeletonBindings[i] = 0;
        }

        if (constant->skeletonBindingsCount > 0)
        {
            GetHumanTransformPropertyValues(*constant, *constant->defaultSkeletonPose);
        }

        RegisterAvatarBindingObjects(constant);

        return constant;
    }

    AvatarBindingConstant* CreateAvatarBindingConstantOpt(Transform& root, mecanim::animation::AvatarConstant const* avatar, mecanim::memory::Allocator& allocator)
    {
        SETPROFILERLABEL(AvatarBindingConstant);

        // Generate binding cache
        dynamic_array<BoundTransform> transformBindingCache(kMemTempAlloc);

        GenerateTransformBindingMapRecursive(root, mecanim::crc32(), transformBindingCache, avatar, false);

        mecanim::skeleton::Skeleton const* skeleton = avatar->m_AvatarSkeleton.Get();

        AvatarBindingConstant* constant = allocator.Construct<AvatarBindingConstant>();
        constant->skeletonBindingsCount = 0;
        constant->skeletonBindings = NULL;
        constant->defaultSkeletonPose = 0;

        // For the flattened transform, it's impossible to tell if the transform will be modified just by the curve which
        // is binded to it, because all its parent transforms will also affect it.
        // Since normally, there are only a few exposed transforms, the performance penalty will not be huge
        // if we don't care which exact properties of the transform are modified.
        int exposedCount = 0;
        int maxExposeCount = transformBindingCache.size();
        dynamic_array<ExposedTransform> exposedTransforms(maxExposeCount, kMemTempAlloc);
        for (int i = 0; i < maxExposeCount; ++i)
        {
            BoundTransform& boundTransform = transformBindingCache[i];
            bool isChildOfRoot = (boundTransform.transform->GetParent() == &root);
            if (!isChildOfRoot)
                continue;

            ExposedTransform& exposedTransform = exposedTransforms[exposedCount];
            exposedTransform.transform = boundTransform.transform;
            exposedTransform.skeletonIndex = -1;
            exposedTransform.skeletonIndexForUpdateTransform = -1;

            if (boundTransform.bindIndexForSkeleton != -1)
            {
                exposedTransform.skeletonIndex = boundTransform.bindIndexForSkeleton;
                exposedTransform.skeletonIndexForUpdateTransform = boundTransform.bindIndexForSkeleton;
            }

            // Handle special case: SkinnedMeshRenderer
            // We directly update the root bone to the Transform of the SkinnedMeshRenderer.
            SkinnedMeshRenderer* skin = boundTransform.transform->QueryComponent<SkinnedMeshRenderer>();
            if (skin)
            {
                const Mesh* mesh = skin->GetMesh();
                if (mesh && mesh->GetRootBonePathHash() != 0)
                {
                    int skinRootIndex = skeleton ? mecanim::skeleton::SkeletonFindNode(
                            skeleton, mesh->GetRootBonePathHash()) : -1;
                    if (skinRootIndex != -1)
                        exposedTransform.skeletonIndexForUpdateTransform = skinRootIndex;
                }
            }
            if (exposedTransform.skeletonIndexForUpdateTransform != -1)
                exposedCount++;
        }

        constant->exposedTransformCount = exposedCount;
        constant->exposedTransforms = allocator.ConstructArray<ExposedTransform>(constant->exposedTransformCount);
        for (int i = 0; i < exposedCount; i++)
            constant->exposedTransforms[i] = exposedTransforms[i];

        RegisterAvatarBindingObjects(constant);

        return constant;
    }

    void DestroyAvatarBindingConstant(AvatarBindingConstant* bindingConstant, mecanim::memory::Allocator& allocator)
    {
        if (bindingConstant != NULL)
        {
            UnregisterAvatarBindingObjects(bindingConstant);

            allocator.Deallocate(bindingConstant->skeletonBindings);
            allocator.Deallocate(bindingConstant->exposedTransforms);
            mecanim::skeleton::DestroySkeletonPose(bindingConstant->defaultSkeletonPose, allocator);
            allocator.Deallocate(bindingConstant);
        }
    }

    AnimatorGenericBindingConstant* CreateAnimatorGenericBindings(const AnimationSetBindings& animationSet, Transform& root, const mecanim::animation::AvatarConstant* avatar, bool allowConstantClipSamplingOptimization, mecanim::memory::Allocator& allocator, Animator& animator)
    {
        SETPROFILERLABEL(AnimatorGenericBindingConstant);

        GenericAnimationBindingCache& bindingCache = GetGenericAnimationBindingCache();

        const mecanim::skeleton::Skeleton* skeleton = avatar->m_AvatarSkeleton.Get();

        // Generate binding cache
        dynamic_array<BoundTransform> transformBindingCache(kMemTempAlloc);
        dynamic_array<int> genericTransformBindingToBindingCache(kMemTempAlloc);
        dynamic_array<std::pair<Transform *, BindingHash> > genericTransform(kMemTempAlloc);

        GenerateTransformBindingMapRecursive(root, mecanim::crc32(), transformBindingCache, avatar, true);

        // Map from animation set to binding cache index
        genericTransformBindingToBindingCache.resize_uninitialized(animationSet.transformBindingsSize);

        for (size_t i = 0; i < animationSet.transformBindingsSize; i++)
        {
            genericTransformBindingToBindingCache[i] = FindTransformBindingIndexByBindingHash(transformBindingCache, animationSet.transformBindings[i].path);

            if (genericTransformBindingToBindingCache[i] != -1 && avatar->isHuman() && transformBindingCache[genericTransformBindingToBindingCache[i]].bindIndexForSkeleton != -1)
            {
                Assert(transformBindingCache[genericTransformBindingToBindingCache[i]].bindIndexForSkeleton < avatar->m_HumanSkeletonReverseIndexCount);
                if (avatar->m_HumanSkeletonReverseIndexArray[transformBindingCache[genericTransformBindingToBindingCache[i]].bindIndexForSkeleton] != -1)
                {
                    genericTransform.push_back(std::make_pair(transformBindingCache[genericTransformBindingToBindingCache[i]].transform, transformBindingCache[genericTransformBindingToBindingCache[i]].pathHash));
                    genericTransformBindingToBindingCache[i] = -1;
                }
            }
        }
#if UNITY_EDITOR
        animator.HandleGenericBindingError(genericTransform, false);
#endif

        // Calculate Transform bindings that are actually animating (Constant curve values can be removed if they match the default values)
        // Generate new reduced ValueArrayCount from it.
        int nonConstantTransformBindingCount = allowConstantClipSamplingOptimization ? CalculateTransformBindingSizeBasedOnConstantOptimization(animationSet, transformBindingCache, genericTransformBindingToBindingCache.begin(), avatar, true)
            : animationSet.transformBindingsSize;
        int optimizedValueArrayConstantCount = animationSet.animationSet->m_DynamicFullValuesConstant->m_Count - (animationSet.transformBindingsSize - nonConstantTransformBindingCount);
        allowConstantClipSamplingOptimization =  allowConstantClipSamplingOptimization && ((size_t)nonConstantTransformBindingCount == animationSet.transformBindingsNonConstantSize);

        size_t size = allocator.AlignForAllocate<AnimatorGenericBindingConstant>();
        size = allocator.AlignForAllocate<BoundCurve>(size, nonConstantTransformBindingCount);
        size = allocator.AlignForAllocate<BoundCurve>(size, animationSet.genericBindingsSize);
        size = allocator.AlignForAllocate<BoundCurve>(size, animationSet.genericPPtrBindingsSize);
        size = allocator.AlignForAllocate<BoundCurve>(size, animationSet.genericIntBindingsSize);

        // Allocate this structure on a cache line boundary to minimize cache miss
        mecanim::memory::InPlaceAllocator inPlaceAllocator(allocator.Allocate(size, 64), size);

        AnimatorGenericBindingConstant* constant = inPlaceAllocator.Construct<AnimatorGenericBindingConstant>();
        constant->exposedTransformScaleChangedArray = NULL;

        constant->transformBindingsCount = nonConstantTransformBindingCount;
        constant->transformBindings = inPlaceAllocator.ConstructArray<BoundCurve>(constant->transformBindingsCount);

        constant->rootPositionValueIndex = -1;
        constant->rootRotationValueIndex = -1;
        constant->rootScaleValueIndex = -1;

        constant->genericBindingsCount = animationSet.genericBindingsSize;
        constant->genericBindings = inPlaceAllocator.ConstructArray<BoundCurve>(constant->genericBindingsCount);

        constant->genericPPtrBindingsCount = animationSet.genericPPtrBindingsSize;
        constant->genericPPtrBindings = inPlaceAllocator.ConstructArray<BoundCurve>(constant->genericPPtrBindingsCount);

        constant->genericIntBindingsCount = animationSet.genericIntBindingsSize;
        constant->genericIntBindings = inPlaceAllocator.ConstructArray<BoundCurve>(constant->genericIntBindingsCount);

        constant->allowConstantClipSamplingOptimization = allowConstantClipSamplingOptimization;

        int rotationIndex = 0;
        int positionIndex = 0;
        int scaleIndex = 0;

        // Bind Transforms
        for (size_t i = 0; i < constant->transformBindingsCount; i++)
        {
            int transformIndex = genericTransformBindingToBindingCache[i];
            constant->transformBindings[i].targetType = animationSet.transformBindings[i].bindType;

            if (transformIndex != -1)
            {
                constant->transformBindings[i].targetObject = transformBindingCache[transformIndex].transform;
            }
            else
            {
                constant->transformBindings[i].targetObject = NULL;
            }

            bool isRoot = transformIndex != -1 ? &root == transformBindingCache[transformIndex].transform : false;

            if (animationSet.transformBindings[i].bindType == kBindTransformPosition)
            {
                if (isRoot)
                    constant->rootPositionValueIndex = positionIndex;

                positionIndex++;
            }
            else if (animationSet.transformBindings[i].bindType == kBindTransformRotation || animationSet.transformBindings[i].bindType == kBindTransformEuler)
            {
                if (isRoot)
                    constant->rootRotationValueIndex = rotationIndex;

                rotationIndex++;
            }
            else if (animationSet.transformBindings[i].bindType == kBindTransformScale)
            {
                if (isRoot)
                    constant->rootScaleValueIndex = scaleIndex;

                scaleIndex++;
            }
        }

        // Bind Generic properties
        for (size_t i = 0; i < constant->genericBindingsCount; i++)
        {
            constant->genericBindings[i].targetObject = NULL;
            constant->genericBindings[i].targetType = kUnbound;

            int index = FindTransformBindingIndexByBindingHash(transformBindingCache, animationSet.genericBindings[i].path);
            if (index != -1)
                bindingCache.BindGeneric(animationSet.genericBindings[i], *transformBindingCache[index].transform, constant->genericBindings[i]);
        }

        // Bind Generic PPtr properties
        for (size_t i = 0; i < constant->genericPPtrBindingsCount; i++)
        {
            constant->genericPPtrBindings[i].targetObject = NULL;
            constant->genericPPtrBindings[i].targetType = kUnbound;

            int index = FindTransformBindingIndexByBindingHash(transformBindingCache, animationSet.genericPPtrBindings[i].path);
            if (index != -1)
                bindingCache.BindPPtrGeneric(animationSet.genericPPtrBindings[i], *transformBindingCache[index].transform, constant->genericPPtrBindings[i]);
        }

        // Bind Generic int properties
        for (size_t i = 0; i < constant->genericIntBindingsCount; i++)
        {
            constant->genericIntBindings[i].targetObject = NULL;
            constant->genericIntBindings[i].targetType = kUnbound;

            int index = FindTransformBindingIndexByBindingHash(transformBindingCache, animationSet.genericIntBindings[i].path);
            if (index != -1)
                bindingCache.BindGeneric(animationSet.genericIntBindings[i], *transformBindingCache[index].transform, constant->genericIntBindings[i]);
        }

        constant->controllerBindingConstant = CreateControllerBindingConstant(animationSet.animationSet, animationSet.animationSet->m_DynamicFullValuesConstant, optimizedValueArrayConstantCount, avatar, allocator);

        // Gravity weight should must be in both optimized and non-optimized ValueArray
        Assert(animationSet.animationSet->m_GravityWeightIndex == -1 || animationSet.animationSet->m_GravityWeightIndex < (int)constant->controllerBindingConstant->m_DynamicValuesDefault->m_FloatCount);

        // Bind Controller skeleton to dynamic value array
        BindControllerTQSMap(animationSet, *skeleton, nonConstantTransformBindingCount, genericTransformBindingToBindingCache.begin(), transformBindingCache.begin(), true, constant->controllerBindingConstant->m_SkeletonTQSMap);

        RegisterGenericBindingObjects(constant);

        InitializeDefaultValues(*constant, avatar, true);

        return constant;
    }

    static void BuildSkeletonScaleChangedArray(const mecanim::animation::AvatarConstant& avatar, const AnimationSetBindings& animationSet, UInt8* skeletonScaleChangedArray)
    {
        bool isHuman = avatar.isHuman();
        const mecanim::skeleton::Skeleton* skeleton = avatar.m_AvatarSkeleton.Get();

        for (size_t i = 0; i < animationSet.transformBindingsSize; i++)
        {
            int skeletonIndex = SkeletonFindNode(skeleton, animationSet.transformBindings[i].path);
            if (skeletonIndex != -1 && animationSet.transformBindings[i].bindType == kBindTransformScale)
                skeletonScaleChangedArray[skeletonIndex] = 1;
        }

        for (size_t i = 1; i < skeleton->m_Count; i++)
        {
            if (isHuman && avatar.m_HumanSkeletonReverseIndexArray[i] != -1)
            {
                // no scale for human bones
                skeletonScaleChangedArray[i] = 0;
                continue;
            }
            if (skeletonScaleChangedArray[skeleton->m_Node[i].m_ParentId] == 1)
            {
                skeletonScaleChangedArray[i] = 1;
            }
        }
    }

    static void CalculateExposedTransformScaleChanges(const mecanim::animation::AvatarConstant& avatar, const AnimationSetBindings& animationSet, const AvatarBindingConstant& avatarBinding, AnimatorGenericBindingConstant* constant)
    {
        dynamic_array<UInt8> skeletonScaleChangedArray(kMemTempAlloc);
        skeletonScaleChangedArray.resize_initialized(avatar.m_AvatarSkeleton->m_Count, 0);
        BuildSkeletonScaleChangedArray(avatar, animationSet, skeletonScaleChangedArray.begin());

        for (size_t i = 0; i < avatarBinding.exposedTransformCount; i++)
        {
            ExposedTransform& exposedTransform = avatarBinding.exposedTransforms[i];
            if (exposedTransform.skeletonIndex != -1)
                constant->exposedTransformScaleChangedArray[i] = skeletonScaleChangedArray[exposedTransform.skeletonIndex];
            else
                constant->exposedTransformScaleChangedArray[i] = false;
        }
    }

    AnimatorGenericBindingConstant* CreateAnimatorGenericBindingsOpt(const AnimationSetBindings& animationSet, Transform& root, const mecanim::animation::AvatarConstant* avatar, const AvatarBindingConstant* avatarBinding, bool allowConstantClipSamplingOptimization, mecanim::memory::Allocator& allocator, Animator& animator)
    {
        GenericAnimationBindingCache& bindingCache = GetGenericAnimationBindingCache();
        const mecanim::skeleton::Skeleton* skeleton = avatar->m_AvatarSkeleton.Get();

        dynamic_array<BoundTransform> transformBindingCache(kMemTempAlloc);
        dynamic_array<std::pair<Transform *, BindingHash> > genericTransform(kMemTempAlloc);

        // BoundTransform.pathHash:                 hash of flattened path
        // BoundTransform.bindIndexForSkeleton:     corresponding skeleton index
        GenerateTransformBindingMapRecursive(root, mecanim::crc32(), transformBindingCache, avatar, false);

        // Calculate Transform bindings that are actually animating (Constant curve values can be removed if they match the default values)
        // Generate new reduced ValueArrayCount from it.
        int nonConstantTransformBindingCount = allowConstantClipSamplingOptimization ?  CalculateTransformBindingSizeBasedOnConstantOptimization(animationSet, transformBindingCache, NULL, avatar, false)
            : animationSet.transformBindingsSize;
        int optimizedValueArrayConstantCount = animationSet.animationSet->m_DynamicFullValuesConstant->m_Count - (animationSet.transformBindingsSize - nonConstantTransformBindingCount);
        allowConstantClipSamplingOptimization = allowConstantClipSamplingOptimization && (nonConstantTransformBindingCount == (int)animationSet.transformBindingsNonConstantSize);

        size_t size = allocator.AlignForAllocate<AnimatorGenericBindingConstant>();
        size = allocator.AlignForAllocate<UInt8>(size, avatarBinding->exposedTransformCount);
        size = allocator.AlignForAllocate<BoundCurve>(size, animationSet.genericBindingsSize);
        size = allocator.AlignForAllocate<BoundCurve>(size, animationSet.genericPPtrBindingsSize);
        size = allocator.AlignForAllocate<BoundCurve>(size, animationSet.genericIntBindingsSize);

        // Allocate this structure on a cache line boundary to minimize cache miss
        mecanim::memory::InPlaceAllocator inPlaceAllocator(allocator.Allocate(size, 64), size);

        AnimatorGenericBindingConstant* constant = inPlaceAllocator.Construct<AnimatorGenericBindingConstant>();
        constant->exposedTransformScaleChangedArray = inPlaceAllocator.ConstructArray<UInt8>(avatarBinding->exposedTransformCount);
        CalculateExposedTransformScaleChanges(*avatar, animationSet, *avatarBinding, constant);

        constant->transformBindingsCount = 0;
        constant->transformBindings = NULL;

        constant->rootPositionValueIndex = -1;
        constant->rootRotationValueIndex = -1;
        constant->rootScaleValueIndex = -1;

        constant->genericBindingsCount = animationSet.genericBindingsSize;
        constant->genericBindings = inPlaceAllocator.ConstructArray<BoundCurve>(constant->genericBindingsCount);

        constant->genericPPtrBindingsCount = animationSet.genericPPtrBindingsSize;
        constant->genericPPtrBindings = inPlaceAllocator.ConstructArray<BoundCurve>(constant->genericPPtrBindingsCount);

        constant->genericIntBindingsCount = animationSet.genericIntBindingsSize;
        constant->genericIntBindings = inPlaceAllocator.ConstructArray<BoundCurve>(constant->genericIntBindingsCount);

        constant->allowConstantClipSamplingOptimization = allowConstantClipSamplingOptimization;

        // Bind Generic properties
        for (size_t i = 0; i < constant->genericBindingsCount; i++)
        {
            constant->genericBindings[i].targetObject = NULL;
            constant->genericBindings[i].targetType = kUnbound;

            BindingHash fullPath = animationSet.genericBindings[i].path;
            int skeletonIndex = mecanim::skeleton::SkeletonFindNode(skeleton, fullPath);

            int transformIndex = FindTransformBindingIndexBySkeletonIndex(transformBindingCache, skeletonIndex);
            if (transformIndex != -1)
                bindingCache.BindGeneric(animationSet.genericBindings[i], *transformBindingCache[transformIndex].transform, constant->genericBindings[i]);
        }

        for (size_t i = 0; i < animationSet.transformBindingsSize; i++)
        {
            Transform* transform = NULL;
            BindingHash fullPath = animationSet.transformBindings[i].path;
            int skeletonIndex = mecanim::skeleton::SkeletonFindNode(skeleton, fullPath);
            if (skeletonIndex != -1 && avatar->isHuman() && avatar->m_HumanSkeletonReverseIndexArray[skeletonIndex] != -1)
                genericTransform.push_back(std::make_pair(transform, fullPath));
        }

#if UNITY_EDITOR
        animator.HandleGenericBindingError(genericTransform, true);
#endif

        // Bind Generic PPtr properties
        for (size_t i = 0; i < constant->genericPPtrBindingsCount; i++)
        {
            constant->genericPPtrBindings[i].targetObject = NULL;
            constant->genericPPtrBindings[i].targetType = kUnbound;

            BindingHash fullPath = animationSet.genericPPtrBindings[i].path;
            int skeletonIndex = mecanim::skeleton::SkeletonFindNode(skeleton, fullPath);

            int transformIndex = FindTransformBindingIndexBySkeletonIndex(transformBindingCache, skeletonIndex);
            if (transformIndex != -1)
                bindingCache.BindPPtrGeneric(animationSet.genericPPtrBindings[i], *transformBindingCache[transformIndex].transform, constant->genericPPtrBindings[i]);
        }

        // Bind Generic Int properties
        for (size_t i = 0; i < constant->genericIntBindingsCount; i++)
        {
            constant->genericIntBindings[i].targetObject = NULL;
            constant->genericIntBindings[i].targetType = kUnbound;

            BindingHash fullPath = animationSet.genericIntBindings[i].path;
            int skeletonIndex = mecanim::skeleton::SkeletonFindNode(skeleton, fullPath);

            int transformIndex = FindTransformBindingIndexBySkeletonIndex(transformBindingCache, skeletonIndex);
            if (transformIndex != -1)
                bindingCache.BindGeneric(animationSet.genericIntBindings[i], *transformBindingCache[transformIndex].transform, constant->genericIntBindings[i]);
        }

        constant->controllerBindingConstant = CreateControllerBindingConstant(animationSet.animationSet, animationSet.animationSet->m_DynamicFullValuesConstant, optimizedValueArrayConstantCount, avatar, allocator);

        // Gravity weight should must be in both optimized and non-optimized ValueArray
        Assert(animationSet.animationSet->m_GravityWeightIndex == -1 || animationSet.animationSet->m_GravityWeightIndex < (mecanim::int32_t)constant->controllerBindingConstant->m_DynamicValuesDefault->m_FloatCount);

        // Bind Controller skeleton to dynamic value array
        BindControllerTQSMap(animationSet, *skeleton, nonConstantTransformBindingCount, NULL, transformBindingCache.begin(), false, constant->controllerBindingConstant->m_SkeletonTQSMap);

        RegisterGenericBindingObjects(constant);

        InitializeDefaultValues(*constant, avatar, false);

        return constant;
    }

    static inline void DeallocateBoundCurveArray(BoundCurve* array, size_t size, mecanim::memory::Allocator& allocator)
    {
#if ENABLE_DOTNET
        for (size_t i = 0; i < size; ++i)
        {
            if (array[i].targetObject != NULL && array[i].targetObject->GetType() == TypeOf<MonoBehaviour>())
            {
                MonoBehaviour* beh = reinterpret_cast<MonoBehaviour *>(array[i].targetObject);
                if (beh != NULL)
                {
                    WinRT::AnimationUnbindField(beh->GetInstance(), array[i].targetPtr);
                }
            }
        }
#endif
    }

    void DestroyAnimatorGenericBindings(AnimatorGenericBindingConstant* bindingConstant, mecanim::memory::Allocator& allocator)
    {
        if (bindingConstant != NULL)
        {
            UnregisterGenericBindingObjects(bindingConstant);

            DestroyControllerBindingConstant(bindingConstant->controllerBindingConstant, allocator);
            DeallocateBoundCurveArray(bindingConstant->genericPPtrBindings, bindingConstant->genericPPtrBindingsCount, allocator);
            DeallocateBoundCurveArray(bindingConstant->genericIntBindings, bindingConstant->genericIntBindingsCount, allocator);
            DeallocateBoundCurveArray(bindingConstant->transformBindings, bindingConstant->transformBindingsCount, allocator);
            DeallocateBoundCurveArray(bindingConstant->genericBindings, bindingConstant->genericBindingsCount, allocator);
            allocator.Deallocate(bindingConstant);
        }
    }

    mecanim::animation::SkeletonTQSMap *CreateAvatarTQSMap(const mecanim::animation::AvatarConstant* avatar, const AnimationSetBindings& animationSet, mecanim::memory::Allocator& allocator)
    {
        mecanim::animation::SkeletonTQSMap *ret = allocator.ConstructArray<mecanim::animation::SkeletonTQSMap>(avatar->m_AvatarSkeleton->m_Count);
        BindControllerTQSMap(animationSet, *avatar->m_AvatarSkeleton.Get(), animationSet.transformBindingsSize, 0, 0, false, ret);
        return ret;
    }

    static void CallAwakeFromLoadInLoopIfNecessary(Object*& lastAwakeFromLoadObject, const BoundCurve& binding)
    {
        // When applying multiple properties to the same object in a row.
        // Call AwakeFromLoad / SetDirty only once.
        // -> We keep track of the last object we called AwakeFromLoad on, if the object is different from the previous one, we call Awake and continue
        if (lastAwakeFromLoadObject != binding.targetObject)
        {
            if (lastAwakeFromLoadObject != NULL)
                BoundCurveValueAwakeGeneric(*lastAwakeFromLoadObject);
            lastAwakeFromLoadObject = binding.targetObject;
        }
    }

    ////// Get & Set Values
    void SetGenericPPtrPropertyValues(const AnimatorGenericBindingConstant& bindings, const mecanim::ValueArray &values)
    {
        //@TODO: if you have an object animated by pptr & float properties, we now call AwakeFromLoad twice. It would probably be a good idea to call it only once.

        Object* lastAwakeFromLoadObject = NULL;
        for (size_t bindIndex = 0; bindIndex != bindings.genericPPtrBindingsCount; bindIndex++)
        {
            const BoundCurve& binding = bindings.genericPPtrBindings[bindIndex];
            int targetType = binding.targetType;

            if (targetType == kUnbound)
                continue;

            Assert(targetType >= kMinSinglePropertyBinding);

            mecanim::int32_t value = 0;
            const size_t intValueIndex = PPtrCurveIndexToIntValueIndex(bindIndex, bindings);
            values.ReadData(value, intValueIndex);
            if (SetBoundCurveInstanceIDValue(binding, InstanceID_Make(value)))
            {
                // When applying multiple properties to the same object in a row.
                // Call AwakeFromLoad / SetDirty only once.
                CallAwakeFromLoadInLoopIfNecessary(lastAwakeFromLoadObject, binding);
            }
        }

        if (lastAwakeFromLoadObject != NULL)
            BoundCurveValueAwakeGeneric(*lastAwakeFromLoadObject);
    }

    ////// Get & Set Values
    void SetGenericIntPropertyValues(const AnimatorGenericBindingConstant& bindings, const mecanim::ValueArray &values)
    {
        //@TODO: if you have an object animated by int & float properties, we now call AwakeFromLoad twice. It would probably be a good idea to call it only once.
        Object* lastAwakeFromLoadObject = NULL;
        for (size_t bindIndex = 0; bindIndex != bindings.genericIntBindingsCount; bindIndex++)
        {
            const BoundCurve& binding = bindings.genericIntBindings[bindIndex];
            int targetType = binding.targetType;

            if (targetType == kUnbound)
                continue;

            Assert(targetType >= kMinSinglePropertyBinding);

            mecanim::int32_t value = 0;
            values.ReadData(value, bindIndex);
            if (SetBoundCurveFloatValue(binding, value))
            {
                // When applying multiple properties to the same object in a row.
                // Call AwakeFromLoad / SetDirty only once.
                CallAwakeFromLoadInLoopIfNecessary(lastAwakeFromLoadObject, binding);
            }
        }

        if (lastAwakeFromLoadObject != NULL)
            BoundCurveValueAwakeGeneric(*lastAwakeFromLoadObject);
    }

    void SetGenericFloatPropertyValues(const AnimatorGenericBindingConstant& bindings, const mecanim::ValueArray &values)
    {
        Object* lastAwakeFromLoadObject = NULL;
        for (size_t bindIndex = 0; bindIndex != bindings.genericBindingsCount; bindIndex++)
        {
            const BoundCurve& binding = bindings.genericBindings[bindIndex];
            int targetType = binding.targetType;

            if (targetType == kUnbound)
                continue;

            Assert(targetType >= kMinSinglePropertyBinding);

            float value = 0.0F;
            values.ReadData(value, bindIndex);

            if (SetBoundCurveFloatValue(binding, value))
            {
                // When applying multiple properties to the same object in a row.
                // Call AwakeFromLoad / SetDirty only once.
                CallAwakeFromLoadInLoopIfNecessary(lastAwakeFromLoadObject, binding);
            }
        }

        if (lastAwakeFromLoadObject != NULL)
            BoundCurveValueAwakeGeneric(*lastAwakeFromLoadObject);
    }

    static void SetTransformsSetDirty(const AnimatorGenericBindingConstant& bindings, const AvatarBindingConstant& avatarBindings)
    {
        // In The editor we set dirty so the inspector UI is always up to date
        #if UNITY_EDITOR
        dynamic_array<Object*> transformsToDirty(kMemTempAlloc);
        transformsToDirty.reserve(avatarBindings.skeletonBindingsCount + bindings.transformBindingsCount);

        for (int bindIndex = 0; bindIndex != avatarBindings.skeletonBindingsCount; bindIndex++)
        {
            Transform* targetTransform = avatarBindings.skeletonBindings[bindIndex];
            if (targetTransform)
                transformsToDirty.push_back(targetTransform);
        }

        for (int bindIndex = 0; bindIndex != bindings.transformBindingsCount; bindIndex++)
        {
            const BoundCurve& binding = bindings.transformBindings[bindIndex];
            Transform* targetTransform = reinterpret_cast<Transform*>(binding.targetObject);
            if (targetTransform)
                transformsToDirty.push_back(targetTransform);
        }

        Object::BatchSetPersistentDirty(transformsToDirty.data(), transformsToDirty.size());
        #endif
    }

    void SetTransformPropertyApplyMainThread(Transform& root, const AnimatorGenericBindingConstant& bindings, const AvatarBindingConstant& avatarBindings)
    {
        root.QueueChanges();
        SetTransformsSetDirty(bindings, avatarBindings);
    }

    void GetHumanTransformPropertyValues(const AvatarBindingConstant& bindings, mecanim::skeleton::SkeletonPose& pose)
    {
        int transformCount = bindings.skeletonBindingsCount;
        Assert((int)pose.m_Count == transformCount);

        for (int i = 0; i < transformCount; i++)
        {
            Transform* transform = bindings.skeletonBindings[i];

            if (transform != NULL)
            {
                pose.m_X[i].t = Vector3fTofloat3(transform->GetLocalPosition());
                pose.m_X[i].q = QuaternionfTofloat4(transform->GetLocalRotation());
            }
        }
    }

    void SetHumanTransformPropertyValues(const AvatarBindingConstant& bindings, const mecanim::skeleton::SkeletonPose& pose, bool skipRoot, TransformChangeSystemMask systemMask)
    {
        int transformCount = bindings.skeletonBindingsCount;
        Assert((int)pose.m_Count == transformCount);

        for (int i = skipRoot ? 1 : 0; i < transformCount; i++)
        {
            Transform* transform = bindings.skeletonBindings[i];
            if (transform != NULL)
            {
                transform->SetLocalPositionWithoutNotification(pose.m_X[i].t, systemMask);
                transform->SetLocalRotationWithoutNotification(pose.m_X[i].q, systemMask);
            }
        }
    }

    static void SetFlattenedTransformsSetDirty(const AvatarBindingConstant& avatarBindings)
    {
        // In The editor we set dirty so the inspector UI is always up to date
        #if UNITY_EDITOR
        for (int bindIndex = 0; bindIndex != avatarBindings.exposedTransformCount; bindIndex++)
        {
            const ExposedTransform& exposed = avatarBindings.exposedTransforms[bindIndex];
            if (exposed.transform)
                exposed.transform->SetDirty();
        }
        #endif
    }

    void SetFlattenedSkeletonTransformsMainThread(Transform& root, const AvatarBindingConstant& avatarBinding)
    {
        root.QueueChanges();
        SetFlattenedTransformsSetDirty(avatarBinding);
    }

    bool HasGenericRootTransformPropertyValues(const AnimatorGenericBindingConstant& bindings, bool scaleOnly)
    {
        return (!scaleOnly && (bindings.rootPositionValueIndex != -1 || bindings.rootRotationValueIndex != -1)) || bindings.rootScaleValueIndex != -1;
    }

    void SetGenericRootTransformPropertyValues(const AnimatorGenericBindingConstant& bindings, const mecanim::ValueArray &values, Transform &rootTransform, bool scaleOnly, bool animatePhysics)
    {
        TransformChangeSystemMask systemMask = animatePhysics ? GetTransformChangeDispatch().GetChangeMaskForInterest(TransformChangeDispatch::kInterestedInPhysicsAnimation) : TransformChangeSystemMask(0);

        if (!scaleOnly)
        {
            if (bindings.rootPositionValueIndex != -1)
            {
                math::float3 value = values.ReadPosition(bindings.rootPositionValueIndex);
                rootTransform.SetLocalPositionWithoutNotification(value, systemMask);
            }

            if (bindings.rootRotationValueIndex != -1)
            {
                math::float4 value = values.ReadQuaternion(bindings.rootRotationValueIndex);
                rootTransform.SetLocalRotationWithoutNotification(value, systemMask);
            }
        }

        if (bindings.rootScaleValueIndex != -1)
        {
            math::float3 value = values.ReadScale(bindings.rootScaleValueIndex);
            rootTransform.SetLocalScaleWithoutNotification(value, systemMask);
        }

        rootTransform.QueueChanges();

        // In The editor we set dirty so the inspector UI is always up to date
        #if UNITY_EDITOR
        rootTransform.SetDirty();
        #endif
    }

    void SetGenericTransformPropertyValues(const AnimatorGenericBindingConstant& bindings, const mecanim::ValueArray &values, Transform *skipTransform, TransformChangeSystemMask systemMask)
    {
        int rotationIndex = 0;
        int positionIndex = 0;
        int scaleIndex = 0;

        for (size_t bindIndex = 0; bindIndex != bindings.transformBindingsCount; bindIndex++)
        {
            const BoundCurve& binding = bindings.transformBindings[bindIndex];
            int targetType = binding.targetType;

            Transform* targetTransform = reinterpret_cast<Transform*>(binding.targetObject);

            if (targetType == kBindTransformRotation || targetType == kBindTransformEuler)
            {
                if (targetTransform && (targetTransform  != skipTransform))
                {
                    math::float4 value = values.ReadQuaternion(rotationIndex);
                    targetTransform->SetLocalRotationWithoutNotification(value, systemMask);
                }

                rotationIndex++;
            }
            else if (targetType == kBindTransformPosition)
            {
                if (targetTransform && (targetTransform  != skipTransform))
                {
                    math::float3 value = values.ReadPosition(positionIndex);
                    targetTransform->SetLocalPositionWithoutNotification(value, systemMask);
                }

                positionIndex++;
            }
            else if (targetType == kBindTransformScale)
            {
                if (targetTransform && (targetTransform  != skipTransform))
                {
                    math::float3 value = values.ReadScale(scaleIndex);
                    targetTransform->SetLocalScaleWithoutNotification(value, systemMask);
                }

                scaleIndex++;
            }
        }
    }

    static void GetDefaultTransformValues(const BoundCurve* transformBindings, size_t transformBindingsCount, mecanim::ValueArray &values)
    {
        int positionIndex = 0;
        int rotationIndex = 0;
        int scaleIndex = 0;

        for (size_t bindIndex = 0; bindIndex < transformBindingsCount; bindIndex++)
        {
            const BoundCurve& binding = transformBindings[bindIndex];

            Transform* targetTransform = reinterpret_cast<Transform*>(binding.targetObject);
            if (binding.targetType == kBindTransformPosition)
            {
                if (targetTransform)
                    values.WritePosition(Vector3fTofloat3(targetTransform->GetLocalPosition()), positionIndex);

                positionIndex++;
            }
            else if (binding.targetType == kBindTransformRotation || binding.targetType == kBindTransformEuler)
            {
                if (targetTransform)
                    values.WriteQuaternion(QuaternionfTofloat4(targetTransform->GetLocalRotation()), rotationIndex);

                rotationIndex++;
            }
            else if (binding.targetType == kBindTransformScale)
            {
                if (targetTransform)
                    values.WriteScale(Vector3fTofloat3(targetTransform->GetLocalScale()), scaleIndex);

                scaleIndex++;
            }
        }
    }

    static void GetDefaultGenericFloatValues(const AnimatorGenericBindingConstant& bindings, mecanim::ValueArray &values)
    {
        for (size_t bindIndex = 0; bindIndex < bindings.genericBindingsCount; bindIndex++)
        {
            const BoundCurve& binding = bindings.genericBindings[bindIndex];
            int targetType = binding.targetType;
            if (targetType == kUnbound)
                continue;

            Assert(targetType >= kMinSinglePropertyBinding);

            float value = GetBoundCurveFloatValue(binding);

            values.WriteData(value, bindIndex);
        }
    }

    static void GetDefaultGenericPPtrValues(const AnimatorGenericBindingConstant& bindings, mecanim::ValueArray &values)
    {
        for (size_t bindIndex = 0; bindIndex < bindings.genericPPtrBindingsCount; bindIndex++)
        {
            const BoundCurve& binding = bindings.genericPPtrBindings[bindIndex];
            int targetType = binding.targetType;
            if (targetType == kUnbound)
                continue;

            Assert(targetType >= kMinSinglePropertyBinding);

            mecanim::int32_t value = InstanceID_AsSInt32Ref(GetBoundCurveInstanceIDValue(binding));
            const size_t intValueIndex = PPtrCurveIndexToIntValueIndex(bindIndex, bindings);
            values.WriteData(value, intValueIndex);
        }
    }

    static void GetDefaultGenericIntValues(const AnimatorGenericBindingConstant& bindings, mecanim::ValueArray &values)
    {
        for (size_t bindIndex = 0; bindIndex < bindings.genericIntBindingsCount; bindIndex++)
        {
            const BoundCurve& binding = bindings.genericIntBindings[bindIndex];
            int targetType = binding.targetType;
            if (targetType == kUnbound)
                continue;

            Assert(targetType >= kMinSinglePropertyBinding);

            mecanim::int32_t value = (int)GetBoundCurveFloatValue(binding);

            values.WriteData(value, bindIndex);
        }
    }

    static void InitializeDefaultValues(const Animation::AnimatorGenericBindingConstant& genericBinding, const mecanim::animation::AvatarConstant* avatar, bool hasTransformHierarchy)
    {
        const mecanim::animation::ControllerBindingConstant& controllerBindingConstant = *genericBinding.controllerBindingConstant;
        const mecanim::skeleton::Skeleton* skeleton = avatar->m_AvatarSkeleton.Get();
        const mecanim::skeleton::SkeletonPose* skeletonPose = avatar->m_AvatarSkeletonPose.Get();

        if (hasTransformHierarchy)
        {
            // Get default values from transform
            GetDefaultTransformValues(genericBinding.transformBindings, genericBinding.transformBindingsCount, *controllerBindingConstant.m_DynamicValuesDefault);
        }
        else
        {
            // When there is no transform & game object hierarchy, get it from the skeleton.
            if (skeleton != NULL && skeletonPose != NULL)
                ValueFromSkeletonPose(*skeleton, *skeletonPose, controllerBindingConstant.m_SkeletonTQSMap, *controllerBindingConstant.m_DynamicValuesDefault);
        }

        //  Get default values from generic bindings
        GetDefaultGenericFloatValues(genericBinding, *controllerBindingConstant.m_DynamicValuesDefault);
        GetDefaultGenericPPtrValues(genericBinding, *controllerBindingConstant.m_DynamicValuesDefault);
        GetDefaultGenericIntValues(genericBinding, *controllerBindingConstant.m_DynamicValuesDefault);
    }
}
}
