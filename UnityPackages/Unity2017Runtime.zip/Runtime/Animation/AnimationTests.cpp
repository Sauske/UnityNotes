#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "Runtime/Testing/Testing.h"
#include "Runtime/Animation/BoundCurveDeprecated.h"
#include "Runtime/Animation/BoundCurve.h"
#include "Runtime/Animation/AnimationClip.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/Testing/TestFixtures.h"

UNIT_TEST_SUITE(AnimationTests)
{
    TEST(AnimationBindingsEnumsMatch)
    {
        CHECK_EQUAL((int)UnityEngine::Animation::kUnbound, (int)::kUnbound);
        CHECK_EQUAL((int)UnityEngine::Animation::kBindTransformPosition, (int)::kBindTransformPosition);
        CHECK_EQUAL((int)UnityEngine::Animation::kBindTransformRotation, (int)::kBindTransformRotation);
        CHECK_EQUAL((int)UnityEngine::Animation::kBindTransformScale, (int)::kBindTransformScale);
        CHECK_EQUAL((int)UnityEngine::Animation::kBindTransformEuler, (int)::kBindTransformEuler);
        CHECK_EQUAL((int)UnityEngine::Animation::kBindFloat, (int)::kBindFloat);
        CHECK_EQUAL((int)UnityEngine::Animation::kBindFloatToBool, (int)::kBindFloatToBool);
        CHECK_EQUAL((int)UnityEngine::Animation::kBindFloatToInt, (int)::kBindFloatToInt);
        CHECK_EQUAL((int)UnityEngine::Animation::kBindDiscreteInt, (int)::kBindDiscreteInt);
    }

    // We cannot create/modify AnimationClip at runtime. So test is editor only.
#if UNITY_EDITOR
    TEST_FIXTURE(TestFixtureBase, AnimationClip_IsEmpty_ReturnsTrueOnReset)
    {
        AnimationClip::SetOnAnimationClipAwake(NULL);

        AnimationClip* clip = NewTestObject<AnimationClip>();
        clip->Reset();
        CHECK(clip->IsEmpty());
    }

    TEST_FIXTURE(TestFixtureBase, AnimationClip_IsEmpty_ReturnsFalseWhenCurveExists)
    {
        AnimationClip::SetOnAnimationClipAwake(NULL);
        AnimationClip* clip = NewTestObject<AnimationClip>();
        clip->Reset();

        AnimationCurveVec3 posCurve(kMemTempAlloc);
        posCurve.AddKey(KeyframeTpl<Vector3f>(0, Vector3f(0, 0, 0)));
        posCurve.AddKey(KeyframeTpl<Vector3f>(1, Vector3f(1, 1, 1)));
        clip->AddPositionCurve(posCurve, "");

        CHECK(!clip->IsEmpty());
    }

#endif
}

#endif
