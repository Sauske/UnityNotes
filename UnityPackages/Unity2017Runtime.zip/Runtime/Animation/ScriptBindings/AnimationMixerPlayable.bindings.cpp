#include "UnityPrefix.h"
#include "Runtime/Animation/ScriptBindings/AnimationMixerPlayable.bindings.h"

#include "Runtime/Animation/Director/AnimationMixerPlayable.h"
#include "Runtime/Director/Core/HPlayableGraph.h"
#include "Runtime/Director/Core/HPlayable.h"
#include "Runtime/Director/Core/PlayableGraph.h"
#include "Runtime/Export/Director/DirectorExport.h"

namespace AnimationMixerPlayableBindings
{
    bool CreateHandleInternal(const HPlayableGraph& graph, int inputCount, bool normalizeWeights, HPlayable& handle)
    {
        if (!PlayableGraphValidityChecks(graph))
            return false;

        AnimationMixerPlayable* instance = graph.m_Handle->m_Graph->ConstructPlayable<AnimationMixerPlayable>(handle, kAnimation);
        if (instance == NULL)
            return false; // TODO: Spit errors
        instance->SetInputCount(inputCount);
        return true;
    }
}
