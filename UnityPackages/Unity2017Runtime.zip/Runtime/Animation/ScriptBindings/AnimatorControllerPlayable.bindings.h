#pragma once

#include "Runtime/Animation/AnimatorInfo.h"

class ICallString;
class RuntimeAnimatorController;

struct HPlayableGraph;
struct HPlayable;

namespace AnimatorControllerPlayableBindings
{
    bool CreateHandleInternal(const HPlayableGraph& graph, RuntimeAnimatorController* controller, HPlayable& handle);
    RuntimeAnimatorController* GetAnimatorControllerInternal(const HPlayable& handle);
    int GetLayerCountInternal(const HPlayable& handle);
    core::string GetLayerNameInternal(const HPlayable& handle, int layerIndex);
    int GetLayerIndexInternal(const HPlayable& handle, const ICallString& layerName);
    float GetLayerWeightInternal(const HPlayable& handle, int layerIndex);
    void SetLayerWeightInternal(const HPlayable& handle, int layerIndex, float weight);
    AnimatorStateInfo GetCurrentAnimatorStateInfoInternal(const HPlayable& handle, int layerIndex);
    AnimatorStateInfo GetNextAnimatorStateInfoInternal(const HPlayable& handle, int layerIndex);
    AnimatorTransitionInfo GetAnimatorTransitionInfoInternal(const HPlayable& handle, int layerIndex);
    dynamic_array<MonoAnimatorClipInfo> GetCurrentAnimatorClipInfoInternal(const HPlayable& handle, int layerIndex);
    int GetAnimatorClipInfoCountInternal(const HPlayable& handle, int layerIndex, bool current);
    dynamic_array<MonoAnimatorClipInfo> GetNextAnimatorClipInfoInternal(const HPlayable& handle, int layerIndex);
    core::string ResolveHashInternal(const HPlayable& handle, int hash);
    bool IsInTransitionInternal(const HPlayable& handle, int layerIndex);
    int GetParameterCountInternal(const HPlayable& handle);
    int StringToHash(const ICallString& name);
    void CrossFadeInFixedTimeInternal(const HPlayable& handle, int stateNameHash, float transitionDuration, int layer, float fixedTime);
    void CrossFadeInternal(const HPlayable& handle, int stateNameHash, float transitionDuration, int layer, float normalizedTime);
    void PlayInFixedTimeInternal(const HPlayable& handle, int stateNameHash, int layer, float fixedTime);
    void PlayInternal(const HPlayable& handle, int stateNameHash, int layer, float normalizedTime);
    bool HasStateInternal(const HPlayable& handle, int layerIndex, int stateID);

    void SetFloatString(const HPlayable& handle, const ICallString& name, float value);
    void SetFloatID(const HPlayable& handle, int id, float value);
    float GetFloatString(const HPlayable& handle, const ICallString& name);
    float GetFloatID(const HPlayable& handle, int id);
    void SetBoolString(const HPlayable& handle, const ICallString& name, bool value);
    void SetBoolID(const HPlayable& handle, int id, bool value);
    bool GetBoolString(const HPlayable& handle, const ICallString& name);
    bool GetBoolID(const HPlayable& handle, int id);
    void SetIntegerString(const HPlayable& handle, const ICallString& name, int value);
    void SetIntegerID(const HPlayable& handle, int id, int value);
    int GetIntegerString(const HPlayable& handle, const ICallString& name);
    int GetIntegerID(const HPlayable& handle, int id);
    void SetTriggerString(const HPlayable& handle, const ICallString& name);
    void SetTriggerID(const HPlayable& handle, int id);
    void ResetTriggerString(const HPlayable& handle, const ICallString& name);
    void ResetTriggerID(const HPlayable& handle, int id);
    bool IsParameterControlledByCurveString(const HPlayable& handle, const ICallString& name);
    bool IsParameterControlledByCurveID(const HPlayable& handle, int id);
}
