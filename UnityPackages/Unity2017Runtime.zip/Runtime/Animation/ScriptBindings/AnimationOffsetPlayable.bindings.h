#pragma once

#include "Runtime/Math/Quaternion.h"
#include "Runtime/Math/Vector3.h"

struct HPlayableGraph;
struct HPlayable;

namespace AnimationOffsetPlayableBindings
{
    bool CreateHandleInternal(const HPlayableGraph& graph, const Vector3f& position, const Quaternionf& rotation, HPlayable& handle);
    Vector3f GetPositionInternal(HPlayable& handle);
    void SetPositionInternal(HPlayable& handle, const Vector3f& value);
    Quaternionf GetRotationInternal(HPlayable& handle);
    void SetRotationInternal(HPlayable& handle, const Quaternionf& value);
}
