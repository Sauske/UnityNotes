#include "UnityPrefix.h"
#include "Runtime/Animation/ScriptBindings/AnimationClipPlayable.bindings.h"

#include "Runtime/Animation/AnimationClip.h"
#include "Runtime/Animation/Director/AnimationClipPlayable.h"
#include "Runtime/Director/Core/HPlayableGraph.h"
#include "Runtime/Director/Core/HPlayable.h"
#include "Runtime/Director/Core/PlayableGraph.h"
#include "Runtime/Export/Director/DirectorExport.h"

static AnimationClipPlayable* GetAnimationClipPlayableUnsafe(const HPlayable &handle)
{
    return static_cast<AnimationClipPlayable*>(handle.m_Handle->m_Playable);
}

namespace AnimationClipPlayableBindings
{
    bool CreateHandleInternal(const HPlayableGraph& graph, AnimationClip* clip, HPlayable& handle)
    {
        if (!PlayableGraphValidityChecks(graph))
            return false;

        AnimationClipPlayable* instance = graph.m_Handle->m_Graph->ConstructPlayable<AnimationClipPlayable>(handle, kAnimation);
        if (instance == NULL)
            return false; // TODO: Spit errors

        instance->SetClip(clip);
        instance->OwnAsset(clip);

        return true;
    }

    AnimationClip* GetAnimationClipInternal(HPlayable& handle)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimationClipPlayableUnsafe(handle)->GetClip();
        return NULL;
    }

    bool GetApplyFootIKInternal(HPlayable& handle)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimationClipPlayableUnsafe(handle)->GetApplyFootIK();
        return false;
    }

    void SetApplyFootIKInternal(HPlayable& handle, bool value)
    {
        if (PlayableValidityChecks(handle))
            GetAnimationClipPlayableUnsafe(handle)->SetApplyFootIK(value);
    }

    bool GetRemoveStartOffsetInternal(HPlayable& handle)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimationClipPlayableUnsafe(handle)->GetRemoveStartOffset();
        return false;
    }

    void SetRemoveStartOffsetInternal(HPlayable& handle, bool value)
    {
        if (PlayableValidityChecks(handle))
            GetAnimationClipPlayableUnsafe(handle)->SetRemoveStartOffset(value);
    }
}
