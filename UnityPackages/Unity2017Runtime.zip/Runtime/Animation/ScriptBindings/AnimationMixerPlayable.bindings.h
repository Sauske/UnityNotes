#pragma once

struct HPlayableGraph;
struct HPlayable;

namespace AnimationMixerPlayableBindings
{
    bool CreateHandleInternal(const HPlayableGraph& graph, int inputCount, bool normalizeWeights, HPlayable& handle);
}
