#include "UnityPrefix.h"
#include "Runtime/Animation/ScriptBindings/AnimationPlayableGraphExtensions.bindings.h"

#include "Runtime/Animation/Animator.h"
#include "Runtime/Animation/Director/AnimationPlayableOutput.h"
#include "Runtime/Animation/Director/AnimationMotionXToDeltaPlayable.h"
#include "Runtime/Director/Core/HPlayableGraph.h"
#include "Runtime/Director/Core/HPlayableOutput.h"
#include "Runtime/Director/Core/HPlayable.h"
#include "Runtime/Director/Core/PlayableGraph.h"
#include "Runtime/Director/Core/PlayableOutput.h"
#include "Runtime/Export/Director/DirectorExport.h"

namespace AnimationPlayableGraphExtensionsBindings
{
    bool InternalCreateAnimationOutput(const HPlayableGraph& graph, const char* name, HPlayableOutput& handle)
    {
        if (!PlayableGraphValidityChecks(graph))
            return false;

        if (!graph.m_Handle->m_Graph->CreateOutput<AnimationPlayableOutput>(name, handle))
            return false;

        return true;
    }

    void InternalSyncUpdateAndTimeMode(const HPlayableGraph& graph, Animator* animator)
    {
        if (!PlayableGraphValidityChecks(graph))
            return;

        PlayableGraph* playableGraph = graph.m_Handle->m_Graph;

        playableGraph->SetTimeUpdateMode(animator->GetTimeUpdateMode());
        playableGraph->SetPrepareStage(animator->GetUpdateMode() == Animator::kAnimatePhysics ? kFixedUpdateStage : kUpdateAnimationBeginStage);
    }

    void InternalDestroyOutput(const HPlayableGraph& graph, const HPlayableOutput& handle)
    {
        if (!PlayableOutputValidityChecks(handle))
            return;

        graph.m_Handle->m_Graph->DestroyOutput(handle);
    }

    int InternalAnimationOutputCount(const HPlayableGraph& graph)
    {
        if (!PlayableGraphValidityChecks(graph))
            return -1;

        return graph.m_Handle->m_Graph->GetOutputCountOfType(kAnimation);
    }

    bool InternalGetAnimationOutput(const HPlayableGraph& graph, int index, HPlayableOutput& handle)
    {
        if (!PlayableGraphValidityChecks(graph))
            return false;

        PlayableOutput* playableOutput = graph.m_Handle->m_Graph->GetOutputOfType(kAnimation, index);

        if (playableOutput == 0)
            return false;

        handle = playableOutput->Handle();

        return true;
    }
}
