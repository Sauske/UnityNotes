#include "UnityPrefix.h"
#include "Runtime/Animation/ScriptBindings/AnimationLayerMixerPlayable.bindings.h"

#include "Runtime/Animation/AvatarMask.h"
#include "Runtime/Animation/Director/AnimationLayerMixerPlayable.h"
#include "Runtime/Director/Core/HPlayableGraph.h"
#include "Runtime/Director/Core/HPlayable.h"
#include "Runtime/Director/Core/PlayableGraph.h"
#include "Runtime/Export/Director/DirectorExport.h"

static AnimationLayerMixerPlayable* GetAnimationLayerMixerPlayableUnsafe(const HPlayable &handle)
{
    return static_cast<AnimationLayerMixerPlayable*>(handle.m_Handle->m_Playable);
}

namespace AnimationLayerMixerPlayableBindings
{
    bool CreateHandleInternal(const HPlayableGraph& graph, HPlayable& handle)
    {
        if (!PlayableGraphValidityChecks(graph))
            return false;

        AnimationLayerMixerPlayable* instance = graph.m_Handle->m_Graph->ConstructPlayable<AnimationLayerMixerPlayable>(handle, kAnimation);
        if (instance == NULL)
            return false; // TODO: Spit errors
        return true;
    }

    bool IsLayerAdditiveInternal(HPlayable& handle, UInt32 layerIndex)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimationLayerMixerPlayableUnsafe(handle)->GetLayerAdditive(layerIndex);
        return false;
    }

    void SetLayerAdditiveInternal(HPlayable& handle, UInt32 layerIndex, bool value)
    {
        if (PlayableValidityChecks(handle))
            GetAnimationLayerMixerPlayableUnsafe(handle)->SetLayerAdditive(layerIndex, value);
    }

    void SetLayerMaskFromAvatarMaskInternal(HPlayable& handle, UInt32 layerIndex, AvatarMask* mask)
    {
        if (PlayableValidityChecks(handle))
            GetAnimationLayerMixerPlayableUnsafe(handle)->SetLayerMaskFromAvatarMask(layerIndex, *mask);
    }
}
