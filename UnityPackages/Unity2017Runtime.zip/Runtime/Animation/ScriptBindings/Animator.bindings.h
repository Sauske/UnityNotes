#pragma once

#include "Runtime/Animation/AnimatorInfo.h"
#include "Runtime/Scripting/Marshalling/Marshalling.h"

namespace Marshalling
{
    //template <>
    //inline void Marshal<AnimatorClipInfo, MonoAnimatorClipInfo>(AnimatorClipInfo* native, const MonoAnimatorClipInfo* mono)
    //{
    //    MonoToAnimatorClipInfo(*mono, *native);
    //}

    template<>
    inline void Unmarshal<MonoAnimatorClipInfo, AnimatorClipInfo>(MonoAnimatorClipInfo* mono, const AnimatorClipInfo* native)
    {
        AnimatorClipInfoToMono(*native, *mono);
    }
}
