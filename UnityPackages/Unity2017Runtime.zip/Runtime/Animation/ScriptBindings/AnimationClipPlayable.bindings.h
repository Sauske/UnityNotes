#pragma once

class AnimationClip;

struct HPlayableGraph;
struct HPlayable;

namespace AnimationClipPlayableBindings
{
    bool CreateHandleInternal(const HPlayableGraph& graph, AnimationClip* clip, HPlayable& handle);
    AnimationClip* GetAnimationClipInternal(HPlayable& handle);
    bool GetApplyFootIKInternal(HPlayable& handle);
    void SetApplyFootIKInternal(HPlayable& handle, bool value);
    bool GetRemoveStartOffsetInternal(HPlayable& handle);
    void SetRemoveStartOffsetInternal(HPlayable& handle, bool value);
}
