#pragma once

class AvatarMask;

struct HPlayableGraph;
struct HPlayable;

namespace AnimationLayerMixerPlayableBindings
{
    bool CreateHandleInternal(const HPlayableGraph& graph, HPlayable& handle);
    bool IsLayerAdditiveInternal(HPlayable& handle, UInt32 layerIndex);
    void SetLayerAdditiveInternal(HPlayable& handle, UInt32 layerIndex, bool value);
    void SetLayerMaskFromAvatarMaskInternal(HPlayable& handle, UInt32 layerIndex, AvatarMask* mask);
}
