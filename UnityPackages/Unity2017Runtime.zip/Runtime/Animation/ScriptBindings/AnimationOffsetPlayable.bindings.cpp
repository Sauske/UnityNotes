#include "UnityPrefix.h"
#include "Runtime/Animation/ScriptBindings/AnimationOffsetPlayable.bindings.h"

#include "Runtime/Animation/Director/AnimationOffsetPlayable.h"
#include "Runtime/Director/Core/HPlayable.h"
#include "Runtime/Director/Core/HPlayableGraph.h"
#include "Runtime/Director/Core/PlayableGraph.h"
#include "Runtime/Export/Director/DirectorExport.h"

static AnimationOffsetPlayable* GetAnimationOffsetPlayableUnsafe(const HPlayable &handle)
{
    return static_cast<AnimationOffsetPlayable*>(handle.m_Handle->m_Playable);
}

namespace AnimationOffsetPlayableBindings
{
    bool CreateHandleInternal(const HPlayableGraph& graph, const Vector3f& position, const Quaternionf& rotation, HPlayable& handle)
    {
        if (!PlayableGraphValidityChecks(graph))
            return false;

        AnimationOffsetPlayable* instance = graph.m_Handle->m_Graph->ConstructPlayable<AnimationOffsetPlayable>(handle, kAnimation);
        if (instance == NULL)
            return false; // TODO: Spit errors

        instance->SetPosition(position);
        instance->SetRotation(rotation);
        return true;
    }

    Vector3f GetPositionInternal(HPlayable& handle)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimationOffsetPlayableUnsafe(handle)->GetPosition();
        return Vector3f::zero;
    }

    void SetPositionInternal(HPlayable& handle, const Vector3f& value)
    {
        if (PlayableValidityChecks(handle))
            GetAnimationOffsetPlayableUnsafe(handle)->SetPosition(value);
    }

    Quaternionf GetRotationInternal(HPlayable& handle)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimationOffsetPlayableUnsafe(handle)->GetRotation();
        return Quaternionf::identity();
    }

    void SetRotationInternal(HPlayable& handle, const Quaternionf& value)
    {
        if (PlayableValidityChecks(handle))
            GetAnimationOffsetPlayableUnsafe(handle)->SetRotation(value);
    }
}
