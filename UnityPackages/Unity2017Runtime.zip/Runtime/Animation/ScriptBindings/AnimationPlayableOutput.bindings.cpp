#include "UnityPrefix.h"
#include "Runtime/Animation/ScriptBindings/AnimationPlayableOutput.bindings.h"

#include "Runtime/Animation/Animator.h"
#include "Runtime/Animation/Director/AnimationPlayableOutput.h"
#include "Runtime/Director/Core/HPlayableOutput.h"
#include "Runtime/Export/Director/DirectorExport.h"

namespace AnimationPlayableOutputBindings
{
    Animator* InternalGetTarget(const HPlayableOutput& handle)
    {
        if (!PlayableOutputValidityChecks(handle))
            return NULL;

        AssertMsg(handle.m_Handle->m_Output->GetPlayerType() == kAnimation, "Wrong PlayableOutputHandle concrete type (Should be AnimationPlayableOutput)");
        AnimationPlayableOutput* animationOutput = static_cast<AnimationPlayableOutput*>(handle.m_Handle->m_Output);

        return animationOutput->GetTargetAnimator();
    }

    void InternalSetTarget(const HPlayableOutput& handle, Animator* target)
    {
        if (!PlayableOutputValidityChecks(handle))
            return;

        AssertMsg(handle.m_Handle->m_Output->GetPlayerType() == kAnimation, "Wrong PlayableOutputHandle concrete type (Should be AnimationPlayableOutput)");
        AnimationPlayableOutput* animationOutput = static_cast<AnimationPlayableOutput*>(handle.m_Handle->m_Output);

        animationOutput->SetTargetAnimator(target);
    }
}
