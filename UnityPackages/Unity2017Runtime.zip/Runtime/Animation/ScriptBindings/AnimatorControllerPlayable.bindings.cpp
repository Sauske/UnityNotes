#include "UnityPrefix.h"
#include "Runtime/Animation/ScriptBindings/AnimatorControllerPlayable.bindings.h"

#include "Runtime/Animation/Animator.h"
#include "Runtime/Animation/Director/AnimatorControllerPlayable.h"
#include "Runtime/Animation/RuntimeAnimatorController.h"
#include "Runtime/Director/Core/HPlayableGraph.h"
#include "Runtime/Director/Core/HPlayable.h"
#include "Runtime/Director/Core/PlayableGraph.h"
#include "Runtime/Export/Director/DirectorExport.h"
#include "Runtime/Scripting/ScriptingTypes.h"

static AnimatorControllerPlayable* GetAnimatorControllerPlayableUnsafe(const HPlayable& handle)
{
    return static_cast<AnimatorControllerPlayable*>(handle.m_Handle->m_Playable);
}

static dynamic_array<MonoAnimatorClipInfo> ConvertAnimatorClipInfoArrayToMonoArray(const dynamic_array<AnimatorClipInfo>& clips)
{
    dynamic_array<MonoAnimatorClipInfo> monoClips(clips.get_memory_label());
    monoClips.reserve(clips.size());
    for (dynamic_array<AnimatorClipInfo>::const_iterator it = clips.begin(); it != clips.end(); ++it)
        AnimatorClipInfoToMono(*it, monoClips.emplace_back_uninitialized());
    return monoClips;
}

namespace AnimatorControllerPlayableBindings
{
    bool CreateHandleInternal(const HPlayableGraph& graph, RuntimeAnimatorController* controller, HPlayable& handle)
    {
        if (!PlayableGraphValidityChecks(graph))
            return false;

        AnimatorControllerPlayable* instance = graph.m_Handle->m_Graph->ConstructPlayable<AnimatorControllerPlayable>(handle, kAnimation);
        if (instance == NULL)
            return false; // TODO: Spit errors

        instance->SetAnimatorController(controller);
        instance->OwnAsset(controller);

        return true;
    }

    RuntimeAnimatorController* GetAnimatorControllerInternal(const HPlayable& handle)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimatorControllerPlayableUnsafe(handle)->GetAnimatorController();
        return NULL;
    }

    int GetLayerCountInternal(const HPlayable& handle)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimatorControllerPlayableUnsafe(handle)->GetLayerCount();
        return -1;
    }

    // Gets name of the layer
    core::string GetLayerNameInternal(const HPlayable& handle, int layerIndex)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimatorControllerPlayableUnsafe(handle)->GetLayerName(layerIndex);
        return "";
    }

    int GetLayerIndexInternal(const HPlayable& handle, const ICallString& layerName)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimatorControllerPlayableUnsafe(handle)->GetLayerIndex((core::string)layerName);
        return -1;
    }

    // Gets the layer's current weight
    float GetLayerWeightInternal(const HPlayable& handle, int layerIndex)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimatorControllerPlayableUnsafe(handle)->GetLayerWeight(layerIndex);
        return -1.0f;
    }

    // Sets the layer's current weight
    void SetLayerWeightInternal(const HPlayable& handle, int layerIndex, float weight)
    {
        if (PlayableValidityChecks(handle))
            GetAnimatorControllerPlayableUnsafe(handle)->SetLayerWeight(layerIndex, weight);
    }

    // Gets the current State information on a specified AnimatorController layer
    AnimatorStateInfo GetCurrentAnimatorStateInfoInternal(const HPlayable& handle, int layerIndex)
    {
        AnimatorStateInfo info;
        if (PlayableValidityChecks(handle))
            GetAnimatorControllerPlayableUnsafe(handle)->GetAnimatorStateInfo(layerIndex, kCurrentState, info);
        return info;
    }

    // Gets the next State information on a specified AnimatorController layer
    AnimatorStateInfo GetNextAnimatorStateInfoInternal(const HPlayable& handle, int layerIndex)
    {
        AnimatorStateInfo info;
        if (PlayableValidityChecks(handle))
            GetAnimatorControllerPlayableUnsafe(handle)->GetAnimatorStateInfo(layerIndex, kNextState, info);
        return info;
    }

    // Gets the Transition information on a specified AnimatorController layer
    AnimatorTransitionInfo GetAnimatorTransitionInfoInternal(const HPlayable& handle, int layerIndex)
    {
        AnimatorTransitionInfo  info;
        if (PlayableValidityChecks(handle))
            GetAnimatorControllerPlayableUnsafe(handle)->GetAnimatorTransitionInfo(layerIndex, info);
        return info;
    }

    // Gets the list of AnimatorClipInfo currently played by the current state
    dynamic_array<MonoAnimatorClipInfo> GetCurrentAnimatorClipInfoInternal(const HPlayable& handle, int layerIndex)
    {
        dynamic_array<AnimatorClipInfo> clips(kMemTempAlloc);
        if (PlayableValidityChecks(handle))
            GetAnimatorControllerPlayableUnsafe(handle)->GetAnimatorClipInfo(layerIndex, true, clips);
        return ConvertAnimatorClipInfoArrayToMonoArray(clips);
    }

    int GetAnimatorClipInfoCountInternal(const HPlayable& handle, int layerIndex, bool current)
    {
        int size = 0;
        if (PlayableValidityChecks(handle))
            size = GetAnimatorControllerPlayableUnsafe(handle)->GetAnimatorClipInfoCount(layerIndex, current);
        return size;
    }

    // Gets the list of AnimatorClipInfo currently played by the next state
    dynamic_array<MonoAnimatorClipInfo> GetNextAnimatorClipInfoInternal(const HPlayable& handle, int layerIndex)
    {
        dynamic_array<AnimatorClipInfo> clips(kMemTempAlloc);
        if (PlayableValidityChecks(handle))
            GetAnimatorControllerPlayableUnsafe(handle)->GetAnimatorClipInfo(layerIndex, false, clips);
        return ConvertAnimatorClipInfoArrayToMonoArray(clips);
    }

    core::string ResolveHashInternal(const HPlayable& handle, int hash)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimatorControllerPlayableUnsafe(handle)->ResolveHash(hash);
        return "";
    }

    // Is the specified AnimatorController layer in a transition
    bool IsInTransitionInternal(const HPlayable& handle, int layerIndex)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimatorControllerPlayableUnsafe(handle)->IsInTransition(layerIndex);
        return false;
    }

    int GetParameterCountInternal(const HPlayable& handle)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimatorControllerPlayableUnsafe(handle)->GetParameters().size();
        return -1;
    }

    // Generates an parameter id from a string
    int StringToHash(const ICallString& name)
    {
        return Animator::ScriptingStringToCRC32(name);
    }

    void CrossFadeInFixedTimeInternal(const HPlayable& handle, int stateNameHash, float transitionDuration, int layer, float fixedTime)
    {
        if (PlayableValidityChecks(handle))
            GetAnimatorControllerPlayableUnsafe(handle)->GotoStateInFixedTime(layer, stateNameHash, fixedTime, transitionDuration);
    }

    void CrossFadeInternal(const HPlayable& handle, int stateNameHash, float transitionDuration, int layer, float normalizedTime)
    {
        if (PlayableValidityChecks(handle))
            GetAnimatorControllerPlayableUnsafe(handle)->GotoState(layer, stateNameHash, normalizedTime, transitionDuration);
    }

    void PlayInFixedTimeInternal(const HPlayable& handle, int stateNameHash, int layer, float fixedTime)
    {
        if (PlayableValidityChecks(handle))
            GetAnimatorControllerPlayableUnsafe(handle)->GotoStateInFixedTime(layer, stateNameHash, fixedTime, 0.0f);
    }

    void PlayInternal(const HPlayable& handle, int stateNameHash, int layer, float normalizedTime)
    {
        if (PlayableValidityChecks(handle))
            GetAnimatorControllerPlayableUnsafe(handle)->GotoState(layer, stateNameHash, normalizedTime, 0.0f);
    }

    bool HasStateInternal(const HPlayable& handle, int layerIndex, int stateID)
    {
        if (PlayableValidityChecks(handle))
            return GetAnimatorControllerPlayableUnsafe(handle)->HasState(layerIndex, stateID);
        return false;
    }

#undef GET_NAME_IMPL
#define GET_NAME_IMPL(Func, x) \
    do { \
        x value; \
        GetSetValueResult result = GetAnimatorControllerPlayableUnsafe(handle)->Func(Animator::ScriptingStringToCRC32(name), value); \
        if (result != kGetSetSuccess)  \
            GetAnimatorControllerPlayableUnsafe(handle)->ValidateParameterString (result, name); \
        return value; \
    } while(0)

#undef SET_NAME_IMPL
#define SET_NAME_IMPL(Func) \
    do { \
        GetSetValueResult result = GetAnimatorControllerPlayableUnsafe(handle)->Func(Animator::ScriptingStringToCRC32(name), value); \
        if (result != kGetSetSuccess) \
            GetAnimatorControllerPlayableUnsafe(handle)->ValidateParameterString (result, name); \
    } while(0)

#undef GET_ID_IMPL
#define GET_ID_IMPL(Func, x) \
    do { \
        x value; \
        GetSetValueResult result = GetAnimatorControllerPlayableUnsafe(handle)->Func(id, value); \
        if (result != kGetSetSuccess) \
            GetAnimatorControllerPlayableUnsafe(handle)->ValidateParameterID (result, id); \
        return value; \
    } while(0)

#undef SET_ID_IMPL
#define SET_ID_IMPL(Func) \
    do { \
        GetSetValueResult result = GetAnimatorControllerPlayableUnsafe(handle)->Func(id, value); \
        if (result != kGetSetSuccess)  \
            GetAnimatorControllerPlayableUnsafe(handle)->ValidateParameterID (result, id); \
    } while(0)

    void SetFloatString(const HPlayable& handle, const ICallString& name, float value)
    {
        SET_NAME_IMPL(SetFloat);
    }

    void SetFloatID(const HPlayable& handle, int id, float value)
    {
        SET_ID_IMPL(SetFloat);
    }

    float GetFloatString(const HPlayable& handle, const ICallString& name)
    {
        GET_NAME_IMPL(GetFloat, float);
    }

    float GetFloatID(const HPlayable& handle, int id)
    {
        GET_ID_IMPL(GetFloat, float);
    }

    void SetBoolString(const HPlayable& handle, const ICallString& name, bool value)
    {
        SET_NAME_IMPL(SetBool);
    }

    void SetBoolID(const HPlayable& handle, int id, bool value)
    {
        SET_ID_IMPL(SetBool);
    }

    bool GetBoolString(const HPlayable& handle, const ICallString& name)
    {
        GET_NAME_IMPL(GetBool, bool);
    }

    bool GetBoolID(const HPlayable& handle, int id)
    {
        GET_ID_IMPL(GetBool, bool);
    }

    void SetIntegerString(const HPlayable& handle, const ICallString& name, int value)
    {
        SET_NAME_IMPL(SetInteger);
    }

    void SetIntegerID(const HPlayable& handle, int id, int value)
    {
        SET_ID_IMPL(SetInteger);
    }

    int GetIntegerString(const HPlayable& handle, const ICallString& name)
    {
        GET_NAME_IMPL(GetInteger, int);
    }

    int GetIntegerID(const HPlayable& handle, int id)
    {
        GET_ID_IMPL(GetInteger, int);
    }

    void SetTriggerString(const HPlayable& handle, const ICallString& name)
    {
        GetSetValueResult result = GetAnimatorControllerPlayableUnsafe(handle)->SetTrigger(Animator::ScriptingStringToCRC32(name));
        if (result != kGetSetSuccess)
            GetAnimatorControllerPlayableUnsafe(handle)->ValidateParameterString(result, name);
    }

    void SetTriggerID(const HPlayable& handle, int id)
    {
        GetSetValueResult result = GetAnimatorControllerPlayableUnsafe(handle)->SetTrigger(id);
        if (result != kGetSetSuccess)
            GetAnimatorControllerPlayableUnsafe(handle)->ValidateParameterID(result, id);
    }

    void ResetTriggerString(const HPlayable& handle, const ICallString& name)
    {
        GetSetValueResult result = GetAnimatorControllerPlayableUnsafe(handle)->ResetTrigger(Animator::ScriptingStringToCRC32(name));
        if (result != kGetSetSuccess)
            GetAnimatorControllerPlayableUnsafe(handle)->ValidateParameterString(result, name);
    }

    void ResetTriggerID(const HPlayable& handle, int id)
    {
        GetSetValueResult result = GetAnimatorControllerPlayableUnsafe(handle)->ResetTrigger(id);
        if (result != kGetSetSuccess)
            GetAnimatorControllerPlayableUnsafe(handle)->ValidateParameterID(result, id);
    }

    bool IsParameterControlledByCurveString(const HPlayable& handle, const ICallString& name)
    {
        GetSetValueResult result = GetAnimatorControllerPlayableUnsafe(handle)->ParameterControlledByCurve(Animator::ScriptingStringToCRC32(name));
        if (result == kParameterIsControlledByCurve)
            return true;
        else if (result == kGetSetSuccess)
            return false;
        else
        {
            GetAnimatorControllerPlayableUnsafe(handle)->ValidateParameterString(result, name);
            return false;
        }
    }

    bool IsParameterControlledByCurveID(const HPlayable& handle, int id)
    {
        GetSetValueResult result = GetAnimatorControllerPlayableUnsafe(handle)->ParameterControlledByCurve(id);
        if (result == kParameterIsControlledByCurve)
            return true;
        else if (result == kGetSetSuccess)
            return false;
        else
        {
            GetAnimatorControllerPlayableUnsafe(handle)->ValidateParameterID(result, id);
            return false;
        }
    }
}
