#pragma once

class Animator;

struct HPlayableOutput;

namespace AnimationPlayableOutputBindings
{
    Animator* InternalGetTarget(const HPlayableOutput& handle);
    void InternalSetTarget(const HPlayableOutput& handle, Animator* target);
}
