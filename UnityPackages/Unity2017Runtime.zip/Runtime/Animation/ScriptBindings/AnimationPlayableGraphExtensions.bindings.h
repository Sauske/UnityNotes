#pragma once

class Animator;
struct HPlayableGraph;
struct HPlayableOutput;
struct HPlayable;

namespace AnimationPlayableGraphExtensionsBindings
{
    bool InternalCreateAnimationOutput(const HPlayableGraph& graph, const char* name, HPlayableOutput& handle);
    void InternalSyncUpdateAndTimeMode(const HPlayableGraph& graph, Animator* animator);
    void InternalDestroyOutput(const HPlayableGraph& graph, const HPlayableOutput& handle);
    int InternalAnimationOutputCount(const HPlayableGraph& graph);
    bool InternalGetAnimationOutput(const HPlayableGraph& graph, int index, HPlayableOutput& handle);
}
