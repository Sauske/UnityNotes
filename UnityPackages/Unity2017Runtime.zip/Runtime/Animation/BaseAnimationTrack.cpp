#include "UnityPrefix.h"

#if UNITY_EDITOR
#include "BaseAnimationTrack.h"

IMPLEMENT_REGISTER_CLASS(BaseAnimationTrack, 110);

BaseAnimationTrack::BaseAnimationTrack(MemLabelId label, ObjectCreationMode mode)
    :   Super(label, mode)
{}

void BaseAnimationTrack::ThreadedCleanup()
{}

#endif
