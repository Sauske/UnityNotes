#include "UnityPrefix.h"

#include "RuntimeAnimatorController.h"
#include "AnimationSetBinding.h"

#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/mecanim/animation/animationset.h"
#include "Runtime/mecanim/generic/valuearray.h"
#include "Runtime/mecanim/animation/controller.h"
#include "AnimationClip.h"

#include "Runtime/mecanim/statemachine/statemachine.h"

#if UNITY_EDITOR
#include "Runtime/Scripting/ScriptingInvocation.h"
#include "Runtime/Mono/MonoManager.h"
#endif

DEFINE_MESSAGE_IDENTIFIER(kDidModifyAnimatorController, ("OnDidModifyAnimatorController", MessageIdentifier::kDontSendToScripts));
DEFINE_MESSAGE_IDENTIFIER(kDidModifyOverrideClip, ("OnDidModifyOverrideClip", MessageIdentifier::kDontSendToScripts));

IMPLEMENT_REGISTER_CLASS(RuntimeAnimatorController, 93);
IMPLEMENT_OBJECT_SERIALIZE(RuntimeAnimatorController);
INSTANTIATE_TEMPLATE_TRANSFER(RuntimeAnimatorController);

RuntimeAnimatorController::RuntimeAnimatorController(MemLabelId label, ObjectCreationMode mode)
    :   Super(label, mode),
    m_ObjectUsers(this),
    m_DependencyList(this)
{
}

void RuntimeAnimatorController::ThreadedCleanup()
{
}

void RuntimeAnimatorController::MainThreadCleanup()
{
    NotifyObjectUsers(kDidModifyAnimatorController);
    m_DependencyList.Clear();
    m_ObjectUsers.Clear();
    Super::MainThreadCleanup();
}

template<class TransferFunction>
void RuntimeAnimatorController::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);
}

void RuntimeAnimatorController::NotifyObjectUsers(const MessageIdentifier& msg)
{
    m_ObjectUsers.SendMessage(msg);
}

void RuntimeAnimatorController::RegisterAnimationClips()
{
    AnimationClipPPtrVector clips = GetAnimationClipsToRegister();
    m_DependencyList.Clear();
    m_DependencyList.Reserve(clips.size()); // Reserve space just for niceness
    for (unsigned i = 0; i < clips.size(); i++)
    {
        AnimationClip* clip = clips[i];
        if (clip)
        {
            // We could do this either way, adding is symmetrical
            clip->GetUserList().AddUser(m_DependencyList);
        }
    }
}

void RuntimeAnimatorController::DestroyCustomController(mecanim::animation::ControllerConstant* sourceController, mecanim::memory::Allocator& allocator)
{
    if (sourceController == 0)
        return;

    mecanim::animation::DestroyBlendTreeConstant(sourceController->m_StateMachineArray[0]->m_StateConstantArray[0]->m_BlendTreeConstantArray[0].Get(), allocator);
    mecanim::statemachine::DestroyStateConstant(sourceController->m_StateMachineArray[0]->m_StateConstantArray[0].Get(), allocator);
    mecanim::statemachine::DestroyStateMachineConstant(sourceController->m_StateMachineArray[0].Get(), allocator);
    mecanim::animation::DestroyLayerConstant(sourceController->m_LayerArray[0].Get(), allocator);
    mecanim::DestroyValueArray(sourceController->m_DefaultValues.Get(), allocator);
    mecanim::DestroyValueArrayConstant(sourceController->m_Values.Get(), allocator);
    mecanim::animation::DestroyControllerConstant(sourceController, allocator);
}

mecanim::animation::ControllerConstant* RuntimeAnimatorController::BuildCustomController(AnimationClip const& clip, mecanim::animation::ControllerConstant const* sourceController, mecanim::memory::Allocator& allocator)
{
    mecanim::uint32_t id = mecanim::processCRC32(clip.GetName());
    mecanim::animation::BlendTreeConstant* blendTreeCst = mecanim::animation::CreateBlendTreeConstant(0, allocator);
    mecanim::statemachine::StateConstant* stateCst = mecanim::statemachine::CreateStateConstant(0, 0, 1, mecanim::NO_PARAM, true, true, false, mecanim::NO_PARAM, 0, mecanim::NO_PARAM, mecanim::NO_PARAM, &blendTreeCst, 1, id, id, id, 0, true, allocator);
    mecanim::statemachine::StateMachineConstant* stateMachinCst = CreateStateMachineConstant(&stateCst, 1 , 0, 0, 0, 0, 0, 1, allocator);
    mecanim::animation::LayerConstant*  layer   = mecanim::animation::CreateLayerConstant(0, 0, allocator);
    layer->m_BodyMask = mecanim::human::FullBodyMask();
    layer->m_SkeletonMask = 0;

    mecanim::ValueArrayConstant* values     = mecanim::CreateValueArrayConstantCopy(sourceController->m_Values.Get(), sourceController->m_Values->m_Count, allocator);
    mecanim::ValueArray* defaultValues      = mecanim::CreateValueArray(values, allocator);
    mecanim::ValueArrayCopy<false>(sourceController->m_DefaultValues.Get(), defaultValues);

    return mecanim::animation::CreateControllerConstant(1, &layer, 1, &stateMachinCst, values, defaultValues, 1, allocator);
}
