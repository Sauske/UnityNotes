#ifndef AVATAR_H
#define AVATAR_H

#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/Misc/UserList.h"
#include "Runtime/BaseClasses/MessageIdentifier.h"
#include "Runtime/Serialize/SerializeTraits.h"
#include "Runtime/mecanim/animation/avatar.h"

#include "Runtime/Animation/MecanimUtility.h"

namespace mecanim
{  namespace animation
{ struct AvatarConstant; } }

enum HumanParameter
{
    UpperArmTwist = 0,
    LowerArmTwist,
    UpperLegTwist,
    LowerLegTwsit,
    ArmStretch,
    LegStretch,
    FeetSpacing
};

DECLARE_MESSAGE_IDENTIFIER(kDidModifyAvatar);

class Avatar : public NamedObject
{
    REGISTER_CLASS(Avatar);
    DECLARE_OBJECT_SERIALIZE();
public:

    static void InitializeClass() {}
    static void CleanupClass() {}

    Avatar(MemLabelId label, ObjectCreationMode mode);

    virtual void MainThreadCleanup();
    virtual void AwakeFromLoad(AwakeFromLoadMode mode);
    virtual void CheckConsistency();

    void SetAsset(mecanim::animation::AvatarConstant* avatarConstant, TOSVector const& tos);

    mecanim::animation::AvatarConstant* GetAsset();
    const mecanim::animation::AvatarConstant*   GetAsset() const;
    TOSVector const&                    GetTOS() const;

    bool    IsValid() const;


    void    SetMuscleMinMax(int muscleId, float min, float max);
    void    SetParameter(int parameterId, float value);

    void    NotifyObjectUsers(const MessageIdentifier& msg);
    void    AddObjectUser(UserListNode& node) { m_ObjectUsers.AddUser(node); }

    bool    IsHuman() const;
    bool    HasRootMotion() const;
    float   GetHumanScale() const;
    float   GetLeftFeetBottomHeight() const;
    float   GetRightFeetBottomHeight() const;

    float       GetAxisLength(int humanId) const;
    Quaternionf GetPreRotation(int humanId) const;
    Quaternionf GetPostRotation(int humanId) const;
    Quaternionf GetZYPostQ(int index, Quaternionf const& parentQ, Quaternionf const& q) const;
    Quaternionf GetZYRoll(int index, Vector3f const& v) const;
    Vector3f    GetLimitSign(int index) const;

protected:

    mecanim::memory::ChainedAllocator   m_Allocator;
    mecanim::animation::AvatarConstant* m_Avatar;
    TOSVector                           m_TOS;

    UInt32                          m_AvatarSize;

    UserList                                m_ObjectUsers;
};
BIND_MANAGED_TYPE_NAME(Avatar, UnityEngine_Avatar);

class HumanTrait
{
public:
    enum
    {
        LastDoF = mecanim::human::kHumanDoFStop,
        LastLeftFingerDoF = mecanim::human::kHumanLeftHandDoFStop,
        LastRightFingerDoF = mecanim::human::kHumanRightHandDoFStop,
        MuscleCount = mecanim::human::kHumanLastDoF
    };

    enum
    {
        LastBodyBone = mecanim::human::kBodyBoneStop,
        LastLeftFingerBone = mecanim::human::kLeftHandBoneStop,
        LastRightFingerBone = mecanim::human::kRightHandBoneStop,
        HumanBoneCount = mecanim::human::kLastHumanBone
    };

    static core::string GetFingerMuscleName(int index, bool left);
    static core::string GetFingerName(int index, bool left);

    class Body
    {
    public:
        static int GetBoneCount();
        static core::string GetBoneName(int index);
        static int GetMuscleCount();
        static core::string GetMuscleName(int index);
    };

    class LeftFinger
    {
    public:
        static int GetBoneCount();
        static core::string GetBoneName(int index);
        static int GetMuscleCount();
        static core::string GetMuscleName(int index);
        static bool IsLeftHand();
    };

    class RightFinger
    {
    public:
        static int GetBoneCount();
        static core::string GetBoneName(int index);
        static int GetMuscleCount();
        static core::string GetMuscleName(int index);
        static bool IsLeftHand();
    };

    static void InitializeClass();
    static void CleanupClass();

    static std::vector<core::string> GetMuscleName();
    static std::vector<core::string> GetBoneName();
    static int MuscleFromBone(int i, int dofIndex);
    static int BoneFromMuscle(int i);
    static int GetBoneId(Avatar const& avatar, int humanId);
    static bool RequiredBone(int humanId);
    static int RequiredBoneCount();
    static bool HasCollider(Avatar& avatar, int humanId);
    static int GetColliderId(Avatar& avatar, int humanId);

    static int GetParent(int humanId);

    static float GetMuscleDefaultMin(int i);
    static float GetMuscleDefaultMax(int i);

    static int GetBoneIndexFromMono(int monoIndex);
    static int GetBoneIndexToMono(int boneIndex);
    static std::vector<core::string> MonoBoneName();

protected:
    static std::vector<core::string>* m_MuscleName;
    static std::vector<core::string>* m_BoneName;

    static int *m_BoneIndexToMono;
    static int *m_BoneIndexFromMono;
    static std::vector<core::string>* m_MonoBoneName;

    static void InitializeMuscleName();
    static void InitializeBoneName();
    static void InitializeMonoIndicies();
};


#endif
