#include "UnityPrefix.h"

#include "Runtime/Animation/AnimatedPropertyEvaluator.h"
#include "Runtime/Animation/AnimatedProperty.h"
#include "Runtime/Animation/AnimatedPropertyVector3.h"
#include "Runtime/Animation/GenericAnimationBindingCache.h"
#include "Runtime/Animation/BoundCurve.h"
#include "Runtime/Director/Core/PropertyAccessorPolicy.h"
#include "Runtime/Mono/MonoBehaviour.h"
#include "Runtime/Jobs/JobTypes.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Serialize/TransferUtility.h"
#include "Runtime/mecanim/generic/crc32.h"
#include "Runtime/Transform/Transform.h"

PROFILER_INFORMATION(gAnimatedPropertyUpdate, "Director.AnimatedProperty", kProfilerDirector);

AnimatedPropertyEvaluator::AnimatedPropertyEvaluator()
{
}

AnimatedPropertyEvaluator::~AnimatedPropertyEvaluator()
{
    Clear();
}

void AnimatedPropertyEvaluator::UpdateSync(float time, ScriptingObjectPtr ptr)
{
    for (AnimatedPropertyFloatCollection::iterator it = m_AnimatedPropertiesFloat.begin(); it != m_AnimatedPropertiesFloat.end(); ++it)
        (*it)->Update(time, ptr);
}

bool AnimatedPropertyEvaluator::BindCurveToScriptingObjectPtr(const AnimationClip::FloatCurve& curve, UInt32 curveIndex, ScriptingObjectPtr scriptingObject, bool isNormalized)
{
    DebugAssertMsg(scriptingObject != SCRIPTING_NULL, "Can not bind curve to NULL");
    if (scriptingObject == SCRIPTING_NULL)
        return false;

    PropertyAccessor accessor;

    bool isBound = false;
    if (PropertyAccessor::CanBindFloatValue(curve.attribute.c_str(), scriptingObject, accessor))
    {
        m_AnimatedPropertiesFloat.push_back(UNITY_NEW(AnimatedProperty, kMemAnimation)(accessor, curve.curve));
        isBound = true;
    }
    accessor.Clear();
    return isBound;
}

void AnimatedPropertyEvaluator::Clear()
{
    AnimatedPropertyFloatCollection::iterator it = NULL;
    for (it = m_AnimatedPropertiesFloat.begin(); it != m_AnimatedPropertiesFloat.end(); ++it)
        UNITY_DELETE(*it, kMemAnimation);
    m_AnimatedPropertiesFloat.clear();
}

void AnimatedPropertyEvaluator::BuildFromScriptableObject(AnimationClip* animationClip, ScriptingObjectPtr ptr)
{
    if (animationClip == NULL)
        return;

    const AnimationClip::FloatCurves& floatCurves = animationClip->GetFloatCurves();
    for (UInt32 curveIndex = 0; curveIndex != floatCurves.size(); ++curveIndex)
    {
        const AnimationClip::FloatCurve& curve = floatCurves[curveIndex];
        BindCurveToScriptingObjectPtr(curve, curveIndex, ptr, true);
    }
}
