#pragma once

class IAnimationBinding;

namespace UnityEngine
{
namespace Animation
{
    // These values can can never be changed, when a system is deprecated,
    // it must be kept commented out and the index is not to be reused!
    // The enum value can not be reused. Otherwise built data (assetbundles) will break.
    enum BindType
    {
        kUnbound                            = 0,

        // Builtin transform bindings
        kBindTransformPosition              = 1,// This enum may not be changed. It is used in GenericClipBinding.
        kBindTransformRotation              = 2,// This enum may not be changed.  It is used in GenericClipBinding.
        kBindTransformScale                 = 3,// It is used in GenericClipBinding.
        kBindTransformEuler                 = 4,

        // Builtin float bindings
        kMinSinglePropertyBinding           = 5,
        kBindFloat                          = 5,
        kBindFloatToBool                    = 6,
        kBindGameObjectActive               = 7,
        kBindMuscle                         = 8,
        kBindScriptObjectReference          = 9,
        kBindFloatToInt                     = 10,
        kBindDiscreteInt                    = 11,

        // Custom bindings
        kBlendShapeWeightBinding            = 20,
        kRendererMaterialPPtrBinding        = 21,
        kRendererMaterialPropertyBinding    = 22,
        kSpriteRendererPPtrBinding          = 23,
        kMonoBehaviourPropertyBinding       = 24,
        kLightPropertyBinding               = 25,
        kRendererOtherPropertyBinding       = 26,
        kParticleSystemPropertyBindings     = 27,
        kRectTransformPropertyBindings      = 28,
        kLineRendererPropertyBindings       = 29,
        kTrailRendererPropertyBindings      = 30,

        kAllBindingCount
    };

    enum
    {
        kEulerOrderXYZ,
        kEulerOrderXZY,
        kEulerOrderYZX,
        kEulerOrderYXZ,
        kEulerOrderZXY,
        kEulerOrderZYX,
    };


    struct BoundCurve
    {
        void*               targetPtr;
        UInt32              targetType;
        IAnimationBinding*  customBinding;
        Object*             targetObject;

        BoundCurve() { targetObject = 0; targetPtr = 0; targetType = 0; customBinding = 0; }

        bool IsEmpty() { return targetPtr == NULL && targetType == 0 && customBinding == NULL && targetObject == NULL; }
    };
}
}
