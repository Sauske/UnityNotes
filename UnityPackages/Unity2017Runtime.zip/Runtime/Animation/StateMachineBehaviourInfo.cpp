#include "UnityPrefix.h"
#include "StateMachineBehaviourInfo.h"
#include "Runtime/Mono/MonoScript.h"

bool HasInvalidBehaviourPredicate::operator()(PPtr<MonoBehaviour> const& behaviour)
{
    if (behaviour.IsNull())
        return true;

    if (behaviour->GetScript().IsNull())
        return true;

    return false;
}

StateRange FindStateBehavioursRange(StateKey const& stateKey, const StateMachineBehaviourVectorDescription * stateMachineBehavioursDescription)
{
    StateMachineBehaviourRanges::const_iterator it =  stateMachineBehavioursDescription->m_StateMachineBehaviourRanges.find(stateKey);
    if (it !=  stateMachineBehavioursDescription->m_StateMachineBehaviourRanges.end())
        return it->second;

    return StateRange();
}
