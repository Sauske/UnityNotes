#include "UnityPrefix.h"
#include "MecanimClipBuilder.h"
#include "StreamedClipBuilder.h"
#include "DenseClipBuilder.h"
#include "GenericAnimationBindingCache.h"
#include "AnimationClipSettings.h"
#include "AnimationSetBinding.h"

#include "Runtime/Transform/Transform.h"
#include "Runtime/mecanim/animation/animationset.h"
#include "AnimationClip.h"

MecanimClipBuilder::MecanimClipBuilder()
    : hasAnimationEvents(false),
    startTime(std::numeric_limits<float>::infinity()),
    stopTime(-std::numeric_limits<float>::infinity()),
    sampleRate(30.0F)
{
    // Muscle curves
    for (mecanim::int32_t muscleIter = 0; muscleIter < mecanim::animation::s_ClipMuscleCurveCount; muscleIter++)
        muscleIndexArray[muscleIter] = -1;
}

template<class T>
static ClipOptType ClassifyCurve(AnimationCurveTpl<T>& curve, bool useHighQualityCurve, float samplingRate)
{
    if (curve.GetKeyCount() == 0)
        return kInvalidCurve;
    if (!(IsFinite(curve.GetRange().first) && IsFinite(curve.GetRange().second)))
        return kInvalidCurve;

    if (IsConstantCurve(curve))
        return kConstantClip;

    if (!useHighQualityCurve && IsDenseCurve(curve, samplingRate))
        return kDenseClip;

    return kStreamedClip;
}

template<class T>
static void AddCurveToConstantClip(mecanim::animation::ConstantClip& clip, int index, AnimationCurveTpl<T>& curve)
{
    memcpy(&clip.data[index], &curve.GetKey(0).value, sizeof(T));
}

static void AddMappedPPtrCurveToStreamedClip(StreamedClipBuilder* builder, int curveIter, UnityEngine::Animation::AnimationClipBindingConstant& clipBindings, const PPtrKeyframes& pptrCurve)
{
    const size_t keyframeCount = pptrCurve.size();

    float* inTime;
    int* inValue;
    ALLOC_TEMP_AUTO(inTime, keyframeCount);
    ALLOC_TEMP_AUTO(inValue, keyframeCount);

    const int mapOffset = clipBindings.pptrCurveMapping.size();
    for (size_t i = 0; i < keyframeCount; ++i)
    {
        inTime[i] = pptrCurve[i].time;
        // Map Object to index
        inValue[i] = mapOffset + i;
        clipBindings.pptrCurveMapping.push_back(pptrCurve[i].value);
    }

    AddIntegerCurveToStreamedClip(builder, curveIter, inTime, inValue, keyframeCount);
}

bool PrepareClipBuilder(MecanimClipBuilder& clipBuilder)
{
    size_t previousTypesCurveCount = 0;

    for (int t = 0; t < kClipOptCount; t++)
    {
        MecanimClipBuilder::Curves& curves = clipBuilder.curves[t];

        size_t keyCount = 0;
        size_t genericBindingIndex = 0;
        size_t curveCount = 0;
        for (size_t i = 0; i < curves.positionCurves.size(); i++)
        {
            keyCount += curves.positionCurves[i]->GetKeyCount() * 3;
            curveCount += 3;
            genericBindingIndex++;
        }

        for (size_t i = 0; i < curves.rotationCurves.size(); i++)
        {
            keyCount += curves.rotationCurves[i]->GetKeyCount() * 4;
            curveCount += 4;
            genericBindingIndex++;
        }

        for (size_t i = 0; i < curves.eulerCurves.size(); i++)
        {
            keyCount += curves.eulerCurves[i]->GetKeyCount() * 3;
            curveCount += 3;
            genericBindingIndex++;
        }

        for (size_t i = 0; i < curves.scaleCurves.size(); i++)
        {
            keyCount += curves.scaleCurves[i]->GetKeyCount() * 3;
            curveCount += 3;
            genericBindingIndex++;
        }

        for (size_t i = 0; i < curves.genericCurves.size(); i++)
        {
            if (IsMuscleBinding(curves.bindings[genericBindingIndex]))
                clipBuilder.muscleIndexArray[curves.bindings[genericBindingIndex].attribute] = curveCount + previousTypesCurveCount;

            keyCount += curves.genericCurves[i]->GetKeyCount();
            genericBindingIndex++;
            curveCount++;
        }

        for (size_t i = 0; i < curves.pptrCurves.size(); i++)
        {
            keyCount += curves.pptrCurves[i]->size();
            curveCount++;
        }

        curves.totalKeyCount = keyCount;
        curves.totalCurveCount = curveCount;
        previousTypesCurveCount += curveCount;
    }

    clipBuilder.totalCurveCount = 0;
    clipBuilder.totalBindingCount = 0;
    for (int t = 0; t < kClipOptCount; t++)
    {
        MecanimClipBuilder::Curves& curves = clipBuilder.curves[t];
        clipBuilder.totalBindingCount += curves.bindings.size();
        clipBuilder.totalCurveCount += curves.totalCurveCount;
    }

    return clipBuilder.totalCurveCount != 0 || clipBuilder.hasAnimationEvents;
}

mecanim::animation::ClipMuscleConstant* BuildMuscleClip(const MecanimClipBuilder& clipBuilder, const AnimationClipSettings& animationClipSettings, bool isHumanClip, UnityEngine::Animation::AnimationClipBindingConstant& outClipBindings, mecanim::memory::Allocator& allocator)
{
    SETPROFILERLABEL(ClipMuscleConstant);

    // Total binding count
    outClipBindings.genericBindings.clear();
    outClipBindings.genericBindings.reserve(clipBuilder.totalBindingCount);
    outClipBindings.pptrCurveMapping.clear();

    // Combine into a single binding array
    outClipBindings.genericBindings.reserve(clipBuilder.totalBindingCount);
    for (int i = 0; i < kClipOptCount; i++)
        outClipBindings.genericBindings.insert(outClipBindings.genericBindings.end(), clipBuilder.curves[i].bindings.begin(), clipBuilder.curves[i].bindings.end());

    mecanim::animation::Clip* clip = mecanim::animation::CreateClipSimple(clipBuilder.totalCurveCount, allocator);

    // Streamed clip
    const MecanimClipBuilder::Curves& streamedCurves = clipBuilder.curves[kStreamedClip];
    StreamedClipBuilder* builder = NULL;
    builder = CreateStreamedClipBuilder(streamedCurves.totalCurveCount, streamedCurves.totalKeyCount);

    // Constant clip
    const MecanimClipBuilder::Curves& constantCurves = clipBuilder.curves[kConstantClip];
    CreateConstantClip(clip->m_ConstantClip, constantCurves.totalCurveCount, allocator);

    // Dense clip
    const MecanimClipBuilder::Curves& denseCurves = clipBuilder.curves[kDenseClip];
    CreateDenseClip(clip->m_DenseClip, denseCurves.totalCurveCount, clipBuilder.startTime, clipBuilder.stopTime, clipBuilder.sampleRate, allocator);

    for (int t = 0; t < kClipOptCount; t++)
    {
        const MecanimClipBuilder::Curves& curves = clipBuilder.curves[t];

        #define AddCurveByType(CURVE_TYPE) \
            if (t == kStreamedClip) \
                AddCurveToStreamedClip(builder, curveIter, *curves.CURVE_TYPE[i]); \
            else if (t == kDenseClip) \
                AddCurveToDenseClip(clip->m_DenseClip, curveIter, *curves.CURVE_TYPE[i]); \
            else if (t == kConstantClip) \
                AddCurveToConstantClip (clip->m_ConstantClip, curveIter, *curves.CURVE_TYPE[i]);

        size_t curveIter = 0;
        for (size_t i = 0; i < curves.positionCurves.size(); i++, curveIter += 3)
        {
            AddCurveByType(positionCurves)
        }

        for (size_t i = 0; i < curves.rotationCurves.size(); i++, curveIter += 4)
        {
            AddCurveByType(rotationCurves)
        }

        for (size_t i = 0; i < curves.eulerCurves.size(); i++, curveIter += 3)
        {
            AddCurveByType(eulerCurves)
        }

        for (size_t i = 0; i < curves.scaleCurves.size(); i++, curveIter += 3)
        {
            AddCurveByType(scaleCurves)
        }

        for (size_t i = 0; i < curves.genericCurves.size(); i++, curveIter++)
        {
            AddCurveByType(genericCurves)
        }

        for (size_t i = 0; i < curves.pptrCurves.size(); i++, curveIter++)
        {
            Assert(t == kStreamedClip);
            AddMappedPPtrCurveToStreamedClip(builder, curveIter, outClipBindings, *streamedCurves.pptrCurves[i]);
        }
    }

    if (builder)
    {
        CreateStreamClipConstant(builder, clip->m_StreamedClip, allocator);
        DestroyStreamedClipBuilder(builder);
    }

    mecanim::animation::ClipMuscleConstant* muscleClip = mecanim::animation::CreateClipMuscleConstant(clip, allocator);
    for (mecanim::int32_t muscleIter = 0; muscleIter < mecanim::animation::s_ClipMuscleCurveCount; muscleIter++)
        muscleClip->m_IndexArray[muscleIter] = clipBuilder.muscleIndexArray[muscleIter];

    return muscleClip;
}

void AddPositionCurveToClipBuilder(AnimationCurveVec3& curve, const core::string& path, MecanimClipBuilder& clipBuilder, bool useHighQualityCurve)
{
    ClipOptType type = ClassifyCurve(curve, useHighQualityCurve, clipBuilder.sampleRate);
    if (type == kInvalidCurve)
        return;

    MecanimClipBuilder::Curves& curves = clipBuilder.curves[type];
    curves.positionCurves.push_back(&curve);
    CreateTransformBinding(path, UnityEngine::Animation::kBindTransformPosition, curves.bindings.emplace_back_uninitialized());
}

void AddEulerCurveToClipBuilder(AnimationCurveVec3& curve, const core::string& path, MecanimClipBuilder& clipBuilder, bool useHighQualityCurve)
{
    ClipOptType type = ClassifyCurve(curve, useHighQualityCurve, clipBuilder.sampleRate);
    if (type == kInvalidCurve)
        return;

    MecanimClipBuilder::Curves& curves = clipBuilder.curves[type];
    curves.eulerCurves.push_back(&curve);
    UnityEngine::Animation::GenericBinding & binding = curves.bindings.emplace_back_uninitialized();
    CreateTransformBinding(path, UnityEngine::Animation::kBindTransformEuler, binding);
    binding.customType = curve.GetRotationOrder() + UnityEngine::Animation::kEulerOrderXYZ;
}

void AddRotationCurveToClipBuilder(AnimationCurveQuat& curve, const core::string& path, MecanimClipBuilder& clipBuilder, bool useHighQualityCurve)
{
    ClipOptType type = ClassifyCurve(curve, useHighQualityCurve, clipBuilder.sampleRate);
    if (type == kInvalidCurve)
        return;

    MecanimClipBuilder::Curves& curves = clipBuilder.curves[type];
    curves.rotationCurves.push_back(&curve);
    CreateTransformBinding(path, UnityEngine::Animation::kBindTransformRotation, curves.bindings.emplace_back_uninitialized());
}

void AddScaleCurveToClipBuilder(AnimationCurveVec3& curve, const core::string& path, MecanimClipBuilder& clipBuilder, bool useHighQualityCurve)
{
    ClipOptType type = ClassifyCurve(curve, useHighQualityCurve, clipBuilder.sampleRate);
    if (type == kInvalidCurve)
        return;

    MecanimClipBuilder::Curves& curves = clipBuilder.curves[type];
    curves.scaleCurves.push_back(&curve);
    CreateTransformBinding(path, UnityEngine::Animation::kBindTransformScale, curves.bindings.emplace_back_uninitialized());
}

void AddGenericCurveToClipBuilder(AnimationCurve& curve, const UnityEngine::Animation::GenericBinding& binding, MecanimClipBuilder& clipBuilder, bool useHighQualityCurve)
{
    ClipOptType type = ClassifyCurve(curve, useHighQualityCurve, clipBuilder.sampleRate);

    // The runtime binding code is not able to handle when a Transform component incorrectly has generic curve.
    // Reject it here..
    if (binding.GetType() == TypeOf<Transform>())
    {
        WarningString("Cannot bind generic curve on Transform component, only position, rotation and scale curve are supported.");
        return;
    }

    if (type == kInvalidCurve)
        return;

    MecanimClipBuilder::Curves& curves = clipBuilder.curves[type];
    curves.genericCurves.push_back(&curve);
    curves.bindings.push_back(binding);
}

void AddPPtrCurveToClipBuilder(PPtrKeyframes& curve, const UnityEngine::Animation::GenericBinding& binding, MecanimClipBuilder& clipBuilder)
{
    if (curve.empty())
        return;

    // The runtime binding code is not able to handle when a Transform component incorrectly has pptr curve.
    // Reject it here..
    if (binding.GetType() == TypeOf<Transform>())
        return;

    MecanimClipBuilder::Curves& curves = clipBuilder.curves[kStreamedClip];
    curves.pptrCurves.push_back(&curve);
    curves.bindings.push_back(binding);
}
