#include "UnityPrefix.h"

#include "StateMachineBehaviourPlayer.h"


#include "Runtime/Mono/MonoScriptCache.h"
#include "Runtime/Animation/Animator.h"
#include "Runtime/Animation/Director/AnimatorControllerPlayable.h"


static inline int GetBehaviourMethod(mecanim::statemachine::StateMachineMessage messageID)
{
    switch (messageID)
    {
        case mecanim::statemachine::kOnStateEnter: return MonoScriptCache::kOnStateEnter;
        case mecanim::statemachine::kOnStateExit: return MonoScriptCache::kOnStateExit;
        case mecanim::statemachine::kOnStateUpdate: return MonoScriptCache::kOnStateUpdate;
        case mecanim::statemachine::kOnStateMove: return MonoScriptCache::kOnStateMove;
        case mecanim::statemachine::kOnStateIK: return MonoScriptCache::kOnStateIK;
        case mecanim::statemachine::kOnStateMachineEnter: return MonoScriptCache::kOnStateMachineEnter;
        case mecanim::statemachine::kOnStateMachineExit: return MonoScriptCache::kOnStateMachineExit;
        default: return MonoScriptCache::kMethodCount;
    }
}

StateMachineBehaviourPlayer::StateMachineBehaviourPlayer(IStateMachineBehaviourSender* sender)
{
    m_Sender = sender;
    m_Player = NULL;
    m_Playable = NULL;
}

bool StateMachineBehaviourPlayer::FireBehaviour(StateKey& key, ScriptingArguments &arguments, mecanim::statemachine::StateMachineMessage messageID, bool stateBehaviour) const
{
    bool ret = false;

    StateMachineBehaviourVector const* behaviours = m_Sender->GetStateMachineBehaviours();
    StateMachineBehaviourVectorDescription const* vectorDescription = m_Sender->GetStateMachineBehaviourVectorDescription();

    StateRange range = FindStateBehavioursRange(key, vectorDescription);

    for (mecanim::uint32_t i = range.GetStartIndex(); i < range.GetStopIndex() && IsSenderEnabled(); i++)
    {
        mecanim::uint32_t behaviourIndex = vectorDescription->m_StateMachineBehaviourIndices[i];

        if (behaviourIndex >= behaviours->size())
            continue;

        MonoBehaviour* behaviour = (*behaviours)[behaviourIndex];

        if (behaviour == NULL || behaviour->GetInstance() == SCRIPTING_NULL || !behaviour->GetEnabled())
            continue;

        // m_MessageID should be a distinct value of enum StateMachineMessage
        // if it not the case GetBehaviourMethodName will return null
        // If we need to support this case then we could iterate over all the message and send each
        // message separatly.
        int method = GetBehaviourMethod(messageID);
        if (method == MonoScriptCache::kMethodCount)
        {
            WarningStringObject(Format("Unknow Message ID: %x", messageID), m_Player);
            continue;
        }

        ScriptingMethodPtr methodPtr = behaviour->GetMethod(method);
        if (methodPtr.IsNull())
            continue;

        HPlayable playableHandle;
        int argumentCount =  scripting_method_get_argument_count(methodPtr);
        if ((stateBehaviour && argumentCount == 4) || (!stateBehaviour && argumentCount == 3))
        {
            playableHandle = m_Playable->Handle();
            arguments.AddStruct(&playableHandle);
        }

        ScriptingInvocation   invocation(behaviour->GetInstance(), methodPtr);
        ScriptingExceptionPtr exception = SCRIPTING_NULL;
        invocation.Arguments() = arguments;
        invocation.objectInstanceIDContextForException = behaviour->GetInstanceID();
        invocation.Invoke(&exception);

        ret |= exception == SCRIPTING_NULL;
    }

    return ret;
}

bool StateMachineBehaviourPlayer::FireStateBehaviour(AnimatorStateInfo &info, int layerIndex, mecanim::statemachine::StateMachineMessage messageID) const
{
    ScriptingArguments    arguments;
    arguments.AddObject(Scripting::ScriptingWrapperFor(m_Player));
    arguments.AddStruct(&info);
    arguments.AddInt(layerIndex);

    StateKey stateKey(info.fullPathHash, layerIndex);

    return FireBehaviour(stateKey, arguments, messageID, true);
}

bool StateMachineBehaviourPlayer::FireStateMachineBehaviour(int stateMachineFullPath, int layerIndex, mecanim::statemachine::StateMachineMessage messageID) const
{
    ScriptingArguments    arguments;
    arguments.AddObject(Scripting::ScriptingWrapperFor(m_Player));
    arguments.AddInt(stateMachineFullPath);

    StateKey stateKey(stateMachineFullPath, layerIndex);

    return FireBehaviour(stateKey, arguments, messageID, false);
}

bool StateMachineBehaviourPlayer::IsSenderEnabled() const
{
    return m_Sender->IsInitialized();
}
