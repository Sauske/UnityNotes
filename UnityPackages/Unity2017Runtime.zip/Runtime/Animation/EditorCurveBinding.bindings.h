#pragma once

#include "Runtime/Animation/EditorCurveBinding.h"
#include "Runtime/Scripting/Marshalling/Marshalling.h"

// C++ unmarshalled version of the class EditorCurveBinding.
//
// Needed to be able to use the class in different modules.
// See AnimationUtility.bindings and GameObjectRecorder.bindings.cs.
//
// Could use a forward declaration and keep the definition in
// AnimationUtility.bindings, but then it wouldn't work with
// vectors of EditorCurveBinding.
//
// This should be fixed with the new binding system, but it's
// not ready yet.
struct MonoEditorCurveBinding
{
    ScriptingStringPtr           path;
    ScriptingSystemTypeObjectPtr type;
    ScriptingStringPtr           propertyName;
    int                          isPPtrCurve;
    int                          isDiscreteCurve;
    int                          isPhantom;
    PersistentTypeID             classID;
    int                          monoScriptInstanceID;
};

// These function are defined in the generated file AnimationUtilityBindings.gen.cpp.
bool MonoToEditorCurveBinding(const MonoEditorCurveBinding& src, EditorCurveBinding& dst);
void EditorCurveBindingToMono(const EditorCurveBinding& src, MonoEditorCurveBinding& dst);

// New templated marshalling functions for the new system.
namespace Marshalling
{
    template<>
    inline void Marshal<EditorCurveBinding, MonoEditorCurveBinding>(EditorCurveBinding* marshalled, const MonoEditorCurveBinding* unmarshalled)
    {
        MonoToEditorCurveBinding(*unmarshalled, *marshalled);
    }

    template<>
    inline void Unmarshal<MonoEditorCurveBinding, EditorCurveBinding>(MonoEditorCurveBinding* unmarshalled, const EditorCurveBinding* marshalled)
    {
        EditorCurveBindingToMono(*marshalled, *unmarshalled);
    }
}
