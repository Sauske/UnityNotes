#pragma once

#include "BoundCurveDeprecated.h"

class GameObject;
class Material;
class MonoScript;
class Transform;
class TypeTree;
class TypeTreeIterator;

#include <string>
#include <map>
#include <vector>
#include "Runtime/Allocator/MemoryMacros.h"
#include "Runtime/Mono/MonoScript.h"

#include "Runtime/Core/Containers/hash_map.h"

struct CurveID
{
    const char*   path;
    const Unity::Type* type;
    const char*   attribute;
    MonoScriptPtr   script;
    unsigned      hash;

    CurveID() {}
    CurveID(const char* inPath, const Unity::Type* inType, MonoScriptPtr inScript, const char* inAttribute, unsigned inHash)
    {
        path = inPath;
        attribute = inAttribute;
        type = inType;
        script = inScript;
        hash = inHash;
    }

    friend bool operator==(const CurveID& lhs, const CurveID& rhs)
    {
        if (lhs.hash == rhs.hash && lhs.type == rhs.type)
        {
            int pathCompare = strcmp(lhs.path, rhs.path);
            if (pathCompare == 0)
            {
                int attributeCompare = strcmp(lhs.attribute, rhs.attribute);
                if (attributeCompare == 0)
                    return lhs.script == rhs.script;
                else
                    return false;
            }
            else
                return false;
        }
        return false;
    }

    void CalculateHash();
};

struct hash_curve
{
    unsigned operator()(const CurveID& curve) const
    {
        return curve.hash;
    }
};


class AnimationBinder
{
    typedef std::map<const Unity::Type*, const TypeTree*> TypeTreeCache;
    TypeTreeCache m_TypeTreeCache;

public:
    typedef core::hash_map<CurveID, unsigned, hash_curve> CurveIDLookup;
    typedef dynamic_array<BoundCurveDeprecated> BoundCurves;
    typedef UNITY_VECTOR (kMemAnimation, Transform*) AffectedRootTransforms;

    AnimationBinder() {}
    ~AnimationBinder();

    bool CalculateTargetPtr(const Unity::Type* objectType, Object* targetObject, const char* attribute, void** targetPtr, int* type);

    // Builds outBoundCurves and generates all binding information
    // NOTE: If a curves can not be bound to the target objects, the entry will be removed from the lookup and will also not be in outBoundCurves
    void BindCurves(const CurveIDLookup& lookup, Transform& transform, BoundCurves& outBoundCurves, AffectedRootTransforms& affectedRootTransforms);
    void BindCurves(const CurveIDLookup& lookup, GameObject& rootGameObject, BoundCurves& outBoundCurves);

    static void RemoveUnboundCurves(CurveIDLookup& lookup, BoundCurves& outBoundCurves);

    static void InitCurveIDLookup(CurveIDLookup& lookup);
    static int InsertCurveIDIntoLookup(CurveIDLookup& lookup, const CurveID& curveIDLookup);

    // Simplified curve binding. No support for materials
    bool BindCurve(const CurveID& curveID, BoundCurveDeprecated& bound, Transform& transform);


    // Sets the value on the bound curve.
    // Does not call AwakeFromLoad or SetDirty. You can call SetValueAwakeGeneric or do it yourself.
    static bool SetFloatValue(const BoundCurveDeprecated& bind, float value);

    // Calls AwakeFromLoad or SetDirty on the target
    static void SetValueAwakeGeneric(const BoundCurveDeprecated& bind);

    static bool ShouldAwakeGeneric(const BoundCurveDeprecated& bind) { return bind.targetType == kBindFloat || bind.targetType == kBindFloatToBool || bind.targetType == kBindFloatToInt || bind.targetType == kBindDiscreteInt; }

    static inline bool AnimationFloatToBool(float result)
    {
        return result > 0.001F || result < -0.001F;
    }

    static inline float AnimationBoolToFloat(bool value)
    {
        return value ? 1.0F : 0.0F;
    }

    #if UNITY_EDITOR

    static bool IsAnimatablePropertyOrHasAnimatableChild(const TypeTreeIterator& variable);

    #endif
};

AnimationBinder& GetAnimationBinder();
