#include "UnityPrefix.h"
#include "UniqueBindingMap.h"

#if ENABLE_UNIT_TESTS
#include "Runtime/Testing/Testing.h"

UNIT_TEST_SUITE(UniqueBindingMapTests)
{
    using namespace UnityEngine::Animation;

    class GenericBindingFixture
    {
    public:
        static const BindingHash kDefaultAttribute = UnityEngine::Animation::kUnbound;
        static const BindingHash kDefaultPath = 0xfefefefe;

        static GenericBinding Default()
        {
            GenericBinding b;
            b.path = kDefaultPath;
            b.attribute = kDefaultAttribute;
            b.typeID = Unity::Type::UndefinedPersistentTypeID;
            return b;
        }

        static GenericBinding FromAttribute(BindingHash attribute)
        {
            GenericBinding b = Default();
            b.attribute = attribute;
            return b;
        }

        static GenericBinding FromCustomAttribute(BindingHash attribute)
        {
            GenericBinding b = Default();
            b.customType = attribute;
            return b;
        }

        static GenericBinding ChangeRotationOrder(const GenericBinding & b, UInt8 rotationOrder)
        {
            GenericBinding out = b;
            out.customType = rotationOrder;
            return out;
        }

        static UniqueBindingMap ProvideMap()
        {
            UniqueBindingMap bindingMap;
            GenericBinding emptyKey;
            emptyKey.attribute = -1;
            emptyKey.path = -1;

            return bindingMap;
        }
    };

    // IsRotation should return true for both rotation types
    TEST_FIXTURE(GenericBindingFixture, RotationsAreRotations)
    {
        GenericBinding rotation =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindTransformRotation);
        GenericBinding euler =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindTransformEuler);

        CHECK(rotation.IsRotation());
        CHECK(euler.IsRotation());
    }

    TEST_FIXTURE(GenericBindingFixture, AttributeForComparison)
    {
        GenericBinding rotation =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindTransformRotation);
        GenericBinding euler =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindTransformEuler);
        GenericBinding scale =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindTransformScale);
        GenericBinding f =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindFloat);

        CHECK_MSG(rotation.AttributeForComparison() == rotation.attribute, "Rotation attribute should be unchanged");
        CHECK_MSG(scale.AttributeForComparison() == scale.attribute, "Scale attribute should be unchanged");
        CHECK_MSG(euler.AttributeForComparison() != euler.attribute, "Euler attribute should change");
        CHECK_MSG(rotation.AttributeForComparison() == euler.AttributeForComparison(), "Euler and rotation should be equal for comparison");
        CHECK_MSG(f.AttributeForComparison() == f.attribute, "float attribute should not change");
    }

    // GenericBindingValueArrayUnique should accept rotations as equal if they only differ by
    // their attribute
    TEST_FIXTURE(GenericBindingFixture, EqualRotationsAreEqual)
    {
        GenericBinding rotation =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindTransformRotation);
        GenericBinding euler =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindTransformEuler);

        GenericBindingValueArrayUnique func;
        CHECK_MSG(func(rotation, euler), "Rotations should be equal");
        CHECK_MSG(func(euler, rotation), "Inverting the order shouldn't matter");
    }

    TEST_FIXTURE(GenericBindingFixture, HashFunction)
    {
        GenericBinding position =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindTransformPosition);
        GenericBinding rotation =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindTransformRotation);
        GenericBinding euler =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindTransformEuler);
        GenericBinding scale =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindTransformScale);
        GenericBinding f =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindFloat);

        GenericBindingHashFunctor hash;
        CHECK_MSG(hash(rotation) == hash(rotation), "hash needs to be deterministic");
        CHECK_MSG(hash(rotation) == hash(euler), "euler and rotation need to have the same hash");
        //Sanity checking
        CHECK_MSG(hash(rotation) != hash(scale), "rotation and scale should not have the same hash");
        CHECK_MSG(hash(scale) != hash(position), "scale and position should not have the same hash");
        CHECK_MSG(hash(position) != hash(f), "position and float should not have the same hash");
    }

    TEST_FIXTURE(GenericBindingFixture, RotationOrderShouldNotAffectUniqueness)
    {
        GenericBinding euler =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindTransformEuler);
        GenericBinding rot =
            GenericBindingFixture::FromAttribute(UnityEngine::Animation::kBindTransformRotation);
        GenericBinding xyz =
            GenericBindingFixture::ChangeRotationOrder(euler, UnityEngine::Animation::kEulerOrderXYZ);
        GenericBinding xzy =
            GenericBindingFixture::ChangeRotationOrder(euler, UnityEngine::Animation::kEulerOrderXZY);
        GenericBinding zxy =
            GenericBindingFixture::ChangeRotationOrder(euler, UnityEngine::Animation::kEulerOrderZXY);
        GenericBinding yxz =
            GenericBindingFixture::ChangeRotationOrder(euler, UnityEngine::Animation::kEulerOrderYXZ);
        GenericBinding yzx =
            GenericBindingFixture::ChangeRotationOrder(euler, UnityEngine::Animation::kEulerOrderYZX);
        GenericBinding zyx =
            GenericBindingFixture::ChangeRotationOrder(euler, UnityEngine::Animation::kEulerOrderZYX);

        UniqueBindingMap uniqueMap = GenericBindingFixture::ProvideMap();

        uniqueMap.insert(std::make_pair(euler, BoundIndex()));
        uniqueMap.insert(std::make_pair(rot, BoundIndex()));
        uniqueMap.insert(std::make_pair(xyz, BoundIndex()));
        uniqueMap.insert(std::make_pair(xzy, BoundIndex()));
        uniqueMap.insert(std::make_pair(zxy, BoundIndex()));
        uniqueMap.insert(std::make_pair(yxz, BoundIndex()));
        uniqueMap.insert(std::make_pair(yzx, BoundIndex()));
        uniqueMap.insert(std::make_pair(zyx, BoundIndex()));
        CHECK_MSG(uniqueMap.size() == 1, "All those bindings must map to the same value");
    }

    TEST_FIXTURE(GenericBindingFixture, CustomPPtrBindingsAreUnique)
    {
        GenericBinding sprite =
            GenericBindingFixture::FromCustomAttribute(UnityEngine::Animation::kSpriteRendererPPtrBinding);
        GenericBinding material =
            GenericBindingFixture::FromCustomAttribute(UnityEngine::Animation::kRendererMaterialPPtrBinding);

        UniqueBindingMap uniqueMap = GenericBindingFixture::ProvideMap();

        uniqueMap.insert(std::make_pair(sprite, BoundIndex()));
        uniqueMap.insert(std::make_pair(material, BoundIndex()));

        CHECK_MSG(uniqueMap.size() == 2, "Expecting separate PPtr bindings");
    }
}
#endif
