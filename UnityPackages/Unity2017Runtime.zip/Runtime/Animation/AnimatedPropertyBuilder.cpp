#include "UnityPrefix.h"

#include "Runtime/Animation/AnimatedPropertyBuilder.h"
#include "Runtime/Animation/AnimatedPropertyEvaluator.h"
#include "Runtime/Animation/AnimatedProperty.h"
#include "Runtime/Animation/AnimatedPropertyVector3.h"
#include "Runtime/Animation/GenericAnimationBindingCache.h"
#include "Runtime/Animation/BoundCurve.h"
#include "Runtime/Director/Core/PropertyAccessorPolicy.h"
#include "Runtime/Mono/MonoBehaviour.h"
#include "Runtime/mecanim/generic/crc32.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/BaseClasses/IsPlaying.h"

IAnimatedPropertyEvaluator* AnimatedPropertyBuilder::Build(AnimationClip* clip, ScriptingObjectPtr target)
{
    if (!clip)
        return NULL;

    AnimatedPropertyEvaluator* evaluator = UNITY_NEW(AnimatedPropertyEvaluator, kMemAnimation)();
    evaluator->BuildFromScriptableObject(clip, target);
    return evaluator;
}
