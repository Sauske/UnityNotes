#pragma once

#include "Runtime/Math/Vector3.h"
#include "Runtime/Math/Quaternion.h"
#include "Runtime/Scripting/BindingsDefs.h"
#include "Runtime/Scripting/ScriptingTypes.h"

struct SkeletonBone
{
    DEFINE_GET_TYPESTRING(SkeletonBone)

    SkeletonBone()
        : m_Position(Vector3f::zero),
        m_Rotation(Quaternionf::identity()),
        m_Scale(Vector3f::one)
    {
    }

    core::string    m_Name;
    core::string    m_ParentName;
    Vector3f    m_Position;
    Quaternionf m_Rotation;
    Vector3f    m_Scale;

    bool operator==(SkeletonBone const& other) const
    {
        return m_Name == other.m_Name &&
            m_ParentName == other.m_ParentName &&
            m_Position == other.m_Position &&
            m_Rotation == other.m_Rotation &&
            m_Scale == other.m_Scale;
    }

    template<class TransferFunction>
    inline void Transfer(TransferFunction& transfer)
    {
        TRANSFER(m_Name);
        TRANSFER(m_ParentName);
        TRANSFER(m_Position);
        TRANSFER(m_Rotation);
        TRANSFER(m_Scale);
    }
};
BIND_MANAGED_TYPE_NAME(SkeletonBone, UnityEngine_SkeletonBone);

struct SkeletonBoneLimit
{
    DEFINE_GET_TYPESTRING(SkeletonBoneLimit)

    SkeletonBoneLimit()
        : m_Min(Vector3f::zero),
        m_Max(Vector3f::zero),
        m_Value(Vector3f::zero),
        m_Length(0.f),
        m_Modified(false)
    {
    }

    Vector3f    m_Min;
    Vector3f    m_Max;
    Vector3f    m_Value;
    float       m_Length;
    bool        m_Modified;

    bool operator==(SkeletonBoneLimit const& other) const
    {
        return m_Min == other.m_Min &&
            m_Max == other.m_Max &&
            m_Value == other.m_Value &&
            m_Length == other.m_Length &&
            m_Modified == other.m_Modified;
    }

    template<class TransferFunction>
    inline void Transfer(TransferFunction& transfer)
    {
        TRANSFER(m_Min);
        TRANSFER(m_Max);
        TRANSFER(m_Value);
        TRANSFER(m_Length);
        TRANSFER(m_Modified);
        transfer.Align();
    }
};


struct HumanBone
{
    DEFINE_GET_TYPESTRING(HumanBone)

    HumanBone();
    HumanBone(core::string const& humanName);

    core::string            m_BoneName;
    core::string            m_HumanName;
    SkeletonBoneLimit   m_Limit;
    //Vector3f          m_ColliderPosition;
    //Quaternionf           m_ColliderRotation;
    //Vector3f          m_ColliderScale;


    bool operator==(HumanBone const& other) const
    {
        return m_BoneName == other.m_BoneName &&
            m_HumanName == other.m_HumanName &&
            m_Limit == other.m_Limit;
    }

    template<class TransferFunction>
    inline void Transfer(TransferFunction& transfer)
    {
        TRANSFER(m_BoneName);
        TRANSFER(m_HumanName);
        TRANSFER(m_Limit);

        //TRANSFER(m_ColliderPosition);
        //TRANSFER(m_ColliderRotation);
        //TRANSFER(m_ColliderScale);
    }
};


typedef std::vector<HumanBone> HumanBoneList;
typedef std::vector<SkeletonBone> SkeletonBoneList;


struct HumanDescription
{
    HumanBoneList m_Human;
    SkeletonBoneList m_Skeleton;

    float   m_ArmTwist;
    float   m_ForeArmTwist;
    float   m_UpperLegTwist;
    float   m_LegTwist;

    float   m_ArmStretch;
    float   m_LegStretch;

    float   m_FeetSpacing;

    core::string    m_RootMotionBoneName;
    Quaternionf m_RootMotionBoneRotation;

    bool    m_HasTranslationDoF;

    bool    m_HasExtraRoot;
    bool    m_SkeletonHasParents;

    HumanDescription()
    {
        Reset();
    }

    void Reset()
    {
        m_Human.clear();
        m_Skeleton.clear();

        m_ArmTwist = 0.5f;
        m_ForeArmTwist = 0.5f;
        m_UpperLegTwist = 0.5f;
        m_LegTwist = 0.5f;
        m_ArmStretch = 0.05f;
        m_LegStretch = 0.05f;

        m_FeetSpacing = 0.0f;

        m_RootMotionBoneName = "";
        m_RootMotionBoneRotation = Quaternionf(0, 0, 0, 1);

        m_HasTranslationDoF = false;

        m_HasExtraRoot = false;

        m_SkeletonHasParents = true;
    }

    bool operator==(HumanDescription const& other) const
    {
        return m_Human == other.m_Human &&
            m_Skeleton == other.m_Skeleton &&
            m_ArmTwist == other.m_ArmTwist &&
            m_ForeArmTwist == other.m_ForeArmTwist &&
            m_UpperLegTwist == other.m_UpperLegTwist &&
            m_LegTwist == other.m_LegTwist &&
            m_ArmStretch == other.m_ArmStretch &&
            m_LegStretch == other.m_LegStretch &&
            m_FeetSpacing == other.m_FeetSpacing &&
            m_RootMotionBoneName == other.m_RootMotionBoneName &&
            m_RootMotionBoneRotation == other.m_RootMotionBoneRotation &&
            m_HasTranslationDoF == other.m_HasTranslationDoF &&
            m_HasExtraRoot == other.m_HasExtraRoot &&
            m_SkeletonHasParents == other.m_SkeletonHasParents;
    }

    DEFINE_GET_TYPESTRING(HumanDescription)

    template<class TransferFunction>
    inline void Transfer(TransferFunction& transfer)
    {
        transfer.SetVersion(2);

        TRANSFER(m_Human);
        TRANSFER(m_Skeleton);

        TRANSFER(m_ArmTwist);
        TRANSFER(m_ForeArmTwist);
        TRANSFER(m_UpperLegTwist);
        TRANSFER(m_LegTwist);
        TRANSFER(m_ArmStretch);
        TRANSFER(m_LegStretch);
        TRANSFER(m_FeetSpacing);
        TRANSFER(m_RootMotionBoneName);
        TRANSFER(m_RootMotionBoneRotation);
        TRANSFER(m_HasTranslationDoF);
        TRANSFER(m_HasExtraRoot);
        TRANSFER(m_SkeletonHasParents);

        transfer.Align();

        if (transfer.IsVersionSmallerOrEqual(1))
            m_SkeletonHasParents = false;
    }
};
BIND_MANAGED_TYPE_NAME(HumanDescription, UnityEngine_HumanDescription);

struct MonoSkeletonBone
{
    ScriptingStringPtr name;
    ScriptingStringPtr parentName;
    Vector3f    position;
    Quaternionf rotation;
    Vector3f    scale;
};

void SkeletonBoneToMono(const SkeletonBone &src, MonoSkeletonBone &dest);
void SkeletonBoneFromMono(const MonoSkeletonBone &src, SkeletonBone &dest);

struct MonoHumanLimit
{
    Vector3f    m_Min;
    Vector3f    m_Max;
    Vector3f    m_Center;
    float       m_AxisLength;
    int         m_UseDefaultValues;
};

void HumanLimitToMono(const SkeletonBoneLimit &src, MonoHumanLimit &dest);
void HumanLimitFromMono(const MonoHumanLimit &src, SkeletonBoneLimit &dest);

struct MonoHumanBone
{
    ScriptingStringPtr  m_BoneName;
    ScriptingStringPtr  m_HumanName;
    MonoHumanLimit      m_Limit;
};

void HumanBoneToMono(const HumanBone &src, MonoHumanBone &dest);
void HumanBoneFromMono(const MonoHumanBone &src, HumanBone &dest);

struct MonoHumanDescription
{
    ScriptingArrayPtr   m_Human;
    ScriptingArrayPtr   m_Skeleton;

    float               m_ArmTwist;
    float               m_ForeArmTwist;
    float               m_UpperLegTwist;
    float               m_LegTwist;
    float               m_ArmStretch;
    float               m_LegStretch;
    float               m_FeetSpacing;
    bool                m_HasTranslationDoF;
};

void HumanDescriptionToMono(const HumanDescription &src, MonoHumanDescription &dest);
void HumanDescriptionFromMono(const MonoHumanDescription &src, HumanDescription &dest);
