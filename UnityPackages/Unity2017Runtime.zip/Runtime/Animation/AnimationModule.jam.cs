using JamSharp.Runtime;
using static JamSharp.Runtime.BuiltinRules;
using External.Jamplus.builds.bin.modules;
using External.Jamplus.builds.bin;

namespace Runtime.Animation
{
    [OriginalJamFile("Runtime/Animation/AnimationModule.jam")]
    class AnimationModule : ConvertedJamFile
    {
        internal static void TopLevel()
        {
            RegisterRuleWithReturnValue("AnimationModule_ReportCpp", AnimationModule_ReportCpp);
            RegisterRuleWithReturnValue("AnimationModule_ReportBindings", AnimationModule_ReportBindings);
            RegisterRuleWithReturnValue("AnimationModule_ReportCs", AnimationModule_ReportCs);
            //# For Coexist with old system
            RegisterRule("AnimationModule_ReportIncludes", AnimationModule_ReportIncludes);
        }

        static JamList AnimationModule_ReportCpp()
        {
            JamList animationSources = Projects.Jam.Rules.UnityRules.Unity_Glob($"{Vars.TOP}/Runtime/Animation", JamList("cpp", "h", "jam.cs"), Vars.TOP);
            JamList mecanimSources = Projects.Jam.Rules.UnityRules.Unity_Glob($"{Vars.TOP}/Runtime/mecanim", JamList("cpp", "h"), Vars.TOP);

            return JamList(animationSources, mecanimSources);
        }

        static JamList AnimationModule_ReportBindings()
        {
            return Projects.Jam.Rules.UnityRules.Unity_Glob($"{Vars.TOP}/Runtime/Animation/ScriptBindings", JamList("bindings"), Vars.TOP);
        }

        static JamList AnimationModule_ReportCs()
        {
            JamList animationManaged = Projects.Jam.Rules.UnityRules.Unity_Glob($"{Vars.TOP}/Runtime/Animation/Managed", JamList("cs"), Vars.TOP);
            JamList animationScriptBindings = Projects.Jam.Rules.UnityRules.Unity_Glob($"{Vars.TOP}/Runtime/Animation/ScriptBindings", JamList("cs"), Vars.TOP);

            return JamList(animationManaged, animationScriptBindings);
        }

        static void AnimationModule_ReportIncludes()
        {
        }
    }
}
