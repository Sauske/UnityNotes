#pragma once

class Animation;

void InitializeAnimationStateNetworkProvider();
void CleanupAnimationStateNetworkProvider();
