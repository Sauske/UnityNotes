#include "UnityPrefix.h"

#include "AvatarMask.h"

#include "Runtime/Transform/Transform.h"
#include "Runtime/Serialize/TransferFunctions/TransferNameConversions.h"
#include "Runtime/mecanim/skeleton/skeleton.h"
#include "Runtime/mecanim/generic/crc32.h"

#include "Runtime/BaseClasses/MessageIdentifier.h"

DECLARE_MESSAGE_IDENTIFIER(kDidModifyMotion);

#define DIRTY_AND_INVALIDATE() m_UserList.SendMessage(kDidModifyMotion); SetDirty();

mecanim::human::HumanPoseMask HumanPoseMaskFromBodyMask(dynamic_array<UInt32> const &bodyMask)
{
    mecanim::human::HumanPoseMask poseMask;

    poseMask.set(mecanim::human::kMaskRootIndex, bodyMask[kRoot] != 0);

    for (int goalIter = 0; goalIter < mecanim::human::kLastGoal; goalIter++)
    {
        poseMask.set(mecanim::human::kMaskGoalStartIndex + goalIter, bodyMask[kLeftFootIK + goalIter] != 0);
    }

    for (int dofIter = 0; dofIter < mecanim::human::kLastBodyDoF; dofIter++)
    {
        poseMask.set(mecanim::human::kMaskDoFStartIndex + mecanim::human::kBodyDoFStart + dofIter, bodyMask[kBody] != 0);
    }

    for (int dofIter = 0; dofIter < mecanim::human::kLastHeadDoF; dofIter++)
    {
        poseMask.set(mecanim::human::kMaskDoFStartIndex + mecanim::human::kHeadDoFStart + dofIter, bodyMask[kHead] != 0);
    }

    for (int dofIter = 0; dofIter < mecanim::human::kLastLegDoF; dofIter++)
    {
        poseMask.set(mecanim::human::kMaskDoFStartIndex + mecanim::human::kLeftLegDoFStart + dofIter, bodyMask[kLeftLowerLeg] != 0);
        poseMask.set(mecanim::human::kMaskDoFStartIndex + mecanim::human::kRightLegDoFStart + dofIter, bodyMask[kRightLowerLeg] != 0);
    }

    for (int dofIter = 0; dofIter < mecanim::human::kLastArmDoF; dofIter++)
    {
        poseMask.set(mecanim::human::kMaskDoFStartIndex + mecanim::human::kLeftArmDoFStart + dofIter, bodyMask[kLeftUpperArm] != 0);
        poseMask.set(mecanim::human::kMaskDoFStartIndex + mecanim::human::kRightArmDoFStart + dofIter, bodyMask[kRightUpperArm] != 0);
    }

    poseMask.set(mecanim::human::kMaskLeftHand, bodyMask[kLeftFingers] != 0);
    poseMask.set(mecanim::human::kMaskRightHand, bodyMask[kRightFingers] != 0);

    for (int dofIter = 0; dofIter < mecanim::human::kLastBodyTDoF; dofIter++)
    {
        poseMask.set(mecanim::human::kMaskTDoFStartIndex + mecanim::human::kBodyTDoFStart + dofIter, bodyMask[kBody] != 0);
    }

    for (int dofIter = 0; dofIter < mecanim::human::kLastHeadTDoF; dofIter++)
    {
        poseMask.set(mecanim::human::kMaskTDoFStartIndex + mecanim::human::kHeadTDoFStart + dofIter, bodyMask[kHead] != 0);
    }

    for (int dofIter = 0; dofIter < mecanim::human::kLastLegTDoF; dofIter++)
    {
        poseMask.set(mecanim::human::kMaskTDoFStartIndex + mecanim::human::kLeftLegTDoFStart + dofIter, bodyMask[kLeftLowerLeg] != 0);
        poseMask.set(mecanim::human::kMaskTDoFStartIndex + mecanim::human::kRightLegTDoFStart + dofIter, bodyMask[kRightLowerLeg] != 0);
    }

    for (int dofIter = 0; dofIter < mecanim::human::kLastArmTDoF; dofIter++)
    {
        poseMask.set(mecanim::human::kMaskTDoFStartIndex + mecanim::human::kLeftArmTDoFStart + dofIter, bodyMask[kLeftUpperArm] != 0);
        poseMask.set(mecanim::human::kMaskTDoFStartIndex + mecanim::human::kRightArmTDoFStart + dofIter, bodyMask[kRightUpperArm] != 0);
    }

    return poseMask;
}

mecanim::skeleton::SkeletonMask* SkeletonMaskFromTransformMask(AvatarMask const &mask, mecanim::memory::Allocator& alloc)
{
    dynamic_array<mecanim::skeleton::SkeletonMaskElement> skeletonMaskElements(kMemTempAlloc);
    skeletonMaskElements.reserve(mask.m_Elements.size());

    TransformMaskElementList::const_iterator it;
    for (it = mask.m_Elements.begin(); it != mask.m_Elements.end(); ++it)
    {
        mecanim::uint32_t pathHash = mecanim::processCRC32(it->m_Path.c_str());

        mecanim::skeleton::SkeletonMaskElement element;
        element.m_PathHash = pathHash;
        element.m_Weight = it->m_Weight;

        skeletonMaskElements.push_back(element);
    }

    return skeletonMaskElements.size() > 0 ? mecanim::skeleton::CreateSkeletonMask(skeletonMaskElements.size(), &skeletonMaskElements.front(), alloc) : NULL;
}

AvatarMask::AvatarMask(MemLabelId label, ObjectCreationMode mode) : Super(label, mode), m_UserList(this), m_Mask(kLastMaskBodyPart, 1, label), m_Elements(label)
{
}

void AvatarMask::ThreadedCleanup()
{
}

void AvatarMask::MainThreadCleanup()
{
    m_UserList.Clear();
    Super::MainThreadCleanup();
}

void AvatarMask::InitializeClass()
{
    RegisterAllowNameConversion("AvatarMask", "elements", "m_Elements");

    RegisterAllowNameConversion("TransformMaskElement", "path", "m_Path");
    RegisterAllowNameConversion("TransformMaskElement", "weight", "m_Weight");
}

void AvatarMask::AwakeFromLoad(AwakeFromLoadMode mode)
{
    Super::AwakeFromLoad(mode);
    m_UserList.SendMessage(kDidModifyMotion);
}

void AvatarMask::Reset()
{
    Super::Reset();

    m_Mask = dynamic_array<UInt32>(kLastMaskBodyPart, 1, m_Mask.get_memory_label());
    m_Elements.clear();
}

int  AvatarMask::GetBodyPartCount() const
{
    return kLastMaskBodyPart;
}

bool  AvatarMask::GetBodyPart(int index)
{
    if (!ValidateBodyPartIndex(index))
        return false;

    return m_Mask[index] != 0;
}

void  AvatarMask::SetBodyPart(int index, bool value)
{
    if (!ValidateBodyPartIndex(index))
        return;

    UInt32 ui32Value = value ? 1 : 0;
    if (m_Mask[index] != ui32Value)
    {
        m_Mask[index] = ui32Value;
        DIRTY_AND_INVALIDATE();
    }
}

mecanim::human::HumanPoseMask AvatarMask::GetHumanPoseMask() const
{
    return HumanPoseMaskFromBodyMask(m_Mask);
}

void AvatarMask::AddSelfToDependencies(UserList& dependencies)
{
    dependencies.AddUser(m_UserList);
}

IMPLEMENT_REGISTER_CLASS(AvatarMask, 319);
IMPLEMENT_OBJECT_SERIALIZE(AvatarMask);

template<class TransferFunction>
void AvatarMask::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);

    TRANSFER(m_Mask);
    TRANSFER(m_Elements);
}

bool AvatarMask::HasFeetIK()
{
    return GetBodyPart(kLeftFootIK) && GetBodyPart(kRightFootIK);
}

void AvatarMask::SetTransformCount(int count)
{
    count = std::max(0, count);
    if (count != m_Elements.size())
    {
        m_Elements.resize_initialized(count);
        DIRTY_AND_INVALIDATE();
    }
}

int AvatarMask::GetTransformCount() const
{
    return m_Elements.size();
}

core::string AvatarMask::GetTransformPath(int index)
{
    if (!ValidateTransformIndex(index))
        return "";

    return m_Elements[index].m_Path;
}

void   AvatarMask::SetTransformPath(int index, core::string const& path)
{
    if (!ValidateTransformIndex(index))
        return;

    if (m_Elements[index].m_Path != path)
    {
        m_Elements[index].m_Path = path;
        DIRTY_AND_INVALIDATE();
    }
}

float AvatarMask::GetTransformWeight(int index)
{
    if (!ValidateTransformIndex(index))
        return 0;

    return m_Elements[index].m_Weight;
}

void  AvatarMask::SetTransformWeight(int index, float weight)
{
    if (!ValidateTransformIndex(index))
        return;

    if (m_Elements[index].m_Weight != weight)
    {
        m_Elements[index].m_Weight = weight;
        DIRTY_AND_INVALIDATE();
    }
}

void AvatarMask::AddTransformPath(Transform& transform, bool recursive)
{
    AddTransformPath(transform, recursive, core::string());
    DIRTY_AND_INVALIDATE();
}

void AvatarMask::AddTransformPath(Transform& transform, bool recursive, const core::string& path)
{
    core::string transformPath = path;
    if (transformPath.empty())
        transformPath = CalculateTransformPath(transform, &transform.GetRoot());
    else
        AppendTransformPath(transformPath, transform.GetName());

    TransformMaskElement& element = m_Elements.emplace_back();
    element.m_Path = transformPath;
    element.m_Weight = 1.0f;

    if (recursive)
    {
        for (int i = 0; i < transform.GetChildrenCount(); ++i)
        {
            Transform& child = transform.GetChild(i);
            AddTransformPath(child, recursive, transformPath);
        }
    }
}

namespace
{
    struct StartsWith
    {
        typedef core::string::size_type size_type;
        const core::string&  m_String;

        StartsWith(const core::string&  string) : m_String(string) {}
        bool operator()(const TransformMaskElement& element)
        {
            size_type size = m_String.size();

            if (size == 0)
                return true;
            if (size > element.m_Path.size())
                return false;

            return std::search(element.m_Path.begin(), element.m_Path.begin() + size, m_String.begin(), m_String.end()) == element.m_Path.begin();
        }
    };

    struct Equals
    {
        typedef core::string::size_type size_type;
        const core::string&  m_String;

        Equals(const core::string& string) : m_String(string) {}
        bool operator()(const TransformMaskElement& element)
        {
            size_type size = m_String.size();
            if (size != element.m_Path.size())
                return false;

            return strcmp(element.m_Path.c_str(), m_String.c_str()) == 0;
        }
    };
}

void AvatarMask::RemoveTransformPath(Transform& transform, bool recursive)
{
    core::string transformPath = CalculateTransformPath(transform, &transform.GetRoot());

    TransformMaskElementList::iterator it = m_Elements.end();
    if (recursive)
        it = std::remove_if(m_Elements.begin(), m_Elements.end(), StartsWith(transformPath));
    else
        it =  std::remove_if(m_Elements.begin(), m_Elements.end(), Equals(transformPath));

    m_Elements.erase(it, m_Elements.end());

    DIRTY_AND_INVALIDATE();
}

mecanim::skeleton::SkeletonMask* AvatarMask::GetSkeletonMask(mecanim::memory::Allocator& alloc) const
{
    return SkeletonMaskFromTransformMask(*this, alloc);
}

bool AvatarMask::ValidateBodyPartIndex(int index) const
{
    if (index >= 0 && index < GetBodyPartCount())
    {
        return true;
    }

    ErrorString("Invalid BodyPart Index");
    return false;
}

bool AvatarMask::ValidateTransformIndex(int index) const
{
    if (index >= 0 && index < GetTransformCount())
    {
        return true;
    }

    ErrorString("Invalid Transform Index");
    return false;
}

#undef DIRTY_AND_INVALIDATE
