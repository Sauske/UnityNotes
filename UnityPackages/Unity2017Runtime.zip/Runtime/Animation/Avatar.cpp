#include "UnityPrefix.h"

#include "Avatar.h"

#include "Runtime/mecanim/math/axes.h"

DEFINE_MESSAGE_IDENTIFIER(kDidModifyAvatar, ("OnDidModifyAvatar", MessageIdentifier::kDontSendToScripts));

Avatar::Avatar(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode),
    m_Allocator(label, 1024 * 4),
    m_Avatar(0),
    m_AvatarSize(0),
    m_ObjectUsers(this)
{
}

void Avatar::ThreadedCleanup()
{
}

void Avatar::MainThreadCleanup()
{
    NotifyObjectUsers(kDidModifyAvatar);
    Super::MainThreadCleanup();
}

void Avatar::NotifyObjectUsers(const MessageIdentifier& msg)
{
    m_ObjectUsers.SendMessage(msg);
}

void Avatar::AwakeFromLoad(AwakeFromLoadMode mode)
{
    Super::AwakeFromLoad(mode);
    NotifyObjectUsers(kDidModifyAvatar);
}

void Avatar::CheckConsistency()
{
    Super::CheckConsistency();
    mecanim::animation::AvatarConstant* cst = GetAsset();
    if (cst != 0)
    {
        //@TODO: It looks like CheckConsistency is being abused to generate m_HumanSkeletonIndexArray??? Shouldn't the model importer do this or whatever generates the avatar constant

        // [case 522188] This is an old maya file with avatar already created.
        // At this time m_HumanSkeletonIndexArray was not there and in this particular case the user did open
        // the file on a pc without maya so we couldn't reimport the file and create a valid avatar.
        if (cst->isHuman() && cst->m_HumanSkeletonIndexCount != cst->m_Human->m_Skeleton->m_Count)
        {
            cst->m_HumanSkeletonIndexCount = cst->m_Human->m_Skeleton->m_Count;

            // No need to deallocate memory here since we are using the ChainedAllocator.
            // the allocator will release the memory on next reset().
            cst->m_HumanSkeletonIndexArray = m_Allocator.ConstructArray<mecanim::int32_t>(cst->m_HumanSkeletonIndexCount);

            mecanim::skeleton::SkeletonBuildIndexArray(cst->m_HumanSkeletonIndexArray.Get(), cst->m_Human->m_Skeleton.Get(), cst->m_AvatarSkeleton.Get());
        }
    }
}

IMPLEMENT_REGISTER_CLASS(Avatar, 90);
IMPLEMENT_OBJECT_SERIALIZE(Avatar);

template<class TransferFunction>
void Avatar::Transfer(TransferFunction& transfer)
{
    SETPROFILERLABEL(AvatarConstant);

    Super::Transfer(transfer);

    transfer.SetUserData(&m_Allocator);
    TRANSFER_BLOB(m_Avatar, m_AvatarSize);
    TRANSFER(m_TOS);
}

void Avatar::SetAsset(mecanim::animation::AvatarConstant* avatarConstant, TOSVector const& tos)
{
    // Free previously allocated memory
    m_Allocator.Reset();

    size_t size = m_AvatarSize;
    m_Avatar = CopyBlob(*avatarConstant, m_Allocator, size);
    m_AvatarSize = size;
    m_TOS = tos;

    NotifyObjectUsers(kDidModifyAvatar);
}

mecanim::animation::AvatarConstant* Avatar::GetAsset()
{
    return m_Avatar;
}

const mecanim::animation::AvatarConstant*   Avatar::GetAsset() const
{
    return m_Avatar;
}

TOSVector const& Avatar::GetTOS() const
{
    return m_TOS;
}

bool    Avatar::IsValid() const
{
    return GetAsset() != 0;
}

bool Avatar::IsHuman() const
{
    return m_Avatar && m_Avatar->isHuman();
}

bool Avatar::HasRootMotion() const
{
    return m_Avatar && m_Avatar->m_RootMotionBoneIndex != -1;
}

float  Avatar::GetHumanScale() const
{
    return IsHuman() ? m_Avatar->m_Human->m_Scale : 1;
}

float   Avatar::GetLeftFeetBottomHeight() const
{
    if (!IsHuman())
        return 0.f;

    return HumanGetFootHeight(m_Avatar->m_Human.Get(), true);
}

float   Avatar::GetRightFeetBottomHeight() const
{
    if (!IsHuman())
        return 0.f;

    return HumanGetFootHeight(m_Avatar->m_Human.Get(), false);
}

void Avatar::SetParameter(int parameterId, float value)
{
    mecanim::animation::AvatarConstant* avatar = GetAsset();
    if (avatar)
    {
        switch (parameterId)
        {
            case UpperArmTwist: avatar->m_Human->m_ArmTwist = value; break;
            case LowerArmTwist: avatar->m_Human->m_ForeArmTwist = value; break;
            case UpperLegTwist: avatar->m_Human->m_UpperLegTwist = value; break;
            case LowerLegTwsit: avatar->m_Human->m_LegTwist = value; break;
            case ArmStretch: avatar->m_Human->m_ArmStretch = value; break;
            case LegStretch: avatar->m_Human->m_LegStretch = value; break;
            case FeetSpacing: avatar->m_Human->m_FeetSpacing = value; break;
            default: break;
        }
    }
}

void    Avatar::SetMuscleMinMax(int muscleId, float min, float max)
{
    int humanId = HumanTrait::BoneFromMuscle(muscleId);

    mecanim::animation::AvatarConstant* avatar = GetAsset();

    int boneId = HumanTrait::GetBoneId(*this, humanId);
    if (boneId != -1)
    {
        int axesId = avatar->m_Human->m_Skeleton->m_Node[boneId].m_AxesId;
        if (axesId != -1)
        {
            math::float3 maxv = avatar->m_Human->m_Skeleton->m_AxesArray[axesId].m_Limit.m_Max;
            math::float3 minv = avatar->m_Human->m_Skeleton->m_AxesArray[axesId].m_Limit.m_Min;

            int musclex = HumanTrait::MuscleFromBone(humanId, 0);
            int muscley = HumanTrait::MuscleFromBone(humanId, 1);
            int musclez = HumanTrait::MuscleFromBone(humanId, 2);

            if (musclex == muscleId)
            {
                minv.x = math::radians(min);
                maxv.x = math::radians(max);
            }
            else if (muscley == muscleId)
            {
                minv.y = math::radians(min);
                maxv.y = math::radians(max);
            }
            else if (musclez == muscleId)
            {
                minv.z = math::radians(min);
                maxv.z = math::radians(max);
            }

            avatar->m_Human->m_Skeleton->m_AxesArray[axesId].m_Limit.m_Max = maxv;
            avatar->m_Human->m_Skeleton->m_AxesArray[axesId].m_Limit.m_Min = minv;
        }
    }
}

float       Avatar::GetAxisLength(int humanId) const
{
    float ret = 0.0f;

    mecanim::animation::AvatarConstant const* avatar = GetAsset();

    int boneId =  HumanTrait::GetBoneId(*this, humanId);
    if (boneId != -1)
    {
        int axesId = avatar->m_Human->m_Skeleton->m_Node[boneId].m_AxesId;
        if (axesId != -1)
        {
            ret = avatar->m_Human->m_Skeleton->m_AxesArray[axesId].m_Length;
        }
    }

    return ret;
}

Quaternionf Avatar::GetPreRotation(int humanId) const
{
    math::float4 ret = math::quatIdentity();

    mecanim::animation::AvatarConstant const* avatar = GetAsset();

    int boneId =  HumanTrait::GetBoneId(*this, humanId);
    if (boneId != -1)
    {
        int axesId = avatar->m_Human->m_Skeleton->m_Node[boneId].m_AxesId;
        if (axesId != -1)
        {
            ret = avatar->m_Human->m_Skeleton->m_AxesArray[axesId].m_PreQ;
        }
    }

    return float4ToQuaternionf(ret);
}

Quaternionf Avatar::GetPostRotation(int humanId) const
{
    math::float4 ret = math::quatIdentity();

    mecanim::animation::AvatarConstant const* avatar = GetAsset();

    int boneId =  HumanTrait::GetBoneId(*this, humanId);
    if (boneId != -1)
    {
        int axesId = avatar->m_Human->m_Skeleton->m_Node[boneId].m_AxesId;
        if (axesId != -1)
        {
            ret = avatar->m_Human->m_Skeleton->m_AxesArray[axesId].m_PostQ;
        }
    }

    return float4ToQuaternionf(ret);
}

Quaternionf Avatar::GetZYPostQ(int index, Quaternionf const& parentQ, Quaternionf const& q) const
{
    mecanim::animation::AvatarConstant const* cst = GetAsset();

    math::float4 qzypost = math::quatIdentity();

    int id = HumanTrait::GetBoneId(*this, index);
    if (id != -1)
    {
        int axesId = cst->m_Human->m_Skeleton->m_Node[id].m_AxesId;
        if (axesId != -1)
        {
            math::float4 mpq = QuaternionfTofloat4(parentQ);
            math::float4 mq = QuaternionfTofloat4(q);

            math::Axes const& axes = cst->m_Human->m_Skeleton->m_AxesArray[axesId];

            math::float4 lq = math::normalize(math::quatMul(math::quatConj(mpq), mq));
            math::float3 dofzy = math::ToAxes(axes, lq);
            dofzy.x = 0.f;
            qzypost = math::normalize(math::quatMul(mpq, math::quatMul(math::FromAxes(axes, dofzy), axes.m_PostQ)));
        }
    }
    return float4ToQuaternionf(qzypost);
}

Quaternionf Avatar::GetZYRoll(int index, Vector3f const& v) const
{
    mecanim::animation::AvatarConstant const* cst = GetAsset();

    math::float4 qzyroll = math::quatIdentity();

    int id = HumanTrait::GetBoneId(*this, index);

    if (id != -1)
    {
        int axesId = cst->m_Human->m_Skeleton->m_Node[id].m_AxesId;
        if (axesId != -1)
        {
            math::Axes const& axes = cst->m_Human->m_Skeleton->m_AxesArray[axesId];
            math::float3 uvw = math::float3(v.x, v.y, v.z);
            qzyroll = math::ZYRoll2Quat(math::chgsign(math::halfTan(math::LimitUnproject(axes.m_Limit, uvw)), axes.m_Sgn));
        }
    }
    return float4ToQuaternionf(qzyroll);
}

Vector3f Avatar::GetLimitSign(int index) const
{
    mecanim::animation::AvatarConstant const* cst = GetAsset();
    int id = HumanTrait::GetBoneId(*this, index);

    Vector3f sign = Vector3f::one;
    if (id != -1)
    {
        int axesId = cst->m_Human->m_Skeleton->m_Node[id].m_AxesId;
        if (axesId != -1)
        {
            sign = float3ToVector3f(cst->m_Human->m_Skeleton->m_AxesArray[axesId].m_Sgn);
        }
    }
    return sign;
}

std::vector<core::string>* HumanTrait::m_MuscleName = NULL;
std::vector<core::string>* HumanTrait::m_BoneName = NULL;

int *HumanTrait::m_BoneIndexFromMono = NULL;
int *HumanTrait::m_BoneIndexToMono = NULL;
std::vector<core::string>* HumanTrait::m_MonoBoneName = NULL;

void HumanTrait::InitializeClass()
{
    InitializeMuscleName();
    InitializeBoneName();
    InitializeMonoIndicies();

    Assert(m_MuscleName->size() == MuscleCount);
    Assert(m_BoneName->size() == HumanBoneCount);

    Assert(m_MonoBoneName->size() == HumanBoneCount);
}

void HumanTrait::CleanupClass()
{
    delete m_MuscleName;
    m_MuscleName = NULL;
    delete m_BoneName;
    m_BoneName = NULL;

    delete m_BoneIndexFromMono;
    m_BoneIndexFromMono = NULL;
    delete m_BoneIndexToMono;
    m_BoneIndexToMono = NULL;
    delete m_MonoBoneName;
    m_MonoBoneName = NULL;
}

core::string HumanTrait::GetFingerMuscleName(int index, bool left)
{
    core::string fingerName = left ? "Left " : "Right ";
    if (0 <= index && index < mecanim::hand::s_DoFCount)
    {
        int fingerIndex = index / mecanim::hand::kLastFingerDoF;
        int dofIndex = index % mecanim::hand::kLastFingerDoF;

        fingerName += mecanim::hand::FingerName(fingerIndex);
        fingerName += " ";
        fingerName += mecanim::hand::FingerDoFName(dofIndex);
    }
    return fingerName;
}

core::string HumanTrait::GetFingerName(int index, bool left)
{
    core::string fingerName = left ? "Left " : "Right ";
    if (0 <= index && index < mecanim::hand::s_BoneCount)
    {
        int fingerIndex = index /  mecanim::hand::kLastPhalange;
        int phalangesIndex = index %  mecanim::hand::kLastPhalange;

        fingerName += mecanim::hand::FingerName(fingerIndex);
        fingerName += " ";
        fingerName += mecanim::hand::PhalangeName(phalangesIndex);
    }
    return fingerName;
}

int HumanTrait::Body::GetBoneCount()
{
    return mecanim::human::kLastBone;
}

core::string HumanTrait::Body::GetBoneName(int index)
{
    return core::string(mecanim::human::BoneName(index));
}

int HumanTrait::Body::GetMuscleCount()
{
    return mecanim::human::kLastDoF;
}

core::string HumanTrait::Body::GetMuscleName(int index)
{
    return core::string(mecanim::human::MuscleName(index));
}

int HumanTrait::LeftFinger::GetBoneCount()
{
    return mecanim::hand::s_BoneCount;
}

core::string HumanTrait::LeftFinger::GetBoneName(int index)
{
    return HumanTrait::GetFingerName(index, IsLeftHand());
}

int HumanTrait::LeftFinger::GetMuscleCount()
{
    return mecanim::hand::s_DoFCount;
}

core::string HumanTrait::LeftFinger::GetMuscleName(int index)
{
    return HumanTrait::GetFingerMuscleName(index, IsLeftHand());
}

bool HumanTrait::LeftFinger::IsLeftHand()
{
    return true;
}

int HumanTrait::RightFinger::GetBoneCount()
{
    return mecanim::hand::s_BoneCount;
}

core::string HumanTrait::RightFinger::GetBoneName(int index)
{
    return HumanTrait::GetFingerName(index, IsLeftHand());
}

int HumanTrait::RightFinger::GetMuscleCount()
{
    return mecanim::hand::s_DoFCount;
}

core::string HumanTrait::RightFinger::GetMuscleName(int index)
{
    return HumanTrait::GetFingerMuscleName(index, IsLeftHand());
}

bool HumanTrait::RightFinger::IsLeftHand()
{
    return false;
}

std::vector<core::string> HumanTrait::GetMuscleName()
{
    return *m_MuscleName;
}

std::vector<core::string> HumanTrait::GetBoneName()
{
    return *m_BoneName;
}

int HumanTrait::MuscleFromBone(int i, int dofIndex)
{
    if (i < 0)
        return -1;

    if (i < LastBodyBone)
        return mecanim::human::MuscleFromBone(i, dofIndex);
    else if (i < LastLeftFingerBone)
    {
        int muscle = mecanim::hand::MuscleFromBone(i - LastBodyBone, dofIndex);
        return muscle != -1 ? LastDoF + muscle : -1;
    }
    else if (i < LastRightFingerBone)
    {
        int muscle = mecanim::hand::MuscleFromBone(i - LastLeftFingerBone, dofIndex);
        return muscle != -1 ? LastLeftFingerDoF + muscle : -1;
    }
    return -1;
}

int HumanTrait::BoneFromMuscle(int i)
{
    if (i < 0)
        return -1;

    if (i < LastDoF)
        return mecanim::human::BoneFromMuscle(i);
    else if (i < LastLeftFingerDoF)
    {
        int bone = mecanim::hand::BoneFromMuscle(i - LastDoF);
        return bone != -1 ? LastBodyBone + bone : -1;
    }
    else if (i < LastRightFingerDoF)
    {
        int bone = mecanim::hand::BoneFromMuscle(i - LastLeftFingerDoF);
        return bone != -1 ? LastLeftFingerBone + bone : -1;
    }
    return -1;
}

int HumanTrait::GetBoneId(Avatar const& avatar, int humanId)
{
    mecanim::animation::AvatarConstant const* cst = avatar.GetAsset();

    int index = -1;

    if (humanId < 0)
        return index;

    if (humanId < LastBodyBone && cst->isHuman())
        index = cst->m_Human->m_HumanBoneIndex[humanId];
    else if (humanId < LastLeftFingerBone && cst->isHuman() && !cst->m_Human->m_LeftHand.IsNull())
        index = cst->m_Human->m_LeftHand->m_HandBoneIndex[humanId - LastBodyBone];
    else if (humanId < LastRightFingerBone && cst->isHuman() && !cst->m_Human->m_RightHand.IsNull())
        index = cst->m_Human->m_RightHand->m_HandBoneIndex[humanId - LastLeftFingerBone];

    return index;
}

bool HumanTrait::RequiredBone(int humanId)
{
    if (humanId < 0)
        return false;
    else if (humanId < LastBodyBone)
        return mecanim::human::RequiredBone(humanId);

    return false;
}

int HumanTrait::RequiredBoneCount()
{
    int count = 0;
    for (int i = 0; i < LastBodyBone; i++)
    {
        count = RequiredBone(i) ? count + 1 : count;
    }
    return count;
}

bool HumanTrait::HasCollider(Avatar& avatar, int humanId)
{
    mecanim::animation::AvatarConstant* cst = avatar.GetAsset();

    bool ret = false;
    if (humanId >= 0 && humanId < LastBodyBone && cst->isHuman())
        ret = cst->m_Human->m_ColliderIndex[humanId] != -1;
    return ret;
}

int HumanTrait::GetColliderId(Avatar& avatar, int humanId)
{
    mecanim::animation::AvatarConstant* cst = avatar.GetAsset();

    int ret = -1;
    if (humanId >= 0 && humanId < LastBodyBone && cst->isHuman())
        ret = cst->m_Human->m_ColliderIndex[humanId];
    return ret;
}

int HumanTrait::GetParent(int humanId)
{
    if (humanId >= 0 && humanId < HumanBoneCount)
    {
        return mecanim::human::BoneParentIndex(humanId);
    }

    return -1;
}

float HumanTrait::GetMuscleDefaultMin(int i)
{
    int bone = HumanTrait::BoneFromMuscle(i);
    int dx = HumanTrait::MuscleFromBone(bone, 0);
    int dy = HumanTrait::MuscleFromBone(bone, 1);
    int dz = HumanTrait::MuscleFromBone(bone, 2);

    if (i < LastDoF)
    {
        math::SetupAxesInfo const& axeInfo = mecanim::human::GetAxeInfo(bone);
        if (i == dx)
            return axeInfo.m_Min[0];
        else if (i == dy)
            return axeInfo.m_Min[1];
        else if (i == dz)
            return axeInfo.m_Min[2];
    }
    else if (i < LastLeftFingerDoF)
    {
        math::SetupAxesInfo const& axeInfo = mecanim::hand::GetAxeInfo(bone - LastBodyBone);
        if (i == dx)
            return axeInfo.m_Min[0];
        else if (i == dy)
            return axeInfo.m_Min[1];
        else if (i == dz)
            return axeInfo.m_Min[2];
    }
    else if (i < LastRightFingerDoF)
    {
        math::SetupAxesInfo const& axeInfo = mecanim::hand::GetAxeInfo(bone - LastLeftFingerBone);
        if (i == dx)
            return axeInfo.m_Min[0];
        else if (i == dy)
            return axeInfo.m_Min[1];
        else if (i == dz)
            return axeInfo.m_Min[2];
    }
    return 0.f;
}

float HumanTrait::GetMuscleDefaultMax(int i)
{
    int bone = HumanTrait::BoneFromMuscle(i);
    int dx = HumanTrait::MuscleFromBone(bone, 0);
    int dy = HumanTrait::MuscleFromBone(bone, 1);
    int dz = HumanTrait::MuscleFromBone(bone, 2);

    if (i < LastDoF)
    {
        math::SetupAxesInfo const& axeInfo = mecanim::human::GetAxeInfo(bone);
        if (i == dx)
            return axeInfo.m_Max[0];
        else if (i == dy)
            return axeInfo.m_Max[1];
        else if (i == dz)
            return axeInfo.m_Max[2];
    }
    else if (i < LastLeftFingerDoF)
    {
        math::SetupAxesInfo const& axeInfo = mecanim::hand::GetAxeInfo(bone - LastBodyBone);
        if (i == dx)
            return axeInfo.m_Max[0];
        else if (i == dy)
            return axeInfo.m_Max[1];
        else if (i == dz)
            return axeInfo.m_Max[2];
    }
    else if (i < LastRightFingerDoF)
    {
        math::SetupAxesInfo const& axeInfo = mecanim::hand::GetAxeInfo(bone - LastLeftFingerBone);
        if (i == dx)
            return axeInfo.m_Max[0];
        else if (i == dy)
            return axeInfo.m_Max[1];
        else if (i == dz)
            return axeInfo.m_Max[2];
    }
    return 0.f;
}

int HumanTrait::GetBoneIndexFromMono(int monoIndex)
{
    return HumanTrait::m_BoneIndexFromMono[monoIndex];
}

int HumanTrait::GetBoneIndexToMono(int boneIndex)
{
    return HumanTrait::m_BoneIndexToMono[boneIndex];
}

std::vector<core::string> HumanTrait::MonoBoneName()
{
    return *m_MonoBoneName;
}

void HumanTrait::InitializeMuscleName()
{
    m_MuscleName = new std::vector<core::string>();

    m_MuscleName->reserve(MuscleCount);
    for (int i = 0; i < MuscleCount; i++)
    {
        if (i < LastDoF)
            m_MuscleName->push_back(core::string(Body::GetMuscleName(i).c_str()));
        else if (i < LastLeftFingerDoF)
            m_MuscleName->push_back(core::string(LeftFinger::GetMuscleName(i - LastDoF).c_str()));
        else if (i < LastRightFingerDoF)
            m_MuscleName->push_back(core::string(RightFinger::GetMuscleName(i - LastLeftFingerDoF).c_str()));
    }
}

void HumanTrait::InitializeBoneName()
{
    m_BoneName = new std::vector<core::string>();
    m_BoneName->reserve(HumanBoneCount);

    for (int i = 0; i < HumanBoneCount; i++)
    {
        if (i < LastBodyBone)
            m_BoneName->push_back(core::string(Body::GetBoneName(i).c_str()));
        else if (i < LastLeftFingerBone)
            m_BoneName->push_back(core::string(LeftFinger::GetBoneName(i - LastBodyBone).c_str()));
        else if (i < LastRightFingerBone)
            m_BoneName->push_back(core::string(RightFinger::GetBoneName(i - LastLeftFingerBone).c_str()));
    }
}

void HumanTrait::InitializeMonoIndicies()
{
    using namespace mecanim;

    m_BoneIndexFromMono = new int[HumanBoneCount];

    int monoBoneIter = 0;

    m_BoneIndexFromMono[/* Hips */ monoBoneIter++] = human::kBodyBoneStart + human::kHips;
    m_BoneIndexFromMono[/* LeftUpperLeg */ monoBoneIter++] = human::kBodyBoneStart + human::kLeftUpperLeg;
    m_BoneIndexFromMono[/* RightUpperLeg */ monoBoneIter++] = human::kBodyBoneStart + human::kRightUpperLeg;
    m_BoneIndexFromMono[/* LeftLowerLeg */ monoBoneIter++] = human::kBodyBoneStart + human::kLeftLowerLeg;
    m_BoneIndexFromMono[/* RightLowerLeg */ monoBoneIter++] = human::kBodyBoneStart + human::kRightLowerLeg;
    m_BoneIndexFromMono[/* LeftFoot */ monoBoneIter++] = human::kBodyBoneStart + human::kLeftFoot;
    m_BoneIndexFromMono[/* RightFoot */ monoBoneIter++] = human::kBodyBoneStart + human::kRightFoot;
    m_BoneIndexFromMono[/* Spine */ monoBoneIter++] = human::kBodyBoneStart + human::kSpine;
    m_BoneIndexFromMono[/* Chest */ monoBoneIter++] = human::kBodyBoneStart + human::kChest;
    m_BoneIndexFromMono[/* Neck */ monoBoneIter++] = human::kBodyBoneStart + human::kNeck;
    m_BoneIndexFromMono[/* Head */ monoBoneIter++] = human::kBodyBoneStart + human::kHead;
    m_BoneIndexFromMono[/* LeftShoulder */ monoBoneIter++] = human::kBodyBoneStart + human::kLeftShoulder;
    m_BoneIndexFromMono[/* RightShoulder */ monoBoneIter++] = human::kBodyBoneStart + human::kRightShoulder;
    m_BoneIndexFromMono[/* LeftUpperArm */ monoBoneIter++] = human::kBodyBoneStart + human::kLeftUpperArm;
    m_BoneIndexFromMono[/* RightUpperArm */ monoBoneIter++] = human::kBodyBoneStart + human::kRightUpperArm;
    m_BoneIndexFromMono[/* LeftLowerArm */ monoBoneIter++] = human::kBodyBoneStart + human::kLeftLowerArm;
    m_BoneIndexFromMono[/* RightLowerArm */ monoBoneIter++] = human::kBodyBoneStart + human::kRightLowerArm;
    m_BoneIndexFromMono[/* LeftHand */ monoBoneIter++] = human::kBodyBoneStart + human::kLeftHand;
    m_BoneIndexFromMono[/* RightHand */ monoBoneIter++] = human::kBodyBoneStart + human::kRightHand;
    m_BoneIndexFromMono[/* LeftToes */ monoBoneIter++] = human::kBodyBoneStart + human::kLeftToes;
    m_BoneIndexFromMono[/* RightToes */ monoBoneIter++] = human::kBodyBoneStart + human::kRightToes;
    m_BoneIndexFromMono[/* LeftEye */ monoBoneIter++] = human::kBodyBoneStart + human::kLeftEye;
    m_BoneIndexFromMono[/* RightEye */ monoBoneIter++] = human::kBodyBoneStart + human::kRightEye;
    m_BoneIndexFromMono[/* Jaw */ monoBoneIter++] = human::kBodyBoneStart + human::kJaw;
    m_BoneIndexFromMono[/* LeftThumbProximal */ monoBoneIter++] = human::kLeftThumbStart + hand::kProximal;
    m_BoneIndexFromMono[/* LeftThumbIntermediate */ monoBoneIter++] = human::kLeftThumbStart + hand::kIntermediate;
    m_BoneIndexFromMono[/* LeftThumbDistal */ monoBoneIter++] = human::kLeftThumbStart + hand::kDistal;
    m_BoneIndexFromMono[/* LeftIndexProximal */ monoBoneIter++] = human::kLeftIndexStart + hand::kProximal;
    m_BoneIndexFromMono[/* LeftIndexIntermediate */ monoBoneIter++] = human::kLeftIndexStart + hand::kIntermediate;
    m_BoneIndexFromMono[/* LeftIndexDistal */ monoBoneIter++] = human::kLeftIndexStart + hand::kDistal;
    m_BoneIndexFromMono[/* LeftMiddleProximal */ monoBoneIter++] = human::kLeftMiddleStart + hand::kProximal;
    m_BoneIndexFromMono[/* LeftMiddleIntermediate */ monoBoneIter++] = human::kLeftMiddleStart + hand::kIntermediate;
    m_BoneIndexFromMono[/* LeftMiddleDistal */ monoBoneIter++] = human::kLeftMiddleStart + hand::kDistal;
    m_BoneIndexFromMono[/* LeftRingProximal */ monoBoneIter++] =  human::kLeftRingStart + hand::kProximal;
    m_BoneIndexFromMono[/* LeftRingIntermediate */ monoBoneIter++] = human::kLeftRingStart + hand::kIntermediate;
    m_BoneIndexFromMono[/* LeftRingDistal */ monoBoneIter++] = human::kLeftRingStart + hand::kDistal;
    m_BoneIndexFromMono[/* LeftLittleProximal */ monoBoneIter++] =  human::kLeftLittleStart + hand::kProximal;
    m_BoneIndexFromMono[/* LeftLittleIntermediate */ monoBoneIter++] = human::kLeftLittleStart + hand::kIntermediate;
    m_BoneIndexFromMono[/* LeftLittleDistal */ monoBoneIter++] = human::kLeftLittleStart + hand::kDistal;
    m_BoneIndexFromMono[/* RightThumbProximal */ monoBoneIter++] =  human::kRightThumbStart + hand::kProximal;
    m_BoneIndexFromMono[/* RightThumbIntermediate */ monoBoneIter++] = human::kRightThumbStart + hand::kIntermediate;
    m_BoneIndexFromMono[/* RightThumbDistal */ monoBoneIter++] = human::kRightThumbStart + hand::kDistal;
    m_BoneIndexFromMono[/* RightIndexProximal */ monoBoneIter++] = human::kRightIndexStart + hand::kProximal;
    m_BoneIndexFromMono[/* RightIndexIntermediate */ monoBoneIter++] =  human::kRightIndexStart + hand::kIntermediate;
    m_BoneIndexFromMono[/* RightIndexDistal */ monoBoneIter++] =  human::kRightIndexStart + hand::kDistal;
    m_BoneIndexFromMono[/* RightMiddleProximal */ monoBoneIter++] = human::kRightMiddleStart + hand::kProximal;
    m_BoneIndexFromMono[/* RightMiddleIntermediate */ monoBoneIter++] = human::kRightMiddleStart + hand::kIntermediate;
    m_BoneIndexFromMono[/* RightMiddleDistal */ monoBoneIter++] = human::kRightMiddleStart + hand::kDistal;
    m_BoneIndexFromMono[/* RightRingProximal */ monoBoneIter++] =  human::kRightRingStart + hand::kProximal;
    m_BoneIndexFromMono[/* RightRingIntermediate */ monoBoneIter++] = human::kRightRingStart + hand::kIntermediate;
    m_BoneIndexFromMono[/* RightRingDistal */ monoBoneIter++] = human::kRightRingStart + hand::kDistal;
    m_BoneIndexFromMono[/* RightLittleProximal */ monoBoneIter++] =  human::kRightLittleStart + hand::kProximal;
    m_BoneIndexFromMono[/* RightLittleIntermediate */ monoBoneIter++] = human::kRightLittleStart + hand::kIntermediate;
    m_BoneIndexFromMono[/* RightLittleDistal */ monoBoneIter++] = human::kRightLittleStart + hand::kDistal;
    m_BoneIndexFromMono[/* UpperChest */ monoBoneIter++] = human::kUpperChest;
    Assert(monoBoneIter == HumanBoneCount);

    m_BoneIndexToMono = new int[HumanBoneCount];
    m_MonoBoneName = new std::vector<core::string>();
    m_MonoBoneName->reserve(HumanBoneCount);

    for (int monoBoneIter = 0; monoBoneIter < HumanBoneCount; monoBoneIter++)
    {
        m_BoneIndexToMono[m_BoneIndexFromMono[monoBoneIter]] = monoBoneIter;
        m_MonoBoneName->push_back(m_BoneName->at(m_BoneIndexFromMono[monoBoneIter]));
    }
}
