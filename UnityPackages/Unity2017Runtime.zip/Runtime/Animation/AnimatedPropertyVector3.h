#pragma once

#include "Runtime/Director/Core/DirectorTypes.h"
#include "Runtime/Director/Core/Property.h"
#include "Runtime/Animation/AnimationClip.h"

class AnimationClip;
class PropertyComponent;

struct HPlayable;

namespace UnityEngine
{
namespace Animation
{
    struct BoundCurve;
}
}

class AnimatedPropertyVector3 : public NonCopyable
{
    UInt32              m_CurveIndex;
    ScriptingObjectPtr      m_ScriptInstance;

    AnimatedPropertyVector3();

public:

    AnimatedPropertyVector3(UInt32 curveIndex,
        const UnityEngine::Animation::BoundCurve& curveBindingX,
        const UnityEngine::Animation::BoundCurve& curveBindingY,
        const UnityEngine::Animation::BoundCurve& curveBindingZ);
    AnimatedPropertyVector3(UInt32 curveIndex, PPtr<MonoBehaviour> script, PropertyAccessor& accessor);

    ~AnimatedPropertyVector3();

    void Update(const HPlayable& playable, const AnimationClip::Vector3Curves& curves);
    const Vector3f& GetValue() const;

private:

    void    SetValue(const Vector3f& value) {}
};
