#include "UnityPrefix.h"
#include "Configuration/UnityConfigure.h"
#include "AnimationBinder.h"
#include "Runtime/Serialize/TransferUtility.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/Shaders/Material.h"
#include "Runtime/Graphics/Mesh/Mesh.h"
#include "Runtime/Graphics/Mesh/SkinnedMeshRenderer.h"
#include "Runtime/Transform/Transform.h"
#if !ENABLE_DOTNET
#include "Runtime/Mono/MonoBehaviour.h"
#include "Runtime/Mono/MonoScript.h"
#endif
#include "Runtime/Utilities/RuntimeStatic.h"
#include "Runtime/Math/Simd/vec-math.h"
#if ENABLE_DOTNET
#include "PlatformDependent/WinRT/AnimationBinderWinRT.h"
#endif

#include "Runtime/mecanim/generic/crc32.h"
#include "Runtime/Interfaces/IAnimation.h"
#include "Runtime/Animation/EditorCurveBinding.h"
#include "Runtime/Animation/GenericAnimationBindingCache.h"
#include "Runtime/Interfaces/IAnimationBinding.h"
#include "Runtime/Camera/Light.h"
#include "Runtime/Utilities/HashStringFunctions.h"


using namespace ShaderLab;

bool BindGenericFloatCurve(const CurveID &curveID, Object* &targetObject, GameObject* go, Transform* actualTransform, void* &targetPtr, int &type, UnityEngine::Animation::BoundCurve& boundCurve);
void AnimationBinder::InitCurveIDLookup(AnimationBinder::CurveIDLookup& curveIDLookup)
{
    curveIDLookup.reserve(1024);
}

static inline bool IsAnimatableProperty(const TypeTreeIterator& variable)
{
    return !variable.IsNull() && variable.ByteOffset() != TypeTree::kByteOffsetUnset;
}

static inline void* GetPropertyPointer(const TypeTreeIterator& variable, Object* object)
{
    Assert(IsAnimatableProperty(variable) && object != NULL);
    UInt32 byteOffset = variable.ByteOffset();
    UInt32 offset = byteOffset & TypeTree::kByteOffsetMask;
#if !ENABLE_DOTNET
    if ((byteOffset & TypeTree::kScriptingInstanceOffset) != 0)
    {
        AssertMsg(object->GetType() == TypeOf<MonoBehaviour>(), "Type must be MonoBehavior if ScriptingInstanceOffset is set");
        return reinterpret_cast<char*>(UnsafeExtractPointerFromScriptingObjectPtr(static_cast<MonoBehaviour*>(object)->GetInstance())) + offset;
    }
    else
#else
    Assert((byteOffset & TypeTree::kScriptingInstanceOffset) == 0);
#endif
    {
        return reinterpret_cast<char*>(object) + offset;
    }
}

AnimationBinder::~AnimationBinder()
{
    for (TypeTreeCache::iterator i = m_TypeTreeCache.begin(); i != m_TypeTreeCache.end(); ++i)
        UNITY_DELETE(i->second, kMemTypeTree);
}

inline int GetAnimatableBindType(const TypeTreeIterator& variable)
{
    int boundType = UnityEngine::Animation::GetTypeTreeBindType(variable);
    if (boundType == kUnbound)
    {
        if (variable.Type() == CommonString(PPtr_Material))
        {
            boundType = kBindMaterialPPtrToRenderer;
        }
        else if (variable.Type() == CommonString(PPtr_Sprite))
        {
            boundType = kBindSpritePPtrToSpriteRenderer;
        }
    }

    return boundType;
}

inline static void BindAnimatableProperty(const TypeTree* typeTree, const char* attribute, bool isScript, Object* targetObject, void** targetPtr, int* type)
{
    // Find attribute
    // * Check if we support binding that value
    // * scripts use direct ptrs but it only works reliable at the root level, because other variables may be moved/deleted arbitrarily

    TypeTreeIterator variable = FindAttributeInTypeTreeNoArrays(typeTree->Root(), attribute);

    if (IsAnimatableProperty(variable))
    {
        *type = GetAnimatableBindType(variable);

        if (*type != kUnbound)
            *targetPtr = GetPropertyPointer(variable, targetObject);
    }

    if (isScript)
        UNITY_DELETE(typeTree, kMemTypeTree);
}

#if UNITY_EDITOR
bool AnimationBinder::IsAnimatablePropertyOrHasAnimatableChild(const TypeTreeIterator& variable)
{
    if (variable.Children().IsNull())
    {
        if (IsAnimatableProperty(variable))
        {
            return GetAnimatableBindType(variable) != kUnbound;
        }
    }

    for (TypeTreeIterator i = variable.Children(); !i.IsNull(); i = i.Next())
    {
        if (IsAnimatablePropertyOrHasAnimatableChild(i))
            return true;
    }

    return false;
}

#endif


bool AnimationBinder::CalculateTargetPtr(const Unity::Type* objectType, Object* targetObject, const char* attribute, void** targetPtr, int* type)
{
    Assert(kBindTypeCount <= (1 << BoundCurveDeprecated::kBindTypeBitCount));
    Assert(targetObject != NULL);

    if (objectType == TypeOf<Transform>())
    {
        Transform* transformTarget = static_cast<Transform*>(targetObject);

        if (strcmp(attribute, "m_LocalPosition") == 0)
        {
            *type = kBindTransformPosition;
            *targetPtr = &transformTarget->m_LocalPosition;
            return true;
        }
        else if (strcmp(attribute, "m_LocalScale") == 0)
        {
            *type = kBindTransformScale;
            *targetPtr = &transformTarget->m_LocalScale;
            return true;
        }
        else if (strcmp(attribute, "m_LocalRotation") == 0)
        {
            *type = kBindTransformRotation;
            *targetPtr = &transformTarget->m_LocalRotation;
            return true;
        }
        else if (strcmp(attribute, "m_LocalEuler") == 0)
        {
            *type = kBindTransformEuler;
            *targetPtr = &transformTarget->m_LocalRotation;
            return true;
        }
    }
    else if (objectType == TypeOf<Material>())
    {
        //      Renderer* renderer = static_cast<Transform*> (targetObject);

        // [0].mainTex.offset.x
        // [0].mainTex.offset.y
        // [0].mainTex.scale.y
        // [0].mainTex.rotation
        // [0].mainColor.r
        // [0].mainColor.x
        // [0].floatPropertyName

        int materialIndex = 0;
        int shaderPropertyIndex = 0;
        int newTargetType = kUnbound;
        int targetIndex = 0;

        // Grab material index "[3]."
        const char* a = attribute;
        if (*a == '[')
        {
            while (*a != 0 && *a != '.')
                a++;

            if (*a == '.')
                materialIndex = StringToInt(attribute + 1);
            else
                return false;
            attribute = a + 1;
        }


        // Find shader propertyname
        int dotIndex = -1;
        const char* lastCharacter;
        while (*a != 0)
        {
            if (*a == '.' && dotIndex == -1)
                dotIndex = a - attribute;
            a++;
        }
        lastCharacter = a - 1;

        // No . must be float property
        if (dotIndex == -1)
        {
            newTargetType = kBindFloatToMaterial;
            shaderPropertyIndex = ShaderLab::GetFastPropertyIndexByName(attribute);
        }
        // Calculate different property types
        else
        {
            shaderPropertyIndex = ShaderLab::GetFastPropertyIndexByName(core::string(attribute, attribute + dotIndex).c_str());
            attribute += dotIndex + 1;

            switch (*attribute)
            {
                // g color or y vector
                case 'g':
                case 'y':
                    newTargetType = kBindFloatToColorMaterial;
                    targetIndex = 1;
                    break;

                // b or z vector
                case 'b':
                case 'z':
                    newTargetType = kBindFloatToColorMaterial;
                    targetIndex = 2;
                    break;

                // alpha or w vector
                case 'a':
                case 'w':
                    newTargetType = kBindFloatToColorMaterial;
                    targetIndex = 3;
                    break;

                // uv scale
                case 's':
                    newTargetType = kBindFloatToMaterialScaleAndOffset;
                    targetIndex = *lastCharacter == 'x' ? 0 : 1;
                    break;
                // uv offset
                case 'o':
                    newTargetType = kBindFloatToMaterialScaleAndOffset;
                    targetIndex = *lastCharacter == 'x' ? 2 : 3;
                    break;

                // r color
                case 'r':
                    if (lastCharacter == attribute)
                    {
                        newTargetType = kBindFloatToColorMaterial;
                        targetIndex = 0;
                    }
                    break;
                // x vector
                case 'x':
                    newTargetType = kBindFloatToColorMaterial;
                    targetIndex = 0;
                    break;
            }
        }

        if (newTargetType != kUnbound)
        {
            Assert(BoundCurveDeprecated::kBindTypeBitCount + BoundCurveDeprecated::kBindMaterialShaderPropertyNameBitCount < 32);
            Assert(newTargetType < (1 << BoundCurveDeprecated::kBindTypeBitCount));
            Assert(shaderPropertyIndex < (1 << BoundCurveDeprecated::kBindMaterialShaderPropertyNameBitCount));
            Assert(targetIndex < (1 << (32 - BoundCurveDeprecated::kBindTypeBitCount - BoundCurveDeprecated::kBindMaterialShaderPropertyNameBitCount)));

            // Encode targetType
            newTargetType |= targetIndex << (BoundCurveDeprecated::kBindMaterialShaderPropertyNameBitCount + BoundCurveDeprecated::kBindTypeBitCount);
            newTargetType |= shaderPropertyIndex << BoundCurveDeprecated::kBindTypeBitCount;
            *targetPtr = reinterpret_cast<void*>(static_cast<intptr_t>(materialIndex));
            *type = newTargetType;
            return true;
        }
        else
        {
            *targetPtr = NULL;
            *type = kUnbound;
            return false;
        }
    }
    else if (objectType == TypeOf<GameObject>())
    {
        if (strcmp(attribute, "m_IsActive") == 0)
        {
            *type = kBindFloatToGameObjectActivate;
            *targetPtr = targetObject;
            return true;
        }
    }

    bool isScript = objectType == TypeOf<MonoBehaviour>();

    const TypeTree* typeTree = NULL;
    if (m_TypeTreeCache.count(objectType))
        typeTree = m_TypeTreeCache.find(objectType)->second;
    else
    {
        // Build proxy
        TypeTree* newTypeTree = UNITY_NEW(TypeTree, kMemTypeTree);
        GenerateTypeTree(*targetObject, *newTypeTree);
        if (!isScript)
            m_TypeTreeCache[objectType] = newTypeTree;
        typeTree = newTypeTree;
    }

    *type = kUnbound;
    *targetPtr = NULL;

#if ENABLE_DOTNET
    bool winrtBinding = false;
    if (isScript)
    {
        MonoBehaviour* beh = (MonoBehaviour*)targetObject;
        if (beh != NULL)
        {
            winrtBinding = WinRT::AnimationBindField(beh->GetInstance(), attribute, targetPtr, type);
        }
    }

    if (!winrtBinding)
    {
        BindAnimatableProperty(typeTree, attribute, isScript, targetObject, targetPtr, type);
        // we use special objects for MonoBehaviour attributes, so we need to wrap direct ptrs too
        if (isScript)
            WinRT::AnimationWrapPtrBinding(targetPtr, *type);
    }
#else
    BindAnimatableProperty(typeTree, attribute, isScript, targetObject, targetPtr, type);
#endif

    return *type != kUnbound;
}

//@TODO: Stop supporting this. Only support batched BindCurve
bool AnimationBinder::BindCurve(const CurveID& curveID, BoundCurveDeprecated& bound, Transform& transform)
{
    // Lookup without path
    Object* targetObject = NULL;
    Transform* child = &transform;
    void* targetPtr = NULL;
    int type = 0;

    bool calculateTargetPtr = true;
    if (curveID.path[0] != '\0')
    {
        child = FindRelativeTransformWithPath(*child, curveID.path);
        if (child == NULL)
            return false;
    }

    // Lookup gameobject
    if (curveID.type == TypeOf<GameObject>())
    {
        targetObject = &child->GetGameObject();
    }
    else if (curveID.type == TypeOf<Transform>())
    {
        targetObject = child;
        if (targetObject == NULL)
            return false;
    }
    // Lookup material
    else if (curveID.type == TypeOf<Material>())
    {
        targetObject = GetComponentWithScript(child->GetGameObject(), TypeOf<Renderer>(), curveID.script);
        if (targetObject == NULL)
            return false;
    }
    else
    {
        if (!BindGenericFloatCurve(curveID, targetObject, &child->GetGameObject(), child, targetPtr, type, bound))
            return false;
        calculateTargetPtr = false;
    }


    //Skip CalculateTargetPtr if the targetPtr has already been set.
    if (calculateTargetPtr && !CalculateTargetPtr(curveID.type, targetObject, curveID.attribute, &targetPtr, &type))
        return false;

    bound.targetPtr = reinterpret_cast<UInt8*>(targetPtr);
    bound.targetType = type;
    bound.targetObject = targetObject;
    bound.targetInstanceID = targetObject->GetInstanceID();

    return true;
}

static void ClearTransformTemporaryFlag(Transform& transform)
{
    transform.SetTemporaryFlags(0);
    Transform::iterator end = transform.end();
    for (Transform::iterator i = transform.begin(); i != end; i++)
        ClearTransformTemporaryFlag(**i);
}

static void CalculateTransformRoots(Transform& transform, AnimationBinder::AffectedRootTransforms& affectedRootTransforms)
{
    if (transform.GetTemporaryFlags())
    {
        affectedRootTransforms.push_back(&transform);
    }
    else
    {
        Transform::iterator end = transform.end();
        for (Transform::iterator i = transform.begin(); i != end; i++)
            CalculateTransformRoots(**i, affectedRootTransforms);
    }
}

void AnimationBinder::RemoveUnboundCurves(CurveIDLookup& lookup, BoundCurves& outBoundCurves)
{
    // Some curves couldn't be bound. We want to avoid the runtime check so we remove from the lookup and boundcurves array completely.
    // - we already removed them from the lookup table
    // - Now we need to remap the bound curves and
    if (lookup.size() != outBoundCurves.size())
    {
        if (lookup.empty())
        {
            outBoundCurves.clear();
            return;
        }

        BoundCurves tempBoundCurves;
        tempBoundCurves.resize_uninitialized(lookup.size());

        // Build a remap table that will compact the array - erasing the curves that are undefined
        std::vector<int> remap;
        remap.resize(outBoundCurves.size());
        int validCount = 0;
        for (size_t j = 0; j < outBoundCurves.size(); j++)
        {
            remap[j] = validCount;
            if (outBoundCurves[j].targetType != kUnbound)
            {
                tempBoundCurves[validCount] = outBoundCurves[j];
                validCount++;
            }
        }

        for (CurveIDLookup::iterator i = lookup.begin(); i != lookup.end(); i++)
            i->second = remap[i->second];

        tempBoundCurves.swap(outBoundCurves);
        outBoundCurves.resize_uninitialized(validCount);
    }
}

void AnimationBinder::BindCurves(const CurveIDLookup& lookup, GameObject& rootGameObject, BoundCurves& outBoundCurves)
{
    AffectedRootTransforms affectedRoot;
    BindCurves(lookup, rootGameObject.GetComponent<Transform>(), outBoundCurves, affectedRoot);
}

void AnimationBinder::BindCurves(const CurveIDLookup& lookup, Transform& transform, BoundCurves& outBoundCurves, AffectedRootTransforms& affectedRootTransforms)
{
    outBoundCurves.resize_initialized(lookup.size());
    affectedRootTransforms.clear();
    bool willTransformChange = false;
    ClearTransformTemporaryFlag(transform);

    // Go through all lookups. Find their binder and assign it.
    for (CurveIDLookup::const_iterator i = lookup.begin(), next = lookup.begin(); i != lookup.end(); i = next)
    {
        next = i;
        next++;

        const CurveID& curveID = i->first;
        int bindIndex = i->second;

        // Lookup without path
        Object* targetObject = NULL;
        GameObject* go = NULL;
        void* targetPtr = NULL;
        int type = 0;
        UnityEngine::Animation::BoundCurve genericBoundCurve;
        bool calculateTargetPtr = true;

        Transform* actualTransform = &transform;
        if (curveID.path[0] != '\0')
        {
            // Lookup child
            Transform* child = FindRelativeTransformWithPath(transform, curveID.path);
            if (child == NULL)
            {
                #if DEBUG_ANIMATIONS
                LogString(Format("Animation bind couldn't find transform child %s", curveID.path));
                #endif
                #if COMPACT_UNBOUND_CURVES
                lookup.erase(i);
                #endif
                outBoundCurves[bindIndex].targetType = kUnbound;
                continue;
            }
            actualTransform = child;
            go = &child->GetGameObject();
        }
        else
        {
            go = &transform.GetGameObject();
        }

        // Lookup component

        if (curveID.type == TypeOf<GameObject>())
        {
            targetObject = go;
        }
        else if (curveID.type == TypeOf<Transform>())
        {
            targetObject = actualTransform;
            if (targetObject == NULL)
            {
#if DEBUG_ANIMATIONS
                LogString(Format("Animation couldn't find %s", curveID.type->className));
#endif
#if COMPACT_UNBOUND_CURVES
                lookup.erase(i);
#endif
                outBoundCurves[bindIndex].targetType = kUnbound;
                continue;
            }
        }
        else if (curveID.type == TypeOf<Material>())
        {
            targetObject = GetComponentWithScript(*go, TypeOf<Renderer>(), curveID.script);
            if (targetObject == NULL)
            {
#if DEBUG_ANIMATIONS
                LogString(Format("Animation couldn't find %s", curveID.type->className));
#endif
#if COMPACT_UNBOUND_CURVES
                lookup.erase(i);
#endif
                outBoundCurves[bindIndex].targetType = kUnbound;
                continue;
            }
        }
        else
        {
            if (!BindGenericFloatCurve(curveID, targetObject, go, actualTransform, targetPtr, type, outBoundCurves[bindIndex]))
            {
#if DEBUG_ANIMATIONS
                LogString(Format("Animation couldn't find %s", (curveID.type == NULL) ? "NULL" : curveID.type->className));
#endif
#if COMPACT_UNBOUND_CURVES
                lookup.erase(i);
#endif
                outBoundCurves[bindIndex].targetType = kUnbound;
                continue;
            }
            calculateTargetPtr = false;
        }


        //Skip CalculateTargetPtr if the targetPtr has already been set
        if (calculateTargetPtr && !CalculateTargetPtr(curveID.type, targetObject, curveID.attribute, &targetPtr, &type))
        {
            #if DEBUG_ANIMATIONS
            LogString(Format("Couldn't bind animation attribute %s.%s", curveID.type->className, curveID.attribute));
            #endif
            #if COMPACT_UNBOUND_CURVES
            lookup.erase(i);
            #endif
            outBoundCurves[bindIndex].targetType = kUnbound;
            continue;
        }

        // - Precalculate affected root transform (Where do we send the transform changed message to)
        // - Precalculated transform changed mask (What part of the transform has changed)
        if (curveID.type->IsDerivedFrom<Transform>())
        {
            willTransformChange = willTransformChange || BeginsWith(curveID.attribute, "m_LocalRotation") || BeginsWith(curveID.attribute, "m_LocalEuler");
            willTransformChange = willTransformChange || BeginsWith(curveID.attribute, "m_LocalPosition");
            willTransformChange = willTransformChange || BeginsWith(curveID.attribute, "m_LocalScale");

            if (willTransformChange)
                targetObject->SetTemporaryFlags(1);
        }

        outBoundCurves[bindIndex].targetPtr = targetPtr;
        outBoundCurves[bindIndex].targetType = type;
        outBoundCurves[bindIndex].targetObject = targetObject;

        // added so that Animation::ValidateBoundCurves() does not always think that target has changed. Mirrors code in BindCurve()
        outBoundCurves[bindIndex].targetInstanceID = targetObject->GetInstanceID();

        #if DEBUG_ANIMATIONS
        outBoundCurves[bindIndex].attribute = curveID.attribute;
        outBoundCurves[bindIndex].path = curveID.path;
        outBoundCurves[bindIndex].klass = curveID.type->className;
        #endif
    }

    CalculateTransformRoots(transform, affectedRootTransforms);
}

RuntimeStatic<AnimationBinder> s_AnimationBinderInstance(kMemAnimation);

AnimationBinder& GetAnimationBinder()
{
    return *s_AnimationBinderInstance;
}

inline Material* GetInstantiatedMaterial(const BoundCurveDeprecated& bind)
{
    unsigned int materialIndex = reinterpret_cast<intptr_t>(bind.targetPtr);
    Renderer* renderer = static_cast<Renderer*>(bind.targetObject);

    if ((int)materialIndex < renderer->GetMaterialCount())
        return renderer->GetAndAssignInstantiatedMaterial(materialIndex, true);
    else
        return NULL;
}

bool AnimationBinder::SetFloatValue(const BoundCurveDeprecated& bind, float value)
{
    UInt32 targetType = bind.targetType;
    Assert(bind.targetType != kUnbound && bind.targetType != kBindTransformRotation && bind.targetType != kBindTransformPosition && bind.targetType != kBindTransformScale && bind.targetType != kBindTransformEuler);

    if (targetType < kBindFloatToMaterial || bind.customBinding != NULL)
    {
        UnityEngine::Animation::SetBoundCurveFloatValue(bind, value);
        return true;
    }
    else
    {
        Material* material = GetInstantiatedMaterial(bind);
        if (material != NULL)
        {
            targetType = bind.targetType;

            // Extract value index, shader property name and real targetType
            int valueIndex = (targetType >> (BoundCurveDeprecated::kBindMaterialShaderPropertyNameBitCount + BoundCurveDeprecated::kBindTypeBitCount)) & BoundCurveDeprecated::kBindTypeMask;
            int propertyName = (targetType & BoundCurveDeprecated::kBindMaterialShaderPropertyNameMask) >> BoundCurveDeprecated::kBindTypeBitCount;
            targetType = targetType & BoundCurveDeprecated::kBindTypeMask;

            ShaderLab::FastPropertyName name;
            name.index = propertyName;
            if (targetType == kBindFloatToMaterial)
                material->SetFloat(name, value);
            else if (targetType == kBindFloatToMaterialScaleAndOffset)
                material->SetTextureScaleAndOffsetIndexed(name, valueIndex, value);
            else if (targetType == kBindFloatToColorMaterial)
                material->SetColorIndexed(name, valueIndex, value);
            else
            {
                AssertString("Unsupported bind mode!");
                return false;
            }

            return true;
        }
    }

    return false;
}

void AnimationBinder::SetValueAwakeGeneric(const BoundCurveDeprecated& bind)
{
    if (ShouldAwakeGeneric(bind))
    {
        UnityEngine::Animation::BoundCurveValueAwakeGeneric(*bind.targetObject);
    }
}

int AnimationBinder::InsertCurveIDIntoLookup(CurveIDLookup& curveIDLookup, const CurveID& curveID)
{
    return curveIDLookup.insert(std::make_pair(curveID, curveIDLookup.size())).first->second;
}

bool BindGenericFloatCurve(const CurveID &curveID, Object* &targetObject, GameObject* go, Transform* actualTransform, void* &targetPtr, int &type, UnityEngine::Animation::BoundCurve& boundCurve)
{
    UnityEngine::Animation::GenericBinding genericBinding;
    UnityEngine::Animation::GetGenericAnimationBindingCache().CreateGenericBinding(curveID.path, curveID.type, curveID.script, curveID.attribute, false, genericBinding);

    if (UnityEngine::Animation::GetGenericAnimationBindingCache().BindGeneric(genericBinding, *actualTransform, boundCurve) == NULL)
        return false;
    targetObject = boundCurve.targetObject;
    targetPtr = boundCurve.targetPtr;
    type = boundCurve.targetType;
    return true;
}

void CurveID::CalculateHash()
{
    hash = std::max<unsigned>(ComputeStringHash32(path) ^ TypeOf<Transform>()->GetPersistentTypeID() ^ ComputeStringHash32(attribute), (unsigned)2);
}
