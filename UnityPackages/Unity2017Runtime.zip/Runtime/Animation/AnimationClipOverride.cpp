#include "UnityPrefix.h"

#include "AnimationClipOverride.h"


PPtr<AnimationClip> return_original(AnimationClipOverride const& overrideClip) { return overrideClip.m_OriginalClip; }
PPtr<AnimationClip> return_override(AnimationClipOverride const& overrideClip) { return overrideClip.m_OverrideClip; }
PPtr<AnimationClip> return_effective(AnimationClipOverride const& overrideClip) { return overrideClip.GetEffectiveClip(); }
