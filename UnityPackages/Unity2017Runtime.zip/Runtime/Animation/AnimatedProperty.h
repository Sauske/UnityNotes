#pragma once

#include "Runtime/Director/Core/DirectorTypes.h"
#include "Runtime/Director/Core/Property.h"
#include "Runtime/Animation/AnimationClip.h"
#include "Runtime/Mono/MonoBehaviour.h"


class AnimationClip;
class PropertyScript;
class PropertyComponent;

namespace UnityEngine
{
namespace Animation
{
    struct BoundCurve;
}
}

class AnimatedProperty : public NonCopyable
{
    PropertyScript     m_PropertyScript;
    AnimationCurve      m_Curve;

    AnimatedProperty();

public:
    AnimatedProperty(const PropertyAccessor& accessor, const AnimationCurve& curve);
    ~AnimatedProperty();

    void Update(float time, ScriptingObjectPtr object);

private:

    void SetValue(ScriptingObjectPtr object, float value);
};
