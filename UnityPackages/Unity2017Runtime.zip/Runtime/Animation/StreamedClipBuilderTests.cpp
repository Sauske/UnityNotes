#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "Runtime/Testing/Testing.h"
#include "StreamedClipBuilder.h"

typedef AnimationCurve::Keyframe Keyframe;
static float Evaluate0(const mecanim::animation::StreamedClip& clip, mecanim::animation::StreamedClipMemory& memory, float time)
{
    float output;
    SampleClip(clip, memory, time, &output);

    return output;
}

typedef AnimationCurveVec3::Keyframe KeyframeVec3;
static Vector3f Evaluate3(const mecanim::animation::StreamedClip& clip, mecanim::animation::StreamedClipMemory& memory, float time)
{
    Vector3f output;
    SampleClip(clip, memory, time, reinterpret_cast<float*>(&output));

    return output;
}

UNIT_TEST_SUITE(StreamedClipBuilderTests)
{
    TEST(StreamedClipBuilder_StreamedClipEvaluation)
    {
        mecanim::memory::MecanimAllocator alloc(kMemTempAlloc);

        AnimationCurve curve(kMemTempAlloc);
        curve.AddKeyBackFast(Keyframe(0.5F, 0.0F));
        curve.AddKeyBackFast(Keyframe(1.0F, 1.0F));
        curve.AddKeyBackFast(Keyframe(2.0F, -1.0F));

        StreamedClipBuilder* builder = CreateStreamedClipBuilder(1, curve.GetKeyCount());
        AddCurveToStreamedClip(builder, 0, curve);
        mecanim::animation::StreamedClip streamclip;
        CreateStreamClipConstant(builder, streamclip, alloc);

        mecanim::animation::StreamedClipMemory memory;
        CreateStreamedClipMemory(streamclip, memory, alloc);

        CHECK_EQUAL(curve.EvaluateClamp(-5.0), Evaluate0(streamclip, memory, -5.0F));
        CHECK_EQUAL(curve.EvaluateClamp(1.0F), Evaluate0(streamclip, memory, 1.0F));
        CHECK_EQUAL(curve.EvaluateClamp(0.0F), Evaluate0(streamclip, memory, 0.0F));
        CHECK_EQUAL(curve.EvaluateClamp(1.5F), Evaluate0(streamclip, memory, 1.5F));
        CHECK_EQUAL(curve.EvaluateClamp(2.0F), Evaluate0(streamclip, memory, 2.0F));
        CHECK_EQUAL(curve.EvaluateClamp(0.1F), Evaluate0(streamclip, memory, 0.1F));
        CHECK_EQUAL(curve.EvaluateClamp(100.0F), Evaluate0(streamclip, memory, 100.0F));
        CHECK_EQUAL(curve.EvaluateClamp(-19), Evaluate0(streamclip, memory, -19.0F));

        DestroyStreamedClipMemory(memory, alloc);
        DestroyStreamedClip(streamclip, alloc);
        DestroyStreamedClipBuilder(builder);
    }

    TEST(StreamedClipEvaluationVector3)
    {
        mecanim::memory::MecanimAllocator alloc(kMemTempAlloc);

        AnimationCurveVec3 curve(kMemTempAlloc);
        curve.AddKeyBackFast(KeyframeVec3(0.5F, Vector3f(0.0, 1.0, 2.0)));
        curve.AddKeyBackFast(KeyframeVec3(1.0F, Vector3f(3.0, 0.0, 4.0)));
        curve.AddKeyBackFast(KeyframeVec3(2.0F, Vector3f(0.0, -1.0, -2.0)));

        StreamedClipBuilder* builder = CreateStreamedClipBuilder(3, curve.GetKeyCount() * 3);
        AddCurveToStreamedClip(builder, 0, curve);
        mecanim::animation::StreamedClip streamclip;
        CreateStreamClipConstant(builder, streamclip, alloc);

        mecanim::animation::StreamedClipMemory memory;
        CreateStreamedClipMemory(streamclip, memory, alloc);

        CHECK(curve.EvaluateClamp(-5.0) == Evaluate3(streamclip, memory, -5.0F));
        CHECK(curve.EvaluateClamp(1.0F) == Evaluate3(streamclip, memory, 1.0F));
        CHECK(curve.EvaluateClamp(0.0F) == Evaluate3(streamclip, memory, 0.0F));
        CHECK(curve.EvaluateClamp(1.5F) == Evaluate3(streamclip, memory, 1.5F));
        CHECK(curve.EvaluateClamp(2.0F) == Evaluate3(streamclip, memory, 2.0F));
        CHECK(curve.EvaluateClamp(0.1F) == Evaluate3(streamclip, memory, 0.1F));
        CHECK(curve.EvaluateClamp(100.0F) == Evaluate3(streamclip, memory, 100.0F));
        CHECK(curve.EvaluateClamp(-19) == Evaluate3(streamclip, memory, -19.0F));

        DestroyStreamedClipMemory(memory, alloc);
        DestroyStreamedClip(streamclip, alloc);
        DestroyStreamedClipBuilder(builder);
    }
}
#endif
