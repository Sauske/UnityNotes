#include "UnityPrefix.h"
#include "HumanPoseHandler.h"
#include "Runtime/Animation/AnimatorGenericBindings.h"

HumanPoseHandler::HumanPoseHandler(Avatar *avatar, Transform *root) :
    m_Alloc(kMemAnimation),
    m_AvatarConstant(0),
    m_Root(0),
    m_BindingConstant(0),
    m_AvatarSkeletonPose(0),
    m_AvatarSkeletonPoseWs(0),
    m_HumanSkeletonPose(0),
    m_HumanSkeletonPoseWsA(0),
    m_HumanSkeletonPoseWsB(0),
    m_HumanSkeletonPoseWsC(0),
    m_HumanSkeletonPoseWsD(0)
{
    m_AvatarConstant = avatar->GetAsset();
    m_Root = root;

    m_BindingConstant = UnityEngine::Animation::CreateAvatarBindingConstant(*root, m_AvatarConstant, m_Alloc);

    m_AvatarSkeletonPose = mecanim::skeleton::CreateSkeletonPose<math::trsX>(m_AvatarConstant->m_AvatarSkeleton.Get(), m_Alloc);
    m_AvatarSkeletonPoseWs = mecanim::skeleton::CreateSkeletonPose<math::trsX>(m_AvatarConstant->m_AvatarSkeleton.Get(), m_Alloc);

    m_HumanSkeletonPose = mecanim::skeleton::CreateSkeletonPose<math::trsX>(m_AvatarConstant->m_Human->m_Skeleton.Get(), m_Alloc);
    m_HumanSkeletonPoseWsA = mecanim::skeleton::CreateSkeletonPose<math::trsX>(m_AvatarConstant->m_Human->m_Skeleton.Get(), m_Alloc);
    m_HumanSkeletonPoseWsB = mecanim::skeleton::CreateSkeletonPose<math::trsX>(m_AvatarConstant->m_Human->m_Skeleton.Get(), m_Alloc);
    m_HumanSkeletonPoseWsC = mecanim::skeleton::CreateSkeletonPose<math::trsX>(m_AvatarConstant->m_Human->m_Skeleton.Get(), m_Alloc);
    m_HumanSkeletonPoseWsD = mecanim::skeleton::CreateSkeletonPose<math::trsX>(m_AvatarConstant->m_Human->m_Skeleton.Get(), m_Alloc);
}

HumanPoseHandler::~HumanPoseHandler()
{
    UnityEngine::Animation::DestroyAvatarBindingConstant(m_BindingConstant, m_Alloc);
    m_BindingConstant = 0;

    mecanim::skeleton::DestroySkeletonPose(m_AvatarSkeletonPose, m_Alloc);
    m_AvatarSkeletonPose = 0;

    mecanim::skeleton::DestroySkeletonPose(m_AvatarSkeletonPoseWs, m_Alloc);
    m_AvatarSkeletonPoseWs = 0;

    mecanim::skeleton::DestroySkeletonPose(m_HumanSkeletonPose, m_Alloc);
    m_HumanSkeletonPose = 0;

    mecanim::skeleton::DestroySkeletonPose(m_HumanSkeletonPoseWsA, m_Alloc);
    m_HumanSkeletonPoseWsA = 0;

    mecanim::skeleton::DestroySkeletonPose(m_HumanSkeletonPoseWsB, m_Alloc);
    m_HumanSkeletonPoseWsB = 0;

    mecanim::skeleton::DestroySkeletonPose(m_HumanSkeletonPoseWsC, m_Alloc);
    m_HumanSkeletonPoseWsC = 0;

    mecanim::skeleton::DestroySkeletonPose(m_HumanSkeletonPoseWsD, m_Alloc);
    m_HumanSkeletonPoseWsD = 0;
}

void HumanPoseHandler::GetHumanPose(Vector3f &bodyPosition, Quaternionf &bodyRotation, float *muscles)
{
    mecanim::int32_t rootIndex = m_AvatarConstant->m_HumanSkeletonIndexArray[0];

    UnityEngine::Animation::GetHumanTransformPropertyValues(*m_BindingConstant, *m_AvatarSkeletonPose);
    mecanim::skeleton::SkeletonPoseComputeGlobal(m_AvatarConstant->m_AvatarSkeleton.Get(), m_AvatarSkeletonPose, m_AvatarSkeletonPoseWs, rootIndex, 0);
    mecanim::skeleton::SkeletonPoseCopy(m_AvatarConstant->m_AvatarSkeleton.Get(), m_AvatarSkeletonPose, m_AvatarConstant->m_Human->m_Skeleton.Get(), m_HumanSkeletonPose);
    m_HumanSkeletonPose->m_X[0] = m_AvatarSkeletonPoseWs->m_X[rootIndex];

    mecanim::human::HumanPose humanPose;
    mecanim::human::RetargetFrom(m_AvatarConstant->m_Human.Get(), m_HumanSkeletonPose, &humanPose, m_HumanSkeletonPoseWsA, m_HumanSkeletonPoseWsB, m_HumanSkeletonPoseWsC, m_HumanSkeletonPoseWsD, 0);

    bodyPosition = float3ToVector3f(humanPose.m_RootX.t);
    bodyRotation = float4ToQuaternionf(humanPose.m_RootX.q);

    int muscleIter = 0;

    for (; muscleIter < mecanim::human::kLastDoF; muscleIter++)
    {
        muscles[muscleIter] = humanPose.m_DoFArray[muscleIter];
    }

    for (int fingerMuscleIter = 0; fingerMuscleIter < mecanim::hand::s_DoFCount; fingerMuscleIter++, muscleIter++)
    {
        muscles[muscleIter] = humanPose.m_LeftHandPose.m_DoFArray[fingerMuscleIter];
    }

    for (int fingerMuscleIter = 0; fingerMuscleIter < mecanim::hand::s_DoFCount; fingerMuscleIter++, muscleIter++)
    {
        muscles[muscleIter] = humanPose.m_RightHandPose.m_DoFArray[fingerMuscleIter];
    }
}

void HumanPoseHandler::SetHumanPose(Vector3f &bodyPosition, Quaternionf &bodyRotation, float *muscles)
{
    mecanim::int32_t rootIndex = m_AvatarConstant->m_HumanSkeletonIndexArray[0];
    mecanim::skeleton::Skeleton const* avatarSkeleton = m_AvatarConstant->m_AvatarSkeleton.Get();
    mecanim::human::Human const* human = m_AvatarConstant->m_Human.Get();
    mecanim::skeleton::Skeleton const* humanSkeleton = human->m_Skeleton.Get();

    math::trsX avatarX = math::trsIdentity();
    avatarX.t = Vector3fTofloat3(m_Root->GetPosition());
    avatarX.q = QuaternionfTofloat4(m_Root->GetRotation());
    avatarX.s = Vector3fTofloat3(m_Root->GetWorldScaleLossy());

    mecanim::human::HumanPose humanPose;
    mecanim::human::HumanPose humanPoseOut;

    humanPose.m_RootX.t = Vector3fTofloat3(bodyPosition);
    humanPose.m_RootX.q = QuaternionfTofloat4(bodyRotation);

    int muscleIter = 0;

    for (; muscleIter < mecanim::human::kLastDoF; muscleIter++)
    {
        humanPose.m_DoFArray[muscleIter] = muscles[muscleIter];
    }

    for (int fingerMuscleIter = 0; fingerMuscleIter < mecanim::hand::s_DoFCount; fingerMuscleIter++, muscleIter++)
    {
        humanPose.m_LeftHandPose.m_DoFArray[fingerMuscleIter] = muscles[muscleIter];
    }

    for (int fingerMuscleIter = 0; fingerMuscleIter < mecanim::hand::s_DoFCount; fingerMuscleIter++, muscleIter++)
    {
        humanPose.m_RightHandPose.m_DoFArray[fingerMuscleIter] = muscles[muscleIter];
    }

    mecanim::human::RetargetTo(human, &humanPose, 0, avatarX, &humanPoseOut, m_HumanSkeletonPose, m_HumanSkeletonPoseWsA);

    mecanim::skeleton::SkeletonPoseCopy(m_HumanSkeletonPose, m_HumanSkeletonPoseWsA);

    TwistSolve(human, m_HumanSkeletonPoseWsA, m_HumanSkeletonPoseWsB);

    mecanim::skeleton::SkeletonPoseCopy(m_AvatarConstant->m_AvatarSkeletonPose.Get(), m_AvatarSkeletonPose);

    m_AvatarSkeletonPose->m_X[0] = avatarX;
    mecanim::skeleton::SkeletonPoseComputeGlobal(avatarSkeleton, m_AvatarSkeletonPose, m_AvatarSkeletonPose, rootIndex, 0);
    mecanim::skeleton::SkeletonPoseComputeGlobal(humanSkeleton, m_HumanSkeletonPoseWsA, m_HumanSkeletonPoseWsA, 1, 1);

    m_HumanSkeletonPoseWsA->m_X[0] = m_AvatarSkeletonPose->m_X[rootIndex];
    mecanim::skeleton::SkeletonPoseComputeLocal(avatarSkeleton, m_AvatarSkeletonPose, m_AvatarSkeletonPose, rootIndex, 0);
    mecanim::skeleton::SkeletonPoseComputeLocal(humanSkeleton, m_HumanSkeletonPoseWsA, m_HumanSkeletonPoseWsA, 1, 1);
    m_HumanSkeletonPoseWsA->m_X[0] = m_AvatarSkeletonPose->m_X[rootIndex];

    mecanim::skeleton::SkeletonPoseCopy(m_HumanSkeletonPoseWsA,
        m_AvatarSkeletonPose,
        m_AvatarConstant->m_HumanSkeletonIndexCount,
        m_AvatarConstant->m_HumanSkeletonIndexArray.Get());

    UnityEngine::Animation::SetHumanTransformPropertyValues(*m_BindingConstant, *m_AvatarSkeletonPose);

    m_Root->QueueChanges();
}
