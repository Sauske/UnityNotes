#ifndef ANIMATIONEVENT_H
#define ANIMATIONEVENT_H

#include "Runtime/BaseClasses/GameObject.h"
#include "Runtime/Animation/AnimatorInfo.h"

class AnimationState;

struct AnimationEvent
{
    DECLARE_SERIALIZE(AnimationEvent)

    float           time;
    core::string        functionName;
    core::string        stringParameter;
    PPtr<Object>    objectReferenceParameter;
    float           floatParameter;
    int             intParameter;

    int             messageOptions;

    mutable AnimationState* stateSender;

    mutable AnimatorStateInfo* animatorStateInfo;
    mutable AnimatorClipInfo* animatorClipInfo;


    AnimationEvent() : time(0.f), functionName(""), stringParameter(""), floatParameter(0.f), intParameter(0), messageOptions(0), stateSender(NULL), animatorStateInfo(NULL), animatorClipInfo(NULL) {}

    friend bool operator<(const AnimationEvent& lhs, const AnimationEvent& rhs) { return lhs.time < rhs.time; }

    bool operator==(AnimationEvent const& other) const
    {
        return time == other.time &&
            functionName == other.functionName &&
            stringParameter == other.stringParameter &&
            objectReferenceParameter == other.objectReferenceParameter &&
            floatParameter == other.floatParameter &&
            intParameter == other.intParameter;
    }
};


typedef UNITY_VECTOR (kMemAnimation, AnimationEvent) AnimationEvents;

bool FireEvent(AnimationEvent& event, Unity::Component& animation, AnimationState* state, AnimatorStateInfo* animatorStateInfo, AnimatorClipInfo* animatorClipInfo);

enum AnimationEventSource
{
    kNoAnimationEventSource = 0,
    kLegacy = 1,
    kAnimator = 2
};

struct MonoAnimationEvent
{
    float               time;
    ScriptingStringPtr  functionName;
    ScriptingStringPtr  stringParameter;
    ScriptingObjectPtr  objectReferenceParameter;
    float               floatParameter;
    int                 intParameter;

    int                 messageOptions;
    int                 source;
    ScriptingObjectPtr  stateSender;

    AnimatorStateInfo animatorStateInfo;
    MonoAnimatorClipInfo animatorClipInfo;
};

void AnimationEventToMono(const AnimationEvent &src, MonoAnimationEvent &dest);
void AnimationEventFromMono(const MonoAnimationEvent &src, AnimationEvent &dest);

#endif
