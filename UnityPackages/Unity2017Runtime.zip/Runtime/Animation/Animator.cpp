#include "UnityPrefix.h"

#include "Animator.h"

#include "Runtime/Animation/OptimizeTransformHierarchy.h"

#include "Runtime/mecanim/animation/damp.h"
#include "Runtime/mecanim/animation/animationset.h"

#include "Runtime/Serialize/TransferFunctions/TransferNameConversions.h"
#include "Runtime/Input/TimeManager.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/BaseClasses/MessageHandlerRegistration.h"
#include "Runtime/Jobs/Jobs.h"
#include "AnimationClip.h"
#include "AnimationSetBinding.h"
#include "MecanimAnimation.h"
#include "StateMachineBehaviourPlayer.h"

#include "Runtime/Misc/BuildSettings.h"
#include "Runtime/Graphics/Renderer.h"
#include "Runtime/GameCode/RootMotionData.h"
#include "Runtime/BaseClasses/EventIDs.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/GameCode/CloneObject.h"

#include "AnimatorController.h"
#include "Avatar.h"
#include "AnimatorOverrideController.h"
#include "AnimatorConfigure.h"
#include "AnimationScriptingClasses.h"

#include "Runtime/mecanim/animation/avatar.h"
#include "Runtime/mecanim/animation/controller.h"


#include "AnimatorGenericBindings.h"

#include "Runtime/Animation/AnimationClip.h"
#include "Runtime/Animation/AnimationUtility.h"

#include "Runtime/Mono/MonoScriptCache.h"
#include "Runtime/Mono/MonoManager.h"
#include "Runtime/Scripting/Scripting.h"
#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/Scripting/ScriptingManager.h"
#include "Runtime/Utilities/UTF16.h"

#include "Runtime/Director/Core/DirectorManager.h"
#include "Runtime/Director/Core/PlayableGraph.h"
#include "Runtime/Director/Core/Traversers.h"

#include "BoundCurve.h"

#include "Runtime/Animation/Director/AnimationLayerMixerPlayable.h"
#include "Runtime/Animation/Director/AnimationMixerPlayable.h"
#include "Runtime/Animation/Director/AnimationClipPlayable.h"
#include "Runtime/Animation/Director/AnimatorControllerPlayable.h"
#include "Runtime/Threads/Thread.h"

#include "Runtime/Core/Callbacks/GlobalCallbacks.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Director/Core/PlayableOutput.h"
#include "Runtime/Animation/Director/AnimationPlayableOutput.h"
#include "Runtime/Transform/TransformHierarchy.h"
#include "Runtime/Transform/TransformChangeDispatch.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Profiler tag for Animator manager update loop
PROFILER_INFORMATION(gAnimatorsUpdate, "Animators.Update", kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorsApplyOnAnimatorMove, "Animators.ApplyOnAnimatorMove",   kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorsFireAnimationEventsAndBehaviours, "Animators.FireAnimationEventsAndBehaviours", kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorsDirtyObject, "Animators.DirtySceneObjects", kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorsPrepareForFirstPass, "Animators.PrepareFirstPass", kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorsPrepareForSecondPass, "Animators.PrepareSecondPass", kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorsProcessRootMotionJob, "Animators.ProcessRootMotionJob", kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorsProcessAnimationsJob, "Animators.ProcessAnimationsJob", kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorsRetargetJob, "Animators.RetargeterJob", kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorsIKJob, "Animators.IKJob", kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorsWriteJob, "Animators.WriteJob", kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorsSortWriteJob, "Animators.SortWriteJob", kProfilerAnimation);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Profiler tag for Animator specific function
PROFILER_INFORMATION(gAnimatorInitialize, "Animator.Initialize",   kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorSetupAvatarDataSet, "Animator.SetupAvatarDataSet",   kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorSetupControllerDataSet, "Animator.SetupControllerDataSet",   kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorRetargetStep, "Animator.EvaluateRetargeter", kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorIKStep, "Animator.EvaluateIK",   kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorWriteStep, "Animator.WriteAnimatedValues", kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorFireAnimationEvents, "Animator.FireAnimationEvents", kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorFireStateMachineBehaviours, "Animator.FireStateMachineBehaviours",   kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorApplyBuiltinRootMotion, "Animator.ApplyBuiltinRootMotion",   kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorApplyOnAnimatorMove, "Animator.ApplyOnAnimatorMove", kProfilerAnimation);
ANIMATOR_PROFILER_INFORMATION_DETAIL(gAnimatorApplyRootPositionAndRotation, "Animator.ApplyRootPositionAndRotation",   kProfilerAnimation);

using namespace UnityEngine::Animation;
using core::string;

#define VALIDATE_HAS_ANIMATOR_CONTROLLER(x) \
if(!ValidateHasAnimatorController()) \
    return x; \

#define VALIDATE_HAS_ANIMATOR_CONTROLLER_VOID() \
if(!ValidateHasAnimatorController()) \
    return; \

#define VALIDATE_HAS_PLAYABLE(x) \
if(!ValidateHasPlayable()) \
    return x; \

#define VALIDATE_HAS_PLAYABLE_VOID() \
if(!ValidateHasPlayable()) \
    return; \

#define FOR_EACH_ANIMATORCONTROLLERPLAYABLE_PARAMETER_RETURN(FUNC, ...) \
{\
    VALIDATE_HAS_PLAYABLE(kAnimatorControllerNotPresent);\
    int ret = 0;\
    for(AnimatorControllerPlayables::iterator it = m_ControllerPlayableCache.begin() ; it != m_ControllerPlayableCache.end() ; ++it)\
        ret |=  (*it)->FUNC(__VA_ARGS__);\
    return (GetSetValueResult)ret;\
}\

#define FOR_EACH_ANIMATORCONTROLLERPLAYABLE(FUNC, ...) \
{\
    for(AnimatorControllerPlayables::iterator it = m_ControllerPlayableCache.begin() ; it != m_ControllerPlayableCache.end() ; ++it)\
        (*it)->FUNC(__VA_ARGS__);\
}\



#define FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(FUNC, DEFAULT, ...) \
{\
    VALIDATE_HAS_PLAYABLE(DEFAULT);\
    if(m_ControllerPlayableCache.size()>0)\
        return m_ControllerPlayableCache[0]->FUNC(__VA_ARGS__);\
    else\
        return DEFAULT;\
}\

#define VALIDATE_ROOT_MOTION_VOID() \
    if(IsPlayingBack()) \
    return; \
    if( !(m_AnimatorActivePasses & kOnAnimatorMove))\
{\
    WarningStringIfLoggingActive("Calling ApplyBuiltinRootMotion can only be done during OnAnimatorMove");\
    return ;\
}\

#define VALIDATE_CAN_DISABLE_ANIMATOR() \
if( (m_AnimatorActivePasses & kWritingFloatPropertyValues))\
{\
    WarningStringIfLoggingActive("Not allowed to disable Animator while it is evaluated");\
    return ;\
}\

#define VALIDATE_CAN_WRITE_VALUES() \
    DebugAssertMsg((m_AnimatorActivePasses & kWritingDisallowed) == 0 , "Cannot write values at this point")

#define GETANIMATIONPLAYABLE(playable, index) \
    static_cast<AnimationPlayable*>(playable->GetPlayerType() == kAnimation ? playable : PlayableTraverser::NextByType(playable, index, kAnimation))

void Animator::AnimatorJob::AddPlayable(AnimationPlayable * playable, float weight)
{
    if (playable == m_Animator->m_ControllerPlayable)
        m_Playables.insert(m_Playables.begin(), WeightedPlayable(playable->Handle(), weight));
    else
        m_Playables.push_back(WeightedPlayable(playable->Handle(), weight));
}

BoundPlayable::BoundPlayable(PlayableOutput *output)
{
    m_PlayableOutput = output->Handle();
    m_Playable = output->GetSourcePlayable()->Handle();
    m_PortIndex = output->GetSourceInputPort();
}

AnimationPlayable* BoundPlayable::GetAnimationPlayable() const
{
    return GETANIMATIONPLAYABLE(m_Playable.GetPlayable(), m_PortIndex);
}

Playable* BoundPlayable::GetPlayable() const
{
    AssertMsg(m_Playable.IsValid(), "Accessing an invalid BoundPlayable");
    return m_Playable.GetPlayable();
}

PlayableOutput* BoundPlayable::GetPlayableOutput() const
{
    if (!m_PlayableOutput.IsValid())
        return NULL;

    return m_PlayableOutput.GetOutput();
}

static void GlobalXToTRS(TransformAccessReadOnly transformAccess, math::trsX &x)
{
    CalculateGlobalPositionAndRotation(transformAccess, x.t, x.q);
    math::float3x3 gsm = CalculateGlobalSM(transformAccess, x.q);
    x.s = math::float3(gsm.m0.x, gsm.m1.y, gsm.m2.z);
}

static bool TRSToGlobalTR(TransformAccess transformAccess, const math::trsX &x)
{
    return SetGlobalTR(transformAccess, x.t, x.q);
}

Animator::Animator(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode),
    m_Visible(false),
    m_CullingMode(kCullNone),
    m_UpdateMode(kNormal),
    m_AnimatorActivePasses(0),
    m_HeapAlloc(label),
    m_AvatarDataSet(label),
    m_BindingsDataSet(label),
    m_SamplingDataSets(label),
    m_DeltaPosition(Vector3f::zero),
    m_DeltaRotation(Quaternionf::identity()),
    m_Velocity(Vector3f::zero),
    m_AngularVelocity(Vector3f::zero),
    m_PivotPosition(0, 0, 0),
    m_TargetPosition(Vector3f::zero),
    m_TargetRotation(Quaternionf::identity()),
    m_MatchStartTime(-1),
    m_MatchStateID(-1),
    m_MatchPosition(Vector3f::zero),
    m_MatchRotation(Quaternionf::identity()),
    m_MatchTargetMask(Vector3f::one, 0),
    m_MustCompleteMatch(false),
    m_ApplyRootMotion(false),
    m_LinearVelocityBlending(false),
    m_Speed(1),
    m_LogWarnings(true),
    m_FireEvents(true),
    m_AnimatorAvatarNode(this),
    m_PlayableNodes(this),
    m_AnimatorControllerNode(this),
    m_ObjectUsers(this),
    m_AvatarPlayback(label),
    m_RecorderMode(eOffline),
    m_PlaybackDeltaTime(0),
    m_PlaybackTime(0),
    m_AllowConstantClipSamplingOptimization(true),
    m_HasTransformHierarchy(true),
    m_ControllerPlayable(NULL),
    m_HasStateMachineBehaviour(false),
    m_ControllerPlayableCache(kMemAnimation),
    m_ControllerPlayableCacheLayerCount(0)
{
}

void Animator::ThreadedCleanup()
{
    AssertMsg(m_AvatarDataSet.m_AvatarMemory == NULL && m_BindingsDataSet.m_GenericBindingConstant == NULL && m_ContainedRenderers.size() == 0,
        "Animator is not cleared when ThreadedCleanup is called");
}

void Animator::MainThreadCleanup()
{
    ClearObject();

    if (m_PlayableGraph.IsValid())
    {
        ClearInternalControllerPlayable();
        m_PlayableOutput.GetOutput()->SetSourcePlayable(0);
        GetDirectorManager().ScheduleGraphDestroy(m_PlayableGraph);
        m_PlayableGraph = HPlayableGraph::Null;
    }

    m_ObjectUsers.Clear();

    BoundPlayables boundPlayables = m_BoundPlayables;
    for (BoundPlayables::iterator it = boundPlayables.begin(); it != boundPlayables.end(); ++it)
    {
        PlayableOutput* output = it->GetPlayableOutput();
        if (output)
        {
            output->OnPlayerDestroyed(this);
        }
    }

    Super::MainThreadCleanup();
}

void Animator::AwakeFromLoad(AwakeFromLoadMode mode)
{
    Super::AwakeFromLoad(mode);
    Rebind(false);
}

void Animator::CheckConsistency()
{
}

void Animator::Reset()
{
    Super::Reset();

    m_CullingMode = kCullNone;
    m_ApplyRootMotion = false;
    m_UpdateMode = kNormal;
    m_HasTransformHierarchy = true;
}

IMPLEMENT_REGISTER_CLASS(Animator, 95);
IMPLEMENT_OBJECT_SERIALIZE(Animator);

template<class TransferFunction>
void Animator::Transfer(TransferFunction& transfer)
{
    transfer.SetVersion(3);

    Super::Transfer(transfer);

    transfer.Transfer(m_Avatar, "m_Avatar");
    transfer.Transfer(m_Controller, "m_Controller");

    TRANSFER_ENUM(m_CullingMode);
    TRANSFER_ENUM(m_UpdateMode);

    transfer.Transfer(m_ApplyRootMotion, "m_ApplyRootMotion", kDontAnimate);
    transfer.Transfer(m_LinearVelocityBlending, "m_LinearVelocityBlending", kDontAnimate);

    transfer.Align();

    if (transfer.IsVersionSmallerOrEqual(2))
    {
        bool animatePhysics = false;
        transfer.Transfer(animatePhysics, "m_AnimatePhysics", kDontAnimate);
        m_UpdateMode = animatePhysics ? kAnimatePhysics : kNormal;
    }

    TRANSFER_EDITOR_ONLY(m_WarningMessage);
    transfer.Transfer(m_HasTransformHierarchy, "m_HasTransformHierarchy", kDontAnimate);
    transfer.Transfer(m_AllowConstantClipSamplingOptimization, "m_AllowConstantClipSamplingOptimization", kDontAnimate);

    transfer.Align();
}

void Animator::OnAddComponent(Component* com)
{
    Renderer* renderer = dynamic_pptr_cast<Renderer*>(com);
    if (renderer)
        InitializeVisibilityCulling();
}

void Animator::Deactivate(DeactivateOperation operation)
{
    Super::Deactivate(operation);
    ClearRelatedPropertyBlocks();
    ClearObject();
    ClearContainedRenderers();
}

void Animator::Rebind(bool writeDefaultValues /* = true */)
{
    if (writeDefaultValues) // Don't write defaults when awakening from load
    {
        WriteDefaultValuesNoDirty();
        ClearInternalControllerPlayable();
    }

    VALIDATE_CAN_DISABLE_ANIMATOR();

    CreateObject();
    InitializeVisibilityCulling();
}

ScriptingMethodPtr StateChangeValidateCallback(ScriptingMethodPtr method, ScriptingClassPtr klass, Object* errorContext)
{
    method = Scripting::GetOverrideMethodOnly(scripting_method_get_name(method), klass,  GetAnimationScriptingClasses().stateMachineBehaviour);

    // If there is no override do not setup cache to avoid useless call
    if (!method.IsNull())
    {
        int parameterCount = scripting_method_get_argument_count(method);
        if ((parameterCount == 3 && !Check3MethodParameters(method, klass, GetAnimationScriptingClasses().animator, GetAnimationScriptingClasses().animatorStateInfo, GetCommonScriptingClasses().int_32, errorContext, GetMonoManager()))  ||
            (parameterCount == 4 && !Check4MethodParameters(method, klass, GetAnimationScriptingClasses().animator, GetAnimationScriptingClasses().animatorStateInfo, GetCommonScriptingClasses().int_32, GetAnimationScriptingClasses().animatorControllerPlayable, errorContext, GetMonoManager())))
        {
            method = NULL;
        }
    }
    return method;
}

ScriptingMethodPtr StateMachineValidateCallback(ScriptingMethodPtr method, ScriptingClassPtr klass, Object* errorContext)
{
    method = Scripting::GetOverrideMethodOnly(scripting_method_get_name(method), klass,  GetAnimationScriptingClasses().stateMachineBehaviour);

    // If there is no override do not setup cache to avoid useless call
    if (!method.IsNull())
    {
        int parameterCount = scripting_method_get_argument_count(method);
        if ((parameterCount == 2 && !Check2MethodParameters(method, klass, GetAnimationScriptingClasses().animator, GetCommonScriptingClasses().int_32, errorContext, GetMonoManager()))  ||
            (parameterCount == 3 && !Check3MethodParameters(method, klass, GetAnimationScriptingClasses().animator, GetCommonScriptingClasses().int_32, GetAnimationScriptingClasses().animatorControllerPlayable, errorContext, GetMonoManager())))
        {
            method = NULL;
        }
    }
    return method;
}

void Animator::AnimationClipModified()
{
    ClearObject();
    m_ObjectUsers.SendMessage(kDidDeleteMotion);
}

void Animator::InitializeClass()
{
    mecanim::memory::Profiler::StaticInitialize();

    REGISTER_MESSAGE_VOID(kDidModifyAnimatorController, ClearAnimatorController);
    REGISTER_MESSAGE_VOID(kDidModifyOverrideClip, UpdateOverrideControllerBindings);

    REGISTER_MESSAGE_VOID(kDidModifyMotion, AnimationClipModified); // an animationClip sends this when modified
    REGISTER_MESSAGE_VOID(kDidDeleteMotion, AnimationClipModified); // an animationClip sends this when deleted
    REGISTER_MESSAGE_VOID(kDidModifyAvatar, ClearObject);

    //@TODO: This doesn't really cover any real world cases...
    /// adding new children is not covered, adding component to children is not covered.
    // [case 585416] Do not remove this line, it will break web player compatibility.
    REGISTER_MESSAGE_PTR(kDidAddComponent, OnAddComponent, Component);

    mecanim::animation::ControllerConstant::InitializeClass();
    mecanim::animation::AvatarConstant::InitializeClass();
    mecanim::statemachine::StateConstant::InitializeClass();

    mecanim::crc32::crc32_table_type::init_table();
    mecanim::animation::InitializeMuscleClipTables();
    HumanTrait::InitializeClass();

    RegisterValidateMethodCallback(MonoScriptCache::kOnStateEnter, StateChangeValidateCallback, "OnStateEnter");
    RegisterValidateMethodCallback(MonoScriptCache::kOnStateExit, StateChangeValidateCallback, "OnStateExit");
    RegisterValidateMethodCallback(MonoScriptCache::kOnStateUpdate, StateChangeValidateCallback, "OnStateUpdate");
    RegisterValidateMethodCallback(MonoScriptCache::kOnStateMove, StateChangeValidateCallback, "OnStateMove");
    RegisterValidateMethodCallback(MonoScriptCache::kOnStateIK, StateChangeValidateCallback, "OnStateIK");
    RegisterValidateMethodCallback(MonoScriptCache::kOnStateMachineEnter, StateMachineValidateCallback, "OnStateMachineEnter");
    RegisterValidateMethodCallback(MonoScriptCache::kOnStateMachineExit, StateMachineValidateCallback, "OnStateMachineExit");

    Assert(mecanim::animation::FindMuscleIndex(0) == -1);
    Assert(mecanim::animation::FindMuscleIndex(mecanim::processCRC32("MotionT.x")) == 0);
#ifdef UNITY_EDITOR
    // case 913301 while in play mode the user can modify a script, the animator must get the callback before any script is able to
    // run MonoBehaviour.OnEnable otherwise call to Animator.GetBehaviour() from an OnEnable will fail
    GlobalCallbacks::Get().beforeProcessingInitializeOnLoad.Register(&Animator::RebindOnDomainReload);
#endif
}

void Animator::CleanupClass()
{
    HumanTrait::CleanupClass();
    mecanim::animation::CleanupMuscleClipTables();

    mecanim::memory::Profiler::StaticDestroy();
#ifdef UNITY_EDITOR
    GlobalCallbacks::Get().beforeProcessingInitializeOnLoad.Unregister(&Animator::RebindOnDomainReload);
#endif
}

static bool DoesLayerHaveIKPass(int layerIndex, const mecanim::animation::ControllerConstant& controller)
{
    return layerIndex < (int)controller.m_LayerCount && controller.m_LayerArray[layerIndex]->m_IKPass;
}

Animator::AutoMecanimDataSet::~AutoMecanimDataSet()
{
    Reset();
}

void Animator::AutoMecanimDataSet::Reset()
{
    m_AvatarDataSet.Reset();
    m_BindingsDataSet.Reset();

    RuntimeAnimatorController::DestroyCustomController(m_ControllerConstant, m_AvatarDataSet.m_Alloc);

    mecanim::animation::DestroyControllerMemory(m_ControllerMemory, m_AvatarDataSet.m_Alloc);

    m_ControllerConstant    = 0;
    m_ControllerMemory      = 0;
}


/// @brief 动画更新采样
/// @param clip 
/// @param inTime 
/// @return 
bool Animator::Sample(AnimationClip& clip, float inTime)
{
    if (clip.IsLegacy() ||  GetRuntimeAnimatorController() == 0)
        return false;

    m_SamplingDataSets.Reset();

    SetupAvatarDataSet(m_Avatar.IsValid() ? m_Avatar->GetAsset() : NULL, m_SamplingDataSets.m_AvatarDataSet, true);

    if (!m_SamplingDataSets.m_AvatarDataSet.m_Initialized)
        return false;

    ScopedAnimatorPass scopedAnimatorPass(m_AnimatorActivePasses, kSampling);

    AnimationClipPPtrVector clips;
    clips.push_back(PPtr<AnimationClip>(&clip));

    m_SamplingDataSets.m_ControllerConstant     = RuntimeAnimatorController::BuildCustomController(clip, m_Controller->GetAsset(), m_SamplingDataSets.m_AvatarDataSet.m_Alloc);
    m_SamplingDataSets.m_ControllerMemory       = mecanim::animation::CreateControllerMemory(m_SamplingDataSets.m_ControllerConstant, m_SamplingDataSets.m_AvatarDataSet.m_Alloc);

    AnimationSetBindingsPtr animationSetBindingsPtr = AnimationSetBindingsPtr(CreateAnimationSetBindings(clips, m_SamplingDataSets.m_BindingsDataSet.m_Alloc), AnimationSetBindingsPtr::deleter_t(m_SamplingDataSets.m_BindingsDataSet.m_Alloc.GetMemoryLabel(), UnityEngine::Animation::DestroyAnimationSetBindings));

    SetupBindingsDataSet(animationSetBindingsPtr, m_SamplingDataSets.m_BindingsDataSet, m_SamplingDataSets.m_AvatarDataSet);

    TransformChangeSystemMask systemMask = (GetUpdateMode() == kAnimatePhysics) ? GetTransformChangeDispatch().GetChangeMaskForInterest(TransformChangeDispatch::kInterestedInPhysicsAnimation) : TransformChangeSystemMask(0);

    // muscle clip can be NULL when there is not curve at all in the clip.
    mecanim::animation::ClipMuscleConstant* muscleConstant = clip.GetRuntimeAsset();
    if (muscleConstant == NULL)
    {
        // in this case we want to set a human rig into relax pose to start keyframing
        if (m_SamplingDataSets.m_AvatarDataSet.m_AvatarConstant->isHuman())
        {
            mecanim::human::HumanPose pose;

            mecanim::human::Human const* human = m_SamplingDataSets.m_AvatarDataSet.m_AvatarConstant->m_Human.Get();
            mecanim::human::RetargetTo(human, &pose, 0, math::trsIdentity(), m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput, m_SamplingDataSets.m_AvatarDataSet.m_AvatarWorkspace->m_BodySkeletonPoseWs, m_SamplingDataSets.m_AvatarDataSet.m_AvatarWorkspace->m_BodySkeletonPoseWsA);
            mecanim::animation::EvaluateAvatarEnd(m_SamplingDataSets.m_AvatarDataSet.m_AvatarConstant, m_SamplingDataSets.m_AvatarDataSet.m_AvatarInput, m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput,
                m_SamplingDataSets.m_AvatarDataSet.m_AvatarMemory, m_SamplingDataSets.m_AvatarDataSet.m_AvatarWorkspace);

            SetHumanTransformPropertyValues(*m_SamplingDataSets.m_AvatarDataSet.m_AvatarBindingConstant, *m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_SkeletonPoseOutput, true, systemMask);
            SetTransformPropertyApplyMainThread(GetComponent<Transform>(), *m_SamplingDataSets.m_BindingsDataSet.m_GenericBindingConstant, *m_SamplingDataSets.m_AvatarDataSet.m_AvatarBindingConstant);
        }
        return false;
    }

    int clipIndex = 0;

    // prepare the evaluation context for clip and evaluate in float array
    mecanim::ValueArray* valuesDefault = m_SamplingDataSets.m_BindingsDataSet.m_GenericBindingConstant->controllerBindingConstant->m_DynamicValuesDefault;
    mecanim::ValueArrayConstant* valuesDefaultConstant = m_SamplingDataSets.m_BindingsDataSet.m_GenericBindingConstant->controllerBindingConstant->m_DynamicValuesConstant;
    mecanim::ValueArrayMask& readMask = *m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesMaskOutput;

    mecanim::animation::AnimationSet::Clip* setClip = &m_SamplingDataSets.m_BindingsDataSet.m_AnimationSetBindings->animationSet->m_ClipConstant[clipIndex];

    mecanim::memory::MecanimAllocator tempAllocator(kMemTempAlloc);
    mecanim::animation::ClipMemory* clipMemory = CreateClipMemory(muscleConstant->m_Clip.Get(), tempAllocator);
    mecanim::animation::ClipOutput* clipOutput = CreateClipOutput(muscleConstant->m_Clip.Get(), tempAllocator);

    mecanim::animation::ClipInput in;
    in.m_Time = inTime;

    mecanim::animation::EvaluateClip(muscleConstant->m_Clip.Get(), &in, clipMemory, clipOutput);

    // load values and retarget
    mecanim::SetValueMask<false>(&readMask, false);
    mecanim::animation::ValuesFromClip<false>(*valuesDefault, *clipOutput, setClip->m_Bindings, m_SamplingDataSets.m_BindingsDataSet.m_AnimationSetBindings->animationSet->m_IntegerRemapStride, *m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesOutput, readMask);

    if (m_SamplingDataSets.m_AvatarDataSet.m_AvatarConstant->isHuman())
    {
        mecanim::animation::GetHumanPose(*muscleConstant, clipOutput->m_Values, *m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_HumanPoseBaseOutput);
        mecanim::human::HumanPoseCopy(*m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput, *m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_HumanPoseBaseOutput);
        mecanim::animation::EvaluateAvatarRetarget(m_SamplingDataSets.m_AvatarDataSet.m_AvatarConstant, m_SamplingDataSets.m_AvatarDataSet.m_AvatarInput, m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput, m_SamplingDataSets.m_AvatarDataSet.m_AvatarMemory, m_SamplingDataSets.m_AvatarDataSet.m_AvatarWorkspace);
        mecanim::animation::EvaluateAvatarEnd(m_SamplingDataSets.m_AvatarDataSet.m_AvatarConstant, m_SamplingDataSets.m_AvatarDataSet.m_AvatarInput, m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput, m_SamplingDataSets.m_AvatarDataSet.m_AvatarMemory, m_SamplingDataSets.m_AvatarDataSet.m_AvatarWorkspace);
    }

    // Controller animated values
    int* additionalIndexArray;
    ALLOC_TEMP_AUTO(additionalIndexArray, m_SamplingDataSets.m_ControllerConstant->m_Values->m_Count);
    memset(additionalIndexArray, -1, sizeof(int) * m_SamplingDataSets.m_ControllerConstant->m_Values->m_Count);
    BindAdditionalCurves(*m_SamplingDataSets.m_ControllerConstant->m_Values, m_SamplingDataSets.m_BindingsDataSet.m_AnimationSetBindings->genericBindingsSize, m_SamplingDataSets.m_BindingsDataSet.m_AnimationSetBindings->genericBindings, additionalIndexArray);
    ValueArrayCopy(valuesDefaultConstant, m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesOutput, m_SamplingDataSets.m_ControllerConstant->m_Values.Get(),
        m_SamplingDataSets.m_ControllerMemory->m_Values.Get(), additionalIndexArray);

    // set generic values
    SetGenericFloatPropertyValues(*m_SamplingDataSets.m_BindingsDataSet.m_GenericBindingConstant, *m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesOutput);
    SetGenericIntPropertyValues(*m_SamplingDataSets.m_BindingsDataSet.m_GenericBindingConstant, *m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesOutput);
    SetGenericPPtrPropertyValues(*m_SamplingDataSets.m_BindingsDataSet.m_GenericBindingConstant, *m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesOutput);

    // set transform values
    if (m_SamplingDataSets.m_AvatarDataSet.m_AvatarConstant->isHuman())
        SetHumanTransformPropertyValues(*m_SamplingDataSets.m_AvatarDataSet.m_AvatarBindingConstant, *m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_SkeletonPoseOutput, true, systemMask);
    SetGenericTransformPropertyValues(*m_SamplingDataSets.m_BindingsDataSet.m_GenericBindingConstant, *m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesOutput, 0, systemMask);  // when sampling set root transform if needed

    SetTransformPropertyApplyMainThread(GetComponent<Transform>(), *m_SamplingDataSets.m_BindingsDataSet.m_GenericBindingConstant, *m_SamplingDataSets.m_AvatarDataSet.m_AvatarBindingConstant);

    DestroyClipMemory(clipMemory, tempAllocator);
    DestroyClipOutput(clipOutput, tempAllocator);
    return true;
}

void Animator::BatchedFKPass(const PlayableOutputArray& jobs)
{
    UpdateAvatars(jobs, true, false, false);
}

void Animator::BatchedIKPass(const PlayableOutputArray& jobs)
{
    UpdateAvatars(jobs, false, true, false);
}

#if ENABLE_MULTITHREADED_ANIMATION
    #define AVATAR_LOOP(x, list, profile) \
    {\
        size_t avatarJobCount = list.size();\
        if(avatarJobCount > 0)\
        {\
            PROFILER_AUTO(profile, NULL);\
            JobFence fence;\
            ScheduleJobForEach<AnimatorJob>(fence, x, list.data(), static_cast<int>(avatarJobCount), kHighJobPriority);\
            SyncFence(fence);\
    }\
    }
#else
    #define AVATAR_LOOP(x, list, profile) \
    {\
        size_t avatarJobCount = list.size();\
        AnimatorJob* jobData = list.data();\
        for (size_t i=0;i<avatarJobCount;i++)\
            { x( jobData, i); }\
    }
#endif


// We should make it so that Animator jobs are only rebuilded when PlayableOutputArray changes.
void Animator::BuildJobs(const PlayableOutputArray& outputs,  AnimatorJobs& animatorJobs, AnimatorJobs* humanoidJobs, bool FKPass, bool updateGraph)
{
    TransformChangeSystemMask physicsSystemsMask = GetTransformChangeDispatch().GetChangeMaskForInterest(TransformChangeDispatch::kInterestedInPhysicsAnimation);

    const size_t inputSize = outputs.size();
    for (size_t i = 0; i < inputSize; i++)
    {
        if (outputs[i]->GetPlayerType() != kAnimation)
            continue;

        AnimationPlayableOutput* animationOutput = static_cast<AnimationPlayableOutput*>(outputs[i]);

        if (animationOutput->GetTargetAnimator() == NULL || animationOutput->GetSourcePlayable() == NULL)
            continue;

        Animator& animator = *(animationOutput->GetTargetAnimator());

        if (!((animator.GetEnabled() || updateGraph) && animator.Prepare()))
            continue;

        bool shouldAdd = FKPass ? (animator.m_AvatarDataSet.m_AvatarMemory->m_FirstEval || (animator.m_Visible || animator.m_CullingMode != kCullAll))
            : animator.m_Visible;
        if (!shouldAdd)
            continue;

        bool animatorAdded = false;
        AnimationPlayable* animationPlayable = GETANIMATIONPLAYABLE(animationOutput->GetSourcePlayable(), animationOutput->GetSourceInputPort());

        if (animationPlayable == NULL)
            continue;


        if (animator.m_BoundPlayables.size() > 1) // if we are bound to multiple playables, we try to append the Playable to the list of the AnimatorJob
        {
            for (AnimatorJobs::iterator it = animatorJobs.begin(); it != animatorJobs.end(); ++it)
            {
                if (it->m_Animator == &animator)
                {
                    it->AddPlayable(animationPlayable, animationOutput->GetOutputWeight());
                    animatorAdded = true;
                    break;
                }
            }
        }

        if (animatorAdded)
            continue;

        TransformChangeSystemMask systemMask = (animator.GetUpdateMode() == kAnimatePhysics) ? physicsSystemsMask : TransformChangeSystemMask(0);
        AnimatorJob job = AnimatorJob(animator.GetRootTransformAccess(), systemMask, &animator, animationPlayable, animationOutput->GetOutputWeight());
        animatorJobs.push_back(job);

        // Humanoid jobs.
        if (!FKPass && animator.IsHuman())
        {
            animatorAdded = false;
            if (animator.m_BoundPlayables.size() > 1)// if we are bound to multiple playables, we try to append the Playable to the list of the AnimatorJob
            {
                for (AnimatorJobs::iterator it = humanoidJobs->begin(); it != humanoidJobs->end(); ++it)
                {
                    if (it->m_Animator == &animator)
                    {
                        it->AddPlayable(animationPlayable, animationOutput->GetOutputWeight());
                        animatorAdded = true;
                        break;
                    }
                }
            }

            if (!animatorAdded)
            {
                humanoidJobs->push_back(job);
                animator.m_AvatarDataSet.m_AvatarWorkspace->m_DefaultIKPass = true;
                animator.m_AvatarDataSet.m_AvatarWorkspace->m_DoIK = true;
            }
        }
    }
}


/// @brief  Job 相关的排序？？
/// @param lhs 
/// @param rhs 
/// @return 
static inline bool JobSort(Animator::AnimatorJob const *lhs, Animator::AnimatorJob const *rhs)
{
    return lhs->m_RootTransformAccess.hierarchy < rhs->m_RootTransformAccess.hierarchy;
}

void Animator::SortJobsBasedOnHierarchy(AnimatorJobs const &jobs, AnimatorWriteJobs &writeJobs)
{
    PROFILER_AUTO(gAnimatorsSortWriteJob, NULL)

    int32_t jobSize = jobs.size();

    if (jobSize > 0)
    {
        dynamic_array<AnimatorJob const *> sortedJobs(kMemTempAlloc);
        sortedJobs.reserve(jobSize);

        for (int32_t jobIter = 0; jobIter < jobSize; jobIter++)
        {
            sortedJobs.push_back(&jobs[jobIter]);
        }

        std::sort(sortedJobs.begin(), sortedJobs.end(), JobSort);

        writeJobs.reserve(jobSize);
        writeJobs.emplace_back();
        writeJobs[0].push_back(*sortedJobs[0]);

        int32_t writeIndex = 0;

        for (int32_t jobIter = 1; jobIter < jobSize; jobIter++)
        {
            if (sortedJobs[jobIter]->m_RootTransformAccess.hierarchy != sortedJobs[jobIter - 1]->m_RootTransformAccess.hierarchy)
            {
                writeIndex++;
                writeJobs.emplace_back();
            }

            writeJobs[writeIndex].push_back(*sortedJobs[jobIter]);
        }
    }
}

void Animator::WriteLoop(AnimatorWriteJobs &writeJobs)
{
    PROFILER_AUTO(gAnimatorsWriteJob, NULL)

    int32_t jobsCount = writeJobs.size();

    AnimatorJobs* jobsData = writeJobs.data();

    #if ENABLE_MULTITHREADED_ANIMATION

    if (jobsCount > 0)
    {
        JobFence fence;
        ScheduleJobForEach(fence, WriteJobs, jobsData, static_cast<int>(jobsCount), kHighJobPriority);
        SyncFence(fence);
    }

    #else

    for (int32_t jobsIter = 0; jobsIter < jobsCount; jobsIter++)
    {
        WriteJobs(jobsData, jobsIter);
    }

    #endif
}

void Animator::UpdateAvatars(const PlayableOutputArray& outputs, bool doFKMove, bool doRetargetIKWrite, bool updateGraph)
{
    PROFILER_AUTO(gAnimatorsUpdate, NULL)

    const size_t inputSize = outputs.size();

    const float deltaTime = inputSize > 0 ? outputs[0]->GetParentGraph()->GetLastUsedDeltaTime() : 0.0f;
    const float realDeltaTime = GetTimeManager().GetDynamicUnscaledDeltaTime();

    if (doFKMove)
    {
        // At the begining of the frame, try to re-add null Playables, which are AnimatorControllerPlayable
        for (size_t i = 0; i < inputSize; i++)
        {
            AnimationPlayableOutput* animationOutput = static_cast<AnimationPlayableOutput*>(outputs[i]);
            Animator *animator = animationOutput->GetTargetAnimator();
            Playable* root = animationOutput->GetSourcePlayable();
            if (root == NULL && animator != NULL)
            {
                animator->Prepare();
            }
        }

        // invisible & visible animators
        AnimatorJobs activeAnimators(kMemTempAlloc);
        activeAnimators.reserve(inputSize);
        {
            PROFILER_AUTO(gAnimatorsPrepareForFirstPass, NULL);
            BuildJobs(outputs, activeAnimators, NULL, true, updateGraph);

            // Init delta time
            for (size_t i = 0; i < activeAnimators.size(); i++)
            {
                Animator& animator =  *activeAnimators[i].m_Animator;
                animator.InitStep((animator.GetUpdateMode() == kUnscaledTime && IsWorldPlaying()) ?  realDeltaTime :  deltaTime);

                // We are writing to m_SkeletonPoseOutputReady & skeleton pose, skin matrix extraction jobs depend on this data.
                // Make sure all jobs depending on this data have already completed.
                SyncFence(animator.m_WriteGlobalPoseFence);
                animator.m_AvatarDataSet.m_AvatarMemory->m_SkeletonPoseOutputReady = false;

                if (animator.IsPlayingBack())
                    animator.EvaluateController(animator.m_AvatarDataSet.m_AvatarInput->m_DeltaTime);
            }
        }

        AVATAR_LOOP(ProcessRootMotionJob, activeAnimators, gAnimatorsProcessRootMotionJob)

        // MainThread AnimationEvents & Behaviours
        {
            PROFILER_AUTO(gAnimatorsFireAnimationEventsAndBehaviours, NULL);

            AutoExecutionRestriction restriction(kDisableImmediateDestruction);

            for (size_t i = 0; i < activeAnimators.size(); i++)
            {
                Animator& animator = *activeAnimators[i].m_Animator;

                if (animator.IsInitialized())
                    animator.FireAnimationEvents(activeAnimators[i]);

                if (animator.IsInitialized())
                    animator.FireBehaviours(mecanim::statemachine::kOnStateEnter | mecanim::statemachine::kOnStateExit | mecanim::statemachine::kOnStateUpdate, activeAnimators[i]);
            }
        }

        {
            PROFILER_AUTO(gAnimatorsApplyOnAnimatorMove, NULL);

            for (size_t i = 0; i < activeAnimators.size(); i++)
            {
                AnimatorJob& animatorJob = activeAnimators[i];
                Animator& animator = *animatorJob.m_Animator;
                animator.ClearFirstEvaluationFlag();

                if (animator.IsInitialized())  // might be disabled by FireBehaviours
                {
                    animator.ApplyOnAnimatorMove(activeAnimators[i]);
                    //Invisible animators don't get a write pass, so their first eval flag needs to be cleared here
                    if (animator.IsVisible() == false)
                        mecanim::animation::UpdateAvatarMemoryFirstEvalFlag(animator.m_AvatarDataSet.m_AvatarMemory, deltaTime);
                }
            }
        }
    }

    if (doRetargetIKWrite)
    {
        int layerCount = 0;

        // only visible animators
        AnimatorJobs visibleAnimators(kMemTempAlloc);
        visibleAnimators.reserve(inputSize);

        // human visible animators
        AnimatorJobs humanAnimators(kMemTempAlloc);
        humanAnimators.reserve(inputSize);

        {
            PROFILER_AUTO(gAnimatorsPrepareForSecondPass, NULL);
            BuildJobs(outputs, visibleAnimators, &humanAnimators, false, updateGraph);
        }

        for (AnimatorJobs::iterator animatorJobIt = visibleAnimators.begin(); animatorJobIt != visibleAnimators.end(); ++animatorJobIt)
        {
            int currentLayerCount = animatorJobIt->m_Animator->m_ControllerPlayableCacheLayerCount;
            layerCount = currentLayerCount >  layerCount ? currentLayerCount : layerCount;
            animatorJobIt->m_Animator->m_AvatarDataSet.m_AvatarWorkspace->m_DoWrite = true;
        }

        AnimatorWriteJobs writeVisibleAnimators(kMemTempAlloc);
        AnimatorWriteJobs writeHumanAnimators(kMemTempAlloc);

        SortJobsBasedOnHierarchy(visibleAnimators, writeVisibleAnimators);
        SortJobsBasedOnHierarchy(humanAnimators, writeHumanAnimators);

        // Process Animation
        AVATAR_LOOP(ProcessAnimationsJob, visibleAnimators, gAnimatorsProcessAnimationsJob)

        // Multithreaded Retarget & PrepareIK
        AVATAR_LOOP(RetargeterJob,          humanAnimators, gAnimatorsRetargetJob)

        // Default IK Pass
        AVATAR_LOOP(IKJob,  humanAnimators, gAnimatorsIKJob)
        WriteLoop(writeHumanAnimators);

        // Layered IK Pass
        for (int layerIter = 0; layerIter < layerCount; layerIter++)
        {
            // MainThread OnApplyAvatarIK
            for (size_t i = 0; i < humanAnimators.size(); i++)
            {
                AnimatorJob& animatorJob = humanAnimators[i];
                Animator& animator = *animatorJob.m_Animator;

                bool ikPass = false;


                for (AnimatorControllerPlayables::const_iterator it = animatorJob.m_Animator->m_ControllerPlayableCache.begin(); it != animatorJob.m_Animator->m_ControllerPlayableCache.end() && animator.IsInitialized(); ++it)
                {
                    if (!(*it)->IsInitialized())
                        continue;
                    ikPass |= DoesLayerHaveIKPass(layerIter, *(*it)->GetMemory()->m_ControllerConstant);
                }


                if (ikPass)
                {
                    animator.ApplyOnAnimatorIK(layerIter, animatorJob);
                }

                if (!animator.IsInitialized())
                    continue;

                animator.m_AvatarDataSet.m_AvatarWorkspace->m_DefaultIKPass = false;
                animator.m_AvatarDataSet.m_AvatarWorkspace->m_DoIK = ikPass;
                animator.m_AvatarDataSet.m_AvatarWorkspace->m_DoWrite = ikPass;
            }

            AVATAR_LOOP(IKJob,      humanAnimators, gAnimatorsIKJob)
            WriteLoop(writeHumanAnimators);
        }

        // Write to those that were not written already
        WriteLoop(writeVisibleAnimators);

        {
            PROFILER_AUTO(gAnimatorsDirtyObject, NULL);

            // [case 591079] Suppress immediate destruction during the callback to disallow
            // the object killing itself directly or indirectly in there (would do bad
            // things to the still updating animator).
            AutoExecutionRestriction restriction(kDisableImmediateDestruction);

            // MainThread Apply skeleton to transform components
            for (size_t i = 0; i < visibleAnimators.size(); i++)
            {
                visibleAnimators[i].m_Animator->WriteProperties(deltaTime, realDeltaTime);
            }
        }
    }
}

void Animator::WriteProperties(float deltaTime, float realDeltaTime)
{
    VALIDATE_CAN_WRITE_VALUES();
    if (!IsActive()) // animator can be turned Inactive by a parent animator -> 566794
        return;

    ScopedAnimatorPass scopedAnimatorPass(m_AnimatorActivePasses, kWritingFloatPropertyValues);

    SetGenericFloatPropertyValues(*m_BindingsDataSet.m_GenericBindingConstant, *m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesOutput);
    if (!IsInitialized())
        return; //case 660460: code can be called to disable the object, so we need to check
    SetGenericPPtrPropertyValues(*m_BindingsDataSet.m_GenericBindingConstant, *m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesOutput);
    SetGenericIntPropertyValues(*m_BindingsDataSet.m_GenericBindingConstant, *m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesOutput);

    if (m_HasTransformHierarchy)
    {
        SetTransformPropertyApplyMainThread(GetComponent<Transform>(), *m_BindingsDataSet.m_GenericBindingConstant, *m_AvatarDataSet.m_AvatarBindingConstant);
    }
    else
    {
        if (m_AvatarDataSet.m_AvatarConstant)
        {
            SetFlattenedSkeletonTransformsMainThread(GetComponent<Transform>(), *m_AvatarDataSet.m_AvatarBindingConstant);
        }
    }

    Record((GetUpdateMode() == kUnscaledTime && IsWorldPlaying()) ? realDeltaTime : deltaTime);

    mecanim::animation::UpdateAvatarMemoryFirstEvalFlag(m_AvatarDataSet.m_AvatarMemory, deltaTime);
}

void Animator::AddObjectUser(UserList& user)
{
    m_ObjectUsers.AddUser(user);
}

bool Animator::Prepare()
{
    if (!IsInitialized())
        CreateObject();

    mecanim::animation::ControllerInput* controllerInput = GetControllerInput();
    if (controllerInput)
        controllerInput->m_Speed = m_Speed;

    return IsInitialized();
}

void Animator::InitStep(float deltaTime)
{
    if (IsAutoPlayingBack())
    {
        SetPlaybackTimeInternal(m_AvatarPlayback.CursorTime() + deltaTime);
    }
    else
    {
        m_AvatarDataSet.m_AvatarInput->m_DeltaTime = deltaTime;
    }

    if (IsPlayingBack())
    {
        m_AvatarDataSet.m_AvatarInput->m_DeltaTime = m_PlaybackDeltaTime;

        m_PlaybackDeltaTime = 0;
    }

    m_AvatarDataSet.m_AvatarInput->m_LinearVelocityBlending = m_LinearVelocityBlending;
}

bool Animator::HasOnlySingleLayeredController()
{
    if (m_ControllerPlayableCache.size() == 0 || m_ControllerPlayableCache.size() != m_BoundPlayables.size())
        return false;

    bool hasLayers = false;

    for (AnimatorControllerPlayables::iterator it = m_ControllerPlayableCache.begin(); it != m_ControllerPlayableCache.end(); ++it)
    {
        hasLayers |= (*it)->GetLayerCount() > 1;
    }

    return !hasLayers;
}

void Animator::RetargetStep()
{
    PROFILER_AUTO(gAnimatorRetargetStep, this)

    bool affectMassCenter = m_AvatarDataSet.m_AvatarInput->m_LayersAffectMassCenter ||  HasOnlySingleLayeredController();

    mecanim::animation::EvaluateAvatarRetarget(m_AvatarDataSet.m_AvatarConstant, m_AvatarDataSet.m_AvatarInput, m_AvatarDataSet.m_AvatarOutput, m_AvatarDataSet.m_AvatarMemory, m_AvatarDataSet.m_AvatarWorkspace, affectMassCenter);
}

void Animator::IKStep()
{
    if (!m_AvatarDataSet.m_AvatarWorkspace->m_DoIK)
        return;

    PROFILER_AUTO(gAnimatorIKStep, this)
    mecanim::animation::EvaluateAvatarIK(m_AvatarDataSet.m_AvatarConstant, m_AvatarDataSet.m_AvatarInput, m_AvatarDataSet.m_AvatarOutput, m_AvatarDataSet.m_AvatarMemory, m_AvatarDataSet.m_AvatarWorkspace, m_AvatarDataSet.m_AvatarWorkspace->m_DefaultIKPass);
    mecanim::animation::EvaluateAvatarEnd(m_AvatarDataSet.m_AvatarConstant, m_AvatarDataSet.m_AvatarInput, m_AvatarDataSet.m_AvatarOutput, m_AvatarDataSet.m_AvatarMemory, m_AvatarDataSet.m_AvatarWorkspace);
}

void SetExposedSkeletonTransforms(mecanim::animation::AvatarConstant const& avatarConstant,  AnimatorGenericBindingConstant const& genericBinding, mecanim::skeleton::SkeletonPose const& localPose, mecanim::skeleton::SkeletonPoseT<math::affineX> const& globalPose, AvatarBindingConstant & bindings, TransformChangeSystemMask systemMask)
{
    for (mecanim::uint32_t i = 0; i < bindings.exposedTransformCount; i++)
    {
        ExposedTransform& exposedTransform = bindings.exposedTransforms[i];

        if (exposedTransform.transform)
        {
            const mecanim::skeleton::Skeleton *skeleton = avatarConstant.m_AvatarSkeleton.Get();

            math::trsX const &rootTRS = localPose.m_X[0];
            math::affineX const& globalX = globalPose.m_X[exposedTransform.skeletonIndexForUpdateTransform];

            math::affineX rootXInv;
            inverse(rootTRS, rootXInv);
            math::affineX localExposeX = math::mul(rootXInv, globalX);

            math::float4 globalR = mecanim::skeleton::SkeletonGetGlobalRotation(skeleton, &localPose, exposedTransform.skeletonIndexForUpdateTransform);
            math::float4 localExposeR = math::quatMul(math::quatConj(rootTRS.q), globalR);
            localExposeR = math::scaleMulQuat(rootTRS.s, localExposeR);

            exposedTransform.transform->SetLocalPositionWithoutNotification(localExposeX.t, systemMask);
            exposedTransform.transform->SetLocalRotationWithoutNotification(localExposeR, systemMask);

            if (genericBinding.exposedTransformScaleChangedArray[i])
            {
                // unfortunately here it may imply a lossy conversion
                // if transforms between expose and root induce a non-uniform scale
                math::float3x3 lrmInv;
                math::quatToMatrix(math::quatConj(localExposeR), lrmInv);
                math::float3x3 lsm = math::mul(lrmInv, localExposeX.rs);
                math::float3 ls = math::float3(lsm.m0.x, lsm.m1.y, lsm.m2.z);
                exposedTransform.transform->SetLocalScaleWithoutNotification(ls, systemMask);
            }
        }
    }
}

void Animator::WriteStep(TransformChangeSystemMask systemMask)
{
    if (!m_AvatarDataSet.m_AvatarWorkspace->m_DoWrite)
        return;

    PROFILER_AUTO(gAnimatorWriteStep, NULL);

    m_AvatarDataSet.m_AvatarWorkspace->m_DoWrite = false;

    if (m_HasTransformHierarchy)
    {
        // Write Transforms from humanoid skeleton
        if (m_AvatarDataSet.m_AvatarConstant->isHuman())
            /// review this function to just write what it needs
            SetHumanTransformPropertyValues(*m_AvatarDataSet.m_AvatarBindingConstant, *m_AvatarDataSet.m_AvatarOutput->m_SkeletonPoseOutput, true, systemMask);

        // Write Transforms for generic binding
        SetGenericTransformPropertyValues(*m_BindingsDataSet.m_GenericBindingConstant, *m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesOutput, &GetComponent<Transform>(), systemMask);
    }
    else if (m_AvatarDataSet.m_AvatarConstant->m_AvatarSkeleton->m_Count > 0)
    {
        mecanim::animation::SkeletonPoseFromValue(*m_AvatarDataSet.m_AvatarConstant->m_AvatarSkeleton.Get(),
            *m_AvatarDataSet.m_AvatarConstant->m_AvatarSkeletonPose.Get(),
            *m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesOutput,
            m_BindingsDataSet.m_GenericBindingConstant->controllerBindingConstant->m_SkeletonTQSMap,
            *m_AvatarDataSet.m_AvatarOutput->m_SkeletonPoseOutput,
            m_AvatarDataSet.m_AvatarConstant->isHuman() ? m_AvatarDataSet.m_AvatarConstant->m_HumanSkeletonReverseIndexArray.Get() : 0,
            true);

        if (!m_AvatarDataSet.m_AvatarConstant->isHuman())
        {
            m_AvatarDataSet.m_AvatarOutput->m_SkeletonPoseOutput->m_X[0] = m_AvatarDataSet.m_AvatarMemory->m_AvatarX;
        }

        mecanim::skeleton::SkeletonPoseCopy(m_AvatarDataSet.m_AvatarOutput->m_SkeletonPoseOutput, m_AvatarDataSet.m_AvatarOutput->m_SkeletonPoseOutputAffine);
        mecanim::skeleton::SkeletonPoseComputeGlobal(m_AvatarDataSet.m_AvatarConstant->m_AvatarSkeleton.Get(), m_AvatarDataSet.m_AvatarOutput->m_SkeletonPoseOutputAffine, m_AvatarDataSet.m_AvatarOutput->m_SkeletonPoseOutputAffine);

        SetExposedSkeletonTransforms(*m_AvatarDataSet.m_AvatarConstant, *m_BindingsDataSet.m_GenericBindingConstant, *m_AvatarDataSet.m_AvatarOutput->m_SkeletonPoseOutput, *m_AvatarDataSet.m_AvatarOutput->m_SkeletonPoseOutputAffine, *m_AvatarDataSet.m_AvatarBindingConstant, systemMask);

        m_AvatarDataSet.m_AvatarMemory->m_SkeletonPoseOutputReady = true;
    }
}

void Animator::FreeGlobalSpaceSkeletonPose(mecanim::skeleton::SkeletonPoseT<math::affineX>* tempMemory)
{
    if (tempMemory != NULL)
    {
        mecanim::memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);
        mecanim::skeleton::DestroySkeletonPose(tempMemory, tempAllocator);
    }
}

const mecanim::skeleton::SkeletonPoseT<math::affineX>* Animator::GetGlobalSpaceSkeletonPose(mecanim::skeleton::SkeletonPoseT<math::affineX>** tempMemory, int rootIndex, math::float4 &rootRotation, TransformAccessReadOnly rootTransformAccess) const
{
    // No skeleton pose can be created.
    if (m_AvatarDataSet.m_AvatarOutput->m_SkeletonPoseOutputAffine == NULL)
    {
        *tempMemory = NULL;
        return NULL;
    }

    const mecanim::animation::AvatarConstant* avatarConstant = m_AvatarDataSet.m_AvatarConstant;
    Assert(avatarConstant != NULL);

    // default fastpath when object is being animated
    if (m_AvatarDataSet.m_AvatarMemory->m_SkeletonPoseOutputReady)
    {
        mecanim::skeleton::SkeletonPoseT<math::affineX>* outputPose = m_AvatarDataSet.m_AvatarOutput->m_SkeletonPoseOutputAffine;
        rootRotation = mecanim::skeleton::SkeletonGetGlobalRotation(avatarConstant->m_AvatarSkeleton.Get(), m_AvatarDataSet.m_AvatarOutput->m_SkeletonPoseOutput, rootIndex);
        *tempMemory = NULL;

        return outputPose;
    }
    // If the skeleton pose is not ready, grab it from the default pose instead.
    // This happens if we have not yet sampled the positions (eg. there is no controller or we are in edit mode)
    else
    {
        mecanim::memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);

        mecanim::skeleton::SkeletonPoseT<math::trsX>* allocatedPoseTRS = mecanim::skeleton::CreateSkeletonPose<math::trsX>(avatarConstant->m_AvatarSkeleton.Get(), tempAllocator);
        mecanim::skeleton::SkeletonPoseT<math::affineX>* allocatedPoseAffine = mecanim::skeleton::CreateSkeletonPose<math::affineX>(avatarConstant->m_AvatarSkeleton.Get(), tempAllocator);

        mecanim::skeleton::SkeletonPoseCopy(avatarConstant->m_DefaultPose.Get(), allocatedPoseTRS);
        GlobalXToTRS(rootTransformAccess, allocatedPoseTRS->m_X[0]);
        mecanim::skeleton::SkeletonPoseCopy(allocatedPoseTRS, allocatedPoseAffine);
        mecanim::skeleton::SkeletonPoseComputeGlobal(avatarConstant->m_AvatarSkeleton.Get(), allocatedPoseAffine, allocatedPoseAffine);
        rootRotation = mecanim::skeleton::SkeletonGetGlobalRotation(avatarConstant->m_AvatarSkeleton.Get(), allocatedPoseTRS, rootIndex);
        mecanim::skeleton::DestroySkeletonPose(allocatedPoseTRS, tempAllocator);

        *tempMemory = allocatedPoseAffine;
        return allocatedPoseAffine;
    }
}

// Example of how velocity and angular velocity can be used with rigid body
//void OnAnimatorMove()
//{
//      Vector3 velocityDiff = animator.velocity - rigidBody.velocity;
//      velocityDiff.y *= 1.0f - animator.gravityWeight;
//      Vector3 angularVelocityDiff = animator.angularVelocity - rigidBody.angularVelocity;
//
//      rigidBody.AddForce (velocityDiff, ForceMode.VelocityChange);
//      rigidBody.AddTorque (angularVelocityDiff, ForceMode.VelocityChange);
//}

void Animator::ApplyOnAnimatorMove(AnimatorJob& job)
{
    PROFILER_AUTO(gAnimatorApplyOnAnimatorMove, this);

    ScopedAnimatorPass scopedAnimatorPass(m_AnimatorActivePasses, kOnAnimatorMove);
    Transform& avatarTransform = GetComponent<Transform>();

    if (!IsPlayingBack())
    {
        bool messageSent = false;
        if (SupportsOnAnimatorMove())
        {
            messageSent = true;
            SendMessage(kAnimatorMove);
        }

        // Suppress immediate destruction during the callback to disallow
        // the object killing itself directly or indirectly in there (would do bad
        // things to the still updating animator).
        {
            AutoExecutionRestriction restriction(kDisableImmediateDestruction);
            messageSent |= FireBehaviours(mecanim::statemachine::kOnStateMove, job);
        }


        if (!IsInitialized())
            return;

        bool canApplyMotionX = m_PlayableConstant.applyMotionX && ((m_AvatarDataSet.m_AvatarOutput->m_MotionOutput && m_BindingsDataSet.m_GenericBindingConstant->controllerBindingConstant->m_AnimationSet->m_HasRootMotionCurves) || m_PlayableConstant.isHuman);

        // in ApplyMotionX, we apply even if m_ApplyRootMotion is false.
        if (canApplyMotionX)
        {
            avatarTransform.SetLocalPosition(float3ToVector3f(m_AvatarDataSet.m_AvatarOutput->m_MotionOutput->m_MotionX.t));
            avatarTransform.SetLocalRotation(float4ToQuaternionf(m_AvatarDataSet.m_AvatarOutput->m_MotionOutput->m_MotionX.q));
            SetGenericRootTransformPropertyValues(*m_BindingsDataSet.m_GenericBindingConstant, *m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesOutput, avatarTransform, true, GetUpdateMode() == kAnimatePhysics); // scale only
        }
        else
        {
            if (!messageSent)
            {
                if (m_ApplyRootMotion)
                {
                    ApplyBuiltinRootMotion();
                }
            }
        }

        if (!IsInitialized())
            return;

        if (!canApplyMotionX  && HasGenericRootTransformPropertyValues(*m_BindingsDataSet.m_GenericBindingConstant, m_ApplyRootMotion))
        {
            SetGenericRootTransformPropertyValues(*m_BindingsDataSet.m_GenericBindingConstant, *m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesOutput, avatarTransform, m_ApplyRootMotion, GetUpdateMode() == kAnimatePhysics);
        }
    }
    else
    {
        if (m_ApplyRootMotion)
        {
            if (TRSToGlobalTR(job.m_RootTransformAccess, job.m_Animator->m_AvatarDataSet.m_AvatarMemory->m_AvatarX))
            {
                avatarTransform.SetDirtyAndQueueChanges();
            }
        }

        if (HasGenericRootTransformPropertyValues(*m_BindingsDataSet.m_GenericBindingConstant, m_ApplyRootMotion))
        {
            SetGenericRootTransformPropertyValues(*m_BindingsDataSet.m_GenericBindingConstant, *m_AvatarDataSet.m_AvatarOutput->m_DynamicValuesOutput, avatarTransform, m_ApplyRootMotion, GetUpdateMode() == kAnimatePhysics);
        }
    }
}

void Animator::ApplyBuiltinRootMotion()
{
    VALIDATE_ROOT_MOTION_VOID()
    PROFILER_AUTO(gAnimatorApplyBuiltinRootMotion, this);

    if (!IsInitialized())
        return;

    // Builtin move (For example rigidbodies & Character Controllers)
    RootMotionData motionData;
    motionData.deltaPosition = GetDeltaPosition();
    motionData.targetRotation = float4ToQuaternionf(m_AvatarDataSet.m_AvatarMemory->m_AvatarX.q);
    motionData.gravityWeight = GetGravityWeight();
    motionData.didApply = false;
    SendMessage(kAnimatorMoveBuiltin, &motionData);

    // Fallback to just moving the transform
    if (!motionData.didApply)
    {
        if (m_Velocity != Vector3f::zero || m_AngularVelocity != Vector3f::zero)
        {
            ANIMATOR_PROFILER_AUTO_DETAIL(gAnimatorApplyRootPositionAndRotation, this);

            if (TRSToGlobalTR(GetRootTransformAccess(), m_AvatarDataSet.m_AvatarMemory->m_AvatarX))
            {
                GetComponent<Transform>().SetDirtyAndQueueChanges();
            }
        }
    }
}

void Animator::SetupAnimationClipsCache()
{
    for (BoundPlayables::iterator it = m_BoundPlayables.begin(); it != m_BoundPlayables.end(); ++it)
    {
        AnimationPlayable* animationPlayable = it->GetAnimationPlayable();
        if (animationPlayable)
            animationPlayable->GetAnimationClips(m_CachedAnimationClips);
    }

#if UNITY_EDITOR
    for (AnimationClips::iterator clipIterator = m_CachedAnimationClips.begin(); clipIterator != m_CachedAnimationClips.end(); ++clipIterator)
    {
        (*clipIterator)->BuildMecanimDataMainThread();
    }
#endif
}

void Animator::SetupPlayableConstant()
{
    if (m_BindingsDataSet.m_GenericBindingConstant  != 0)
    {
        m_PlayableConstant.values = m_BindingsDataSet.m_GenericBindingConstant->controllerBindingConstant->m_DynamicValuesConstant;
        m_PlayableConstant.defaultValues = m_BindingsDataSet.m_GenericBindingConstant->controllerBindingConstant->m_DynamicValuesDefault;
        m_PlayableConstant.avatarConstant = m_AvatarDataSet.m_AvatarConstant;
        m_PlayableConstant.genericBindingsSize = m_BindingsDataSet.m_AnimationSetBindings->genericBindingsSize;
        m_PlayableConstant.genericBindings = m_BindingsDataSet.m_AnimationSetBindings->genericBindings;

        m_PlayableConstant.tqsMap = m_BindingsDataSet.m_GenericBindingConstant->controllerBindingConstant->m_SkeletonTQSMap;
        m_PlayableConstant.controllerBindingConstant = m_BindingsDataSet.m_GenericBindingConstant->controllerBindingConstant;
        m_PlayableConstant.clipArray = m_BindingsDataSet.m_AnimationSetBindings->animationSet->m_ClipConstant;
        m_PlayableConstant.clipCount = m_BindingsDataSet.m_AnimationSetBindings->animationSet->m_ClipCount;
        m_PlayableConstant.gravityWeightIndex = m_BindingsDataSet.m_AnimationSetBindings->animationSet->m_GravityWeightIndex;
        m_PlayableConstant.integerRemapStride = m_BindingsDataSet.m_AnimationSetBindings->animationSet->m_IntegerRemapStride;
        m_PlayableConstant.rootPositionValueIndex = m_BindingsDataSet.m_GenericBindingConstant->rootPositionValueIndex;
        m_PlayableConstant.rootRotationValueIndex = m_BindingsDataSet.m_GenericBindingConstant->rootRotationValueIndex;
        m_PlayableConstant.rootScaleValueIndex = m_BindingsDataSet.m_GenericBindingConstant->rootScaleValueIndex;
        m_PlayableConstant.hasRootTransformValues = m_PlayableConstant.rootPositionValueIndex != -1 || m_PlayableConstant.rootRotationValueIndex != -1 || m_PlayableConstant.rootScaleValueIndex != -1;
        m_PlayableConstant.allowConstantCurveOptimization = m_BindingsDataSet.m_GenericBindingConstant->allowConstantClipSamplingOptimization;
        m_PlayableConstant.hasRootMotion = !m_PlayableConstant.avatarConstant->isHuman() && m_AvatarDataSet.m_AvatarOutput->m_MotionOutput != NULL;
        m_PlayableConstant.isHuman = m_PlayableConstant.avatarConstant->isHuman();

        m_PlayableConstant.affectMassCenter = m_AvatarDataSet.m_AvatarInput->m_LayersAffectMassCenter;

        m_PlayableConstant.applyMotionX = true;
        for (BoundPlayables::iterator it = m_BoundPlayables.begin(); it != m_BoundPlayables.end(); ++it)
        {
            if (it->GetPlayableOutput()->GetOutputWeight() > 0)
            {
                AnimationPlayable* animationPlayable = it->GetAnimationPlayable();
                if (animationPlayable)
                    m_PlayableConstant.applyMotionX &= animationPlayable->GetApplyMotionX();
            }
        }


        m_PlayableConstant.player = this;
    }
    else
    {
        m_PlayableConstant.Clear();
    }
}

void Animator::PrepareAnimationEvents(AnimatorJob &job)
{
    if (m_AnimatorActivePasses & kFiringEvents)
        return;

    for (WeightedPlayables::iterator it = job.m_Playables.begin(); it != job.m_Playables.end(); ++it)
    {
        if (it->IsValid())
            static_cast<AnimationPlayable*>(it->GetPlayable())->PrepareAnimationEvents(1.0f, job.m_TempEventInfos);
    }
}

void Animator::FireAnimationEvents(AnimatorJob &job)
{
    if (m_AnimatorActivePasses & kFiringEvents)
        return;

    ScopedAnimatorPass scopedAnimatorPass(m_AnimatorActivePasses, kFiringEvents);


    if (m_FireEvents)
    {
        PROFILER_AUTO(gAnimatorFireAnimationEvents, this);

        for (AnimationClipEventInfos::iterator it = job.m_TempEventInfos.begin(); it != job.m_TempEventInfos.end(); ++it)
        {
            if (IsInitialized())
                it->m_AnimationClip->FireAnimationEvents(it, *this);
        }
    }
    job.m_TempEventInfos.clear();
}

bool Animator::FireBehaviours(mecanim::statemachine::StateMachineMessage filter, AnimatorJob &job)
{
    bool ret = false;

    if (!m_HasStateMachineBehaviour)
        return ret;

    PROFILER_AUTO(gAnimatorFireStateMachineBehaviours, this);


    AnimatorControllerPlayables playableArrayCopy(m_ControllerPlayableCache, kMemTempAlloc);

    for (AnimatorControllerPlayables::const_iterator it = playableArrayCopy.begin(); it != playableArrayCopy.end(); ++it)
    {
        const mecanim::animation::ControllerConstant*   constant    = (*it)->GetMemory()->m_ControllerConstant;
        mecanim::animation::ControllerMemory*           memory      = (*it)->GetMemory()->m_ControllerMemory;
        mecanim::animation::ControllerWorkspace*        workspace   = (*it)->GetMemory()->m_ControllerWorkspace;
        HPlayable handle = (*it)->Handle();

        if (constant == 0)
            continue;

        const StateMachineBehaviourPlayer&  stateMachineBehaviourPlayer = (*it)->GetBehaviourPlayer();
        if (!stateMachineBehaviourPlayer.HasStateMachineBehaviour())
            continue;

        // nothing can be fired until we get a first eval with a delta time != 0
        if (memory->m_FirstEval == mecanim::statemachine::kWaitForTick)
            continue;

        mecanim::uint32_t i;

        for (i = 0; IsInitialized() && handle.IsValid() && i < constant->m_StateMachineCount; i++)
        {
            mecanim::statemachine::StateMachineOutput& stateMachineOutput = *workspace->m_StateMachineOutput[i];

            mecanim::uint32_t j;
            mecanim::statemachine::StateMachineMessage filteredMsgId;
            for (j = 0; IsInitialized() && handle.IsValid() && j < constant->m_LayerCount; j++)
            {
                if (constant->m_LayerArray[j]->m_StateMachineIndex != i)
                    continue;


                // special case for exit, we use kExitState for current state and kCurrentState for next state
                bool isExit = stateMachineOutput.m_EndTransition;

                StateInfoIndex currentStateInfo = isExit ? kExitState : kCurrentState;
                StateInfoIndex nextStateInfo = isExit ? kCurrentState : kNextState;

                // Fire behaviour only if there is something to evaluate
                filteredMsgId = FilteredMessageId(stateMachineOutput.m_CurrentStateMessage, filter);
                if (filteredMsgId != 0)
                {
                    AnimatorStateInfo stateInfo;
                    if ((*it)->GetAnimatorStateInfo(j, currentStateInfo, stateInfo))
                        ret |= stateMachineBehaviourPlayer.FireStateBehaviour(stateInfo, j, filteredMsgId);
                }

                if (!IsInitialized() || !handle.IsValid())
                    continue;

                filteredMsgId = FilteredMessageId(stateMachineOutput.m_InterruptedStateMessage, filter);
                if (filteredMsgId != 0)
                {
                    AnimatorStateInfo stateInfo;
                    if ((*it)->GetAnimatorStateInfo(j, kInterruptedState, stateInfo))
                        ret |= stateMachineBehaviourPlayer.FireStateBehaviour(stateInfo, j, filteredMsgId);
                }

                if (!IsInitialized() || !handle.IsValid())
                    continue;

                filteredMsgId = FilteredMessageId(stateMachineOutput.m_NextStateMessage, filter);
                if (filteredMsgId != 0)
                {
                    AnimatorStateInfo stateInfo;
                    if ((*it)->GetAnimatorStateInfo(j, nextStateInfo, stateInfo))
                        ret |= stateMachineBehaviourPlayer.FireStateBehaviour(stateInfo, j, filteredMsgId);
                }
            }
        }
    }

    return ret;
}

void Animator::SetPrepareStage()
{
    if (m_PlayableGraph.IsValid())
        m_PlayableGraph.GetGraph()->SetPrepareStage(GetUpdateMode() == kAnimatePhysics ? kFixedUpdateStage : kUpdateAnimationBeginStage);
}

MonoBehaviour* Animator::GetBehaviour(ScriptingClassPtr type)
{
    AnimatorControllerPlayables controllers(kMemTempAlloc);
    for (BoundPlayables::iterator it = m_BoundPlayables.begin(); it != m_BoundPlayables.end(); ++it)
    {
        AnimationPlayable* animationPlayable = it->GetAnimationPlayable();
        if (animationPlayable)
            animationPlayable->CollectAnimatorControllerPlayables(controllers);
    }

    for (AnimatorControllerPlayables::const_iterator it = controllers.begin(); it != controllers.end(); ++it)
    {
        MonoBehaviour* bhvr = (*it)->GetBehaviour(type);
        if (bhvr)
            return bhvr;
    }
    return NULL;
}

StateMachineBehaviourVector Animator::GetBehaviours(ScriptingClassPtr type)
{
    StateMachineBehaviourVector ret;
    AnimatorControllerPlayables controllers(kMemTempAlloc);

    for (BoundPlayables::iterator it = m_BoundPlayables.begin(); it != m_BoundPlayables.end(); ++it)
    {
        AnimationPlayable* animationPlayable = it->GetAnimationPlayable();
        if (animationPlayable)
            animationPlayable->CollectAnimatorControllerPlayables(controllers);
    }

    for (AnimatorControllerPlayables::const_iterator it = controllers.begin(); it != controllers.end(); ++it)
    {
        StateMachineBehaviourVector toAdd = (*it)->GetBehaviours(type);
        for (StateMachineBehaviourVector::const_iterator bhvr = toAdd.begin(); bhvr != toAdd.end(); ++bhvr)
            ret.push_back(*bhvr);
    }

    return ret;
}

void Animator::GetBehaviours(int fullPathHash, int layerIndex, StateMachineBehaviourVector& outBehaviours)
{
    if (!m_HasStateMachineBehaviour)
        return;

    StateKey stateKey(fullPathHash, layerIndex);
    for (AnimatorControllerPlayables::const_iterator it = m_ControllerPlayableCache.begin(); it != m_ControllerPlayableCache.end(); ++it)
    {
        if (!(*it)->HasStateMachineBehaviour() || !(*it)->IsInitialized())
            continue;

        StateMachineBehaviourVector const* behaviours = (*it)->GetStateMachineBehaviours();
        StateMachineBehaviourVectorDescription const* behavioursDescription = (*it)->GetStateMachineBehaviourVectorDescription();
        StateRange range = FindStateBehavioursRange(stateKey, behavioursDescription);
        for (mecanim::uint32_t i = range.GetStartIndex(); i < range.GetStopIndex(); i++)
        {
            mecanim::uint32_t behaviourIndex = behavioursDescription->m_StateMachineBehaviourIndices[i];

            if (behaviourIndex >= behaviours->size())
                continue;

            MonoBehaviour* behaviour = (*behaviours)[behaviourIndex];

            if (behaviour == NULL || behaviour->GetInstance() == SCRIPTING_NULL)
                continue;

            outBehaviours.push_back(behaviour);
        }
    }
}

AnimatorController* Animator::GetEffectiveAnimatorController()
{
    RuntimeAnimatorController* runtimeController = m_Controller;
    AnimatorControllerPlayables controllers(kMemTempAlloc);
    for (BoundPlayables::iterator it = m_BoundPlayables.begin(); it != m_BoundPlayables.end(); ++it)
    {
        AnimationPlayable* animationPlayable = it->GetAnimationPlayable();
        if (animationPlayable)
            animationPlayable->CollectAnimatorControllerPlayables(controllers);
    }

    if (controllers.size() > 0)
    {
        RuntimeAnimatorController* playableRuntimeController = controllers[0]->GetAnimatorController();
        if (playableRuntimeController)
            runtimeController = playableRuntimeController;
    }

    return dynamic_pptr_cast<AnimatorController*>(AnimatorOverrideController::GetEffectiveController(runtimeController));
}

AnimatorControllerPlayable* Animator::FindAnimatorControllerPlayable(AnimatorController* controller)
{
    AnimatorControllerPlayables controllers(kMemTempAlloc);
    for (BoundPlayables::iterator it = m_BoundPlayables.begin(); it != m_BoundPlayables.end(); ++it)
    {
        AnimationPlayable* animationPlayable = it->GetAnimationPlayable();
        if (animationPlayable)
            animationPlayable->CollectAnimatorControllerPlayables(controllers);
    }

    for (AnimatorControllerPlayables::iterator it = controllers.begin(); it != controllers.end(); ++it)
    {
        RuntimeAnimatorController* effectiveController = AnimatorOverrideController::GetEffectiveController((*it)->GetAnimatorController());
        if (effectiveController == controller)
        {
            return *it;
        }
    }

    return 0;
}

int Animator::ScriptingStringToCRC32(const ICallString& stringValue)
{
    if (stringValue.IsNull())
        return 0;
#if ENABLE_MONO
    const gunichar2* chars = (const gunichar2*)scripting_string_chars(stringValue.GetScriptingString());
    const size_t length = stringValue.Utf16CodeUnits();

    if (IsUtf16InAsciiRange(chars, length))
    {
        return mecanim::processCRC32UTF16Ascii(chars, length);
    }
    else
#endif
    {
        return mecanim::processCRC32(stringValue.ToUTF8().c_str());
    }
}

bool Animator::SupportsOnAnimatorMove()
{
    return GetGameObject().SupportsMessage(kAnimatorMove);
}

void Animator::ApplyOnAnimatorIK(int layerIndex, AnimatorJob& job)
{
    ScopedAnimatorPass scopedAnimatorPass(m_AnimatorActivePasses, kOnAnimatorIK);

    if (GetGameObject().SupportsMessage(kAnimatorIK))
        SendMessage(kAnimatorIK, layerIndex);

    // Suppress immediate destruction during the callback to disallow
    // the object killing itself directly or indirectly in there (would do bad
    // things to the still updating animator).
    {
        AutoExecutionRestriction restriction(kDisableImmediateDestruction);
        FireBehaviours(mecanim::statemachine::kOnStateIK, job);
    }
}

void Animator::Record(float deltaTime)
{
    if (HasAnimatorController() && m_RecorderMode == eRecord && GetSpeed() >= 0)
    {
        m_AvatarPlayback.RecordFrame(deltaTime * GetSpeed(), m_AvatarDataSet.m_AvatarMemory, GetControllerMemory());
    }
}

void Animator::ProcessRootMotionJob(AnimatorJob* jobData, unsigned int i)
{
    if (!jobData[i].m_Animator->IsInitialized())
        return;

    // sync avatarX before ProcessRootMotion
    GlobalXToTRS(jobData[i].m_RootTransformAccess, jobData[i].m_Animator->m_AvatarDataSet.m_AvatarMemory->m_AvatarX);
    jobData[i].m_Animator->ProcessRootMotionStep(jobData[i]);
    jobData[i].m_Animator->PrepareAnimationEvents(jobData[i]);
}

void Animator::ProcessAnimationsJob(AnimatorJob* jobData, unsigned int i)
{
    if (!jobData[i].m_Animator->IsInitialized())
        return;

    // sync avatarX before ProcessAnimation
    GlobalXToTRS(jobData[i].m_RootTransformAccess, jobData[i].m_Animator->m_AvatarDataSet.m_AvatarMemory->m_AvatarX);
    jobData[i].m_Animator->ProcessAnimationsStep(jobData[i]);
}

void Animator::RetargeterJob(AnimatorJob* jobData, unsigned int i)
{
    if (!jobData[i].m_Animator->IsInitialized())
        return;
    jobData[i].m_Animator->RetargetStep();
}

void Animator::IKJob(AnimatorJob* jobData, unsigned int i)
{
    if (!jobData[i].m_Animator->IsInitialized())
        return;
    // sync avatarX before IKStep
    GlobalXToTRS(jobData[i].m_RootTransformAccess, jobData[i].m_Animator->m_AvatarDataSet.m_AvatarMemory->m_AvatarX);
    jobData[i].m_Animator->IKStep();
}

void Animator::WriteJob(AnimatorJob* jobData, unsigned int i)
{
    if (!jobData[i].m_Animator->IsInitialized())
        return;

    jobData[i].m_Animator->WriteStep(jobData[i].m_SystemMask);
}

void Animator::WriteJobs(AnimatorJobs* jobsData, unsigned int i)
{
    int32_t jobsCount = jobsData[i].size();

    for (int32_t jobsIter = 0; jobsIter < jobsCount; jobsIter++)
    {
        WriteJob(jobsData[i].data(), jobsIter);
    }
}

void Animator::UpdateWithDelta(float deltaTime)
{
    if (!IsActive())
    {
        WarningStringIfLoggingActive("Can't call Animator.Update on inactive object");
        return;
    }

    Prepare();

    if (m_ControllerPlayable && m_PlayableGraph.IsValid())
    {
        m_PlayableGraph.GetGraph()->BumpFrameID();
        m_PlayableGraph.GetGraph()->PrepareFrame(kEvaluatePrepare, deltaTime, 0, 0, kMainThread);
        m_PlayableGraph.GetGraph()->BumpFrameID(); // to force re-evaluation after.

        if (m_ControllerPlayable) //  can be disabled during PrepareFrame.
        {
            m_ControllerPlayable->ClearFirstEvaluationFlag();
            PlayableOutputArray jobs(kMemTempAlloc);
            jobs.push_back(m_PlayableOutput.GetOutput());
            UpdateAvatars(jobs, true, true, true);
        }
    }
}

void Animator::EvaluateController(float deltaTime)
{
    if (m_ControllerPlayable && m_ControllerPlayable->IsInitialized())
    {
        bool deltaTimeIs0 = deltaTime == 0;
        if (m_ControllerPlayable->GetMemory()->m_ControllerMemory->m_FirstEval == mecanim::statemachine::kWaitForTick && (!deltaTimeIs0 || !GetEnabled()))
            m_ControllerPlayable->GetMemory()->m_ControllerMemory->m_FirstEval = mecanim::statemachine::kFirstEval;

        m_ControllerPlayable->UpdateGraph(deltaTime);
    }
}

bool Animator::IsInitialized() const
{
    return IsAvatarInitialized() && m_BindingsDataSet.m_GenericBindingConstant != 0;
}

void Animator::SetLayersAffectMassCenter(bool value)
{
    if (!IsAvatarInitialized())
        return;

    m_AvatarDataSet.m_AvatarInput->m_LayersAffectMassCenter = value;
}

bool Animator::GetLayersAffectMassCenter() const
{
    if (!IsAvatarInitialized())
        return false;

    return m_AvatarDataSet.m_AvatarInput->m_LayersAffectMassCenter;
}

RuntimeAnimatorController* Animator::GetRuntimeAnimatorController() const
{
    return m_Controller;
}

void Animator::SetRuntimeAnimatorController(RuntimeAnimatorController* controller)
{
    if (m_Controller != PPtr<RuntimeAnimatorController>(controller))
    {
        AnimatorOverrideController* overrideController = dynamic_pptr_cast<AnimatorOverrideController*>(controller);

        bool fullRebind = true;
        if (overrideController != 0)
        {
            if (overrideController->GetAsset() == NULL)
            {
                ErrorStringMsg("Could not set Runtime Animator Controller. The controller %s is an AnimatorOverrideController with no AnimatorController to override.", overrideController->GetName());
                return;
            }
            RuntimeAnimatorController* newController = AnimatorOverrideController::GetEffectiveController(controller);
            RuntimeAnimatorController* oldController = AnimatorOverrideController::GetEffectiveController(m_Controller);
            fullRebind = newController != oldController || m_AvatarDataSet.m_AvatarConstant == NULL || m_ControllerPlayable == NULL;
        }

        m_Controller = controller;

        if (fullRebind)
        {
            Rebind(true);
        }
        else
        {
            // Always reset dependancy list when changing controller
            // to avoid having a unused controller sending msg that reset the animator
            // for a full rebind, Rebind() function is taking care of this but for the this case
            // the old controller was still in the dependancy list
            WriteDefaultValuesNoDirty();
            m_AnimatorControllerNode.Clear();
            overrideController->AddObjectUser(m_AnimatorControllerNode);

            m_ControllerPlayable->SetOverrideController(overrideController);

            // SetOverrideController already generate graph
            UpdateOverrideControllerBindings();
        }

        SetDirty();
    }
}

bool Animator::HasBoundPlayables() const
{
    return m_BoundPlayables.size() > 0;
}

void Animator::UpdateOverrideControllerBindings()
{
    for (AnimatorControllerPlayables::iterator it = m_ControllerPlayableCache.begin(); it != m_ControllerPlayableCache.end(); ++it)
    {
        (*it)->OverrideClipPlayables();
    }

    ClearBindings();
    CreateBindings();

    for (AnimatorControllerPlayables::iterator it = m_ControllerPlayableCache.begin(); it != m_ControllerPlayableCache.end(); ++it)
    {
        (*it)->UpdateInternalStateRecursive<AnimationPlayable::kAllocateBindings, false>(&m_PlayableConstant);
        (*it)->PreProcessAnimation(&m_PlayableConstant, NULL);
    }
}

AnimatorController* Animator::GetAnimatorController() const
{
    return dynamic_pptr_cast<AnimatorController*>(m_Controller);
}

AnimatorOverrideController* Animator::GetAnimatorOverrideController() const
{
    return dynamic_pptr_cast<AnimatorOverrideController*>(m_Controller);
}

Avatar* Animator::GetAvatar()
{
    return m_Avatar;
}

void Animator::SetAvatar(Avatar* avatar)
{
    if (m_Avatar != PPtr<Avatar>(avatar))
    {
        m_Avatar = avatar;

        Rebind(true);
        SetDirty();
    }
}

void Animator::InitializeAvatar()
{
    mecanim::animation::AvatarConstant* avatarConstant = NULL;
    if (m_Avatar.IsValid())
    {
        avatarConstant = m_Avatar->GetAsset();
        m_Avatar->AddObjectUser(m_AnimatorAvatarNode);
    }

    SetupAvatarDataSet(avatarConstant, m_AvatarDataSet, false);
}

const mecanim::animation::AvatarConstant* Animator::GetAvatarConstant()
{
    if (!IsAvatarInitialized())
    {
        InitializeAvatar();
    }
    return m_AvatarDataSet.m_AvatarConstant;
}

void Animator::SetCullingMode(CullingMode mode)
{
    if (m_CullingMode == mode)
        return;

    m_CullingMode = mode;

    OnCullingModeChanged();
}

void Animator::OnCullingModeChanged()
{
    InitializeVisibilityCulling();
    SyncPlayStateToCulling();
}

void Animator::SetVisibleRenderers(bool visible)
{
    Assert(m_CullingMode != kCullNone);

    bool becameVisible = visible && !m_Visible;
    m_Visible = visible;

    if (!IsWorldPlaying() || !IsAddedToManager()) // we dont care of culling in Editor mode.
        return;

    // Perform Retarget & IK step during culling to ensure the animator
    // will be rendered correctly in the same frame.
    if (becameVisible)
    {
        float deltaTime = GetDeltaTime();
        if (!m_PlayableGraph.IsValid() || deltaTime == 0)
            return;

        if (Prepare())
        {
            bool doFK = m_CullingMode == kCullAll || m_AvatarDataSet.m_AvatarMemory->m_FirstEval;
            m_AvatarDataSet.m_AvatarMemory->m_FirstEval = 1;
            m_AvatarDataSet.m_AvatarMemory->m_SkeletonPoseOutputReady = 0;
            {
                if (m_PlayableGraph.IsValid() && m_ControllerPlayable != NULL)
                {
                    PlayableOutputArray jobs(kMemTempAlloc);
                    jobs.push_back(m_PlayableOutput.GetOutput());
                    UpdateAvatars(jobs, doFK, true, true);
                }
            }
        }
    }

    SyncPlayStateToCulling();
}

void Animator::SyncPlayStateToCulling()
{
    const bool paused = (!m_Visible && m_CullingMode == kCullAll);
    for (BoundPlayables::iterator it = m_BoundPlayables.begin(); it != m_BoundPlayables.end(); ++it)
    {
        if (paused)
            it->GetPlayable()->Pause();
        else
            it->GetPlayable()->Play();
    }
}

#ifdef UNITY_EDITOR
void Animator::RebindOnDomainReload()
{
    dynamic_array<Animator*> animators(kMemTempAlloc);
    Object::FindObjectsOfType(animators);
    for (size_t i = 0; i < animators.size(); ++i)
    {
        ScopedAnimatorPass disallowWriting(animators[i]->m_AnimatorActivePasses, kWritingDisallowed);
        animators[i]->Rebind(false);
    }
}

#endif
void Animator::AnimatorVisibilityCallback(void* userData, void* renderer, int visibilityEvent)
{
    Animator& animator = *reinterpret_cast<Animator*>(userData);

    if (visibilityEvent == kBecameVisibleEvent)
        animator.SetVisibleRenderers(true);
    else if (visibilityEvent == kBecameInvisibleEvent)
    {
        animator.SetVisibleRenderers(animator.IsAnyRendererVisible());
    }
    else if (visibilityEvent == kWillDestroyEvent)
    {
        animator.RemoveContainedRenderer(renderer);

        // Check if we are visible
        animator.SetVisibleRenderers(animator.IsAnyRendererVisible());
    }
}

void Animator::RemoveContainedRenderer(void* renderer)
{
    for (size_t i = 0; i < m_ContainedRenderers.size(); i++)
    {
        if (m_ContainedRenderers[i] == renderer)
        {
            m_ContainedRenderers[i] = m_ContainedRenderers.back();
            m_ContainedRenderers.pop_back();
            return;
        }
    }
}

bool Animator::IsAnyRendererVisible() const
{
    Assert(m_CullingMode != kCullNone);

    ContainedRenderers::const_iterator end = m_ContainedRenderers.end();
    for (ContainedRenderers::const_iterator i = m_ContainedRenderers.begin(); i != end; ++i)
    {
        const Renderer* renderer = *i;
        Assert(renderer->HasEvent(AnimatorVisibilityCallback, this));

        if (!renderer->IsInScene())
            continue;

        if (renderer->IsVisibleInScene())
            return true;
    }

    return false;
}

void Animator::ClearRelatedPropertyBlocks()
{
    ContainedRenderers::iterator end = m_RenderersToClear.end();
    for (ContainedRenderers::iterator i = m_RenderersToClear.begin(); i != end; ++i)
    {
        Renderer* renderer = *i;
        if (renderer)
            renderer->ClearCustomProperties();
    }
    m_RenderersToClear.clear();
}

void Animator::ClearContainedRenderers()
{
    ContainedRenderers::iterator end = m_ContainedRenderers.end();
    for (ContainedRenderers::iterator i = m_ContainedRenderers.begin(); i != end; ++i)
    {
        Renderer* renderer = *i;
        renderer->RemoveEvent(AnimatorVisibilityCallback, this);
    }
    m_ContainedRenderers.clear();
}

void Animator::RecomputeContainedRenderersRecurse(Transform& transform)
{
    Renderer* renderer = transform.QueryComponent<Renderer>();
    if (renderer)
    {
        m_ContainedRenderers.push_back(renderer);
        renderer->AddEvent(AnimatorVisibilityCallback, this);
    }
    Transform::iterator end = transform.end();
    for (Transform::iterator i = transform.begin(); i != end; ++i)
    {
        RecomputeContainedRenderersRecurse(**i);
    }
}

void Animator::InitializeVisibilityCulling()
{
    if (!IsActive())
        return;

    ClearContainedRenderers();

    if (m_CullingMode == kCullNone)
    {
        m_Visible = true;
    }
    else
    {
        Transform& transform = GetComponent<Transform>();
        RecomputeContainedRenderersRecurse(transform);

        m_Visible = IsAnyRendererVisible();
    }
}

void Animator::BindingsDataSet::Reset()
{
    DestroyAnimatorGenericBindings(m_GenericBindingConstant, m_Alloc);
    m_GenericBindingConstant    = 0;

    m_AnimationSetBindings.Delete();
}

void Animator::AvatarDataSet::Reset()
{
    if (m_OwnsAvatar)
    {
        mecanim::animation::DestroyAvatarConstant(const_cast<mecanim::animation::AvatarConstant*>(m_AvatarConstant), m_Alloc);
        m_OwnsAvatar = false;
    }

    mecanim::animation::DestroyAvatarInput(m_AvatarInput, m_Alloc);
    mecanim::animation::DestroyAvatarOutput(m_AvatarOutput, m_Alloc);

    if (m_AvatarMemorySize == 0 && m_AvatarMemory != 0)
        mecanim::animation::DestroyAvatarMemory(m_AvatarMemory, m_Alloc);
    else if (m_AvatarMemorySize != 0 && m_AvatarMemory != 0)
        m_Alloc.Deallocate(m_AvatarMemory);

    mecanim::animation::DestroyAvatarWorkspace(m_AvatarWorkspace, m_Alloc);

    DestroyAvatarBindingConstant(m_AvatarBindingConstant, m_Alloc);

    m_AvatarConstant = 0;
    m_AvatarInput = 0;
    m_AvatarOutput = 0;
    m_AvatarMemory = 0;
    m_AvatarWorkspace = 0;
    m_AvatarMemorySize = 0;
    m_AvatarBindingConstant = 0;
    m_OwnsAvatar = false;
    m_Initialized = false;
}

void Animator::ClearAnimatorController()
{
    ClearObject();
    ClearInternalControllerPlayable();
}

void Animator::ClearObject()
{
    VALIDATE_CAN_DISABLE_ANIMATOR();


    InvokeEvent(kAnimatorClearEvent);
    SyncFence(m_WriteGlobalPoseFence);

    m_AvatarDataSet.Reset();

    ClearBindings();

    if (!IsAddedToManager() && m_PlayableGraph.IsValid())
    {
        m_PlayableGraph.GetGraph()->Stop();
        ClearInternalControllerPlayable();
    }

    StopRecording();
    // dependencies
    m_AnimatorAvatarNode.Clear();
}

void Animator::SetupAvatarDataSet(mecanim::animation::AvatarConstant const* avatarConstant, Animator::AvatarDataSet& outMecanimDataSet, bool sampling)
{
    PROFILER_AUTO(gAnimatorSetupAvatarDataSet, this);

    outMecanimDataSet.m_AvatarConstant = avatarConstant;

    if (outMecanimDataSet.m_AvatarConstant == NULL)
    {
        if (!m_HasTransformHierarchy)
        {
            WarningStringIfLoggingActive("Object is set to Optimize Game Object but does not have an Avatar, Animation will not play.");
            return;
        }

        outMecanimDataSet.m_OwnsAvatar = true;
        outMecanimDataSet.m_AvatarConstant = mecanim::animation::CreateAvatarConstant(0, 0, 0, 0, 0, -1, math::trsIdentity(), outMecanimDataSet.m_Alloc);
    }

    // It is very important to reset the memory size to zero because we use this member to determine if the data is blobified and ready to be copy by recorder
    outMecanimDataSet.m_AvatarMemorySize = 0;
    outMecanimDataSet.m_AvatarMemory = mecanim::animation::CreateAvatarMemory(outMecanimDataSet.m_AvatarConstant, outMecanimDataSet.m_Alloc);
    outMecanimDataSet.m_AvatarInput = mecanim::animation::CreateAvatarInput(outMecanimDataSet.m_AvatarConstant, outMecanimDataSet.m_Alloc);
    outMecanimDataSet.m_AvatarWorkspace = mecanim::animation::CreateAvatarWorkspace(outMecanimDataSet.m_AvatarConstant, outMecanimDataSet.m_Alloc);
    outMecanimDataSet.m_AvatarOutput = mecanim::animation::CreateAvatarOutput(outMecanimDataSet.m_AvatarConstant, sampling || m_HasTransformHierarchy, m_ApplyRootMotion || SupportsOnAnimatorMove(), outMecanimDataSet.m_Alloc);

    Transform *effectiveRoot = GetAvatarRoot();
    if (m_HasTransformHierarchy)
        outMecanimDataSet.m_AvatarBindingConstant = CreateAvatarBindingConstant(*effectiveRoot, outMecanimDataSet.m_AvatarConstant, outMecanimDataSet.m_Alloc);
    else
        outMecanimDataSet.m_AvatarBindingConstant = CreateAvatarBindingConstantOpt(*effectiveRoot, outMecanimDataSet.m_AvatarConstant, outMecanimDataSet.m_Alloc);

    outMecanimDataSet.m_Initialized = true;

    // Setup AvatarX based on current transform
    GlobalXToTRS(GetRootTransformAccess(), outMecanimDataSet.m_AvatarMemory->m_AvatarX);
}

void Animator::SetupBindingsDataSet(AnimationSetBindingsPtr animationSetBindings, Animator::BindingsDataSet& bindings, Animator::AvatarDataSet& avatar)
{
    PROFILER_AUTO(gAnimatorSetupControllerDataSet, this);

    bindings.m_AnimationSetBindings = animationSetBindings;

    Transform *effectiveRoot = GetAvatarRoot();
    if (m_HasTransformHierarchy)
        bindings.m_GenericBindingConstant = CreateAnimatorGenericBindings(*animationSetBindings, *effectiveRoot, avatar.m_AvatarConstant, m_AllowConstantClipSamplingOptimization, bindings.m_Alloc, *this);
    else
        bindings.m_GenericBindingConstant = CreateAnimatorGenericBindingsOpt(*animationSetBindings, *effectiveRoot, avatar.m_AvatarConstant, avatar.m_AvatarBindingConstant, m_AllowConstantClipSamplingOptimization, bindings.m_Alloc, *this);

    const mecanim::ValueArrayConstant* dynamicValuesConstant = bindings.m_GenericBindingConstant->controllerBindingConstant->m_DynamicValuesConstant;
    bool hasRootMotion = m_ApplyRootMotion || !avatar.m_AvatarConstant->m_Human.IsNull() || avatar.m_AvatarConstant->m_RootMotionBoneIndex != -1 || bindings.m_AnimationSetBindings->animationSet->m_HasRootMotionCurves;
    AllocateAvatarOuputForBindings(avatar.m_AvatarOutput, hasRootMotion, dynamicValuesConstant, bindings.m_Alloc);

    mecanim::ValueArrayCopy<false>(bindings.m_GenericBindingConstant->controllerBindingConstant->m_DynamicValuesDefault, avatar.m_AvatarOutput->m_DynamicValuesOutput);
}

void Animator::CollectAnimatedRenderers(Animator::BindingsDataSet const& dataSet)
{
    if (m_BindingsDataSet.m_GenericBindingConstant == NULL)
        return;

    Renderer* lastAddedRenderer = NULL;
    int genericBindingsCount = dataSet.m_GenericBindingConstant->genericBindingsCount;
    for (int i = 0; i < genericBindingsCount; i++)
    {
        if (dataSet.m_GenericBindingConstant->genericBindings[i].targetType == kRendererMaterialPropertyBinding)
        {
            Renderer* animatedRenderer = static_cast<Renderer*>(dataSet.m_GenericBindingConstant->genericBindings[i].targetObject);
            if (lastAddedRenderer != animatedRenderer)
            {
                lastAddedRenderer = animatedRenderer;
                m_RenderersToClear.push_back(animatedRenderer);
            }
        }
    }
}

void Animator::CreateBindings()
{
    RuntimeAnimatorController* controller = GetRuntimeAnimatorController();

    SetupAnimationClipsCache();

    AnimationSetBindingsPtr animationSetBindingsPtr;

    if (!m_Controller.IsNull() && m_BoundPlayables.size() == 1) // fast path
    {
        if (controller == 0)
            return;

        // Convert from SharedAnimationSetBindingsPtr to AnimationSetBindingsPtr
        animationSetBindingsPtr = AnimationSetBindingsPtr(controller->GetAnimationSetBindings());
    }
    else
    {
        const AnimationClips& clips = GetAnimationClips();
        animationSetBindingsPtr = AnimationSetBindingsPtr(CreateAnimationSetBindings(clips, m_HeapAlloc), AnimationSetBindingsPtr::deleter_t(m_HeapAlloc.GetMemoryLabel(), UnityEngine::Animation::DestroyAnimationSetBindings));
        for (BoundPlayables::iterator it = m_BoundPlayables.begin(); it != m_BoundPlayables.end(); ++it)
        {
            AnimationPlayable* animationPlayable = it->GetAnimationPlayable();
            if (animationPlayable)
                animationPlayable->AddObjectUser(m_PlayableNodes);
        }
        for (unsigned i = 0; i < clips.size(); i++)
            if (clips[i])
                clips[i]->GetUserList().AddUser(m_PlayableNodes);
    }

    if (animationSetBindingsPtr.IsNull())
        return;

    m_BindingsDataSet.Reset();
    DeallocateAvatarOuputForBindings(m_AvatarDataSet.m_AvatarOutput, m_BindingsDataSet.m_Alloc);
    SetupBindingsDataSet(animationSetBindingsPtr, m_BindingsDataSet, m_AvatarDataSet);

    SetupPlayableConstant();
}

void Animator::CreatePlayableGraph()
{
    if (!m_PlayableGraph.IsValid())
    {
        PlayableGraph* graph = GetDirectorManager().ConstructPlayableGraph();
        m_PlayableGraph = graph->Handle();

        AnimationPlayableOutput* output = graph->CreateOutput<AnimationPlayableOutput>("AnimatorOuput", m_PlayableOutput);
        output->SetTargetAnimator(this);
        AnimationPlayable* playable = m_ControllerPlayable;
        if (playable != NULL)
            output->SetSourcePlayable(playable);

        graph->SetTimeUpdateMode(GetTimeUpdateMode());
        SetPrepareStage();
    }
}

void Animator::CreateInternalControllerPlayable()
{
    RuntimeAnimatorController* controller = GetRuntimeAnimatorController();

    if (controller != 0)
    {
        if (m_ControllerPlayable == NULL)
        {
            m_ControllerPlayable = m_PlayableGraph.GetGraph()->ConstructPlayable<AnimatorControllerPlayable>(kAnimation);
            m_ControllerPlayable->SetAnimatorController(controller);
            m_PlayableOutput.GetOutput()->SetSourcePlayable(m_ControllerPlayable);

            controller->AddObjectUser(m_AnimatorControllerNode);
        }


        if (IsAddedToManager())
        {
            m_PlayableGraph.GetGraph()->Play();
        }
    }
}

void Animator::ClearInternalControllerPlayable()
{
    if (m_ControllerPlayable)
    {
        if (m_PlayableGraph.IsValid())
        {
            m_PlayableGraph.GetGraph()->SchedulePlayableDestruction(m_ControllerPlayable->Handle());
            m_PlayableOutput.GetOutput()->SetSourcePlayable(NULL); // unbind now, so its removed from BoundPlayables
        }
        m_ControllerPlayable = NULL;

        m_AnimatorControllerNode.Clear();
    }
}

void Animator::CreatePlayableMemory()
{
    SetupPlayableConstant();
    for (BoundPlayables::iterator it = m_BoundPlayables.begin(); it != m_BoundPlayables.end(); ++it)
    {
        AnimationPlayable* animationPlayable = it->GetAnimationPlayable();
        if (animationPlayable)
        {
            animationPlayable->UpdateInternalStateRecursive<AnimationPlayable::kReallocateBindings, false>(&m_PlayableConstant);

            animationPlayable->PreProcessAnimation(&m_PlayableConstant, 0);
        }
    }

    m_HasStateMachineBehaviour = false;
    for (AnimatorControllerPlayables::iterator it = m_ControllerPlayableCache.begin(); it != m_ControllerPlayableCache.end(); ++it)
        m_HasStateMachineBehaviour |=   (*it)->HasStateMachineBehaviours();
}

void Animator::ClearBindings()
{
    m_CachedAnimationClips.clear();
    m_BindingsDataSet.Reset();

    if (m_ControllerPlayable)
    {
        m_ControllerPlayable->UpdateInternalStateRecursive<AnimationPlayable::kDeallocateBindings, false>(&m_PlayableConstant);
    }

    m_PlayableNodes.Clear();
}

void Animator::CreateObject()
{
    VALIDATE_CAN_DISABLE_ANIMATOR();

    if (!IsActive())
        return;
#if UNITY_EDITOR
    ClearWarning();
#endif
    SETPROFILERLABEL(Animator);
    PROFILER_AUTO(gAnimatorInitialize, this);

    ClearObject();

    InitializeAvatar();

    if (m_AvatarDataSet.m_AvatarConstant == NULL)
        return;

    CreatePlayableGraph();
    CreateInternalControllerPlayable();
    CreateBindings();
    CreatePlayableMemory();
    CollectAnimatedRenderers(m_BindingsDataSet);
}

AnimationClipStats Animator::GetClipStats() const
{
    AnimationClipStats stats;
    stats.Reset();

    if (!IsInitialized())
        return stats;

    AnimationClips const& allClips = GetAnimationClips();
    for (int clipIter = 0; clipIter < allClips.size(); clipIter++)
    {
        AnimationClipStats clipStats;
        allClips[clipIter]->GetStats(clipStats);
        stats.Combine(clipStats);
    }

    return stats;
}

core::string Animator::GetStats()
{
    AnimationClipStats stats = GetClipStats();

    core::string info;
    float constantRatio = stats.totalCurves > 0 ? float(stats.constantCurves) / float(stats.totalCurves) * 100.0f : 0.0f;
    float denseRatio = stats.totalCurves > 0 ? float(stats.denseCurves) / float(stats.totalCurves) * 100.0f : 0.0f;
    float streamRatio = stats.totalCurves > 0 ? float(stats.streamCurves) / float(stats.totalCurves) * 100.0f : 0.0f;

    AnimationClips const& allClips = GetAnimationClips();
    info += Format("Clip Count: %d\n", (int)allClips.size());
    info += Format("Curves Pos: %d Quat: %d Euler: %d Scale: %d Muscles: %d Generic: %d PPtr: %d\n", stats.positionCurves, stats.quaternionCurves, stats.eulerCurves, stats.scaleCurves, stats.muscleCurves, stats.genericCurves, stats.pptrCurves);
    info += Format("Curves Count: %d Constant: %d (%.1f%%) Dense: %d (%.1f%%) Stream: %d (%.1f%%)\n", stats.totalCurves, stats.constantCurves, constantRatio, stats.denseCurves, denseRatio, stats.streamCurves, streamRatio);
    return info;
}

core::string Animator::GetPerformanceHints()
{
    if (m_BindingsDataSet.m_GenericBindingConstant == NULL)
        return "Not initialized";

    core::string info;
    ///@TODO: more accuaracy...

    //  if (!m_BindingsDataSet.m_GenericBindingConstant->allowConstantClipSamplingOptimization)
    //      info += "Constant curve optimization disabled (Instance default values differ from constant curve values)\n";
    //  else
    //      info += Format ("Constant curve optimization enabled. %d of %d were eliminated.\n", m_BindingsDataSet.m_GenericBindingConstant->controllerBindingConstant->m_AnimationSet->m_DynamicReducedValuesConstant->m_Count, GetAnimationSet()->m_DynamicFullValuesConstant->m_Count);

    //@TODO: Bound curves overview like animationclip stats...

    info += "Instance memory: ";
    info += FormatBytes(GetRuntimeMemorySize()).c_str();

    return info;
}

void Animator::PrepareForPlayback()
{
    if (!HasAnimatorController())
        return;

    if (m_AvatarDataSet.m_AvatarMemory && m_AvatarDataSet.m_AvatarMemorySize == 0)
    {
        /// Blobify memory to be able to use inplace allocator during playback
        mecanim::animation::AvatarMemory *mem = m_AvatarDataSet.m_AvatarMemory;
        m_AvatarDataSet.m_AvatarMemory = CopyBlob(*mem, m_HeapAlloc, m_AvatarDataSet.m_AvatarMemorySize);
        mecanim::animation::DestroyAvatarMemory(mem, m_HeapAlloc);
    }

    m_ControllerPlayable->PrepareForPlayback(m_HeapAlloc);
}

void Animator::StartRecording(int frameCount)
{
    if (!IsAvatarInitialized())
    {
        WarningStringIfLoggingActive("Can't call StartRecording on inactive object");
        return;
    }

    PrepareForPlayback();

    if (m_RecorderMode == ePlayback)
    {
        WarningStringIfLoggingActive("Can't call StartRecording while in playback mode. You must call StopPlayback.");
        return;
    }

    m_AvatarPlayback.Init(frameCount);
    m_RecorderMode = eRecord;
}

void Animator::StopRecording()
{
    m_RecorderMode = eOffline;
}

float Animator::GetRecorderStartTime()
{
    return m_AvatarPlayback.StartTime();
}

float Animator::GetRecorderStopTime()
{
    return m_AvatarPlayback.StopTime();
}

void Animator::StartPlayback()
{
    if (m_RecorderMode == eRecord)
    {
        WarningStringIfLoggingActive("Can't call StartPlayback while in record mode. You must call StopRecording.");
        return;
    }

    m_RecorderMode = ePlayback;

    mecanim::animation::ControllerMemory* controllerMemory = GetControllerMemory();
    if (controllerMemory)
        controllerMemory->m_InPlayback = true;
}

void Animator::SetPlaybackTimeInternal(float time)
{
    mecanim::animation::AvatarMemory*  avatarMemory = 0;
    mecanim::animation::ControllerMemory* controllerMemory = 0;

    float effectiveTime = m_AvatarPlayback.PlayFrame(time, avatarMemory, controllerMemory);

    if (avatarMemory != 0)
    {
        if (effectiveTime > time)
        {
            if (IsAutoPlayingBack())
                WarningStringIfLoggingActive("Cannot rewind Animator Recorder anymore. No more recorded data");
            else
                WarningStringIfLoggingActive("Animator Recorder does not have recorded data at given time");
        }
        else if (time > m_AvatarPlayback.StopTime())
        {
            WarningStringIfLoggingActive("Animator Recorder does not have recorded data at given time, Animator will update based on current AnimatorParameters");
        }

        PrepareForPlayback();

        m_PlaybackTime = time;
        mecanim::memory::InPlaceAllocator inPlaceAlloc(m_AvatarDataSet.m_AvatarMemory, m_AvatarDataSet.m_AvatarMemorySize);
        mecanim::animation::AvatarMemory* memoryCopy = CopyBlob(*avatarMemory, inPlaceAlloc, m_AvatarDataSet.m_AvatarMemorySize);
        if (memoryCopy != 0)
            m_AvatarDataSet.m_AvatarMemory = memoryCopy;
        else
        {
            // We don't have enough memory to fulfill the request with the current m_AvatarDataSet.m_AvatarMemory memory block
            // Let's try another time with a memory block big enough.
            mecanim::animation::DestroyAvatarMemory(m_AvatarDataSet.m_AvatarMemory, m_HeapAlloc);

            UInt8* ptr = reinterpret_cast<UInt8*>(m_HeapAlloc.Allocate(m_AvatarDataSet.m_AvatarMemorySize, ALIGN_OF(mecanim::animation::AvatarMemory)));
            mecanim::memory::InPlaceAllocator inPlaceAlloc(ptr, m_AvatarDataSet.m_AvatarMemorySize);
            m_AvatarDataSet.m_AvatarMemory = CopyBlob(*avatarMemory, inPlaceAlloc, m_AvatarDataSet.m_AvatarMemorySize);
            if (m_AvatarDataSet.m_AvatarMemory == 0)
            {
                WarningStringIfLoggingActive("Can't playback from recorder, cannot allocate memory for recorded data.");
                m_PlaybackDeltaTime = 0;
                m_PlaybackTime = 0;
                return;
            }
        }
        m_PlaybackDeltaTime = time - effectiveTime;

        m_ControllerPlayable->SetRecorderData(controllerMemory, m_HeapAlloc);
    }
    else
    {
        WarningStringIfLoggingActive("Can't playback from recorder, no recorded data found");
        m_PlaybackDeltaTime = 0;
        m_PlaybackTime = 0;
    }
}

float Animator::GetPlaybackTime()
{
    if (m_RecorderMode != ePlayback)
    {
        WarningStringIfLoggingActive("Can't call GetPlaybackTime while not in playback mode. You must call StartPlayback before.");
        return -1;
    }

    return m_PlaybackTime;
}

void Animator::SetPlaybackTime(float time)
{
    if (!IsInitialized() || m_ControllerPlayable == NULL)
        return;

    if (m_RecorderMode != ePlayback)
    {
        WarningStringIfLoggingActive("Can't call SetPlaybackTime while not in playback mode. You must call StartPlayback before.");
        return;
    }

    Prepare();

    SetPlaybackTimeInternal(time);
}

void Animator::StopPlayback()
{
    m_RecorderMode = eOffline;
    m_Speed = std::max(0.0f, m_Speed);
    mecanim::animation::ControllerMemory* controllerMemory = GetControllerMemory();
    if (controllerMemory)
        controllerMemory->m_InPlayback = false;
}

AnimatorRecorderMode Animator::GetRecorderMode() const
{
    return m_RecorderMode;
}

bool Animator::IsOptimizable() const
{
    return m_Avatar.IsValid() &&    // PPtr is valid
        m_Avatar->IsValid();        // Avatar itself is valid
}

bool Animator::IsHuman() const
{
    return m_Avatar.IsValid() && m_Avatar->IsHuman();
}

bool Animator::HasRootMotion() const
{
    return m_Avatar.IsValid() && m_Avatar->HasRootMotion();
}

bool Animator::IsRootTranslationOrRotationControllerByCurves() const
{
    return m_BindingsDataSet.m_GenericBindingConstant != 0 ?
        (m_BindingsDataSet.m_GenericBindingConstant->rootPositionValueIndex != -1 ||
         m_BindingsDataSet.m_GenericBindingConstant->rootRotationValueIndex != -1) :
        false;
}

float  Animator::GetHumanScale() const
{
    return m_Avatar.IsValid() ? m_Avatar->GetHumanScale() : 1.f;
}

void  Animator::SetApplyRootMotion(bool rootMotion)
{
    if (m_ApplyRootMotion != rootMotion)
    {
        m_ApplyRootMotion = rootMotion;
        SetDirty();
    }
}

void  Animator::SetLinearVelocityBlending(bool linearVelocityBlending)
{
    if (m_LinearVelocityBlending != linearVelocityBlending)
    {
        m_LinearVelocityBlending = linearVelocityBlending;
        SetDirty();
    }
}

void Animator::SetUpdateMode(UpdateMode updateMode)
{
    if (m_UpdateMode != updateMode)
    {
        m_UpdateMode = updateMode;
        OnUpdateModeChanged();
    }
}

void Animator::OnUpdateModeChanged()
{
    SetDirty();
    if (IsWorldPlaying() && IsAddedToManager())
    {
        m_PlayableGraph.GetGraph()->Stop();
        m_PlayableGraph.GetGraph()->SetTimeUpdateMode(GetTimeUpdateMode());
        SetPrepareStage();
        m_PlayableGraph.GetGraph()->Play();
    }
}

void Animator::SetHasTransformHierarchy(bool value)
{
    if (m_HasTransformHierarchy != value)
    {
        m_HasTransformHierarchy = value;
        ClearObject();
        SetDirty();
    }
}

void Animator::SetAllowConstantClipSamplingOptimization(bool value)
{
    if (m_AllowConstantClipSamplingOptimization != value)
    {
        m_AllowConstantClipSamplingOptimization = value;
        SetDirty();
    }
}

bool Animator::GetAllowConstantClipSamplingOptimization()
{
    return m_AllowConstantClipSamplingOptimization;
}

GetSetValueResult Animator::SetFloatDamp(int id, float value, float dampTime, float deltaTime)
{
    VALIDATE_HAS_PLAYABLE(kAnimatorControllerNotPresent);

    if (dampTime > 0)
    {
        mecanim::dynamics::ScalDamp damper;
        FOR_EACH_ANIMATORCONTROLLERPLAYABLE(GetFloat, id, damper.m_Value);
        damper.m_DampTime = dampTime;
        damper.Evaluate(value, deltaTime);
        value = damper.m_Value;
    }

    FOR_EACH_ANIMATORCONTROLLERPLAYABLE_PARAMETER_RETURN(SetFloat, id, value);
}

GetSetValueResult Animator::SetFloat(int id, float value)
{
    FOR_EACH_ANIMATORCONTROLLERPLAYABLE_PARAMETER_RETURN(SetFloat, id, value);
}

GetSetValueResult Animator::SetBool(int id, bool value)
{
    FOR_EACH_ANIMATORCONTROLLERPLAYABLE_PARAMETER_RETURN(SetBool, id, value);
}

GetSetValueResult Animator::SetInteger(int id, int value)
{
    FOR_EACH_ANIMATORCONTROLLERPLAYABLE_PARAMETER_RETURN(SetInteger, id, value);
}

GetSetValueResult Animator::GetFloat(int id, float& output, bool sampling)
{
    output = 0.0f; // initialize to default value, to keep backward compat
    if (sampling)
        Prepare();

    VALIDATE_HAS_PLAYABLE(kAnimatorControllerNotPresent);
    if (sampling)
    {
        BindingsDataSet& bindings =  m_SamplingDataSets.m_BindingsDataSet;
        const mecanim::animation::ControllerConstant* controllerConstant = m_SamplingDataSets.m_ControllerConstant;

        if (bindings.m_GenericBindingConstant == NULL)
        {
#if UNITY_EDITOR
            AnimatorController* animatorController = GetAnimatorController();
            if (animatorController)
            {
                controllerConstant = animatorController->GetAsset();
                mecanim::int32_t i = mecanim::FindValueIndex(controllerConstant->m_Values.Get(), id);
                if (i != -1)
                {
                    output = 0.0f;
                    return kGetSetSuccess;
                }
            }
#endif
            output = 0.0f;
            return kAnimatorNotInitialized;
        }

        mecanim::int32_t i = mecanim::FindValueIndex(controllerConstant->m_Values.Get(), id);

        if (i == -1)
        {
            output = 0.0f;
            return kParameterDoesNotExist;
        }

        m_SamplingDataSets.m_ControllerMemory->m_Values->ReadData(output, controllerConstant->m_Values->m_ValueArray[i].m_Index);

        return kGetSetSuccess;
    }
    else
        FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(GetFloat, kAnimatorControllerNotPresent, id, output);
}

GetSetValueResult Animator::GetBool(int id, bool& output)
{
    output = false; // initialize to default value, to keep backward compat
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(GetBool, kAnimatorControllerNotPresent, id, output);
}

GetSetValueResult Animator::GetInteger(int id, int& output)
{
    output = 0.0f; // initialize to default value, to keep backward compat
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(GetInteger, kAnimatorControllerNotPresent, id, output);
}

GetSetValueResult Animator::ResetTrigger(int id)
{
    FOR_EACH_ANIMATORCONTROLLERPLAYABLE_PARAMETER_RETURN(ResetTrigger, id);
}

GetSetValueResult Animator::SetTrigger(int id)
{
    FOR_EACH_ANIMATORCONTROLLERPLAYABLE_PARAMETER_RETURN(SetTrigger, id);
}

GetSetValueResult Animator::ParameterControlledByCurve(int id)
{
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(ParameterControlledByCurve, kAnimatorControllerNotPresent, id);
}

bool Animator::HasParameter(int id)
{
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(HasParameter, false, id);
}

int Animator::GetLayerCount() const
{
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(GetLayerCount, 0);
}

core::string    Animator::GetLayerName(int layerIndex)
{
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(GetLayerName, "", layerIndex);
}

int Animator::GetLayerIndex(const core::string& layerName)
{
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(GetLayerIndex, -1, layerName);
}

float Animator::GetLayerWeight(int layerIndex)
{
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(GetLayerWeight, -1.0f, layerIndex);
}

void Animator::SetLayerWeight(int layerIndex, float w)
{
    VALIDATE_HAS_PLAYABLE_VOID();
    FOR_EACH_ANIMATORCONTROLLERPLAYABLE(SetLayerWeight, layerIndex, w);
}

AnimatorControllerParameterVector Animator::GetParameters()
{
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(GetParameters, AnimatorControllerParameterVector());
}

bool Animator::IsInTransition(int layerIndex) const
{
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(IsInTransition, false, layerIndex);
}

bool Animator::GetAnimatorClipInfo(int layerIndex, bool currentState, dynamic_array<AnimatorClipInfo>& output)
{
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(GetAnimatorClipInfo, false, layerIndex, currentState, output);
}

int Animator::GetAnimatorClipInfoCount(int layerIndex, bool currentState)
{
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(GetAnimatorClipInfoCount, 0, layerIndex, currentState);
}

bool Animator::GetAnimatorStateInfo(int layerIndex, StateInfoIndex stateInfoIndex, AnimatorStateInfo& output) const
{
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(GetAnimatorStateInfo, false, layerIndex, stateInfoIndex, output);
}

bool Animator::GetAnimatorTransitionInfo(int layerIndex, AnimatorTransitionInfo& info) const
{
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(GetAnimatorTransitionInfo, false, layerIndex, info);
}

bool Animator::HasState(int layerIndex, int stateID) const
{
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(HasState, false, layerIndex, stateID);
}

core::string Animator::GetAnimatorStateName(int layerIndex, bool currentState)
{
    FOR_FIRST_ANIMATORCONTROLLERPLAYABLE_RETURN(GetAnimatorStateName, "", layerIndex, currentState);
}

core::string Animator::ResolveHash(int hash)
{
    VALIDATE_HAS_ANIMATOR_CONTROLLER("");
    return m_ControllerPlayable->ResolveHash(hash);
}

void Animator::GotoStateInFixedTime(int layerIndex, int stateId, float fixedTime, float fixedTransitionDuration, float normalizedTransitionTime)
{
    VALIDATE_HAS_ANIMATOR_CONTROLLER_VOID();
    FOR_EACH_ANIMATORCONTROLLERPLAYABLE(GotoStateInFixedTime, layerIndex, stateId, fixedTime, fixedTransitionDuration, normalizedTransitionTime);
}

void Animator::GotoState(int layerIndex, int stateId, float normalizedTime, float transitionDuration, float transitionTime)
{
    VALIDATE_HAS_ANIMATOR_CONTROLLER_VOID();
    FOR_EACH_ANIMATORCONTROLLERPLAYABLE(GotoState, layerIndex, stateId, normalizedTime, transitionDuration, transitionTime);
}

bool  Animator::GetMuscleValue(int id, float *value)
{
    *value = 0;
    if (this->m_Avatar.IsNull())
        return false;

    // it is the desire behavior to return true if the Animator is not initialized correctly because the AnimationWindows is using this function to
    // find what is the newly added curve type.
    // Also has a side effect adding any kind of curve like MotionT trigger a ClearObject() on the animator because we are adding new curve to a clip
    // used by the animator.
    mecanim::int32_t muscleIndex = mecanim::animation::FindMuscleIndex(id);

    // case-805254
    // Bail-out if avatar contains generic animation, but still allow access to muscle motion and muscle root curves.
    if (!this->m_Avatar->IsHuman() && muscleIndex >= mecanim::animation::s_ClipMuscleCurveRootEnd)
        return false;

    bool ret = muscleIndex != -1;

    if (m_SamplingDataSets.m_BindingsDataSet.m_GenericBindingConstant == NULL)
        return ret;

    if (ret)
        *value = mecanim::animation::GetMuscleCurveValue(*m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput, m_SamplingDataSets.m_AvatarDataSet.m_AvatarOutput->m_MotionOutput->m_MotionX, muscleIndex);

    return ret;
}

bool Animator::IsInIKPass()
{
    return (m_AnimatorActivePasses & kOnAnimatorIK) != 0;
}

Vector3f    Animator::GetAvatarPosition()
{
    if (!IsAvatarInitialized())
        return Vector3f(0, 0, 0);

    return float3ToVector3f(m_AvatarDataSet.m_AvatarMemory->m_AvatarX.t);
}

void Animator::SetAvatarPosition(const Vector3f& pos)
{
    ///@TODO: Give error messages...
    if (!IsAvatarInitialized())
        return;

    m_AvatarDataSet.m_AvatarMemory->m_AvatarX.t = Vector3fTofloat3(pos);
}

Quaternionf Animator::GetAvatarRotation()
{
    if (!IsAvatarInitialized())
        return Quaternionf(0, 0, 0, 1);

    return float4ToQuaternionf(m_AvatarDataSet.m_AvatarMemory->m_AvatarX.q);
}

void Animator::SetAvatarRotation(const Quaternionf& q)
{
    if (!IsAvatarInitialized())
        return;

    m_AvatarDataSet.m_AvatarMemory->m_AvatarX.q = QuaternionfTofloat4(q);
}

Vector3f    Animator::GetDeltaPosition()
{
    return m_DeltaPosition;
}

Quaternionf Animator::GetDeltaRotation()
{
    return m_DeltaRotation;
}

Vector3f    Animator::GetVelocity()
{
    return m_Velocity;
}

Vector3f    Animator::GetAngualrVelocity()
{
    return m_AngularVelocity;
}

Vector3f    Animator::GetBodyPosition()
{
    if (!IsAvatarInitialized())
        return Vector3f::zero;

    mecanim::animation::AvatarConstant const* avatar = m_AvatarDataSet.m_AvatarConstant;

    if (avatar->isHuman())
    {
        return float3ToVector3f(m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_RootX.t);
    }

    return Vector3f::zero;
}

Quaternionf Animator::GetBodyRotation()
{
    if (!IsAvatarInitialized())
        return Quaternionf();

    mecanim::animation::AvatarConstant const * avatar = m_AvatarDataSet.m_AvatarConstant;

    if (avatar->isHuman())
    {
        return float4ToQuaternionf(m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_RootX.q);
    }

    return Quaternionf();
}

void Animator::SetBodyPosition(Vector3f const& bodyPosition)
{
    if (!IsAvatarInitialized() || !m_AvatarDataSet.m_AvatarConstant->isHuman())
        return;

    m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_RootX.t = Vector3fTofloat3(bodyPosition);
}

void Animator::SetBodyRotation(Quaternionf const& bodyRotation)
{
    if (!IsAvatarInitialized() || !m_AvatarDataSet.m_AvatarConstant->isHuman())
        return;

    m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_RootX.q = QuaternionfTofloat4(bodyRotation);
}

Vector3f Animator::GetPivotPosition()
{
    return m_PivotPosition;
}

Vector3f  Animator::GetTargetPosition()
{
    return m_TargetPosition;
}

Quaternionf  Animator::GetTargetRotation()
{
    if (IsAvatarInitialized() && m_AvatarDataSet.m_AvatarInput->m_TargetIndex >= mecanim::animation::kTargetLeftFoot && m_AvatarDataSet.m_AvatarInput->m_TargetIndex <= mecanim::animation::kTargetRightHand)
    {
        return m_TargetRotation * float4ToQuaternionf(mecanim::human::HumanGetGoalOrientationOffset(mecanim::human::Goal(m_AvatarDataSet.m_AvatarInput->m_TargetIndex - mecanim::animation::kTargetLeftFoot)));
    }

    return m_TargetRotation;
}

float Animator::GetGravityWeight()
{
    if (IsAvatarInitialized() && m_AvatarDataSet.m_AvatarOutput && m_AvatarDataSet.m_AvatarOutput->m_MotionOutput)
    {
        return m_AvatarDataSet.m_AvatarOutput->m_MotionOutput->m_GravityWeight;
    }
    else
    {
        return 0;
    }
}

bool Animator::IsBoneTransform(Transform *transform)
{
    if (!IsAvatarInitialized())
        return false;

    bool ret = false;

    if (m_HasTransformHierarchy)
    {
        for (size_t boneIter = 0; !ret && boneIter < m_AvatarDataSet.m_AvatarBindingConstant->skeletonBindingsCount; boneIter++)
        {
            ret = m_AvatarDataSet.m_AvatarBindingConstant->skeletonBindings[boneIter] == transform;
        }
    }
    else
    {
        for (size_t exposedIndex = 0; !ret && exposedIndex < m_AvatarDataSet.m_AvatarBindingConstant->exposedTransformCount; exposedIndex++)
        {
            ret = (m_AvatarDataSet.m_AvatarBindingConstant->exposedTransforms[exposedIndex].transform == transform) &&
                (m_AvatarDataSet.m_AvatarBindingConstant->exposedTransforms[exposedIndex].skeletonIndex != -1);
        }
    }

    return ret;
}

Transform* Animator::GetBoneTransform(int humanId)
{
    if (!IsAvatarInitialized())
        return NULL;

    Avatar* avatar = GetAvatar();
    if (avatar == NULL)
        return NULL;

    Transform *ret = NULL;

    mecanim::animation::AvatarConstant* cst = avatar->GetAsset();

    if (cst && cst->isHuman())
    {
        int humanBoneId = HumanTrait::GetBoneId(*avatar, humanId);

        if (humanBoneId == -1)
            return NULL;

        if (m_HasTransformHierarchy)
        {
            ret = m_AvatarDataSet.m_AvatarBindingConstant->skeletonBindings[cst->m_HumanSkeletonIndexArray[humanBoneId]];
        }
        else
        {
            int skeletonIndex = cst->m_HumanSkeletonIndexArray[humanBoneId];
            for (size_t exposedIndex = 0; exposedIndex < m_AvatarDataSet.m_AvatarBindingConstant->exposedTransformCount; exposedIndex++)
            {
                const ExposedTransform& exposedTransform = m_AvatarDataSet.m_AvatarBindingConstant->exposedTransforms[exposedIndex];
                if (exposedTransform.skeletonIndex == skeletonIndex)
                {
                    ret = exposedTransform.transform;
                    break;
                }
            }
        }
    }

    return ret;
}

void Animator::MatchTarget(Vector3f const& matchPosition, Quaternionf const& matchRotation, int targetIndex, const MatchTargetWeightMask & mask, float startNormalizedTime,  float targetNormalizedTime)
{
    // It's only possible to match a target on the first layer
    const int layerIndex = 0;

    if (!ValidateTargetIndex(targetIndex) || IsMatchingTarget() || !IsInitialized())
        return;

    if (m_ControllerPlayable->IsInTransitionInternal(layerIndex))
    {
        WarningStringIfLoggingActive("Calling Animator.MatchTarget while in transition does not have any effect.");
        return;
    }

    if (m_AvatarDataSet.m_AvatarOutput->m_MotionOutput == NULL)
    {
        WarningStringIfLoggingActive("Calling Animator.MatchTarget when Apply Root Motion is disabled does not have any effect.");
        return;
    }

    mecanim::statemachine::StateMachineMemory const* apStateMachineMem = m_ControllerPlayable->GetStateMachineMemory(layerIndex);

    float internalTime = apStateMachineMem->m_CurrentStatePreviousTime;

    float intTime = 0;
    float currentStateTime = math::modf(internalTime, intTime);

    float effectiveStartTime = 0;
    float effectiveTargetTime = targetNormalizedTime + intTime;

    if (currentStateTime <= startNormalizedTime)
        effectiveStartTime = startNormalizedTime + intTime;
    else if (currentStateTime > startNormalizedTime && currentStateTime < targetNormalizedTime)
        effectiveStartTime = currentStateTime + intTime;
    else
    {
        // Passed target time, wait for next loop
        effectiveStartTime = startNormalizedTime + intTime + 1.0f;
        effectiveTargetTime += 1.0f;
    }

    AnimatorStateInfo animatorInfo;
    GetAnimatorStateInfo(layerIndex, kCurrentState, animatorInfo);
    if (!(animatorInfo.loop != 0) && targetNormalizedTime < effectiveStartTime)
        return;

    m_MatchTargetMask = mask;

    m_MatchStartTime = effectiveStartTime;
    m_MatchStateID = animatorInfo.nameHash;
    m_MatchPosition = matchPosition;
    m_MatchRotation = SqrMagnitude(matchRotation) > 0 ? matchRotation : Quaternionf::identity();
    m_AvatarDataSet.m_AvatarInput->m_TargetIndex = targetIndex;
    m_AvatarDataSet.m_AvatarInput->m_TargetTime = effectiveTargetTime < effectiveStartTime ? effectiveTargetTime + 1.f : effectiveTargetTime;
}

void Animator::InterruptMatchTarget(bool completeMatch)
{
    if (completeMatch)
        m_MustCompleteMatch = true;
    else
    {
        m_MatchStartTime  = -1;
        m_MatchStateID = -1;
    }
}

bool Animator::IsInMatchTargetState() const
{
    if (!IsInitialized() || !ValidateHasAnimatorController() || !m_ControllerPlayable->ValidateLayerIndex(0))
        return false;

    mecanim::statemachine::StateMachineConstant const* apStateMachineConst = GetControllerConstant()->m_StateMachineArray[GetControllerConstant()->m_LayerArray[0]->m_StateMachineIndex].Get();
    if (apStateMachineConst->m_StateConstantCount <= 0)
        return false;

    mecanim::statemachine::StateMachineMemory const* apStateMachineMem = m_ControllerPlayable->GetStateMachineMemory(0);
    mecanim::statemachine::StateConstant const* state = apStateMachineConst->m_StateConstantArray[apStateMachineMem->m_CurrentStateIndex].Get();

    return CompareStateID(state, m_MatchStateID);
}

bool Animator::IsMatchingTarget() const
{
    return m_MatchStartTime >= 0;
}

void Animator::SetTarget(int targetIndex, float targetNormalizedTime)
{
    if (!ValidateTargetIndex(targetIndex) || !IsInitialized())
        return;

    if (IsMatchingTarget())
        WarningStringIfLoggingActive("Calling Animator::SetTarget while already Matching Target does not have any effect");

    m_AvatarDataSet.m_AvatarInput->m_TargetIndex = targetIndex;
    m_AvatarDataSet.m_AvatarInput->m_TargetTime = targetNormalizedTime;
}

void Animator::SetSpeed(float speed)
{
    if (speed < 0.0f && GetRecorderMode() == eOffline)
        WarningStringIfLoggingActive("Animator.speed can only be negative when Animator recorder is enabled. Animator.recorderMode != AnimatorRecorderMode.Offline");

    m_Speed = GetRecorderMode() == eOffline ? std::max(0.0f, speed) : speed;

    mecanim::animation::ControllerMemory* controllerMemory = GetControllerMemory();
    if (controllerMemory)
    {
        controllerMemory->m_InPlayback = IsAutoPlayingBack();
        GetControllerInput()->m_Speed = m_Speed;
    }
}

float Animator::GetSpeed() const
{
    return m_Speed;
}

#define VALIDATE_IK_GOAL(x) \
if(!ValidateGoalIndex(index) || !IsAvatarInitialized() || !m_AvatarDataSet.m_AvatarConstant->isHuman()) \
    return x; \

#define VALIDATE_IK_GOAL_VOID() \
if(!ValidateGoalIndex(index) || !IsAvatarInitialized() || !m_AvatarDataSet.m_AvatarConstant->isHuman()) \
    return; \


Vector3f Animator::GetGoalPosition(int index)
{
    VALIDATE_IK_GOAL(Vector3f::zero)

    return float3ToVector3f(m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_GoalArray[index].m_X.t);
}

void Animator::SetGoalPosition(int index, Vector3f const& pos)
{
    VALIDATE_IK_GOAL_VOID()

    m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_GoalArray[index].m_X.t = Vector3fTofloat3(pos);
}

Quaternionf Animator::GetGoalRotation(int index)
{
    VALIDATE_IK_GOAL(Quaternionf::identity())

    return float4ToQuaternionf(math::normalize(math::quatMul(m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_GoalArray[index].m_X.q, mecanim::human::HumanGetGoalOrientationOffset(mecanim::human::Goal(index)))));
}

void Animator::SetGoalRotation(int index, Quaternionf const& rot)
{
    VALIDATE_IK_GOAL_VOID()

    m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_GoalArray[index].m_X.q =  math::normalize(math::quatMul(QuaternionfTofloat4(rot), math::quatConj(mecanim::human::HumanGetGoalOrientationOffset(mecanim::human::Goal(index)))));
}

void Animator::SetGoalWeightPosition(int index, float value)
{
    VALIDATE_IK_GOAL_VOID()

    m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_GoalArray[index].m_WeightT = value;
}

void Animator::SetGoalWeightRotation(int index, float value)
{
    VALIDATE_IK_GOAL_VOID()

    m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_GoalArray[index].m_WeightR = value;
}

float Animator::GetGoalWeightPosition(int index)
{
    VALIDATE_IK_GOAL(0.0F)

    return m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_GoalArray[index].m_WeightT;
}

float Animator::GetGoalWeightRotation(int index)
{
    VALIDATE_IK_GOAL(0.0F)

    return m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_GoalArray[index].m_WeightR;
}

Vector3f Animator::GetHintPosition(int index)
{
    VALIDATE_IK_GOAL(Vector3f::zero)

    return float3ToVector3f(m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_GoalArray[index].m_HintT);
}

void Animator::SetHintPosition(int index, Vector3f const& pos)
{
    VALIDATE_IK_GOAL_VOID()

    m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_GoalArray[index].m_HintT = Vector3fTofloat3(pos);
}

void Animator::SetHintWeightPosition(int index, float value)
{
    VALIDATE_IK_GOAL_VOID()

    m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_GoalArray[index].m_HintWeightT = value;
}

float Animator::GetHintWeightPosition(int index)
{
    VALIDATE_IK_GOAL(0.0F)

    return m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_GoalArray[index].m_HintWeightT;
}

#define VALIDATE_LOOKAT \
if (!IsAvatarInitialized() || !m_AvatarDataSet.m_AvatarConstant->isHuman()) return;\


void Animator::SetLookAtPosition(Vector3f lookAtPosition)
{
    VALIDATE_LOOKAT

    m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_LookAtPosition = Vector3fTofloat3(lookAtPosition);
}

void Animator::SetLookAtClampWeight(float weight)
{
    VALIDATE_LOOKAT

    m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_LookAtWeight.x = weight;
}

void Animator::SetLookAtBodyWeight(float weight)
{
    VALIDATE_LOOKAT

    m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_LookAtWeight.y = weight;
}

void Animator::SetLookAtHeadWeight(float weight)
{
    VALIDATE_LOOKAT

    m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_LookAtWeight.z = weight;
}

void Animator::SetLookAtEyesWeight(float weight)
{
    VALIDATE_LOOKAT

    m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_LookAtWeight.w = weight;
}

void Animator::SetBoneLocalRotation(int humanBoneId, Quaternionf rotation)
{
    if (!IsAvatarInitialized())
        return;

    Avatar* avatar = GetAvatar();
    if (avatar == NULL)
        return;

    mecanim::animation::AvatarConstant* cst = avatar->GetAsset();
    if (cst == NULL)
        return;

    if (!cst->isHuman())
        return;

    int boneIndex = HumanTrait::GetBoneId(*avatar, humanBoneId);
    if (boneIndex == -1)
        return;

    m_AvatarDataSet.m_AvatarWorkspace->m_BodySkeletonPoseWs->m_X[boneIndex].q = QuaternionfTofloat4(rotation);
}

float Animator::GetPivotWeight()
{
    if (!IsAvatarInitialized())
        return 0;

    return m_AvatarDataSet.m_AvatarMemory->m_PivotWeight;
}

AnimationClips const& Animator::GetAnimationClips() const
{
    if (m_CachedAnimationClips.size() == 0)
        const_cast<Animator*>(this)->SetupAnimationClipsCache();

    return m_CachedAnimationClips;
}

const mecanim::animation::ControllerConstant* Animator::GetControllerConstant() const
{
    if (!HasAnimatorController())
        return 0;

    return m_ControllerPlayable->GetMemory()->m_ControllerConstant;
}

mecanim::animation::ControllerMemory* Animator::GetControllerMemory() const
{
    if (!HasAnimatorController())
        return 0;

    return m_ControllerPlayable->GetMemory()->m_ControllerMemory;
}

mecanim::animation::ControllerWorkspace* Animator::GetControllerWorkspace() const
{
    if (!HasAnimatorController())
        return 0;

    return m_ControllerPlayable->GetMemory()->m_ControllerWorkspace;
}

mecanim::animation::ControllerInput* Animator::GetControllerInput() const
{
    if (!HasAnimatorController())
        return 0;

    return m_ControllerPlayable->GetMemory()->m_ControllerInput;
}

void Animator::GetRootBlendTreeConstantAndWorkspace(int layerIndex, int stateHash, mecanim::animation::BlendTreeNodeConstant const* & constant, mecanim::animation::BlendTreeWorkspace*& workspace)
{
    if (!ValidateHasAnimatorController() || !m_ControllerPlayable->ValidateLayerIndex(layerIndex))
        return;


    mecanim::uint32_t stateMachineIndex = GetControllerConstant()->m_LayerArray[layerIndex]->m_StateMachineIndex;
    mecanim::uint32_t motionSetIndex = GetControllerConstant()->m_LayerArray[layerIndex]->m_StateMachineMotionSetIndex;

    mecanim::statemachine::StateMachineConstant const* apStateMachineConst = GetControllerConstant()->m_StateMachineArray[GetControllerConstant()->m_LayerArray[layerIndex]->m_StateMachineIndex].Get();
    mecanim::statemachine::StateMachineWorkspace* apStateMachineWorkspace = GetControllerWorkspace()->m_StateMachineWorkspace[stateMachineIndex];

    for (size_t i = 0; i < apStateMachineConst->m_StateConstantCount; i++)
    {
        if (CompareStateID(apStateMachineConst->m_StateConstantArray[i].Get(), stateHash))
        {
            constant = apStateMachineConst->m_StateConstantArray[i]->m_BlendTreeConstantArray[motionSetIndex]->m_NodeArray[0].Get();
            workspace = apStateMachineWorkspace->m_StateWorkspace->m_BlendTreeWorkspaceArray[motionSetIndex];
        }
    }
}

float Animator::GetFeetPivotActive()
{
    if (!IsAvatarInitialized())
        return false;

    return m_AvatarDataSet.m_AvatarInput->m_FeetPivotActive;
}

void Animator::SetFeetPivotActive(float value)
{
    if (!IsAvatarInitialized())
        return;

    m_AvatarDataSet.m_AvatarInput->m_FeetPivotActive = value;
}

bool Animator::GetStabilizeFeet()
{
    if (!IsAvatarInitialized())
        return false;

    return m_AvatarDataSet.m_AvatarInput->m_StabilizeFeet;
}

void Animator::SetStabilizeFeet(bool value)
{
    if (!IsAvatarInitialized())
        return;

    m_AvatarDataSet.m_AvatarInput->m_StabilizeFeet = value;
}

float   Animator::GetLeftFeetBottomHeight()
{
    if (!m_Avatar.IsValid())
        return 0.f;

    return m_Avatar->GetLeftFeetBottomHeight();
}

float   Animator::GetRightFeetBottomHeight()
{
    if (!m_Avatar.IsValid())
        return 0.f;

    return m_Avatar->GetRightFeetBottomHeight();
}

#if UNITY_EDITOR

void Animator::WriteSkeletonPose(mecanim::skeleton::SkeletonPose& pose)
{
    VALIDATE_CAN_WRITE_VALUES();
    if (m_BindingsDataSet.m_GenericBindingConstant != NULL)
    {
        TransformChangeSystemMask systemMask = (GetUpdateMode() == kAnimatePhysics) ? GetTransformChangeDispatch().GetChangeMaskForInterest(TransformChangeDispatch::kInterestedInPhysicsAnimation) : TransformChangeSystemMask(0);
        SetHumanTransformPropertyValues(*m_AvatarDataSet.m_AvatarBindingConstant, pose, true, systemMask);
        SetTransformPropertyApplyMainThread(GetComponent<Transform>(), *m_BindingsDataSet.m_GenericBindingConstant, *m_AvatarDataSet.m_AvatarBindingConstant);
    }
    else
    {
        ErrorStringObject("Failed to write skeleton pose", this);
    }
}

void  Animator::WriteHumanPose(mecanim::human::HumanPose &pose)
{
    VALIDATE_CAN_WRITE_VALUES();
    // this function is only called from the editor.
    // always fetch the avatar constant from the Avatar asset in case it been updated.
    // Looking if the pptr is valid
    if (!m_Avatar.IsValid())
        return;

    // Looking if the mecanim avatar constant is valid
    if (!m_Avatar->IsValid())
        return;

    if (!Prepare())
        return;

    mecanim::animation::AvatarConstant *avatar = m_Avatar->GetAsset();

    if (avatar && avatar->isHuman())
    {
        m_SamplingDataSets.Reset();
        SetupAvatarDataSet(avatar, m_SamplingDataSets.m_AvatarDataSet, true);

        AvatarDataSet const &avatarDataSet = m_SamplingDataSets.m_AvatarDataSet;

        mecanim::human::Human *human = avatar->m_Human.Get();
        mecanim::human::RetargetTo(human, &pose, 0, math::trsIdentity(), avatarDataSet.m_AvatarOutput->m_HumanPoseOutput, avatarDataSet.m_AvatarWorkspace->m_BodySkeletonPoseWs, avatarDataSet.m_AvatarWorkspace->m_BodySkeletonPoseWsA);
        mecanim::animation::EvaluateAvatarEnd(avatar, avatarDataSet.m_AvatarInput, avatarDataSet.m_AvatarOutput, avatarDataSet.m_AvatarMemory, avatarDataSet.m_AvatarWorkspace);

        WriteSkeletonPose(*avatarDataSet.m_AvatarOutput->m_SkeletonPoseOutput);
    }
    else
    {
        ErrorStringObject("Failed to write human pose", this);
    }
}

void Animator::WriteDefaultPose()
{
    VALIDATE_CAN_WRITE_VALUES();
    // Looking if the pptr is valid
    if (!m_Avatar.IsValid())
        return;

    // Looking if the mecanim avatar constant is valid
    if (!m_Avatar->IsValid())
        return;

    if (!Prepare())
        return;

    mecanim::animation::AvatarConstant *avatar = m_Avatar->GetAsset();

    WriteSkeletonPose(*avatar->m_AvatarSkeletonPose);
}

#endif


void Animator::WriteDefaultValuesNoDirty()
{
    VALIDATE_CAN_WRITE_VALUES();
    if (m_BindingsDataSet.m_GenericBindingConstant != NULL && m_AvatarDataSet.m_AvatarBindingConstant != NULL)
    {
        SetGenericFloatPropertyValues(*m_BindingsDataSet.m_GenericBindingConstant, *m_BindingsDataSet.m_GenericBindingConstant->controllerBindingConstant->m_DynamicValuesDefault);
        SetGenericPPtrPropertyValues(*m_BindingsDataSet.m_GenericBindingConstant, *m_BindingsDataSet.m_GenericBindingConstant->controllerBindingConstant->m_DynamicValuesDefault);
        SetGenericIntPropertyValues(*m_BindingsDataSet.m_GenericBindingConstant, *m_BindingsDataSet.m_GenericBindingConstant->controllerBindingConstant->m_DynamicValuesDefault);

        TransformChangeSystemMask systemMask = (GetUpdateMode() == kAnimatePhysics) ? GetTransformChangeDispatch().GetChangeMaskForInterest(TransformChangeDispatch::kInterestedInPhysicsAnimation) : TransformChangeSystemMask(0);

        if (m_AvatarDataSet.m_AvatarConstant->isHuman() && m_AvatarDataSet.m_AvatarBindingConstant->defaultSkeletonPose != NULL)
        {
            SetHumanTransformPropertyValues(*m_AvatarDataSet.m_AvatarBindingConstant, *m_AvatarDataSet.m_AvatarBindingConstant->defaultSkeletonPose, true, systemMask);
        }

        SetGenericTransformPropertyValues(*m_BindingsDataSet.m_GenericBindingConstant, *m_BindingsDataSet.m_GenericBindingConstant->controllerBindingConstant->m_DynamicValuesDefault, m_ApplyRootMotion ? &GetComponent<Transform>() : 0, systemMask);
    }
}

bool Animator::IsAutoPlayingBack()
{
    return m_RecorderMode == eRecord && GetSpeed() < 0;
}

bool Animator::IsPlayingBack()
{
    return m_RecorderMode == ePlayback || IsAutoPlayingBack();
}

bool Animator::ShouldInterruptMatchTarget() const
{
    if (IsMatchingTarget())
    {
        // case 516805: Match target must be interrupted if we begin a transition.
        if (m_ControllerPlayable->IsInTransitionInternal(0))
            return true;

        // case 542102: when the frame rate drop we miss the end of the match target and the last match target parameter stick.
        // detect such case in TargetMatch by watching the initial state id
        if (!IsInMatchTargetState())
            return true;
    }

    return false;
}

void Animator::TargetMatch()
{
    if (ShouldInterruptMatchTarget())
        InterruptMatchTarget(true);

    if (IsInitialized() && IsMatchingTarget() && m_AvatarDataSet.m_AvatarOutput->m_MotionOutput != NULL)
    {
        math::trsX avatarX = m_AvatarDataSet.m_AvatarMemory->m_AvatarX;

        math::float1 scale = m_AvatarDataSet.m_AvatarConstant->isHuman() ? math::float1(m_AvatarDataSet.m_AvatarConstant->m_Human->m_Scale) : math::float1(1.0f);
        math::trsX dxo = MotionOutputGetDeltaTransform(m_AvatarDataSet.m_AvatarOutput->m_MotionOutput);
        math::trsX dx = dxo;
        dx.t *= scale;
        avatarX = math::mul(avatarX, dx);

        float stateTime = 0;
        float stateDuration = 1;
        if (GetControllerConstant()->m_LayerCount > 0 && m_ControllerPlayable != 0)
        {
            AnimatorStateInfo info;
            m_ControllerPlayable->GetAnimatorStateInfo(0, kCurrentState, info);
            stateTime = info.normalizedTime;
            stateDuration = info.length;
        }

        if (stateTime >= m_MatchStartTime)
        {
            float endTime = m_AvatarDataSet.m_AvatarInput->m_TargetTime;
            float normalizeDeltaTime = m_AvatarDataSet.m_AvatarInput->m_DeltaTime / stateDuration;

            // since we are calculating this after we have already adjusted state time for the frame, we end up one frame ahead
            stateTime -= normalizeDeltaTime;

            float remainingTime = std::max(0.0f, endTime - stateTime);
            float w = remainingTime != 0 ? normalizeDeltaTime / remainingTime : 1;

            w = math::saturate(w);

            math::float3 targetT = m_AvatarDataSet.m_AvatarOutput->m_MotionOutput->m_TargetX.t;
            math::float4 targetQ = m_AvatarDataSet.m_AvatarOutput->m_MotionOutput->m_TargetX.q;

            mecanim::uint32_t targetIndex = m_AvatarDataSet.m_AvatarInput->m_TargetIndex;

            if (m_MustCompleteMatch)
            {
                w = 1;
                if (targetIndex  == mecanim::animation::kTargetReference)
                {
                    targetT = math::float3(math::ZERO);
                    targetQ = math::quatIdentity();
                }
                else if (targetIndex  == mecanim::animation::kTargetRoot)
                {
                    targetT = m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_RootX.t;
                    targetQ = m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_RootX.q;
                }
                else if (targetIndex >= mecanim::animation::kTargetLeftFoot && targetIndex <= mecanim::animation::kTargetRightHand)
                {
                    targetT = m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_GoalArray[targetIndex - 2].m_X.t;
                    targetQ = m_AvatarDataSet.m_AvatarOutput->m_HumanPoseOutput->m_GoalArray[targetIndex - 2].m_X.q;
                }
            }


            if (targetIndex >= mecanim::animation::kTargetLeftFoot && targetIndex <= mecanim::animation::kTargetRightHand)
                targetQ = math::normalize(math::quatMul(targetQ, mecanim::human::HumanGetGoalOrientationOffset(mecanim::human::Goal(targetIndex - mecanim::animation::kTargetLeftFoot))));


            // from muscleclips, local to avatarX
            math::trsX targetXLocal(targetT, targetQ, math::float3(1.f));

            // from user, where we need to be, in world space
            math::trsX matchX(Vector3fTofloat3(m_MatchPosition), QuaternionfTofloat4(m_MatchRotation), math::float3(1.f));

            // make match local to avatar X
            math::trsX matchXLocal = math::invMul(avatarX, matchX); // @Sonny: any problem here for match target bug on IOS

            // m_AvatarDataSet.m_AvatarOutput->m_Velocity and AngularVelocity are in normalized space, so it must be computed in normalized space too.
            // dt not influenced by rotation
            math::trsX dxn(matchXLocal.t - targetXLocal.t, math::quatMul(matchXLocal.q, math::quatConj(targetXLocal.q)), math::float3(1.0f));
            dxn.t *= math::rcp(scale);
            dxn.t *= Vector3fTofloat3(w * m_MatchTargetMask.m_PositionXYZWeight);
            dxn.q = math::quatLerp(math::quatIdentity(), dxn.q, math::float1(w * m_MatchTargetMask.m_RotationWeight));

            dx = math::mul(dxo, dxn);

            MotionOutputSetDeltaTransform(m_AvatarDataSet.m_AvatarOutput->m_MotionOutput, dx);

            if (w >= 1)
            {
                InterruptMatchTarget(false);
            }
        }
    }
}

bool Animator::ValidateHasAnimatorController() const
{
    if (!HasAnimatorController())
    {
        WarningStringIfLoggingActive("Animator does not have an AnimatorController");
        return false;
    }

    return true;
}

bool Animator::ValidateHasPlayable() const
{
    if (m_BoundPlayables.size() <= 0)
    {
        WarningStringIfLoggingActive("Animator is not playing an AnimatorController");
        return false;
    }

    return true;
}

bool Animator::ValidateGoalIndex(int index)
{
    if (index < mecanim::human::kLeftFootGoal || index > mecanim::human::kRightHandGoal)
    {
        WarningStringIfLoggingActive("Invalid Goal Index");
        return false;
    }

    return true;
}

bool Animator::ValidateTargetIndex(int index)
{
    if (index < mecanim::animation::kTargetReference || index > mecanim::animation::kTargetRightHand)
    {
        WarningStringIfLoggingActive("Invalid Target Index");
        return false;
    }

    return true;
}

void Animator::WarningStringIfLoggingActive(const core::string& warning) const
{
    WarningStringIfLoggingActive(warning.c_str());
}

/// add or modify curve for a read only imported clip ... put Animation Window modification to curve in .meta

void Animator::WarningStringIfLoggingActive(const char* warning) const
{
#if UNITY_EDITOR
    if (m_LogWarnings)
    {
        WarningStringObject(warning , this);
    }
#endif
}

void Animator::ValidateParameterID(GetSetValueResult result, int identifier)
{
    ValidateParameterString(result, Format("Hash %d", identifier));
}

void Animator::ValidateParameterString(GetSetValueResult result, const core::string& name)
{
    if (result == kParameterMismatchFailure)
    {
        WarningStringIfLoggingActive(Format("Parameter type '%s' does not match.", name.c_str()));
    }
    else if (result == kParameterDoesNotExist)
    {
        WarningStringIfLoggingActive(Format("Parameter '%s' does not exist.", name.c_str()));
    }
    else if (result == kAnimatorNotInitialized)
    {
        WarningStringIfLoggingActive("Animator has not been initialized.");
    }
    else if (result == kParameterIsControlledByCurve)
    {
        WarningStringIfLoggingActive(Format("Parameter '%s' is controlled by a curve.", name.c_str()));
    }
}

#if UNITY_EDITOR
static bool IsTransformBindedByClip(UnityEngine::Animation::AnimationClipBindingConstant* bindingConstant, dynamic_array<std::pair<Transform *, BindingHash> > const& transforms)
{
    for (int j = 0; j < bindingConstant->genericBindings.size(); ++j)
    {
        BindingHash const& bindingHash = bindingConstant->genericBindings[j].path;
        for (int k = 0; k < transforms.size(); ++k)
        {
            if (transforms[k].second == bindingHash)
                return true;
        }
    }
    return false;
}

void Animator::HandleGenericBindingError(dynamic_array<std::pair<Transform *, BindingHash> > const& transforms, bool isOptimizedHierarchy)
{
    if (m_AnimatorActivePasses & kSampling)
        return;

    if (m_Controller.IsNull())
        return;

    if (transforms.size() == 0)
        return;

    LogWarning(Format("Binding warning: Some generic clip(s) animate transforms that are already bound by a Humanoid avatar. These transforms can only be changed by Humanoid clips."));

    const int maxErrorcount = 10;

    // We cannot show transfrom name when the rig is optimized
    if (!isOptimizedHierarchy)
    {
        for (int i = 0; i < transforms.size() && i < maxErrorcount; ++i)
        {
            if (transforms[i].first != NULL)
                LogWarning(Format("\tTransform '%s'", transforms[i].first->GetName()));
        }

        // Show that there is more error than those 10 first.
        if (transforms.size() > maxErrorcount)
            LogWarning("\tand more ...");
    }

    AnimationClipPPtrVector const& clips = m_Controller->GetAnimationClips();
    int errorCount = 0;
    for (int i = 0; i < clips.size() && errorCount < maxErrorcount; ++i)
    {
        if (IsTransformBindedByClip(clips[i]->GetBindingConstant(), transforms))
        {
            LogWarning(Format("\tFrom animation clip '%s'", clips[i]->GetName()));
            errorCount++;
            continue;
        }
    }

    // Show that there is more error than those 10 first.
    if (errorCount == maxErrorcount)
        LogWarning("\tand more ...");
}

#endif


Transform* Animator::GetAvatarRoot()
{
    Transform *root = &GetComponent<Transform>();
    if (m_Avatar.IsValid())
    {
        Transform* effectiveRoot =  0;
        if (m_Avatar->GetAsset() && m_Avatar->GetAsset()->m_AvatarSkeleton.Get())
        {
            effectiveRoot = FindAvatarRoot(m_Avatar->GetAsset()->m_AvatarSkeleton.Get(), m_Avatar->GetAsset()->m_SkeletonNameIDArray.Get(), *root, m_HasTransformHierarchy);
        }
        if (effectiveRoot)
            root = effectiveRoot;
    }

    return root;
}

TransformAccess Animator::GetRootTransformAccess() const
{
    return GetComponent<Transform>().GetTransformAccess();
}

StateMachineBehaviourVector const*  Animator::GetStateMachineBehaviours() const
{
    VALIDATE_HAS_ANIMATOR_CONTROLLER(0);
    return m_ControllerPlayable->GetStateMachineBehaviours();
}

bool Animator::HasAnimatorController() const
{
    return m_Controller.GetInstanceID() != InstanceID_None && m_ControllerPlayable != NULL;
}

AnimatorControllerPlayable* Animator::GetControllerPlayable() const
{
    return m_ControllerPlayable;
}

void Animator::OnGraphTopologyChanged(Playable* root, int outputPort)
{
    if (!IsActive() || root == NULL)
        return;

    AnimationPlayable* playable = GETANIMATIONPLAYABLE(root, outputPort);

    if (playable != 0)
    {
        if (playable->ComputeNeedsBindingRebuilded() && IsInitialized())
        {
            WriteDefaultValuesNoDirty();

            ClearBindings();
            CreateBindings();
            CreatePlayableMemory();
        }
        if (IsInitialized())
        {
            SetupPlayableConstant();
        }

        BuildControllerPlayableCache();
    }
}

void Animator::AddToManager()
{
    // case 718748 To keep the same behaviour as before 5.2b5 do not clear animator memory when only the animator component is disabled
    if (IsAddedToManager())
    {
        if (!m_PlayableGraph.IsValid())
        {
            CreatePlayableGraph();
        }
        if (m_ControllerPlayable == NULL)
        {
            CreateInternalControllerPlayable();
        }
        m_PlayableGraph.GetGraph()->Play();
    }
}

void Animator::RemoveFromManager()
{
    // case 718748 To keep the same behaviour as before 5.2b5 do not clear animator memory when only the animator component is disabled
    if (!IsAddedToManager() && m_PlayableGraph.IsValid())
    {
        m_PlayableGraph.GetGraph()->Stop();
    }
}

void Animator::OnPlayableUnbind(AnimationPlayableOutput *playableOutput)
{
    for (BoundPlayables::iterator it = m_BoundPlayables.begin(); it != m_BoundPlayables.end(); ++it)
    {
        if (playableOutput == it->GetPlayableOutput())
        {
            if (playableOutput->GetSourcePlayableUnsafe() == m_ControllerPlayable)
            {
                StopRecording();
                m_ControllerPlayable = NULL;
                m_AnimatorControllerNode.Clear();
            }

            m_BoundPlayables.erase(it);
            BuildControllerPlayableCache();
            return;
        }
    }
}

void Animator::OnPlayableBind(AnimationPlayableOutput *playableOutput)
{
    if (playableOutput == NULL)
        return;

    for (BoundPlayables::iterator it = m_BoundPlayables.begin(); it != m_BoundPlayables.end(); ++it)
    {
        if (playableOutput == it->GetPlayableOutput())
            return; // already binded nothing to do.
    }

    m_BoundPlayables.push_back(BoundPlayable(playableOutput));

    ClearBindings();
    SyncPlayStateToCulling();

    BuildControllerPlayableCache();
}

void Animator::BuildControllerPlayableCache()
{
    m_ControllerPlayableCache.clear();
    for (BoundPlayables::iterator it = m_BoundPlayables.begin(); it != m_BoundPlayables.end(); ++it)
    {
        AnimationPlayable* animationPlayable = it->GetAnimationPlayable();
        if (animationPlayable)
        {
            animationPlayable->CollectAnimatorControllerPlayables(m_ControllerPlayableCache);
        }
    }

    for (AnimatorControllerPlayables::const_iterator it = m_ControllerPlayableCache.begin(); it != m_ControllerPlayableCache.end(); ++it)
    {
        const int currentLayerCount = (*it)->GetLayerCount();
        m_ControllerPlayableCacheLayerCount = currentLayerCount > m_ControllerPlayableCacheLayerCount ? currentLayerCount : m_ControllerPlayableCacheLayerCount;
    }
}

void Animator::ClearFirstEvaluationFlag()
{
    for (AnimatorControllerPlayables::const_iterator it = m_ControllerPlayableCache.begin(); it != m_ControllerPlayableCache.end(); ++it)
    {
        (*it)->ClearFirstEvaluationFlag();
    }
}

void Animator::SetInternalPlayableWeight(float weight)
{
    if (m_PlayableOutput.IsValid())
    {
        m_PlayableOutput.GetOutput()->SetOutputWeight(weight);
    }
}

///@TODO:

/// * How does a user setup the animation range in the animation window?
/// * Figure out how we want to move loop blend feel intuitive.

/// * LivePreview pretends that non-looping animations loop. At least that looks like what it is visualizing...
/// * Blending of dynamic values does not treat default values correctly
/// muscle clip info for animation window created clips
/// visible avatar for some objects like lights
/// * Figure out how we will handle startTime / stopTime from AnimationWindow.

///@TODO: Write Test
/// Create cube with light attached
/// * Create Animation clip with transform changes -> Automatically applies root motion
/// * Animated child object is animated as normal position movement
/// * Blending between one clip that has a property and one that doesn't
