#include "UnityPrefix.h"

#include "Animator.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/mecanim/animation/avatar.h"
#include "Runtime/Animation/Director/AnimationLayerMixerPlayable.h"
#include "Runtime/Director/Core/Traversers.h"
#include "Runtime/Director/Core/PlayableOutput.h"

PROFILER_INFORMATION(gAnimatorProcessRootMotion, "Animator.ProcessRootMotion", kProfilerAnimation);
PROFILER_INFORMATION(gAnimatorProcessAnimations, "Animator.ProcessAnimations", kProfilerAnimation);

namespace
{
    typedef void (*PreFunc)(AnimationPlayableEvaluationConstant &, AnimationPlayable &);
    typedef void (*BeginFunc)(AnimationPlayableEvaluationConstant &, AnimationPlayableEvaluationInput &, AnimationPlayableEvaluationOutput &);
    typedef void (*MixFunc)(AnimationPlayableEvaluationOutput &, AnimationPlayableEvaluationConstant &, AnimationPlayableEvaluationInput &, AnimationPlayableEvaluationOutput &, float);
    typedef void (*EndFunc)(AnimationPlayableEvaluationConstant &, AnimationPlayableEvaluationInput &, AnimationPlayableEvaluationOutput &);

    void PreProcessRootMotion(AnimationPlayableEvaluationConstant &constant, AnimationPlayable &playable)
    {
        if (playable.NeedsPreProcess())
        {
            playable.PreProcessAnimation(&constant, 0);
        }
    }

    void ProcessRootMotionBegin(AnimationPlayableEvaluationConstant &constant, AnimationPlayableEvaluationInput &input, AnimationPlayableEvaluationOutput &output)
    {
        ClearMotionOutput(output.nodeStateOutput);

        if (constant.hasRootTransformValues || input.hasControllerParameters)
        {
            mecanim::SetValueMask<false>(output.nodeStateOutput->m_DynamicValuesMask, false);
        }
    }

    void ProcessRootMotionMix(AnimationPlayableEvaluationOutput &baseOutput, AnimationPlayableEvaluationConstant &constant, AnimationPlayableEvaluationInput &input, AnimationPlayableEvaluationOutput &output, float weight)
    {
        AnimationLayerMixerPlayable::MixRootMotion(&baseOutput, &constant, &input, &output, weight, output.nodeStateOutput->m_MotionReadMask);

        if (constant.hasRootTransformValues)
        {
            SetTransformValueMask(constant.rootPositionValueIndex, constant.rootRotationValueIndex, constant.rootScaleValueIndex, baseOutput.nodeStateOutput->m_DynamicValuesMask, false);
            AnimationLayerMixerPlayable::MixRootTransformValues(&baseOutput, &constant, &input, &output, weight);
        }

        if (input.hasControllerParameters)
        {
            mecanim::SetValueMask<true>(baseOutput.nodeStateOutput->m_DynamicValuesMask, false);
            AnimationLayerMixerPlayable::MixValues<true>(&baseOutput, &constant, &input, &output, weight);
        }
    }

    void ProcessRootMotionEnd(AnimationPlayableEvaluationConstant &constant, AnimationPlayableEvaluationInput &input, AnimationPlayableEvaluationOutput &output)
    {
        if (constant.hasRootTransformValues || input.hasControllerParameters)
        {
            mecanim::InvertValueMask<false>(output.nodeStateOutput->m_DynamicValuesMask);
            mecanim::AndValueMask<false>(input.passValueMask, output.nodeStateOutput->m_DynamicValuesMask);
            mecanim::ValueArrayCopy<false>(constant.defaultValues, output.nodeStateOutput->m_DynamicValues, output.nodeStateOutput->m_DynamicValuesMask);
            mecanim::InvertValueMask<false>(output.nodeStateOutput->m_DynamicValuesMask);
        }
    }

    void PreProcessAnimation(AnimationPlayableEvaluationConstant &constant, AnimationPlayable &playable)
    {
    }

    void ProcessAnimationBegin(AnimationPlayableEvaluationConstant &constant, AnimationPlayableEvaluationInput &input, AnimationPlayableEvaluationOutput &output)
    {
        mecanim::SetValueMask<false>(output.nodeStateOutput->m_DynamicValuesMask, false);

        if (constant.isHuman)
        {
            ClearHumanPoses(output.nodeStateOutput);
        }
    }

    void ProcessAnimationMix(AnimationPlayableEvaluationOutput &baseOutput, AnimationPlayableEvaluationConstant &constant, AnimationPlayableEvaluationInput &input, AnimationPlayableEvaluationOutput &output, float weight)
    {
        if (constant.isHuman && output.nodeStateOutput->m_HumanReadMask)
        {
            AnimationLayerMixerPlayable::MixHuman(&baseOutput, &constant, &input, &output, weight);
        }

        AnimationLayerMixerPlayable::MixValues<false>(&baseOutput, &constant, &input, &output, weight);
    }

    void ProcessAnimationEnd(AnimationPlayableEvaluationConstant &constant, AnimationPlayableEvaluationInput &input, AnimationPlayableEvaluationOutput &output)
    {
        mecanim::InvertValueMask<false>(output.nodeStateOutput->m_DynamicValuesMask);
        mecanim::AndValueMask<false>(input.passValueMask, output.nodeStateOutput->m_DynamicValuesMask);
        mecanim::ValueArrayCopy<false>(constant.defaultValues, output.nodeStateOutput->m_DynamicValues, output.nodeStateOutput->m_DynamicValuesMask);
        mecanim::InvertValueMask<false>(output.nodeStateOutput->m_DynamicValuesMask);
    }

    void ProcessPlayableGraph(Animator::AnimatorJob &job,
        AnimationPlayableEvaluationConstant &playableConstant,
        AnimationPlayableEvaluationInput &playableInput,
        AnimationPlayableEvaluationOutput &playableOutput,
        PreFunc preFunc,
        BeginFunc beginFunc,
        MixFunc mixFunc,
        EndFunc endFunc,
        AnimationPlayableProcessFunc processFunc)
    {
        bool hasSinglePlayable = job.m_Playables.size() == 1 && job.m_Playables[0].m_Weight == 1.0f;

        mecanim::memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);
        mecanim::animation::AnimationNodeState *nodeState = hasSinglePlayable ? NULL : mecanim::animation::CreateAnimationNodeState(*playableConstant.values, playableConstant.hasRootMotion, playableConstant.isHuman, playableConstant.affectMassCenter, tempAllocator);

        AnimationPlayableEvaluationOutput childOutput;
        childOutput.nodeStateOutput = nodeState;

        for (WeightedPlayables::iterator playableIt = job.m_Playables.begin(); playableIt != job.m_Playables.end(); ++playableIt)
        {
            if (!playableIt->IsValid())
                continue;

            AnimationPlayableEvaluationOutput* currentPlayableOutput = hasSinglePlayable ? &playableOutput : &childOutput;
            AnimationPlayable* playable = static_cast<AnimationPlayable*>(playableIt->GetPlayable());

            if (playable->NeedsAllocateBindings() || playable->ChildsNeedsAllocateBindings())
                playable->UpdateInternalStateRecursive<AnimationPlayable::kReallocateBindings, true>(&playableConstant);

            preFunc(playableConstant, *playable);

            beginFunc(playableConstant, playableInput, *currentPlayableOutput);
            (playable->*processFunc)(&playableConstant, &playableInput, currentPlayableOutput);
            endFunc(playableConstant, playableInput, *currentPlayableOutput);

            if (!hasSinglePlayable)
            {
                playableInput.defaultValuesOverride = playableOutput.nodeStateOutput->m_DynamicValues;
                mixFunc(playableOutput, playableConstant, playableInput, *currentPlayableOutput, playableIt->m_Weight);
            }
        }

        mecanim::animation::DestroyAnimationNodeState(nodeState, tempAllocator);
    }

    void ProcessOutputPrepare(Animator::AvatarDataSet &dataSet, mecanim::animation::AnimationNodeState &output)
    {
        output.m_DynamicValues = dataSet.m_AvatarOutput->m_DynamicValuesOutput;
        output.m_DynamicValuesMask = dataSet.m_AvatarOutput->m_DynamicValuesMaskOutput;
        output.m_MotionOutput = dataSet.m_AvatarOutput->m_MotionOutput;
        output.m_HumanPose = dataSet.m_AvatarOutput->m_HumanPoseOutput;
        output.m_HumanPoseBase = dataSet.m_AvatarInput->m_LayersAffectMassCenter ? 0 : dataSet.m_AvatarOutput->m_HumanPoseBaseOutput;
    }
}

void Animator::ProcessRootMotionStep(AnimatorJob &job)
{
    PROFILER_AUTO(gAnimatorProcessRootMotion, this);

    mecanim::memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);

    m_DeltaPosition = Vector3f::zero;
    m_DeltaRotation = Quaternionf::identity();

    m_Velocity = Vector3f::zero;
    m_AngularVelocity = Vector3f::zero;

    AnimationPlayableEvaluationInput playableInput;

    playableInput.passValueMask = mecanim::CreateValueArrayMask(m_PlayableConstant.controllerBindingConstant->m_DynamicValuesConstant, tempAllocator);
    mecanim::SetValueMask<false>(playableInput.passValueMask, false);
    mecanim::SetTransformValueMask(m_PlayableConstant.rootPositionValueIndex, m_PlayableConstant.rootRotationValueIndex, m_PlayableConstant.rootScaleValueIndex, playableInput.passValueMask, true);
    playableInput.hasControllerParameters = false;

    if (m_PlayableConstant.gravityWeightIndex != -1)
    {
        playableInput.passValueMask->m_FloatValues[m_PlayableConstant.gravityWeightIndex] = true;
        playableInput.hasControllerParameters = true;
    }

    playableInput.avatarInput = m_AvatarDataSet.m_AvatarInput;
    playableInput.additive = false;
    mecanim::human::HumanPoseMask fullBodyMask = mecanim::human::FullBodyMask();
    playableInput.humanPoseMask = &fullBodyMask;
    playableInput.lastEvaluationValues = 0;

    AnimationPlayableEvaluationOutput playableOutput;
    mecanim::animation::AnimationNodeState nodeStateOutput;
    ProcessOutputPrepare(m_AvatarDataSet, nodeStateOutput);
    playableOutput.nodeStateOutput = &nodeStateOutput;

    mecanim::animation::ClearMotionOutput(playableOutput.nodeStateOutput);
    mecanim::SetValueMask<false>(playableOutput.nodeStateOutput->m_DynamicValuesMask, false);

    ProcessPlayableGraph(job,
        m_PlayableConstant,
        playableInput,
        playableOutput,
        PreProcessRootMotion,
        ProcessRootMotionBegin,
        ProcessRootMotionMix,
        ProcessRootMotionEnd,
        &AnimationPlayable::ProcessRootMotion);

    mecanim::DestroyValueArrayMask(playableInput.passValueMask, tempAllocator);

    bool hasRootMotion = m_PlayableConstant.hasRootMotion;
    bool isHuman = m_PlayableConstant.isHuman;

    if (hasRootMotion || isHuman)
    {
        playableOutput.nodeStateOutput->m_MotionOutput->m_DeltaTime = playableInput.avatarInput->m_DeltaTime;

        if (!playableInput.avatarInput->m_LinearVelocityBlending)
        {
            if (playableOutput.nodeStateOutput->m_MotionOutput->m_DeltaTime != 0)
            {
                playableOutput.nodeStateOutput->m_MotionOutput->m_Velocity /= playableOutput.nodeStateOutput->m_MotionOutput->m_DeltaTime;
                playableOutput.nodeStateOutput->m_MotionOutput->m_AngularVelocity /= playableOutput.nodeStateOutput->m_MotionOutput->m_DeltaTime;
            }
            else
            {
                playableOutput.nodeStateOutput->m_MotionOutput->m_Velocity = math::float3(math::ZERO);
                playableOutput.nodeStateOutput->m_MotionOutput->m_AngularVelocity = math::float3(math::ZERO);
            }
        }

        mecanim::animation::EvaluateAvatarDX(m_AvatarDataSet.m_AvatarConstant,
            m_AvatarDataSet.m_AvatarInput,
            m_AvatarDataSet.m_AvatarMemory,
            m_AvatarDataSet.m_AvatarWorkspace,
            m_AvatarDataSet.m_AvatarOutput);

        math::float1 scale = isHuman ? math::float1(m_AvatarDataSet.m_AvatarConstant->m_Human->m_Scale) : math::float1(1);

        m_AvatarDataSet.m_AvatarOutput->m_MotionOutput->m_TargetX.t *= scale;
        TargetMatch();
        m_MustCompleteMatch = false;

        m_DeltaPosition = float3ToVector3f(math::quatMulVec(m_AvatarDataSet.m_AvatarMemory->m_AvatarX.q, MotionOutputGetDeltaPosition(m_AvatarDataSet.m_AvatarOutput->m_MotionOutput) * m_AvatarDataSet.m_AvatarMemory->m_AvatarX.s * scale));
        m_DeltaRotation = float4ToQuaternionf(MotionOutputGetDeltaRotation(m_AvatarDataSet.m_AvatarOutput->m_MotionOutput));

        m_Velocity = float3ToVector3f(math::quatMulVec(m_AvatarDataSet.m_AvatarMemory->m_AvatarX.q, m_AvatarDataSet.m_AvatarOutput->m_MotionOutput->m_Velocity * m_AvatarDataSet.m_AvatarMemory->m_AvatarX.s * scale));
        m_AngularVelocity = float3ToVector3f(math::quatMulVec(m_AvatarDataSet.m_AvatarMemory->m_AvatarX.q, m_AvatarDataSet.m_AvatarOutput->m_MotionOutput->m_AngularVelocity));

        mecanim::animation::EvaluateAvatarX(m_AvatarDataSet.m_AvatarConstant, m_AvatarDataSet.m_AvatarInput, m_AvatarDataSet.m_AvatarOutput, m_AvatarDataSet.m_AvatarMemory, m_AvatarDataSet.m_AvatarWorkspace);

        m_TargetPosition = float3ToVector3f(math::mul(m_AvatarDataSet.m_AvatarMemory->m_AvatarX, m_AvatarDataSet.m_AvatarOutput->m_MotionOutput->m_TargetX.t));
        m_TargetRotation = float4ToQuaternionf(math::normalize(math::quatMul(m_AvatarDataSet.m_AvatarMemory->m_AvatarX.q, m_AvatarDataSet.m_AvatarOutput->m_MotionOutput->m_TargetX.q)));
        m_PivotPosition = float3ToVector3f(math::mul(m_AvatarDataSet.m_AvatarMemory->m_AvatarX, m_AvatarDataSet.m_AvatarMemory->m_Pivot * scale));
    }
}

void Animator::ProcessAnimationsStep(AnimatorJob &job)
{
    PROFILER_AUTO(gAnimatorProcessAnimations, this);

    mecanim::memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);

    AnimationPlayableEvaluationInput playableInput;

    playableInput.passValueMask = mecanim::CreateValueArrayMask(m_PlayableConstant.controllerBindingConstant->m_DynamicValuesConstant, tempAllocator);
    mecanim::SetValueMask<false>(playableInput.passValueMask, true);
    mecanim::SetTransformValueMask(m_PlayableConstant.rootPositionValueIndex, m_PlayableConstant.rootRotationValueIndex, m_PlayableConstant.rootScaleValueIndex, playableInput.passValueMask, false);
    playableInput.hasControllerParameters = false;

    if (m_PlayableConstant.gravityWeightIndex != -1)
    {
        playableInput.passValueMask->m_FloatValues[m_PlayableConstant.gravityWeightIndex] = false;
        playableInput.hasControllerParameters = true;
    }

    playableInput.avatarInput = m_AvatarDataSet.m_AvatarInput;
    playableInput.additive = false;
    mecanim::human::HumanPoseMask fullBodyMask = mecanim::human::FullBodyMask();
    playableInput.humanPoseMask = &fullBodyMask;
    playableInput.lastEvaluationValues = 0;

    AnimationPlayableEvaluationOutput playableOutput;
    mecanim::animation::AnimationNodeState nodeStateOutput;
    ProcessOutputPrepare(m_AvatarDataSet, nodeStateOutput);
    playableOutput.nodeStateOutput = &nodeStateOutput;

    // applyMotionX is based on the outputWeight so must be set at every frame.
    m_PlayableConstant.applyMotionX = true;
    for (BoundPlayables::iterator it = m_BoundPlayables.begin(); it != m_BoundPlayables.end(); ++it)
    {
        if (it->GetPlayableOutput()->GetOutputWeight() > 0)
        {
            AnimationPlayable* animationPlayable = it->GetAnimationPlayable();
            if (animationPlayable)
                m_PlayableConstant.applyMotionX &= animationPlayable->GetApplyMotionX();
        }
    }


    ProcessPlayableGraph(job,
        m_PlayableConstant,
        playableInput,
        playableOutput,
        PreProcessAnimation,
        ProcessAnimationBegin,
        ProcessAnimationMix,
        ProcessAnimationEnd,
        &AnimationPlayable::ProcessAnimation);

    mecanim::DestroyValueArrayMask(playableInput.passValueMask, tempAllocator);

    if (m_PlayableConstant.isHuman)
    {
        m_AvatarDataSet.m_AvatarInput->m_IKOnFeet = playableOutput.m_IKOnFeet;
    }
}
