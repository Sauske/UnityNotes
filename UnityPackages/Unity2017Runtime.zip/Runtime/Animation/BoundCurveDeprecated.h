#pragma once
#include "Runtime/Animation/AnimationClipBindings.h"
#include "Runtime/Animation/BoundCurve.h"
struct BoundCurveDeprecated : public UnityEngine::Animation::BoundCurve
{
    InstanceID     targetInstanceID;

    // Which states affect the bound curve?
    UInt32  affectedStateMask;

    BoundCurveDeprecated()
        : UnityEngine::Animation::BoundCurve()
    {
        targetInstanceID = InstanceID_None;
        affectedStateMask = 0;
    }

    enum
    {
        kBindTypeBitCount = 5,
        kBindMaterialShaderPropertyNameBitCount = 24,

        kBindTypeMask = (1 << kBindTypeBitCount) - 1,
        kBindMaterialShaderPropertyNameMask = ((1 << kBindMaterialShaderPropertyNameBitCount) - 1) << kBindTypeBitCount,
    };
};

enum
{
    kUnbound = 0,
    kBindTransformPosition = 1, // This enum may not be changed. It is used in GenericClipBinding.
    kBindTransformRotation = 2, // This enum may not be changed.  It is used in GenericClipBinding.
    kBindTransformScale = 3,    //  It is used in GenericClipBinding.
    kBindTransformEuler = 4,
    kMinGenericBinding = 5,

    kBindFloat = kMinGenericBinding,
    kBindFloatToBool,
    kBindFloatToGameObjectActivate,

    kBindFloatToInt = UnityEngine::Animation::kBindFloatToInt,
    kBindDiscreteInt = UnityEngine::Animation::kBindDiscreteInt,
    kMinIntCurveBinding,
    kBindMaterialPPtrToRenderer = kMinIntCurveBinding,
    kBindSpritePPtrToSpriteRenderer,
    kMaxIntCurveBinding,

    // These must always come last since materials do special bit masking magic.
    kBindFloatToMaterial = kMaxIntCurveBinding,
    kBindFloatToColorMaterial,
    kBindFloatToMaterialScaleAndOffset,

    kBindTypeCount
};
