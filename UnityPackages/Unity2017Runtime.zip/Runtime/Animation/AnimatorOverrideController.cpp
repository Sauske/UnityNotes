#include "UnityPrefix.h"
#include "AnimatorOverrideController.h"
#include "AnimationSetBinding.h"
#include "RuntimeAnimatorController.h"
#include "AnimationClip.h"
#include "AnimationScriptingClasses.h"
#include "Runtime/BaseClasses/MessageHandlerRegistration.h"

#if UNITY_EDITOR
#include "Runtime/Scripting/Scripting.h"
#include "Runtime/Scripting/ScriptingInvocation.h"
#include "Runtime/Scripting/ScriptingManager.h"
#endif

#define DIRTY_AND_INVALIDATE() ClearAsset(); SetDirty(); NotifyObjectUsers( kDidModifyAnimatorController ); CheckConsistency()
#define DIRTY_AND_UPDATE() ClearAsset(); SetDirty(); NotifyObjectUsers( kDidModifyOverrideClip ); CheckConsistency()

IMPLEMENT_REGISTER_CLASS(AnimatorOverrideController, 221);
IMPLEMENT_OBJECT_SERIALIZE(AnimatorOverrideController);
INSTANTIATE_TEMPLATE_TRANSFER(AnimatorOverrideController);

AnimatorOverrideController::AnimatorOverrideController(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
    , m_AnimationSetBindings(0)
    , m_Allocator(label)
    , m_AnimationSetNode(this)
    , m_OriginalAnimationClips(label)
    , m_AnimationClips(label)
{
}

void AnimatorOverrideController::ThreadedCleanup()
{
    // Do not call ClearAsset() in the destructor, otherwise we end up with a lot ton of asserts.
    ClearMemory();
}

void AnimatorOverrideController::MainThreadCleanup()
{
    m_AnimationSetNode.Clear();
    Super::MainThreadCleanup();
}

void AnimatorOverrideController::AwakeFromLoad(AwakeFromLoadMode mode)
{
    Super::AwakeFromLoad(mode);

    if (!m_Controller.IsNull())
        m_Controller->AddObjectUser(m_AnimationSetNode);

    NotifyObjectUsers(kDidModifyAnimatorController);

    //case 771609 : make sure m_AnimationSetBindings are builded on load instead of on instantiate.
    if (m_AnimationSetBindings == NULL)
    {
        BuildAsset();
    }
}

void AnimatorOverrideController::CheckConsistency()
{
    Super::CheckConsistency();

#if UNITY_EDITOR
    for (int i = 0; i < m_Clips.size(); i++)
    {
        AnimationClip *animationClip = m_Clips[i].m_OverrideClip;
        if (animationClip != NULL && animationClip->IsLegacy())
        {
            core::string warning = Format("The legacy Animation Clip \"%s\" cannot be used in the Override Controller \"%s\". Legacy Animation Clips are not allowed in Animator Override Controllers.", animationClip->GetName(), this->GetName());
            if (animationClip->GetHideFlags() && Object::kNotEditable)
            {
                warning += "  To use this Animation Clip in this Animator Override Controller, you must reimport it as a Generic or Humanoid Animation Clip.";
            }

            WarningStringObject(warning, this);
            m_Clips[i].m_OverrideClip = 0;
        }
    }
#endif
}

void AnimatorOverrideController::InitializeClass()
{
    REGISTER_MESSAGE_VOID(kDidModifyAnimatorController, OnInvalidateAnimatorController);
    REGISTER_MESSAGE_VOID(kDidModifyMotion, OnInvalidateAnimatorController);
    REGISTER_MESSAGE_VOID(kDidDeleteMotion, OnInvalidateAnimatorController);
}

template<class Functor> PPtr<AnimationClip> AnimatorOverrideController::FindAnimationClipInMap(PPtr<AnimationClip> const& clip, Functor functor, PPtr<AnimationClip> const& defaultClip) const
{
    AnimationClipOverrideVector::const_iterator it = std::find_if(m_Clips.begin(), m_Clips.end(), FindOriginalClip(clip));
    return it != m_Clips.end() ? functor(*it) : defaultClip;
}

// Return the clip list from controller
AnimationClipPPtrVector const& AnimatorOverrideController::GetOriginalClips() const
{
    Assert(Thread::CurrentThreadIsMainThread());

    if (!m_OriginalAnimationClips.empty())
        return m_OriginalAnimationClips;

    if (m_Controller.IsNull())
        return m_OriginalAnimationClips;

    // Create a copy as we need to modify the list and remove duplicate
    m_OriginalAnimationClips = m_Controller->GetAnimationClips();
    std::sort(m_OriginalAnimationClips.begin(), m_OriginalAnimationClips.end());

    AnimationClipPPtrVector::iterator it = std::unique(m_OriginalAnimationClips.begin(), m_OriginalAnimationClips.end());
    m_OriginalAnimationClips.resize_uninitialized(std::distance(m_OriginalAnimationClips.begin(), it));

    return m_OriginalAnimationClips;
}

// Return the merged clip list that should be used to drive the animator
// Always start from original clip list and search for each clip if there is a match in m_Clips
AnimationClipPPtrVector const& AnimatorOverrideController::GetAnimationClips() const
{
    Assert(Thread::CurrentThreadIsMainThread());

    if (!m_AnimationClips.empty())
        return m_AnimationClips;

    if (m_Controller.IsNull())
        return m_AnimationClips;

    AnimationClipPPtrVector const& controllerClips = m_Controller->GetAnimationClips();

    m_AnimationClips.reserve(controllerClips.size());

    for (AnimationClipPPtrVector::const_iterator clipIt = controllerClips.begin(); clipIt != controllerClips.end(); ++clipIt)
        m_AnimationClips.push_back(FindAnimationClipInMap(*clipIt, return_effective, *clipIt));

    return m_AnimationClips;
}

AnimationClipPPtrVector AnimatorOverrideController::GetOverrideClips() const
{
    AnimationClipPPtrVector const& controllerClips = GetOriginalClips();
    AnimationClipPPtrVector clips;
    clips.reserve(controllerClips.size());

    for (AnimationClipPPtrVector::const_iterator clipIt = controllerClips.begin(); clipIt != controllerClips.end(); ++clipIt)
        clips.push_back(FindAnimationClipInMap(*clipIt, return_override, NULL));

    return clips;
}

StateMachineBehaviourVector const& AnimatorOverrideController::GetBehaviours() const
{
    return m_Controller->GetBehaviours();
}

StateMachineBehaviourVectorDescription const& AnimatorOverrideController::GetStateMachineBehaviourVectorDescription() const
{
    return m_Controller->GetStateMachineBehaviourVectorDescription();
}

bool AnimatorOverrideController::HasMultiThreadedStateMachine() const
{
    return m_Controller.IsValid() && m_Controller->HasMultiThreadedStateMachine();
}

AnimationClipOverrideVector const* AnimatorOverrideController::GetAnimationClipOverrideVector() const
{
    return &m_Clips;
}

mecanim::animation::ControllerConstant* AnimatorOverrideController::GetAsset(bool forceBuild)
{
    if (m_Controller.IsNull())
        return 0;

    return m_Controller->GetAsset(forceBuild);
}

void AnimatorOverrideController::BuildAsset()
{
    ClearAsset();

    if (m_Controller.IsNull())
    {
        m_Clips.clear();
        return;
    }

    mecanim::animation::ControllerConstant* controller = m_Controller->GetAsset();
    if (controller == 0)
    {
        m_Clips.clear();
        return;
    }

    RegisterAnimationClips();
    m_AnimationSetBindings = UnityEngine::Animation::CreateAnimationSetBindings(GetAnimationClips(), m_Allocator);
}

core::string    AnimatorOverrideController::StringFromID(unsigned int ID) const
{
    if (m_Controller.IsNull())
        return "";

    return m_Controller->StringFromID(ID);
}

void AnimatorOverrideController::ClearMemory()
{
    DestroyAnimationSetBindings(m_AnimationSetBindings, m_Allocator);
    m_AnimationSetBindings = 0;
}

void AnimatorOverrideController::OnInvalidateAnimatorController()
{
    ClearAsset();
    NotifyObjectUsers(kDidModifyAnimatorController);
}

void AnimatorOverrideController::ClearAsset()
{
    m_OriginalAnimationClips.clear();
    m_AnimationClips.clear();

    ClearMemory();

#if UNITY_EDITOR
    // This is needed to update AnimatorOverrideController's inspector clip list.
    // If a user modify the controller by adding or removing a clip we cannot dirty AnimatorOverrideController asset because the user didn't modify it but still we need to update the UI
    // which is based on the controller clip list.
    ScriptingInvocation invocation(GetAnimationScriptingClasses().onInvalidateOverrideController);
    invocation.AddObject(Scripting::ScriptingWrapperFor(this));
    invocation.Invoke();
#endif
}

template<class TransferFunction>
void AnimatorOverrideController::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);

    TRANSFER(m_Controller);
    TRANSFER(m_Clips);
}

PPtr<RuntimeAnimatorController> AnimatorOverrideController::GetAnimatorController() const
{
    return m_Controller;
}

void AnimatorOverrideController::SetAnimatorController(PPtr<RuntimeAnimatorController> controller)
{
    if (!controller.IsNull() && controller->Is<AnimatorOverrideController>())
    {
        ErrorStringMsg("Cannot nest AnimatorOverrideController '%s' with '%s'.", controller->GetName(), GetName());
        return;
    }

    if (m_Controller != controller)
    {
        m_AnimationSetNode.Clear();

        m_Controller = controller;

        if (!m_Controller.IsNull())
            m_Controller->AddObjectUser(m_AnimationSetNode);

        DIRTY_AND_INVALIDATE();
    }
}

PPtr<AnimationClip> AnimatorOverrideController::GetClip(core::string const& name, bool returnEffectiveClip) const
{
    // if clip 'name' is not an original clip bailout
    PPtr<AnimationClip> originalClip = GetOriginalClip(name);
    if (originalClip.IsNull())
        return NULL;

    return returnEffectiveClip ? FindAnimationClipInMap(originalClip, return_effective, originalClip) : FindAnimationClipInMap(originalClip, return_override, originalClip);
}

PPtr<AnimationClip> AnimatorOverrideController::GetClip(PPtr<AnimationClip> originalClip, bool returnEffectiveClip) const
{
    // This is not an original clip, bail out
    if (!IsAnOriginalClip(originalClip))
        return NULL;

    return returnEffectiveClip ? FindAnimationClipInMap(originalClip, return_effective, originalClip) : FindAnimationClipInMap(originalClip, return_override, originalClip);
}

PPtr<AnimationClip> AnimatorOverrideController::GetOriginalClip(int index) const
{
    AnimationClipPPtrVector const& originalClips = GetOriginalClips();

    Assert(index >= 0 && index < originalClips.size());
    if (index < 0 || index >= originalClips.size())
        return NULL;

    return originalClips[index];
}

PPtr<AnimationClip> AnimatorOverrideController::GetOverrideClip(PPtr<AnimationClip> originalClip) const
{
    return FindAnimationClipInMap(originalClip, return_override, NULL);
}

void AnimatorOverrideController::SetClipOverride(PPtr<AnimationClip> originalClip, PPtr<AnimationClip> overrideClip, bool notify)
{
    AnimationClipOverrideVector::iterator clipOverrideIt = std::find_if(m_Clips.begin(), m_Clips.end(), FindOriginalClip(originalClip));
    if (clipOverrideIt != m_Clips.end())
    {
        clipOverrideIt->m_OverrideClip = overrideClip;
    }
    else
    {
        AnimationClipOverride clipOverride;
        clipOverride.m_OriginalClip = originalClip;
        clipOverride.m_OverrideClip = overrideClip;

        m_Clips.push_back(clipOverride);
    }
    if (notify)
        DIRTY_AND_UPDATE();
}

void AnimatorOverrideController::SetClip(PPtr<AnimationClip> originalClip, PPtr<AnimationClip> overrideClip, bool notify /*=true*/)
{
    // This is not an original clip, bail out
    if (!IsAnOriginalClip(originalClip))
        return;

    SetClipOverride(originalClip, overrideClip, notify);
}

void AnimatorOverrideController::SetClip(core::string const& name, PPtr<AnimationClip> overrideClip, bool notify /*=true*/)
{
    PPtr<AnimationClip> originalClip = GetOriginalClip(name);

    // This is not an original clip, bail out
    if (originalClip.IsNull())
        return;

    SetClipOverride(originalClip, overrideClip, notify);
}

bool AnimatorOverrideController::IsAnOriginalClip(PPtr<AnimationClip> clip) const
{
    if (m_Controller.IsNull() || clip.IsNull())
        return false;

    AnimationClipPPtrVector const& controllerClips = m_Controller->GetAnimationClips();
    AnimationClipPPtrVector::const_iterator originalClipIt = std::find_if(controllerClips.begin(), controllerClips.end(), FindClip(clip));

    return originalClipIt != controllerClips.end();
}

PPtr<AnimationClip>  AnimatorOverrideController::GetOriginalClip(core::string const& name) const
{
    if (m_Controller.IsNull() || name.empty())
        return NULL;

    AnimationClipPPtrVector const& controllerClips = m_Controller->GetAnimationClips();
    AnimationClipPPtrVector::const_iterator originalClipIt = std::find_if(controllerClips.begin(), controllerClips.end(), FindClipByName(name.c_str()));

    return originalClipIt != controllerClips.end() ? *originalClipIt : NULL;
}

SharedAnimationSetBindingsPtr AnimatorOverrideController::GetAnimationSetBindings()
{
    if (m_AnimationSetBindings == 0)
        BuildAsset();

    return SharedAnimationSetBindingsPtr(m_AnimationSetBindings);
}

AnimationClipPPtrVector AnimatorOverrideController::GetAnimationClipsToRegister() const
{
    return GetOverrideClips();
}

void AnimatorOverrideController::PerformOverrideClipListCleanup()
{
    AnimationClipPPtrVector const& clips = GetOriginalClips();

    AnimationClipOverrideVector clipsToRemove;
    AnimationClipOverrideVector::iterator it;
    for (it = m_Clips.begin(); it != m_Clips.end(); ++it)
    {
        if (it->m_OriginalClip.IsNull() || it->m_OverrideClip.IsNull())
            clipsToRemove.push_back(*it);
        else
        {
            AnimationClipPPtrVector::const_iterator it2 = std::find_if(clips.begin(), clips.end(), FindClip(it->m_OriginalClip));
            if (it2 == clips.end())
                clipsToRemove.push_back(*it);
        }
    }

    for (it = clipsToRemove.begin(); it != clipsToRemove.end(); ++it)
    {
        AnimationClipOverrideVector::iterator it2 = std::find_if(m_Clips.begin(), m_Clips.end(), FindOriginalClip(it->m_OriginalClip));
        if (it2 != m_Clips.end())
            m_Clips.erase(it2);
    }

    if (clipsToRemove.size() > 0)
        DIRTY_AND_INVALIDATE();
}

RuntimeAnimatorController* AnimatorOverrideController::GetEffectiveController(RuntimeAnimatorController* controller)
{
    if (controller == NULL)
        return NULL;

    AnimatorOverrideController* overrideController  = dynamic_pptr_cast<AnimatorOverrideController*>(controller);
    if (overrideController != NULL)
    {
        while (dynamic_pptr_cast<AnimatorOverrideController*>(overrideController->GetAnimatorController()) != NULL)
            overrideController = dynamic_pptr_cast<AnimatorOverrideController*>(overrideController->GetAnimatorController());
        controller = overrideController->GetAnimatorController();
    }
    return controller;
}

void AnimatorOverrideController::SendNotification()
{
    DIRTY_AND_UPDATE();
}

#undef DIRTY_AND_INVALIDATE
#undef DIRTY_AND_UPDATE
