#pragma once
#include "Runtime/Scripting/ScriptingTypes.h"

struct IAnimatedPropertyEvaluator;
class AnimationClip;


struct AnimatedPropertyBuilder
{
    static IAnimatedPropertyEvaluator* Build(AnimationClip* clip, ScriptingObjectPtr target);
};
