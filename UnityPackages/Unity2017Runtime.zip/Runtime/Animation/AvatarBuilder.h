#ifndef AVATARBUILDER_H
#define AVATARBUILDER_H

#include "Runtime/BaseClasses/NamedObject.h"

#include "Runtime/Math/Vector3.h"
#include "Runtime/Math/Quaternion.h"
#include "Runtime/mecanim/types.h"

#include "Runtime/Animation/MecanimUtility.h"
#include "Runtime/Animation/HumanDescription.h"
#include "Runtime/Serialize/SerializeTraits.h"

#include <vector>

class Avatar;
class GameObject;
class Transform;

namespace mecanim
{
namespace skeleton
{
    struct Skeleton;

    template<typename transformType> struct SkeletonPoseT;
    typedef SkeletonPoseT<math::trsX> SkeletonPose;
}

namespace animation
{
    struct AvatarConstant;
}
}


class FindHumanBone
{
protected:
    core::string  mName;
public:
    FindHumanBone(core::string const& name) : mName(name) {}
    bool operator()(HumanBone const& bone) { return mName == bone.m_HumanName; }
};

class FindBoneName
{
protected:
    core::string  mName;
public:
    FindBoneName(core::string const& name) : mName(name) {}
    bool operator()(HumanBone const& bone) { return mName == bone.m_BoneName; }
};

class FindSkeletonBone
{
protected:
    core::string  mName;
public:
    FindSkeletonBone(core::string const& name) : mName(name) {}
    bool operator()(SkeletonBone const& bone) { return mName == bone.m_Name; }
};

// The type of Avatar to create
enum AvatarType
{
    kGeneric  = 2,
    kHumanoid = 3
};

class AvatarBuilder
{
public:
    struct Options
    {
        Options() : avatarType(kGeneric), readTransform(false), useMask(false) {}

        AvatarType avatarType;
        bool readTransform;
        bool useMask;
    };

    struct NamedTransform
    {
        core::string    name;
        core::string    path;
        Transform*  transform;
    };

    typedef std::vector<NamedTransform> NamedTransforms;

    // readTransform is mainly used by importer. It does read the Default pose from the first frame pose found in the file.
    // useMask is mainly used for API call, when suer want to select only a sub part of a hierarchy.
    static core::string BuildAvatar(Avatar& avatar, const GameObject& go, const HumanDescription& humanDescription, Options options = Options());
    static void         BuildAvatarInternal(Avatar& avatar, const NamedTransforms &namedTransforms, const GameObject& go, const HumanDescription& humanDescription, Options options, bool fixOldRigs = false);

    static bool         IsValidHumanDescription(HumanDescription const& humanDescription, core::string& error, bool copiedDescription);
    static bool         IsValidHuman(HumanDescription const& humanDescription, NamedTransforms const& namedTransform, Transform& rootTransform, core::string& error);
    static bool         IsValidHumanHierarchy(HumanDescription const& humanDescription, NamedTransforms const& namedTransform, Transform& rootTransform, core::string& error);
    static bool         GenerateAvatarMap(GameObject const& go, NamedTransforms& namedTransforms, NamedTransforms& humanNamedTransforms, const HumanDescription& humanDescription, AvatarType avatarType, bool useMask, core::string& error);

    static void         GetAllChildren(Transform& node, NamedTransforms& transforms, std::vector<core::string> const& mask = std::vector<core::string>());
    static void         GetAllParent(Transform& node, NamedTransforms& transforms, std::vector<core::string> const& mask = std::vector<core::string>(), bool includeSelf = false);

    static void         ReadFromLocalTransformToSkeletonPose(mecanim::skeleton::SkeletonPose* pose, NamedTransforms const& namedTransform);

    static bool         TPoseMatch(mecanim::animation::AvatarConstant const& avatar, NamedTransforms const& namedTransform, core::string& posWarning, core::string& rotWarning);
protected:

    static void GetAllChildren(Transform& node, core::string& path, NamedTransforms& transforms, std::vector<core::string> const& mask);
    static void GetAllParent(Transform& root, Transform& node, NamedTransforms& transforms, std::vector<core::string> const& mask = std::vector<core::string>(), bool includeSelf = false);

    static Transform* GetTransform(int id, HumanDescription const& humanDescription, NamedTransforms const& namedTransform, std::vector<core::string> const& boneName);

    static Transform*   GetRootMotionNode(const core::string& rootMotionBoneName, NamedTransforms const& transforms);
    static void         RemoveAllNoneHumanLeaf(NamedTransforms& namedTransform, HumanDescription const& humanDescription);
};

#endif
