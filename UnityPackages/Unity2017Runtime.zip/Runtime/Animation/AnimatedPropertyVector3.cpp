#include "UnityPrefix.h"

#include "Runtime/Animation/AnimatedPropertyVector3.h"
#include "Runtime/Animation/BaseAnimationTrack.h"
#include "Runtime/Director/Core/Property.h"
#include "Runtime/Director/Core/HPlayable.h"
#include "Runtime/Director/Core/Playable.h"
#include "Runtime/Mono/MonoBehaviour.h"

AnimatedPropertyVector3::AnimatedPropertyVector3(UInt32 curveIndex, PPtr<MonoBehaviour> script, PropertyAccessor& accessor)
    : m_CurveIndex(curveIndex)
    , m_ScriptInstance(script->GetInstance())
{
}

void AnimatedPropertyVector3::Update(const HPlayable& playable, const AnimationClip::Vector3Curves& curves)
{
    if (!playable.IsValid())
        return;

    const AnimationClip::Vector3Curve& constfCurve = curves[m_CurveIndex];
    AnimationClip::Vector3Curve& fCurve = const_cast<AnimationClip::Vector3Curve&>(constfCurve);

    int keyCount = fCurve.curve.GetKeyCount();

    if (keyCount == 1)
    {
        const AnimationCurveVec3::Keyframe& kf = fCurve.curve.GetKey(0);
        SetValue(kf.value);
        return;
    }

    float time = playable.GetPlayable()->GetTime();

    fCurve.curve.InvalidateCache();
    Vector3f value = fCurve.curve.Evaluate(time);

    SetValue(value);
}
