#include "UnityPrefix.h"
#include "Runtime/Modules/ModuleRegistration.h"
#include "Runtime/Mono/MonoScriptCache.h"
#include "Runtime/Scripting/CommonScriptingClasses.h"
#include "Runtime/Scripting/Scripting.h"
#include "MecanimAnimation.h"
#include "AnimationScriptingClasses.h"
#include "CalculateAnimatorSkinMatrices.h"

#define UNITY_MODULE_NAME    Animation
#define UNITY_MODULE_STRIPPABLE
#define UNITY_MODULE_INCLUDE "Runtime/Animation/AnimationModule.inc.h"
    #include "Runtime/Modules/ModuleTemplate.inc.h"
#undef UNITY_MODULE_NAME
#undef UNITY_MODULE_INCLUDE

void SetupMonoScriptCacheForAnimation(MonoScriptCache* cache)
{
    cache->isStateMachineBehaviour = scripting_class_is_subclass_of(cache->klass,  GetAnimationScriptingClasses().stateMachineBehaviour);
    cache->sharedBetweenAnimators = scripting_class_has_attribute(cache->klass, GetAnimationScriptingClasses().sharedBetweenAnimatorsAttribute);
}

UNITY_MODULE_INITIALIZE(Animation)
{
    Assert(gCalculateAnimatorSkinMatricesFunc == NULL);
    gCalculateAnimatorSkinMatricesFunc = &DoCalculateAnimatorSkinMatrices;

    SetIAnimation(UNITY_NEW_AS_ROOT_NO_LABEL(MecanimAnimation, kMemAnimation, "AnimationInterface", ""));

    GlobalCallbacks::Get().createMonoScriptCache.Register(SetupMonoScriptCacheForAnimation);
}

UNITY_MODULE_CLEANUP(Animation)
{
    GlobalCallbacks::Get().createMonoScriptCache.Unregister(SetupMonoScriptCacheForAnimation);

    gCalculateAnimatorSkinMatricesFunc = NULL;

    MecanimAnimation* animation = reinterpret_cast<MecanimAnimation*>(GetIAnimation());
    UNITY_DELETE(animation, kMemAnimation);

    SetIAnimation(NULL);
}
