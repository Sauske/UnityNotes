#pragma once

#include "Runtime/mecanim/memory.h"
#include "Runtime/Utilities/Annotations.h"
#include "Runtime/Core/AllocPtr.h"
#include "Runtime/Animation/AnimationSetBinding.h"

enum StateInfoIndex
{
    kCurrentState,
    kNextState,
    kExitState,
    kInterruptedState
};


enum GetSetValueResult
{
    kGetSetSuccess                  = 1 << 0 ,
    kParameterMismatchFailure       = 1 << 1 ,
    kParameterDoesNotExist          = 1 << 2 ,
    kAnimatorNotInitialized         = 1 << 3 ,
    kParameterIsControlledByCurve   = 1 << 4 ,
    kAnimatorInPlaybackMode         = 1 << 5 ,
    kAnimatorControllerNotPresent   = 1 << 6
};


UNITY_INLINE void DeallocateBlobObject(void* ptr, mecanim::memory::Allocator& alloc)
{
    if (ptr != NULL)
        alloc.Deallocate(ptr);
}

template<class TType>
struct MecanimDestroyPolicy
{
    typedef void (*destroy_t)(TType*, mecanim::memory::Allocator& alloc);

    MemLabelId                  m_Label;
    destroy_t                   m_DestroyFunc;

    UNITY_FORCEINLINE MecanimDestroyPolicy()
        : m_Label(kMemAnimation)
        , m_DestroyFunc()
    {   // default construct
    }

    UNITY_FORCEINLINE MecanimDestroyPolicy(MemLabelId label, destroy_t destroy)
        : m_Label(label)
        , m_DestroyFunc(destroy)
    {   // default construct
    }

    template<class TType2>
    UNITY_FORCEINLINE MecanimDestroyPolicy(const MecanimDestroyPolicy<TType2>& other)
        : m_Label(other.m_Label)
        , m_DestroyFunc(other.m_DeleteFunc)
    {   // construct from another
    }

    template<class TType2>
    UNITY_FORCEINLINE MecanimDestroyPolicy(const core::UnitySharedPolicy<TType2>& other)
        : m_Label(kMemAnimation)
        , m_DestroyFunc()
    {   // construct from UnitySharedPolicy, in this case we won't delete the object
    }

    UNITY_FORCEINLINE void operator()(TType *ptr) const
    {
        mecanim::memory::MecanimAllocator alloc(m_Label);

        if (m_DestroyFunc != destroy_t())
            m_DestroyFunc(ptr, alloc);
    }
};

typedef core::AllocPtr<UnityEngine::Animation::AnimationSetBindings, core::UnitySharedPolicy<UnityEngine::Animation::AnimationSetBindings> >    SharedAnimationSetBindingsPtr;
typedef core::AllocPtr<UnityEngine::Animation::AnimationSetBindings, MecanimDestroyPolicy<UnityEngine::Animation::AnimationSetBindings> >       AnimationSetBindingsPtr;
