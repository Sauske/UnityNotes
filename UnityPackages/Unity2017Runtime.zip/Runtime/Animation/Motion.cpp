#include "UnityPrefix.h"
#include "Motion.h"

Motion::Motion(MemLabelId label, ObjectCreationMode mode) : Super(label, mode)
    , m_ObjectUsers(this)
{}

void Motion::ThreadedCleanup()
{
}

void Motion::MainThreadCleanup()
{
    m_ObjectUsers.Clear();
    Super::MainThreadCleanup();
}

void Motion::NotifyObjectUsers(const MessageIdentifier& msg)
{
    m_ObjectUsers.SendMessage(msg);
}

void Motion::AddObjectUser(UserList& user)
{
    m_ObjectUsers.AddUser(user);
}

IMPLEMENT_REGISTER_CLASS(Motion, 207);
