#pragma once

#include "Runtime/Interfaces/IAnimation.h"

struct IAnimatedPropertyEvaluator;

class MecanimAnimation : public IAnimation
{
public:
    MecanimAnimation() {}
    virtual ~MecanimAnimation() {}

    virtual bool PathHashesToIndices(Unity::Component& animator, const BindingHash* bonePathHashes, size_t count, UInt16* outIndices);

    virtual void RegisterIAnimationBinding(const Unity::Type* type, int inCustomType, IAnimationBinding* bindingInterface);

    virtual JobFence& GetReadWriteGlobalSpaceSkeletonPoseFence(Unity::Component* animator);

    virtual IAnimatedPropertyEvaluator* BuildAnimatedProperties(const Object* animationClip, ScriptingObjectPtr target);

    virtual void DeleteAnimatedProperties(IAnimatedPropertyEvaluator*& evaluator);
};
