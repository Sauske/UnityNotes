#pragma once

#include "Runtime/Interfaces/IAnimatedPropertyEvaluator.h"
#include "Runtime/Jobs/JobTypes.h"
#include "Runtime/Animation/AnimationClip.h"


struct JobFence;
class AnimatedPropertyEvaluator;
class PropertyAccessor;
class AnimatedProperty;
class AnimatedPropertyVector3;

typedef dynamic_array<AnimatedProperty*> AnimatedPropertyFloatCollection;

class AnimatedPropertyEvaluator : public IAnimatedPropertyEvaluator
{
public:
    AnimatedPropertyEvaluator();
    virtual ~AnimatedPropertyEvaluator();

    virtual void UpdateSync(float time, ScriptingObjectPtr ptr);

    void Clear();
    void BuildFromScriptableObject(AnimationClip* animationClip, ScriptingObjectPtr ptr);
private:

    bool BindCurveToScriptingObjectPtr(const AnimationClip::FloatCurve& curve, UInt32 curveIndex, ScriptingObjectPtr scriptingObject, bool isNormalized);

    AnimatedPropertyFloatCollection     m_AnimatedPropertiesFloat;
};
