#pragma once


#include "Runtime/Animation/RuntimeAnimatorController.h"
#include "Runtime/Animation/AnimationClipOverride.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/mecanim/memory.h"
#include "Runtime/Misc/UserList.h"
#include <vector>


class AnimationClip;

typedef dynamic_array<PPtr<AnimationClip> > AnimationClipPPtrVector;

namespace UnityEngine
{namespace Animation
{struct AnimationSetBindings; }}


class AnimatorOverrideController : public RuntimeAnimatorController
{
    REGISTER_CLASS(AnimatorOverrideController);
    DECLARE_OBJECT_SERIALIZE();
public:
    static void InitializeClass();
    static void CleanupClass() {}

    AnimatorOverrideController(MemLabelId label, ObjectCreationMode mode);

    virtual void AwakeFromLoad(AwakeFromLoadMode mode);
    virtual void CheckConsistency();

    virtual void MainThreadCleanup();

    virtual mecanim::animation::ControllerConstant* GetAsset(bool forceBuild = true);
    virtual void BuildAsset();
    virtual void ClearAsset();

    virtual SharedAnimationSetBindingsPtr GetAnimationSetBindings();
    virtual AnimationClipPPtrVector const& GetAnimationClips() const;

    virtual core::string    StringFromID(unsigned int ID) const;

    virtual StateMachineBehaviourVector const&  GetBehaviours() const;
    virtual StateMachineBehaviourVectorDescription const&   GetStateMachineBehaviourVectorDescription() const;

    virtual bool                                            HasMultiThreadedStateMachine() const;

    virtual AnimationClipOverrideVector const*      GetAnimationClipOverrideVector() const;

    PPtr<RuntimeAnimatorController> GetAnimatorController() const;
    void SetAnimatorController(PPtr<RuntimeAnimatorController> controller);

    AnimationClipPPtrVector const& GetOriginalClips() const;
    AnimationClipPPtrVector GetOverrideClips() const;

    PPtr<AnimationClip> GetClip(core::string const& name, bool returnEffectiveClip) const;
    void                SetClip(core::string const& name, PPtr<AnimationClip> overrideClip, bool notify = true);

    PPtr<AnimationClip> GetClip(PPtr<AnimationClip> originalClip, bool returnEffectiveClip) const;
    void                SetClip(PPtr<AnimationClip> originalClip, PPtr<AnimationClip> overrideClip, bool notify = true);

    PPtr<AnimationClip> GetOriginalClip(int index) const;
    PPtr<AnimationClip> GetOverrideClip(PPtr<AnimationClip> originalClip) const;

    void                SendNotification();

    void                PerformOverrideClipListCleanup();

    static RuntimeAnimatorController* GetEffectiveController(RuntimeAnimatorController* controller);
protected:


    PPtr<RuntimeAnimatorController>                     m_Controller;

    // This list is a map between m_Controller clips and override clips.
    // We should never rely on this list to return m_Controller clip list because this list may become
    // offsync when an user edit the controller's clip list(either adding or removing a state).
    //
    // The map should only be updated by PerformOverrideClipListCleanup() when user edit the
    // AnimatorOverrideController in the inspector.
    AnimationClipOverrideVector                         m_Clips;

    UnityEngine::Animation::AnimationSetBindings*       m_AnimationSetBindings;
    mecanim::memory::MecanimAllocator                   m_Allocator;
    UserListNode                                        m_AnimationSetNode;

private:
    void ClearMemory();

    void OnInvalidateAnimatorController();

    virtual AnimationClipPPtrVector GetAnimationClipsToRegister() const;

    bool                IsAnOriginalClip(PPtr<AnimationClip> clip) const;
    PPtr<AnimationClip> GetOriginalClip(core::string const& name) const;
    void                SetClipOverride(PPtr<AnimationClip> originalClip, PPtr<AnimationClip> overrideClip, bool notify = true);

    template<class Functor> PPtr<AnimationClip> FindAnimationClipInMap(PPtr<AnimationClip> const& clip, Functor functor, PPtr<AnimationClip> const& defaultClip = PPtr<AnimationClip>()) const;

    mutable AnimationClipPPtrVector m_OriginalAnimationClips;
    mutable AnimationClipPPtrVector m_AnimationClips;
};
