#pragma once

#include "Runtime/Scripting/BindingsDefs.h"

class AnimationClip;
struct HPlayable;

class AnimationPlayableExtensions
{
public:
    static void SetAnimatedPropertiesInternal(HPlayable& playable, AnimationClip* animatedProperties);

private:
    AnimationPlayableExtensions(); // not implemented, this class should not be instantiated.
};

BIND_MANAGED_TYPE_NAME(AnimationPlayableExtensions, UnityEngine_Animations_AnimationPlayableExtensions);
