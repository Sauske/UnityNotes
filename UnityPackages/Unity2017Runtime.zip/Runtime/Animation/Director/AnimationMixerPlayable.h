#pragma once

#include "Runtime/Animation/Director/AnimationPlayable.h"

typedef void (*AnimationMixerPlayableFunc)(AnimationPlayableEvaluationConstant *, AnimationPlayableEvaluationInput *, AnimationPlayableEvaluationOutput *);
typedef void (*AnimationMixerPlayableMixingFunc)(AnimationPlayableEvaluationOutput *, AnimationPlayableEvaluationConstant *, AnimationPlayableEvaluationInput *, AnimationPlayableEvaluationOutput *, mecanim::ValueArrayWeight *valueArrayWeight, float);
typedef void (*AnimationMixerPlayableEndFunc)(AnimationPlayableEvaluationConstant *, AnimationPlayableEvaluationInput *, AnimationPlayableEvaluationOutput *, mecanim::ValueArrayWeight *valueArrayWeight, float);

class AnimationMixerPlayable : public AnimationPlayable
{
public:

    DEFINE_PLAYABLE(AnimationMixerPlayable, GetAnimationScriptingClasses().animationMixerPlayable, AnimationPlayable);

    virtual bool SetInputConnection(Playable* input, int inputPort);

    void  MixerProcess(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output,
        AnimationPlayableProcessFunc processFunc,
        AnimationMixerPlayableFunc emptyMixerFunc,
        AnimationMixerPlayableFunc mixerBeginFunc,
        AnimationMixerPlayableMixingFunc mixerFunc,
        AnimationMixerPlayableEndFunc mixerEndFunc);

    virtual void ProcessRootMotion(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);

    virtual void ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);
};

BIND_MANAGED_TYPE_NAME(AnimationMixerPlayable, UnityEngine_Animations_AnimationMixerPlayable);
