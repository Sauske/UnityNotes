#include "UnityPrefix.h"
#include "Runtime/Animation/Director/AnimationClipPlayable.h"

#include "Runtime/Animation/AnimatorConfigure.h"
#include "Runtime/Animation/AnimationClip.h"
#include "Runtime/Animation/MecanimUtility.h"
#include "Runtime/mecanim/animation/avatar.h"
#include "Runtime/mecanim/statemachine/statemachine.h"---
#include "Runtime/Input/TimeManager.h"

ANIMATOR_PROFILER_INFORMATION_DETAIL(gAnimationClipPlayableProcessRootMotion, "AnimationClipPlayable.ProcessRootMotion", kProfilerAnimation);
ANIMATOR_PROFILER_INFORMATION_DETAIL(gAnimationClipPlayableProcessAnimation, "AnimationClipPlayable.ProcessAnimation", kProfilerAnimation);
ANIMATOR_PROFILER_INFORMATION_DETAIL(gAnimationClipPlayablePrepareAnimationEvents, "AnimationClipPlayable.PrepareAnimationEvents", kProfilerAnimation);

namespace mecanim
{
namespace animation
{
    float EvaluateClip(ClipMuscleConstant const *muscleConstant, ClipMuscleInput const *muscleInput, ClipMemory *clipMemory, ClipOutput *clipOutput, float time)
    {
        float timeInt;
        float normalizedTime = 0;

        ClipInput in;
        in.m_Time = ComputeClipTime(time,
                muscleConstant->m_StartTime,
                muscleConstant->m_StopTime,
                muscleConstant->m_CycleOffset + muscleInput->m_CycleOffset,
                muscleConstant->m_LoopTime,
                muscleInput->m_Speed,
                normalizedTime,
                timeInt,
                muscleInput->m_Time < 0);

        EvaluateClip(muscleConstant->m_Clip.Get(), &in, clipMemory, clipOutput);

        return normalizedTime;
    }

    void EvaluateHuman(ClipMuscleConstant const *muscleConstant, ClipMuscleInput const *muscleInput, ClipOutput const *clipOutput, AnimationNodeState *nodeStateOutput, bool additive)
    {
        EvaluateHumanPose(*muscleConstant, *muscleInput, clipOutput->m_Values, *nodeStateOutput->m_MotionOutput, *nodeStateOutput->m_HumanPose);

        if (additive)
        {
            mecanim::human::HumanPose humanPoseWs;

            if (!muscleConstant->m_ValueArrayReferencePose.IsNull())
            {
                GetHumanPose(*muscleConstant, muscleConstant->m_ValueArrayReferencePose.Get(), humanPoseWs);
            }
            else
            {
                GetHumanPose(*muscleConstant, muscleConstant->m_ValueArrayDelta.Get(), humanPoseWs);
            }

            if (muscleConstant->m_Mirror)
            {
                HumanPoseMirror(humanPoseWs, humanPoseWs);
            }

            nodeStateOutput->m_HumanPose->m_RootX = math::mul(nodeStateOutput->m_MotionOutput->m_MotionX, nodeStateOutput->m_HumanPose->m_RootX);
            HumanPoseSub(*nodeStateOutput->m_HumanPose, *nodeStateOutput->m_HumanPose, humanPoseWs);

            for (mecanim::uint32_t i = 0; i < mecanim::human::kLastGoal; i++)
            {
                nodeStateOutput->m_HumanPose->m_GoalArray[i].m_X = math::trsIdentity();
            }
        }

        if (nodeStateOutput->m_HumanPoseBase != 0)
        {
            mecanim::human::HumanPoseCopy(*nodeStateOutput->m_HumanPoseBase, *nodeStateOutput->m_HumanPose);
        }
    }

    void AdjustPoseForMotion(AvatarConstant const& avatarConstant, SkeletonTQSMap const &tqsMap, math::trsX const &motionX, ValueArray &values, skeleton::SkeletonPose &poseWsA, skeleton::SkeletonPose &poseWsB)
    {
        int lastIndex = avatarConstant.m_RootMotionSkeleton->m_Count - 1;

        SkeletonPoseFromValueRecursive(*avatarConstant.m_RootMotionSkeleton.Get(), *avatarConstant.m_AvatarSkeletonPose.Get(), values, &tqsMap, avatarConstant.m_RootMotionSkeletonIndexArray.Get(), poseWsA, lastIndex, 0);

        skeleton::SkeletonPoseComputeGlobal(avatarConstant.m_RootMotionSkeleton.Get(), &poseWsA, &poseWsB);
        poseWsA.m_X[0] = motionX;

        ////////////////////////////////////////////////////
        // case 903883: Animation starts sliding in Blend Tree preview when having more that two animations
        // force nodes between root and root motion node to their default values
        skeleton::SkeletonPose const *defaultPose = avatarConstant.m_DefaultPose.Get();
        int32_t const *indexArray = avatarConstant.m_RootMotionSkeletonIndexArray.Get();

        for (int skIter = 1 /* skip root */; skIter < lastIndex /* skip last */; skIter++)
        {
            poseWsA.m_X[skIter] = defaultPose->m_X[indexArray[skIter]];
        }
        ////////////////////////////////////////////////////

        if (avatarConstant.m_RootMotionBoneIndex > 0)
            skeleton::SkeletonPoseComputeGlobal(avatarConstant.m_RootMotionSkeleton.Get(), &poseWsA, &poseWsB, lastIndex - 1, 0);

        skeleton::SkeletonPoseComputeLocal(avatarConstant.m_RootMotionSkeleton.Get(), &poseWsB, &poseWsA, lastIndex, lastIndex);
        poseWsA.m_X[0] = math::trsIdentity();

        ValueFromSkeletonPoseRecursive(*avatarConstant.m_RootMotionSkeleton.Get(), poseWsA, &tqsMap, avatarConstant.m_RootMotionSkeletonIndexArray.Get(), values, lastIndex, 0);
    }

    void ComputeRootMotionValues(AvatarConstant const& avatarConstant, SkeletonTQSMap const &tqsMap, MotionOutput const &motionOutput, ValueArray &values, ValueArray &startValues, ValueArray &stopValues, bool loop)
    {
        memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);

        skeleton::SkeletonPose *poseWsA = mecanim::skeleton::CreateSkeletonPose<math::trsX>(avatarConstant.m_RootMotionSkeleton.Get(), tempAllocator);
        skeleton::SkeletonPose *poseWsB = mecanim::skeleton::CreateSkeletonPose<math::trsX>(avatarConstant.m_RootMotionSkeleton.Get(), tempAllocator);

        if (loop)
        {
            AdjustPoseForMotion(avatarConstant, tqsMap, motionOutput.m_MotionStartX, startValues, *poseWsA, *poseWsB);
            AdjustPoseForMotion(avatarConstant, tqsMap, motionOutput.m_MotionStopX, stopValues, *poseWsA, *poseWsB);
        }

        AdjustPoseForMotion(avatarConstant, tqsMap, motionOutput.m_MotionX, values, *poseWsA, *poseWsB);

        skeleton::DestroySkeletonPose(poseWsA, tempAllocator);
        skeleton::DestroySkeletonPose(poseWsB, tempAllocator);
    }

    void EvaluateFloatValues(ClipMuscleConstant const *muscleConstant,
        ValueArrayConstant const *values,
        ClipBindings const *clipBindings,
        ClipOutput const *clipOutput,
        AnimationNodeState *nodeStateOutput,
        float normalizedTime,
        bool additive,
        bool loop)
    {
        memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);

        mecanim::ValueArray *valuesStartWs = 0;
        mecanim::ValueArray *valuesStopWs = 0;
        mecanim::ValueArray *valuesAdditiveReferencePose = 0;

        if (additive || loop)
        {
            valuesStartWs =  CreateFloatValueArray(values, tempAllocator);
            valuesStopWs =  CreateFloatValueArray(values, tempAllocator);
            valuesAdditiveReferencePose =  CreateFloatValueArray(values, tempAllocator);

            DeltasFromClip<true>(*muscleConstant, *clipBindings, *nodeStateOutput->m_DynamicValuesMask, *valuesStartWs, *valuesStopWs, *valuesAdditiveReferencePose);
        }

        if (additive)
        {
            ValueArraySub<true>(*valuesAdditiveReferencePose, nodeStateOutput->m_DynamicValuesMask, *nodeStateOutput->m_DynamicValues);
        }

        if (loop)
        {
            ValueArrayLoop<true>(*valuesStartWs, *valuesStopWs, *nodeStateOutput->m_DynamicValuesMask, *nodeStateOutput->m_DynamicValues, normalizedTime);
        }

        DestroyValueArray(valuesStartWs, tempAllocator);
        DestroyValueArray(valuesStopWs, tempAllocator);
        DestroyValueArray(valuesAdditiveReferencePose, tempAllocator);
    }

    void EvaluateTransformValues(int32_t positionValueIndex,
        int32_t rotationValueIndex,
        int32_t scaleValueIndex,
        ClipMuscleConstant const *muscleConstant,
        ValueArrayConstant const *values,
        ClipBindings const *clipBindings,
        ClipOutput const *clipOutput,
        AnimationNodeState *nodeStateOutput,
        float normalizedTime,
        bool additive,
        bool loop)
    {
        memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);

        math::trsX startX;
        math::trsX stopX;
        math::trsX addX;

        if (additive || loop)
        {
            TransformDeltasFromClip(positionValueIndex, rotationValueIndex, scaleValueIndex, *muscleConstant, *clipBindings, *nodeStateOutput->m_DynamicValuesMask, startX, stopX, addX);
        }

        if (additive)
        {
            TransformValueArraySub(positionValueIndex, rotationValueIndex, scaleValueIndex, addX, *nodeStateOutput->m_DynamicValues);
        }

        if (loop)
        {
            TransformValueArrayLoop(positionValueIndex, rotationValueIndex, scaleValueIndex, startX, stopX, *nodeStateOutput->m_DynamicValues, normalizedTime);
        }
    }

    void EvaluateValues(ClipMuscleConstant const *muscleConstant,
        ValueArrayConstant const *values,
        ClipBindings const *clipBindings,
        AvatarConstant const *avatarConstant,
        SkeletonTQSMap const *tqsMap,
        ClipOutput const *clipOutput,
        AnimationNodeState *nodeStateOutput,
        float normalizedTime,
        bool hasRootMotion,
        bool additive,
        bool loop)
    {
        memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);

        mecanim::ValueArray *valuesStartWs = 0;
        mecanim::ValueArray *valuesStopWs = 0;
        mecanim::ValueArray *valuesAdditiveReferencePose = 0;

        if (additive || loop)
        {
            valuesStartWs =  CreateValueArray(values, tempAllocator);
            valuesStopWs =  CreateValueArray(values, tempAllocator);
            valuesAdditiveReferencePose =  CreateValueArray(values, tempAllocator);

            DeltasFromClip<false>(*muscleConstant, *clipBindings, *nodeStateOutput->m_DynamicValuesMask, *valuesStartWs, *valuesStopWs, *valuesAdditiveReferencePose);
        }

        if (hasRootMotion && !additive)
        {
            if (avatarConstant->m_RootMotionBoneIndex != -1)
            {
                ComputeRootMotionValues(*avatarConstant, *tqsMap, *nodeStateOutput->m_MotionOutput, *nodeStateOutput->m_DynamicValues, *valuesStartWs, *valuesStopWs, loop);
            }
        }

        if (additive)
        {
            ValueArraySub<false>(*valuesAdditiveReferencePose, nodeStateOutput->m_DynamicValuesMask, *nodeStateOutput->m_DynamicValues);
        }

        if (loop)
        {
            ValueArrayLoop<false>(*valuesStartWs, *valuesStopWs, *nodeStateOutput->m_DynamicValuesMask, *nodeStateOutput->m_DynamicValues, normalizedTime);
        }

        DestroyValueArray(valuesStartWs, tempAllocator);
        DestroyValueArray(valuesStopWs, tempAllocator);
        DestroyValueArray(valuesAdditiveReferencePose, tempAllocator);
    }
}
}

AnimationClipPlayable::AnimationClipPlayable(DirectorPlayerType playerType)
    : AnimationPlayable(playerType)
    , m_AnimationClip(NULL)
    , m_ApplyFootIK(true)
    , m_RemoveStartOffset(false)
    , m_HumanReadMask(false)
    , m_MotionReadMask(false)
{
#if ANIMATION_PLAYABLE_SANITY_CHECK
    m_Type = eAnimationClipPlayable;
#endif
    SetScriptRestrictionFlags(kCantChangeTopology || kCantChangeWeights);
}

void AnimationClipPlayable::SetClip(AnimationClip* clip)
{
    if (m_AnimationClip != clip)
    {
        m_AnimationClip = clip;
        RequestAllocateBindings();
    }
}

NamedObject* AnimationClipPlayable::GetAsset() const
{
    return m_AnimationClip;
}

void AnimationClipPlayable::SetStateMachineMessage(mecanim::statemachine::StateMachineMessage message)
{
    m_AnimationClipMemory.m_MessageID = message;
}

void AnimationClipPlayable::OnAdvanceTime(double delta)
{
    if (!TimeHasBeenSet())
    {
        m_AnimationClipMemory.m_LastTime    = m_LocalTime;

        SetStateMachineMessage(mecanim::statemachine::kInvalid);
        if (m_AnimationClipMemory.m_FirstEval == mecanim::statemachine::kFirstEval)
            m_AnimationClipMemory.m_FirstEval = mecanim::statemachine::kFirstEvalCompleted;

        bool deltaTimeIs0 = delta == 0;
        if (m_AnimationClipMemory.m_FirstEval == mecanim::statemachine::kWaitForTick && !deltaTimeIs0)
        {
            SetStateMachineMessage(mecanim::statemachine::kOnStateEnter);
            m_AnimationClipMemory.m_FirstEval = mecanim::statemachine::kFirstEval;
        }
    }

    Playable::OnAdvanceTime(delta);
}

void AnimationClipPlayable::ProcessRootMotionNoClip(AnimationPlayableEvaluationConstant const *constant,
    AnimationPlayableEvaluationInput const *input,
    AnimationPlayableEvaluationOutput *output)
{
    ClearMotionOutput(output->nodeStateOutput);

    if (constant->hasRootTransformValues || input->hasControllerParameters)
    {
        mecanim::SetValueMask<false>(output->nodeStateOutput->m_DynamicValuesMask, false);

        bool useLastEval = !m_AnimationClipMemory.m_WriteDefaultValues;

        mecanim::SetTransformValueMask(constant->rootPositionValueIndex,
            constant->rootRotationValueIndex,
            constant->rootScaleValueIndex,
            output->nodeStateOutput->m_DynamicValuesMask,
            useLastEval);

        if (useLastEval)
        {
            mecanim::TransformValueArrayCopy(constant->rootPositionValueIndex,
                constant->rootRotationValueIndex,
                constant->rootScaleValueIndex,
                input->lastEvaluationValues,
                output->nodeStateOutput->m_DynamicValues);

            if (input->hasControllerParameters)
            {
                mecanim::CopyValueMask<true>(input->passValueMask, output->nodeStateOutput->m_DynamicValuesMask);
                mecanim::ValueArrayCopy<true>(input->lastEvaluationValues, output->nodeStateOutput->m_DynamicValues, output->nodeStateOutput->m_DynamicValuesMask);
            }
        }
    }
}

void AnimationClipPlayable::ProcessAnimationNoClip(AnimationPlayableEvaluationConstant const *constant,
    AnimationPlayableEvaluationInput const *input,
    AnimationPlayableEvaluationOutput *output)
{
    bool useLastEval = !m_AnimationClipMemory.m_WriteDefaultValues;

    if (useLastEval)
    {
        mecanim::SetValueMask<false>(output->nodeStateOutput->m_DynamicValuesMask, true);

        mecanim::SetTransformValueMask(constant->rootPositionValueIndex,
            constant->rootRotationValueIndex,
            constant->rootScaleValueIndex,
            output->nodeStateOutput->m_DynamicValuesMask,
            false);

        mecanim::CopyValueMask<true>(input->passValueMask, output->nodeStateOutput->m_DynamicValuesMask);

        mecanim::ValueArrayCopy<false>(input->lastEvaluationValues, output->nodeStateOutput->m_DynamicValues, output->nodeStateOutput->m_DynamicValuesMask);
    }
    else
    {
        mecanim::SetValueMask<false>(output->nodeStateOutput->m_DynamicValuesMask, false);
    }
}

void AnimationClipPlayable::ProcessAnimationClipInputPrepare(AnimationPlayableEvaluationConstant const *constant,
    mecanim::animation::ClipMuscleInput *muscleInput)
{
    float clipDuration = m_AnimationClip->GetAverageDuration();
    muscleInput->m_Time = clipDuration != 0 ? m_LocalTime / clipDuration : 0.0f;
    muscleInput->m_PreviousTime = clipDuration != 0 ? m_AnimationClipMemory.m_LastTime / clipDuration : 0.0f;

    muscleInput->m_CycleOffset = m_AnimationClipMemory.m_CycleOffset;
    muscleInput->m_Speed = m_AnimationClipMemory.m_Speed;
    muscleInput->m_Mirror = m_AnimationClipMemory.m_Mirror;
    muscleInput->m_ComputeCycleX = constant->applyMotionX;
    muscleInput->m_RemoveStartOffset = m_RemoveStartOffset;
}

void AnimationClipPlayable::ProcessAnimationRootMotionPass(AnimationPlayableEvaluationConstant const *constant,
    AnimationPlayableEvaluationInput const *input,
    AnimationPlayableEvaluationOutput *output)
{
    bool hasRootMotion = constant->hasRootMotion;
    bool isHuman = constant->isHuman;
    bool evaluateRootMotion = hasRootMotion || isHuman;

    output->nodeStateOutput->m_MotionReadMask |= m_MotionReadMask;

    if (m_AnimationClipMemory.muscleConstant == 0)
    {
        ProcessRootMotionNoClip(constant, input, output);
    }
    else
    {
        mecanim::memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);

        mecanim::animation::ClipMuscleConstant const &muscleConstant = *m_AnimationClipMemory.muscleConstant;
        mecanim::animation::ClipMuscleInput muscleInput;

        ProcessAnimationClipInputPrepare(constant, &muscleInput);

        bool additive = input->additive;
        bool loop = muscleConstant.m_LoopTime && muscleConstant.m_LoopBlend;

        mecanim::animation::AnimationNodeState &nodeStateOutput = *output->nodeStateOutput;
        mecanim::animation::MotionOutput *motionOutput = nodeStateOutput.m_MotionOutput;
        mecanim::ValueArray *valuesOutput = nodeStateOutput.m_DynamicValues;

        mecanim::animation::Clip const *clip = muscleConstant.m_Clip.Get();
        mecanim::animation::ClipMemory& clipMemory = *m_AnimationClipMemory.clipMemory;
        mecanim::animation::ClipOutput *clipOutputPrev = 0;
        mecanim::animation::ClipOutput *clipOutput = m_AnimationClipMemory.clipOutputCache;

        if (evaluateRootMotion)
        {
            clipOutputPrev = mecanim::animation::CreateClipOutput(clip, tempAllocator);
            EvaluateClip(&muscleConstant, &muscleInput, &clipMemory, clipOutputPrev, muscleInput.m_PreviousTime);
        }

        m_AnimationClipMemory.normalizedTime = EvaluateClip(&muscleConstant, &muscleInput, &clipMemory, clipOutput, muscleInput.m_Time);

        mecanim::animation::ClipBindings const &clipBindings = *m_AnimationClipMemory.clipBindings;

        if (constant->hasRootTransformValues || input->hasControllerParameters)
        {
            mecanim::ValueArray const &defaultValues = input->defaultValuesOverride != NULL ?  *input->defaultValuesOverride : *constant->defaultValues;

            mecanim::ValueArray const &fallbackValues = (!additive && !m_AnimationClipMemory.m_WriteDefaultValues && input->lastEvaluationValues) ? *input->lastEvaluationValues : defaultValues;

            mecanim::SetValueMask<false>(output->nodeStateOutput->m_DynamicValuesMask, false);

            TransformValuesFromClip(constant->rootPositionValueIndex,
                constant->rootRotationValueIndex,
                constant->rootScaleValueIndex,
                fallbackValues,
                *clipOutput,
                clipBindings,
                *valuesOutput,
                *nodeStateOutput.m_DynamicValuesMask,
                !m_AnimationClipMemory.m_WriteDefaultValues);

            if (input->hasControllerParameters)
            {
                mecanim::animation::ValuesFromClip<true>(fallbackValues,
                    *clipOutput,
                    clipBindings,
                    0,
                    *valuesOutput,
                    *nodeStateOutput.m_DynamicValuesMask,
                    !m_AnimationClipMemory.m_WriteDefaultValues,
                    input->passValueMask);
            }
        }

        if (evaluateRootMotion)
        {
            EvaluateRootMotion(muscleConstant, muscleInput, clipOutputPrev->m_Values, clipOutput->m_Values, *motionOutput, isHuman);
            mecanim::animation::DestroyClipOutput(clipOutputPrev, tempAllocator);

            if (!input->avatarInput->m_LinearVelocityBlending)
            {
                motionOutput->m_Velocity *= motionOutput->m_DeltaTime;
                motionOutput->m_AngularVelocity *= motionOutput->m_DeltaTime;
            }

            mecanim::int32_t gravityWeightIndex = constant->gravityWeightIndex;

            if (input->hasControllerParameters && gravityWeightIndex != -1 && nodeStateOutput.m_DynamicValuesMask->m_FloatValues[gravityWeightIndex])
            {
                valuesOutput->ReadData(motionOutput->m_GravityWeight, gravityWeightIndex);
            }
            else if (isHuman || constant->avatarConstant->m_RootMotionBoneIndex != -1)
            {
                motionOutput->m_GravityWeight =  muscleConstant.m_LoopBlendPositionY ? 1 : 0;
            }
            else
            {
                motionOutput->m_GravityWeight =  1.0f;
            }

            if (additive)
            {
                mecanim::animation::MotionOutputClearAdditiveLayer(motionOutput);
            }
        }

        if (constant->hasRootTransformValues || input->hasControllerParameters)
        {
            EvaluateTransformValues(constant->rootPositionValueIndex,
                constant->rootRotationValueIndex,
                constant->rootScaleValueIndex,
                &muscleConstant,
                constant->values,
                &clipBindings,
                clipOutput,
                &nodeStateOutput,
                m_AnimationClipMemory.normalizedTime,
                additive,
                loop);

            if (input->hasControllerParameters)
            {
                EvaluateFloatValues(&muscleConstant,
                    constant->values,
                    &clipBindings,
                    clipOutput,
                    &nodeStateOutput,
                    m_AnimationClipMemory.normalizedTime,
                    additive,
                    loop);
            }
        }

        if (evaluateRootMotion)
        {
            mecanim::animation::MotionOutputCopy(m_AnimationClipMemory.motionOutputCache, output->nodeStateOutput->m_MotionOutput, hasRootMotion, isHuman, mecanim::human::FullBodyMask());
        }
    }
}

void AnimationClipPlayable::ProcessAnimationTargetMatchPass(AnimationPlayableEvaluationConstant const *constant,
    AnimationPlayableEvaluationInput const *input,
    AnimationPlayableEvaluationOutput *output)
{
    if (m_AnimationClipMemory.muscleConstant == 0)
        return;

    if (input->avatarInput->m_TargetIndex != -1)
    {
        bool hasRootMotion = constant->hasRootMotion;
        bool isHuman = constant->isHuman;

        if (hasRootMotion || isHuman)
        {
            mecanim::memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);

            bool isHuman = constant->isHuman;

            mecanim::animation::ClipMuscleConstant const &muscleConstant = *m_AnimationClipMemory.muscleConstant;
            mecanim::animation::Clip const *clip = muscleConstant.m_Clip.Get();

            mecanim::animation::ClipMuscleInput muscleInput;
            ProcessAnimationClipInputPrepare(constant, &muscleInput);

            mecanim::animation::MotionOutput *motionOutput = output->nodeStateOutput->m_MotionOutput;

            mecanim::animation::ClipMemory *clipMemory = mecanim::animation::CloneClipMemory(m_AnimationClipMemory.clipMemory, tempAllocator);
            mecanim::animation::ClipOutput *clipOutput = mecanim::animation::CreateClipOutput(clip, tempAllocator);

            EvaluateClip(&muscleConstant, &muscleInput, clipMemory, clipOutput, input->avatarInput->m_TargetTime);

            muscleInput.m_ComputeCycleX = true;
            muscleInput.m_PreviousTime = input->avatarInput->m_TargetTime;
            muscleInput.m_Time = input->avatarInput->m_TargetTime;

            mecanim::animation::MotionOutput motionOutputTarget;
            mecanim::human::HumanPose humanPoseTarget;

            EvaluateRootMotion(muscleConstant, muscleInput, clipOutput->m_Values, clipOutput->m_Values, motionOutputTarget, isHuman);

            motionOutput->m_TargetX = motionOutputTarget.m_MotionX;

            if (isHuman && input->avatarInput->m_TargetIndex > mecanim::animation::kTargetReference && input->avatarInput->m_TargetIndex <= mecanim::animation::kTargetRightHand)
            {
                EvaluateHumanPose(muscleConstant, muscleInput, clipOutput->m_Values, motionOutputTarget, humanPoseTarget);

                if (input->avatarInput->m_TargetIndex > mecanim::animation::kTargetRoot)
                {
                    int32_t targetGoalIndex = input->avatarInput->m_TargetIndex - mecanim::animation::kTargetLeftFoot;

                    motionOutput->m_TargetX = math::mul(motionOutput->m_TargetX, humanPoseTarget.m_GoalArray[targetGoalIndex].m_X);
                }
                else
                {
                    motionOutput->m_TargetX = math::mul(motionOutput->m_TargetX, humanPoseTarget.m_RootX);
                }
            }

            motionOutput->m_TargetX = math::invMul(motionOutput->m_MotionX, motionOutput->m_TargetX);

            mecanim::animation::DestroyClipOutput(clipOutput, tempAllocator);
            mecanim::animation::DestroyClipMemory(clipMemory, tempAllocator);
        }
    }
}

void AnimationClipPlayable::ProcessAnimationPass(AnimationPlayableEvaluationConstant const *constant,
    AnimationPlayableEvaluationInput const *input,
    AnimationPlayableEvaluationOutput *output)
{
    if (m_AnimationClipMemory.muscleConstant == 0)
    {
        ProcessAnimationNoClip(constant, input, output);
    }
    else
    {
        bool hasRootMotion = constant->hasRootMotion;

        if (hasRootMotion)
        {
            mecanim::animation::MotionOutputCopy(output->nodeStateOutput->m_MotionOutput, m_AnimationClipMemory.motionOutputCache, hasRootMotion, false, mecanim::human::FullBodyMask());
        }

        mecanim::animation::ClipMuscleConstant const &muscleConstant = *m_AnimationClipMemory.muscleConstant;
        mecanim::animation::ClipMuscleInput muscleInput;
        ProcessAnimationClipInputPrepare(constant, &muscleInput);

        bool additive = input->additive;

        mecanim::animation::AnimationNodeState &nodeStateOutput = *output->nodeStateOutput;

        mecanim::animation::ClipOutput *clipOutput = m_AnimationClipMemory.clipOutputCache;

        mecanim::animation::ClipBindings const &clipBindings = *m_AnimationClipMemory.clipBindings;
        mecanim::ValueArray const &defaultValues = *constant->defaultValues;
        mecanim::int32_t integerRemapStride = constant->integerRemapStride;

        mecanim::ValueArray *valuesOutput = nodeStateOutput.m_DynamicValues;
        bool loop = muscleConstant.m_LoopTime && muscleConstant.m_LoopBlend;

        mecanim::ValueArray const &fallbackValues = (!additive && !m_AnimationClipMemory.m_WriteDefaultValues && input->lastEvaluationValues) ? *input->lastEvaluationValues : defaultValues;

        mecanim::animation::ValuesFromClip<false>(fallbackValues,
            *clipOutput,
            clipBindings,
            integerRemapStride,
            *valuesOutput,
            *nodeStateOutput.m_DynamicValuesMask,
            !m_AnimationClipMemory.m_WriteDefaultValues,
            input->passValueMask);

        EvaluateValues(&muscleConstant,
            constant->values,
            &clipBindings,
            constant->avatarConstant,
            constant->tqsMap,
            clipOutput,
            &nodeStateOutput,
            m_AnimationClipMemory.normalizedTime,
            hasRootMotion,
            additive,
            loop);
    }
}

void AnimationClipPlayable::ProcessHumanPass(AnimationPlayableEvaluationConstant const *constant,
    AnimationPlayableEvaluationInput const *input,
    AnimationPlayableEvaluationOutput *output)
{
    output->m_IKOnFeet |= m_ApplyFootIK;
    output->nodeStateOutput->m_HumanReadMask |= m_HumanReadMask;

    if (m_AnimationClipMemory.muscleConstant == 0)
    {
        ClearMotionOutput(output->nodeStateOutput);
        ClearHumanPoses(output->nodeStateOutput);
    }
    else
    {
        mecanim::animation::MotionOutputCopy(output->nodeStateOutput->m_MotionOutput, m_AnimationClipMemory.motionOutputCache, false, true, mecanim::human::FullBodyMask());

        mecanim::animation::ClipMuscleConstant const &muscleConstant = *m_AnimationClipMemory.muscleConstant;
        mecanim::animation::ClipMuscleInput muscleInput;
        ProcessAnimationClipInputPrepare(constant, &muscleInput);

        bool additive = input->additive;

        mecanim::animation::AnimationNodeState &nodeStateOutput = *output->nodeStateOutput;
        mecanim::animation::ClipOutput *clipOutput = m_AnimationClipMemory.clipOutputCache;

        EvaluateHuman(&muscleConstant, &muscleInput, clipOutput, &nodeStateOutput, additive);
    }
}

void AnimationClipPlayable::ProcessRootMotion(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    ANIMATOR_PROFILER_AUTO_DETAIL(gAnimationClipPlayableProcessRootMotion, NULL);

    ProcessAnimationRootMotionPass(constant, input, output);
    ProcessAnimationTargetMatchPass(constant, input, output);

    m_AnimationClipMemory.rootMotionProcessed = true;
}

void AnimationClipPlayable::ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    ANIMATOR_PROFILER_AUTO_DETAIL(gAnimationClipPlayableProcessAnimation, NULL);

    if (!m_AnimationClipMemory.rootMotionProcessed)
    {
        ProcessRootMotion(constant, input, output);
    }

    ProcessAnimationPass(constant, input, output);

    if (constant->isHuman)
    {
        ProcessHumanPass(constant, input, output);
    }

    m_AnimationClipMemory.rootMotionProcessed = false;
}

void AnimationClipPlayable::PrepareAnimationEvents(float weight, AnimationClipEventInfos& eventInfos)
{
    if (m_AnimationClip == NULL || m_AnimationClipMemory.muscleConstant == NULL || !m_AnimationClip->HasAnimationEvents())
        return;

    bool isExitingState = FilteredMessageId(m_AnimationClipMemory.m_MessageID, mecanim::statemachine::kOnStateExit) == mecanim::statemachine::kOnStateExit;
    bool isEnteringState = FilteredMessageId(m_AnimationClipMemory.m_MessageID, mecanim::statemachine::kOnStateEnter) == mecanim::statemachine::kOnStateEnter;

    // nothing can be fired until we get a first eval with a delta time != 0
    if (m_AnimationClipMemory.m_FirstEval != mecanim::statemachine::kWaitForTick && (weight > 0  || isExitingState || isEnteringState))
    {
        ANIMATOR_PROFILER_AUTO_DETAIL(gAnimationClipPlayablePrepareAnimationEvents, NULL);

        AnimationClipEventInfo& eventInfo = eventInfos.emplace_back_uninitialized();
        eventInfo.m_AnimationClip = m_AnimationClip;
        eventInfo.m_StateInfo = m_AnimationClipMemory.m_StateInfo;

        float speedMultiplier = m_AnimationClipMemory.m_StateMachineMemory == NULL ? 1.0f : eventInfo.m_StateInfo.speedMultiplier;
        const float duration = m_AnimationClip->GetAverageDuration();

        eventInfo.m_ClipInfo.clip = m_AnimationClip;
        eventInfo.m_ClipInfo.weight = weight;

        float dummy;

        if (m_AnimationClipMemory.m_LastParameterizedTime >= 0.0f)
        {
            eventInfo.m_LastTime    = m_AnimationClipMemory.m_LastParameterizedTime;
            eventInfo.m_CurrenTime  = m_AnimationClipMemory.m_CurrentParameterizedTime;
        }
        else
        {
            eventInfo.m_LastTime    = m_AnimationClipMemory.m_LastTime;
            eventInfo.m_CurrenTime  = m_LocalTime;
            eventInfo.m_LastTime    /= duration != 0 ? duration : 1.0f;
            eventInfo.m_CurrenTime  /= duration != 0 ? duration : 1.0f;
        }

        eventInfo.m_PlaybackSpeed = m_AnimationClipMemory.m_Speed * speedMultiplier;
        eventInfo.m_LoopLastTime = true;


        const float cycleOffset = m_AnimationClipMemory.muscleConstant->m_CycleOffset + m_AnimationClipMemory.m_CycleOffset;

        float lastTimeLoop = 0;
        float currentTimeLoop = 0;

        eventInfo.m_LastTime = mecanim::animation::ComputeClipTime(eventInfo.m_LastTime, m_AnimationClipMemory.muscleConstant->m_StartTime, m_AnimationClipMemory.muscleConstant->m_StopTime,
                cycleOffset,
                m_AnimationClipMemory.muscleConstant->m_LoopTime, m_AnimationClipMemory.m_Speed,
                dummy, lastTimeLoop, m_LocalTime < 0);

        eventInfo.m_CurrenTime = mecanim::animation::ComputeClipTime(eventInfo.m_CurrenTime, m_AnimationClipMemory.muscleConstant->m_StartTime, m_AnimationClipMemory.muscleConstant->m_StopTime,
                cycleOffset,
                m_AnimationClipMemory.muscleConstant->m_LoopTime, m_AnimationClipMemory.m_Speed,
                dummy, currentTimeLoop, m_LocalTime < 0);

        // m_LastTime is always is clip range, m_CurrentTime is rebased on it
        if (currentTimeLoop > lastTimeLoop && eventInfo.m_PlaybackSpeed > 0)
        {
            eventInfo.m_CurrenTime += (currentTimeLoop - lastTimeLoop) * duration;
        }
        else if (currentTimeLoop < lastTimeLoop && eventInfo.m_PlaybackSpeed < 0)
        {
            eventInfo.m_CurrenTime -= (lastTimeLoop - currentTimeLoop) * duration;
        }

        // Handle special cases.
        // Clip range is [0, 0] or [1, 1] when we start to play a new state, this is not handled correctly by animation clip FireEvent function.
        // We have to cheat the clip range
        // case 676489
        bool playingForward = math::chgsign(1.0f, eventInfo.m_PlaybackSpeed) > 0.0f;
        if (isEnteringState && playingForward)
        {
            eventInfo.m_LastTime -= math::epsilon_second();
        }
        else if (isEnteringState && !playingForward)
        {
            eventInfo.m_LastTime += math::epsilon_second();
        }
        else if (isExitingState && m_AnimationClipMemory.muscleConstant->m_LoopTime)
        {
            mecanim::statemachine::StateMachineMemory const * stateMachineMemory = m_AnimationClipMemory.m_StateMachineMemory;

            float timeInt = 0.f;
            float denormalizeStartTime = mecanim::animation::ComputeClipTime(stateMachineMemory->m_TransitionStartTime, m_AnimationClipMemory.muscleConstant->m_StartTime, m_AnimationClipMemory.muscleConstant->m_StopTime, cycleOffset, m_AnimationClipMemory.muscleConstant->m_LoopTime, m_AnimationClipMemory.m_Speed, dummy, timeInt, stateMachineMemory->m_TransitionStartTime < 0);

            // case 745781: transitions have exit time of 1 and transitions duration is 0
            timeInt = timeInt != 0.f && denormalizeStartTime == 0.f ? 1.0f : 0.0f;

            float denormalizeTransitionDuration = stateMachineMemory->m_FixedTransition ? stateMachineMemory->m_TransitionDuration : stateMachineMemory->m_TransitionDuration * duration;
            float denormalizeStopTime = (timeInt * duration) + denormalizeStartTime + denormalizeTransitionDuration;

            // case 909973: snap exit time to clip stop time if we are really close
            // In this particular case there is a precision issue due to a difference between how mono and c++ trunc value for transition exit time.
            if (math::abs(denormalizeStopTime - m_AnimationClipMemory.muscleConstant->m_StopTime) < math::epsilon_second())
                denormalizeStopTime = m_AnimationClipMemory.muscleConstant->m_StopTime;


            // Find Transition stop time, do not send event after this time since clip weight should be 0
            if (eventInfo.m_CurrenTime >= denormalizeStopTime)
            {
                eventInfo.m_CurrenTime = denormalizeStopTime;

                // Don't loop when we are exiting and on the end of the clip.
                if (math::modf(eventInfo.m_CurrenTime / duration, dummy) == 0.0f)
                    eventInfo.m_LoopLastTime = false;

                if (eventInfo.m_LastTime > eventInfo.m_CurrenTime)
                {
                    eventInfo.m_LastTime = eventInfo.m_CurrenTime;
                }
            }
        }
    }

    AnimationPlayable::PrepareAnimationEvents(weight, eventInfos);
}

void AnimationClipPlayable::AllocateBindings(AnimationPlayableEvaluationConstant const *constant)
{
    m_AnimationClipMemory.rootMotionProcessed = false;

    if (!m_BindingsAllocated && m_AnimationClip != NULL)
    {
        for (int i = 0; i < constant->clipCount; ++i)
        {
            mecanim::animation::AnimationSet::Clip const& setClip = constant->clipArray[i];
            if (setClip.m_AnimationClip == m_AnimationClip && m_AnimationClip != 0 && m_AnimationClip->IsMecanimDataValid())
            {
                m_AnimationClipMemory.muscleConstant =  m_AnimationClip->GetRuntimeAsset();

                m_MotionReadMask |= mecanim::animation::HasMotionCurves(*m_AnimationClipMemory.muscleConstant);
                m_MotionReadMask |= mecanim::animation::HasRootCurves(*m_AnimationClipMemory.muscleConstant);
                m_HumanReadMask |= mecanim::animation::HasHumanCurves(*m_AnimationClipMemory.muscleConstant);

                m_AnimationClipMemory.clipBindings = &setClip.m_Bindings;

                mecanim::uint32_t usedCurves = constant->allowConstantCurveOptimization ? setClip.m_TotalUsedOptimizedCurveCount : mecanim::animation::GetClipCurveCount(*m_AnimationClipMemory.muscleConstant);
                m_AnimationClipMemory.clipMemory = m_AnimationClipMemory.muscleConstant != 0 ? mecanim::animation::CreateClipMemory(m_AnimationClipMemory.muscleConstant->m_Clip.Get(), usedCurves, m_Allocator) : 0;

                m_AnimationClipMemory.clipOutputCache = m_AnimationClipMemory.muscleConstant != 0 ? mecanim::animation::CreateClipOutput(m_AnimationClipMemory.muscleConstant->m_Clip.Get(), m_Allocator) : 0;

                if (constant->hasRootMotion || constant->isHuman)
                {
                    m_AnimationClipMemory.motionOutputCache = m_Allocator.Construct<mecanim::animation::MotionOutput>();
                }
                break;
            }
        }

        AnimationPlayable::AllocateBindings(constant);
    }
}

void AnimationClipPlayable::DeallocateBindings()
{
    if (m_BindingsAllocated)
    {
        mecanim::animation::DestroyClipMemory(m_AnimationClipMemory.clipMemory, m_Allocator);
        m_AnimationClipMemory.clipMemory = 0;
        mecanim::animation::DestroyClipOutput(m_AnimationClipMemory.clipOutputCache, m_Allocator);
        m_AnimationClipMemory.clipOutputCache = 0;
        m_Allocator.Deallocate(m_AnimationClipMemory.motionOutputCache);
        m_AnimationClipMemory.motionOutputCache = 0;
        m_AnimationClipMemory.muscleConstant = 0;
        m_AnimationClipMemory.clipBindings = 0;
    }
    AnimationPlayable::DeallocateBindings();
}

void AnimationClipPlayable::SetTime(double time)
{
    m_AnimationClipMemory.m_LastTime    = m_LocalTime;
    Playable::SetTime(time);
}

void AnimationClipPlayable::GetAnimationClips(AnimationClips& clips)
{
    if (m_AnimationClip != NULL)
    {
        clips.push_back(m_AnimationClip);
    }

    AnimationPlayable::GetAnimationClips(clips);
}

void AnimationClipPlayable::CollectAnimationClipPlayables(AnimationClipPlayables& clips)
{
    clips.push_back(this);
    AnimationPlayable::CollectAnimationClipPlayables(clips);
}
