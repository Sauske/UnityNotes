#pragma once

#include "Runtime/Animation/RuntimeAnimatorController.h"
#include "Runtime/Animation/Director/AnimationPlayable.h"
#include "Runtime/Animation/AnimatorControllerParameter.h"
#include "Runtime/Animation/AnimatorDefines.h"
#include "Runtime/Animation/StateMachineBehaviourPlayer.h"

void BindAdditionalCurves(mecanim::ValueArrayConstant const &valueConstant, size_t genericBindingsSize, UnityEngine::Animation::GenericBinding const * genericBindings, mecanim::int32_t *additionalIndexArray);

struct PlayableInstanceData
{
public:
    AnimationStateMachineMixerPlayable**        m_StateMachineMixers;
    int                             m_StateMachineMixersCount;
};

class AnimatorOverrideController;
class AnimationLayerMixerPlayable;

struct HPlayableGraph;
struct HPlayable;

class AnimatorControllerPlayable : public AnimationPlayable , public IStateMachineBehaviourSender
{
    DEFINE_PLAYABLE(AnimatorControllerPlayable, GetAnimationScriptingClasses().animatorControllerPlayable, AnimationPlayable);

private:
    class Memory;

public:

    void PrepareForPlayback(mecanim::memory::Allocator& allocator);
    void SetRecorderData(mecanim::animation::ControllerMemory* runtimeMemory, mecanim::memory::Allocator& allocator);
    mecanim::animation::ControllerMemory* GetRecorderData();

    void SetAnimatorController(RuntimeAnimatorController* controller);
    RuntimeAnimatorController* GetAnimatorController() { return m_AnimatorController; }
    void SetOverrideController(::AnimatorOverrideController* controller);
    void OverrideClipPlayables();

    void UpdateGraph(float deltaTime);

    void ClearFirstEvaluationFlag();

    virtual void GetAnimationClips(AnimationClips& animationClips);
    virtual void PrepareFrame(const DirectorVisitorInfo& info);
    virtual void PreProcessAnimation(AnimationPlayableEvaluationConstant const *constant, mecanim::animation::AnimationNodeState const* state);
    virtual void ProcessRootMotion(AnimationPlayableEvaluationConstant *constant, AnimationPlayableEvaluationInput *input, AnimationPlayableEvaluationOutput *output);
    virtual void ProcessAnimation(AnimationPlayableEvaluationConstant *constant, AnimationPlayableEvaluationInput *input, AnimationPlayableEvaluationOutput *output);
    virtual void CollectAnimatorControllerPlayables(AnimatorControllerPlayables& controllerPlayable);

    virtual bool SetupStateMachineBehaviours();
    virtual void CleanupStateMachineBehaviours();

    virtual void AllocateBindings(AnimationPlayableEvaluationConstant const *constant);
    virtual void DeallocateBindings();

    inline virtual bool IsMultithreadable() const { return m_IsMultithreadable; }

    inline bool HasStateMachineBehaviours() { return m_StateMachineBehaviours.size() > 0; }

    virtual void PrepareAnimationEvents(float weight, AnimationClipEventInfos& eventInfos);

    Memory*     GetMemory() {return &m_AnimatorControllerMemory; }

    virtual NamedObject* GetAsset() const;

    void AddObjectUser(UserList& user);


    void AllocateMemory();
    virtual void DeallocateResources();


    //////////////////////////////////////////////////////////
    // StateMachine control
    template<typename T>
    GetSetValueResult SetValue(mecanim::uint32_t id, T const& value);

    template<typename T>
    GetSetValueResult GetValue(mecanim::uint32_t id, T& value);
    virtual GetSetValueResult GetFloat(int id, float& value);
    virtual GetSetValueResult SetFloat(int id, const float& value);

    virtual GetSetValueResult GetInteger(int id, int& output);
    virtual GetSetValueResult SetInteger(int id, const int& integer);

    virtual GetSetValueResult GetBool(int id, bool& output);
    virtual GetSetValueResult SetBool(int id, const bool& value);

    virtual GetSetValueResult ResetTrigger(int id);
    virtual GetSetValueResult SetTrigger(int id);

    void                ValidateParameterString(GetSetValueResult result, const core::string& parameterName);
    void                ValidateParameterID(GetSetValueResult result, int identifier);

    GetSetValueResult   ParameterControlledByCurve(int id);

    bool                HasParameter(int id);

    int                 GetLayerCount() const;
    core::string            GetLayerName(int layerIndex);
    int                 GetLayerIndex(const core::string& layerName);
    float               GetLayerWeight(int layerIndex);
    void                SetLayerWeight(int layerIndex, float w);

    AnimatorControllerParameterVector GetParameters();

    bool        IsInTransition(int layerIndex) const;
    bool        IsInTransitionInternal(int layerIndex) const;

    int         GetAnimatorClipInfoCount(int layerIndex, bool currentState) const;
    bool        GetAnimatorClipInfo(int layerIndex, bool currentState, dynamic_array<AnimatorClipInfo>& output);
    bool        GetAnimatorStateInfo(int layerIndex, StateInfoIndex stateInfoIndex, AnimatorStateInfo& output) const;
    bool        GetAnimatorTransitionInfo(int layerIndex, AnimatorTransitionInfo& output) const;
    bool        HasState(int layerIndex, int stateID) const;

    core::string    GetAnimatorStateName(int layerIndex, bool currentState);

    core::string    ResolveHash(int hash);


    void        GotoState(int layer, int stateId, float normalizedTimeOffset, float normalizedTransitionDuration, float normalizedTransitionTime = 0.0F);
    void        GotoStateInFixedTime(int layerIndex, int stateId, float fixedTimeOffset, float fixedTransitionDuration, float normalizedTransitionTime = 0.0F);

    bool        ValidateLayerIndex(int index) const;
    const mecanim::statemachine::StateMachineMemory* GetStateMachineMemory(int layerIndex) const;

    const StateMachineBehaviourPlayer&              GetBehaviourPlayer() const { return m_BehaviourPlayer; }
    bool                                            HasStateMachineBehaviour() const { return !m_StateMachineBehaviours.empty(); }
    StateMachineBehaviourVector const*              GetStateMachineBehaviours() const;
    StateMachineBehaviourVectorDescription const*   GetStateMachineBehaviourVectorDescription() const;

    MonoBehaviour* GetBehaviour(ScriptingClassPtr type);
    StateMachineBehaviourVector GetBehaviours(ScriptingClassPtr type);

    bool IsInitialized() const;

private:

    void GenerateGraph();
    void ClearPlayable();
    void RebuildMemory();


    void GotoStateInternal(int layerIndex, int stateID, float timeOffset, float duration, float transitionTime, bool isFixedtime);
    const mecanim::statemachine::StateMachineConstant* GetStateMachineConstant(int layerIndex) const;
    bool ValidateGoToState(int& layerIndex, int& stateId) const;

    void PrepareFrame(const FrameData& info, Playable* source, bool forceEvaluation);
    AnimationStateMachineMixerPlayable* GetStateMachineMixer(int layerIndex) const;

    void SetLayerAutoWeight();

    class Memory
    {
    public:
        mecanim::animation::ControllerConstant const*   m_ControllerConstant;
        mecanim::animation::ControllerInput*            m_ControllerInput;
        mecanim::animation::ControllerMemory*           m_ControllerMemory;
        mecanim::animation::ControllerWorkspace*        m_ControllerWorkspace;
        size_t                                          m_ControllerMemorySize;


        Memory() : m_ControllerConstant(0), m_ControllerInput(0), m_ControllerMemory(0), m_ControllerWorkspace(0), m_ControllerMemorySize(0) {}
        virtual ~Memory() {}

        void                                        Reset(mecanim::memory::MecanimAllocator& allocator);
    };


    RuntimeAnimatorController*              m_AnimatorController;
    Memory                                  m_AnimatorControllerMemory;

    StateMachineBehaviourVector             m_StateMachineBehaviours;
    StateMachineBehaviourPlayer             m_BehaviourPlayer;

    int32_t*                                m_AdditionalIndexArray;
    mecanim::ValueArray*                    m_DefaultValueOverride;

    AnimationLayerMixerPlayable* m_LayerMixer;

    PlayableInstanceData*   m_Playables;
    int                     m_PlayablesCount;
    bool                    m_IsMultithreadable;
};

BIND_MANAGED_TYPE_NAME(AnimatorControllerPlayable, UnityEngine_Animations_AnimatorControllerPlayable);
