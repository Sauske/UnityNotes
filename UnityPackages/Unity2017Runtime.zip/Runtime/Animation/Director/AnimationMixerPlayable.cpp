#include "UnityPrefix.h"
#include "Runtime/Animation/Director/AnimationMixerPlayable.h"

#include "Runtime/Animation/AnimatorConfigure.h"
#include "Runtime/mecanim/animation/avatar.h"

ANIMATOR_PROFILER_INFORMATION_DETAIL(gAnimationMixerPlayableProcessRootMotion, "AnimationMixerPlayable.ProcessRootMotion", kProfilerAnimation);
ANIMATOR_PROFILER_INFORMATION_DETAIL(gAnimationMixerPlayableProcessAnimation, "AnimationMixerPlayable.ProcessAnimation",   kProfilerAnimation);

AnimationMixerPlayable::AnimationMixerPlayable(DirectorPlayerType playerType) : AnimationPlayable(playerType)
{
#if ANIMATION_PLAYABLE_SANITY_CHECK
    m_Type = eAnimationMixerPlayable;
#endif
}

bool AnimationMixerPlayable::SetInputConnection(Playable* input, int inputPort)
{
    bool success = AnimationPlayable::SetInputConnection(input, inputPort);
    if (!success)
        return false;

    return true;
}

void ProcessRootMotionEmptyMixer(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    if (constant->hasRootTransformValues)
    {
        mecanim::SetTransformValueMask(constant->rootPositionValueIndex,
            constant->rootRotationValueIndex,
            constant->rootScaleValueIndex,
            output->nodeStateOutput->m_DynamicValuesMask,
            false);
    }

    if (input->hasControllerParameters)
    {
        mecanim::SetValueMask<true>(output->nodeStateOutput->m_DynamicValuesMask, false);
    }

    ClearMotionOutput(output->nodeStateOutput);
}

void ProcessRootMotionMixBegin(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    bool hasRootMotion = constant->hasRootMotion;
    bool isHuman = constant->isHuman;

    if (hasRootMotion || isHuman)
    {
        mecanim::animation::MotionOutputBlendBegin(output->nodeStateOutput->m_MotionOutput, hasRootMotion, isHuman);
    }

    if (constant->hasRootTransformValues || input->hasControllerParameters)
    {
        if (constant->hasRootTransformValues)
        {
            TransformValueArrayBlendBegin(constant->rootPositionValueIndex,
                constant->rootRotationValueIndex,
                constant->rootScaleValueIndex,
                *output->nodeStateOutput->m_DynamicValuesMask);
        }

        if (input->hasControllerParameters)
        {
            mecanim::ValueArrayBlendBegin<true>(*output->nodeStateOutput->m_DynamicValuesMask);
        }
    }
}

void ProcessRootMotionMix(AnimationPlayableEvaluationOutput *baseOutput,
    AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output,
    mecanim::ValueArrayWeight *valueArrayWeight,
    float weight)
{
    bool hasRootMotion = constant->hasRootMotion;
    bool isHuman = constant->isHuman;

    baseOutput->nodeStateOutput->m_MotionReadMask |= output->nodeStateOutput->m_MotionReadMask;


    if (hasRootMotion || isHuman)
    {
        mecanim::animation::MotionOutputBlendNode(baseOutput->nodeStateOutput->m_MotionOutput,
            output->nodeStateOutput->m_MotionOutput,
            weight,
            hasRootMotion,
            isHuman,
            *input->humanPoseMask);
    }

    if (constant->hasRootTransformValues)
    {
        TransformValueArrayBlendNode(constant->rootPositionValueIndex,
            constant->rootRotationValueIndex,
            constant->rootScaleValueIndex,
            *output->nodeStateOutput->m_DynamicValues,
            *output->nodeStateOutput->m_DynamicValuesMask,
            *baseOutput->nodeStateOutput->m_DynamicValues,
            *baseOutput->nodeStateOutput->m_DynamicValuesMask,
            *valueArrayWeight,
            weight);
    }

    if (input->hasControllerParameters)
    {
        mecanim::ValueArrayBlendNode<true>(*output->nodeStateOutput->m_DynamicValues,
            *output->nodeStateOutput->m_DynamicValuesMask,
            *baseOutput->nodeStateOutput->m_DynamicValues,
            *baseOutput->nodeStateOutput->m_DynamicValuesMask,
            *valueArrayWeight,
            weight);
    }
}

void ProcessRootMotionMixEnd(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output,
    mecanim::ValueArrayWeight *valueArrayWeight,
    float weightSum)
{
    bool hasRootMotion = constant->hasRootMotion;
    bool isHuman = constant->isHuman;

    if (constant->hasRootTransformValues || input->hasControllerParameters)
    {
        mecanim::ValueArray const *defaultValues = input->defaultValuesOverride != NULL ?  input->defaultValuesOverride : constant->defaultValues;

        if (constant->hasRootTransformValues)
        {
            TransformValueArrayBlendEnd(constant->rootPositionValueIndex,
                constant->rootRotationValueIndex,
                constant->rootScaleValueIndex,
                !input->additive ? defaultValues : NULL,
                *output->nodeStateOutput->m_DynamicValuesMask,
                *valueArrayWeight,
                *output->nodeStateOutput->m_DynamicValues);
        }

        if (input->hasControllerParameters)
        {
            mecanim::ValueArrayBlendEnd<true>(!input->additive ? defaultValues : NULL,
                *output->nodeStateOutput->m_DynamicValuesMask,
                *valueArrayWeight,
                *output->nodeStateOutput->m_DynamicValues);
        }
    }

    if (hasRootMotion || isHuman)
    {
        mecanim::animation::MotionOutputBlendEnd(output->nodeStateOutput->m_MotionOutput, hasRootMotion, isHuman, *input->humanPoseMask, weightSum);
    }
}

void ProcessAnimationEmptyMixer(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    mecanim::SetValueMask<false>(output->nodeStateOutput->m_DynamicValuesMask, false);
    ClearHumanPoses(output->nodeStateOutput);
}

void ProcessAnimationMixBegin(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    mecanim::ValueArrayBlendBegin<false>(*output->nodeStateOutput->m_DynamicValuesMask);

    if (constant->isHuman)
    {
        mecanim::human::HumanPoseBlendBegin(*output->nodeStateOutput->m_HumanPose);

        if (output->nodeStateOutput->m_HumanPoseBase != 0)
        {
            mecanim::human::HumanPoseBlendBegin(*output->nodeStateOutput->m_HumanPoseBase);
        }
    }
}

void ProcessAnimationMix(AnimationPlayableEvaluationOutput *baseOutput,
    AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output,
    mecanim::ValueArrayWeight *valueArrayWeight,
    float weight)
{
    mecanim::ValueArrayBlendNode<false>(*output->nodeStateOutput->m_DynamicValues,
        *output->nodeStateOutput->m_DynamicValuesMask,
        *baseOutput->nodeStateOutput->m_DynamicValues,
        *baseOutput->nodeStateOutput->m_DynamicValuesMask,
        *valueArrayWeight,
        weight);

    if (constant->isHuman)
    {
        baseOutput->m_IKOnFeet |= output->m_IKOnFeet;
        baseOutput->nodeStateOutput->m_HumanReadMask |= output->nodeStateOutput->m_HumanReadMask;

        mecanim::human::HumanPoseBlendNode(*baseOutput->nodeStateOutput->m_HumanPose, output->nodeStateOutput->m_HumanPose, weight);

        if (output->nodeStateOutput->m_HumanPoseBase != 0)
        {
            mecanim::human::HumanPoseBlendNode(*baseOutput->nodeStateOutput->m_HumanPoseBase, output->nodeStateOutput->m_HumanPoseBase, weight);
        }
    }
}

void ProcessAnimationMixEnd(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output,
    mecanim::ValueArrayWeight *valueArrayWeight,
    float weightSum)
{
    mecanim::ValueArray const *defaultValues = input->defaultValuesOverride != NULL ?  input->defaultValuesOverride : constant->defaultValues;

    mecanim::ValueArrayBlendEnd<false>(!input->additive ? defaultValues : NULL,
        *output->nodeStateOutput->m_DynamicValuesMask,
        *valueArrayWeight,
        *output->nodeStateOutput->m_DynamicValues);

    if (constant->isHuman)
    {
        mecanim::human::HumanPoseBlendEnd(*output->nodeStateOutput->m_HumanPose, weightSum);

        if (output->nodeStateOutput->m_HumanPoseBase != 0)
        {
            mecanim::human::HumanPoseBlendEnd(*output->nodeStateOutput->m_HumanPoseBase, weightSum);
        }
    }
}

void  AnimationMixerPlayable::MixerProcess(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output,
    AnimationPlayableProcessFunc processFunc,
    AnimationMixerPlayableFunc emptyMixerFunc,
    AnimationMixerPlayableFunc mixerBeginFunc,
    AnimationMixerPlayableMixingFunc mixerFunc,
    AnimationMixerPlayableEndFunc mixerEndFunc)
{
    bool hasRootMotion = constant->hasRootMotion;
    bool isHuman = constant->isHuman;
    bool affectMassCenter = constant->affectMassCenter;

    uint32_t childCount = m_Connections->m_Inputs.size();

    dynamic_array<float> activeWeights(kMemTempJobAlloc);
    activeWeights.reserve(childCount);

    dynamic_array<AnimationPlayable*> activeAnimationPlayables(kMemTempJobAlloc);
    activeAnimationPlayables.reserve(childCount);

    for (int childIter = 0; childIter < childCount; childIter++)
    {
        const PortConnection& input = m_Connections->m_Inputs[childIter];
        if (input.weight > 0)
        {
            AnimationPlayable* animationPlayable = GetNextCompatibleDescendant(childIter);

            if (animationPlayable != NULL && !animationPlayable->IsDelayed())
            {
                activeAnimationPlayables.push_back(animationPlayable);
                activeWeights.push_back(input.weight);
            }
        }
    }

    uint32_t activeCount = activeAnimationPlayables.size();

    if (activeCount == 0)
    {
        (*emptyMixerFunc)(constant, input, output);
    }
    else if (activeCount == 1 && activeWeights[0] == 1.0f)
    {
        (activeAnimationPlayables[0]->*processFunc)(constant, input, output);
    }
    else
    {
        mecanim::memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);

        (*mixerBeginFunc)(constant, input, output);

        float weightSum = 0;
        mecanim::ValueArrayWeight *valueArrayWeight = mecanim::CreateValueArrayWeight(constant->values, tempAllocator);
        mecanim::animation::AnimationNodeState *nodeState = mecanim::animation::CreateAnimationNodeState(*constant->values, hasRootMotion, isHuman, affectMassCenter, tempAllocator);

        for (int activeIter = 0; activeIter < activeCount; activeIter++)
        {
            AnimationPlayableEvaluationOutput childOutput;
            childOutput.nodeStateOutput = nodeState;


            AnimationPlayable* animationPlayable = activeAnimationPlayables[activeIter];
            float weight = activeWeights[activeIter];

            (animationPlayable->*processFunc)(constant, input, &childOutput);
            (*mixerFunc)(output, constant, input, &childOutput, valueArrayWeight, weight);

            weightSum += weight;
        }

        (*mixerEndFunc)(constant, input, output, valueArrayWeight, weightSum);

        mecanim::DestroyValueArrayWeight(valueArrayWeight, tempAllocator);
        mecanim::animation::DestroyAnimationNodeState(nodeState, tempAllocator);
    }
}

void AnimationMixerPlayable::ProcessRootMotion(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    ANIMATOR_PROFILER_AUTO_DETAIL(gAnimationMixerPlayableProcessRootMotion, NULL);

    MixerProcess(constant,
        input,
        output,
        &AnimationPlayable::ProcessRootMotion,
        ProcessRootMotionEmptyMixer,
        ProcessRootMotionMixBegin,
        ProcessRootMotionMix,
        ProcessRootMotionMixEnd);
}

void AnimationMixerPlayable::ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    ANIMATOR_PROFILER_AUTO_DETAIL(gAnimationMixerPlayableProcessAnimation, NULL);

    MixerProcess(constant,
        input,
        output,
        &AnimationPlayable::ProcessAnimation,
        ProcessAnimationEmptyMixer,
        ProcessAnimationMixBegin,
        ProcessAnimationMix,
        ProcessAnimationMixEnd);
}
