#include "UnityPrefix.h"
#include "Runtime/Animation/Director/AnimationPosePlayable.h"

#include "Runtime/mecanim/animation/avatar.h"
#include "Runtime/mecanim/generic/valuearray.h"


AnimationPosePlayable::AnimationPosePlayable(DirectorPlayerType playerType) : AnimationPlayable(playerType)
    , m_MustReadPreviousPose(false), m_ApplyFootIK(false)
{
#if ANIMATION_PLAYABLE_SANITY_CHECK
    m_Type = eAnimationPosePlayable;
#endif
}

void AnimationPosePlayable::AllocateBindings(AnimationPlayableEvaluationConstant const *constant)
{
    if (!m_BindingsAllocated)
    {
        m_AnimationNodeState = mecanim::animation::CreateAnimationNodeState(*constant->values, constant->hasRootMotion, constant->isHuman, constant->affectMassCenter, m_Allocator);
    }

    AnimationPlayable::AllocateBindings(constant);
}

void AnimationPosePlayable::DeallocateBindings()
{
    if (m_BindingsAllocated)
    {
        mecanim::animation::DestroyAnimationNodeState(m_AnimationNodeState, m_Allocator);
        m_AnimationNodeState = NULL;
    }
    AnimationPlayable::DeallocateBindings();
}

void AnimationPosePlayable::ProcessRootMotion(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    mecanim::animation::CopyMotionOutput(m_AnimationNodeState, output->nodeStateOutput, constant->hasRootMotion, constant->isHuman, *input->humanPoseMask);

    if (constant->hasRootTransformValues)
    {
        CopyTransformValueMask(constant->rootPositionValueIndex,
            constant->rootRotationValueIndex,
            constant->rootScaleValueIndex,
            m_AnimationNodeState->m_DynamicValuesMask,
            output->nodeStateOutput->m_DynamicValuesMask);

        TransformValueArrayCopy(constant->rootPositionValueIndex,
            constant->rootRotationValueIndex,
            constant->rootScaleValueIndex,
            m_AnimationNodeState->m_DynamicValues,
            output->nodeStateOutput->m_DynamicValues);
    }

    if (input->hasControllerParameters)
    {
        mecanim::OrValueMask<true>(m_AnimationNodeState->m_DynamicValuesMask, output->nodeStateOutput->m_DynamicValuesMask);
        mecanim::ValueArrayCopy<true>(m_AnimationNodeState->m_DynamicValues, output->nodeStateOutput->m_DynamicValues, m_AnimationNodeState->m_DynamicValuesMask);
    }

    output->nodeStateOutput->m_MotionReadMask = constant->hasRootMotion;
}

void AnimationPosePlayable::ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    mecanim::OrValueMask<false>(m_AnimationNodeState->m_DynamicValuesMask, output->nodeStateOutput->m_DynamicValuesMask);

    if (constant->hasRootTransformValues)
    {
        SetTransformValueMask(constant->rootPositionValueIndex,
            constant->rootRotationValueIndex,
            constant->rootScaleValueIndex,
            output->nodeStateOutput->m_DynamicValuesMask,
            false);
    }

    mecanim::ValueArrayCopy<false>(m_AnimationNodeState->m_DynamicValues, output->nodeStateOutput->m_DynamicValues, output->nodeStateOutput->m_DynamicValuesMask);

    if (constant->isHuman)
    {
        mecanim::animation::CopyHumanPoses(m_AnimationNodeState, output->nodeStateOutput, *input->humanPoseMask);
        output->nodeStateOutput->m_HumanReadMask = true;
        output->m_IKOnFeet = m_ApplyFootIK;
    }
}

void AnimationPosePlayable::PreProcessAnimation(AnimationPlayableEvaluationConstant const *constant, mecanim::animation::AnimationNodeState const* state)
{
    if (MustReadPreviousPose())
    {
        mecanim::animation::CopyAnimationNodeState(state, m_AnimationNodeState, constant->hasRootMotion, constant->isHuman, mecanim::human::FullBodyMask());

        if (constant->hasRootTransformValues)
        {
            SetTransformValueMask(constant->rootPositionValueIndex,
                constant->rootRotationValueIndex,
                constant->rootScaleValueIndex,
                m_AnimationNodeState->m_DynamicValuesMask,
                true);
        }
        SetMustReadPreviousPose(false);
    }

    AnimationPlayable::PreProcessAnimation(constant, state);
}
