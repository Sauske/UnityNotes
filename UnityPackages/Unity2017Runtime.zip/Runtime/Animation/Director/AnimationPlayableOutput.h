#pragma once

#include "Runtime/Director/Core/PlayableOutput.h"
#include "Runtime/Scripting/BindingsDefs.h"

class Animator;

class AnimationPlayableOutput : public PlayableOutput
{
public:
    DEFINE_PLAYABLEOUTPUT(AnimationPlayableOutput, GetAnimationScriptingClasses().animationPlayableOutput, PlayableOutput);

    AnimationPlayableOutput(UInt32 nameHash, PlayableGraph* parentGraph);
    virtual void Destroy();

    Animator* GetTargetAnimator() const;
    void SetTargetAnimator(Animator* target);

    virtual bool SetSourcePlayable(Playable* source);
    virtual void SetSourceInputPort(int port);

    virtual void OnPlayerDestroyed(Object* player);

    virtual DirectorPlayerType GetPlayerType() const { return kAnimation; }
    virtual void GetStages(StageDescriptionArray& out_batches) const;
    virtual void OnConnectionHashChange();

private:

    void Unbind();
    void Bind();

    Animator* m_TargetAnimator;
};

BIND_MANAGED_TYPE_NAME(AnimationPlayableOutput, UnityEngine_Animations_AnimationPlayableOutput);
