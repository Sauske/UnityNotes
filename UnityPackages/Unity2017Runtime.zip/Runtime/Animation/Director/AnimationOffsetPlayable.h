#pragma once

#include "Runtime/Animation/Director/AnimationPlayable.h"
#include "Runtime/Animation/AnimationClip.h"

#include "Runtime/Math/Vector3.h"
#include "Runtime/Math/Quaternion.h"

class AnimationOffsetPlayable : public AnimationPlayable
{
public:
    DEFINE_PLAYABLE(AnimationOffsetPlayable, GetAnimationScriptingClasses().animationOffsetPlayable, AnimationPlayable);

    virtual void ProcessRootMotion(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);

    Vector3f    GetPosition();
    void        SetPosition(const Vector3f& position);

    Quaternionf GetRotation();
    void        SetRotation(const Quaternionf& rotation);

private:
    math::float3            m_Position;
    math::float4            m_Quaternion;
};

BIND_MANAGED_TYPE_NAME(AnimationOffsetPlayable, UnityEngine_Animations_AnimationOffsetPlayable);
