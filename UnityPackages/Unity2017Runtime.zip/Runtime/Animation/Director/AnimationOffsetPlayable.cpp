#include "UnityPrefix.h"
#include "Runtime/Animation/Director/AnimationOffsetPlayable.h"

#include "Runtime/mecanim/animation/avatar.h"
#include "Runtime/mecanim/generic/valuearray.h"
#include "Runtime/Animation/MecanimUtility.h"
#include "Runtime/Animation/AnimatorGenericBindings.h"
#include "Runtime/Animation/MecanimClipBuilder.h"

AnimationOffsetPlayable::AnimationOffsetPlayable(DirectorPlayerType playerType)
    : AnimationPlayable(playerType)
    , m_Position(math::float3(math::ZERO))
    , m_Quaternion(math::quatIdentity())
{
    // any set time calls should get passed directly to it's input
    PropagateSetTime(true);
}

void AnimationOffsetPlayable::ProcessRootMotion(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    AnimationPlayable::ProcessRootMotion(constant, input, output);

    if (output->nodeStateOutput->m_MotionOutput)
    {
        output->nodeStateOutput->m_MotionOutput->m_MotionX.t = m_Position + math::quatMulVec(m_Quaternion, output->nodeStateOutput->m_MotionOutput->m_MotionX.t);
        output->nodeStateOutput->m_MotionOutput->m_MotionX.q  = math::quatMul(m_Quaternion, output->nodeStateOutput->m_MotionOutput->m_MotionX.q);
    }
}

Vector3f AnimationOffsetPlayable::GetPosition()
{
    return float3ToVector3f(m_Position);
}

void AnimationOffsetPlayable::SetPosition(const Vector3f& position)
{
    m_Position = Vector3fTofloat3(position);
}

Quaternionf AnimationOffsetPlayable::GetRotation()
{
    return float4ToQuaternionf(m_Quaternion);
}

void AnimationOffsetPlayable::SetRotation(const Quaternionf& rotation)
{
    m_Quaternion = QuaternionfTofloat4(rotation);
}
