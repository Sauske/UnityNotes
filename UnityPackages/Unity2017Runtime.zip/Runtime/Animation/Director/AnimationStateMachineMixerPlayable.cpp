#include "UnityPrefix.h"

#include "Runtime/Animation/Director/AnimationStateMachineMixerPlayable.h"

AnimationStateMachineMixerPlayable::AnimationStateMachineMixerPlayable(DirectorPlayerType playerType)
    : AnimationMixerPlayable(playerType), m_InterruptedEmptyState(false)
{
#if ANIMATION_PLAYABLE_SANITY_CHECK
    m_Type = eAnimationMixerPlayable;
#endif
}

AnimationMixerPlayable* AnimationStateMachineMixerPlayable::GetStateMixerPlayable(bool currentState) const
{
    DebugAssert(!(currentState && IsInInterruptedTransition()));
    DebugAssert(GetInputs()[currentState ? 0 : 1].playable != NULL);
    return static_cast<AnimationMixerPlayable*>(GetInputs()[currentState ? 0 : 1].playable);
}

AnimationPosePlayable* AnimationStateMachineMixerPlayable::GetInterruptedPosePlayable() const
{
    return static_cast<AnimationPosePlayable*>(GetInputs()[m_InterruptedPoseIndex].playable);
}

void AnimationStateMachineMixerPlayable::SetInterruptedPoseIndex(int index)
{
    DebugAssert(index < 3);
    m_InterruptedPoseIndex = index % 3;
}

void AnimationStateMachineMixerPlayable::EndTransition()
{
    if (IsInInterruptedTransition())
    {
        //Everyone rolls to the left:
        //- next state becomes current state
        //- unused mixer in slot 2 becomes next state in slot 1
        //- interruption pose in slot 0 goes to slot 2 (unused)
        AnimationPosePlayable* pose = static_cast<AnimationPosePlayable*>(GetInputs()[0].playable);
        AnimationMixerPlayable* nextState = static_cast<AnimationMixerPlayable*>(GetInputs()[1].playable);
        AnimationMixerPlayable* unused = static_cast<AnimationMixerPlayable*>(GetInputs()[2].playable);

        AnimationPlayable::DisconnectNoTopologyChange(this, 0);
        AnimationPlayable::DisconnectNoTopologyChange(this, 1);
        AnimationPlayable::DisconnectNoTopologyChange(this, 2);

        AnimationPlayable::ConnectNoTopologyChange(nextState, this, 0, 0);
        AnimationPlayable::ConnectNoTopologyChange(unused, this, 0, 1);
        AnimationPlayable::ConnectNoTopologyChange(pose, this, 0, 2);
        m_InterruptedPoseIndex = 2;

        pose->SetApplyFootIK(false);
    }
    else
    {
        //Current and next state mixers swap.
        //- Next state becomes current state
        //- current state becomes next state (and will stay unused until next transition)
        //- pose stays unchanged
        AnimationMixerPlayable* currentState = static_cast<AnimationMixerPlayable*>(GetInputs()[0].playable);
        AnimationMixerPlayable* nextState = static_cast<AnimationMixerPlayable*>(GetInputs()[1].playable);

        AnimationPlayable::DisconnectNoTopologyChange(this, 0);
        AnimationPlayable::DisconnectNoTopologyChange(this, 1);

        AnimationPlayable::ConnectNoTopologyChange(nextState, this, 0, 0);
        AnimationPlayable::ConnectNoTopologyChange(currentState, this, 0, 1);

        const InputConnections& prevCurrentStateInputs = currentState->GetInputs();
        // As long as we have the AnimationPosePlayable always connected in the last input slot in the graph for write default
        // we must jump over the last input
        //  see void AnimatorControllerPlayable::GenerateGraph()
        for (uint32_t i = 0; i < prevCurrentStateInputs.size() - 1; ++i)
        {
            currentState->SetInputWeight(i, 0.0f);
            AnimationClipPlayable* animationClipPlayable = static_cast<AnimationClipPlayable*>(prevCurrentStateInputs[i].playable);
            animationClipPlayable->SetClip(0);
        }
    }
    SetInputWeight(1, 0.0f);
    SetInputWeight(2, 0.0f);

#if ANIMATION_PLAYABLE_SANITY_CHECK
    DebugAssert(GetInputs()[0]->m_Type == eAnimationMixerPlayable);
    DebugAssert(GetInputs()[1]->m_Type == eAnimationMixerPlayable);
    DebugAssert(GetInputs()[2]->m_Type == eAnimationPosePlayable);
#endif
}

void AnimationStateMachineMixerPlayable::ArrangePlayables(bool isInInterruptedTransition, bool applyFootIK)
{
    if (IsInInterruptedTransition() && !isInInterruptedTransition)
    {
        EndTransition();
    }
    else if (!IsInInterruptedTransition() && isInInterruptedTransition)
    {
        StartInterruptedTransition(applyFootIK, false);
    }
}

void AnimationStateMachineMixerPlayable::StartInterruptedTransition(bool applyFootIK, bool interruptedEmptyState)
{
    DebugAssert(!IsInInterruptedTransition());

    AnimationMixerPlayable* disconnected = GetStateMixerPlayable(true);
    AnimationPosePlayable* interruptedPose = GetInterruptedPosePlayable();

    m_InterruptedEmptyState = interruptedEmptyState;

    interruptedPose->SetApplyFootIK(applyFootIK);

    AnimationPlayable::DisconnectNoTopologyChange(this, 0);
    AnimationPlayable::DisconnectNoTopologyChange(this, m_InterruptedPoseIndex);

    AnimationPlayable::ConnectNoTopologyChange(interruptedPose, this, -1, 0);
    AnimationPlayable::ConnectNoTopologyChange(disconnected, this, -1, 2);

    SetInputWeight(2, 0.0f);

    m_InterruptedPoseIndex = 0;

#if ANIMATION_PLAYABLE_SANITY_CHECK
    DebugAssert(disconnected->m_Type == eAnimationMixerPlayable);
    DebugAssert(interruptedPose->m_Type == eAnimationPosePlayable);
#endif
}
