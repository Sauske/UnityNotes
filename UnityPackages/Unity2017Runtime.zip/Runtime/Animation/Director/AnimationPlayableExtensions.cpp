#include "UnityPrefix.h"
#include "Runtime/Animation/Director/AnimationPlayableExtensions.h"

#include "Runtime/Animation/AnimationClip.h"
#include "Runtime/Director/Core/HPlayable.h"
#include "Runtime/Director/Core/Playable.h"
#include "Runtime/Export/Director/DirectorExport.h"

void AnimationPlayableExtensions::SetAnimatedPropertiesInternal(HPlayable& playable, AnimationClip* animatedProperties)
{
    if (!PlayableValidityChecks(playable))
        return;

    playable.m_Handle->m_Playable->SetAnimatedProperties(animatedProperties);
}
