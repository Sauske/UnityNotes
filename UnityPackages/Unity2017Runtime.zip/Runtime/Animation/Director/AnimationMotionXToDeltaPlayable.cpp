#include "UnityPrefix.h"
#include "Runtime/Animation/Director/AnimationMotionXToDeltaPlayable.h"

#include "Runtime/mecanim/animation/avatar.h"
#include "Runtime/Director/Core/PlayableGraph.h"
#include "Runtime/Export/Director/DirectorExport.h"


AnimationMotionXToDeltaPlayable::AnimationMotionXToDeltaPlayable(DirectorPlayerType playerType)
    : AnimationPlayable(playerType)
    , m_PreviousX(math::trsIdentity())
    , m_IsActive(false)
{
}

void AnimationMotionXToDeltaPlayable::ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    AnimationPlayableEvaluationInput childInput = *input;
    childInput.applyMotionX = true;
    AnimationPlayable::ProcessAnimation(constant, &childInput, output);


    if (output->nodeStateOutput->m_MotionOutput)
    {
        bool wasActive = m_IsActive;
        m_IsActive = output->nodeStateOutput->m_MotionReadMask;

        if (m_IsActive && wasActive) // m_PreviousX is valid
        {
            output->nodeStateOutput->m_MotionOutput->m_DeltaTime = input->avatarInput->m_DeltaTime;
            math::trsX dx = math::trsInvMulNS(m_PreviousX, output->nodeStateOutput->m_MotionOutput->m_MotionX);
            MotionOutputSetDeltaTransform(output->nodeStateOutput->m_MotionOutput, dx);

            if (!input->avatarInput->m_LinearVelocityBlending)
            {
                output->nodeStateOutput->m_MotionOutput->m_Velocity *= output->nodeStateOutput->m_MotionOutput->m_DeltaTime;
                output->nodeStateOutput->m_MotionOutput->m_AngularVelocity *= output->nodeStateOutput->m_MotionOutput->m_DeltaTime;
            }
        }


        if (m_IsActive) // always read previous when active.
        {
            m_PreviousX = output->nodeStateOutput->m_MotionOutput->m_MotionX;
        }
    }
}

bool AnimationMotionXToDeltaPlayable::CreateHandleInternal(HPlayableGraph graph, HPlayable& handle)
{
    if (!PlayableGraphValidityChecks(graph))
        return false;

    AnimationMotionXToDeltaPlayable* instance = graph.m_Handle->m_Graph->ConstructPlayable<AnimationMotionXToDeltaPlayable>(handle, kAnimation);
    if (instance == NULL)
        return false;

    return true;
}
