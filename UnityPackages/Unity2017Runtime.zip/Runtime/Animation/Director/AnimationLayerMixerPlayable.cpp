#include "UnityPrefix.h"
#include "Runtime/Animation/Director/AnimationLayerMixerPlayable.h"

#include "Runtime/Animation/AnimatorConfigure.h"
#include "Runtime/mecanim/animation/controller.h"
#include "Runtime/Animation/AvatarMask.h"
#include "Runtime/mecanim/animation/avatar.h"

static void ValueArrayMaskFromSkeletonMask(const mecanim::ValueArrayConstant& valueConstant, const mecanim::skeleton::SkeletonMask* skeletonMask, mecanim::ValueArrayMask& mask)
{
    bool emptyMask = skeletonMask == NULL || skeletonMask->m_Count == 0;

    for (size_t maskIter = 0; maskIter < valueConstant.m_Count; maskIter++)
    {
        bool maskValue = false;

        if (emptyMask || (valueConstant.m_ValueArray[maskIter].m_Type == mecanim::kFloatType))
        {
            maskValue = true;
        }
        else
        {
            bool found = false;

            for (size_t skIter = 0; !found && skIter < skeletonMask->m_Count; skIter++)
            {
                if (skeletonMask->m_Data[skIter].m_Weight > 0)
                {
                    found = valueConstant.m_ValueArray[maskIter].m_ID == 0 || valueConstant.m_ValueArray[maskIter].m_ID == skeletonMask->m_Data[skIter].m_PathHash;
                }
            }

            maskValue = found;
        }

        int index = valueConstant.m_ValueArray[maskIter].m_Index;
        switch (valueConstant.m_ValueArray[maskIter].m_Type)
        {
            case mecanim::kPositionType:
                mask.m_PositionValues[index] = maskValue;
                break;
            case mecanim::kQuaternionType:
                mask.m_QuaternionValues[index] = maskValue;
                break;
            case mecanim::kScaleType:
                mask.m_ScaleValues[index] = maskValue;
                break;
            case mecanim::kFloatType:
                mask.m_FloatValues[index] = maskValue;
                break;
            case mecanim::kInt32Type:
                mask.m_IntValues[index] = maskValue;
                break;
            default:
                Assert("Unsupported");
        }
    }
}

static bool HasRootMotionMask(const mecanim::animation::AvatarConstant &avatar, const mecanim::skeleton::SkeletonMask* skeletonMask)
{
    // No mask or an empty mask include everything
    if (skeletonMask == NULL || skeletonMask->m_Count == 0)
        return true;

    if (avatar.m_RootMotionBoneIndex == -1)
        return false;

    mecanim::uint32_t rootMotionNodePathHash = avatar.m_AvatarSkeleton->m_ID[avatar.m_RootMotionBoneIndex];

    bool mask = false;
    for (mecanim::uint32_t maskIter = 0; !mask && maskIter < skeletonMask->m_Count; maskIter++)
    {
        if (skeletonMask->m_Data[maskIter].m_PathHash == rootMotionNodePathHash)
        {
            mask = skeletonMask->m_Data[maskIter].m_Weight > 0;
            break;
        }
    }
    return mask;
}

ANIMATOR_PROFILER_INFORMATION_DETAIL(gAnimationLayerMixerPlayableProcessRootMotion, "AnimationLayerMixerPlayable.ProcessRootMotion", kProfilerAnimation);
ANIMATOR_PROFILER_INFORMATION_DETAIL(gAnimationLayerMixerPlayableProcessAnimation, "AnimationLayerMixerPlayable.ProcessAnimation", kProfilerAnimation);

AnimationLayerMixerPlayable::AnimationLayerMixerPlayable(DirectorPlayerType playerType)
    : AnimationPlayable(playerType)
{
#if ANIMATION_PLAYABLE_SANITY_CHECK
    m_Type = eAnimationLayerMixerPlayable;
#endif
}

void AnimationLayerMixerPlayable::UpdateLayerParameters()
{
    if (m_LayerParameters.size() != m_Connections->m_Inputs.size())
    {
        m_LayerParameters.resize_initialized(m_Connections->m_Inputs.size(), LayerParameters());
        RequestAllocateBindings();
    }
}

void AnimationLayerMixerPlayable::SetInputCount(int count)
{
    Playable::SetInputCount(count);
    UpdateLayerParameters();
}

bool AnimationLayerMixerPlayable::SetInputConnection(Playable* input, int inputPort)
{
    if (!AnimationPlayable::SetInputConnection(input, inputPort))
        return false;

    UpdateLayerParameters();

    return true;
}

void AnimationLayerMixerPlayable::SetInputWeight(int inputIndex, float weight)
{
    UpdateLayerParameters();
    Assert(inputIndex < m_LayerParameters.size());
    Playable::SetInputWeight(inputIndex, weight);

    SetLayerWeight(inputIndex, weight);
}

void AnimationLayerMixerPlayable::SetLayerWeight(unsigned int layerIndex, float weight)
{
    UpdateLayerParameters();
    Assert(layerIndex < m_LayerParameters.size());

    if (layerIndex < m_LayerParameters.size())
        m_LayerParameters[layerIndex].m_LayerWeight = weight;
}

bool AnimationLayerMixerPlayable::GetLayerAdditive(unsigned int layerIndex) const
{
    bool additive = false;

    if (layerIndex < m_LayerParameters.size())
        additive = m_LayerParameters[layerIndex].m_Additive;

    return additive;
}

void AnimationLayerMixerPlayable::SetLayerAdditive(unsigned int layerIndex, bool additive)
{
    UpdateLayerParameters();
    Assert(layerIndex < m_LayerParameters.size());

    if (layerIndex < m_LayerParameters.size())
        m_LayerParameters[layerIndex].m_Additive = additive;
}

void AnimationLayerMixerPlayable::SetLayerMaskFromAvatarMask(unsigned int layerIndex, const AvatarMask& mask)
{
    mecanim::memory::MecanimAllocator allocator(kMemTempAlloc);
    mecanim::skeleton::SkeletonMask* skeletonMask = mask.GetSkeletonMask(allocator);

    SetLayerMaskCopy(layerIndex, mask.GetHumanPoseMask(), skeletonMask);

    mecanim::skeleton::DestroySkeletonMask(skeletonMask, allocator);
}

void AnimationLayerMixerPlayable::SetLayerMaskCopy(unsigned int layerIndex, mecanim::human::HumanPoseMask const& humanPoseMask, mecanim::skeleton::SkeletonMask const* skeletonMask)
{
    UpdateLayerParameters();
    Assert(layerIndex < m_LayerParameters.size());

    if (layerIndex < m_LayerParameters.size())
    {
        // For now we do create a copy of both mask, with mixed controller with playable it become hard to manage if the allocation is owned or not by the playable.
        mecanim::memory::MecanimAllocator allocator(kMemAnimation);
        m_LayerParameters[layerIndex].m_HumanPoseMask = humanPoseMask;

        mecanim::skeleton::DestroySkeletonMask(m_LayerParameters[layerIndex].m_SkeletonMask, allocator);
        m_LayerParameters[layerIndex].m_SkeletonMask = skeletonMask != NULL ? mecanim::skeleton::CreateSkeletonMask(skeletonMask->m_Count, skeletonMask->m_Data.Get(), allocator) : NULL;
        RequestAllocateBindings();
    }
}

void AnimationLayerMixerPlayable::MixRootTransformValues(AnimationPlayableEvaluationOutput* baseOutput,
    AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput* output,
    float weight)
{
    mecanim::ValueArray const *defaultValues = input->defaultValuesOverride != NULL ?  input->defaultValuesOverride : constant->defaultValues;

    mecanim::TransformValueArrayAdd(constant->rootPositionValueIndex,
        constant->rootRotationValueIndex,
        constant->rootScaleValueIndex,
        defaultValues,
        output->nodeStateOutput->m_DynamicValues,
        output->nodeStateOutput->m_DynamicValuesMask,
        weight,
        input->additive,
        baseOutput->nodeStateOutput->m_DynamicValues,
        baseOutput->nodeStateOutput->m_DynamicValuesMask);
}

template<bool floatOnly> void AnimationLayerMixerPlayable::MixValues(AnimationPlayableEvaluationOutput* baseOutput,
    AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput* output,
    float weight)
{
    mecanim::ValueArray const *defaultValues = input->defaultValuesOverride != NULL ?  input->defaultValuesOverride : constant->defaultValues;
    mecanim::ValueArrayAdd<floatOnly>(defaultValues,
        output->nodeStateOutput->m_DynamicValues,
        output->nodeStateOutput->m_DynamicValuesMask,
        weight,
        input->additive,
        baseOutput->nodeStateOutput->m_DynamicValues,
        baseOutput->nodeStateOutput->m_DynamicValuesMask);
}

void AnimationLayerMixerPlayable::MixRootMotion(AnimationPlayableEvaluationOutput* baseOutput,
    AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput* output,
    float weight,
    bool layerRootMotionMask)
{
    bool hasRootMotion = constant->hasRootMotion;
    bool isHuman = constant->isHuman;

    if (!input->additive && (hasRootMotion || isHuman))
    {
        bool rootMotionMask = hasRootMotion && layerRootMotionMask;

        mecanim::animation::MotionAddOverrideLayer(baseOutput->nodeStateOutput->m_MotionOutput,
            output->nodeStateOutput->m_MotionOutput,
            weight,
            rootMotionMask,
            isHuman,
            *input->humanPoseMask);
    }
}

void  AnimationLayerMixerPlayable::MixHuman(AnimationPlayableEvaluationOutput* baseOutput,
    AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput* output,
    float weight)
{
    baseOutput->m_IKOnFeet |= output->m_IKOnFeet;

    mecanim::human::HumanPoseMask const *layerHumanPoseMask = input->humanPoseMask;

    mecanim::human::Human const *human = constant->avatarConstant->m_Human.Get();

    mecanim::human::HumanPoseMask mask = *layerHumanPoseMask;
    mask.set(mecanim::human::kMaskLeftHand, mask.test(mecanim::human::kMaskLeftHand) && human->m_HasLeftHand);
    mask.set(mecanim::human::kMaskRightHand, mask.test(mecanim::human::kMaskRightHand) && human->m_HasRightHand);

    if (input->additive)
    {
        mecanim::human::HumanPoseAddAdditiveLayer(*baseOutput->nodeStateOutput->m_HumanPose, *output->nodeStateOutput->m_HumanPose, weight, mask);

        if (baseOutput->nodeStateOutput->m_HumanPoseBase != 0 && mask.test(mecanim::human::kMaskRootIndex))
        {
            mecanim::human::HumanPoseAddAdditiveLayer(*baseOutput->nodeStateOutput->m_HumanPoseBase, *output->nodeStateOutput->m_HumanPoseBase, weight, mask);
        }
    }
    else
    {
        mecanim::human::HumanPoseAddOverrideLayer(*baseOutput->nodeStateOutput->m_HumanPose, *output->nodeStateOutput->m_HumanPose, weight, mask);

        if (baseOutput->nodeStateOutput->m_HumanPoseBase != 0 && mask.test(mecanim::human::kMaskRootIndex))
        {
            mecanim::human::HumanPoseAddOverrideLayer(*baseOutput->nodeStateOutput->m_HumanPoseBase, *output->nodeStateOutput->m_HumanPoseBase, weight, mask);
        }
    }
}

void AnimationLayerMixerPlayable::ProcessRootMotionSingleLayer(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    mecanim::animation::CopyMotionOutput(output->nodeStateOutput, m_LayerMixerMemory.nodeStateArray[0], constant->hasRootMotion, constant->isHuman, *input->humanPoseMask);

    if (constant->hasRootTransformValues || input->hasControllerParameters)
    {
        mecanim::ValueArrayMask const *layerValuesMask = m_LayerMixerMemory.m_DynamicValuesMaskArray[0];

        if (layerValuesMask)
        {
            mecanim::AndValueMask<false>(layerValuesMask, output->nodeStateOutput->m_DynamicValuesMask);
        }

        if (constant->hasRootTransformValues)
        {
            mecanim::TransformValueArrayCopy(constant->rootPositionValueIndex,
                constant->rootRotationValueIndex,
                constant->rootScaleValueIndex,
                output->nodeStateOutput->m_DynamicValues,
                m_LayerMixerMemory.nodeStateArray[0]->m_DynamicValues);

            mecanim::CopyTransformValueMask(constant->rootPositionValueIndex,
                constant->rootRotationValueIndex,
                constant->rootScaleValueIndex,
                output->nodeStateOutput->m_DynamicValuesMask,
                m_LayerMixerMemory.nodeStateArray[0]->m_DynamicValuesMask);
        }

        if (input->hasControllerParameters)
        {
            mecanim::ValueArrayCopy<true>(output->nodeStateOutput->m_DynamicValues, m_LayerMixerMemory.nodeStateArray[0]->m_DynamicValues);
            mecanim::CopyValueMask<true>(output->nodeStateOutput->m_DynamicValuesMask, m_LayerMixerMemory.nodeStateArray[0]->m_DynamicValuesMask);
        }
    }
}

void  AnimationLayerMixerPlayable::ProcessRootMotionLayerBegin(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    ClearMotionOutput(output->nodeStateOutput);
    mecanim::SetValueMask<false>(output->nodeStateOutput->m_DynamicValuesMask, false);
}

void  AnimationLayerMixerPlayable::ProcessRootMotionLayerMix(AnimationPlayableEvaluationOutput *baseOutput,
    AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output,
    int index,
    float weight)
{
    if (constant->hasRootTransformValues || input->hasControllerParameters)
    {
        mecanim::ValueArrayMask const *layerValuesMask = m_LayerMixerMemory.m_DynamicValuesMaskArray[index];

        if (layerValuesMask)
        {
            mecanim::AndValueMask<false>(layerValuesMask, output->nodeStateOutput->m_DynamicValuesMask);
        }

        if (constant->hasRootTransformValues)
        {
            MixRootTransformValues(baseOutput, constant, input, output, weight);
        }

        if (input->hasControllerParameters)
        {
            MixValues<true>(baseOutput, constant, input, output, weight);
        }
    }

    if (output->nodeStateOutput->m_MotionReadMask)
    {
        MixRootMotion(baseOutput, constant, input, output, weight,  m_LayerMixerMemory.m_RootMotionLayerMask[index]);
    }

    baseOutput->nodeStateOutput->m_MotionReadMask |= output->nodeStateOutput->m_MotionReadMask;
}

void AnimationLayerMixerPlayable::ProcessAnimationSingleLayer(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    mecanim::ValueArrayMask const *layerValuesMask = m_LayerMixerMemory.m_DynamicValuesMaskArray[0];

    if (layerValuesMask)
    {
        mecanim::AndValueMask<false>(layerValuesMask, output->nodeStateOutput->m_DynamicValuesMask);
    }

    mecanim::ValueArrayCopy<false>(output->nodeStateOutput->m_DynamicValues, m_LayerMixerMemory.nodeStateArray[0]->m_DynamicValues, output->nodeStateOutput->m_DynamicValuesMask);
    mecanim::OrValueMask<false>(output->nodeStateOutput->m_DynamicValuesMask, m_LayerMixerMemory.nodeStateArray[0]->m_DynamicValuesMask);

    if (constant->isHuman)
    {
        mecanim::human::HumanPoseClear(*output->nodeStateOutput->m_HumanPose, *input->humanPoseMask);
        mecanim::animation::CopyHumanPoses(output->nodeStateOutput, m_LayerMixerMemory.nodeStateArray[0], *input->humanPoseMask);
    }
}

void  AnimationLayerMixerPlayable::ProcessAnimationLayerBegin(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    mecanim::SetValueMask<false>(output->nodeStateOutput->m_DynamicValuesMask, false);
    ClearHumanPoses(output->nodeStateOutput);
}

void  AnimationLayerMixerPlayable::ProcessAnimationLayerMix(AnimationPlayableEvaluationOutput *baseOutput,
    AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output,
    int index,
    float weight)
{
    mecanim::ValueArrayMask const *layerValuesMask = m_LayerMixerMemory.m_DynamicValuesMaskArray[index];

    if (layerValuesMask)
    {
        mecanim::AndValueMask<false>(layerValuesMask, output->nodeStateOutput->m_DynamicValuesMask);
    }

    MixValues<false>(baseOutput, constant, input, output, weight);

    if (constant->isHuman && output->nodeStateOutput->m_HumanReadMask)
    {
        MixHuman(baseOutput, constant, input, output, weight);
    }

    baseOutput->nodeStateOutput->m_HumanReadMask |= output->nodeStateOutput->m_HumanReadMask;
}

void AnimationLayerMixerPlayable::LayerMixerProcess(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output,
    AnimationPlayableProcessFunc processFunc,
    AnimationLayerMixerPlayableFunc singleLayerMixerFunc,
    AnimationLayerMixerPlayableFunc layerMixerBeginFunc,
    AnimationLayerMixerPlayableMixingFunc layerMixerFunc)
{
    int childCount = m_Connections->m_Inputs.size();

    if (childCount == 1 && !m_LayerParameters[0].m_Additive)
    {
        AnimationPlayable* animationPlayable = GetNextCompatibleDescendant(0);

        if (animationPlayable != 0)
        {
            LayerParameters& parameters = m_LayerParameters[0];

            AnimationPlayableEvaluationInput childInput;
            childInput = *input;
            childInput.additive = parameters.m_Additive;
            childInput.humanPoseMask = &parameters.m_HumanPoseMask;
            childInput.lastEvaluationValues =  m_LayerMixerMemory.nodeStateArray[0]->m_DynamicValues;

            (animationPlayable->*processFunc)(constant, &childInput, output);

            (this->*singleLayerMixerFunc)(constant, &childInput, output);
        }
    }
    else
    {
        (this->*layerMixerBeginFunc)(constant, input, output);

        if (childCount > 0)
        {
            mecanim::animation::AnimationNodeState *nodeState = 0;
            mecanim::memory::MecanimAllocator tempAllocator(kMemTempJobAlloc);
            mecanim::ValueArray* lastEvaluationValues = mecanim::CreateValueArray(constant->values, tempAllocator);
            mecanim::ValueArrayCopy<false>(output->nodeStateOutput->m_DynamicValues, lastEvaluationValues);

            for (int childIndex = 0; childIndex < childCount; childIndex++)
            {
                float weight = m_Connections->m_Inputs[childIndex].weight;

                if (weight > 0)
                {
                    AnimationPlayable* animationPlayable  = GetNextCompatibleDescendant(childIndex);

                    if (animationPlayable != NULL && !animationPlayable->IsDelayed())
                    {
                        nodeState = m_LayerMixerMemory.nodeStateArray[childIndex];
                        LayerParameters& layerData = m_LayerParameters[childIndex];

                        AnimationPlayableEvaluationInput childInput;
                        childInput = *input;
                        childInput.additive = layerData.m_Additive;
                        childInput.humanPoseMask = &layerData.m_HumanPoseMask;
                        childInput.lastEvaluationValues = lastEvaluationValues;
                        mecanim::ValueArrayCopy<false>(output->nodeStateOutput->m_DynamicValues, childInput.lastEvaluationValues, output->nodeStateOutput->m_DynamicValuesMask);

                        AnimationPlayableEvaluationOutput childOutput;
                        childOutput.nodeStateOutput = nodeState;

                        (animationPlayable->*processFunc)(constant, &childInput, &childOutput);

                        (this->*layerMixerFunc)(output, constant, &childInput, &childOutput, childIndex, weight);
                    }
                }
            }

            DestroyValueArray(lastEvaluationValues, tempAllocator);
        }
    }
}

void AnimationLayerMixerPlayable::ProcessRootMotion(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    ANIMATOR_PROFILER_AUTO_DETAIL(gAnimationLayerMixerPlayableProcessRootMotion, NULL);

    LayerMixerProcess(constant,
        input,
        output,
        &AnimationPlayable::ProcessRootMotion,
        &AnimationLayerMixerPlayable::ProcessRootMotionSingleLayer,
        &AnimationLayerMixerPlayable::ProcessRootMotionLayerBegin,
        &AnimationLayerMixerPlayable::ProcessRootMotionLayerMix);
}

void AnimationLayerMixerPlayable::ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
    AnimationPlayableEvaluationInput *input,
    AnimationPlayableEvaluationOutput *output)
{
    ANIMATOR_PROFILER_AUTO_DETAIL(gAnimationLayerMixerPlayableProcessAnimation, NULL);

    LayerMixerProcess(constant,
        input,
        output,
        &AnimationPlayable::ProcessAnimation,
        &AnimationLayerMixerPlayable::ProcessAnimationSingleLayer,
        &AnimationLayerMixerPlayable::ProcessAnimationLayerBegin,
        &AnimationLayerMixerPlayable::ProcessAnimationLayerMix);
}

void AnimationLayerMixerPlayable::PrepareAnimationEvents(float weight, AnimationClipEventInfos& eventInfos)
{
    int inputSize = m_Connections->m_Inputs.size();
    for (int i = 0; i < inputSize; ++i)
    {
        if (m_Connections->m_Inputs[i].playable == NULL)
            continue;

        const LayerParameters& layerData = m_LayerParameters[i];
        // Skip animation events if layer weight is zero
        // case 812917
        if (layerData.m_LayerWeight > 0)
        {
            AnimationPlayable* childAnimationPlayable = GetNextCompatibleDescendant(i);
            if (childAnimationPlayable != NULL)
            {
                float childWeight = weight * m_Connections->m_Inputs[i].weight;
                childAnimationPlayable->PrepareAnimationEvents(childWeight, eventInfos);
            }
        }
    }
}

void AnimationLayerMixerPlayable::AllocateBindings(AnimationPlayableEvaluationConstant const *constant)
{
    if (!m_BindingsAllocated)
    {
        UpdateLayerParameters();
        bool hasRootMotion = constant->hasRootMotion;
        bool isHuman = constant->isHuman;
        bool affectMassCenter = constant->affectMassCenter;

        size_t layerCount = m_Connections->m_Inputs.size();
        m_LayerMixerMemory.CreateNodeStateArray(layerCount, *constant->values, hasRootMotion, isHuman, affectMassCenter, m_Allocator);

        m_LayerMixerMemory.m_DynamicValuesMaskArray = m_Allocator.ConstructArray<mecanim::ValueArrayMask *>(layerCount);
        m_LayerMixerMemory.m_DynamicValuesMaskArrayCount = layerCount;
        m_LayerMixerMemory.m_RootMotionLayerMask    = m_Allocator.ConstructArray<bool>(layerCount, true);

        for (int layerIndex = 0; layerIndex < layerCount; layerIndex++)
        {
            mecanim::ValueArrayCopy<false>(constant->defaultValues, m_LayerMixerMemory.nodeStateArray[layerIndex]->m_DynamicValues);
            m_LayerMixerMemory.m_DynamicValuesMaskArray[layerIndex] = mecanim::CreateValueArrayMask(constant->controllerBindingConstant->m_AnimationSet->m_DynamicFullValuesConstant, m_Allocator);
            mecanim::SetValueMask<false>(m_LayerMixerMemory.m_DynamicValuesMaskArray[layerIndex], true);

            ValueArrayMaskFromSkeletonMask(*constant->controllerBindingConstant->m_AnimationSet->m_DynamicFullValuesConstant, m_LayerParameters[layerIndex].m_SkeletonMask, *m_LayerMixerMemory.m_DynamicValuesMaskArray[layerIndex]);
            m_LayerMixerMemory.m_RootMotionLayerMask[layerIndex] = layerIndex == 0 ? true : HasRootMotionMask(*constant->avatarConstant, m_LayerParameters[layerIndex].m_SkeletonMask);
        }
    }

    AnimationPlayable::AllocateBindings(constant);
}

void AnimationLayerMixerPlayable::DeallocateBindings()
{
    if (m_BindingsAllocated)
    {
        size_t layerCount = m_LayerMixerMemory.m_DynamicValuesMaskArrayCount;
        for (int layer = 0; layer < layerCount; layer++)
            mecanim::DestroyValueArrayMask(m_LayerMixerMemory.m_DynamicValuesMaskArray[layer], m_Allocator);

        m_Allocator.Deallocate(m_LayerMixerMemory.m_RootMotionLayerMask);
        m_Allocator.Deallocate(m_LayerMixerMemory.m_DynamicValuesMaskArray);
        m_LayerMixerMemory.DestroyNodeStateArray(m_Allocator);

        m_LayerMixerMemory.m_DynamicValuesMaskArray = NULL;
        m_LayerMixerMemory.m_RootMotionLayerMask = NULL;
    }
    AnimationPlayable::DeallocateBindings();
}

void AnimationLayerMixerPlayable::ClearBindings()
{
    DeallocateResources();
}

float AnimationLayerMixerPlayable::GetLayerWeight(unsigned int layerIndex) const
{
    Assert(layerIndex < m_LayerParameters.size());

    return m_LayerParameters[layerIndex].m_LayerWeight;
}

void AnimationLayerMixerPlayable::DeallocateResources()
{
    mecanim::memory::MecanimAllocator allocator(kMemAnimation);
    size_t layerCount = m_Connections->m_Inputs.size();
    for (int layerIndex = 0; layerIndex < layerCount; layerIndex++)
    {
        mecanim::skeleton::DestroySkeletonMask(m_LayerParameters[layerIndex].m_SkeletonMask, allocator);
        m_LayerParameters[layerIndex].m_SkeletonMask = NULL;
    }

    AnimationPlayable::DeallocateResources();
}

void AnimationLayerMixerPlayable::Memory::CreateNodeStateArray(int nodeCount, mecanim::ValueArrayConstant const &values, bool hasRootMotion, bool isHuman, bool affectMassCenter, mecanim::memory::Allocator& alloc)
{
    if (nodeStateArray.size() != nodeCount)
    {
        DestroyNodeStateArray(alloc);

        nodeStateArray.resize_uninitialized(nodeCount);

        for (int nodeIter = 0; nodeIter < nodeCount; nodeIter++)
        {
            nodeStateArray[nodeIter] = mecanim::animation::CreateAnimationNodeState(values, hasRootMotion, isHuman, affectMassCenter, alloc);
        }
    }
}

void AnimationLayerMixerPlayable::Memory::DestroyNodeStateArray(mecanim::memory::Allocator& alloc)
{
    for (int nodeIter = 0; nodeIter < nodeStateArray.size(); nodeIter++)
    {
        DestroyAnimationNodeState(nodeStateArray[nodeIter], alloc);
    }

    nodeStateArray.clear();
}

// explicit template instantiations...

template void AnimationLayerMixerPlayable::MixValues<true>(AnimationPlayableEvaluationOutput* baseOutput, AnimationPlayableEvaluationConstant *constant, AnimationPlayableEvaluationInput *input, AnimationPlayableEvaluationOutput* output, float weight);
template void AnimationLayerMixerPlayable::MixValues<false>(AnimationPlayableEvaluationOutput* baseOutput, AnimationPlayableEvaluationConstant *constant, AnimationPlayableEvaluationInput *input, AnimationPlayableEvaluationOutput* output, float weight);
