#include "UnityPrefix.h"

#include "AnimationPlayableOutput.h"
#include "Runtime/Animation/Animator.h"
#include "Runtime/BaseClasses/IsPlaying.h"

AnimationPlayableOutput::AnimationPlayableOutput(UInt32 nameHash, PlayableGraph* parentGraph)
    : PlayableOutput(nameHash, parentGraph), m_TargetAnimator(NULL)
{}


void AnimationPlayableOutput::Destroy()
{
    Unbind();
    PlayableOutput::Destroy();
}

Animator* AnimationPlayableOutput::GetTargetAnimator() const
{
    return m_TargetAnimator;
}

void AnimationPlayableOutput::SetTargetAnimator(Animator* target)
{
    Unbind();
    m_TargetAnimator = target;
    Bind();
}

bool AnimationPlayableOutput::SetSourcePlayable(Playable* source)
{
    Unbind();
    bool ret = PlayableOutput::SetSourcePlayable(source);
    Bind();

    return ret;
}

void AnimationPlayableOutput::SetSourceInputPort(int port)
{
    Unbind();
    PlayableOutput::SetSourceInputPort(port);
    Bind();
}

void AnimationPlayableOutput::OnPlayerDestroyed(Object* player)
{
    if (m_TargetAnimator == player)
    {
        SetTargetAnimator(0);
    }
}

void AnimationPlayableOutput::GetStages(StageDescriptionArray& out_batches) const
{
    StageDescription pass1;
    StageDescription pass2;

    bool isPlaying = IsWorldPlaying();
    Animator::UpdateMode updateMode = m_TargetAnimator == NULL ? Animator::kNormal : m_TargetAnimator->GetUpdateMode();

    switch (updateMode)
    {
        case Animator::kUnscaledTime:
        case Animator::kNormal:
        {
            pass1.stage = isPlaying ? kUpdateAnimationBeginStage : kUpdateStage;
            pass1.callback = Animator::BatchedFKPass;

            pass2.stage = isPlaying ? kUpdateAnimationEndStage : kLateUpdateStage;
            pass2.callback = Animator::BatchedIKPass;
            break;
        }

        case Animator::kAnimatePhysics:
        {
            pass1.stage = isPlaying ? kFixedUpdateStage : kUpdateStage;
            pass1.callback = Animator::BatchedFKPass;

            pass2.stage = isPlaying ? kFixedUpdatePostPhysicsStage : kLateUpdateStage;
            pass2.callback = Animator::BatchedIKPass;
            break;
        }
    }
    out_batches.push_back(pass1);
    out_batches.push_back(pass2);
}

void AnimationPlayableOutput::OnConnectionHashChange()
{
    if (m_TargetAnimator != NULL)
    {
        m_TargetAnimator->OnGraphTopologyChanged(GetSourcePlayable(), GetSourceInputPort());
    }
}

void AnimationPlayableOutput::Bind()
{
    Playable *playable = GetSourcePlayable();
    if (playable != NULL && m_TargetAnimator != NULL)
    {
        m_TargetAnimator->OnPlayableBind(this);
    }
}

void AnimationPlayableOutput::Unbind()
{
    Playable *playable = GetSourcePlayableUnsafe();
    if (playable != NULL && m_TargetAnimator != NULL)
    {
        m_TargetAnimator->OnPlayableUnbind(this);
    }
}
