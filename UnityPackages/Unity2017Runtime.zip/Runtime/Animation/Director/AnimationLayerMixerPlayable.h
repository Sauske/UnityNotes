#pragma once
#include "Runtime/Animation/Director/AnimationPlayable.h"
#include "Runtime/mecanim/human/human.h"
#include "Runtime/mecanim/skeleton/skeleton.h"

class AvatarMask;

class AnimationLayerMixerPlayable;
typedef void (AnimationLayerMixerPlayable::*AnimationLayerMixerPlayableFunc)(AnimationPlayableEvaluationConstant *, AnimationPlayableEvaluationInput *, AnimationPlayableEvaluationOutput *);
typedef void (AnimationLayerMixerPlayable::*AnimationLayerMixerPlayableMixingFunc)(AnimationPlayableEvaluationOutput *, AnimationPlayableEvaluationConstant *, AnimationPlayableEvaluationInput *, AnimationPlayableEvaluationOutput *, int, float);

class AnimationLayerMixerPlayable : public AnimationPlayable
{
public:

    template<bool floatOnly> static void MixValues(AnimationPlayableEvaluationOutput* baseOutput, AnimationPlayableEvaluationConstant *constant, AnimationPlayableEvaluationInput *input, AnimationPlayableEvaluationOutput* output, float weight);
    static void MixRootTransformValues(AnimationPlayableEvaluationOutput* baseOutput, AnimationPlayableEvaluationConstant *constant, AnimationPlayableEvaluationInput *input, AnimationPlayableEvaluationOutput* output, float weight);
    static void MixRootMotion(AnimationPlayableEvaluationOutput* baseOutput, AnimationPlayableEvaluationConstant *constant, AnimationPlayableEvaluationInput *input, AnimationPlayableEvaluationOutput* output, float weight, bool layerRootMotionMask = true);
    static void MixHuman(AnimationPlayableEvaluationOutput* baseOutput, AnimationPlayableEvaluationConstant *constant, AnimationPlayableEvaluationInput *input, AnimationPlayableEvaluationOutput* output, float weight);

    DEFINE_PLAYABLE(AnimationLayerMixerPlayable, GetAnimationScriptingClasses().animationLayerMixerPlayable, AnimationPlayable);

    struct LayerParameters
    {
        LayerParameters()
            : m_SkeletonMask(NULL)
            , m_HumanPoseMask(mecanim::human::FullBodyMask())
            , m_LayerWeight(0.0f)
            , m_RootMask(false)
            , m_Additive(false)
        {
        }

        mecanim::skeleton::SkeletonMask* m_SkeletonMask;
        mecanim::human::HumanPoseMask    m_HumanPoseMask;
        float m_LayerWeight;        // As set by the user, this weight doesn't include the layer autoweight
        bool  m_RootMask;
        bool  m_Additive;
    };

    struct Memory
    {
        dynamic_array<mecanim::animation::AnimationNodeState *> nodeStateArray;
        mecanim::ValueArrayMask**   m_DynamicValuesMaskArray;
        int                         m_DynamicValuesMaskArrayCount;
        bool*                       m_RootMotionLayerMask;

        void CreateNodeStateArray(int nodeCount, mecanim::ValueArrayConstant const &values, bool hasRootMotion, bool isHuman, bool affectMassCenter, mecanim::memory::Allocator& alloc);
        void DestroyNodeStateArray(mecanim::memory::Allocator& alloc);
    };

    void ProcessRootMotionSingleLayer(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);

    void ProcessRootMotionLayerBegin(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);

    void ProcessRootMotionLayerMix(AnimationPlayableEvaluationOutput *baseOutput,
        AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output,
        int index,
        float weight);

    void ProcessAnimationSingleLayer(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);

    void ProcessAnimationLayerBegin(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);

    void ProcessAnimationLayerMix(AnimationPlayableEvaluationOutput *baseOutput,
        AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output,
        int index,
        float weight);

    void LayerMixerProcess(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output,
        AnimationPlayableProcessFunc processFunc,
        AnimationLayerMixerPlayableFunc singleLayerMixerFunc,
        AnimationLayerMixerPlayableFunc layerMixerBeginFunc,
        AnimationLayerMixerPlayableMixingFunc layerMixerFunc);

    virtual void ProcessRootMotion(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);

    virtual void ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);

    virtual void PrepareAnimationEvents(float weight, AnimationClipEventInfos& eventInfos);

    virtual void ClearBindings();
    virtual void AllocateBindings(AnimationPlayableEvaluationConstant const *constant);
    virtual void DeallocateBindings();
    virtual void DeallocateResources();

    virtual LayerParameters& GetLayerParameters(unsigned int index) {return m_LayerParameters[index]; }
    virtual const LayerParameters& GetLayerParameters(unsigned int index) const {return m_LayerParameters[index]; }

    virtual void SetInputCount(int count);

    virtual void SetInputWeight(int inputIndex, float weight);
    float GetLayerWeight(unsigned int layerIndex) const;

    void SetLayerAdditive(unsigned int layerIndex, bool additive);
    bool GetLayerAdditive(unsigned int layerIndex) const;

    void SetLayerMaskFromAvatarMask(unsigned int layerIndex, const AvatarMask& mask);

protected:
    virtual bool SetInputConnection(Playable* input, int inputPort);

private:
    // This is needed by the AnimatorControllerPlayable to set the weight of the layer without the auto weight to fire animation events correctly.
    friend class AnimatorControllerPlayable;
    void SetLayerWeight(unsigned int layerIndex, float weight);
    void SetLayerMaskCopy(unsigned int layerIndex, mecanim::human::HumanPoseMask const& humanPoseMask, mecanim::skeleton::SkeletonMask const* skeletonMask);
    void UpdateLayerParameters();

public:  // make private
    Memory                                  m_LayerMixerMemory;
    dynamic_array<LayerParameters>          m_LayerParameters;
};

BIND_MANAGED_TYPE_NAME(AnimationLayerMixerPlayable, UnityEngine_Animations_AnimationLayerMixerPlayable);
