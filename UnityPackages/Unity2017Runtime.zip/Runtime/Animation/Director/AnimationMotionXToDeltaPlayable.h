#pragma once

#include "Runtime/Animation/Director/AnimationPlayable.h"

class AnimationMotionXToDeltaPlayable : public AnimationPlayable
{
public:
    DEFINE_PLAYABLE(AnimationMotionXToDeltaPlayable, GetAnimationScriptingClasses().animationMotionXToDeltaPlayable, AnimationPlayable);

    virtual void ProcessAnimation(AnimationPlayableEvaluationConstant *constant,
        AnimationPlayableEvaluationInput *input,
        AnimationPlayableEvaluationOutput *output);

    virtual bool GetApplyMotionX() const { return true; }

    // Bindings methods.
    static bool CreateHandleInternal(HPlayableGraph graph, HPlayable& handle);

private:
    math::trsX  m_PreviousX;
    bool        m_IsActive;
};

BIND_MANAGED_TYPE_NAME(AnimationMotionXToDeltaPlayable, UnityEngine_Animations_AnimationMotionXToDeltaPlayable);
