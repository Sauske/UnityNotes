#pragma once

#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/Serialize/SerializeTraits.h"
#include "Runtime/Scripting/BindingsDefs.h"

#include "Runtime/Animation/MecanimUtility.h"
#include "Runtime/mecanim/human/human.h"
#include "Runtime/Misc/UserList.h"

namespace mecanim
{
namespace memory
{
    class Allocator;
}

namespace skeleton
{
    struct SkeletonMask;
    struct Skeleton;
}
}

class Transform;

enum MaskBodyPart
{
    kRoot,
    kBody,
    kHead,
    kLeftLowerLeg,
    kRightLowerLeg,
    kLeftUpperArm,
    kRightUpperArm,
    kLeftFingers,
    kRightFingers,
    kLeftFootIK,
    kRightFootIK,
    kLeftHandIK,
    kRightHandIK,
    kLastMaskBodyPart
};

struct TransformMaskElement
{
    TransformMaskElement() : m_Path(""), m_Weight(0)
    {
    }

    TransformMaskElement(core::string transformPath, bool weight) : m_Path(transformPath), m_Weight(weight)
    {
    }

    bool operator==(TransformMaskElement const& other) const
    {
        return m_Path == other.m_Path && m_Weight == other.m_Weight;
    }

    core::string m_Path;
    float m_Weight;

    DEFINE_GET_TYPESTRING(TransformMaskElement);

    template<class TransferFunction>
    void Transfer(TransferFunction& transfer)
    {
        TRANSFER(m_Path);
        TRANSFER(m_Weight);
    }
};
BIND_MANAGED_TYPE_NAME(TransformMaskElement, UnityEditor_TransformMaskElement);

typedef dynamic_array<TransformMaskElement> TransformMaskElementList;

class AvatarMask : public NamedObject
{
    REGISTER_CLASS(AvatarMask);
    DECLARE_OBJECT_SERIALIZE();
public:
    static void InitializeClass();
    static void CleanupClass() {}

    AvatarMask(MemLabelId label, ObjectCreationMode mode);

    virtual void AwakeFromLoad(AwakeFromLoadMode mode);
    virtual void Reset();

    void MainThreadCleanup();

    int GetBodyPartCount() const;
    bool GetBodyPart(int index);
    void SetBodyPart(int index, bool value);
    mecanim::human::HumanPoseMask GetHumanPoseMask() const;

    bool HasFeetIK();

    void SetTransformCount(int count);
    int GetTransformCount() const;

    core::string  GetTransformPath(int index);
    void   SetTransformPath(int index, core::string const& path);
    float GetTransformWeight(int index);
    void  SetTransformWeight(int index, float weight);

    void AddTransformPath(Transform& transform, bool recursive);
    void RemoveTransformPath(Transform& transform, bool recursive);

    mecanim::skeleton::SkeletonMask* GetSkeletonMask(mecanim::memory::Allocator& alloc) const;

    void AddSelfToDependencies(UserList& dependencies);

    TransformMaskElementList m_Elements;

protected:

    bool ValidateBodyPartIndex(int index) const;
    bool ValidateTransformIndex(int index) const;

    void AddTransformPath(Transform& transform, bool recursive, const core::string& path);

    dynamic_array<UInt32> m_Mask;
    mutable UserList m_UserList;
};

BIND_MANAGED_TYPE_NAME(AvatarMask, UnityEngine_AvatarMask);

mecanim::human::HumanPoseMask HumanPoseMaskFromBodyMask(dynamic_array<UInt32> const &m_Mask);
mecanim::skeleton::SkeletonMask* SkeletonMaskFromTransformMask(AvatarMask const &mask, mecanim::memory::Allocator& alloc);
