#include "UnityPrefix.h"

#include "Runtime/Animation/CalculateAnimatorSkinMatrices.h"
#include "Runtime/Animation/Avatar.h"
#include "Runtime/Animation/Animator.h"
#include "Runtime/Animation/MecanimUtility.h"
#include "Runtime/Graphics/Mesh/MeshSkinning.h"
#include "Runtime/mecanim/animation/avatar.h"
#include "Runtime/mecanim/skeleton/skeleton.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Math/Simd/vec-matrix.h"
#include "Runtime/Utilities/Align.h"

PROFILER_INFORMATION(gMeshSkinningPullMatrices, "MeshSkinning.CalculateSkinningMatrices", kProfilerRender)

void DoCalculateAnimatorSkinMatrices(CalculateSkinMatricesTask* task)
{
    using namespace math;

    PROFILER_AUTO(gMeshSkinningPullMatrices, NULL);

    Animator* animator = static_cast<Animator*>(task->animator);

    math::float4 rootRotation;
    mecanim::skeleton::SkeletonPoseT<math::affineX>* allocatedMemory = NULL;
    const mecanim::skeleton::SkeletonPoseT<math::affineX>* animatedPose = animator->GetGlobalSpaceSkeletonPose(&allocatedMemory, task->rootIndex, rootRotation, task->rootTransformAccess);

    if (animatedPose)
    {
        // The TransformInfo of the SkinnedMeshRenderer has no scale component when 'hasSkin' is true.
        // Thus we need to keep the scale component in task->outpose.
        // Do it by removing scale from rootPose.
        // The whole transform chain would be:
        // TransformInfo(TR) * rootPose(TR inverse) * animatedPose (TRS, worldspace)

        float3x3 rInv;
        quatToMatrix(quatConj(rootRotation), rInv);
        affineX rootPose(mul(rInv, -animatedPose->m_X[task->rootIndex].t), rInv);

        if (!IsPtr16ByteAligned(task->outPose))
            FatalErrorMsg("Skin matrices must be 16-byte aligned");

        float4x4* outPoses = reinterpret_cast<float4x4*>(task->outPose);

        if (task->getGlobal)
        {
            for (int i = 0; i < task->bindPoseCount; i++)
            {
                UInt16 skeletonIndex = task->skeletonIndices[i];

                outPoses[i] = affineTo4x4(animatedPose->m_X[skeletonIndex]);
            }
        }
        // Normal skinning path which calculates final matrices including bindposes.
        else if (task->sharedMeshData != NULL)
        {
            const float4x4* bindPoses = reinterpret_cast<float4x4 const*>(task->sharedMeshData->GetMeshSkinningData().GetBindpose().begin());
            for (int i = 0; i < task->bindPoseCount; i++)
            {
                UInt16 skeletonIndex = task->skeletonIndices[i];

                outPoses[i] = affineTo4x4(mul(mul(rootPose, animatedPose->m_X[skeletonIndex]), float4x4ToAffine(bindPoses[i])));
            }
        }
        // Rare calculate pure skeleton matrices codepath.
        else
        {
            for (int i = 0; i < task->bindPoseCount; i++)
            {
                UInt16 skeletonIndex = task->skeletonIndices[i];

                outPoses[i] = affineTo4x4(mul(rootPose, animatedPose->m_X[skeletonIndex]));
            }
        }
    }
    else
    {
        ErrorString("no animated pose. thread failure.");
        for (int i = 0; i < task->bindPoseCount; i++)
            task->outPose[i].SetIdentity();
    }

    // Cleanup
    Animator::FreeGlobalSpaceSkeletonPose(allocatedMemory);

    if (task->deleteWhenFinished)
    {
        if (task->sharedMeshData != NULL)
            task->sharedMeshData->Release();
        UNITY_DELETE(task, kMemTempJobAlloc);
    }
}
