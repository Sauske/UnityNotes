#include "UnityPrefix.h"
#include "AnimationEvent.h"
#include "AnimationClip.h"
#include "AnimationState.h"
#include "AnimationScriptingClasses.h"
#include "Configuration/UnityConfigure.h"
#include "Runtime/Mono/MonoBehaviour.h"
#include "Runtime/Scripting/ScriptingManager.h"
#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/Scripting/ScriptingExportUtility.h"
#include "Runtime/Misc/BuildSettings.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Mono/LazyScriptCache.h"

INSTANTIATE_TEMPLATE_TRANSFER_EXPORTED(AnimationEvent);

template<class TransferFunction>
void AnimationEvent::Transfer(TransferFunction& transfer)
{
    TRANSFER(time);
    TRANSFER(functionName);
    transfer.Transfer(stringParameter, "data");
    transfer.Transfer(objectReferenceParameter, "objectReferenceParameter");
    transfer.Transfer(floatParameter, "floatParameter");
    transfer.Transfer(intParameter, "intParameter");

    TRANSFER(messageOptions);
}

static bool SetupInvokeArgument(ScriptingMethodPtr method, AnimationEvent& event, ScriptingArguments& parameters)
{
    int argCount = scripting_method_get_argument_count(method);

    // Fast path - method takes no arguments
    if (argCount == 0)
        return true;

    if (argCount > 1)
        return false;

    ScriptingTypePtr typeOfFirstArgument = scripting_method_get_nth_argumenttype(method, 0);
    ScriptingClassPtr classOfFirstArgument = scripting_class_from_type(typeOfFirstArgument);

    const CommonScriptingClasses& cc = GetScriptingManager().GetCommonClasses();

    if (classOfFirstArgument == cc.floatSingle)
    {
        parameters.AddFloat(event.floatParameter);
        return true;
    }

    if (classOfFirstArgument == cc.int_32)
    {
        parameters.AddInt(event.intParameter);
        return true;
    }

    if (classOfFirstArgument == cc.string)
    {
        parameters.AddString(event.stringParameter.c_str());
        return true;
    }

    if (classOfFirstArgument == GetAnimationScriptingClasses().animationEvent)
    {
        // Allocate managed memory only when necessary
        MonoAnimationEvent monoEvent;
        AnimationEventToMono(event, monoEvent);
        parameters.AddObject(CreateScriptingObjectFromNativeStruct(GetAnimationScriptingClasses().animationEvent, monoEvent));
        return true;
    }

    if (scripting_class_is_subclass_of(classOfFirstArgument, GetCoreScriptingClasses().object))
    {
        PPtr<Object> object = event.objectReferenceParameter;
        if (object.IsNull())
        {
            parameters.AddObject(Scripting::ScriptingWrapperFor(event.objectReferenceParameter));
            return true;
        }
        else
        {
            if (object->GetType() == TypeOf<MonoBehaviour>())
            {
                MonoBehaviour *monoBehaviour = dynamic_pptr_cast<MonoBehaviour*>(object);
                if (monoBehaviour != NULL)
                {
                    if (scripting_class_is_subclass_of(monoBehaviour->GetClass(), classOfFirstArgument))
                    {
                        parameters.AddObject(Scripting::ScriptingWrapperFor(event.objectReferenceParameter));
                        return true;
                    }
                }
            }
            else if (scripting_class_is_subclass_of(Scripting::TypeToScriptingType(object->GetType()), classOfFirstArgument))
            {
                parameters.AddObject(Scripting::ScriptingWrapperFor(event.objectReferenceParameter));
                return true;
            }
        }
    }

    if (scripting_class_is_enum(classOfFirstArgument))
    {
        parameters.AddInt(event.intParameter);
        return true;
    }

    return false;
}

static bool FireEventTo(MonoBehaviour& behaviour, AnimationEvent& event, AnimationState* state, AnimatorStateInfo* animatorStateInfo, AnimatorClipInfo* animatorClipInfo, ScriptingMethodPtr method)
{
    ScriptingObjectPtr instance = behaviour.GetInstance();
    if (instance == SCRIPTING_NULL)
        return false;

    if (method.IsNull())
        return false;

    event.stateSender = state;
    event.animatorStateInfo = animatorStateInfo;
    event.animatorClipInfo = animatorClipInfo;

    ScriptingInvocation invocation(instance, method);
    if (!SetupInvokeArgument(method, event, invocation.Arguments()))
    {
        ErrorStringObject(Format("Failed to call AnimationEvent %s of class %s.\nThe function must have either 0 or 1 parameters and the parameter can only be: string, float, int, enum, Object and AnimationEvent.", scripting_method_get_name(method), behaviour.GetScriptClassName().c_str()), &behaviour);
        return true;
    }

    // Suppress immediate destruction during the event callback to disallow
    // the object killing itself directly or indirectly in there (would do bad
    // things to the still updating animation state).
    ExecutionRestrictions originalRestrictions = SetExecutionRestrictions(kDisableImmediateDestruction);

    ScriptingExceptionPtr exception = SCRIPTING_NULL;
    invocation.logException = true;
    invocation.objectInstanceIDContextForException = behaviour.GetInstanceID();
    ScriptingObjectPtr returnValue = invocation.Invoke();

    SetExecutionRestrictions(originalRestrictions);

    if (returnValue && exception == SCRIPTING_NULL)
        behaviour.HandleCoroutineReturnValue(method, returnValue);

    event.stateSender = NULL;
    event.animatorStateInfo = NULL;
    event.animatorClipInfo = NULL;

    return true;
}

static bool EventRequiresReceiver(const AnimationEvent& event)
{
    return event.messageOptions == 0;
}

bool FireEvent(AnimationEvent& event, Unity::Component& animation, AnimationState* state, AnimatorStateInfo* animatorStateInfo, AnimatorClipInfo* animatorClipInfo)
{
    GameObject& go = animation.GetGameObject();
    if (!go.IsActive())
        return false;

    bool sent = false;

    for (int i = 0; i < go.GetComponentCount(); i++)
    {
        if (go.GetComponentTypeAtIndex(i) != TypeOf<MonoBehaviour>())
            continue;

        MonoBehaviour& behaviour = static_cast<MonoBehaviour&>(go.GetComponentAtIndex(i));

        ScriptingMethodPtr methodPtr = Scripting::FindMethodCached(behaviour.GetClass(), event.functionName.c_str());

        if (!methodPtr.IsNull() && FireEventTo(behaviour, event, state, animatorStateInfo, animatorClipInfo, methodPtr))
            sent = true;
    }
    if (DEPLOY_OPTIMIZED)
        return true;

    if (sent)
        return true;

    if (!EventRequiresReceiver(event))
        return true;

    core::string warning = event.functionName.empty()
        ? Format("'%s' AnimationEvent has no function name specified!", go.GetName())
        : Format("'%s' AnimationEvent '%s' has no receiver! Are you missing a component?", go.GetName(), event.functionName.c_str());

    ErrorStringObject(warning.c_str(), animation.GetGameObjectPtr());
    return true;
}

void AnimationEventToMono(const AnimationEvent &src, MonoAnimationEvent &dest)
{
    dest.time                       = src.time;
    dest.functionName               = scripting_string_new(src.functionName);
    dest.stringParameter            = scripting_string_new(src.stringParameter);
    dest.objectReferenceParameter   = Scripting::ScriptingWrapperFor(src.objectReferenceParameter);
    dest.floatParameter             = src.floatParameter;
    dest.intParameter               = src.intParameter;

    dest.messageOptions             = src.messageOptions;
    dest.source                     = src.stateSender != NULL ? kLegacy : src.animatorClipInfo != NULL ? kAnimator : kNoAnimationEventSource;
    dest.stateSender                = TrackedReferenceBaseToScriptingObject(src.stateSender, animationState);

    if (src.animatorStateInfo != NULL)
        dest.animatorStateInfo = *src.animatorStateInfo;
    if (src.animatorClipInfo != NULL)
        AnimatorClipInfoToMono(*src.animatorClipInfo, dest.animatorClipInfo);
}

void AnimationEventFromMono(const MonoAnimationEvent &src, AnimationEvent &dest)
{
    dest.time                       = src.time;
    dest.functionName               = scripting_cpp_string_for(src.functionName);
    dest.stringParameter            = scripting_cpp_string_for(src.stringParameter);
    dest.objectReferenceParameter   = ScriptingObjectToObject<Object>(src.objectReferenceParameter);
    dest.floatParameter             = src.floatParameter;
    dest.intParameter               = src.intParameter;

    dest.messageOptions             = src.messageOptions;
}
