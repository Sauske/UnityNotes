#pragma once

#include "Runtime/Animation/StateMachineBehaviourInfo.h"
#include "Runtime/mecanim/statemachine/statemachinemessage.h"


class Animator;
class AnimatorControllerPlayable;
struct AnimatorStateInfo;


class IStateMachineBehaviourSender
{
public:
    virtual bool IsInitialized() const  = 0;
    virtual bool HasStateMachineBehaviour() const = 0;
    virtual StateMachineBehaviourVector const*  GetStateMachineBehaviours() const = 0;
    virtual StateMachineBehaviourVectorDescription const* GetStateMachineBehaviourVectorDescription() const = 0;
};

struct StateMachineBehaviourPlayer
{
public:
    StateMachineBehaviourPlayer(IStateMachineBehaviourSender* sender);

    bool FireStateBehaviour(AnimatorStateInfo &info, int layerIndex, mecanim::statemachine::StateMachineMessage messageID) const;
    bool FireStateMachineBehaviour(int stateMachineFullPath,  int layerIndex, mecanim::statemachine::StateMachineMessage messageID) const;

    inline bool HasStateMachineBehaviour() const { return m_Sender->HasStateMachineBehaviour(); }
    bool IsSenderEnabled() const;
    Object*                                     m_Player;
    AnimatorControllerPlayable*                 m_Playable;

private:

    bool FireBehaviour(StateKey& key, ScriptingArguments &arguments, mecanim::statemachine::StateMachineMessage messageID, bool stateBehaviour) const;

    const IStateMachineBehaviourSender*         m_Sender;
};
