#include "UnityPrefix.h"

#include "Runtime/Animation/AnimatedProperty.h"
#include "Runtime/Animation/BaseAnimationTrack.h"
#include "Runtime/Director/Core/Property.h"
#include "Runtime/Director/Core/Playable.h"
#include "Runtime/Mono/MonoBehaviour.h"

#define PLAYABLE_DURATION_EPSILON 0.00001F


AnimatedProperty::AnimatedProperty(const PropertyAccessor& accessor, const AnimationCurve& curve)
    : m_PropertyScript(accessor)
    , m_Curve(curve)
{
}

AnimatedProperty::~AnimatedProperty()
{
}

void AnimatedProperty::Update(float time, ScriptingObjectPtr object)
{
    if (!object)
        return;

    if (m_Curve.GetKeyCount() == 1)
    {
        const AnimationCurve::Keyframe& kf = m_Curve.GetKey(0);
        SetValue(object, kf.value);
        return;
    }

    float value = m_Curve.Evaluate(time);
    SetValue(object, value);
}

void AnimatedProperty::SetValue(ScriptingObjectPtr object, float value)
{
    m_PropertyScript.SetValue(object, value);
}
