#pragma once

#include "Runtime/Interfaces/IAnimation.h"

class Animator;

// Multi-threaded.
// Can only get animated pose.
// Bindpose included.
void    DoCalculateAnimatorSkinMatrices(CalculateSkinMatricesTask* task);
