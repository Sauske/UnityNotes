#ifndef AVATARCONTROLLER_H
#define AVATARCONTROLLER_H

#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/BaseClasses/MessageIdentifier.h"
#include "Runtime/mecanim/memory.h"
#include "Runtime/Animation/MecanimUtility.h"
#include "Runtime/mecanim/statemachine/statemachine.h"
#include "Runtime/Animation/StateMachineBehaviourInfo.h"
#include "Runtime/Animation/AnimatorDefines.h"

#include "Runtime/Misc/UserList.h"

DECLARE_MESSAGE_IDENTIFIER(kDidModifyAnimatorController);
DECLARE_MESSAGE_IDENTIFIER(kDidModifyOverrideClip);

template<class T>
class PPtr;
class AnimationClip;
class StateMachine;
class Animator;

typedef dynamic_array<PPtr<AnimationClip> > AnimationClipPPtrVector;

namespace UnityEngine
{
namespace Animation
{
    struct AnimationSetBindings;
    struct AnimationSet;
}
}

namespace mecanim
{
namespace animation
{
    struct ControllerConstant;
    struct ControllerInput;
    struct ControllerMemory;
    struct ControllerWorkspace;
    struct AnimationSet;
}

    struct ValueArrayConstant;
}

class RuntimeAnimatorController : public NamedObject
{
    REGISTER_CLASS_TRAITS(kTypeIsAbstract);
    REGISTER_CLASS(RuntimeAnimatorController);
    DECLARE_OBJECT_SERIALIZE();
public:
    RuntimeAnimatorController(MemLabelId label, ObjectCreationMode mode);

    virtual void MainThreadCleanup();

    static void CleanupClass() {}

    virtual mecanim::animation::ControllerConstant* GetAsset(bool forceBuild = true) = 0;
    virtual SharedAnimationSetBindingsPtr GetAnimationSetBindings() = 0;

    virtual AnimationClipPPtrVector const&  GetAnimationClips()  const = 0;

    virtual core::string    StringFromID(unsigned int ID) const = 0;

    virtual StateMachineBehaviourVector const&  GetBehaviours() const = 0;
    virtual StateMachineBehaviourVectorDescription const& GetStateMachineBehaviourVectorDescription() const = 0;

    virtual bool                                    HasMultiThreadedStateMachine() const = 0;

    virtual AnimationClipOverrideVector const*      GetAnimationClipOverrideVector() const {return 0; }

    static mecanim::animation::ControllerConstant*  BuildCustomController(AnimationClip const& clip, mecanim::animation::ControllerConstant const* sourceController, mecanim::memory::Allocator& allocator);

    static void DestroyCustomController(mecanim::animation::ControllerConstant* sourceController, mecanim::memory::Allocator& allocator);

    void AddObjectUser(UserList& user) { m_ObjectUsers.AddUser(user); }
    void AddObjectUser(UserListNode& user) { m_ObjectUsers.AddUser(user); }

    void NotifyObjectUsers(const MessageIdentifier& msg);
    UserList& GetUserList() { return m_ObjectUsers; }


protected:

    virtual void RegisterAnimationClips();

    UserList                                m_ObjectUsers;      // for animatorControllers
    UserList                                m_DependencyList;   // for animationclips

private:

    virtual AnimationClipPPtrVector GetAnimationClipsToRegister() const = 0;
};

BIND_MANAGED_TYPE_NAME(RuntimeAnimatorController, UnityEngine_RuntimeAnimatorController);

#endif
