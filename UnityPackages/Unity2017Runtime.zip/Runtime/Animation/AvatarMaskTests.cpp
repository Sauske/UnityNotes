#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "Runtime/Testing/Testing.h"
#include "Runtime/Testing/TestFixtures.h"
#include "Runtime/Testing/ParametricTest.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/Transform/Transform.h"

#include "Runtime/mecanim/memory.h"
#include "Runtime/mecanim/generic/crc32.h"
#include "Runtime/mecanim/skeleton/skeleton.h"
#include "Runtime/Animation/AvatarMask.h"

class AvatarMaskFixture : public TestFixtureBase
{
public:
    enum
    {
        kInvalidTransformIndex = -1
    };

    AvatarMask* MakeAvatarMask(const char* name)
    {
        AvatarMask* avatarMask = NewTestObject<AvatarMask>(true);
        avatarMask->SetName(name);
        return avatarMask;
    }

    Transform* MakeTransform(const char* name)
    {
        Transform* tf = NewTestObject<Transform>(true);
        GameObject* go = NewTestObject<GameObject>(true);
        go->SetName(name);
        go->AddComponentInternal(tf);
        return tf;
    }

    size_t CreateTransformHierarchy(Transform* parent, size_t depth, size_t childCount, const char* name)
    {
        if (depth == 0)
            return 0;

        size_t transformCount = 0;
        for (; transformCount < childCount; transformCount++)
        {
            Transform* child = MakeTransform(Format("%s%d", name, transformCount).c_str());
            child->SetParent(parent);

            transformCount += CreateTransformHierarchy(child, depth - 1, childCount, name);
        }

        return transformCount;
    }

    int FindTransformIndexInAvatarMask(Transform* transform, AvatarMask* avatarMask)
    {
        // Let validate that the root is not in the mask
        core::string transformPath = CalculateTransformPath(*transform, &transform->GetRoot());
        for (int transformIndex = 0; transformIndex < avatarMask->GetTransformCount(); ++transformIndex)
        {
            if (transformPath == avatarMask->GetTransformPath(transformIndex))
                return transformIndex;
        }
        return kInvalidTransformIndex;
    }
};

UNIT_TEST_SUITE(AvatarMask)
{
    TEST_FIXTURE(AvatarMaskFixture, WhenCreated_NothingIsMasked)
    {
        AvatarMask* avatarMask = MakeAvatarMask("MyMask");

        CHECK_EQUAL(0, avatarMask->GetTransformCount());

        for (int i = 0; i < avatarMask->GetBodyPartCount(); ++i)
        {
            CHECK(avatarMask->GetBodyPart(i));
        }
    }

    TEST_FIXTURE(AvatarMaskFixture, WhenBodyPartIsSetToFalse_ReturnFalse)
    {
        AvatarMask* avatarMask = MakeAvatarMask("MyMask");
        for (int i = 0; i < avatarMask->GetBodyPartCount(); ++i)
        {
            avatarMask->SetBodyPart(i, false);
        }

        for (int i = 0; i < avatarMask->GetBodyPartCount(); ++i)
        {
            CHECK(!avatarMask->GetBodyPart(i));
        }
    }

    TEST_FIXTURE(AvatarMaskFixture, WhenTransformCountIsSetTo10_TransformCountReturn10)
    {
        AvatarMask* avatarMask = MakeAvatarMask("MyMask");

        avatarMask->SetTransformCount(10);
        CHECK_EQUAL(10, avatarMask->GetTransformCount());
    }

    TEST_FIXTURE(AvatarMaskFixture, WhenResetIsCalled_NothingIsMasked)
    {
        AvatarMask* avatarMask = MakeAvatarMask("MyMask");
        for (int i = 0; i < avatarMask->GetBodyPartCount(); ++i)
        {
            avatarMask->SetBodyPart(i, false);
        }
        avatarMask->SetTransformCount(10);

        avatarMask->Reset();

        CHECK_EQUAL(0, avatarMask->GetTransformCount());
        for (int i = 0; i < avatarMask->GetBodyPartCount(); ++i)
        {
            CHECK(avatarMask->GetBodyPart(i));
        }
    }

    TEST_FIXTURE(AvatarMaskFixture, WhenRootTransformIsAddedNonRecursivly_MaskIncludeRootOnly)
    {
        AvatarMask* avatarMask = MakeAvatarMask("MyMask");
        Transform* root = MakeTransform("root");
        size_t hierachyDepth = 5;
        size_t childCount = 2;
        const char* childNamePrefix = "myChild";

        CreateTransformHierarchy(root, hierachyDepth, childCount, childNamePrefix);

        avatarMask->AddTransformPath(*root, false);

        CHECK_EQUAL(1, avatarMask->GetTransformCount());
        for (int i = 0; i < avatarMask->GetTransformCount(); ++i)
        {
            CHECK_EQUAL(core::string(""), avatarMask->GetTransformPath(i));
            CHECK_EQUAL(1.0f, avatarMask->GetTransformWeight(i));
        }
    }

    TEST_FIXTURE(AvatarMaskFixture, WhenRootTransformIsAddedRecursivly_MaskIncludeCompleteTransformHierarchy)
    {
        AvatarMask* avatarMask = MakeAvatarMask("MyMask");

        size_t transformCount = 1;
        Transform* root = MakeTransform("root");
        size_t hierachyDepth = 5;
        size_t childCount = 2;
        const char* childNamePrefix = "myChild";

        transformCount += CreateTransformHierarchy(root, hierachyDepth, childCount, childNamePrefix);

        avatarMask->AddTransformPath(*root, true);
        CHECK_EQUAL(transformCount , avatarMask->GetTransformCount());

        dynamic_array<Transform*> transforms(kMemTempAlloc);
        transforms.reserve(transformCount);
        GetComponentsInChildren(root->GetGameObject(), transforms);

        CHECK_EQUAL(transformCount, transforms.size());

        for (int i = 0; i < transforms.size(); ++i)
        {
            Transform* transform = transforms[i];
            int transformIndex = FindTransformIndexInAvatarMask(transform, avatarMask);
            CHECK(transformIndex < avatarMask->GetTransformCount());
            if (transformIndex < avatarMask->GetTransformCount())
            {
                CHECK_EQUAL(1.0f, avatarMask->GetTransformWeight(transformIndex));
            }
        }
    }

    TEST_FIXTURE(AvatarMaskFixture, WhenShoulderTransformIsAddedRecursivly_MaskDoesIncludeShoulderAndChildren)
    {
        AvatarMask* avatarMask = MakeAvatarMask("MyMask");

        Transform* root = MakeTransform("root");
        size_t hierachyDepth = 2;
        size_t childCount = 2;
        const char* childNamePrefix = "myChild";

        CreateTransformHierarchy(root, hierachyDepth, childCount, childNamePrefix);

        // Get 2nd level transform and create an arm like structure
        size_t transformCount = 1;
        Transform* shoulder = &root->GetChild(0).GetChild(0);
        shoulder->SetName("shoulder");
        transformCount += CreateTransformHierarchy(shoulder, 3, 1, "arm");

        avatarMask->AddTransformPath(*shoulder, true);
        CHECK_EQUAL(transformCount , avatarMask->GetTransformCount());

        dynamic_array<Transform*> transforms(kMemTempAlloc);
        transforms.reserve(transformCount);
        GetComponentsInChildren(shoulder->GetGameObject(), transforms);

        CHECK_EQUAL(transformCount, transforms.size());

        // Validate that root is not in the mask
        CHECK_EQUAL(kInvalidTransformIndex, FindTransformIndexInAvatarMask(root, avatarMask));
        for (int i = 0; i < transforms.size(); ++i)
        {
            Transform* transform = transforms[i];

            int transformIndex = FindTransformIndexInAvatarMask(transform, avatarMask);
            CHECK(transformIndex < avatarMask->GetTransformCount());
            if (transformIndex < avatarMask->GetTransformCount())
            {
                CHECK_EQUAL(1.0f, avatarMask->GetTransformWeight(transformIndex));
            }
        }
    }

    TEST_FIXTURE(AvatarMaskFixture, WhenRootTransformIsRemovedNonRecursivly_MaskIncludeOnlyRootChildren)
    {
        AvatarMask* avatarMask = MakeAvatarMask("MyMask");

        size_t transformCount = 1;
        Transform* root = MakeTransform("root");
        size_t hierachyDepth = 5;
        size_t childCount = 2;
        const char* childNamePrefix = "myChild";

        transformCount += CreateTransformHierarchy(root, hierachyDepth, childCount, childNamePrefix);

        avatarMask->AddTransformPath(*root, true);
        CHECK_EQUAL(transformCount , avatarMask->GetTransformCount());

        avatarMask->RemoveTransformPath(*root, false);
        CHECK_EQUAL(transformCount - 1 , avatarMask->GetTransformCount());

        // Validate that root is not in the mask
        CHECK_EQUAL(kInvalidTransformIndex, FindTransformIndexInAvatarMask(root, avatarMask));
    }

    TEST_FIXTURE(AvatarMaskFixture, WhenRootTransformIsRemovedRecursivly_MaskIsEmpty)
    {
        AvatarMask* avatarMask = MakeAvatarMask("MyMask");

        size_t transformCount = 1;
        Transform* root = MakeTransform("root");
        size_t hierachyDepth = 5;
        size_t childCount = 2;
        const char* childNamePrefix = "myChild";

        transformCount += CreateTransformHierarchy(root, hierachyDepth, childCount, childNamePrefix);

        avatarMask->AddTransformPath(*root, true);
        CHECK_EQUAL(transformCount , avatarMask->GetTransformCount());

        avatarMask->RemoveTransformPath(*root, true);
        CHECK_EQUAL(0 , avatarMask->GetTransformCount());
    }

    TEST_FIXTURE(AvatarMaskFixture, WhenShoulderTransformIsRemovedRecursivly_MaskDoesIncludeCompleteHierarchyExceptShoulderAndChildren)
    {
        AvatarMask* avatarMask = MakeAvatarMask("MyMask");

        size_t transformCount = 1;
        Transform* root = MakeTransform("root");
        size_t hierachyDepth = 2;
        size_t childCount = 2;
        const char* childNamePrefix = "myChild";

        transformCount += CreateTransformHierarchy(root, hierachyDepth, childCount, childNamePrefix);

        // Get 2nd level transform and create an arm like structure
        Transform* shoulderParent = &root->GetChild(0).GetChild(0);

        size_t shoulderTransformCount = 1;
        Transform* shoulder = MakeTransform("shoulder");
        shoulder->SetParent(shoulderParent);
        shoulderTransformCount += CreateTransformHierarchy(shoulder, 3, 1, "arm");

        avatarMask->AddTransformPath(*root, true);
        CHECK_EQUAL(transformCount + shoulderTransformCount , avatarMask->GetTransformCount());

        avatarMask->RemoveTransformPath(*shoulder, true);
        CHECK_EQUAL(transformCount , avatarMask->GetTransformCount());

        // Validate that shoulder is not in the mask
        CHECK_EQUAL(kInvalidTransformIndex, FindTransformIndexInAvatarMask(shoulder, avatarMask));
    }


    TEST_FIXTURE(AvatarMaskFixture, WhenBodyPartAreSetToTrue_GeneratedHumanPoseMaskHaveAllDoFSetToTrue)
    {
        AvatarMask* avatarMask = MakeAvatarMask("MyMask");

        for (int i = 0; i < avatarMask->GetBodyPartCount(); ++i)
        {
            avatarMask->SetBodyPart(i, true);
        }

        mecanim::human::HumanPoseMask humanPoseMask = avatarMask->GetHumanPoseMask();
        CHECK(humanPoseMask == mecanim::human::FullBodyMask());
    }

    TEST_FIXTURE(AvatarMaskFixture, WhenBodyPartAreSetToFalse_GeneratedHumanPoseMaskHaveAllDoFSetToFalse)
    {
        AvatarMask* avatarMask = MakeAvatarMask("MyMask");
        for (int i = 0; i < avatarMask->GetBodyPartCount(); ++i)
        {
            avatarMask->SetBodyPart(i, false);
        }

        mecanim::human::HumanPoseMask emptyHumanPoseMask(0);
        mecanim::human::HumanPoseMask humanPoseMask = avatarMask->GetHumanPoseMask();
        CHECK(humanPoseMask == emptyHumanPoseMask);
    }

    TEST_FIXTURE(AvatarMaskFixture, WhenMaskIsEmpty_GeneratedSkeletonMask_ReturnsNULL)
    {
        mecanim::memory::MecanimAllocator allocator(kMemTempAlloc);

        AvatarMask* avatarMask = MakeAvatarMask("MyMask");

        // An empty Avatar mask should yield no skeleton mask, that's it everything is included
        CHECK(avatarMask->GetSkeletonMask(allocator) == NULL);
    }

    TEST_FIXTURE(AvatarMaskFixture, WhenSkeletonMaskIsGeneratedFromAnNonEmptyAvatarMask_ReturnsEquivalentSkeletonMask)
    {
        mecanim::memory::MecanimAllocator allocator(kMemTempAlloc);

        AvatarMask* avatarMask = MakeAvatarMask("MyMask");

        size_t transformCount = 1;
        Transform* root = MakeTransform("root");
        size_t hierachyDepth = 3;
        size_t childCount = 1;
        const char* childNamePrefix = "myChild";

        transformCount += CreateTransformHierarchy(root, hierachyDepth, childCount, childNamePrefix);
        avatarMask->AddTransformPath(*root, true);

        mecanim::skeleton::SkeletonMask* skeletonMask = avatarMask->GetSkeletonMask(allocator);
        CHECK_EQUAL(transformCount, skeletonMask->m_Count);
        CHECK_EQUAL(transformCount, avatarMask->GetTransformCount());
        for (mecanim::int32_t i = 0; i < skeletonMask->m_Count; i++)
        {
            core::string transformPath = avatarMask->GetTransformPath(i);
            mecanim::uint32_t pathHash = mecanim::processCRC32(transformPath.c_str());

            CHECK_EQUAL(pathHash, skeletonMask->m_Data[i].m_PathHash);
            CHECK_EQUAL(1.0f, skeletonMask->m_Data[i].m_Weight);
        }

        DestroySkeletonMask(skeletonMask, allocator);
    }
}

#endif // ENABLE_UNIT_TESTS
