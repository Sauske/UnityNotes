#pragma once

// Must be kept in sync with AnimationClipStats in AnimationUtility.bindings
struct AnimationClipStats
{
    int size;
    int positionCurves;
    int quaternionCurves;
    int eulerCurves;
    int scaleCurves;
    int muscleCurves;
    int genericCurves;
    int pptrCurves;
    int totalCurves;
    int constantCurves;
    int denseCurves;
    int streamCurves;

    void Reset()
    {
        size = 0;
        positionCurves = 0;
        quaternionCurves = 0;
        eulerCurves = 0;
        scaleCurves = 0;
        muscleCurves = 0;
        genericCurves = 0;
        pptrCurves = 0;
        totalCurves = 0;
        constantCurves = 0;
        denseCurves = 0;
        streamCurves = 0;
    }

    void Combine(AnimationClipStats const& other)
    {
        size += other.size;
        positionCurves += other.positionCurves;
        quaternionCurves += other.quaternionCurves;
        eulerCurves += other.eulerCurves;
        scaleCurves += other.scaleCurves;
        muscleCurves += other.muscleCurves;
        genericCurves += other.genericCurves;
        pptrCurves += other.pptrCurves;
        totalCurves += other.totalCurves;
        constantCurves += other.constantCurves;
        denseCurves += other.denseCurves;
        streamCurves += other.streamCurves;
    }
};
