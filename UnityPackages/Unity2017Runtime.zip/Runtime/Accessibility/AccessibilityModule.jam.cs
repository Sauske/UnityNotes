using JamSharp.Runtime;
using static JamSharp.Runtime.BuiltinRules;
using External.Jamplus.builds.bin.modules;
using External.Jamplus.builds.bin;

namespace Runtime.Accessibility
{
    [OriginalJamFile("Runtime/Accessibility/AccessibilityModule.jam")]
    class AccessibilityModule : ConvertedJamFile
    {
        internal static void TopLevel()
        {
            RegisterRuleWithReturnValue("AccessibilityModule_ReportCs", AccessibilityModule_ReportCs);
        }

        static JamList AccessibilityModule_ReportCs()
        {
            return "Runtime/Accessibility/Managed/VisionUtility.cs";
        }
    }
}
