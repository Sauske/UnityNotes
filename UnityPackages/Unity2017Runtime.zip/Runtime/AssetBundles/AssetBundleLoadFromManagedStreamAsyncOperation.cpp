#include "UnityPrefix.h"

#include "Runtime/AssetBundles/AssetBundleLoadFromManagedStreamAsyncOperation.h"
#include "Runtime/Jobs/BackgroundJobQueue.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/VirtualFileSystem/ManagedStreamFile.h"

PROFILER_INFORMATION(gLoadFromManagedStream, "AssetBundles.LoadFromManagedStream", kProfilerLoading);

AssetBundleLoadFromManagedStreamAsyncOperation::AssetBundleLoadFromManagedStreamAsyncOperation(MemLabelId label)
    : AssetBundleLoadFromStreamAsyncOperation(label)
    , m_ManagedStreamPtr(SCRIPTING_NULL)
    , m_ManagedStreamGCHandle()
{
    SetAssetBundleName("IO.Stream");
#if SUPPORT_SCRIPTING_THREADS
    m_ScriptingDomain = scripting_domain_get();
#endif
}

AssetBundleLoadFromManagedStreamAsyncOperation::~AssetBundleLoadFromManagedStreamAsyncOperation()
{
#if SUPPORT_SCRIPTING_THREADS
    m_ScriptingDomain = NULL;
#endif
}

void AssetBundleLoadFromManagedStreamAsyncOperation::Execute()
{
    AssertMsg(m_ManagedStreamPtr != SCRIPTING_NULL, "ManagedStreamFile must be initialized with a valid IO.Stream");

    // grab handle to prevent GC on managed side
    if (!m_ManagedStreamGCHandle.HasTarget())
    {
        m_ManagedStreamGCHandle.AcquireStrong(m_ManagedStreamPtr);
    }

    AssertMsg(m_ManagedStreamGCHandle.HasTarget(), "Failed to obtain GC handle for IO.Stream!");

    GetBackgroundJobQueue().ScheduleJob(&LoadArchiveJob, this);
}

void AssetBundleLoadFromManagedStreamAsyncOperation::ExecuteSynchronously()
{
    PROFILER_AUTO(gLoadFromManagedStream, NULL);
    AssertMsg(m_ManagedStreamPtr != SCRIPTING_NULL, "ManagedStreamFile must be initialized with a valid IO.Stream");

    // grab handle to prevent GC on managed side
    if (!m_ManagedStreamGCHandle.HasTarget())
    {
        m_ManagedStreamGCHandle.AcquireStrong(m_ManagedStreamPtr);
    }

    AssertMsg(m_ManagedStreamGCHandle.HasTarget(), "Failed to obtain GC handle for IO.Stream!");

    AssetBundleLoadFromManagedStreamAsyncOperation::InitializeResult result = LoadArchive();
    if (result == kInitializeHasStreamBlocks)
        ConvertArchive();

    IntegrateImmediately();
}

void AssetBundleLoadFromManagedStreamAsyncOperation::LoadArchiveJob(AssetBundleLoadFromManagedStreamAsyncOperation* context)
{
    if (!context->IsCancelled() && context->LoadArchive() == kInitializeHasStreamBlocks)
    {
        // Need decompression
        GetBackgroundJobQueue().ScheduleJob(&ConvertArchiveJob, context);
    }
    else
    {
        context->IntegrateWithPreloadManager();
    }
}

void AssetBundleLoadFromManagedStreamAsyncOperation::ConvertArchiveJob(AssetBundleLoadFromManagedStreamAsyncOperation* context)
{
    if (!context->IsCancelled())
        context->ConvertArchive();
    context->IntegrateWithPreloadManager();
}

AssetBundleLoadFromManagedStreamAsyncOperation::InitializeResult AssetBundleLoadFromManagedStreamAsyncOperation::LoadArchive()
{
    // Try to open archive as is
    FileSystemEntry streamEntry = ManagedStreamFile::CreateFileSystemEntry(kMemFile, m_ManagedStreamPtr, m_ManagedStreamGCHandle, GetScriptingDomain(), m_ManagedReadBufferSize);
    AssetBundleLoadFromManagedStreamAsyncOperation::InitializeResult result = InitializeAssetBundleStorage(streamEntry, 0, false);
    return result;
}

bool AssetBundleLoadFromManagedStreamAsyncOperation::ConvertArchive()
{
    FileSystemEntry streamEntry = ManagedStreamFile::CreateFileSystemEntry(kMemFile, m_ManagedStreamPtr, m_ManagedStreamGCHandle, GetScriptingDomain(), m_ManagedReadBufferSize);
    FileAccessor reader;
    if (!reader.Open(streamEntry, kReadPermission))
        return false;

    reader.Seek(0, kBeginning);

    UInt64 archiveSize = reader.Size();
    dynamic_array<UInt8> buffer(kMemTempAlloc);
    buffer.resize_uninitialized(std::min<size_t>(kCachedArchiveChunkSize, archiveSize));

    // ConvertArchiveJob operation is running on another thread already, we don't need more threads.
    SetAllowThreadedConversion(false);

    for (;;)
    {
        UInt64 read;
        if (!reader.Read(buffer.size(), &buffer[0], &read) || read == 0)
            break;

        if (!FeedStream(&buffer[0], read))
            return false;
    }

    if (!FinalizeStream())
        return false;

    return true;
}
