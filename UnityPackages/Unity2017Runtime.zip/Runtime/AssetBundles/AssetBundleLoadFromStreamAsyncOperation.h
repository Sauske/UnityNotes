#pragma once

#include "Runtime/AssetBundles/AssetBundleLoadFromAsyncOperation.h"
#include "Runtime/Utilities/File.h"
#include "Runtime/VirtualFileSystem/ArchiveFileSystem/ArchiveStorageConverter.h"

class Cache;

/// Class for loading AssetBundle from a binary stream and transforming in into
/// uncompressed/chunk-compressed archive which can be saved to a disk cache or memory location.
/// Basically it implements the following states:
/// 1. Load from cache.
/// 2. Initialize converter.
/// 3. Prepare cache (memory/disk).
/// 4. Convert (decompress/compress) to cache.
/// 5. Finalize cache (move to final location).
/// 6. Initialize asset bundle from the final location (open, validate).
/// 7. Enqueue in PreloadManager for integration (loading file streams).
/// TODO: Refactor to state machine (now it makes sense).
class AssetBundleLoadFromStreamAsyncOperation :
    public AssetBundleLoadFromAsyncOperation,
    public IArchiveStorageConverterListener
{
public:
    AssetBundleLoadFromStreamAsyncOperation(MemLabelId label);
    virtual ~AssetBundleLoadFromStreamAsyncOperation();

    void SetCacheId(const core::string& cacheId) { m_CacheId = cacheId; }
    const core::string& GetCacheId() const { return m_CacheId; }
    void SetAllowThreadedConversion(bool threadedConversion) { m_AllowThreadedConversion = threadedConversion; }

    /// AsyncOperation impl
    virtual float GetProgress();
    virtual void SetPriority(int priority);

    /// Immediately loads AssetBundle from cache and starts integration.
    virtual bool LoadCachedArchive();

    /// Add data of the compressed AB to the decompressor.
    bool FeedStream(const void* data, size_t size);
    /// Tell decompressor that this is the last portion of bundle's data and initiate integration.
    bool FinalizeStream();

    /// Return size of the processed data.
    UInt64 GetDownloadedBytes() const;
    /// Return size of the stream encoded in the header.
    UInt64 GetExpectedStreamSize() const;

protected:
    /// Output archive name.
    static const char* kCachedArchiveFilename;
    /// Default chunk size for the cached archive
    static const UInt32 kCachedArchiveChunkSize;
    // The current cache when starting loading.
    Cache* m_Cache;

private:
    // IArchiveStorageConverterListener impl
    virtual bool OnArchiveStorageBlocksInfoProcessed(ArchiveStorageConverter* converter, ArchiveStorageReader* storage);
    virtual bool OnArchiveStorageDirectoryInfoProcessed(ArchiveStorageConverter* converter, ArchiveStorageReader* storage);

    core::string CreateTempOutputDirectory(const core::string& prefix) const;
    bool TryInitializeDiskCache();
    bool TryInitializeMemoryCache();
    bool FinalizeArchiveCreator();
    bool MoveFilesToCachePath();

    /// Converter instance which is responsible for transforming solid-compressed archive to chunk-compressed archive.
    ArchiveStorageConverter* m_ArchiveConverter;
    float m_ArchiveConverterProgress;

    /// Temporary lock file which is used to prevent cache folder from deletion while data is being decompressed to the cache.
    File m_LockFile;

    /// Cache identifier (filename) we use to save decompressed data. If empty, memory file is used.
    core::string m_CacheId;

    /// Allow conversion to another format on a separate thread (another than FeedData is called on).
    bool m_AllowThreadedConversion;
};
