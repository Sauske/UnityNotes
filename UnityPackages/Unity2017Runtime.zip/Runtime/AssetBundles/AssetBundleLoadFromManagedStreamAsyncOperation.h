#pragma once

#include "Runtime/AssetBundles/AssetBundleLoadFromStreamAsyncOperation.h"

#include "Runtime/Scripting/Scripting.h"

/// AssetBundleCreateOperation implementation which can load assetbundle from an IO.Stream instance.
/// If archive supports realtime decompression (chunk-based compression), we load it directly form a stream,
/// overwise we decompress it into memory.
/// If used IO.Stream is kept alive within an AssetBundle object.
class AssetBundleLoadFromManagedStreamAsyncOperation : public AssetBundleLoadFromStreamAsyncOperation
{
public:
    AssetBundleLoadFromManagedStreamAsyncOperation(MemLabelId label);
    virtual ~AssetBundleLoadFromManagedStreamAsyncOperation();

    void SetManagedStreamObjectPtr(ScriptingObjectPtr ptr) { m_ManagedStreamPtr = ptr; }
    void SetManagedReadBufferSize(UInt32 managedReadBufferSize) { m_ManagedReadBufferSize = managedReadBufferSize; }
    void Execute();
    void ExecuteSynchronously();

private:
    static void LoadArchiveJob(AssetBundleLoadFromManagedStreamAsyncOperation* context);
    static void ConvertArchiveJob(AssetBundleLoadFromManagedStreamAsyncOperation* context);

    InitializeResult LoadArchive();
    bool ConvertArchive();
    inline ScriptingDomainPtr GetScriptingDomain()
    {
#if SUPPORT_SCRIPTING_THREADS
        return m_ScriptingDomain;
#else
        return SCRIPTING_NULL;
#endif
    }

    ScriptingObjectPtr m_ManagedStreamPtr;
    ScriptingGCHandle  m_ManagedStreamGCHandle;

    UInt32 m_ManagedReadBufferSize;
#if SUPPORT_SCRIPTING_THREADS
    ScriptingDomainPtr m_ScriptingDomain;
#endif
};
