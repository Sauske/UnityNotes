#include "UnityPrefix.h"
#include "Runtime/AssetBundles/AssetBundleLoadAssetOperation.h"
#include "Runtime/AssetBundles/AssetBundleManager.h"
#include "Runtime/AssetBundles/AssetBundleUtility.h"
#include "Runtime/Misc/BuildSettings.h"
#include "Runtime/Utilities/RuntimeStatic.h"
#include "Runtime/VirtualFileSystem/ArchiveFileSystem/ArchiveStorageReader.h"
#include "Runtime/VirtualFileSystem/AssetBundleFileSystem/AssetBundleFileSystem.h"
#include "Runtime/Testing/Faking.h"
#include "Runtime/Mono/MonoScript.h"

static RuntimeStatic<AssetBundleManager, true> gSingletonABManager(kMemManager, "AssetBundle", "AssetBundleManager");

AssetBundleManager::AssetBundleManager(MemLabelId label)
    : m_AssetBundleLoadAssetOperations(label)
    , m_ScenePathToAssetBundleMap(label)
    , m_SceneNameToAssetBundleMap(label)
{
}

AssetBundleManager::~AssetBundleManager()
{
}

void AssetBundleManager::RegisterAssetBundle(AssetBundle* assetBundle)
{
    Assert(assetBundle != NULL);

    // Register AssetBundle scenes.
    std::vector<core::string> scenePaths;
    GetAllScenePathsFromAssetBundle(*assetBundle, scenePaths);

    {
        ReadWriteLock::AutoWriteLock lock(m_RWLock);

        // No need to add streamed scene asset bundle as it won't be dependent by other asset bundles.
        if (!assetBundle->m_IsStreamedSceneAssetBundle)
            m_HashToAssetBundle[assetBundle->m_AssetBundleName] = assetBundle;

        for (size_t i = 0; i < scenePaths.size(); ++i)
        {
            core::string& scenePath = scenePaths[i];
            if (!m_ScenePathToAssetBundleMap.insert(std::make_pair(scenePath.c_str(), assetBundle)).second)
            {
                SceneToAssetBundleMap::iterator sceneIt = m_ScenePathToAssetBundleMap.find(scenePath.c_str());
                WarningStringMsg("Scene '%s' from AssetBundle '%s' is already registered with another AssetBundle '%s'.", scenePath.c_str(), assetBundle->GetName(), sceneIt->second->GetName());
                continue;
            }

            // Also add the name to the m_SceneNameToAssetBundleMap so we can support quick path for loading by name.
            // If two scenes with same name but different paths, like Assets/SceneFolder1/scene.unity & Assets/sceneFolder2/scene.unity, we keep the first met one.
            // In this case, you have to load the other scene by full path.
            core::string sceneName = GetFileNameWithoutExtension(scenePath);
            m_SceneNameToAssetBundleMap.insert(std::make_pair(sceneName.c_str(), assetBundle));
        }
    }
    // Registered files are removed in SaveAndLoadHelper.h - void UnloadAssetBundle (AssetBundle& file, bool unloadAllLoadedObjects)
}

void AssetBundleManager::UnloadAssetBundle(AssetBundle* assetBundle)
{
    if (assetBundle == NULL)
        return;

    // Unregister AssetBundle scenes
    std::vector<core::string> scenePaths;
    GetAllScenePathsFromAssetBundle(*assetBundle, scenePaths);

    {
        ReadWriteLock::AutoWriteLock lock(m_RWLock);

        if (!assetBundle->m_IsStreamedSceneAssetBundle)
            m_HashToAssetBundle.erase(assetBundle->m_AssetBundleName);

        // Remove scene name and path from AssetBundle mappings if scene is registered with this AssetBundle.
        for (size_t i = 0; i < scenePaths.size(); ++i)
        {
            SceneToAssetBundleMap::iterator sceneIt = m_ScenePathToAssetBundleMap.find(scenePaths[i].c_str());
            if (sceneIt != m_ScenePathToAssetBundleMap.end() && sceneIt->second == assetBundle)
                m_ScenePathToAssetBundleMap.erase(sceneIt);

            core::string sceneName = GetFileNameWithoutExtension(scenePaths[i]);
            sceneIt = m_SceneNameToAssetBundleMap.find(sceneName.c_str());
            if (sceneIt != m_SceneNameToAssetBundleMap.end() && sceneIt->second == assetBundle)
                m_SceneNameToAssetBundleMap.erase(sceneIt);
        }
    }
}

void AssetBundleManager::GetAllLoadedAssetBundles(vector_map<ConstantString, AssetBundle*> &outBundleList)
{
    ReadWriteLock::AutoWriteLock lock(m_RWLock);
    outBundleList = m_HashToAssetBundle;
}

void AssetBundleManager::AddAssetBundleLoadAssetOperation(AssetBundleLoadAssetOperation* operation)
{
    if (operation == NULL)
        return;

    ReadWriteLock::AutoWriteLock lock(m_RWLock);
    m_AssetBundleLoadAssetOperations.insert(std::make_pair(operation, true));
}

void AssetBundleManager::RemoveAssetBundleLoadAssetOperation(AssetBundleLoadAssetOperation* operation)
{
    if (operation == NULL)
        return;

    ReadWriteLock::AutoWriteLock lock(m_RWLock);
    m_AssetBundleLoadAssetOperations.erase(operation);
}

void AssetBundleManager::CollectPreloadObjectsFromAssetBundleLoadAssetOperations(dynamic_array<InstanceID>& objects)
{
    if (m_AssetBundleLoadAssetOperations.empty())
        return;

    ReadWriteLock::AutoReadLock lock(m_RWLock);
    UNITY_SET(kMemTempAlloc, InstanceID) ids;
    for (AssetBundleLoadAssetOperationMap::const_iterator it = m_AssetBundleLoadAssetOperations.begin(); it != m_AssetBundleLoadAssetOperations.end(); ++it)
    {
        AssetBundleLoadAssetOperation* operation = it->first;
        AssertMsg(operation != NULL, "AssetBundleLoadAssetOperation registered to AssetBundleManager cannot be NULL.");

        // Only process the finished AssetBundleLoadAssetOperation.
        if (!operation->IsDone())
            continue;

        const dynamic_array<InstanceID>& tempObjects = operation->GetAssetsToLoadDependencies();
        ids.insert(tempObjects.begin(), tempObjects.end());
        const dynamic_array<InstanceID>& tempLoadedObjects = operation->GetAssetsLoadedDependencies();
        ids.insert(tempLoadedObjects.begin(), tempLoadedObjects.end());
    }

    for (UNITY_SET(kMemTempAlloc, InstanceID) ::const_iterator it = ids.begin(); it != ids.end(); ++it)
        objects.push_back(*it);
}

void AssetBundleManager::SortPreloadObjects(dynamic_array<InstanceID>& preloadObjects, bool scriptsOnly)
{
    if (preloadObjects.empty())
        return;

    dynamic_array<PreloadData> preloadDataArray(kMemTempAlloc);
    preloadDataArray.reserve(preloadObjects.size());
    PopulatePreloadData(preloadObjects, preloadDataArray, scriptsOnly);

    // Sort even there's no dependencies.
    SortPreloadDataByIdentifier sortPreloadDataByIdentifier;
    std::sort(preloadDataArray.begin(), preloadDataArray.end(), sortPreloadDataByIdentifier);

    // Clear the previous preload data and add the new preload data.
    preloadObjects.resize_uninitialized(preloadDataArray.size());
    for (size_t i = 0; i < preloadDataArray.size(); ++i)
        preloadObjects[i] = preloadDataArray[i].m_InstanceID;
}

void AssetBundleManager::CollectPreloadDataDependencies(const AssetBundle* bundle, const std::vector<ConstantString>& dependencies, dynamic_array<InstanceID>& preloadObjects, bool scriptsOnly, bool hasReadLock)
{
    if (preloadObjects.empty())
        return;

    if (bundle != NULL && bundle->m_ExplicitDataLayout)
        return;

    CollectPreloadDataRecursively(bundle, dependencies, preloadObjects, hasReadLock);
    SortPreloadObjects(preloadObjects, scriptsOnly);
}

void AssetBundleManager::CollectPreloadDataDependencies(PPtr<AssetBundle>& bundlePPtr, dynamic_array<InstanceID>& preloadObjects, bool scriptsOnly)
{
    ReadWriteLock::AutoReadLock lock(m_RWLock);

    if ((bundlePPtr.GetInstanceID() == InstanceID_None) || (Object::IDToPointerThreadSafe(bundlePPtr.GetInstanceID()) == NULL))
    {
        WarningStringMsg("Asset bundle was already unloaded.");
        return;
    }

    AssetBundle* bundle = dynamic_pptr_cast<AssetBundle*>(Object::IDToPointerThreadSafe(bundlePPtr.GetInstanceID()));
    CollectPreloadDataDependencies(bundle, bundle->m_Dependencies, preloadObjects, scriptsOnly, true);
}

void AssetBundleManager::PopulatePreloadData(const dynamic_array<InstanceID>& instanceIDs, dynamic_array<PreloadData>& preloadDataArray, bool scriptsOnly)
{
    dynamic_array<const Unity::Type*> types(kMemTempAlloc);
    dynamic_array<SerializedObjectIdentifier> identifiers(kMemTempAlloc);

    GetPersistentManager().GetSerializedTypesAndIdentifiers(instanceIDs, types, identifiers);
    for (size_t i = 0; i < instanceIDs.size(); ++i)
    {
        bool isScript = types[i] == TypeOf<MonoScript>();
        if (scriptsOnly && !isScript)
            continue;
        PreloadData preloadData(instanceIDs[i], isScript ? -1 : 0);
        preloadData.m_Identifier = identifiers[i];
        preloadDataArray.push_back(preloadData);
    }
}

const AssetBundle* AssetBundleManager::CollectPreloadData(InstanceID instanceID, const AssetBundle* bundle, const std::vector<ConstantString>& dependencies,
    dynamic_array<InstanceID>& preloadObjects, bool hasReadLock)
{
    // Don't lock m_RWLock if it's already been locked at a higher level.
    if (!hasReadLock)
        m_RWLock.ReadLock();

    const AssetBundle* result = NULL;

    if (bundle != NULL && bundle->GetPreloadData(instanceID, preloadObjects))
    {
        result = bundle;
    }
    else
    {
        // Loop the dependencies to find the assetBundle in which the object is.
        for (std::vector<ConstantString>::const_iterator it = dependencies.begin(); it != dependencies.end(); it++)
        {
            AssetBundleDependenciesMap::iterator dependency = m_HashToAssetBundle.find(*it);

            if (dependency == m_HashToAssetBundle.end())
                continue;

            AssetBundle* assetBundle = dependency->second;
            if (assetBundle->GetPreloadData(instanceID, preloadObjects))
            {
                result = assetBundle;
                break;
            }
        }
    }

    if (!hasReadLock)
        m_RWLock.ReadUnlock();

    return result;
}

struct SearchEntry
{
    InstanceID id;
    const AssetBundle *bundle;
    const std::vector<ConstantString> *dependencies;
};

typedef UNITY_SET (kMemTempAlloc, InstanceID) VisitedSet;

static void InsertIDsToSearchList(const dynamic_array<InstanceID> &ids, const AssetBundle *referencedFromBundle, const std::vector<ConstantString>& dependencies, dynamic_array<SearchEntry> &searchList, VisitedSet &visitedSet)
{
    int size = ids.size();
    for (int i = 0; i < size; i++)
    {
        if (visitedSet.find(ids[i]) == visitedSet.end())
        {
            // Must include loaded objects in the visited set
            visitedSet.insert(ids[i]);

            // Check to see if we already have the data loaded
            if (Object::IDToPointerThreadSafe(ids[i]) != NULL)
                continue;

            SearchEntry entry = { ids[i], referencedFromBundle, &dependencies };
            searchList.push_back(entry);
        }
    }
}

void AssetBundleManager::CollectPreloadDataRecursively(const AssetBundle* bundle, const std::vector<ConstantString>& initialDependencies, dynamic_array<InstanceID>& preloadObjects, bool hasReadLock)
{
    VisitedSet visitedIDs;
    dynamic_array<SearchEntry> searchList;
    dynamic_array<InstanceID> tempPreloadObjects(kMemTempAlloc);

    // insert initial preload objects
    InsertIDsToSearchList(preloadObjects, bundle, initialDependencies, searchList, visitedIDs);
    while (!searchList.empty())
    {
        SearchEntry &entry = searchList.back();
        const AssetBundle* bundleWithDeps = CollectPreloadData(entry.id, entry.bundle, *entry.dependencies, tempPreloadObjects, hasReadLock);
        searchList.pop_back();

        if (bundleWithDeps != NULL)
            InsertIDsToSearchList(tempPreloadObjects, bundleWithDeps, bundleWithDeps->m_Dependencies, searchList, visitedIDs);

        tempPreloadObjects.resize_uninitialized(0);
    }

    // the input array is cleared as used for the output array
    preloadObjects.resize_uninitialized(visitedIDs.size());
    int idx = 0;
    for (VisitedSet::iterator it = visitedIDs.begin(); it != visitedIDs.end(); it++, idx++)
        preloadObjects[idx] = *it;
}

bool AssetBundleManager::GetAssetBundleScenePaths(const core::string& sceneName, core::string& scenePath, core::string& sceneLoadingPath, core::string& sceneAssetPath) const
{
    __FAKEABLE_METHOD__(AssetBundleManager, GetAssetBundleScenePaths, (sceneName, scenePath, sceneLoadingPath, sceneAssetPath));

    core::string bundlePrefix;
    {
        ReadWriteLock::AutoReadLock lock(m_RWLock);

        AssetBundle* assetBundle = NULL;
        GetAssetBundleAndScenePathBySceneName(sceneName, assetBundle, scenePath);

        if (assetBundle == NULL || assetBundle->m_ArchiveStorage == NULL)
            return false;

        if (!assetBundle->m_ArchiveStorage->IsDirectoryInfoValid() || assetBundle->m_ArchiveStorage->GetDirectoryInfo().nodes.empty())
            return false;

        bundlePrefix = AppendPathName(AssetBundle::kAssetBundleRootPath, assetBundle->m_ArchiveStorage->GetPrefix());
        if (!assetBundle->GetSceneHash(scenePath, sceneLoadingPath))
        {
            sceneLoadingPath = "BuildPlayer-" + GetFileNameWithoutExtension(sceneName);
            sceneAssetPath = sceneLoadingPath;
        }
        else
        {
            sceneAssetPath = assetBundle->m_ArchiveStorage->GetPrefix();
            sceneAssetPath = sceneAssetPath.substr(0, sceneAssetPath.size() - 1);
        }
    }

    sceneLoadingPath = AppendPathName(bundlePrefix, sceneLoadingPath);
    sceneAssetPath = AppendPathName(bundlePrefix, sceneAssetPath);
    sceneAssetPath = AppendPathNameExtension(sceneAssetPath, "sharedAssets");
    return true;
}

static bool GetScenePathFromAssetBundle(AssetBundle& assetBundle, const core::string& sceneName, core::string& scenePath)
{
    for (AssetBundle::AssetMap::const_iterator it = assetBundle.m_PathContainer.begin(); it != assetBundle.m_PathContainer.end(); ++it)
    {
        core::string tempName = GetFileNameWithoutExtension(it->first);
        if (StrIEquals(sceneName, tempName))
        {
            scenePath = it->first;
            return true;
        }
    }

    return false;
}

void AssetBundleManager::GetAssetBundleAndScenePathBySceneName(const core::string& sceneName, AssetBundle*& assetBundle, core::string& scenePath) const
{
    if (sceneName.find(kPathNameSeparator) != core::string::npos)
    {
        SceneToAssetBundleMap::const_iterator it;

        if (StartsWithPath(sceneName, "Assets/") && EndsWithCaseInsensitive(sceneName, ".unity"))
        {
            // Full scene path match.
            it = m_ScenePathToAssetBundleMap.find(sceneName.c_str());
        }
        else
        {
            // Display scene path match.
            BuildSettings& buildSettings = GetBuildSettings();
            core::string tempScenePath = buildSettings.ConvertDisplayScenePathToScenePath(sceneName);
            it = m_ScenePathToAssetBundleMap.find(tempScenePath.c_str());
        }

        if (it != m_ScenePathToAssetBundleMap.end())
        {
            scenePath = it->first.c_str();
            assetBundle = it->second;
        }
    }
    else
    {
        // Scene name match.
        SceneToAssetBundleMap::const_iterator it = m_SceneNameToAssetBundleMap.find(sceneName.c_str());

        if (it != m_SceneNameToAssetBundleMap.end())
        {
            GetScenePathFromAssetBundle(*it->second, sceneName, scenePath);
            assetBundle = it->second;
        }
    }
}

AssetBundleManager& GetAssetBundleManager()
{
    Assert(gSingletonABManager != NULL);
    return *gSingletonABManager;
}
