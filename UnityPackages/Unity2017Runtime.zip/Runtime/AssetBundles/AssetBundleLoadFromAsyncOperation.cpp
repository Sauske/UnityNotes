#include "UnityPrefix.h"
#include "Runtime/AssetBundles/AssetBundleLoadFromAsyncOperation.h"
#include "Runtime/AssetBundles/AssetBundleManager.h"
#include "Runtime/AssetBundles/AssetBundleUtility.h"
#include "Runtime/Misc/SaveAndLoadHelper.h"
#include "Runtime/Serialize/PersistentManager.h"
#include "Runtime/Threads/ThreadUtility.h"
#include "Runtime/Utilities/CRC.h"
#include "Runtime/Utilities/File.h"
#include "Runtime/VirtualFileSystem/AssetBundleFileSystem/AssetBundleFileSystem.h"

#if ENABLE_CACHING
#include "Runtime/Misc/CachingManager.h"
#endif

AssetBundleLoadFromAsyncOperation::AssetBundleLoadFromAsyncOperation(MemLabelId label)
    : PreloadManagerOperation(label)
    , m_Storage(NULL)
    , m_IsStorageCleanupPathInCache(false)
    , m_AssetBundle(0)
    , m_AssetBundleName("<no name>")
    , m_ExpectedCrc32(0)
    , m_CompressedSize(0)
    , m_Result(kResultSuccess)
    , m_EnableCompatibilityChecks(true)
{
    // AssetBundleLoadAsyncOperations are self managing until they get to PreloadManager.
    // All AssetBundleLoadFrom* AsyncOperations in async mode are being executed on a BackgroundJobQueue.
    // And to avoid destruction during GC run while there is reading / decompression happens on a job thread additional Retain is called.
    // Once operation is completed (finished, failed) it's being added to the PreloadManager,
    // which takes care about integration of AssetBundle object, coroutine continuation and final Release.
    // Thus in case there was a cancellation or AssetBundle was never queried we do double release.
    AddRef();
}

AssetBundleLoadFromAsyncOperation::~AssetBundleLoadFromAsyncOperation()
{
    DeleteStorage();

    if (!m_StorageCleanupPath.empty())
    {
        if (m_IsStorageCleanupPathInCache)
        {
#if ENABLE_CACHING
            // If it's coming from cache, we have to unregister it
            GetCachingManager().RemoveloadedAssetBundle(m_StorageCleanupPath);
#endif
        }
        else
        {
            // If data was cached into MemoryFS, delete it,
            DeleteFileOrDirectory(m_StorageCleanupPath);
            // and say we don't need MemoryFS anymore
            GetFileSystem().UnmountMemoryFileSystem();
        }
    }
}

void AssetBundleLoadFromAsyncOperation::Cancel()
{
    SetResult(kResultCancelled);
}

bool AssetBundleLoadFromAsyncOperation::IsDone()
{
    // Done on error
    if (GetResult() != kResultSuccess)
        return true;
    // And only after integration
    return PreloadManagerOperation::IsDone();
}

UInt64 AssetBundleLoadFromAsyncOperation::GetSize() const
{
    return m_CompressedSize;
}

void AssetBundleLoadFromAsyncOperation::Perform()
{
}

void AssetBundleLoadFromAsyncOperation::IntegrateMainThread()
{
    if (!TryToLoadAndInitializeAssetBundle())
        PrintError();
}

void AssetBundleLoadFromAsyncOperation::DeleteStorage()
{
    if (m_Storage != NULL)
        UNITY_DELETE(m_Storage, kMemFile);
}

AssetBundleLoadFromAsyncOperation::InitializeResult AssetBundleLoadFromAsyncOperation::InitializeAssetBundleStorage(const core::string& path, UInt64 offset)
{
    FileSystemEntry entry(path.c_str());
    return InitializeAssetBundleStorage(entry, offset);
}

AssetBundleLoadFromAsyncOperation::InitializeResult AssetBundleLoadFromAsyncOperation::InitializeAssetBundleStorage(FileSystemEntry& fileEntry, UInt64 offset, bool canCloseFile)
{
    // Check for already initialized storage
    AssertMsg(m_Storage == NULL, "InitializeAssetBundleStorage was already called!");

    // Init archive
    m_Storage = UNITY_NEW(ArchiveStorageReader, kMemFile)(kMemFile);
    if (m_Storage->Initialize(fileEntry, offset, canCloseFile) != ArchiveStorageHeader::kSuccess)
    {
        DeleteStorage();
        return kInitializeError;
    }

    // We can integrate only non-solid archives that support random-read
    if (!m_Storage->IsDirectoryInfoValid() || m_Storage->HasStreamBlocks())
    {
        DeleteStorage();
        return kInitializeHasStreamBlocks;
    }

    // Check crc32 of the uncompressed data once we have a valid archive
    if (!IsCrc32Valid())
    {
        DeleteStorage();
        return kInitializeError;
    }

    UInt64 compressedSize = 0;
    const ArchiveStorageHeader::BlocksInfo& blocksInfo = m_Storage->GetBlocksInfo();
    for (size_t i = 0; i < blocksInfo.storageBlocks.size(); ++i)
        compressedSize += blocksInfo.storageBlocks[i].compressedSize;
    m_CompressedSize = compressedSize;

    // Once archive is initialized and verified it's up to ArchiveFiles to reopen and use it when needed
    m_Storage->MakeStorageUnused();

    return kInitializeSuccess;
}

bool AssetBundleLoadFromAsyncOperation::IsDirectoryInfoValid(const ArchiveStorageHeader::DirectoryInfo& directoryInfo) const
{
    // If we have serialized data in the bundle this is correct bundle.
    for (size_t i = 0; i < directoryInfo.nodes.size(); ++i)
    {
        if (directoryInfo.nodes[i].IsSerializedFile())
            return true;
    }

    return false;
}

bool AssetBundleLoadFromAsyncOperation::IsCrc32Valid()
{
    if (m_Storage == NULL)
        return false;

    if (m_ExpectedCrc32 == 0)
        return true;

    UInt32 crc = CRCBegin();

    // Read data from a storage block by block
    const ArchiveStorageHeader::BlocksInfo& blocksInfo = m_Storage->GetBlocksInfo();
    UInt64 uncompressedSize = 0;
    for (size_t i = 0; i < blocksInfo.storageBlocks.size(); ++i)
        uncompressedSize += blocksInfo.storageBlocks[i].uncompressedSize;

    dynamic_array<UInt8> buffer(kMemTempAlloc);
    buffer.resize_uninitialized(32 * 1024);
    UInt64 pos = 0;
    while (pos < uncompressedSize)
    {
        UInt64 toRead = std::min<UInt64>(uncompressedSize - pos, buffer.size());
        UInt64 actual;
        if (!m_Storage->Read(pos, toRead, &buffer[0], &actual) || actual == 0)
            break;

        crc = CRCFeed(crc, &buffer[0], actual);
        pos += actual;
    }

    crc = CRCDone(crc);
    if (crc != m_ExpectedCrc32)
    {
        SetResult(kResultNotMatchingCrc, Format("CRC Mismatch. Provided %x, calculated %x from data. Will not load AssetBundle '%s'", m_ExpectedCrc32, crc, GetAssetBundleName()).c_str());
        return false;
    }

    return true;
}

void AssetBundleLoadFromAsyncOperation::IntegrateWithPreloadManager()
{
    GetPreloadManager().AddToQueue(this);
    Release();
}

void AssetBundleLoadFromAsyncOperation::IntegrateImmediately()
{
    __FAKEABLE_METHOD__(AssetBundleLoadFromAsyncOperation, IntegrateImmediately, ());

    if (!TryToLoadAndInitializeAssetBundle())
        PrintError();

    Release();
}

bool AssetBundleLoadFromAsyncOperation::TryToLoadAndInitializeAssetBundle()
{
    if (GetResult() != kResultSuccess)
    {
        if (m_Storage != NULL)
        {
            UNITY_DELETE(m_Storage, kMemFile);
            m_Storage = NULL;
        }

        return false;
    }

    // Do nothing if we don't have initialized storage where we can read data from
    if (m_Storage == NULL)
        return false;

    // Here we assume that storage is an AssetBundle storage and contains valid files
    const ArchiveStorageHeader::DirectoryInfo& directory = m_Storage->GetDirectoryInfo();
    const char* firstAssetBundleFilename = directory.nodes[0].path.c_str();
    core::string assetBundleHandlerPathPrefix = GetAssetBundlePrefix(firstAssetBundleFilename);
    m_Storage->SetPrefix(assetBundleHandlerPathPrefix.c_str());

    // Collect serialized files
    core::string assetBundleAbsolutePathPrefix = GetAbsoluteAssetBundlePrefix(firstAssetBundleFilename);
    std::vector<core::string> serializedFilePaths;
    for (size_t i = 0; i < directory.nodes.size(); ++i)
    {
        if (directory.nodes[i].IsSerializedFile())
            serializedFilePaths.push_back(AppendPathName(assetBundleAbsolutePathPrefix, directory.nodes[i].path.c_str()));
    }

    if (serializedFilePaths.empty())
    {
        SetResult(kResultNoSerializedData);
        return false;
    }

    PersistentManager& pm = GetPersistentManager();
    pm.Lock();

    // Check if we have SerializedFiles already loaded into PersistentManager
    for (size_t i = 0; i < serializedFilePaths.size(); ++i)
    {
        if (pm.IsStreamLoaded(serializedFilePaths[i]))
        {
            pm.Unlock();
            SetResult(kResultAlreadyLoaded);

            return false;
        }
    }

    // Mount archive into global filesystem
    GetAssetBundleFileSystem().AddArchive(m_Storage);

    // Load all streams into PersistentManager
    for (size_t i = 0; i < serializedFilePaths.size(); ++i)
    {
        if (!pm.LoadFileStream(serializedFilePaths[i], serializedFilePaths[i], kSerializeGameRelease, 0))
        {
            pm.Unlock();
            SetResult(kResultNotCompatible);
            UnloadAssetBundleFileStreams(serializedFilePaths);
            GetAssetBundleFileSystem().RemoveArchive(m_Storage);
            return false;
        }
    }

    // Check backward compatibility.
    if (m_EnableCompatibilityChecks)
    {
        core::string error;
        for (size_t i = 0; i < serializedFilePaths.size(); ++i)
        {
            if (!TestAssetBundleCompatibility(serializedFilePaths[i], m_AssetBundleName, error))
            {
                pm.Unlock();

                SetResult(kResultNotCompatible, error.c_str());
                UnloadAssetBundleFileStreams(serializedFilePaths);
                GetAssetBundleFileSystem().RemoveArchive(m_Storage);

                return false;
            }
        }
    }

    pm.Unlock();

    return InitializeAssetBundle(serializedFilePaths[0]);
}

static AssetBundle* FindAssetBundleObjectAtPath(core::string const& assetBundlePath)
{
    PersistentManager& pm = GetPersistentManager();

    // An AssetBundle can be the first (AssetBundle) or the second object (StreamedLevel assets file)
    const int fileID1 = 1, fileID2 = 2;

    int fileID = 0;
    if (pm.GetTypeFromPathAndFileID(assetBundlePath, fileID1) == TypeOf<AssetBundle>())
        fileID = fileID1;
    else if (pm.GetTypeFromPathAndFileID(assetBundlePath, fileID2) == TypeOf<AssetBundle>())
        fileID = fileID2;
    else
    {
        // Old streamed scene asset bundle that has no AssetBundle object.
        return NULL;
    }

    InstanceID instanceID = pm.GetInstanceIDFromPathAndFileID(assetBundlePath, fileID);
    return dynamic_instanceID_cast<AssetBundle*>(instanceID);
}

bool AssetBundleLoadFromAsyncOperation::InitializeAssetBundle(const core::string& mainAssetBundleFilename)
{
    // Locate AssetBundle object.
    AssetBundle* assetBundle = FindAssetBundleObjectAtPath(mainAssetBundleFilename);
    if (!assetBundle)
    {
        // We used to not include AssetBundle objects in streamed scene
        // asset bundles that had type trees.  This is no longer the case
        // but to handle this case, we create an AssetBundle object on
        // demand (like before).

        assetBundle = NEW_OBJECT(AssetBundle);
        assetBundle->Reset();
        assetBundle->AwakeFromLoad(kInstantiateOrCreateFromCodeAwakeFromLoad);

        // Set to incompatible runtime version.
        assetBundle->m_RuntimeCompatibility = 0;
    }

    AssertMsg(assetBundle->m_ArchiveStorage == NULL, "AssetBundle must not have any associated data at the initialization stage!");

    // Associate archive with asset bundle.
    assetBundle->m_ArchiveStorage = m_Storage;
    UNITY_TRANSFER_OWNERSHIP(m_Storage, kMemFile, GET_ROOT_REFERENCE(assetBundle, assetBundle->GetMemoryLabel()));
    m_Storage = NULL;
    // Transfer information about the archive's source path if it's cached
    assetBundle->m_ArchiveStorageCleanupPath = m_StorageCleanupPath;
    assetBundle->m_IsArchiveStorageCleanupPathInCache = m_IsStorageCleanupPathInCache;
    m_StorageCleanupPath.clear();

    // Make sure the asset bundle can be loaded into this
    // build of the player.
    if (m_EnableCompatibilityChecks)
    {
        core::string errorMessage;
        bool isCompatible = TestAssetBundleCompatibility(*assetBundle, m_AssetBundleName, errorMessage);
        if (!isCompatible)
        {
            SetResult(kResultNotCompatible, errorMessage.c_str());
            UnloadAssetBundle(*assetBundle, true);

            return false;
        }
    }

    GetAssetBundleManager().RegisterAssetBundle(assetBundle);

    // Now we have AssetBundle completely initialized and loaded
    m_AssetBundle = assetBundle;
    UnityMemoryBarrier();

    return true;
}

void AssetBundleLoadFromAsyncOperation::SetResult(AssetBundleLoadResult r, const char* resultStr)
{
    // Leave only the first error
    if (m_Result != kResultSuccess)
        return;

    m_Result = r;
    UnityMemoryBarrier();

    if (r != kResultSuccess)
    {
        // Store string representation
        Mutex::AutoLock lock(m_ResultStrMutex);
        if (resultStr != NULL)
            m_ResultStr = resultStr;
        else
            m_ResultStr = GetResultStr(r);
    }
}

core::string AssetBundleLoadFromAsyncOperation::GetResultStr() const
{
    Mutex::AutoLock lock(m_ResultStrMutex);
    return m_ResultStr;
}

core::string AssetBundleLoadFromAsyncOperation::GetResultStr(AssetBundleLoadResult r) const
{
    switch (r)
    {
        case AssetBundleLoadFromAsyncOperation::kResultSuccess:
            return core::string();
        case AssetBundleLoadFromAsyncOperation::kResultCancelled:
            return Format("Cancelled loading AssetBundle '%s'.", GetAssetBundleName());
        case AssetBundleLoadFromAsyncOperation::kResultNotMatchingCrc:
            return Format("AssetBundle '%s' has invalid crc!", GetAssetBundleName());
        case AssetBundleLoadFromAsyncOperation::kResultFailedCache:
            return Format("Failed to initialize cache for the AssetBundle '%s'.", GetAssetBundleName());
        case AssetBundleLoadFromAsyncOperation::kResultNotValidAssetBundle:
            return Format("The '%s' file is not a valid AssetBundle.", GetAssetBundleName());
        case AssetBundleLoadFromAsyncOperation::kResultNoSerializedData:
            return Format("The AssetBundle '%s' can't be loaded because it doesn't have serialized data.", GetAssetBundleName());
        case AssetBundleLoadFromAsyncOperation::kResultNotCompatible:
            return Format("The AssetBundle '%s' can't be loaded because it was not built with the right version or build target.", GetAssetBundleName());
        case AssetBundleLoadFromAsyncOperation::kResultAlreadyLoaded:
            return Format("The AssetBundle '%s' can't be loaded because another AssetBundle with the same files is already loaded.", GetAssetBundleName());
        case AssetBundleLoadFromAsyncOperation::kResultFailedRead:
            return Format("Failed to read data for the AssetBundle '%s'.", GetAssetBundleName());
        case AssetBundleLoadFromAsyncOperation::kResultFailedDecompression:
            return Format("Failed to decompress data for the AssetBundle '%s'.", GetAssetBundleName());
        default:
            return Format("The AssetBundle '%s' can't be loaded because of internal error.", GetAssetBundleName());
    }
}

void AssetBundleLoadFromAsyncOperation::PrintError() const
{
    if (m_Result == kResultSuccess || m_Result == kResultCancelled)
        return;

    Mutex::AutoLock lock(m_ResultStrMutex);
    ErrorString(m_ResultStr);
}
