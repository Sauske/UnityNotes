#include "UnityPrefix.h"
#include "AssetBundleUtility.h"
#include "AssetBundle.h"
#include "AssetBundleManager.h"
#include "artifacts/generated/Configuration/UnityConfigureOther.gen.h"
#include "artifacts/generated/Configuration/UnityConfigureVersion.gen.h"
#include "Runtime/Misc/Player.h"
#include "Runtime/Misc/BuildSettings.h"
#include "Runtime/AssetBundles/AssetBundleLoadAssetOperation.h"
#include "Runtime/Serialize/PersistentManager.h"
#include "Runtime/Serialize/SerializedFile.h"
#include "Runtime/Utilities/File.h"
#include "Runtime/Mono/MonoScriptManager.h"
#include "Runtime/Mono/MonoScript.h"
#include "Runtime/Mono/MonoBehaviour.h"
#include "Runtime/Misc/SaveAndLoadHelper.h"
#include "Runtime/Scripting/ScriptingManager.h"
#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/Scripting/GetComponent.h"
#include "Runtime/Threads/ThreadUtility.h"

#if UNITY_EDITOR
#include "Editor/Src/BuildPipeline/BuildPlayer.h"
#include "Editor/Src/EditorUserBuildSettings.h"
#include "Runtime/Serialize/BuildTargetVerification.h"
#endif

#if SUPPORT_SERIALIZATION_FROM_DISK
#include "Runtime/VirtualFileSystem/ArchiveFileSystem/ArchiveFileSystem.h"
#include "Runtime/VirtualFileSystem/AssetBundleFileSystem/AssetBundleFileSystem.h"
#endif // SUPPORT_SERIALIZATION_FROM_DISK


static char const* kIncompatibleScriptsMsg = "The AssetBundle '%s' could not be loaded because it references scripts that are not compatible with the currently loaded ones. Rebuild the AssetBundle to fix this error.";
static char const* kIncompatibleRuntimeClassMsg = "The AssetBundle '%s' could not be loaded because it contains run-time classes of incompatible version. Rebuild the AssetBundle to fix this error.";
static char const* kIncompatibleRuntimeMsg = "The AssetBundle '%s' could not be loaded because it is not compatible with this newer version of the Unity runtime. Rebuild the AssetBundle to fix this error.";

bool TestAssetBundleCompatibility(AssetBundle& bundle, const core::string& bundleName, core::string& error)
{
    error = core::string();

    // Check against our runtime compatibility version to see if there's
    // been some more profound changes to the runtime that prevent old
    // asset bundles from working.

    if (bundle.m_RuntimeCompatibility < AssetBundle::CURRENT_RUNTIME_COMPATIBILITY_VERSION)
    {
        error = Format(kIncompatibleRuntimeMsg, bundleName.c_str());
        return false;
    }

    return true;
}

bool TestAssetBundleCompatibility(const core::string& bundlePath, const core::string& bundleName, core::string& error)
{
    PersistentManager& pm = GetPersistentManager();
    SerializedFile* stream = pm.GetSerializedFileInternal(bundlePath);
    Assert(stream != NULL);

    // If type tree enabled, we should always be able to read the stream.
    if (stream->IsTypeTreeEnabled())
        return true;

    const SerializedFile::TypeVector& serializedTypes = stream->GetTypes();

#if UNITY_EDITOR
    // Update the script hashes to the build settings.
    // If the users build the AssetBundles without typetree, then we need the script hashes to do the script compatibility check when loading the AssetBundles.
    // So we have to make sure we update the build settings before loading AssetBundle.
    // Please refer to case 756567 for more information.
    UpdateBuildSettingsScriptHashes();
#endif
    BuildSettings& buildSettings = GetBuildSettings();

    for (SerializedFile::TypeVector::const_iterator it = serializedTypes.begin(); it != serializedTypes.end(); ++it)
    {
        Hash128 currentTypeHash;

        const Unity::Type* type = it->GetType();

        const bool isScript = type == TypeOf<MonoBehaviour>();

        if (isScript)
            currentTypeHash = buildSettings.GetHashOfScript(it->GetScriptID());
        else
            currentTypeHash = buildSettings.GetHashOfType(type);

        if (currentTypeHash != it->GetOldTypeHash())
        {
            if (isScript)
                error = Format(kIncompatibleScriptsMsg, bundleName.c_str());
            else
                error = Format(kIncompatibleRuntimeClassMsg, bundleName.c_str());

            return false;
        }
    }

    return true;
}

core::string GetAssetBundlePrefix(const core::string& mainAssetFileName)
{
    if (IsAssetBundleFilename(mainAssetFileName))
        return GetFileNameWithoutExtension(mainAssetFileName) + "/";

    return core::string();
}

core::string GetAbsoluteAssetBundlePrefix(const core::string& mainAssetFileName)
{
    return AssetBundle::kAssetBundleRootPath + GetAssetBundlePrefix(mainAssetFileName);
}

bool IsAssetBundleFilename(const core::string& filename)
{
    return (BeginsWith(filename, "BuildPlayer-") ||
            BeginsWith(filename, "CustomAssetBundle") ||
            BeginsWith(filename, "CAB"));
}

void UnloadAssetBundleFileStreams(const std::vector<core::string>& fileStreams)
{
    PersistentManager& pm = GetPersistentManager();
    for (vector<core::string>::const_iterator it = fileStreams.begin(); it != fileStreams.end(); ++it)
    {
        pm.UnloadStream(*it, true);
    }
}

static void ForcePreload(AssetBundle& bundle, dynamic_array<InstanceID> preloadObjects, bool scriptsOnly)
{
    GetAssetBundleManager().CollectPreloadDataDependencies(&bundle, bundle.m_Dependencies, preloadObjects, scriptsOnly, false);

    for (int i = 0; i < preloadObjects.size(); i++)
    {
        PPtr<Object> preload(preloadObjects[i]);
        preload.IsValid();
    }
}

static void ProcessAssetBundleEntries(AssetBundle& bundle, const AssetBundle::range& entries, ScriptingSystemTypeObjectPtr systemTypeInstance, dynamic_array<Object*>& output, bool stopAfterOne)
{
    dynamic_array<InstanceID> assetsToLoad(kMemTempAlloc);
    dynamic_array<InstanceID> assetsLoaded(kMemTempAlloc);
    dynamic_array<PPtr<Object> > assets;
    AssetBundleLoadAssetOperation::PreparePreloadAssets(bundle, entries, systemTypeInstance, stopAfterOne, assetsToLoad, assetsLoaded, assets);

    if (!bundle.m_ExplicitDataLayout)
    {
        // Until we fix the inconsistent writing of preload data, this very odd looking loading block is the current fastest method to load an asset from a bundle
        // preload data has 2 formats: full and sparse, in the full format we have a list of exactly what is needed to load so we only need to sort the data,
        // in the sparse format we will need to find references to assets and expand the preload data to include all the objects in that asset
        // The root problem is that we have fairly complex assets and object references, so CollectPreloadDataDependencies is just a best guess method and is greedy
        // so we end up loading more objects than absolutely necessary. Loading objects in this order: Scripts, Main Asset, Remaining while calling
        // CollectPreloadDataDependencies for Scripts and Remaining reduce how greedy we are in object loading for both full and sparse formats.
        // Asset Bundle team will be migrating all preload data to the full format during the build pipeline rewrite. (ryanc 5/15/17)
        ForcePreload(bundle, assetsToLoad, true);
        for (dynamic_array<PPtr<Object> >::iterator it = assets.begin(); it != assets.end(); ++it)
            it->IsValid();
    }
    ForcePreload(bundle, assetsToLoad, false);

    ScriptingClassPtr klass = scripting_class_from_systemtypeinstance(systemTypeInstance);
    for (dynamic_array<PPtr<Object> >::iterator it = assets.begin(); it != assets.end(); ++it)
    {
        Object* object = (*it);
        if (object == NULL)
            continue; // Object failed to load for some reason

        ScriptingObjectPtr scriptingObject = Scripting::ScriptingWrapperFor(object);
        if (scriptingObject && scripting_class_is_subclass_of(scripting_object_get_class(scriptingObject), klass))
            output.push_back(object);
    }
}

Object* LoadNamedObjectFromAssetBundle(AssetBundle& bundle, const core::string& name, ScriptingSystemTypeObjectPtr type)
{
    AssetBundle::range found = bundle.GetPathRange(name);

    dynamic_array<Object*> result(kMemTempAlloc);
    ProcessAssetBundleEntries(bundle, found, type, result, true);
    if (result.empty())
        return NULL;

    return result[0];
}

void LoadAssetWithSubAssetFromAssetBundle(AssetBundle& bundle, const core::string& name, ScriptingSystemTypeObjectPtr type, dynamic_array<Object*>& output)
{
    // Name is empty when loading all objects.
    AssetBundle::range found = name.empty() ? bundle.GetAll() : bundle.GetPathRange(name);
    ProcessAssetBundleEntries(bundle, found, type, output, false);
}

void LoadAssetsFromAssetBundle(AssetBundle& bundle, const AssetBundle::range& assets, dynamic_array<SInt32>* dependencies, ScriptingSystemTypeObjectPtr type, bool onlyFirst, dynamic_array<Object*>& output)
{
    ProcessAssetBundleEntries(bundle, assets, type, output, onlyFirst);
}

Object* LoadMainObjectFromAssetBundle(AssetBundle& bundle)
{
    // Don't load if it is already loaded.
    Object* obj = Object::IDToPointer(bundle.m_MainAsset.asset.GetInstanceID());
    if (obj != NULL)
        return obj;

    dynamic_array<InstanceID> preloadAssets(kMemTempAlloc);
    InstanceID mainAssetInstanceID = AssetBundleLoadAssetOperation::PrepareMainAssetPreloadList(bundle, preloadAssets);
    if (!bundle.m_ExplicitDataLayout)
    {
        ForcePreload(bundle, preloadAssets, true);
        bundle.m_MainAsset.asset.IsValid();
    }
    ForcePreload(bundle, preloadAssets, false);

    return PPtr<Object>(mainAssetInstanceID);
}

void GetAllAssetNamesFromAssetBundle(AssetBundle& assetBundle, std::vector<core::string>& assetNames)
{
    if (assetBundle.m_IsStreamedSceneAssetBundle)
        return;

    // Return the asset names and remove the duplicate names(for assets have sub assets, there would be duplicate names).
    for (AssetBundle::AssetMap::const_iterator it = assetBundle.m_PathContainer.begin(); it != assetBundle.m_PathContainer.end(); ++it)
    {
        if (!assetNames.empty() && it->first == assetNames.back())
            continue;

        assetNames.push_back(it->first);
    }
}

void GetAllScenePathsFromAssetBundle(AssetBundle& assetBundle, std::vector<core::string>& scenePaths)
{
    if (!assetBundle.m_IsStreamedSceneAssetBundle)
        return;

    for (AssetBundle::AssetMap::const_iterator it = assetBundle.m_PathContainer.begin(); it != assetBundle.m_PathContainer.end(); ++it)
    {
        scenePaths.push_back(it->first);
    }
}
