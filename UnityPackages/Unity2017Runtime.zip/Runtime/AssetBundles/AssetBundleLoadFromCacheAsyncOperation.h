#pragma once

#include "Runtime/AssetBundles/AssetBundleLoadFromStreamAsyncOperation.h"

#if ENABLE_CACHING

/// AssetBundleCreateOperation which fetches data from a cache and supports feeding.
/// Used for WWW backward compatibility.
class AssetBundleLoadFromCacheAsyncOperation : public AssetBundleLoadFromStreamAsyncOperation
{
public:
    AssetBundleLoadFromCacheAsyncOperation(MemLabelId label, const core::string& assetBundleName);
    virtual ~AssetBundleLoadFromCacheAsyncOperation();

    void SetCacheHash(const Hash128& hash) { m_CacheHash = hash; }
    void SetCacheName(const core::string& name) { m_cachedName = name; }
    void SetCacheUrl(const core::string& url) { m_Url = url; }

    virtual bool LoadCachedArchive();

    void Execute();
    void ExecuteSynchronously();

private:
    static void LoadCachedArchiveJob(AssetBundleLoadFromCacheAsyncOperation* this_);

    core::string m_cachedName;
    Hash128 m_CacheHash;
    core::string m_Url;
};

#endif // ENABLE_CACHING
