#pragma once

#include "Runtime/AssetBundles/AssetBundleLoadFromStreamAsyncOperation.h"

class AssetBundleLoadFromMemoryAsyncOperation : public AssetBundleLoadFromStreamAsyncOperation
{
public:
    AssetBundleLoadFromMemoryAsyncOperation(MemLabelId label);

    void Execute(const UInt8* dataPtr, size_t dataSize);
    void ExecuteSynchronously(const UInt8* dataPtr, size_t dataSize);

private:
    static void FinalizeJob(AssetBundleLoadFromMemoryAsyncOperation* this_);
};
