#pragma once

#include "Runtime/PreloadManager/PreloadManager.h"
#include "Runtime/AssetBundles/AssetBundle.h"
#include "Runtime/VirtualFileSystem/ArchiveFileSystem/ArchiveStorageReader.h"
#include "Runtime/Testing/Faking.h"

/// Class which is responsible for the loading of AssetBundle object from a
/// prepared archive file (uncompressed or chunk-compressed).
class AssetBundleLoadFromAsyncOperation : public PreloadManagerOperation
{
public:
    AssetBundleLoadFromAsyncOperation(MemLabelId label);
    virtual ~AssetBundleLoadFromAsyncOperation();

    /// Simply deref and return AB pointer
    AssetBundle* GetAssetBundle() const
    {
        __FAKEABLE_METHOD__(AssetBundleLoadFromAsyncOperation, GetAssetBundle, ());

        return m_AssetBundle;
    }

    /// Return AB name that is being created
    void SetAssetBundleName(const core::string& str) { m_AssetBundleName = str; }
    const char* GetAssetBundleName() const { return m_AssetBundleName.c_str(); }

    enum AssetBundleLoadResult
    {
        kResultSuccess = 0,
        kResultCancelled,
        kResultNotMatchingCrc,
        kResultFailedCache,
        kResultNotValidAssetBundle,
        kResultNoSerializedData,
        kResultNotCompatible,
        kResultAlreadyLoaded,
        kResultFailedRead,
        kResultFailedDecompression,
    };

    /// Return true if we have a valid AssetBundle object
    bool DidSucceed() const { return m_Result == kResultSuccess && m_AssetBundle.GetInstanceID() != InstanceID_None; }
    /// Returns true if request was cancelled
    bool IsCancelled() const { return m_Result == kResultCancelled; }
    /// Return result error code
    AssetBundleLoadResult GetResult() const { return m_Result; }
    /// Return result string
    core::string GetResultStr() const;

    /// Set crc of the uncompressed data the loaded AB should be checked against.
    /// If crc doesn't match, bundle won't be loaded.
    void SetExpectedCrc32(UInt32 crc) { m_ExpectedCrc32 = crc; }
    UInt32 GetExpectedCrc32() const { return m_ExpectedCrc32; }

    /// Set whether to perform runtime compatibility checks or not.  Unfortunately, in the
    /// editor we get lots of old asset bundles handed to us from the asset store to deliver
    /// previews.  Given that in the editor we can actually still run that content (unlike in
    /// players), we allow disabling checks for those bundles.
    ///
    /// This is an internal feature only.
    void SetEnableCompatibilityChecks(bool value) { m_EnableCompatibilityChecks = value; }

    /// Start PreloadManager integration process
    void IntegrateWithPreloadManager();
    /// Integration immediately
    void IntegrateImmediately();

    /// Cancel operation
    void Cancel();


    /// AsyncOperation impl
    virtual bool IsDone();
    UInt64 GetSize() const;

    /// PreloadManagerOperation impl
    virtual void Perform();
    virtual void IntegrateMainThread();
#if ENABLE_PROFILER
    virtual core::string GetDebugName() { return "AssetBundleCreateAsyncOperation"; }
#endif

protected:
    /// Return true if storage was already initialized
    bool IsAssetBundleStorageInitialized() const { return m_Storage != NULL; }

    enum InitializeResult
    {
        kInitializeError = -1,
        kInitializeSuccess = 0,
        kInitializeHasStreamBlocks
    };
    /// Create and initialize archive file
    InitializeResult InitializeAssetBundleStorage(const core::string& path, UInt64 offset);
    InitializeResult InitializeAssetBundleStorage(FileSystemEntry& fileEntry, UInt64 offset, bool canCloseFile = true);
    void DeleteStorage();

    /// Check if archive has correct files.
    bool IsDirectoryInfoValid(const ArchiveStorageHeader::DirectoryInfo& directoryInfo) const;
    /// Check if storage's data has valid crc32
    bool IsCrc32Valid();

    /// Set internal error result
    void SetResult(AssetBundleLoadResult r, const char* resultStr = NULL);

    /// Return true is bundle was loaded
    bool WasLoaded() const { return m_AssetBundle.GetInstanceID() != InstanceID_None; }

    /// Path of the folder where we store bundle's data.
    /// Could be temporary memory folder or cache folder.
    core::string m_StorageCleanupPath;
    /// Path is a cache path.
    bool m_IsStorageCleanupPathInCache;

private:
    /// Load all SerializedFile data in the archive into PersistentManager
    bool TryToLoadAndInitializeAssetBundle();
    /// Create AssetBundle object
    bool InitializeAssetBundle(const core::string& mainAssetBundleFilename);

    /// Return string error for the given result code
    core::string GetResultStr(AssetBundleLoadResult r) const;
    /// Output the error
    void PrintError() const;

    /// Final storage which is associated with a loaded AB
    ArchiveStorageReader* m_Storage;
    /// Constructed AB object reference
    PPtr<AssetBundle> m_AssetBundle;

    /// If not 0, we calculate crc of an input data and compare it against this value to verify data integrity.
    UInt32 m_ExpectedCrc32;
    UInt64 m_CompressedSize;

    /// Load result code
    volatile AssetBundleLoadResult m_Result;
    /// Error string
    core::string m_ResultStr;
    mutable Mutex m_ResultStrMutex;

    /// Name we want to refer to AB
    core::string m_AssetBundleName;
    bool m_EnableCompatibilityChecks;
};
