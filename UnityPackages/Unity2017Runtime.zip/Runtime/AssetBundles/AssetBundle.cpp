#include "UnityPrefix.h"
#include "AssetBundle.h"
#include "Runtime/Misc/HasNoReferencesAttribute.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Serialize/PersistentManager.h"
#include "Runtime/Utilities/PathNameUtility.h"

#if UNITY_EDITOR
#include "Editor/Src/Utility/RuntimeClassHashing.h"
#endif

#if ENABLE_CACHING
#include "Runtime/Misc/CachingManager.h"
#endif

REGISTER_TYPE_ATTRIBUTES(AssetBundle, (HasNoReferences, ()));
IMPLEMENT_REGISTER_CLASS(AssetBundle, 142);
IMPLEMENT_OBJECT_SERIALIZE(AssetBundle);

const char* AssetBundle::kAssetBundleRootPath = "archive:/";

AssetBundle::AssetBundle(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
    , m_RuntimeCompatibility(CURRENT_RUNTIME_COMPATIBILITY_VERSION)
    , m_PreloadTable(label)
    , m_AssetLookupContainer(label)
    , m_TypeLookupContainer(label)
    , m_ArchiveStorage(NULL)
    , m_IsArchiveStorageCleanupPathInCache(false)
    , m_IsStreamedSceneAssetBundle(false)
    , m_ExplicitDataLayout(false)
    , m_PathFlags(kGenerateAll)
{
    // Mark as kHideAndDontSave, so that AssetBundles are not unloaded on scene loads
    SetHideFlags(Object::kHideAndDontSave);
}

template<class TransferFunc>
void AssetBundle::AssetInfo::Transfer(TransferFunc& transfer)
{
    TRANSFER(preloadIndex);
    TRANSFER(preloadSize);
    TRANSFER(asset);
}

template<class TransferFunc>
void AssetBundle::Transfer(TransferFunc& transfer)
{
    Super::Transfer(transfer);
    transfer.SetVersion(3);
    Assert((transfer.GetFlags() & kPerformUnloadDependencyTracking) == 0);

    if (transfer.IsReading())
    {
        m_RuntimeCompatibility = 0;
        m_PathFlags = kGenerateAll;
    }

    if (transfer.IsOldVersion(1))
    {
        std::multimap<core::string, PPtr<Object> > oldContainer;
        transfer.Transfer(oldContainer, "m_Container");
        PPtr<Object> mainAsset;
        transfer.Transfer(mainAsset, "m_MainAsset");

        m_PathContainer.clear();
        for (std::multimap<core::string, PPtr<Object> >::iterator i = oldContainer.begin(); i != oldContainer.end(); i++)
        {
            AssetInfo info;
            info.preloadIndex = 0;
            info.preloadSize = 0;
            info.asset = i->second;
            m_PathContainer.insert(std::make_pair(i->first, info));
        }

        m_MainAsset.preloadIndex = 0;
        m_MainAsset.preloadSize = 0;
        m_MainAsset.asset = mainAsset;
    }
    else
    {
        transfer.Transfer(m_PreloadTable, "m_PreloadTable");
        transfer.Transfer(m_PathContainer, "m_Container");
        transfer.Transfer(m_MainAsset, "m_MainAsset");

        if (!transfer.IsOldVersion(2))
            transfer.Transfer(m_RuntimeCompatibility, "m_RuntimeCompatibility");

        transfer.Transfer(m_AssetBundleName, "m_AssetBundleName");
        transfer.Transfer(m_Dependencies, "m_Dependencies");
        transfer.Transfer(m_IsStreamedSceneAssetBundle, "m_IsStreamedSceneAssetBundle");
        transfer.Align();
        TRANSFER_ENUM(m_ExplicitDataLayout);
        TRANSFER_ENUM(m_PathFlags);
        TRANSFER(m_SceneHashes);
    }

    BuildLookupAndNameContainerFromPathContainer();
}

void AssetBundle::DebugPrintContents()
{
    for (iterator i = m_PathContainer.begin(); i != m_PathContainer.end(); i++)
    {
        printf_console("- %s\n", i->first.c_str());
    }
}

AssetBundle::range AssetBundle::GetPathRange(const core::string& inPath)
{
    core::string path(inPath);
    ConvertSeparatorsToUnity(path);
    // Don't auto convert to lower case for bundles built with new build pipeline
    if (!m_ExplicitDataLayout)
        path = ToLower(path);

    // Lookup asset path as is.
    AssetBundle::range foundRange = m_PathContainer.equal_range(path);
    if (foundRange.first != foundRange.second)
        return foundRange;

    // If path contains directory separators, consider it is as an exact path and return
    if (path.find_first_of(kPathNameSeparator) != core::string::npos)
        return foundRange;

    // Lookup asset name as is.
    foundRange = m_NameContainer.equal_range(path);
    if (foundRange.first != foundRange.second)
        return foundRange;

    // Lookup asset name with extension as is.
    foundRange = m_FileContainer.equal_range(path);
    if (foundRange.first != foundRange.second)
        return foundRange;

    return foundRange;
}

AssetBundle::range AssetBundle::GetAll()
{
    return make_pair(m_PathContainer.begin(), m_PathContainer.end());
}

Object* AssetBundle::GetImpl(const Unity::Type* type, const core::string& path)
{
    range r = GetPathRange(path);
    for (iterator i = r.first; i != r.second; i++)
    {
        Object* obj = i->second.asset;
        if (obj && obj->Is(type))
            return obj;
    }

    //printf_console(("Failed loading " + path  + "\n***********\n").c_str());
    //DebugPrintContents();

    return NULL;
}

void AssetBundle::ThreadedCleanup()
{
    // Don't kill of m_UncompressedFileInfo here due to weird
    // logic in UnloadAssetBundle() that will access the UncompressedFileInfo
    // even after the AssetBundle has been deleted through DestroyAllAtPath().
}

bool AssetBundle::GetPreloadData(InstanceID instanceID, dynamic_array<InstanceID>& preloadObjects) const
{
    AssetBundle::AssetLookupMap::const_iterator it = m_AssetLookupContainer.find(instanceID);
    if (it == m_AssetLookupContainer.end())
        return false;

    const AssetBundle::AssetInfo* assetInfo = it->second;
    for (int i = 0; i < assetInfo->preloadSize; i++)
    {
        PPtr<Object> preload = m_PreloadTable[i + assetInfo->preloadIndex];
        preloadObjects.push_back(preload.GetInstanceID());
    }

    return true;
}

bool AssetBundle::GetSceneHash(const core::string& scenePath, core::string& sceneHash) const
{
    SceneHashMap::const_iterator it = m_SceneHashes.find(scenePath);
    if (it == m_SceneHashes.end())
        return false;

    sceneHash = it->second;
    return true;
}

const Unity::Type* AssetBundle::GetAssetType(InstanceID instanceId) const
{
    TypeLookupMap::const_iterator it = m_TypeLookupContainer.find(instanceId);
    if (it == m_TypeLookupContainer.end())
        return NULL;

    return it->second;
}

bool AssetBundle::ShouldIgnoreInGarbageDependencyTracking()
{
    return true;
}

void AssetBundle::BuildLookupAndNameContainerFromPathContainer()
{
    m_NameContainer.clear();
    m_FileContainer.clear();
    m_AssetLookupContainer.clear();
    m_TypeLookupContainer.clear();

    dynamic_array<InstanceID> objects(kMemTempAlloc);

    for (AssetBundle::AssetMap::const_iterator it = m_PathContainer.begin(); it != m_PathContainer.end(); ++it)
    {
        InstanceID instanceID = it->second.asset.GetInstanceID();
        objects.push_back(instanceID);

        if (HasFlag(m_PathFlags, kGenerateNames))
        {
            core::string name = GetFileNameWithoutExtension(it->first);
            m_NameContainer.insert(std::make_pair(name, it->second));
        }

        if (HasFlag(m_PathFlags, kGenerateFiles))
        {
            core::string file = GetLastPathNameComponent(it->first);
            m_FileContainer.insert(std::make_pair(file, it->second));
        }

        m_AssetLookupContainer.insert(std::make_pair(instanceID, &it->second));
    }

    dynamic_array<const Unity::Type*> types(kMemTempAlloc);
    GetPersistentManager().GetSerializedTypes(objects, types);
    for (size_t i = 0; i < types.size(); ++i)
        m_TypeLookupContainer.insert(std::make_pair(objects[i], types[i]));
}
