#pragma once

#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/Scripting/BindingsDefs.h"

#include <utility>

class ArchiveStorageReader;

class AssetBundle : public NamedObject
{
    REGISTER_CLASS(AssetBundle);
    DECLARE_OBJECT_SERIALIZE();
public:

    enum
    {
        /// A simple integer version count to keep track of changes to the
        /// runtime that cause asset bundles to no longer work as intended.
        /// Increase this version whenever you need to break backwards-compatibility.
        /// An example of this is when we started to no longer package all default
        /// resources with every player and thus broke asset bundles that were
        /// referencing these resources.
        ///
        /// @see TestAssetBundleCompatiblity
        CURRENT_RUNTIME_COMPATIBILITY_VERSION = 1
    };

    enum PathFlags
    {
        kPathFlagsNone = 0,

        // Generates the m_NameContainer at laod
        kGenerateNames = 1 << 0,

        // Generates the m_FileContainer at load
        kGenerateFiles = 1 << 1,

        // Generates both m_NameContainer & m_FileContainer at load
        kGenerateAll = kGenerateNames | kGenerateFiles
    };
    ENUM_FLAGS_AS_MEMBER(PathFlags);

    // Root path to the assetbundle filesystem - "archive:/"
    static const char* kAssetBundleRootPath;

    struct AssetInfo
    {
        DECLARE_SERIALIZE(AssetInfo)

        int preloadIndex;
        int preloadSize;

        PPtr<Object> asset;

        AssetInfo() { preloadIndex = 0; preloadSize = 0; }
    };

    AssetBundle(MemLabelId label, ObjectCreationMode mode);
    // ~AssetBundle (); declared-by-macro

    typedef  std::multimap<core::string, AssetInfo> AssetMap;
    typedef  AssetMap::iterator iterator;
    typedef  std::pair<iterator, iterator> range;

    typedef core::hash_map<core::string, core::string> SceneHashMap;

    typedef core::hash_map<InstanceID, const AssetInfo*> AssetLookupMap;
    typedef core::hash_map<InstanceID, const Unity::Type*> TypeLookupMap;


    range GetAll();
    range GetPathRange(const core::string& path);

    virtual bool ShouldIgnoreInGarbageDependencyTracking();

    void DebugPrintContents();

    template<class T>
    T* Get(const core::string& path)
    {
        Object* res = GetImpl(TypeOf<T>(), path);
        return static_cast<T*>(res);
    }

    Object* GetImpl(const Unity::Type* type, const core::string& path);

    UInt32 m_RuntimeCompatibility;

    /// AssetInfo for the main asset.  Has no associated name.
    AssetInfo m_MainAsset;

    /// Table of objects that need to be pulled from the bundle by the preload
    /// manager when a specific asset is loaded from the bundle.  Each AssetInfo
    /// entry has an associated range of entries in the preload table.
    dynamic_array<PPtr<Object> > m_PreloadTable;

    /// Map of asset paths contained in the bundle.  Multiple objects may have the same path.
    AssetMap m_PathContainer;

    /// Map of asset names contained in the bundle.  Multiple objects may have the same name.
    AssetMap m_NameContainer;

    /// Map of asset names contained in the bundle.  Multiple objects may have the same name.
    AssetMap m_FileContainer;

    /// Map of InstanceIDs to paths for faster lookup in preoloading
    AssetLookupMap m_AssetLookupContainer;

    /// Map of InstanceIDs to types for faster lookup in preloading
    TypeLookupMap m_TypeLookupContainer;

    /// Associated file storage.
    ArchiveStorageReader* m_ArchiveStorage;
    /// Folder which we have to remove once the bundle is unloaded.
    /// This could be a temporary memory folder or cache folder.
    core::string m_ArchiveStorageCleanupPath;
    /// True if m_ArchiveStorageCleanupPath is a cache path.
    bool m_IsArchiveStorageCleanupPathInCache;

    ConstantString m_AssetBundleName;
    // Cannot use dynamic_array as it won't call the default constructor of ConstantString.
    std::vector<ConstantString> m_Dependencies;

    bool m_IsStreamedSceneAssetBundle;

    bool m_ExplicitDataLayout;

    // Eventually we want to deprecate & remove m_NameContainer & m_FileContainer
    // For now, add an option to turn these maps off
    PathFlags m_PathFlags;

    // Map of scene path to internal name
    SceneHashMap m_SceneHashes;

    bool GetPreloadData(InstanceID instanceID, dynamic_array<InstanceID>& preloadObjects) const;

    bool GetSceneHash(const core::string& scenePath, core::string& sceneHash) const;

    const Unity::Type* GetAssetType(InstanceID instanceId) const;

private:
    void BuildLookupAndNameContainerFromPathContainer();
};

BIND_MANAGED_TYPE_NAME(AssetBundle, UnityEngine_AssetBundle)
