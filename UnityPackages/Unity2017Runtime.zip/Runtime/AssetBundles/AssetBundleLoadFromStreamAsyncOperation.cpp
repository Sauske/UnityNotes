#include "UnityPrefix.h"
#include "Runtime/AssetBundles/AssetBundleLoadFromStreamAsyncOperation.h"
#include "Runtime/Input/TimeManager.h"
#include "Runtime/Utilities/CRC.h"
#include "Runtime/Utilities/FileUtilities.h"
#include "Runtime/VirtualFileSystem/MemoryFileSystem/MemoryFile.h"
#include "Runtime/VirtualFileSystem/MemoryFileSystem/MultiBlocksMemoryFileData.h"
#include "Runtime/Testing/Faking.h"

#if ENABLE_CACHING
#include "Runtime/Misc/CachingManager.h"
#endif // ENABLE_CACHING

#if PLATFORM_IPHONE || PLATFORM_TVOS
#include "PlatformDependent/iPhonePlayer/TrampolineInterface.h"
#endif

const char* AssetBundleLoadFromStreamAsyncOperation::kCachedArchiveFilename = "__data";
const UInt32 AssetBundleLoadFromStreamAsyncOperation::kCachedArchiveChunkSize = 128 * 1024;

AssetBundleLoadFromStreamAsyncOperation::AssetBundleLoadFromStreamAsyncOperation(MemLabelId label)
    : AssetBundleLoadFromAsyncOperation(label)
    , m_Cache(NULL)
    , m_ArchiveConverter(NULL)
    , m_ArchiveConverterProgress(0)
    , m_CacheId()
    , m_AllowThreadedConversion(false)
{
}

AssetBundleLoadFromStreamAsyncOperation::~AssetBundleLoadFromStreamAsyncOperation()
{
    if (m_ArchiveConverter != NULL)
        UNITY_DELETE(m_ArchiveConverter, kMemFile);

    // Release lock file in a temporary folder in case of failure (cache, decompression, etc.)

    m_LockFile.Close();
}

float AssetBundleLoadFromStreamAsyncOperation::GetProgress()
{
    if (WasLoaded())
        return 1.0f;

    const float kConvertWeight = 0.9f;
    const float kPreloadWeight = 0.1f;
    float preloadProgress = AssetBundleLoadFromAsyncOperation::GetProgress();
    return m_ArchiveConverterProgress * kConvertWeight + preloadProgress * kPreloadWeight;
}

void AssetBundleLoadFromStreamAsyncOperation::SetPriority(int priority)
{
    AssetBundleLoadFromAsyncOperation::SetPriority(priority);
    if (m_ArchiveConverter != NULL)
        m_ArchiveConverter->SetPriority((ThreadPriority)priority);
}

bool AssetBundleLoadFromStreamAsyncOperation::OnArchiveStorageBlocksInfoProcessed(ArchiveStorageConverter* converter, ArchiveStorageReader* storage)
{
    AssertMsg(m_ArchiveConverter != NULL, "m_ArchiveConverter must be created!");

    // Try disk cache
    if (!TryInitializeDiskCache())
    {
        // Fallback to memory
        if (!TryInitializeMemoryCache())
        {
            SetResult(kResultFailedCache);
            return false;
        }
    }

    // Mark output folder as temp and lock it
    SetFileFlags(m_StorageCleanupPath, kFileFlagDontIndex | kFileFlagTemporary, kFileFlagDontIndex | kFileFlagTemporary);
    if (!m_LockFile.Open(AppendPathName(m_StorageCleanupPath, "__lock"), File::kWritePermission, File::kSilentReturnOnOpenFail))
    {
        SetResult(kResultFailedCache);
        return false;
    }
    m_LockFile.Lock(File::kExclusive, false);

    // Set default compression
    CompressionType compression = kCompressionLz4;
#if ENABLE_CACHING
    if (!GetCachingManager().GetCompressionEnabled())
        compression = kCompressionNone;
#endif
    // Initialize output archive
    if (!m_ArchiveConverter->InitializeTargetArchive(AppendPathName(m_StorageCleanupPath, kCachedArchiveFilename), compression, kCachedArchiveChunkSize))
    {
        SetResult(kResultFailedDecompression);
        return false;
    }

    return true;
}

bool AssetBundleLoadFromStreamAsyncOperation::OnArchiveStorageDirectoryInfoProcessed(ArchiveStorageConverter* converter, ArchiveStorageReader* storage)
{
    AssertMsg(m_ArchiveConverter != NULL, "m_ArchiveConverter must be created!");

    if (!IsDirectoryInfoValid(*m_ArchiveConverter->GetDirectoryInfo()))
    {
        SetResult(kResultNotValidAssetBundle);
        return false;
    }

    return true;
}

bool AssetBundleLoadFromStreamAsyncOperation::LoadCachedArchive()
{
    return false;
}

bool AssetBundleLoadFromStreamAsyncOperation::FeedStream(const void* data, size_t size)
{
    __FAKEABLE_METHOD__(AssetBundleLoadFromStreamAsyncOperation, FeedStream, (data, size));

    if (GetResult() != kResultSuccess)
        return false;

    if (IsAssetBundleStorageInitialized())
    {
        AssertFormatMsg(false, "Internal error: Invalid AssetBundle load state - can't feed more data: '%s'.", GetAssetBundleName());
        return false;
    }

    // Init converter if not yet created
    if (m_ArchiveConverter == NULL)
    {
        m_ArchiveConverter = UNITY_NEW(ArchiveStorageConverter(this, m_AllowThreadedConversion), kMemFile);
        m_ArchiveConverter->SetPriority((ThreadPriority)m_Priority);
    }

    if (data != NULL && size > 0)
    {
        // Feed converter
        if (m_ArchiveConverter->ProcessData(data, size) <= ArchiveStorageHeader::kError)
        {
            SetResult(kResultFailedDecompression);
            return false;
        }
    }

    m_ArchiveConverterProgress = m_ArchiveConverter->GetProgress();

    return true;
}

bool AssetBundleLoadFromStreamAsyncOperation::FinalizeStream()
{
    __FAKEABLE_METHOD__(AssetBundleLoadFromStreamAsyncOperation, FinalizeStream, ());

    if (GetResult() != kResultSuccess)
        return false;

    if (IsAssetBundleStorageInitialized())
    {
        AssertFormatMsg(false, "Internal error: Invalid AssetBundle load state - can't feed more data: '%s'.", GetAssetBundleName());
        return false;
    }

    AssertFormatMsg(m_ArchiveConverter != NULL, "Internal error: Invalid AssetBundle load state - date recompressor is not initialized: '%s'.", GetAssetBundleName());

    // Finish if no data anymore
    if (!FinalizeArchiveCreator())
    {
        SetResult(kResultFailedDecompression);
        return false;
    }

    m_ArchiveConverterProgress = 1.0f;

    return true;
}

UInt64 AssetBundleLoadFromStreamAsyncOperation::GetDownloadedBytes() const
{
    if (m_ArchiveConverter == NULL)
        return 0;

    return m_ArchiveConverter->GetOriginalArchiveSize();
}

UInt64 AssetBundleLoadFromStreamAsyncOperation::GetExpectedStreamSize() const
{
    if (m_ArchiveConverter == NULL)
        return 0;

    return m_ArchiveConverter->GetOriginalArchiveSize();
}

core::string AssetBundleLoadFromStreamAsyncOperation::CreateTempOutputDirectory(const core::string& prefix) const
{
    core::string baseFileName;
    const ArchiveStorageHeader::DirectoryInfo* directory = m_ArchiveConverter->GetDirectoryInfo();
    if (directory != NULL)
        baseFileName = directory->nodes[0].path.c_str();
    else
        baseFileName = "UnityAssetBundle";

    core::string pathNoExtension = AppendPathName(prefix, baseFileName);
    return CreateUniqueTempDirectory(pathNoExtension);
}

bool AssetBundleLoadFromStreamAsyncOperation::TryInitializeDiskCache()
{
    if (m_CacheId.empty())
        return false;

#if ENABLE_CACHING
    CachingManager& cachingManager = GetCachingManager();

    AssertMsg(m_Cache == NULL, "Cache Should be NULL.");
    m_Cache = &cachingManager.GetCurrentCache();
    m_Cache->AddRef();

    // Cleanup old data
    core::string cachePath = m_Cache->GetFullCacheFolder(m_CacheId, false);
    if (IsDirectoryCreated(cachePath) && !DeleteFileOrDirectory(cachePath))
    {
        WarningStringMsg("Couldn't remove existing cached file '%s'.", cachePath.c_str());
        return false;
    }

    // Check space for the new data
    UInt64 decompressedSize = m_ArchiveConverter->GetUncompressedArchiveSize();
    if (decompressedSize > m_Cache->GetCachingDiskSpaceFreeAndUsable())
    {
        if (!m_Cache->FreeSpace(decompressedSize))
        {
            WarningStringMsg("Not enough space in cache to write file '%s'.", cachePath.c_str());
            return false;
        }
    }

    // Create temp folder for the uncompressed archive
    core::string outputFolder = CachingManager::GetTempFolder();
    if (!CreateDirectory(outputFolder.c_str()))
    {
        WarningStringMsg("Couldn't create temporary cache directory '%s'!", outputFolder.c_str());
        return false;
    }

    m_StorageCleanupPath = outputFolder;
    m_IsStorageCleanupPathInCache = true;

    return true;
#else
    return false;
#endif // ENABLE_CACHING
}

bool AssetBundleLoadFromStreamAsyncOperation::TryInitializeMemoryCache()
{
    m_CacheId.clear();

    // Mount MemoryFS and create temp memory folder
    GetFileSystem().MountMemoryFileSystem();
    m_StorageCleanupPath = CreateTempOutputDirectory(kMemoryFileSystemMountPoint);
    if (m_StorageCleanupPath.empty())
        return false;

    m_IsStorageCleanupPathInCache = false;
    return true;
}

bool AssetBundleLoadFromStreamAsyncOperation::FinalizeArchiveCreator()
{
    UInt32 crc = 0;
    bool converterSuccess = m_ArchiveConverter->FinalizeTargetArchive(&crc);

    // We don't need converter any more.
    UNITY_DELETE(m_ArchiveConverter, kMemFile);
    m_ArchiveConverter = NULL;

    if (!converterSuccess)
        return false;

    // Check crc
    if (GetExpectedCrc32() != 0)
    {
        // We were able to compute it during conversion
        if (crc != 0)
        {
            if (GetExpectedCrc32() != crc)
            {
                SetResult(kResultNotMatchingCrc, Format("CRC Mismatch. Provided %x, calculated %x from data. Will not load AssetBundle '%s'", GetExpectedCrc32(), crc, GetAssetBundleName()).c_str());
                return false;
            }
        }
        else
        {
            // We have to do an extra pass to calculate crc as we just copied the data before.
            // To do it we simply initialize bundle in a temp folder.
            if (InitializeAssetBundleStorage(AppendPathName(m_StorageCleanupPath, kCachedArchiveFilename), 0) != kInitializeSuccess)
                return false;
            DeleteStorage();
        }

        // Avoid further crc checks
        SetExpectedCrc32(0);
    }

    // Move temp file to the persistent location if needed
    if (!MoveFilesToCachePath())
        return false;

    // Converted cached archive is ready, just load it now
    core::string cachedFilePath = AppendPathName(m_StorageCleanupPath, kCachedArchiveFilename);
    if (InitializeAssetBundleStorage(cachedFilePath, 0) != kInitializeSuccess)
        return false;

    // At this point assetbundle's container is valid and cached.

    return true;
}

bool AssetBundleLoadFromStreamAsyncOperation::MoveFilesToCachePath()
{
#if ENABLE_CACHING
    if (m_CacheId.empty())
        return true;

    AssertMsg(m_Cache != NULL, "Cache shouldn't be NULL.");

    // Unlock temp folder
    m_LockFile.Lock(File::kNone, false);
    m_LockFile.Close();
    DeleteFileOrDirectory(AppendPathName(m_StorageCleanupPath, "__lock"));

    // Make sure cache folder exists
    core::string cacheRootFolder = m_Cache->GetFullCacheFolder("", true);
    if (cacheRootFolder.empty())
    {
        SetResult(kResultFailedCache, Format("Couldn't create cache folder '%s' when caching AssetBundle '%s'.",
                m_StorageCleanupPath.c_str(), GetAssetBundleName()).c_str());
        return false;
    }

    // Create the cache folder if necessary.
    core::string cacheFolder = m_Cache->GetFullCacheFolder(m_CacheId, false);
    core::string directory = DeleteLastPathNameComponent(cacheFolder);
    if (!IsDirectoryCreated(directory))
    {
        if (!CreateDirectoryRecursive(directory))
            return false;
    }

    // Move temp file to a final cache location
    if (!MoveFolderToCacheFolder(m_StorageCleanupPath, cacheFolder))
    {
        SetResult(kResultFailedCache, Format("Couldn't move cache data '%s' into place '%s' when caching AssetBundle '%s'.",
                m_StorageCleanupPath.c_str(), cacheFolder.c_str(), GetAssetBundleName()).c_str());
        return false;
    }

    // Write info file.
    std::vector<core::string> fileNames;
    fileNames.push_back(kCachedArchiveFilename);
    size_t written = Cache::WriteInfoFileForCachedFile(cacheFolder, fileNames);
    if (!written)
    {
        SetResult(kResultFailedCache, Format("Couldn't write cache header file when caching AssetBundle '%s'.", GetAssetBundleName()).c_str());
        return false;
    }

    // Get the cached file size.
    FileSystemEntry convertedArchive(AppendPathName(cacheFolder, kCachedArchiveFilename).c_str());
    written += convertedArchive.Size();

    // TODO: unify with SetFileFlags?
#if PLATFORM_IPHONE || PLATFORM_TVOS
    UnityUpdateNoBackupFlag(AppendPathName(m_StorageCleanupPath, kCachedArchiveFilename).c_str(), 1);
#endif

    // Mark cached bundle as used immediately to prevent deletion while not actually opened yet.
    // Here we know that this is correct bundle and we will load it later.
    m_Cache->AddLoadedAssetBundle(cacheFolder);
    m_Cache->AddToCache(cacheFolder, written);

    m_StorageCleanupPath = cacheFolder;
    m_IsStorageCleanupPathInCache = true;

    m_Cache->Release();
    m_Cache = NULL;
#endif // ENABLE_CACHING

    return true;
}
