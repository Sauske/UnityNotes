#include "UnityPrefix.h"
#include "Runtime/AssetBundles/AssetBundleLoadFromFileAsyncOperation.h"
#include "Runtime/Jobs/BackgroundJobQueue.h"
#include "Runtime/Profiler/Profiler.h"

PROFILER_INFORMATION(gLoadFromFile, "AssetBundles.LoadFromFile", kProfilerLoading);

AssetBundleLoadFromFileAsyncOperation::AssetBundleLoadFromFileAsyncOperation(MemLabelId label)
    : AssetBundleLoadFromStreamAsyncOperation(label)
    , m_Offset(0)
{
}

AssetBundleLoadFromFileAsyncOperation::~AssetBundleLoadFromFileAsyncOperation()
{
}

void AssetBundleLoadFromFileAsyncOperation::SetPath(const core::string& path)
{
    m_Path = path;
    SetAssetBundleName(GetLastPathNameComponent(path));
}

void AssetBundleLoadFromFileAsyncOperation::Execute()
{
    // It uses PreloadManager at later stages, but decompression is executed on a background job
    // LoadArchive checks if we need decompression to memory, does that and then enqueue loadoperation in preloadmanager.
    GetBackgroundJobQueue().ScheduleJob(LoadArchiveJob, this);
}

void AssetBundleLoadFromFileAsyncOperation::ExecuteSynchronously()
{
    PROFILER_AUTO(gLoadFromFile, NULL);
    AssetBundleLoadFromFileAsyncOperation::InitializeResult result = LoadArchive();
    if (result == kInitializeHasStreamBlocks)
        ConvertArchive();

    IntegrateImmediately();
}

void AssetBundleLoadFromFileAsyncOperation::LoadArchiveJob(AssetBundleLoadFromFileAsyncOperation* this_)
{
    if (!this_->IsCancelled() && this_->LoadArchive() == kInitializeHasStreamBlocks)
    {
        // Need decompression
        GetBackgroundJobQueue().ScheduleJob(ConvertArchiveJob, this_);
    }
    else
    {
        this_->IntegrateWithPreloadManager();
    }
}

void AssetBundleLoadFromFileAsyncOperation::ConvertArchiveJob(AssetBundleLoadFromFileAsyncOperation* this_)
{
    if (!this_->IsCancelled())
        this_->ConvertArchive();
    this_->IntegrateWithPreloadManager();
}

AssetBundleLoadFromFileAsyncOperation::InitializeResult AssetBundleLoadFromFileAsyncOperation::LoadArchive()
{
    // Try to open archive as is
    AssetBundleLoadFromFileAsyncOperation::InitializeResult result = InitializeAssetBundleStorage(m_Path, m_Offset);
    return result;
}

bool AssetBundleLoadFromFileAsyncOperation::ConvertArchive()
{
    FileAccessor reader;
    if (!reader.Open(m_Path, kReadPermission))
        return false;

    reader.Seek(m_Offset, kBeginning);

    UInt64 archiveSize = reader.Size();
    dynamic_array<UInt8> buffer(kMemTempAlloc);
    buffer.resize_uninitialized(std::min<size_t>(kCachedArchiveChunkSize, archiveSize));

    // ConvertArchiveJob operation is running on another thread already, we don't need more threads.
    SetAllowThreadedConversion(false);

    for (;;)
    {
        UInt64 read;
        if (!reader.Read(buffer.size(), &buffer[0], &read) || read == 0)
            break;

        if (!FeedStream(&buffer[0], read))
            return false;
    }

    if (!FinalizeStream())
        return false;

    return true;
}
