#pragma once

#include "Runtime/BaseClasses/NamedObject.h"
#include "Runtime/Utilities/Hash128.h"
#include "Runtime/Containers/ConstantString.h"
#include "Runtime/Utilities/vector_map.h"
#include "Runtime/Utilities/vector_set.h"

class AssetBundleManifest : public NamedObject
{
    REGISTER_CLASS(AssetBundleManifest);
    DECLARE_OBJECT_SERIALIZE();
public:
    struct AssetBundleInfo
    {
        Hash128 m_AssetBundleHash;
        vector_set<SInt32> m_AssetBundleDependencies;

        DECLARE_SERIALIZE_NO_PPTR(AssetBundleInfo)
    };

    typedef vector_map<SInt32, AssetBundleInfo> AssetBundleInfoContainer;
    AssetBundleInfoContainer m_AssetBundleInfos;

    vector_map<SInt32, ConstantString> m_AssetBundleNames;
    vector_set<SInt32> m_AssetBundlesWithVariant;
public:

    AssetBundleManifest(MemLabelId label, ObjectCreationMode mode)
        : Super(label, mode)
    {
        SetHideFlags(Object::kHideAndDontSave);
    }

    // ~AssetBundleManifest (); declared-by-macro

    // Get all the assetBundles in the manifest file.
    void GetAllAssetBundles(std::vector<core::string>& assetBundleNames);

    // Get all the assetBundles with variant in the manifest file.
    void GetAllAssetBundlesWithVariant(std::vector<core::string>& assetBundleNames);

    // Get the assetBundle hash.
    Hash128 GetAssetBundleHash(const core::string& assetBundleName);

    // Collect the direct dependencies.
    void CollectDirectDependencies(const core::string& assetBundleName, std::vector<core::string>& dependencies);
    // Collect the dependencies includes both direct dependencies and implicit dependencies.
    void CollectAllDependencies(const core::string& assetBundleName, std::vector<core::string>& dependencies);

protected:
    void CollectAllDependenciesRecursively(SInt32 assetBundleIndex, std::set<SInt32>& dependencies);

    SInt32 GetAssetBundleIndex(const core::string& assetBundleName);
};

template<class TransferFunc>
void AssetBundleManifest::AssetBundleInfo::Transfer(TransferFunc& transfer)
{
    transfer.Transfer(m_AssetBundleHash, "AssetBundleHash");
    transfer.Transfer(m_AssetBundleDependencies, "AssetBundleDependencies");
}

template<class TransferFunc>
void AssetBundleManifest::Transfer(TransferFunc& transfer)
{
    Super::Transfer(transfer);

    transfer.Transfer(m_AssetBundleNames, "AssetBundleNames");
    transfer.Transfer(m_AssetBundlesWithVariant, "AssetBundlesWithVariant");
    transfer.Transfer(m_AssetBundleInfos, "AssetBundleInfos");
}

#if UNITY_EDITOR
class YAMLWrite;

template<>
void AssetBundleManifest::Transfer(YAMLWrite& transfer);

#endif
