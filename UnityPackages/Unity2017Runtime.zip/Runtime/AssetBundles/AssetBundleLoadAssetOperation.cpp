#include "UnityPrefix.h"
#include "Runtime/AssetBundles/AssetBundleLoadAssetOperation.h"
#include "Runtime/AssetBundles/AssetBundleManager.h"
#include "Runtime/AssetBundles/AssetBundleUtility.h"
#include "Runtime/Graphics/Substance/SubstanceSystem.h"
#include "Runtime/Scripting/Scripting.h"
#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/Serialize/LoadProgress.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Mono/MonoBehaviour.h"

PROFILER_INFORMATION(gAssetBundle_LoadAssetAsync, "AssetBundle.LoadAssetAsync", kProfilerLoading)
PROFILER_INFORMATION(gAssetBundle_LoadAssetAsyncCollectDependencies, "AssetBundle.LoadAssetAsync [Collecting dependencies]", kProfilerLoading)
PROFILER_INFORMATION(gAssetBundle_asset, "AssetBundle.asset", kProfilerLoading)
PROFILER_INFORMATION(gAssetBundle_allAssets, "AssetBundle.allAssets", kProfilerLoading)
PROFILER_WARNING(gAssetBundle_ForceLoad, "AssetBundle.asset/allAssets [Forced assets loading]", kProfilerLoading)

static void AddAssetsToPreload(const AssetBundle& bundle, int index, int size, dynamic_array<InstanceID>& preloadAssets)
{
    if (size > 0)
    {
        const PPtr<Object>* source = &bundle.m_PreloadTable[index];
        for (int i = 0; i < size; i++)
            preloadAssets.push_back(source[i].GetInstanceID());
    }
}

AssetBundleLoadAssetOperation::AssetBundleLoadAssetOperation(MemLabelId label, AssetBundle& bundle, const core::string& name, ScriptingSystemTypeObjectPtr type, bool includeSubAssets)
    : LoadOperation(label)
    , m_AssetBundle(&bundle)
    , m_AssetBundleName(bundle.m_AssetBundleName)
    , m_AssetName(name)
    , m_AssetType(type)
    , m_AssetsToLoadDependencies(kMemThread)
{
#if ENABLE_PROFILER || PROFILE_PRELOAD_MANAGER
    m_DebugName = "Loading AssetBundle asset: " + name;
#endif

    GetAssetBundleManager().AddAssetBundleLoadAssetOperation(this);

    // Build initial list of objects to load
    if ((m_AssetBundle.GetInstanceID() == InstanceID_None) || (Object::IDToPointerThreadSafe(m_AssetBundle.GetInstanceID()) == NULL))
    {
        WarningStringMsg("AssetBundleRequest won't complete. Asset bundle %s was already unloaded.", m_AssetBundleName.c_str());
    }
    else
    {
        AssetBundle::range assetsToLoad = m_AssetName.empty() ? m_AssetBundle->GetAll() : m_AssetBundle->GetPathRange(m_AssetName);
        PreparePreloadAssets(*m_AssetBundle, assetsToLoad, m_AssetType, !includeSubAssets, m_AssetsToLoadDependencies, m_AssetsLoadedDependencies, m_AssetsToLoad);
    }
    GetPreloadManager().AddToQueue(this);
}

AssetBundleLoadAssetOperation::~AssetBundleLoadAssetOperation()
{
    GetAssetBundleManager().RemoveAssetBundleLoadAssetOperation(this);
}

AssetBundleLoadAssetOperation* AssetBundleLoadAssetOperation::LoadAsset(AssetBundle& bundle, const core::string& name, ScriptingSystemTypeObjectPtr type, bool includeSubAssets)
{
    PROFILER_AUTO(gAssetBundle_LoadAssetAsync, &bundle);

    AssetBundleLoadAssetOperation* operation = UNITY_NEW(AssetBundleLoadAssetOperation, kMemFile)(kMemFile, bundle, name, type, includeSubAssets);
    return operation;
}

Object* AssetBundleLoadAssetOperation::GetLoadedAsset()
{
    PROFILER_AUTO(gAssetBundle_asset, Object::IDToPointerThreadSafe(m_AssetBundle.GetInstanceID()));

    dynamic_array<Object*> objects(kMemTempAlloc);
    GetLoadedAssets(objects, true);
    return objects.empty() ? NULL : objects[0];
}

void AssetBundleLoadAssetOperation::GetAllLoadedAssets(dynamic_array<Object*>& objects)
{
    PROFILER_AUTO(gAssetBundle_allAssets, Object::IDToPointerThreadSafe(m_AssetBundle.GetInstanceID()));

    GetLoadedAssets(objects, false);
}

InstanceID AssetBundleLoadAssetOperation::PrepareMainAssetPreloadList(AssetBundle& bundle, dynamic_array<InstanceID>& preloadAssets)
{
    // Check we actually have main asset.
    InstanceID instanceID = bundle.m_MainAsset.asset.GetInstanceID();
    if (instanceID == InstanceID_None && bundle.m_MainAsset.preloadSize == 0)
        return InstanceID_None;

    // Prepare initial preload list.
    AddAssetsToPreload(bundle, bundle.m_MainAsset.preloadIndex, bundle.m_MainAsset.preloadSize, preloadAssets);
    return instanceID;
}

void AssetBundleLoadAssetOperation::PreparePreloadAssets(const AssetBundle& bundle, const AssetBundle::range& assets, const ScriptingSystemTypeObjectPtr& typeToLoad, bool loadFirstOnly,
    dynamic_array<InstanceID>& outAssetsToLoad, dynamic_array<InstanceID>& outAssetsLoaded, dynamic_array<PPtr<Object> >& outAssets)
{
    ScriptingClassPtr requestedTypeClass = scripting_class_from_systemtypeinstance(typeToLoad);

    for (AssetBundle::AssetMap::const_iterator it = assets.first; it != assets.second; ++it)
    {
        InstanceID instanceID = it->second.asset.GetInstanceID();

        bool doesTypeMatch = true; // If we don't enable scripting, we just add the first object and treat it as matched.
        const Unity::Type* classType = bundle.GetAssetType(instanceID);
        if (classType == NULL)
            continue;

        if (classType->GetFactory() == NULL) // in case we have stub-types with unknown classids
            continue;

        bool isScript = (classType == TypeOf<MonoBehaviour>());
        doesTypeMatch = scripting_class_is_subclass_of(Scripting::TypeToScriptingType(classType), requestedTypeClass);

        // If the current object is a script, we have to load it to know its actually type.
        // Please refer to case 780289 for more details.
        if (!doesTypeMatch && !isScript)
            continue;

        outAssets.push_back(it->second.asset);

        // Prepare the preload list. Don't load if it is already loaded.
        if (Object::IDToPointer(instanceID) == NULL)
            AddAssetsToPreload(bundle, it->second.preloadIndex, it->second.preloadSize, outAssetsToLoad);
        else
            AddAssetsToPreload(bundle, it->second.preloadIndex, it->second.preloadSize, outAssetsLoaded);

        // Stop if we only include the first object.
        if (doesTypeMatch && loadFirstOnly)
            break;
    }

    // Remove duplicate IDs.
    if (!bundle.m_ExplicitDataLayout)
    {
        std::sort(outAssetsToLoad.begin(), outAssetsToLoad.end());
        outAssetsToLoad.erase(std::unique(outAssetsToLoad.begin(), outAssetsToLoad.end()), outAssetsToLoad.end());
    }
}

void AssetBundleLoadAssetOperation::CollectFullPreloadDataDependencies(dynamic_array<InstanceID>& assetsToLoadDependencies)
{
    PROFILER_AUTO(gAssetBundle_LoadAssetAsyncCollectDependencies, Object::IDToPointerThreadSafe(m_AssetBundle.GetInstanceID()));

    // Collect full dependencies of the initial preload assets set, including the assets from another bundles this bundle depends on.
    GetAssetBundleManager().CollectPreloadDataDependencies(m_AssetBundle, m_AssetsToLoadDependencies, false);
    GetAssetBundleManager().CollectPreloadDataDependencies(m_AssetBundle, m_AssetsLoadedDependencies, false);

    assetsToLoadDependencies = m_AssetsToLoadDependencies;
}

void AssetBundleLoadAssetOperation::Perform()
{
    // Collect dependencies
    CollectFullPreloadDataDependencies(m_PreloadAssets);
    // Now do actual loading
    LoadOperation::Perform();
}

void AssetBundleLoadAssetOperation::GetLoadedAssets(dynamic_array<Object*>& objects, bool onlyFirst)
{
    objects.clear();

    // The behavior of AssetBundleRequest.asset is to blocks until loading is finished.
    // Load all assets immediately
    if (!IsDone())
    {
        PROFILER_AUTO(gAssetBundle_ForceLoad, Object::IDToPointerThreadSafe(m_AssetBundle.GetInstanceID()));
        GetPreloadManager().WaitForAllAsyncOperationsToComplete();
    }

    ScriptingClassPtr klass = scripting_class_from_systemtypeinstance(m_AssetType);
    for (dynamic_array<PPtr<Object> >::iterator it = m_AssetsToLoad.begin(); it != m_AssetsToLoad.end(); ++it)
    {
        // Object should be already fully loaded at this point
        Object* obj = (*it);
        if (obj == NULL)
            continue;

        // Check the scripting type.
        ScriptingObjectPtr o = Scripting::ScriptingWrapperFor(obj);
        if (o && scripting_class_is_subclass_of(scripting_object_get_class(o), klass))
        {
            objects.push_back(obj);
            if (onlyFirst)
                break;
        }
    }
}
