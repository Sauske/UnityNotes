#include "UnityPrefix.h"
#include "Runtime/AssetBundles/AssetBundleLoadFromCacheAsyncOperation.h"

#if ENABLE_CACHING

#include "Runtime/AssetBundles/AssetBundleUtility.h"
#include "Runtime/Jobs/BackgroundJobQueue.h"
#include "Runtime/Misc/CachingManager.h"

AssetBundleLoadFromCacheAsyncOperation::AssetBundleLoadFromCacheAsyncOperation(MemLabelId label, const core::string& assetBundleName)
    : AssetBundleLoadFromStreamAsyncOperation(label)
{
    SetAssetBundleName(assetBundleName);
    SetAllowThreadedConversion(true);
}

AssetBundleLoadFromCacheAsyncOperation::~AssetBundleLoadFromCacheAsyncOperation()
{
}

bool AssetBundleLoadFromCacheAsyncOperation::LoadCachedArchive()
{
#if ENABLE_CACHING
    const core::string& cachedId = GetCacheId();
    if (cachedId.empty())
        return false;

    core::string cacheFolder;
    std::vector<core::string> fileNames;
    Cache* cache = NULL;
    if (GetCachingManager().IsCached(m_Url, m_cachedName, m_CacheHash, cache, cacheFolder, fileNames))
    {
        // Update timestamp.
        time_t timestamp = GenerateCacheTimeStamp();
        Cache::WriteInfoFileForCachedFile(cacheFolder, fileNames, timestamp);
        cache->UpdateTimestamp(cacheFolder, timestamp);

        InitializeResult result = InitializeAssetBundleStorage(AppendPathName(cacheFolder, kCachedArchiveFilename), 0);
        if (result == AssetBundleLoadFromAsyncOperation::kInitializeSuccess)
        {
            cache->AddLoadedAssetBundle(cacheFolder);
            m_StorageCleanupPath = cacheFolder;
            m_IsStorageCleanupPathInCache = true;
            return true;
        }
    }

    // Invalidate cache if loading the cached file failed.
    DeleteFileOrDirectory(cacheFolder);
    return false;
#endif // ENABLE_CACHING

    return false;
}

void AssetBundleLoadFromCacheAsyncOperation::Execute()
{
    core::string subpath = Cache::URLToCachePath(m_Url, m_cachedName, m_CacheHash);
    SetCacheId(subpath);

    GetBackgroundJobQueue().ScheduleJob(LoadCachedArchiveJob, this);
}

void AssetBundleLoadFromCacheAsyncOperation::ExecuteSynchronously()
{
    core::string subpath = Cache::URLToCachePath(m_Url, m_cachedName, m_CacheHash);
    SetCacheId(subpath);

    LoadCachedArchive();
    IntegrateImmediately();
}

void AssetBundleLoadFromCacheAsyncOperation::LoadCachedArchiveJob(AssetBundleLoadFromCacheAsyncOperation* this_)
{
    if (!this_->IsCancelled())
        this_->LoadCachedArchive();
    this_->IntegrateWithPreloadManager();
}

#endif // ENABLE_CACHING
