#ifndef GAMEOBJECT_H
#define GAMEOBJECT_H

#include "EditorExtension.h"
#include "Runtime/Logging/LogAssert.h"
#include "MessageIdentifier.h"
#include "MessageData.h"
#include "ImmediatePtr.h"
#include "BitField.h"
#include "Runtime/BaseClasses/Type.h"
#include "Runtime/Utilities/LinkedList.h"
#include "Runtime/Containers/ConstantString.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Scripting/BindingsDefs.h"

#if UNITY_EDITOR
#include "Editor/Src/Utility/StaticEditorFlags.h"
#endif

struct GarbageCollectorThreadState;
class GameManager;
class MessageHandler;
class Texture2D;
class AwakeFromLoadQueue;
class Transform;
typedef UNITY_SET (kMemTempAlloc, Object*) TempSelectionSet;

DECLARE_MESSAGE_IDENTIFIER(kLayerChanged);
DECLARE_MESSAGE_IDENTIFIER(kCullSceneChanged);
DECLARE_MESSAGE_IDENTIFIER(kDidAddComponent);
DECLARE_MESSAGE_IDENTIFIER(kDidRemoveComponent);

/// A GameObject is basically a bag of GOComponents.
/// GOComponents are added and removed at runtime.
/// This allows GameObject to be composed of an arbitrary amount of GOComponents.

/// You can query for any GOCOmponents using
/// QueryComponent and GetComponent
/// This will Ask every of the component in the GO if it is derived from the wanted class
/// eg. from inside a Component you can query for a Transform:
/// Transform* t = QueryComponent<Transform>();
/// If there is no Transform inside the GameObject, NULL is returned.
/// The difference between QueryComponent and GetComponent is that
/// QueryComponent returns a ptr, GetComponent returns a reference
/// but asserts if no matching component could be found
/// Also you are not allowed to Query for Component classes
/// that are in the GameObject more than once.


/// Also GameObjects support messaging.
/// MessageIdentifier kTransformChanged ("TransformChanged");
/// MessageIdentifier kTestMessage ("Test", TypeOf<float>());
/// In order to receive a message
/// Register the message notification inside the InitializeClass of the class
/// Renderer::InitializeClass ()
/// {
///     REGISTER_MESSAGE_VOID (Renderer, kTransformChanged, TransformChanged);
///     REGISTER_MESSAGE (Renderer, kTestMessage, TestMessage, float);
/// }
/// bool Renderer::TransformChanged () { ... }
/// bool Renderer::TestMessage (float f) { ... }

/// In order to send a message use:
/// SendMessage (kTransformChanged);
/// SendMessage (kTestMessage, 0.1f);

namespace Unity
{ class Component; }

enum DeactivateOperation
{
    kNormalDeactivate = 0,
    // Deactivate was called because the component will be destroyed
    kWillDestroySingleComponentDeactivate = 1,
    // Deactivate was called because the entire game object will be destroyed
    kWillDestroyGameObjectDeactivate = 2
};

class EXPORT_COREMODULE GameObject : public EditorExtension
{
    REGISTER_CLASS(GameObject);
    DECLARE_OBJECT_SERIALIZE();
public:

    struct ComponentPair
    {
        ComponentPair() {}

        static ComponentPair FromComponent(Unity::Component* component);
        static ComponentPair FromTypeIndexAndComponent(RuntimeTypeIndex typeIndex, Unity::Component* component);

        DECLARE_SERIALIZE(ComponentPair);

        inline RuntimeTypeIndex const GetTypeIndex() const { return typeIndex; }
        inline ImmediatePtr<Unity::Component> const& GetComponentPtr() const { return component; }

        void SetComponentPtr(Unity::Component* const ptr);

    private:
        RuntimeTypeIndex typeIndex;
        ImmediatePtr<Unity::Component> component;
    };

    typedef dynamic_array<ComponentPair>    Container;

    GameObject(MemLabelId label, ObjectCreationMode mode);
    // ~GameObject (); declared-by-macro

    /// An GameObject can either be active or inactive (Template GameObjects are always inactive)
    /// If an GameObject is active/inactive all its components have the same state as well.
    /// (Components that are not added to a gameobject are always inactive)
    /// Querying and messaging still works for inactive GameObjects and Components
    void Activate();
    void ActivateInternal() {m_IsActive = true; }

    /// Deactiates the game object and thus all it's components.
    void Deactivate(DeactivateOperation operation = kNormalDeactivate);

    bool IsActiveIgnoreImplicitPrefab();
    bool IsActive() const;
    bool IsSelfActive() const { return m_IsActive; }
    void SetSelfActive(bool state);

    /// Set the GameObject Layer.
    /// This is used for collisions and messaging
    void SetLayer(int layerIndex);
    int GetLayer() const    { return m_Layer; }
    UInt32 GetLayerMask() const { return 1 << m_Layer; }

    void SetCullSceneMask(UInt64 mask);
    UInt64 GetCullSceneMask() const;

    /// Set the Tag of the gameobject
    UInt32 GetTag() const { return m_Tag; }
    void SetTag(UInt32 tag);

    // Adds a new Component to the GameObject.
    // Using the PersistentObject interface so that Components,
    // which are not loaded at the moment can be added.
    // Use GameObjectUtility instead, you must invoke specific callbacks etc.
    void AddComponentInternal(Unity::Component* component);

    void AddFirstTransformComponentInternal(::Transform* newTransform);
    void ReplaceTransformComponentInternal(::Transform* newTransform);

    // Removes a Component from the GameObject.
    void RemoveComponentAtIndex(int index);

    int GetComponentCount() const                      { return static_cast<int>(m_Component.size()); }
    Unity::Component& GetComponentAtIndex(int i) const;
    Unity::Component* GetComponentPtrAtIndex(int i) const;

    // ------------------------------------------------------------------------

    template<class T> T& GetComponent() const;
    template<class T> T* QueryComponent() const;

    Unity::Component* QueryComponentByType(const Unity::Type* type) const;
    Unity::Component* QueryComponentByExactType(const Unity::Type* type) const;

    const Unity::Type* GetComponentTypeAtIndex(int index) const;
    template<class T> T& GetComponentAtIndex(int index) const;
    template<class T> T* QueryComponentAtIndex(int index) const;

    // ------------------------------------------------------------------------

    /// Swap two components in the vector.
    void SwapComponents(int index1, int index2);

    /// Get the index of a component.
    int GetComponentIndex(Unity::Component *component);

    /// Send a message identified by messageID to all components if they can handle it
    void SendMessageAny(const MessageIdentifier& messageID, MessageData& messageData);

    /// Send a message identified by messageID to all components if they can handle it
    template<class T>
    void SendMessage(const MessageIdentifier& messageID, T messageData);
    void SendMessage(const MessageIdentifier& messageID);

    /// Will this message be handled by any component in the gameobject?
    bool WillHandleMessage(const MessageIdentifier& messageID);

    virtual char const* GetName() const { return m_Name.c_str(); }
    virtual void SetName(char const* name);

    // Deprecated since Unity 4.0
    void SetActiveRecursivelyDeprecated(bool state);
    bool GetIsStaticDeprecated();
    void SetIsStaticDeprecated(bool s);

    #if UNITY_EDITOR
    bool AreStaticEditorFlagsSet(StaticEditorFlags flags) const;
    StaticEditorFlags GetStaticEditorFlags() const;
    void SetStaticEditorFlags(StaticEditorFlags flags);
    #endif

    //@TODO: When we rewrite static batching in C++ fix this up
    bool IsStaticBatchable() const;

    // Callback functions
    typedef void DestroyGOCallbackFunction (GameObject* go);
    static void RegisterDestroyedCallback(DestroyGOCallbackFunction* callback);
    static void InvokeDestroyedCallback(GameObject* go);

    typedef void SetGONameFunction (GameObject* go);
    static void RegisterSetGONameCallback(SetGONameFunction* callback);

    virtual void Reset();

    static void InitializeClass();
    static void CleanupClass();

    // Internally used during object destruction to prevent double deletion etc.
    bool IsDestroying() const { return (m_ActivationState & kDestroying) != 0; }
    bool IsActivating() const { return (m_ActivationState & kActivatingOrDeactivating) != 0; }
    bool IsActivatingChildren() const { return (m_ActivationState & (kActivatingChildren | kDeactivatingChildren)) != 0; }

    void WillDestroyGameObject();


    inline MessageIdentifier::OptimizedMessageMask GetSupportedMessages();
    bool SupportsMessage(const MessageIdentifier& messageIdentifier) const { return (m_SupportedMessages & messageIdentifier.GetOptimizedMask()) != 0; }
    void SetSupportedMessagesDirty();
    void InvalidateSupportedMessages();

    virtual void AwakeFromLoad(AwakeFromLoadMode mode);

    virtual void SetHideFlags(HideFlags flags);

    virtual void CheckConsistency();

    static void AddComponentInternal(GameObject& gameObject, Unity::Component& clone);
    static void RemoveComponentFromGameObjectInternal(Unity::Component& clone);

    #if UNITY_EDITOR
    enum EditorVisibility
    {
        kNotVisible = 0,
        kSelfVisible = 1,
        kVisibleAsChild = 2,
    };
    EditorVisibility IsMarkedVisible() const { return m_MarkedVisible; }
    void SetMarkedVisible(EditorVisibility marked) { m_MarkedVisible = marked; }
    void SetIcon(PPtr<Texture2D> icon);

    // Get the custom icon for this gameobject. Does not scan components for their icons.
    PPtr<Texture2D> GetIcon() const;

    UInt32 GetNavMeshLayer() const { return m_NavMeshLayer; }
    void SetNavMeshLayer(UInt32 layer) { m_NavMeshLayer = layer; SetDirty(); }
    #endif

    // Internal functions that you should never call unless you really understand all side effects.
    void SetActiveBitInternal(bool value) { m_IsActive = value; }

    void CopyProperties(GameObject& dest);

    void SetComponentAtIndexInternal(PPtr<Unity::Component> component, int index);

    void UpdateActiveGONode();

    void TransformParentHasChanged();

    const Container& GetComponentContainerInternal() const { return m_Component; }
    Container& GetComponentContainerInternal() { return m_Component; }

    void ActivateAwakeRecursively(DeactivateOperation deactivateOperation = kNormalDeactivate);
    void ActivateAwakeRecursivelyInternal(DeactivateOperation deactivateOperation, AwakeFromLoadQueue &queue);

    void MarkGameObjectAndComponentDependencies(GarbageCollectorThreadState& gc) const;

private:
    void GetSupportedMessagesRecalculate();

    void MarkActiveRecursively(bool state);

    template<class TransferFunction>
    void TransferComponents(TransferFunction& transfer);

    /// Make sure there is only a single Transform or RectTransform component.  If multiple transforms
    /// (of either type) are found, all are merged into the first one (whatever the type).  If no transform
    /// is found, a Tranform component is added.  Also ensure the transform is the first component on
    /// the object.
    /// Returns true if the object was okay and had only a single transform or false if repairs had to be made.
    bool EnsureUniqueTransform();

    void FinalizeAddComponentInternal(Unity::Component* component);

    Container   m_Component;

    UInt64          m_CullSceneMask;
    UInt32          m_Layer;
    UInt16          m_Tag;
    bool            m_IsActive;
    mutable SInt8   m_IsActiveCached;

    enum ActivationState
    {
        kNotActivating          = 0,
        kActivatingChildren     = 1 << 0,
        kActivatingComponents   = 1 << 1,
        kDeactivatingChildren   = 1 << 2,
        kDeactivatingComponents = 1 << 3,
        kDestroying             = 1 << 4,
        kActivatingOrDeactivating = kActivatingChildren | kActivatingComponents | kDeactivatingChildren | kDeactivatingComponents,
    };
    ActivationState m_ActivationState;

    MessageIdentifier::OptimizedMessageMask m_SupportedMessages;

    ConstantString  m_Name;

    #if UNITY_EDITOR
    UInt32          m_StaticEditorFlags;
    core::string    m_TagString;
    EditorVisibility m_MarkedVisible;
    PPtr<Texture2D> m_Icon;
    UInt32          m_NavMeshLayer;
    bool            m_IsOldVersion;
    #endif

    ListNode<GameObject> m_ActiveGONode;

    static DestroyGOCallbackFunction* s_GameObjectDestroyedCallback;
    static SetGONameFunction*         s_SetGONameCallback;

    friend class Unity::Component;
};

BIND_MANAGED_TYPE_NAME(GameObject, UnityEngine_GameObject);

namespace Unity
{
    class EXPORT_COREMODULE Component : public EditorExtension
    {
        REGISTER_CLASS(Component);
        DECLARE_OBJECT_SERIALIZE();
    private:
        ImmediatePtr<GameObject>    m_GameObject;

    public:


        // LLVM mislinks some constructors. This LLVM bug affects Component ctor on webgl if ENABLE_UNIT_TESTS=1
        // As a consequence Component::Component will be missing from the Emscripten-generated js
        // To workaround that, Component ctor is implemented here.
        // https://github.com/kripken/emscripten/issues/4234
        Component(MemLabelId label, ObjectCreationMode mode)
            : Super(label, mode)
        {
            m_GameObject = NULL;
        }

        // ~Component (); declared-by-macro

        // Returns a reference to the GameObject holding this component
        GameObject& GetGameObject()                    { return *m_GameObject; }
        const GameObject& GetGameObject() const        { return *m_GameObject; }
        GameObject* GetGameObjectPtr()     { return m_GameObject; }
        GameObject* GetGameObjectPtr() const   { return m_GameObject; }

        template<class T> T& GetComponent() const { return m_GameObject->GetComponent<T>(); }
        template<class T> T* QueryComponent() const { return m_GameObject->QueryComponent<T>(); }

        /// Send a message identified by messageName to every components of the gameobject
        /// that can handle it
        void SendMessageAny(const MessageIdentifier& messageID, MessageData& messageData);

        template<class T>
        void SendMessage(const MessageIdentifier& messageID, T messageData);
        void SendMessage(const MessageIdentifier& messageID);

        /// Is this component active?
        /// A component is always inactive if its not attached to a gameobject
        /// A component is always inactive if its gameobject is inactive
        /// If its a prefab, the gameobject and its components are always set to be inactive
        bool IsActive() const;

        virtual char const* GetName() const;
        virtual void SetName(char const* name);

        virtual MessageIdentifier::OptimizedMessageMask CalculateSupportedMessages() { return 0; }
        virtual void SupportedMessagesDidChange(MessageIdentifier::OptimizedMessageMask /*newMask*/) {}

        virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode);

        // Invoke any callbacks prior to component destruction.
        virtual void WillDestroyComponent() {}

        /// Deactivate will be called just before the Component is going to be removed from a GameObject
        /// It can still communicate with other components at this point.
        /// Deactivate will only be called when the component is remove from the GameObject,
        /// not if the object is persistet to disk and removed from memory
        /// Deactivate will only be called if the GameObject the Component is being removed from is active
        /// YOU CAN NOT RELY ON IsActive returning false inside Deactivate
        virtual void Deactivate(DeactivateOperation /*operation*/) {}

        virtual void CheckConsistency();

    #if UNITY_EDITOR
        // Some components always go together, e.g. when removing one you have
        // to remove other. Example, ParticleSystem and ParticleSystemRenderer.
        // Override and return Type of that "dependent" component.

        virtual const Unity::Type* GetCoupledComponentType() const { return NULL; }
    #endif

        // Indicates whether this component supports enabling. If false, GetEnabled always returns true and
        // SetEnabled is considered an error.
        virtual bool HasEnabled() const { return false; }
        virtual bool GetEnabled() const { return true; }
        virtual void SetEnabled(bool enable);

    public:

        InstanceID GetGameObjectInstanceID() const { return m_GameObject.GetInstanceID(); }

        /// SetGameObject is called whenever the GameObject of a component changes.
        void SetGameObjectInternal(GameObject* go) { m_GameObject = go; }

        void MarkGameObjectAndComponentDependencies(GarbageCollectorThreadState& gc) const;

        friend class ::GameObject;
    };
} // End namespace Unity

BIND_MANAGED_TYPE_NAME(Unity::Component, UnityEngine_Component);

typedef List<ListNode<GameObject> > GameObjectList;

// A fast lookup for all tagged and active game objects
class GameObjectManager
{
public:
    static void StaticInitialize();
    static void StaticDestroy();
    // Nodes that are tagged and active
    GameObjectList m_TaggedNodes;
    // Nodes that are just active
    // (If you want to get all active nodes you need to go through tagged and active nodes)
    GameObjectList m_ActiveNodes;

    static GameObjectManager* s_Instance;
};
GameObjectManager& GetGameObjectManager();


template<class T> inline
T& GameObject::GetComponent() const
{
    T* component = QueryComponent<T>();
    DebugAssertMsg(component != NULL, "GetComponent returned NULL. You cannot use GetComponent unless the component is guaranteed to be part of the GO");
    return *component;
}

template<class T> inline
T* GameObject::QueryComponent() const
{
    return static_cast<T*>(QueryComponentByType(TypeOf<T>()));
}

template<class T> inline
T* GameObject::QueryComponentAtIndex(int index) const
{
    Unity::Component* comp = m_Component[index].GetComponentPtr();
    DebugAssert(comp != NULL);
    return dynamic_pptr_cast<T*>(comp);
}

template<class T> inline
T& GameObject::GetComponentAtIndex(int index) const
{
    Unity::Component* comp = QueryComponentAtIndex<T>(index);
    DebugAssert(comp != NULL);
    return comp;
}

inline Unity::Component& GameObject::GetComponentAtIndex(int i) const
{
    return *m_Component[i].GetComponentPtr();
}

inline const Unity::Type* GameObject::GetComponentTypeAtIndex(int i) const
{
    return Unity::Type::GetTypeByRuntimeTypeIndex(m_Component[i].GetTypeIndex());
}

inline bool Unity::Component::IsActive() const
{
    GameObject* go = m_GameObject;
    return go != NULL && go->IsActive();
}

inline GameObject::ComponentPair GameObject::ComponentPair::FromComponent(Unity::Component* component)
{
    ComponentPair ret;
    ret.typeIndex = component->GetType()->GetRuntimeTypeIndex();
    ret.component = component;
    return ret;
}

inline GameObject::ComponentPair GameObject::ComponentPair::FromTypeIndexAndComponent(RuntimeTypeIndex typeIndex, Unity::Component* component)
{
    ComponentPair ret;
    ret.typeIndex = typeIndex;
    ret.component = component;
    return ret;
}

inline MessageIdentifier::OptimizedMessageMask GameObject::GetSupportedMessages()
{
    return m_SupportedMessages;
}

template<class T> inline
void GameObject::SendMessage(const MessageIdentifier& messageID,
    T messageData)
{
    MessageData data(messageData);
    SendMessageAny(messageID, data);
}

inline void GameObject::SendMessage(const MessageIdentifier& messageID)
{
    MessageData data;
    SendMessageAny(messageID, data);
}

template<class T> inline
void Unity::Component::SendMessage(const MessageIdentifier& messageID,
    T messageData)
{
    MessageData data(messageData);
    SendMessageAny(messageID, data);
}

inline void Unity::Component::SendMessage(const MessageIdentifier& messageID)
{
    MessageData data;
    SendMessageAny(messageID, data);
}

void SendMessageDirect(Object& target, const MessageIdentifier& messageIdentifier, MessageData& messageData);

#endif
