#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "Modules/Audio/Public/AudioMixer.h"

#include "BaseObject.h"

#include "Runtime/Threads/Thread.h"
#include "Runtime/Testing/Testing.h"
#include "Runtime/Testing/ParametricTest.h"
#include "Runtime/Allocator/BaseAllocator.h"
#include "Runtime/Allocator/MemoryManager.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Serialize/TransferUtility.h"
#include "Runtime/BaseClasses/WeakTypeOf.h"
#include "Runtime/BaseClasses/GameObject.h"
#include "Runtime/BaseClasses/GameManager.h"
#include "Runtime/Mono/MonoManager.h"
#include "Runtime/Mono/MonoScript.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Animation/AnimationClip.h"
#include "Runtime/Animation/AnimatorOverrideController.h"
#include "Runtime/Graphics/Substance/ProceduralMaterial.h"
#include "Runtime/Graphics/Substance/ProceduralTexture.h"
#include "Runtime/Graphics/Texture3D.h"
#include "Runtime/Camera/RenderLayers/GUITexture.h"
#include "Runtime/TextRendering/Public/Font.h"
#if UNITY_EDITOR
#include "Editor/Src/AssetPipeline/ScriptedImporter.h"
#include "Editor/Src/EditorUserSettings.h"
#endif
#if ENABLE_HOLOLENS_MODULE
#include "Runtime/VR/HoloLens/WorldAnchor/WorldAnchor.h"
#endif
#if PLATFORM_METRO
#include "Modules/Terrain/Public/TerrainData.h"
#endif
#if ENABLE_MOVIES
#include "Runtime/Video/MovieTexture.h"
#endif
#if ENABLE_RAKNET
#include "Runtime/Network/NetworkView.h"
#endif


class ScriptedObjectTestClass;


INTEGRATION_TEST_SUITE(BaseObject)
{
    using namespace Testing;

    void AllNonAbstractTypes(TestCaseEmitter<const Unity::Type*>& testCase)
    {
        dynamic_array<const Unity::Type*> classes(kMemTempAlloc);
        TypeOf<Object>()->FindAllDerivedClasses(classes, Unity::Type::kOnlyNonAbstract);

        for (int i = 0; i < classes.size(); ++i)
        {
            const Unity::Type* type = classes[i];

            // MonoManager requires the Mono library to be loaded.
            if (type == TypeOf<MonoManager>())
                continue;

            // Cleaning up AudioMixer requires AudioManager to be installed.
            if (type->IsDerivedFrom(TypeOf<AudioMixer>()))
                continue;

            testCase.WithValues(type);
        }
    }

    // Every object should destruct properly even when not having its AwakeFromLoad()
    // method called.
    PARAMETRIC_TEST(ClassAllowsDestructionWithoutAwakening, (const Unity::Type * type), AllNonAbstractTypes)
    {
        Object* instance = Object::Produce(type);
        instance->Reset();
        DestroySingleObject(instance);
    }

    class StompingAllocator : public BaseAllocator
    {
    private:
        BaseAllocator* m_UnderlyingAllocator;
    public:
        StompingAllocator(BaseAllocator* underlying) : BaseAllocator("Stomping allocator"), m_UnderlyingAllocator(underlying) {}

        UInt8 pattern;

        virtual void*  Allocate(size_t size, int align)
        {
            void* result = m_UnderlyingAllocator->Allocate(size, align);
            memset(result, pattern, size);
            return result;
        }

        virtual void*  Reallocate(void* p, size_t size, int align)
        {
            // Not supported
            return NULL;
        }

        virtual void   Deallocate(void* p) { m_UnderlyingAllocator->Deallocate(p); }
        virtual bool   Contains(const void* p) const { return m_UnderlyingAllocator->Contains(p); }
        virtual size_t GetPtrSize(const void* ptr) const { return m_UnderlyingAllocator->GetPtrSize(ptr); }

            #if USE_MEMORY_DEBUGGING || ENABLE_MEM_PROFILER
        virtual ProfilerAllocationHeader* GetProfilerHeader(const void* ptr) const { return m_UnderlyingAllocator->GetProfilerHeader(ptr); }
        virtual size_t GetRequestedPtrSize(const void* ptr) const { return m_UnderlyingAllocator->GetRequestedPtrSize(ptr); }
            #endif // USE_MEMORY_DEBUGGING || ENABLE_MEM_PROFILER

        virtual bool CanStompMemoryOnAlloc() const { return false; }
    };


    PARAMETRIC_TEST(Class_AfterCreateAndReset_HasConsistentSerializedData, (const Unity::Type * type), AllNonAbstractTypes)
    {
        StompingAllocator stomper(GetMemoryManager().GetAllocator(kMemDefault));
        MemLabelId stomperId = GetMemoryManager().AddCustomAllocator(&stomper);

        dynamic_array<UInt8> obj1(kMemTempAlloc);
        dynamic_array<UInt8> obj2(kMemTempAlloc);

        // Create and reset the object once, initially filling the memory with 0x00,
        // and serialize it to a vector.

        stomper.pattern = 0;

        Object* obj = Object::Produce(type, InstanceID_None, stomperId, kCreateObjectDefault);
        obj->Reset();
        obj1.clear();
        WriteObjectToVector(*obj, obj1);
        DestroySingleObject(obj);

        // Create and reset the object again, now filling memory with 0xff, and serialize.
        // Any value the object does not set in constructor/reset will thus be different.

        stomper.pattern = 0xff;

        obj = Object::Produce(type, InstanceID_None, stomperId, kCreateObjectDefault);
        obj->Reset();
        obj2.clear();
        WriteObjectToVector(*obj, obj2);
        DestroySingleObject(obj);

        // Compare the serialized representations
        CHECK_EQUAL(obj1.size(), obj2.size());
        CHECK_MSG(obj1 == obj2, Format("Expected two created+reset instances to match when serialized, but they differed at position %u (of %u). This means you forgot to initialize a field that is serialized.",
                std::distance(obj1.begin(), std::mismatch(obj1.begin(), obj1.end(), obj2.begin()).first),
                obj1.size()).c_str());

        GetMemoryManager().RemoveCustomAllocator(stomperId);
    }

#if SUPPORT_THREADS

    const static InstanceID kBaseVeryHighInstanceID = InstanceID_Make((std::numeric_limits<SInt32>::max() - 1) - 5000 * 4);

    struct CreateObjectsOnNonMainThreadFixture
    {
        const Unity::Type* objectType;
        Object* createdObject;

        static void* CreateObjectThread(void* userData)
        {
            CreateObjectsOnNonMainThreadFixture* fixture = (CreateObjectsOnNonMainThreadFixture*)userData;

            Object* obj = Object::Produce(fixture->objectType, kBaseVeryHighInstanceID, kMemBaseObject, kCreateObjectFromNonMainThread);
            obj->Reset();
            obj->AwakeFromLoadThreaded();

            fixture->createdObject = obj;

            return NULL;
        }

        ~CreateObjectsOnNonMainThreadFixture()
        {
            DestroySingleObject(createdObject);
        }
    };

    PARAMETRIC_TEST_SOURCE(AllTypesThatCanBeAwakedInTests, (const Unity::Type*))
    {
        dynamic_array<const Unity::Type*> classes(kMemTempAlloc);
        TypeOf<Object>()->FindAllDerivedClasses(classes, Unity::Type::kOnlyNonAbstract);

        for (int i = 0; i < classes.size(); ++i)
        {
            const Unity::Type* type = classes[i];

            // Ignore game manager derived
            if (type->IsDerivedFrom(TypeOf<GameManager>()))
                continue;

            // AudioMixer requires AudioManager to be installed.
            if (type->IsDerivedFrom(TypeOf<AudioMixer>()))
                continue;

            // MonoManager and MonoScript require the Mono library to be loaded.
            if (type == TypeOf<MonoManager>() || type == TypeOf<MonoScript>())
                continue;

            // Substance requires an active build target
            if (type == TypeOf<ProceduralTexture>() || type == TypeOf<ProceduralMaterial>())
                continue;

            // AnimationClip and AnimatorOverrideController have scripting-side awake code
            if (type->IsDerivedFrom(TypeOf<AnimationClip>()) || type == TypeOf<AnimatorOverrideController>())
                continue;

            // Can't awake Texture3D without putting actual content into them
            if (type == TypeOf<Texture3D>())
                continue;

#if ENABLE_MOVIES
            // Can't awake MovieTexture without putting actual content into them
            if (type == TypeOf<MovieTexture>())
                continue;
#endif

            // Awaking Font requires the default font be available from built-in resources
            if (type == TypeOf<TextRendering::Font>())
                continue;

#if ENABLE_RAKNET
            // NetworkView requires that the NetworkManager is ready
            if (type == TypeOf<NetworkView>())
                continue;
#endif

            // GUITexture creates extra materials that fail the leak test
            if (type == TypeOf<GUITexture>())
                continue;

#if PLATFORM_METRO
            // Windows Store apps use debug PhysX library
            // Gu::HeightField::loadFromDesc: desc.isValid() failed!
            // (Filename: C:/buildslave/physx/build/Source/GeomUtils/src/hf/GuHeightField.cpp Line: 353)
            if (type == TypeOf<TerrainData>())
                continue;
#endif

#if ENABLE_HOLOLENS_MODULE
            // WorldAnchor::LockAtCurrentPosition_Internal() is accessing GameObject which is not created in this case
            if (type == TypeOf<WorldAnchor>())
                continue;
#endif

            PARAMETRIC_TEST_CASE(type);
        }
    }

    PARAMETRIC_TEST_FIXTURE(CreateObjectsOnNonMainThreadFixture, Class_CanBeCreatedOnNonMainThread_ThenAwakedOnMainThread, (const Unity::Type * type), AllTypesThatCanBeAwakedInTests)
    {
        objectType = type;

        Thread creatorThread;
        creatorThread.Run(&CreateObjectsOnNonMainThreadFixture::CreateObjectThread, (CreateObjectsOnNonMainThreadFixture*)this);
        creatorThread.WaitForExit();

        Object::RegisterInstanceID(createdObject);
        createdObject->AwakeFromLoad(kDidLoadThreaded);
    }

#endif

    PARAMETRIC_TEST_SOURCE(AllTypesThatCanBeSerializedAfterReset, (const Unity::Type*))
    {
        dynamic_array<const Unity::Type*> classes(kMemTempAlloc);
        TypeOf<Object>()->FindAllDerivedClasses(classes, Unity::Type::kOnlyNonAbstract);

        for (int i = 0; i < classes.size(); ++i)
        {
            const Unity::Type* type = classes[i];

            // Ignore game manager derived
            if (type->IsDerivedFrom(TypeOf<GameManager>()))
                continue;

            // AudioMixer requires AudioManager to be installed.
            if (type->IsDerivedFrom(TypeOf<AudioMixer>()))
                continue;

#if !UNITY_EDITOR
            // Cannot serialize MonoBehaviour with no script set outside of the editor
            if (type == TypeOf<MonoBehaviour>())
                continue;
#endif

            PARAMETRIC_TEST_CASE(type);
        }
    }

    PARAMETRIC_TEST(Class_AfterCreateAndReset_RoundTripsWithConsistentData, (const Unity::Type * type), AllTypesThatCanBeSerializedAfterReset)
    {
        dynamic_array<UInt8> before(kMemTempAlloc);
        dynamic_array<UInt8> after(kMemTempAlloc);

        Object* obj = Object::Produce(type, InstanceID_None, kMemBaseObject, kCreateObjectDefault);
        obj->Reset();

        // Serialize it once
        WriteObjectToVector(*obj, before);

        // Read it back
        ReadObjectFromVector(*obj, before);

        // Serialize it again for comparison
        WriteObjectToVector(*obj, after);

        CHECK_EQUAL(before.size(), after.size());
        CHECK(before == after);

        DestroySingleObject(obj);
    }

#if SUPPORT_TEXT_SERIALIZATION
    PARAMETRIC_TEST(Class_AfterCreateAndReset_RoundTripsWithConsistentYAMLData, (const Unity::Type * type), AllTypesThatCanBeSerializedAfterReset)
    {
#if UNITY_EDITOR
        // These 3 types don't handle the roundtrip. bug reported:
        // https://fogbugz.unity3d.com/f/cases/927092/

        if (type->IsDerivedFrom(TypeOf<ScriptedImporter>()) ||
            type->IsDerivedFrom(TypeOf<EditorUserSettings>()))
            return;
#endif
        // TODO(svr): ScriptedObjectTestClass is defined in "Runtime/Scripting/ScriptedObjectTests.cpp" which can't be included
        // in this file since it's a .cpp file. So we're forced to use WeakTypeOf here until this is resolved
        if (type->IsDerivedFrom(WeakTypeOf<ScriptedObjectTestClass>()))
            return;

        core::string before(kMemTempAlloc);
        core::string after(kMemTempAlloc);

        Object* obj = Object::Produce(type, InstanceID_None, kMemBaseObject, kCreateObjectDefault);
        obj->Reset();

        // Serialize it once
        WriteObjectToString(*obj, before);

        // Read it back
        ReadObjectFromString(*obj, before);

        // Serialize it again for comparison
        WriteObjectToString(*obj, after);

        CHECK_EQUAL(before.size(), after.size());
        CHECK(before == after);

        DestroySingleObject(obj);
    }
#endif

    struct CreateGameObjectAndTransformFixture
    {
        CreateGameObjectAndTransformFixture()
        {
            gameObject = Object::Produce(TypeOf<GameObject>());
            gameObject->Reset();
            transform = Object::Produce(TypeOf<Transform>());
            transform->Reset();
        }

        ~CreateGameObjectAndTransformFixture()
        {
            DestroySingleObject(transform);
            DestroySingleObject(gameObject);
        }

        static bool ContainsInstance(const dynamic_array<InstanceID>& instancesToSearch, const InstanceID& instanceToFind)
        {
            return std::find(instancesToSearch.begin(), instancesToSearch.end(), instanceToFind) != instancesToSearch.end();
        }

        PPtr<Object> transform;
        PPtr<Object> gameObject;
    };

    TEST_FIXTURE(CreateGameObjectAndTransformFixture, FindInstanceIDsOfTypes_va_arg_Type_ptr_FindsAllInstances)
    {
        dynamic_array<InstanceID> foundInstances;
        Object::FindInstanceIDsOfTypes(foundInstances,
            TypeOf<Transform>(),
            TypeOf<GameObject>(),
            NULL
            );

        CHECK(ContainsInstance(foundInstances, transform->GetInstanceID()));
        CHECK(ContainsInstance(foundInstances, gameObject->GetInstanceID()));
    }
}

namespace ObjectProduceTestTypes
{
    class Derived : public Object
    {
    public:
        REGISTER_CLASS(Derived);
        DECLARE_OBJECT_SERIALIZE();
        Derived(MemLabelId label, ObjectCreationMode mode)
            : Super(label, mode) {}
    };
    void Derived::ThreadedCleanup() { Super::ThreadedCleanup(); }
    template<class TransferFunction> void Derived::Transfer(TransferFunction& transfer) {}

    class SubDerived : public Derived
    {
    public:
        REGISTER_CLASS(SubDerived);
        DECLARE_OBJECT_SERIALIZE();
        SubDerived(MemLabelId label, ObjectCreationMode mode)
            : Super(label, mode) {}
    };
    void SubDerived::ThreadedCleanup() { Super::ThreadedCleanup(); }
    template<class TransferFunction> void SubDerived::Transfer(TransferFunction& transfer) {}

    class SiblingDerived : public Object
    {
    public:
        REGISTER_CLASS(SiblingDerived);
        DECLARE_OBJECT_SERIALIZE();
        SiblingDerived(MemLabelId label, ObjectCreationMode mode)
            : Super(label, mode) {}
    };
    void SiblingDerived::ThreadedCleanup() { Super::ThreadedCleanup(); }
    template<class TransferFunction> void SiblingDerived::Transfer(TransferFunction& transfer) {}
}

IMPLEMENT_REGISTER_CLASS(ObjectProduceTestTypes, Derived, 0x410FD41F);
IMPLEMENT_OBJECT_SERIALIZE(ObjectProduceTestTypes::Derived);
IMPLEMENT_REGISTER_CLASS(ObjectProduceTestTypes, SubDerived, 0x15E5E8FF);
IMPLEMENT_OBJECT_SERIALIZE(ObjectProduceTestTypes::SubDerived);
IMPLEMENT_REGISTER_CLASS(ObjectProduceTestTypes, SiblingDerived, 0x13F4A461);
IMPLEMENT_OBJECT_SERIALIZE(ObjectProduceTestTypes::SiblingDerived);

UNIT_TEST_SUITE(BaseObjectProduce)
{
    TEST(NullTypeReturnsNull)
    {
        using namespace ObjectProduceTestTypes;

        const Unity::Type* nullType = NULL;
        Derived* nullRaw = Object::Produce<Derived>(nullType);
        Derived* nullMacro = Derived::Produce(nullType);

        CHECK_NULL(nullRaw);
        CHECK_NULL(nullMacro);
    }

    TEST(ValidTypeReturnsValidObject)
    {
        using namespace ObjectProduceTestTypes;

        const Unity::Type* derivedType = TypeOf<Derived>();
        Derived* derivedRaw = Object::Produce<Derived>(derivedType);
        Derived* derivedMacro = Derived::Produce(); // equivalent to raw version

        CHECK_NOT_NULL(derivedRaw);
        CHECK_NOT_NULL(derivedMacro);

        CHECK_EQUAL(derivedType, derivedRaw->GetType());
        CHECK_EQUAL(derivedType, derivedMacro->GetType());

        derivedRaw->Reset();
        DestroySingleObject(derivedRaw);
        derivedMacro->Reset();
        DestroySingleObject(derivedMacro);
    }

    TEST(ValidDerivedTypeReturnsValidObject)
    {
        using namespace ObjectProduceTestTypes;

        const Unity::Type* subDerivedType = TypeOf<SubDerived>();
        Derived* subDerivedRaw = Object::Produce<Derived>(subDerivedType);
        Derived* subDerivedPartial = Derived::Produce(subDerivedType);
        Derived* subDerivedDirect = SubDerived::Produce();

        CHECK_NOT_NULL(subDerivedRaw);
        CHECK_NOT_NULL(subDerivedPartial);
        CHECK_NOT_NULL(subDerivedDirect);

        CHECK_EQUAL(subDerivedType, subDerivedRaw->GetType());
        CHECK_EQUAL(subDerivedType, subDerivedPartial->GetType());
        CHECK_EQUAL(subDerivedType, subDerivedDirect->GetType());

        subDerivedRaw->Reset();
        DestroySingleObject(subDerivedRaw);
        subDerivedPartial->Reset();
        DestroySingleObject(subDerivedPartial);
        subDerivedDirect->Reset();
        DestroySingleObject(subDerivedDirect);
    }

    TEST(IncompatibleTypesAssertsAndReturnsNull)
    {
        using namespace ObjectProduceTestTypes;

        #if ENABLE_ASSERTIONS
        EXPECT(Assert, "Invalid conversion of runtime type SubDerived to static type SiblingDerived");
        #endif
        SiblingDerived* invalidRaw = Object::Produce<SiblingDerived>(TypeOf<SubDerived>());

        #if ENABLE_ASSERTIONS
        EXPECT(Assert, "Invalid conversion of runtime type SiblingDerived to static type SubDerived");
        #endif
        SubDerived* invalidMacro = SubDerived::Produce(TypeOf<SiblingDerived>());

        CHECK_NULL(invalidRaw);
        CHECK_NULL(invalidMacro);
    }
}

#endif // ENABLE_UNIT_TESTS
