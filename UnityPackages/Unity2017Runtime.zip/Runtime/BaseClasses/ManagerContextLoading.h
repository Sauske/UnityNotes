#ifndef _MANAGERCONTEXT_LOADING_H_
#define _MANAGERCONTEXT_LOADING_H_

#include "Runtime/Utilities/dynamic_array.h"

typedef dynamic_array<InstanceID> InstanceIDArray;
class AwakeFromLoadQueue;
class Object;

typedef UInt32 GlobalManagerMaskType;
const GlobalManagerMaskType kAllGlobalManagersMask = ~(GlobalManagerMaskType)0;

void CollectLevelGameManagers(InstanceIDArray& outputObjects, bool stripManagersNotNeededForBuild = false);
void DestroyLevelManagers();
core::string PlayerLoadSettingsAndInput(const core::string& dataFile);
core::string PlayerLoadGlobalManagers(const char* globalManagerPath, const char* globalManagerAssetPath, GlobalManagerMaskType loadManagerMask = kAllGlobalManagersMask);

// Used by editor to ensure consistency and reloading of all global managers...
void ValidateGlobalGameManagers();
void AssignGlobalGameManager(Object* obj);
void CreateMissingGlobalGameManagers();

#endif
