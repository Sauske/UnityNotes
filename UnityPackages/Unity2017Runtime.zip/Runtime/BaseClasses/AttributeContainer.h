#pragma once

#include "Type.h"

namespace Unity
{
    // Generic Iterator for AllAttributes
    template<typename TAttribute, class Enable = void>
    class AllAttributesIterator
    {
    public:
        typedef AllAttributesIterator                               self_type;
        typedef std::pair<const Unity::Type*, const TAttribute*>    value_type;
        typedef ptrdiff_t                                           difference_type;
        typedef const value_type&                                   reference;
        typedef const value_type*                                   pointer;
        typedef std::forward_iterator_tag                           iterator_category;

        // Default iterator == end() iterator
        AllAttributesIterator() : m_Current(static_cast<const Unity::Type*>(NULL), static_cast<const TAttribute*>(NULL)) {}

        self_type& operator++()
        {
            RuntimeTypeIndex currentRuntimeTypeIndex = m_Current.first == NULL ? -1 : m_Current.first->GetRuntimeTypeIndex();
            m_Current.second = NULL;

            while (m_Current.second == NULL && ++currentRuntimeTypeIndex < Unity::Type::GetTypeCount())
            {
                m_Current.first = Unity::Type::GetTypeByRuntimeTypeIndex(currentRuntimeTypeIndex);
                m_Current.second = m_Current.first->template FindAttribute<TAttribute>();
            }

            return *this;
        }

        self_type operator++(int)
        {
            self_type tmp(*this);
            operator++();
            return tmp;
        }

        reference operator*() const { return m_Current; }
        pointer operator->() const { return &m_Current; }

        bool operator==(const self_type& iter) const { return iter.m_Current.second == m_Current.second; }
        bool operator!=(const self_type& iter) const { return iter.m_Current.second != m_Current.second; }

    private:
        value_type m_Current;
    };

    // Iterator for AllAttributes for empty attribute types
    template<typename TAttribute>
    class AllAttributesIterator<TAttribute, typename EnableIf<core::is_empty<TAttribute>::value>::type>
    {
    public:
        typedef AllAttributesIterator                               self_type;
        typedef Unity::Type                                         value_type;
        typedef ptrdiff_t                                           difference_type;
        typedef const value_type&                                   reference;
        typedef const value_type*                                   pointer;
        typedef std::forward_iterator_tag                           iterator_category;

        // Default iterator == end() iterator
        AllAttributesIterator() : m_CurrentType(NULL) {}

        self_type& operator++()
        {
            RuntimeTypeIndex currentRuntimeTypeIndex = m_CurrentType == NULL ? -1 : m_CurrentType->GetRuntimeTypeIndex();
            bool hasAttribute = false;
            while (!hasAttribute && ++currentRuntimeTypeIndex < Unity::Type::GetTypeCount())
            {
                m_CurrentType = Unity::Type::GetTypeByRuntimeTypeIndex(currentRuntimeTypeIndex);
                hasAttribute = m_CurrentType->HasAttribute<TAttribute>();
            }

            if (!hasAttribute)
                m_CurrentType = NULL; // at the end

            return *this;
        }

        self_type operator++(int)
        {
            self_type tmp(*this);
            operator++();
            return tmp;
        }

        reference operator*() const { return *m_CurrentType; }
        pointer operator->() const { return m_CurrentType; }

        bool operator==(const self_type& iter) const { return iter.m_CurrentType == m_CurrentType; }
        bool operator!=(const self_type& iter) const { return iter.m_CurrentType != m_CurrentType; }

    private:
        const Unity::Type* m_CurrentType;
    };


    // Container returned by Unity::Type::GetAllAttributes()
    template<typename TAttribute>
    class AllAttributes
    {
    public:
        typedef AllAttributesIterator<TAttribute>           const_iterator;
        typedef typename const_iterator::value_type         value_type;
        typedef typename const_iterator::difference_type    difference_type;
        typedef typename const_iterator::reference          reference;
        typedef typename const_iterator::pointer            pointer;

        const_iterator begin() { return ++(const_iterator()); }
        const_iterator end() { return const_iterator(); }
    };


    // Iterator for TypeAttributes
    class TypeAttributesIterator
    {
    public:
        typedef TypeAttributesIterator      self_type;
        typedef ConstVariantRef             value_type;
        typedef ptrdiff_t                   difference_type;
        typedef const value_type&           reference;
        typedef const value_type*           pointer;
        typedef std::forward_iterator_tag   iterator_category;

        // Default iterator == end() iterator
        TypeAttributesIterator(const Unity::Type* type, size_t currentAttributeIndex)
            : m_Type(type), m_CurrentAttributeIndex(currentAttributeIndex) {}

        self_type& operator++()
        {
            m_CurrentAttributeIndex++;
            return *this;
        }

        self_type operator++(int)
        {
            self_type tmp(*this);
            operator++();
            return tmp;
        }

        reference operator*() const { return GetCurrent(); }
        pointer operator->() const { return &GetCurrent(); }

        bool operator==(const self_type& iter) const { return m_CurrentAttributeIndex == iter.m_CurrentAttributeIndex && m_Type == iter.m_Type; }
        bool operator!=(const self_type& iter) const { return m_CurrentAttributeIndex != iter.m_CurrentAttributeIndex || m_Type != iter.m_Type; }

        const Unity::Type* GetType() const { return m_Type; }

    private:
        const ConstVariantRef& GetCurrent() const;
        const Unity::Type* m_Type;
        size_t m_CurrentAttributeIndex;
    };

    // Container returned by Unity::Type::GetAttributes()
    class TypeAttributes
    {
    public:
        typedef TypeAttributesIterator          const_iterator;
        typedef const_iterator::value_type      value_type;
        typedef const_iterator::difference_type difference_type;
        typedef const_iterator::reference       reference;
        typedef const_iterator::pointer         pointer;

        TypeAttributes() : m_Type(NULL), m_AttributeCount(0) {}
        TypeAttributes(const Unity::Type* type, size_t attributeCount)
            : m_Type(type)
            , m_AttributeCount(attributeCount) {}

        const_iterator begin() { return const_iterator(m_Type, 0); }
        const_iterator end() { return const_iterator(m_Type, m_AttributeCount); }

        const Unity::Type* GetType() const { return m_Type; }

    private:
        const Unity::Type* m_Type;
        size_t m_AttributeCount;
    };
} // end namespace Unity
