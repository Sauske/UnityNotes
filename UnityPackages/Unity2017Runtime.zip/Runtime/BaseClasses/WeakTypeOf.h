#pragma once

#include "Type.h"

// ----------------------------------------------------------------------------
// PUBLIC API

// Prefer TypeOf over this function
//        ~~~~~~
//
// This function is different from TypeOf only in that it will work with forward declared types
// WeakTypeOf will WORK EVEN IF THE TYPE IS NEVER DEFINED and this can lead to subtle mistakes
// if a type is mistakenly forward declared in the wrong namespace, or has a typo
//
// Example:
// class Component; namespace Unity {class Component;}
// WeakTypeOf<Component>() will be different than WeakTypeOf<Unity::Component>()
//
template<typename T>
const Unity::Type* WeakTypeOf()
{
    return reinterpret_cast<Unity::Type*>(&TypeContainer<T>::rtti);
}
