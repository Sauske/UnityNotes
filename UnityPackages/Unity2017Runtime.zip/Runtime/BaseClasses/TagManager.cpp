#include "UnityPrefix.h"
#include "TagManager.h"
#include "ManagerContext.h"
#include "Editor/Src/Undo/Undo.h"
#include "Runtime/2D/Sorting/SortingGroup.h"
#include "Runtime/Graphics/Renderer.h"
#include "Runtime/Misc/HasNoReferencesAttribute.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/UI/Canvas.h"
#include "Runtime/Utilities/algorithm_utility.h"
#include "Runtime/Utilities/BitUtility.h"
#include "Runtime/Utilities/RegisterRuntimeInitializeAndCleanup.h"
#include "Runtime/Utilities/HashFunctions.h"
#include "Runtime/Testing/Faking.h"
#include <vector>

static const char* kDefaultSortingLayerName = "Default";
static const char* kInvalidSortingLayerName = "<unknown layer>";
static const core::string gEmpty;

template<class TransferFunc>
void SortingLayerEntry::Transfer(TransferFunc& transfer)
{
    TRANSFER(name);
    TRANSFER(uniqueID);
    TRANSFER_EDITOR_ONLY(locked);
    transfer.Align();
}

TagManager::TagManager(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
#if UNITY_EDITOR
    , m_LockedPickingLayers(0)
#endif
{
    m_TagManagerContainer = UNITY_NEW_AS_ROOT(MemLabelRootId, kMemResource, "LayerTagManager", "") ();
    SET_ALLOC_OWNER(m_TagManagerContainer->rootLabel);
    m_StringToTag = UNITY_NEW(StringToUnsigned, *m_TagManagerContainer);
    m_TagToString = UNITY_NEW(UnsignedToString, *m_TagManagerContainer);
    m_StringToMask = UNITY_NEW(StringToUnsigned, *m_TagManagerContainer);
    // TODO: Pass label to m_SortingLayers
    RegisterDefaultTagsAndLayerMasks();
}

void TagManager::Reset()
{
    __FAKEABLE_METHOD__(TagManager, Reset, ());

    Super::Reset();
    RegisterDefaultTagsAndLayerMasks();
}

bool TagManager::ShouldIgnoreInGarbageDependencyTracking()
{
    __FAKEABLE_METHOD__(TagManager, ShouldIgnoreInGarbageDependencyTracking, ());

    return true;
}

void TagManager::ThreadedCleanup()
{
    UNITY_DELETE(m_StringToTag, *m_TagManagerContainer);
    UNITY_DELETE(m_TagToString, *m_TagManagerContainer);
    UNITY_DELETE(m_StringToMask, *m_TagManagerContainer);
    for (int i = 0; i < 32; i++)
        m_MaskToString[i] = core::string();
    UNITY_DELETE(m_TagManagerContainer, *m_TagManagerContainer);
}

void TagManager::FindDefaultLayerIndex()
{
    __FAKEABLE_METHOD__(TagManager, FindDefaultLayerIndex, ());

    m_DefaultLayerIndex = 0;
    for (size_t i = 0, n = m_SortingLayers.size(); i != n; ++i)
    {
        if (m_SortingLayers[i].uniqueID == 0)
        {
            m_DefaultLayerIndex = i;
            break;
        }
    }
}

void TagManager::AddDefaultLayerIfNeeded()
{
    __FAKEABLE_METHOD__(TagManager, AddDefaultLayerIfNeeded, ());

    // do we have a default layer?
    for (size_t i = 0, n = m_SortingLayers.size(); i != n; ++i)
    {
        if (m_SortingLayers[i].uniqueID == 0)
            return;
    }

    // no default layer, add one in front
    SortingLayerEntry layer;
    layer.name = kDefaultSortingLayerName;
    layer.uniqueID = 0;
    m_SortingLayers.insert(m_SortingLayers.begin(), layer);
    m_DefaultLayerIndex = 0;
}

void TagManager::RegisterTag(UInt32 tag, const core::string& name)
{
    __FAKEABLE_METHOD__(TagManager, RegisterTag, (tag, name));

    SET_ALLOC_OWNER(m_TagManagerContainer->rootLabel);
    if (!m_StringToTag->insert(std::make_pair(name, tag)).second && !name.empty())
        LogStringObject("Default GameObject Tag: " + name + " already registered", this);

    if (!m_TagToString->insert(std::make_pair(tag, name)).second)
        LogStringObject("Default GameObject Tag for name: " + name + " already registered", this);
}

void TagManager::RegisterLayer(UInt32 tag, const core::string& name)
{
    __FAKEABLE_METHOD__(TagManager, RegisterLayer, (tag, name));

    SET_ALLOC_OWNER(m_TagManagerContainer->rootLabel);
    if (!m_StringToMask->insert(std::make_pair(name, tag)).second && !name.empty())
        LogStringObject("Default GameObject BitMask: " + name + " already registered", this);

    if (m_MaskToString[tag].empty())
        m_MaskToString[tag] = name;
    else
        LogStringObject("Default GameObject BitMask for name: " + name + " already registered", this);
}

void TagManager::RegisterDefaultTagsAndLayerMasks()
{
    __FAKEABLE_METHOD__(TagManager, RegisterDefaultTagsAndLayerMasks, ());

    SET_ALLOC_OWNER(m_TagManagerContainer->rootLabel);
    m_StringToTag->clear(); m_TagToString->clear();
    m_StringToMask->clear();
    for (int i = 0; i < 32; i++)
        m_MaskToString[i].clear();

    m_SortingLayers.clear();
    // add "Default" sorting layer
    m_SortingLayers.push_back(SortingLayerEntry());
    SortingLayerEntry& layer = m_SortingLayers[0];
    layer.name = kDefaultSortingLayerName;
    layer.uniqueID = 0;
    m_DefaultLayerIndex = 0;

    RegisterTag(kUntagged, "Untagged");
    RegisterTag(kRespawnTag, "Respawn");
    RegisterTag(kFinishTag, "Finish");
    RegisterTag(kEditorOnlyTag, "EditorOnly");
    RegisterTag(kMainCameraTag, "MainCamera");
    RegisterTag(kGameControllerTag, "GameController");
    RegisterTag(kPlayerTag, "Player");

    RegisterLayer(kDefaultLayer, "Default");
    RegisterLayer(kNoFXLayer, "TransparentFX");
    RegisterLayer(kIgnoreRaycastLayer, "Ignore Raycast");
    RegisterLayer(kWaterLayer, "Water");
    RegisterLayer(kUILayer, "UI");
}

template<class TransferFunction>
void TagManager::Transfer(TransferFunction& transfer)
{
    transfer.SetVersion(2);
    dynamic_array<core::string> tags;

    // Build tags array
    if (transfer.IsWriting())
    {
        UnsignedToString::iterator begin = m_TagToString->lower_bound(kFirstUserTag);
        UnsignedToString::iterator end = m_TagToString->upper_bound(kLastUserTag);
        for (UnsignedToString::iterator i = begin; i != end; i++)
        {
            if (transfer.IsReadingOrWritingSerializedFile() && i->second.empty())
                continue;                                                                   // skip empty tags when writing to disk
            tags.push_back(i->second);
        }
    }
    else if (transfer.IsReading())
    {
        RegisterDefaultTagsAndLayerMasks();
    }

    TRANSFER(tags);

    // case 644146
    // Some old project might have an empty string as the first user tag, which would be given the id 20000 (kFirstUserTag).
    // We don't want to register the empty tag any more so we have to skip it, but the first valid user tag should still start at kFirstUserTag
    // That is why we use the tagIndex instead of simply using kFirstUserTag + i, when registering the tags as that would shift the tags by 1
    int tagIndex = kFirstUserTag;

    // Register tags we've read (if there actually was tag data in the stream).
    if (transfer.DidReadLastProperty())
    {
        for (size_t i = 0; i < tags.size(); i++)
        {
            RegisterTag(tagIndex++, tags[i]);
        }
    }

    if (transfer.IsOldVersion(1))
    {
        // Build bitnames array
        core::string bitnames[32];
        for (int i = 0; i < 32; i++)
        {
            char name[64];
            bool editable = i >= kUserLayer;
            if (editable)
                snprintf(name, sizeof(name), "User Layer %d", i);
            else
                snprintf(name, sizeof(name), "Builtin Layer %d", i);

            bitnames[i] = LayerToString(i);
            transfer.Transfer(bitnames[i], name, editable ? kNoTransferFlags : kNotEditableMask);

            if (transfer.DidReadLastProperty())
            {
                if (i >= kUserLayer)
                    RegisterLayer(i, bitnames[i]);
            }
        }
    }
    else
    {
        // Build layers array
        std::vector<core::string> layers;
        for (int i = 0; i < 32; i++)
        {
            layers.push_back(LayerToString(i));
        }

        TRANSFER(layers);

        if (transfer.DidReadLastProperty())
        {
            const int maxSize = std::min((int)layers.size(), 32);
            for (int i = 8; i < maxSize; i++)
                RegisterLayer(i, layers[i]);
        }
    }

    // Sorting layers
    TRANSFER(m_SortingLayers);
    if (!transfer.IsWriting() && transfer.IsReading())
    {
        AddDefaultLayerIfNeeded();
        FindDefaultLayerIndex();
    }
}

UInt32 TagManager::StringToTag(const core::string& tag)
{
    __FAKEABLE_METHOD__(TagManager, StringToTag, (tag));

#if UNITY_EDITOR
    Mutex::AutoLock lock(m_TagToStringMutex);
#endif

    StringToUnsigned::iterator i = m_StringToTag->find(tag);
    if (i == m_StringToTag->end())
        return kUndefinedTag;
    else
        return i->second;
}

const core::string& TagManager::TagToString(UInt32 tag)
{
    __FAKEABLE_METHOD__(TagManager, TagToString, (tag));

#if UNITY_EDITOR
    Mutex::AutoLock lock(m_TagToStringMutex);
#endif
    UnsignedToString::iterator i = m_TagToString->find(tag);
    if (i == m_TagToString->end())
    {
        return gEmpty;
    }
    else
        return i->second;
}

// In the editor we might add / remove tags from the gStringToTag array.
// And we might do this from the loading thread and main thread at the same time.
// In the player this map is completely fixed, thus even if two threads access the data at the same time, the data always stays constant.
#if UNITY_EDITOR

UInt32 TagManager::StringToTagAddIfUnavailable(const core::string& tag)
{
    __FAKEABLE_METHOD__(TagManager, StringToTagAddIfUnavailable, (tag));

    // Users could have empty tag on the game object in the scene which is supposed to be "Untagged". (Don't know how this happened, please refer to case 667492.)
    // For this case, we would like to return kUntagged rather than assertion.
    // Then users will see the "Untagged" tag and only save the tag when they modify it.
    if (tag.empty())
        return kUntagged;

    Mutex::AutoLock lock(m_TagToStringMutex);
    StringToUnsigned::iterator i = m_StringToTag->find(tag);
    if (i == m_StringToTag->end())
    {
        SET_ALLOC_OWNER(m_TagManagerContainer->rootLabel);
        int nextTagID = last_iterator(*m_TagToString)->first + 1;
        if (nextTagID < kFirstUserTag)
            nextTagID = kFirstUserTag;
        m_TagToString->insert(std::make_pair(nextTagID, tag));
        m_StringToTag->insert(std::make_pair(tag, nextTagID));
        return nextTagID;
    }
    else
        return i->second;
}

void TagManager::RemoveTag(const core::string& tag)
{
    __FAKEABLE_METHOD__(TagManager, RemoveTag, (tag));

    if (tag.empty())
        return;
    Mutex::AutoLock lock(m_TagToStringMutex);
    StringToUnsigned::iterator it = m_StringToTag->find(tag);
    Assert(it != m_StringToTag->end());
    int ntag = it->second;
    (*m_TagToString)[ntag] = "";
    m_StringToTag->erase(it);
    SetDirty();
}

#endif

UInt32 TagManager::StringToLayer(const core::string& tag)
{
    __FAKEABLE_METHOD__(TagManager, StringToLayer, (tag));

    StringToUnsigned::iterator i = m_StringToMask->find(tag);
    if (i == m_StringToMask->end())
        return -1;
    else
        return i->second;
}

const core::string& TagManager::LayerToString(UInt32 layer)
{
    __FAKEABLE_METHOD__(TagManager, LayerToString, (layer));

    if (layer >= 32)
    {
        ErrorString("Layer index out of bounds");
        return gEmpty;
    }
    return m_MaskToString[layer];
}

UnsignedToString TagManager::GetTags()
{
    __FAKEABLE_METHOD__(TagManager, GetTags, ());

    // Cull out all empty string tags. (The user is allowed to add those but we dont want them to show up!)
    UnsignedToString tags;
    for (UnsignedToString::iterator i = m_TagToString->begin(); i != m_TagToString->end(); i++)
    {
        if (!i->second.empty())
            tags.insert(std::make_pair(i->first, i->second));
    }
    return tags;
}

// -------------------------------------------------------------------
// For sorting layers.

int TagManager::GetSortingLayerCount()
{
    __FAKEABLE_METHOD__(TagManager, GetSortingLayerCount, ());

    return m_SortingLayers.size();
}

core::string TagManager::GetSortingLayerName(int index)
{
    __FAKEABLE_METHOD__(TagManager, GetSortingLayerName, (index));

    if (index < 0 || index >= (int)m_SortingLayers.size())
        return core::string(kInvalidSortingLayerName);
    return m_SortingLayers[index].name;
}

core::string TagManager::GetSortingLayerNameFromUniqueID(int id)
{
    __FAKEABLE_METHOD__(TagManager, GetSortingLayerNameFromUniqueID, (id));

    if (id == 0)
        return core::string(kDefaultSortingLayerName);

    for (size_t i = 0; i < m_SortingLayers.size(); ++i)
        if (m_SortingLayers[i].uniqueID == (UInt32)id)
            return m_SortingLayers[i].name;

    return core::string(kInvalidSortingLayerName);
}

core::string TagManager::GetSortingLayerNameFromValue(int layerValue)
{
    __FAKEABLE_METHOD__(TagManager, GetSortingLayerNameFromValue, (layerValue));

    int index = m_DefaultLayerIndex + layerValue;
    if (index < 0 || index >= (int)m_SortingLayers.size())
        return core::string(kInvalidSortingLayerName);
    return m_SortingLayers[index].name;
}

int TagManager::GetSortingLayerUniqueID(int index)
{
    __FAKEABLE_METHOD__(TagManager, GetSortingLayerUniqueID, (index));

    Assert(index >= 0 && index < (int)m_SortingLayers.size());
    return m_SortingLayers[index].uniqueID;
}

int TagManager::GetSortingLayerUniqueIDFromValue(int layerValue)
{
    __FAKEABLE_METHOD__(TagManager, GetSortingLayerUniqueIDFromValue, (layerValue));

    int index = m_DefaultLayerIndex + layerValue;
    if (index < 0 || index >= (int)m_SortingLayers.size())
        return 0;
    return m_SortingLayers[index].uniqueID;
}

int TagManager::GetSortingLayerUniqueIDFromName(const core::string& name)
{
    __FAKEABLE_METHOD__(TagManager, GetSortingLayerUniqueIDFromName, (name));

    if (name.empty())
        return 0;

    for (size_t i = 0; i < m_SortingLayers.size(); ++i)
        if (m_SortingLayers[i].name == name)
            return m_SortingLayers[i].uniqueID;

    return 0; // unknown layer: treat as default layer
}

int TagManager::GetSortingLayerIndexFromValue(int layerValue)
{
    __FAKEABLE_METHOD__(TagManager, GetSortingLayerIndexFromValue, (layerValue));

    int index = m_DefaultLayerIndex + layerValue;
    if (index < 0 || index >= (int)m_SortingLayers.size())
        index = 0;
    return index;
}

int TagManager::GetSortingLayerValueFromUniqueID(int id)
{
    __FAKEABLE_METHOD__(TagManager, GetSortingLayerValueFromUniqueID, (id));

    if (id == 0)
        return 0;

    for (size_t i = 0; i < m_SortingLayers.size(); ++i)
        if (m_SortingLayers[i].uniqueID == (UInt32)id)
            return i - m_DefaultLayerIndex;

    return 0; // unknown layer: treat as if no layer is assigned
}

int TagManager::GetSortingLayerValueFromName(const core::string& name)
{
    __FAKEABLE_METHOD__(TagManager, GetSortingLayerValueFromName, (name));

    if (name.empty())
        return 0;

    for (size_t i = 0; i < m_SortingLayers.size(); ++i)
        if (m_SortingLayers[i].name == name)
            return i - m_DefaultLayerIndex;

    return 0; // unknown layer: treat as default layer
}

bool TagManager::IsSortingLayerUniqueIDValid(int id)
{
    __FAKEABLE_METHOD__(TagManager, IsSortingLayerUniqueIDValid, (id));

    if (id == 0)
        return true;

    for (size_t i = 0; i < m_SortingLayers.size(); ++i)
        if (m_SortingLayers[i].uniqueID == (UInt32)id)
            return true;

    return false;
}

#if UNITY_EDITOR
void TagManager::SetSortingLayerName(int index, const core::string& name)
{
    __FAKEABLE_METHOD__(TagManager, SetSortingLayerName, (index, name));

    Assert(index >= 0 && index < m_SortingLayers.size());
    RegisterUndo(this, "Rename Sorting Layer", 0);
    m_SortingLayers[index].name = name;
    SetDirty();
}

void TagManager::AddSortingLayer()
{
    __FAKEABLE_METHOD__(TagManager, AddSortingLayer, ());

    SortingLayerEntry s;

    // internal ID should be quite unique; generate a GUID and hash to and integer
    UnityGUID guid;
    guid.Init();
    s.uniqueID = ComputeHash32(&guid.data, sizeof(guid.data));
    s.uniqueID |= 1; // make sure it's never zero

    s.name = Format("New Layer");
    s.locked = false;

    RegisterUndo(this, "Add Sorting Layer", 0);
    m_SortingLayers.push_back(s);
    SetDirty();
}

void TagManager::UpdateSortingLayersOrder()
{
    __FAKEABLE_METHOD__(TagManager, UpdateSortingLayersOrder, ());

    FindDefaultLayerIndex();

    {
        dynamic_array<Renderer*> objs(kMemTempAlloc);
        Object::FindObjectsOfType(objs);
        for (size_t i = 0, n = objs.size(); i != n; ++i)
        {
            objs[i]->SetupSortingOverride();
        }
    }

    {
        dynamic_array<SortingGroup*> objs(kMemTempAlloc);
        Object::FindObjectsOfType(objs);
        for (size_t i = 0, n = objs.size(); i != n; ++i)
        {
            objs[i]->SetupSortingOverride();
        }
    }

    {
        dynamic_array<UI::Canvas*> objs(kMemTempAlloc);
        Object::FindObjectsOfType(objs);
        for (size_t i = 0, n = objs.size(); i != n; ++i)
        {
            objs[i]->UpdateCachedSortingLayerValue();
        }
    }
}

void TagManager::SwapSortingLayers(int idx1, int idx2)
{
    __FAKEABLE_METHOD__(TagManager, SwapSortingLayers, (idx1, idx2));

    Assert(idx1 >= 0 && idx1 < m_SortingLayers.size());
    Assert(idx2 >= 0 && idx2 < m_SortingLayers.size());
    std::swap(m_SortingLayers[idx1], m_SortingLayers[idx2]);
    UpdateSortingLayersOrder();
    SetDirty();
}

void TagManager::SetLockedPickingLayers(int lockedPickingLayers)
{
    __FAKEABLE_METHOD__(TagManager, SetLockedPickingLayers, (lockedPickingLayers));

    m_LockedPickingLayers = lockedPickingLayers;
}

int TagManager::GetLockedPickingLayers()
{
    __FAKEABLE_METHOD__(TagManager, GetLockedPickingLayers, ());

    return m_LockedPickingLayers;
}

void TagManager::SetSortingLayerLocked(int index, bool locked)
{
    __FAKEABLE_METHOD__(TagManager, SetSortingLayerLocked, (index, locked));

    Assert(index >= 0 && index < m_SortingLayers.size());
    m_SortingLayers[index].locked = locked;
    SetDirty();
}

bool TagManager::GetSortingLayerLocked(int index)
{
    __FAKEABLE_METHOD__(TagManager, GetSortingLayerLocked, (index));

    if (index < 0 || index >= m_SortingLayers.size())
        return false;
    return m_SortingLayers[index].locked;
}

bool TagManager::IsSortingLayerDefault(int index)
{
    __FAKEABLE_METHOD__(TagManager, IsSortingLayerDefault, (index));

    return index == m_DefaultLayerIndex;
}

#endif // #if UNITY_EDITOR

REGISTER_TYPE_ATTRIBUTES(TagManager, (HasNoReferences, ()));
IMPLEMENT_REGISTER_CLASS(TagManager, 78);
IMPLEMENT_OBJECT_SERIALIZE(TagManager);

TagManager& GetTagManager()
{
    __FAKEABLE_FUNCTION__(GetTagManager, ());

    return (TagManager&)GetManagerFromContext(ManagerContext::kTagManager);
}
