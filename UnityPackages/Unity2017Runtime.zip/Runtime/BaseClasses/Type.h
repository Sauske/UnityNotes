#pragma once

#include "Variant.h"
#include "Runtime/Core/Containers/String.h"
#include "Runtime/Logging/LogAssert.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Utilities/EnumFlags.h"
#if ENABLE_UNIT_TESTS
#include "Runtime/Testing/TestingForwardDecls.h"
#endif

#include "Runtime/Utilities/Annotations.h"
#include <bitset>

class Object;

enum ObjectCreationMode
{
    // Create the object from the main thread in a perfectly normal way
    kCreateObjectDefault = 0,
    // Create the object from another thread. Might assign an instance ID but will not register with IDToPointer map.
    // Objects created like this, need to call,  AwakeFromLoadThraded, and Object::RegisterInstanceID and AwakeFromLoad (kDidLoadThreaded); from the main thread
    kCreateObjectFromNonMainThread = 1,
    // Create the object and register the instance id but do not lock the object
    // creation mutex because the code calling it already called LockObjectCreation mutex.
    kCreateObjectDefaultNoLock = 2
};

// NOTE : Keep in sync with the managed enum in UnityType.cs
enum TypeFlags
{
    kTypeNoFlags        = 0,
    kTypeIsAbstract     = 1 << 0,
    kTypeIsSealed       = 1 << 1,
    kTypeIsEditorOnly   = 1 << 2,
    kTypeIsStripped     = 1 << 3
};
ENUM_FLAGS(TypeFlags);

typedef SInt32 PersistentTypeID;
typedef UInt32 RuntimeTypeIndex;

// ----------------------------------------------------------------------------
// Internal

// RTTI is deliberately a pod (plain old data) type and is aggregate initialized instead of using constructors
// TypeContainer<T>::rtti is used for many different types in many different translation units
// If RTTI was not a pod type many compilers would generate an unreasonable amount of initialization code
struct RTTI
{
    enum
    {
        UndefinedPersistentTypeID = -1
    };

    typedef Object* FactoryFunction (MemLabelId label, ObjectCreationMode mode);

    struct DerivedFromInfo
    {
        RuntimeTypeIndex typeIndex;        // consecutive type index, assigned so that all descendant classes have a type index in the range [typeIndex,typeIndex+descendantCount[
        UInt32 descendantCount;
    };

    enum
    {
        // These values are chosen so that IsDerivedFrom(a,b) always return false if a or b have default values (they are undefined types)
        DefaultTypeIndex = 0x80000000,
        DefaultDescendentCount = 0
    };

    static inline bool IsDerivedFrom(RuntimeTypeIndex typeIndex, RuntimeTypeIndex baseTypeIndex, UInt32 baseDescendantCount)
    {
        return (typeIndex - baseTypeIndex) < baseDescendantCount;
    }

    static inline bool IsDerivedFrom(RuntimeTypeIndex typeIndex, const RTTI& baseType)
    {
        return (typeIndex - baseType.derivedFromInfo.typeIndex) < baseType.derivedFromInfo.descendantCount;
    }

    static inline bool IsDerivedFrom(const RTTI& derivedType, const RTTI& baseType)
    {
        return (derivedType.derivedFromInfo.typeIndex - baseType.derivedFromInfo.typeIndex) < baseType.derivedFromInfo.descendantCount;
    }

    core::string GetFullName() const;

    const RTTI*              base;             // super rtti class
    FactoryFunction*         factory;          // the factory function of the class
    const char*              className;        // the name of the class
    const char*              classNamespace;
    const char*              module;
    PersistentTypeID         persistentTypeID; // the class ID of the class
    int                      size;             // sizeof (Class)
    DerivedFromInfo          derivedFromInfo;
    bool                     isAbstract;       // is the class Abstract?
    bool                     isSealed;
    bool                     isEditorOnly;
    bool                     isStripped;
    const ConstVariantRef*   attributes;       // Array of attributes associated with this type
    size_t                   attributeCount;

    struct RuntimeTypeArray
    {
        static const UInt32 MAX_RUNTIME_TYPES = 1024;

        UInt32 Count;
        RTTI* Types[MAX_RUNTIME_TYPES];
    };

    // TODO (scobi 21-jun-17) would like to see this concept of faking an inline wrapped up better;
    // see https://ono.unity3d.com/unity/draft/pull-request/30359/_/core/typeinfo/sendmessage#comment-207798
#if ENABLE_UNIT_TESTS
    static RuntimeTypeArray& GetRuntimeTypes();
    static RuntimeTypeArray& GetRuntimeTypes_Unfaked()
#else
    static RuntimeTypeArray& GetRuntimeTypes()
#endif
    {
        return ms_runtimeTypes;
    }

private:
    static RuntimeTypeArray ms_runtimeTypes;
};


// As is TypeContainer<T>::rtti will not be guaranteed to be unique with dylibs/dlls
// On OSX and Linux it will need a visibility("default") attribute and on windows
// the linking of these symbols needs to be handled manually by using a custom section and
// remapping on startup (using __declspec(allocate("...") and #pragma section)
template<typename T>
struct TypeContainer
{
    static RTTI rtti;
};

// RTTI is deliberately aggregate initialized (see the comment on the definition of RTTI)
#define RTTI_DEFAULT_INITIALIZER_LIST { NULL, NULL, "[UNREGISTERED]", "", "Core", RTTI::UndefinedPersistentTypeID, -1, \
{ (UInt32)RTTI::DefaultTypeIndex, (UInt32)RTTI::DefaultDescendentCount}, false, false, false, false, NULL, 0 }

template<typename T>
RTTI TypeContainer<T>::rtti = RTTI_DEFAULT_INITIALIZER_LIST;

namespace detail
{
    // The static initialization of AttributeMap will generate a linked list of AttributeMapEntrys.
    // Each AttributeEntry has a bitset that has a bit set, for each Type that has the attribute.
    // The registration of types in the bitsets is done in TypeManager

    typedef std::bitset<RTTI::RuntimeTypeArray::MAX_RUNTIME_TYPES> TypeBitset;

    struct AttributeMapEntry
    {
        static AttributeMapEntry* s_head;
        TypeBitset *types;
        const Unity::Type* attrType;
        AttributeMapEntry* next;
    };

    template<class TAttribute>
    class AttributeMap
    {
    public:
        AttributeMap()
        {
            m_entry.next = AttributeMapEntry::s_head;
            AttributeMapEntry::s_head = &m_entry;
            m_entry.types = &m_types;
            m_entry.attrType = TypeOf<TAttribute>();
        }

        inline bool HasAttribute(RuntimeTypeIndex index)
        {
            return m_types[index];
        }

    private:
        AttributeMapEntry m_entry;
        TypeBitset m_types;
    };

    template<class TAttribute>
    struct AttributeMapContainer
    {
        static AttributeMap<TAttribute> s_map;
    };

    template<class TAttribute>
    AttributeMap<TAttribute> AttributeMapContainer<TAttribute>::s_map;
}


// ----------------------------------------------------------------------------
// PUBLIC API

namespace Unity
{ class Type; }


// The template argument of TypeOf must be a complete type
// Whenever possible this should be used over WeakTypeOf to avoid errors where you mistakenly forward define
// a type in the wrong namespace or with a misspelled name and end up referencing the wrong type
template<typename T>
const Unity::Type* TypeOf()
{
    CompileTimeAssert(sizeof(T) > 0, "TypeOf<> cannot be used with incomplete type");
    return reinterpret_cast<Unity::Type*>(&TypeContainer<T>::rtti);
}

namespace Unity
{
    template<typename TAttribute> class AllAttributes;
    class TypeAttributes;

    class Type
    {
    public:
        enum CaseSensitivityOptions
        {
            kCaseSensitive,
            kCaseInSensitive,
        };

        enum TypeFilterOptions
        {
            kAllTypes,
            kOnlyNonAbstract,
        };

        enum
        {
            UndefinedPersistentTypeID = RTTI::UndefinedPersistentTypeID
        };

        typedef Object* FactoryFunction (MemLabelId label, ObjectCreationMode mode);

        static UInt32 GetTypeCount() { return RTTI::GetRuntimeTypes().Count; }

        static const Type* GetTypeByRuntimeTypeIndex(RuntimeTypeIndex index)
        {
            DebugAssertMsg(index < GetTypeCount(), "Runtime type index is out of bounds of registered types");
            return reinterpret_cast<Type*>(RTTI::GetRuntimeTypes().Types[index]);
        }

        static const Type* FindTypeByName(const char* name, CaseSensitivityOptions options = kCaseSensitive);
        static const Type* FindTypeByPersistentTypeID(PersistentTypeID id);
        static const Type* GetDeserializationStubForPersistentTypeID(PersistentTypeID typeID);

        bool HasValidRuntimeTypeIndex() const { return m_internal.derivedFromInfo.typeIndex != RTTI::DefaultTypeIndex; }

        PersistentTypeID GetPersistentTypeID() const { return PersistentTypeID(m_internal.persistentTypeID); }

        RuntimeTypeIndex GetRuntimeTypeIndex() const { return m_internal.derivedFromInfo.typeIndex; }
        UInt32 GetDescendantCount() const { return m_internal.derivedFromInfo.descendantCount; }

        const char* GetName() const { return m_internal.className; }
        const char* GetNamespace() const { return m_internal.classNamespace; }
        const char* GetModule() const { return m_internal.module; }
        core::string GetFullName() const { return m_internal.GetFullName(); }

        const Type* GetBaseClass() const { return reinterpret_cast<const Type*>(m_internal.base); }
        void FindAllDerivedClasses(dynamic_array<const Type*>& result, TypeFilterOptions options) const;

        template<typename TAttribute>
        bool HasAttribute() const
        {
            return detail::AttributeMapContainer<TAttribute>::s_map.HasAttribute(GetRuntimeTypeIndex());
        }

        template<typename TAttribute>
        const TAttribute* FindAttribute() const
        {
            CompileTimeAssert(!core::is_empty<TAttribute>::value, "Attribute is an empty attribute type. Use HasAttribute() instead. FindAttribute is for finding a non-empty attribute instance");
            const Type* attributeType = TypeOf<TAttribute>();
            const ConstVariantRef* arr = m_internal.attributes;
            for (size_t i = 0; i < m_internal.attributeCount; ++i)
            {
                if (attributeType == arr[i].GetType())
                    return &(arr[i].Get<TAttribute>());
            }
            return NULL;
        }

        size_t GetAttributeCount() const { return m_internal.attributeCount; }
        const ConstVariantRef& GetAttribute(size_t idx) const { return m_internal.attributes[idx]; }

        void GetAttributes(TypeAttributes& result) const;

        template<typename TAttribute>
        static AllAttributes<TAttribute> GetAllAttributes()
        {
            return AllAttributes<TAttribute>();
        }

        int GetSize() const { return m_internal.size; }
        FactoryFunction* GetFactory() const { return m_internal.factory; }

        bool IsSealed() const { return m_internal.isSealed; }
        bool IsAbstract() const { return m_internal.isAbstract; }
        bool IsEditorOnly() const { return m_internal.isEditorOnly; }
        bool IsStripped() const { return m_internal.isStripped; }

        bool IsBaseOf(RuntimeTypeIndex derived) const { return RTTI::IsDerivedFrom(derived, m_internal); }
        bool IsBaseOf(const Type* derived) const
        {
            AssertMsg(derived != NULL, "IsBaseOf : Derived type cannot be null");
            return RTTI::IsDerivedFrom(derived->m_internal, m_internal);
        }

        template<typename T> bool IsBaseOf() const { return RTTI::IsDerivedFrom(TypeOf<T>()->m_internal, m_internal); }

        bool IsDerivedFrom(const Type* base) const
        {
            AssertMsg(base != NULL, "IsDerivedFrom : base type cannot be null");
            return RTTI::IsDerivedFrom(m_internal, base->m_internal);
        }

        template<typename T> bool IsDerivedFrom() const { return RTTI::IsDerivedFrom(m_internal, TypeOf<T>()->m_internal); }

    private:
        RTTI m_internal;
    };

#if ENABLE_UNIT_TESTS
    // Define operator << for const Type*, which will be automatically picked up and used by the unit testing framework to
    // e.g. make parametric tests display nice type names in their titles instead of just the addresses of type objects
    std::ostream& operator<<(std::ostream& stream, const Type* type);
#endif
} // namespace Unity


// ----------------------------------------------------------------------------

typedef void TypeCallback ();

struct TypeRegistrationDesc
{
    RTTI init;
    RTTI* type; // this is the storage for the type information ('init' is copied into it)
    TypeCallback* initCallback;
    TypeCallback* postInitCallback;
    TypeCallback* cleanupCallback;
};

// TypeRegistrationDesc is deliberately aggregate initialized (necessary for IMPLEMENT_REGISTER_CLASS to work at file scope)
#define TYPEREGISTRATIONDESC_DEFAULT_INITIALIZER_LIST { RTTI_DEFAULT_INITIALIZER_LIST, NULL, NULL, NULL, NULL }
