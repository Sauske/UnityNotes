#pragma once

#include "UnityPrefix.h"
#include "Runtime/Allocator/MemoryMacros.h"
#include "Runtime/BaseClasses/InstanceID.h"
#include "Runtime/BaseClasses/ObjectDefines.h"
#include "Runtime/Containers/CommonString.h"
#include "Runtime/Serialize/SerializeUtility.h"
#include "Runtime/Serialize/SerializationMetaFlags.h"
#include "Runtime/Scripting/ScriptingTypes.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Utilities/NonCopyable.h"
#include "Runtime/Logging/LogAssert.h"
#include "Runtime/Utilities/Prefetch.h"
#include "Runtime/Scripting/BindingsDefs.h"
#include "Runtime/ScriptingBackend/ScriptingApi.h"
#include "Runtime/Scripting/BindingsDefs.h"

#if THREADED_LOADING
#include "Runtime/Threads/ThreadSpecificValue.h"
#include "Runtime/Threads/ProfilerMutex.h"
#endif

#include "Runtime/Core/Containers/hash_map.h"

#include <string>


class GenerateTypeTreeTransfer;
class SafeBinaryRead;
template<bool kSwap>
class StreamedBinaryRead;
template<bool kSwap>
class StreamedBinaryWrite;
class RemapPPtrTransfer;
class TypeTree;
class Object;
struct EventEntry;
#if SUPPORT_TEXT_SERIALIZATION
class YAMLRead;
class YAMLWrite;
#endif
#if UNITY_EDITOR
class JSONRead;
class JSONWrite;
#endif

#include <typeinfo>

// Every class that is derived from object has to place this inside the class Declaration
// REGISTER_CLASS (Foo, #);
// Where # is a Type id, these are random 32 bit numbers and in order to reduce the risk of collisions
// please use http://www.random.org/cgi-bin/randbyte?nbytes=4&format=h to generate ids for new types
// (in VS you can ctrl+click the link to generate a number). In the unlikely event of a collision
// the type manager will report a problem during initialization.

//In the cpp file of every object derived class you have to place eg. IMPLEMENT_CLASS (Foo)
//#define IMPLEMENT_CLASS(x)
// or IMPLEMENT_CLASS_HAS_INIT (x) which will call the static class Function InitializeClass (); on startup.

enum AwakeFromLoadMode
{
    // This is the default, usually called from the inspector or various serialization methods
    kDefaultAwakeFromLoad = 0,
    // The object was loaded from disk
    kDidLoadFromDisk = 1 << 0,
    // The object was loaded from a loading thread (in almost all cases through loading from disk asynchronously)
    kDidLoadThreaded = 1 << 1,
    // Object was instantiated and is now getting its first Awake function or it was created from code and gets the Awake function called
    kInstantiateOrCreateFromCodeAwakeFromLoad = 1 << 2,
    // GameObject was made active or a component was added to an active game object
    kActivateAwakeFromLoad = 1 << 3,
    // The object serialized values have been modified by the animation system.
    kAnimationAwakeFromLoad = 1 << 4,

    // This object is only loaded temporarily for the purpose of building data for assetbundles/player.
    // The object will be unloaded immediately afterwards.
    // When loading an asset for build the full maks will be: kPersistentManagerAwakeFromLoadMode | kWillUnloadAfterWritingBuildData
    kWillUnloadAfterWritingBuildData = 1 << 5,


    // This is the combined flags which are used to load objects from the disk (PersistentManager)
    kPersistentManagerAwakeFromLoadMode = kDidLoadFromDisk | kDidLoadThreaded,
    kDefaultAwakeFromLoadInvalid = -1
};
ENUM_FLAGS(AwakeFromLoadMode);

// Check if the AwakeFromLoadMode correspond to an awake called on existing object but where any value
// might have changed.
inline bool DidChangeExistingValueAwake(AwakeFromLoadMode mode)
{
    return (mode & (kDidLoadFromDisk | kActivateAwakeFromLoad | kInstantiateOrCreateFromCodeAwakeFromLoad)) == 0;
}

class BaseAllocator;

enum ObjectDeleteMode
{
    kUnknownMode = 0
};

class EXPORT_COREMODULE Object : public NonCopyable
{
public:
    // These values are necessary for child classes to be able to register themselves using the REGISTER_CLASS macro
    struct kTypeFlags { enum { value = kTypeIsAbstract }; };
    typedef Object ThisType;

protected:

    /// You may not implement the destructor for Object derived classes.
    /// Use ThreadedCleanup or MainThreadCleanup instead.
    /// Please note that default destruction of embedded types happens at the same time as ThreadedCleanup,
    /// thus they may not access global state
    virtual ~Object();

public:

    Object(MemLabelId label, ObjectCreationMode mode);

    /// Some classes need to deallocate resources on the main thread or deregister themselves from other objects,
    /// for those things you want to override MainThreadCleanup.
    /// Unless the code is thread safe, that work must be done in MainThreadCleanup as there are no guarantees about when on the other thread the destructor will be called.
    ///
    /// Every class implementing MainThreadCleanup must call Super::MainThreadCleanup().
    /// void MyClass::MainThreadCleanup()
    /// {
    ///     Super::MainThreadCleanup();
    ///     RemoveMeFromSomeGlobalLinkedList ();
    /// }
    virtual void MainThreadCleanup()
    {
#if !UNITY_RELEASE
        m_MainThreadCleanupCalled = 1;
#endif
    }

    /// ThreadedCleanup is called just before the object is destroyed.
    /// ThreadedCleanup may be called on the destruction thread, or in some cases on the main thread, but there is no guarantee.
    /// This functions exists to let you to do any type of cleanup that does not touch global state or other objects.
    /// It is not safe to touch global state or access other objects from ThreadedCleanup.
    /// For this reason GetInstanceID () returns 0 and asserts on access when it is accessed after MainThreadCleanup has been called.
    /// See BatchDeleteObjects.h
    /// NOTE: This function is not virtual the destructor at each level thus you shall not call the super classes ThreadedCleanup.
    void ThreadedCleanup() {}

    /// AwakeFromLoad is called on the main thread, after the data of the object has been modified from outside in a generic way.
    /// For example:
    /// * after reading from disk
    /// * reading from a binary serialized array (eg. SerializedProperty / Prefabs)
    /// * Also the animation system might patch float and bool member variables of the object directly.
    /// * After an object has been created from code
    /// * When a game object is being activated

    /// AwakeFromLoadMode can be used to differentiate the different actions.

    /// AwakeFromLoad is effectively the call where you get to sync up any cached state that can go out of sync when the data is changed underneath you.
    /// AwakeFromLoad is always called on the main thread.
    virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode)
    {
        SetAwakeCalledInternal();
        if (awakeMode & kDidLoadThreaded)
            SetAwakeDidLoadThreadedCalledInternal();
    }

    /// AwakeFromLoadThreaded is called immediately after deserialization when an object is loaded from disk.
    /// It is called on the loading thread, thus NOT guaranteed to always be called.
    /// Objects created from code do not call this function, it is only called when loading from disk.
    /// Thus it is not safe to access other objects or any global state from AwakeFromLoadThreaded unless the code is thread safe
    /// A common usage case is to compute expensive data on the loading thread in order to not incur any cost on the main thread.
    virtual void AwakeFromLoadThreaded()
    {
#if !UNITY_RELEASE
        m_AwakeThreadedCalled           = 1;
        m_AwakeCalled                   = 0;
        m_AwakeDidLoadThreadedCalled    = 0;
#endif
    }

    /// CheckConsistency is called in the Editor when loading data from disk and when changing data in the inspector.
    /// It gives you a chance to validate the serialized data, check for value ranges or internal consistency.

    /// It is always called before AwakeFromLoad is called. Thus AwakeFromLoad can safely rely on clamped values enforced by CheckConsistency.
    /// Conversely CheckConsistency should never expect objects to be fully initialized since AwakeFromLoad has not yet been called.
    /// Note: The data set in CheckConsistency won't be saved back to meta file, because after CheckConsistency m_DirtyIndex is cleared via ClearPersistentDirty()
    virtual void CheckConsistency() {}


    /// Override Reset in order to setup default serialized values for the Object.
    /// Reset can be invoked on the loading thread or main thread and objects may not be fully constructed.
    /// For example you can not safely access other components from Reset.
    /// Global state can also not be safely accessed since it can be called from the loading thread.
    ///
    /// Reset is called when an object is:
    /// * Created from code
    /// * Loaded from disk via SafeBinaryRead or YamlRead (We do not know if all properties are defined)
    ///
    /// Reset is NOT called when an object is read from disk via StreamedBinaryRead. Thus in most scenarios in the player, Reset is not called.
    /// The basic concept is that
    ///
    /// Reset should ONLY be used to reset serialized values. This is because it will no be called when reading StreamedBinaryReadData
    /// (We assume data is already going to fill in all values in a good state)
    ///
    /// In Reset you cannot access other objects. And objects should be initialized deterministically.
    /// eg. m_HitPoints = 100;
    virtual void Reset()
    {
        SetResetCalledInternal();
#if !UNITY_RELEASE
        m_AwakeCalled                   = 0;
        m_AwakeThreadedCalled           = 0;
        m_AwakeDidLoadThreadedCalled    = 0;
#endif
    }

    /// Smart Reset is called when "Reset" context menu is selected, when AddComponent is called and a new ScriptableObject is created,
    /// or when an AssetImporter is created from scratch.
    /// For default initialization/resetting, use Reset() instead.
    ///
    /// It is most useful for calculating values that depend o a global view, eg. adjust a collider box size by the renderers mesh bounding volume.
    /// You can traverse the hierarchy and the object is guaranteed to already be in a valid state.
    /// Assumptions you can make:
    /// * If it is a component, then it has been added to a fully initialized gameobject
    /// * All managers have been fully initialized
    /// * Always called on the main thread
    ///
    /// In SmartReset you can access others objects. The values you initialize can be indeterministic and usually depend on other objects in the scene.
    /// eg. m_HitPoints = QueryComponent(Orc) != NULL ? 100 : 20;
    virtual void SmartReset()
    {
        SetResetCalledInternal();
#if !UNITY_RELEASE
        m_AwakeCalled                   = 0;
        m_AwakeThreadedCalled           = 0;
        m_AwakeDidLoadThreadedCalled    = 0;
#endif
    }

    /// To destroy objects use delete_object instead of delete operator
    /// The default way to destroy objects is using the DestroyObject Function, which also destroys the object from it's file
    /// Must be protected by LockObjectCreation / UnlockObjectCreation
    friend void delete_object_internal_step1(Object* p);
    friend void delete_object_internal_step2(Object* p);

    // ----------------------------------------------------------------------------
    // TYPE API

    bool Is(const Unity::Type* type) const { return type->IsBaseOf(m_CachedTypeIndex); }
    template<typename T> bool Is() const { return TypeOf<T>()->IsBaseOf(m_CachedTypeIndex); }

    const Unity::Type* GetType() const { return Unity::Type::GetTypeByRuntimeTypeIndex(m_CachedTypeIndex); }

    static void FindInstanceIDsOfType(const Unity::Type* type, dynamic_array<InstanceID>& instanceIDs, bool sorted = false);

    template<class T>
    static void FindInstanceIDsOfType(dynamic_array<InstanceID>& instanceIDs, bool sorted = false)
    {
        FindInstanceIDsOfType(TypeOf<T>(), instanceIDs, sorted);
    }

    // Variadic arguments should be terminated with NULL
    // FindInstanceIDsOfTypes(objects, TypeOf<Type1>(), TypeOf<Type2>(), NULL);
    // type1 should never be NULL
    static void FindInstanceIDsOfTypes(dynamic_array<InstanceID>& objects, const Unity::Type* type1, ...);

    static void FindObjectsOfType(const Unity::Type* type, dynamic_array<Object*>& derivedObjects, bool sorted = false);

    template<class T>
    static void FindObjectsOfType(dynamic_array<T*>& derivedObjects, bool sorted = false)
    {
        dynamic_array<Object*>& casted = reinterpret_cast<dynamic_array<Object*>&>(derivedObjects);
        FindObjectsOfType(TypeOf<T>(), casted, sorted);
    }

    // Variadic arguments should be terminated with NULL
    // FindObjectsOfTypes(objects, TypeOf<Type1>(), TypeOf<Type2>(), NULL);
    // type1 should never be NULL
    static void FindObjectsOfTypes(dynamic_array<Object*>& objects, const Unity::Type* type1, ...);

    virtual bool IsAScriptedObject() { return false; }

private:
    virtual const Unity::Type*const GetTypeVirtualInternal() const
    {
        AssertString("Object::GetTypeVirtualInternal called. GetTypeVirtualInternal should always be overriden in derived classes");
        return TypeOf<Object>();
    }

public:

    // Helper method to get the type name of the class
    const char* GetTypeName() const { return GetType()->GetName(); }

    // ----------------------------------------------------------------------------

#if !UNITY_RELEASE
    /// Use it to check AwakeFromLoad/AwakeFromLoadThreaded/Reset/SmartReset were correctly called
    void CheckCorrectAwakeUsage(bool mustHaveCalledAwake = true);

    //@{ Internal functions that are a part of our object system and used mostly in the Editor. Set debug flags in cases you REALLY know what you are doing.

    /// Call when you don't want to Reset in case of object fully inited and don't need to be reset to default state
    /// e.g. if you de-serialize object - you don't need reset
    inline void SetResetCalledInternal() { m_ResetCalled = 1; }

    /// Call when AwakeFromLoad has some side-effects so you need to postpone that call for indefinite time
    /// e.g. AudioClip will try to load sound in AwakeFromLoad, so you better do this only when needed.
    /// The use-case usually is you create an object and want to destroy it without complete awaking.
    inline void SetAwakeCalledInternal() { m_AwakeCalled = 1; }

    /// Same as AwakeFromLoadInternal but for Awake with kDidLoadThreaded param.
    inline void SetAwakeDidLoadThreadedCalledInternal() { m_AwakeDidLoadThreadedCalled = 1; }

    //@}
#else
    inline void SetResetCalledInternal() {}
    inline void SetAwakeCalledInternal() {}
    inline void SetAwakeDidLoadThreadedCalledInternal() {}
#endif

    /// Get and set the name
    virtual char const* GetName() const { return ""; }
    virtual void SetName(char const* /*name*/) {}
    void SetNameCpp(const core::string& name) { SetName(name.c_str()); }

#if UNITY_EDITOR
    /// Return true if you want the inspector to automatically refresh without SetDirty being called.
    virtual bool HasDebugmodeAutoRefreshInspector() { return false; }
    virtual void WarnInstantiateDisallowed() {}
#endif

private:

    static Object* Produce(const Unity::Type* targetCastType, const Unity::Type* produceType, InstanceID instanceID, MemLabelId memLabel, ObjectCreationMode mode);

public:

    static Object* Produce(const Unity::Type* type, InstanceID instanceID = InstanceID_None, MemLabelId memLabel = kMemBaseObject, ObjectCreationMode mode = kCreateObjectDefault)
    {
        return Produce(TypeOf<Object>(), type, instanceID, memLabel, mode);
    }

    template<typename T>
    static T* Produce(const Unity::Type* type, InstanceID instanceID = InstanceID_None, MemLabelId memLabel = kMemBaseObject, ObjectCreationMode mode = kCreateObjectDefault)
    {
        return static_cast<T*>(Produce(TypeOf<T>(), type, instanceID, memLabel, mode));
    }

    template<typename T>
    static T* Produce(InstanceID instanceID = InstanceID_None, MemLabelId memLabel = kMemBaseObject, ObjectCreationMode mode = kCreateObjectDefault)
    {
        return static_cast<T*>(Produce(TypeOf<T>(), TypeOf<T>(), instanceID, memLabel, mode));
    }

    // Static initialize and destroy for BaseObject
    static void StaticInitialize();
    static void StaticDestroy();

    /// Registers instance id with IDToPointerMap
    /// useful for thread loading with delayed activation from main thread
    /// Can only be called from main thead
    static void RegisterInstanceID(Object* obj);
    static void RegisterInstanceIDNoLock(Object* obj);

    /// Allocates new instanceID and registers it with IDToPointerMap
    /// Can only be called from main thead
    static Object* AllocateAndAssignInstanceID(Object* obj);
    static Object* AllocateAndAssignInstanceIDNoLock(Object* obj);

#if UNITY_EDITOR
    virtual void CloneAdditionalEditorProperties(const Object& /*source*/) {}

    /// Can assign variable allows you to do additional type checking when assigning a variable
    /// in the property inspector.
    /// E.g. MonoBehaviours checks if a monobehaviour can be assigned based on the actual Mono class
    virtual bool CanAssignMonoVariable(const char* /*property*/, Object* /*object*/) { return false; }
#endif

    virtual bool ShouldIgnoreInGarbageDependencyTracking()             { return false; }

    /// Gets the instance ID
    InstanceID  GetInstanceID() const                                  { Assert(m_InstanceID != InstanceID_None); return m_InstanceID; }
    bool        IsInstanceIDCreated() const                            { return m_InstanceID != InstanceID_None; }

#if UNITY_EDITOR
    /// Has this object been synced with the PersistentManager
    bool IsPersistentDirty() const                     { return m_DirtyIndex != 0; }

    void SetPersistentDirtyIndex(UInt32 dirtyIndex);
    UInt32 GetPersistentDirtyIndex() { return m_DirtyIndex; }

    /// @TODO: Rename this to SetPersistentDirty
    /// Whenever variables that are being serialized in Transfer change, SetDirty () should be called
    /// This will allow tracking of objects that have changed since the last saving to disk or over the network
    void SetDirty();

    /// This method can be called if you need to unload an object from memory even if it's dirty. Editor-only!
    void ClearPersistentDirty();

    // Callback support for callbacks when SetDirty is called
    typedef void ObjectDirtyCallbackFunction (Object * const * objectsToDirty, size_t count);
    static void RegisterDirtyCallback(ObjectDirtyCallbackFunction* callback);
    static ObjectDirtyCallbackFunction* GetDirtyCallback();
    static void BatchSetPersistentDirty(Object * const * objectsToDirty, size_t count);

    void SetFileIDHint(LocalIdentifierInFileType hint) { m_FileIDHint = hint; }
    LocalIdentifierInFileType GetFileIDHint() const { return m_FileIDHint; }

#else
    void SetDirty() {}
#endif

    enum HideFlags
    {
        kHideFlagsNone = 0,

        // The object will not appear in the hierarchy and will not show up in the project view if it is stored in an asset.
        kHideInHierarchy = 1 << 0,

        // The object will be hidden in the inspector
        kHideInspector = 1 << 1,

        // The object will not be saved when saving a scene in the editor
        kDontSaveInEditor = 1 << 2,

        // The object is not editable in the inspector
        kNotEditable = 1 << 3,

        // The object will not be saved when building a player
        kDontSaveInBuild = 1 << 4,

        // The object will not be unloaded by UnloadUnusedAssets
        kDontUnloadUnusedAsset = 1 << 5,

        // The object will not be destroyed by Destroy or DestroyImmediate
        kDontAllowDestruction = 1 << 6,

        // Cannot add flags without allocating bits and updating kHideFlagsBits.

        // Common mode that is used for objects that are "owned" by a manager and are not stored anywhere.
        kHideAndDontSave                    = kDontUnloadUnusedAsset | kHideInHierarchy | kNotEditable | kDontSaveInEditor | kDontSaveInBuild,

        // A common mode used by incremental baking processes, where the data should not be stored in the scene on disk
        // But should be included in a build.
        kHideAndDontSaveButIncludeInBuild   = kDontUnloadUnusedAsset | kHideInHierarchy | kNotEditable | kDontSaveInEditor
    };
    ENUM_FLAGS_AS_MEMBER(HideFlags);


    HideFlags GetHideFlags() const { return static_cast<HideFlags>(m_HideFlags); }
    bool TestHideFlag(HideFlags mask) const { return (m_HideFlags & mask) == mask; }
    bool TestHideFlagAny(HideFlags mask) const { return (m_HideFlags & mask) != 0; }

    virtual void SetHideFlags(HideFlags flags) { m_HideFlags = flags; }
    void SetHideFlagsObjectOnly(HideFlags flags) { m_HideFlags = flags; AssertMsg(GetHideFlags() == flags, "Hide flags could not be stored in allocated amount of bits."); }

    /// You must document all usage here in order to provide clear overview and avoid overlaps
    /// - Transform root calculation for animation component, when binding animation states (Runtime only)
    void SetTemporaryFlags(int flags) { Assert(flags < (1 << kTemporaryFlagsBits));  m_TemporaryFlags = flags; }
    int GetTemporaryFlags() const { return m_TemporaryFlags; }
#if ENABLE_DOTNET
    /// Used by WinRT's GarbageCollectSharedAssets
    void SetTemporaryUnusedAssetsFlags(int flags) { m_TemporaryUnusedAssetsFlags = flags; }
    int GetTemporaryUnusedAssetsFlags() const { return m_TemporaryUnusedAssetsFlags; }
#endif

    ScriptingGCHandle GetGCHandle() const { return m_MonoReference; }

    /// Overall memory allocated for this object. Should calculate any memory allocated by other subsystems as well.
    /// For example if OpenGL allocates memory for a texture it must return how much memory we "think" OpenGL will allocate for the texture.
    virtual size_t GetRuntimeMemorySize() const;

    /// Is this object persistent?
    bool IsPersistent() const { return m_IsPersistent; }

    typedef core::hash_map<InstanceID, Object*> IDToPointerMap;

    /// How many objects are there in memory?
    static IDToPointerMap::size_type GetLoadedObjectCount() { return ms_IDToPointer->size(); }

    // Finds the pointer to the object referenced by instanceID (NULL if none found in memory)
    static Object* IDToPointer(InstanceID inInstanceID);
    static Object* IDToPointerThreadSafe(InstanceID inInstanceID);

    /// This function may not be called unless you use LockObjectCreation / UnlockObjectCreation from another thread first...
    /// If you don't know 100% what you are doing use: IDToPointerThreadSafe instead
    static Object* IDToPointerNoThreadCheck(InstanceID inInstanceID);

    /// Callback support for callbacks when an object is destroyed
    typedef void ObjectDestroyCallbackFunction (InstanceID instanceID);
    static void RegisterDestroyedCallback(ObjectDestroyCallbackFunction* callback);

    /// Checks if an array of instance id's are loaded.
    /// If an instanceID is loaded it is set to 0.
    static void CheckInstanceIDsLoaded(InstanceID* instanceIDs, int size);

#if ENABLE_MEM_PROFILER
    MemLabelId GetMemoryLabel() const { return m_FullMemoryLabel; }
#else
    MemLabelId GetMemoryLabel() const { return CreateMemLabel((MemLabelIdentifier)m_MemLabelIdentifier); }
#endif

    static IDToPointerMap& GetIDToPointerMapInternal() { return *ms_IDToPointer; }

    void PreCleanupObject();

    // Generic Event callback support.
    typedef void EventCallback (void* userData, void* sender, int eventType);

    void AddEvent(EventCallback* callback, void* userData);
    void RemoveEvent(EventCallback* callback, void* userData);
    bool HasEvent(EventCallback* callback, const void* userData) const;
    void InvokeEvent(int eventType);


    static int GetOffsetOfInstanceIdMember();

private:
    static  IDToPointerMap* ms_IDToPointer;

    InstanceID              m_InstanceID;

    enum Bits
    {
        kMemLabelBits = 12,         // 12
        kTemporaryFlagsBits = 1,    // 13
        kHideFlagsBits = 7,         // 20
        kIsPersistentBits = 1,      // 21
        kCachedTypeIndexBits = 11   // 32
    };

    static const UInt32 INVALID_CACHED_TYPEINDEX = (1 << kCachedTypeIndexBits) - 1;

    UInt32                m_MemLabelIdentifier : kMemLabelBits;
    UInt32                m_TemporaryFlags    : kTemporaryFlagsBits;
    UInt32                m_HideFlags         : kHideFlagsBits;
    UInt32                m_IsPersistent      : kIsPersistentBits;
    UInt32                m_CachedTypeIndex   : kCachedTypeIndexBits;

    EventEntry*           m_EventIndex;
#if ENABLE_MEM_PROFILER
    MemLabelId            m_FullMemoryLabel;
#endif

#if !UNITY_RELEASE
    PersistentTypeID      m_DEBUGPersistentTypeID;
    UInt32                m_AwakeCalled : 1;
    UInt32                m_ResetCalled : 1;
    UInt32                m_AwakeThreadedCalled : 1;
    UInt32                m_AwakeDidLoadThreadedCalled : 1;
    UInt32                m_MainThreadCleanupCalled : 1;
#endif

    ScriptingGCHandle     m_MonoReference;

#if ENABLE_DOTNET
    UInt32                m_TemporaryUnusedAssetsFlags;
#endif

#if UNITY_EDITOR
    UInt32                    m_DirtyIndex;
    LocalIdentifierInFileType m_FileIDHint;
#endif

public:
    void SetupWeakHandle();
    bool RevertWeakHandle();

    virtual void SetCachedScriptingObject(ScriptingObjectPtr cachedPointer);
    ScriptingObjectPtr GetCachedScriptingObject() const { return m_MonoReference.Resolve(); }

#if ENABLE_PROFILER
    int m_ObjectProfilerListIndex;
#endif

    static Object* CalculateCachedTypeIndex(Object* obj);

private:

    static void InsertObjectInMap(Object* obj);

    void SetIsPersistent(bool p);

    void SetInstanceID(InstanceID inID)                { m_InstanceID = inID; }

protected:

    template<class TransferFunction>
    void Transfer(TransferFunction& transfer);

public:

    /// Returns whether or not the class needs one typetree per object, not per persistentTypeID
    /// Having a per object typetree makes serialization considerably slower because safeBinaryTransfer is always used
    /// Since no TypeTree can be generated before reading the object.
    /// The File size will also increase because the typetree is not shared among the same classes.
    /// It is used for example in PythonBehaviour
    /// Also for one class you have to always returns true or always false.
    virtual bool GetNeedsPerObjectTypeTree() const { return false; }

    // Required by serialization
    virtual void VirtualRedirectTransfer(StreamedBinaryWrite<false>&)  { AssertString(Format("Serialization not implemented for type %s", GetTypeName())); }
    virtual void VirtualRedirectTransfer(StreamedBinaryRead<false>&)   { AssertString(Format("Serialization not implemented for type %s", GetTypeName())); }
    virtual void VirtualRedirectTransfer(RemapPPtrTransfer&)           { AssertString(Format("Serialization not implemented for type %s", GetTypeName())); }
    virtual void VirtualRedirectTransfer(GenerateTypeTreeTransfer&)    { AssertString(Format("Serialization not implemented for type %s", GetTypeName())); }
#if SUPPORT_SERIALIZED_TYPETREES
    virtual void VirtualRedirectTransfer(StreamedBinaryRead<true>&) { AssertString(Format("Serialization not implemented for type %s", GetTypeName())); }
    virtual void VirtualRedirectTransfer(SafeBinaryRead&)      { AssertString(Format("Serialization not implemented for type %s", GetTypeName())); }
    virtual void VirtualRedirectTransfer(StreamedBinaryWrite<true>&) { AssertString(Format("Serialization not implemented for type %s", GetTypeName())); }
#if UNITY_EDITOR
    virtual void VirtualStrippedRedirectTransfer(SafeBinaryRead& t) { VirtualRedirectTransfer(t); }
#endif //  UNITY_EDITOR
#endif
#if SUPPORT_TEXT_SERIALIZATION
    virtual void VirtualRedirectTransfer(YAMLRead&)    { AssertString(Format("Serialization not implemented for type %s", GetTypeName())); }
    virtual void VirtualRedirectTransfer(YAMLWrite&)   { AssertString(Format("Serialization not implemented for type %s", GetTypeName())); }
    virtual void VirtualStrippedRedirectTransfer(YAMLRead& t) { VirtualRedirectTransfer(t); }
    virtual void VirtualStrippedRedirectTransfer(YAMLWrite& t) { VirtualRedirectTransfer(t); }
#endif
#if UNITY_EDITOR
    virtual void VirtualRedirectTransfer(JSONRead&)    { AssertString(Format("Serialization not implemented for type %s", GetTypeName())); }
    virtual void VirtualRedirectTransfer(JSONWrite&)   { AssertString(Format("Serialization not implemented for type %s", GetTypeName())); }
    virtual void VirtualStrippedRedirectTransfer(JSONRead& t) { VirtualRedirectTransfer(t); }
    virtual void VirtualStrippedRedirectTransfer(JSONWrite& t) { VirtualRedirectTransfer(t); }

    virtual void VirtualStrippedRedirectTransfer(StreamedBinaryRead<false>& t) { VirtualRedirectTransfer(t); }
    virtual void VirtualStrippedRedirectTransfer(StreamedBinaryRead<true>& t) { VirtualRedirectTransfer(t); }
    virtual void VirtualStrippedRedirectTransfer(StreamedBinaryWrite<false>& t) { VirtualRedirectTransfer(t); }
    virtual void VirtualStrippedRedirectTransfer(StreamedBinaryWrite<true>& t) { VirtualRedirectTransfer(t); }
    virtual void VirtualStrippedRedirectTransfer(GenerateTypeTreeTransfer& t) { VirtualRedirectTransfer(t); }
#endif

    static const char* GetClassStringStatic() { return CommonString(Object); }
    static const char* GetPPtrTypeString() { return CommonString(PPtr_Object); }

    friend class PersistentManager;
    friend class SerializedFile;
};
BIND_MANAGED_TYPE_NAME(Object, UnityEngine_Object);

struct LocalSerializedObjectIdentifier
{
    SInt32 localSerializedFileIndex;
    LocalIdentifierInFileType localIdentifierInFile;

    LocalSerializedObjectIdentifier()
    {
        localIdentifierInFile = 0;
        localSerializedFileIndex = 0;
    }

    friend bool operator<(const LocalSerializedObjectIdentifier& lhs, const LocalSerializedObjectIdentifier& rhs)
    {
        if (lhs.localSerializedFileIndex != rhs.localSerializedFileIndex)
            return lhs.localSerializedFileIndex < rhs.localSerializedFileIndex;
        else
            return lhs.localIdentifierInFile < rhs.localIdentifierInFile;
    }

    friend bool operator==(const LocalSerializedObjectIdentifier& lhs, const LocalSerializedObjectIdentifier& rhs)
    {
        return lhs.localIdentifierInFile == rhs.localIdentifierInFile && lhs.localSerializedFileIndex == rhs.localSerializedFileIndex;
    }
};

typedef void InstanceIDResolveCallback (InstanceID id, LocalSerializedObjectIdentifier& localIdentifier, void* context);
void SetInstanceIDResolveCallback(InstanceIDResolveCallback* callback, const void* context = NULL);

// Global helpers to retrieve instance IDs - see InstanceID.h for details
inline InstanceID GetInstanceIDFrom(const Object* object) { return object != NULL ? object->GetInstanceID() : InstanceID_None; }
inline InstanceID GetInstanceIDFrom(const Object& object) { return object.GetInstanceID(); }

void EXPORT_COREMODULE InstanceIDToLocalSerializedObjectIdentifier(InstanceID id, LocalSerializedObjectIdentifier& localIdentifier);
void EXPORT_COREMODULE LocalSerializedObjectIdentifierToInstanceID(const LocalSerializedObjectIdentifier& fileID, InstanceID& memoryID);
EXPORT_COREMODULE Object* ReadObjectFromPersistentManager(InstanceID instanceID);
Object* PreallocateObjectFromPersistentManager(InstanceID instanceID, bool threadedLoading);

#if THREADED_LOADING
EXPORT_COREMODULE Object* InstanceIDToObjectPartiallyLoadedThreadSafe(InstanceID instanceID, bool isLoadingThread);
#else
#define InstanceIDToObjectPartiallyLoadedThreadSafe(X, Y) PPtr<Object> (X)
#endif

#include "PPtr.h"

enum ExecutionRestrictions
{
    kNoRestriction                  = 0,
    kDisableImmediateDestruction    = 1 << 0,
    kDisableSendMessage             = 1 << 2,
};
ENUM_FLAGS(ExecutionRestrictions);

ExecutionRestrictions EXPORT_COREMODULE GetExecutionRestrictions();
ExecutionRestrictions EXPORT_COREMODULE SetExecutionRestrictions(ExecutionRestrictions desiredRestrictions);

FORCE_INLINE bool GetDisableImmediateDestruction() { return (GetExecutionRestrictions() & kDisableImmediateDestruction) != 0; }
FORCE_INLINE bool GetDisableSendMessage() { return (GetExecutionRestrictions() & kDisableSendMessage) != 0; }

class AutoExecutionRestriction
{
public:
    AutoExecutionRestriction(ExecutionRestrictions desiredRestrictions)
        : m_PreviousRestrictions(SetExecutionRestrictions(GetExecutionRestrictions() | desiredRestrictions))
#if !UNITY_RELEASE
        , m_DesiredRestrictions(desiredRestrictions)
#endif
    {
    }

    ~AutoExecutionRestriction()
    {
#if !UNITY_RELEASE
        AssertMsg((m_PreviousRestrictions | m_DesiredRestrictions) == GetExecutionRestrictions(), "ExecutionRestriction has been changed while an AutoExecutionRestriction was active. This might cause unepxected behaviour.");
#endif
        SetExecutionRestrictions(m_PreviousRestrictions);
    }

private:
    ExecutionRestrictions m_PreviousRestrictions;
#if !UNITY_RELEASE
    ExecutionRestrictions m_DesiredRestrictions;
#endif
};

/// Returns if the object can possibly be loaded or is already in memory, without actually performing the loading.
bool IsObjectAvailable(InstanceID instanceID);

InstanceID AllocateNextLowestInstanceID();

/// Lock elements from being added from other threads to global objects map.
void LockObjectCreation();
void UnlockObjectCreation();

//Implementation
FORCE_INLINE Object* Object::IDToPointer(InstanceID instanceID)
{
#if THREADED_LOADING
    DebugAssert(Thread::CurrentThreadIsMainThread());
#endif
    return IDToPointerNoThreadCheck(instanceID);
}

FORCE_INLINE Object* Object::IDToPointerThreadSafe(InstanceID instanceID)
{
    LockObjectCreation();
    Object* obj = IDToPointerNoThreadCheck(instanceID);
    UnlockObjectCreation();
    return obj;
}

FORCE_INLINE Object* Object::IDToPointerNoThreadCheck(InstanceID instanceID)
{
    //@TODO: Assert against this...
    //@TODO: handle 0 case specifically?
    if (!ms_IDToPointer)
        return NULL;

    IDToPointerMap::const_iterator i = ms_IDToPointer->find(instanceID);
    if (i != ms_IDToPointer->end())
        return i->second;

    return NULL;
}

// Destroys a Object removing from memory and disk when needed.
// Might load the object as part of destruction which is probably unwanted.
// @TODO: Refactor code to not do that
void EXPORT_COREMODULE DestroySingleObject(Object* o);
void UnloadObject(Object* o);

/// Destroys the object if it is loaded. (Will not load the object from disk if it is not loaded at the moment)
/// Will remove it from any remapping tables
/// Will not removed it from the actual serialized file, with the assumption that the file will be unloaded from disk later.
void DestroyWithoutLoadingButDontDestroyFromFile(InstanceID instanceID, bool removeFromPersistentManager);

/// Helper to create object correctly from code. Will call Reset and AwakeFromLoad
template<typename T> T* CreateObjectFromCode(AwakeFromLoadMode awakeMode = kInstantiateOrCreateFromCodeAwakeFromLoad, MemLabelId label = kMemBaseObject)
{
    Assert(TypeOf<T>()->HasValidRuntimeTypeIndex());
    T* obj = NEW_OBJECT_USING_MEMLABEL(T, label);
    SET_ALLOC_OWNER(obj->GetMemoryLabel());
    obj->Reset();
    obj->AwakeFromLoad(awakeMode);
    return obj;
}

template<typename T>
inline T* ResetAndAwake(T* object)
{
    object->Reset();
    object->AwakeFromLoad(kDefaultAwakeFromLoad);
    return object;
}

void delete_object_internal(Object* p);
void delete_object_internal_step1(Object* object);
void delete_object_internal_step2(Object* object);
