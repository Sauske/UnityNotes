#include "UnityPrefix.h"
#include "Runtime/Testing/Faking.h"
#include "AttributeContainer.h"
#include "TypeManager.h"

#if ENABLE_UNIT_TESTS
#include <ostream>
#endif

RTTI::RuntimeTypeArray RTTI::ms_runtimeTypes;

detail::AttributeMapEntry* detail::AttributeMapEntry::s_head = NULL;

core::string RTTI::GetFullName() const
{
    if (classNamespace && *classNamespace)
    {
        core::string fullName;
        fullName += classNamespace;
        fullName += "::";
        fullName += className;
        return fullName;
    }

    return className;
}

#if ENABLE_UNIT_TESTS

RTTI::RuntimeTypeArray& RTTI::GetRuntimeTypes()
{
#   if ENABLE_UNIT_TESTS_WITH_FAKES
    __FAKEABLE_STATIC_METHOD__(RTTI, GetRuntimeTypes, ());
#   endif
    return GetRuntimeTypes_Unfaked();
}

#endif

namespace Unity
{
    const Type* Type::FindTypeByName(const char* name, CaseSensitivityOptions options)
    {
        return reinterpret_cast<const Type*>(TypeManager::Get().ClassNameToRTTI(name, options == kCaseInSensitive));
    }

    const Type* Type::FindTypeByPersistentTypeID(PersistentTypeID id)
    {
        return reinterpret_cast<const Type*>(TypeManager::Get().PersistentTypeIDToRTTI(id));
    }

    const Type* Type::GetDeserializationStubForPersistentTypeID(PersistentTypeID id)
    {
        return reinterpret_cast<const Type*>(TypeManager::Get().GetDeserializationRTTIStubForPersistentTypeID(id));
    }

    void Type::FindAllDerivedClasses(dynamic_array<const Type*>& result, TypeFilterOptions options) const
    {
        TypeManager::Get().FindAllRTTIDerivedTypes(&m_internal, reinterpret_cast<dynamic_array<const RTTI*>&>(result), options == kOnlyNonAbstract);
    }

    void Type::GetAttributes(TypeAttributes& result) const
    {
        result = TypeAttributes(this, GetAttributeCount());
    }

#if ENABLE_UNIT_TESTS
    std::ostream& operator<<(std::ostream& stream, const Type* type)
    {
        return (stream << (type ? type->GetFullName() : "<null type>"));
    }

#endif
}
