#include "UnityPrefix.h"
#include "AttributeContainer.h"

namespace Unity
{
    const ConstVariantRef& TypeAttributesIterator::GetCurrent() const
    {
        return m_Type->GetAttribute(m_CurrentAttributeIndex);
    }
} // end namespace Unity
