#include "UnityPrefix.h"
#include "GameObject.h"
#include "Runtime/Serialize/AwakeFromLoadQueue.h"
#include "TagManager.h"
#include "Runtime/Misc/BuildSettings.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/Misc/ComponentRequirement.h"
#include "Runtime/Mono/MonoBehaviour.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Transform/TransformHierarchyTypes.h"
#include "Runtime/Transform/RectTransform.h"
#include "Runtime/SceneManager/UnityScene.h"
#include "MessageHandler.h"
#include "Runtime/Animation/MecanimUtility.h"
#include "Runtime/Testing/Faking.h"

#if UNITY_EDITOR
#include "Runtime/Graphics/Texture2D.h"
#include "Editor/Src/Application/Application.h"
#include "Editor/Src/BuildPipeline/BuildTargetPlatformSpecific.h"
#include "Editor/Src/BuildPipeline/ModuleMetadata.h"
#include "Editor/Src/Utility/DelayedCleanupManager.h"
#include "Editor/Src/Prefabs/Prefab.h"
#include "Editor/Src/Utility/StaticEditorFlags.h"
#include "Editor/Src/Undo/Undo.h"
#endif

void MergeTransformComponents(Transform& source, Transform& target, bool mergeTRS);

PROFILER_INFORMATION(gActivateGameObjectProfiler, "GameObject.Activate", kProfilerScripts)
PROFILER_INFORMATION(gDeactivateGameObjectProfiler, "GameObject.Deactivate", kProfilerScripts)

DEFINE_MESSAGE_IDENTIFIER(kLayerChanged, ("OnLayersChanged", MessageIdentifier::kDontSendToScripts));
DEFINE_MESSAGE_IDENTIFIER(kCullSceneChanged, ("OnCullSceneChanged", MessageIdentifier::kDontSendToScripts));
DEFINE_MESSAGE_IDENTIFIER(kDidAddComponent, ("OnDidAddComponent", MessageIdentifier::kDontSendToScripts, TypeOf<Unity::Component>()));
DEFINE_MESSAGE_IDENTIFIER(kDidRemoveComponent, ("OnDidRemoveComponent", MessageIdentifier::kDontSendToScripts, TypeOf<Unity::Component>()));

GameObject::DestroyGOCallbackFunction* GameObject::s_GameObjectDestroyedCallback = NULL;
GameObject::SetGONameFunction* GameObject::s_SetGONameCallback = NULL;

GameObject::GameObject(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode),
    m_Component(label),
    m_ActiveGONode(this)
{
    m_SupportedMessages = 0;
    m_ActivationState = kNotActivating;
    m_Tag = 0;
    m_IsActive = false;
    m_IsActiveCached = -1;
    m_CullSceneMask = kDefaultSceneCullingMask;

    #if UNITY_EDITOR
    m_IsOldVersion = false;
    m_StaticEditorFlags = 0;
    m_MarkedVisible = kSelfVisible;
    #endif
}

void GameObject::Reset()
{
    Super::Reset();
    m_Layer = kDefaultLayer;
    m_Tag = 0;
    m_CullSceneMask = kDefaultSceneCullingMask;
    #if UNITY_EDITOR
    m_StaticEditorFlags = 0;
    m_TagString = GetTagManager().TagToString(m_Tag);
    m_NavMeshLayer = 0;
    #endif
}

void GameObject::ThreadedCleanup()
{
}

void GameObject::WillDestroyGameObject()
{
    Assert(!IsDestroying());
    m_ActivationState = kDestroying;

    // Find a component with the requested ID
    Container::const_iterator i;
    Container::const_iterator end = m_Component.end();
    for (i = m_Component.begin(); i != end; ++i)
    {
        Unity::Component& com = *i->GetComponentPtr();
        com.WillDestroyComponent();
    }
}

void GameObject::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);

    if (awakeMode == kPersistentManagerAwakeFromLoadMode)
    {
        // Clear cached active state, as we may have called IsActive()
        // during the PersistentManager load
        m_IsActiveCached = -1;
    }

    SetSupportedMessagesDirty();
    UpdateActiveGONode();

    if (s_SetGONameCallback)
        s_SetGONameCallback(this);

    #if UNITY_EDITOR
    // When we are modifying the game object active state from the inspector
    // We need to Activate / Deactivate the relevant components
    // This never happens in the player.
    if (awakeMode == kDefaultAwakeFromLoad)
        ActivateAwakeRecursively();
    #endif
}

void GameObject::SetName(char const* name)
{
    m_Name.assign(name, GetMemoryLabel());
    if (s_SetGONameCallback)
        s_SetGONameCallback(this);
    SetDirty();
}

void GameObject::UpdateActiveGONode()
{
    m_ActiveGONode.RemoveFromList();
    if (IsActive())
    {
        if (m_Tag != 0)
            GetGameObjectManager().m_TaggedNodes.push_back(m_ActiveGONode);
        else
            GetGameObjectManager().m_ActiveNodes.push_back(m_ActiveGONode);
    }
}

void GameObject::MarkActiveRecursively(bool state)
{
    Transform &transform = GetComponent<Transform>();
    for (Transform::iterator i = transform.begin(); i != transform.end(); i++)
        (*i)->GetGameObject().MarkActiveRecursively(state);

    m_IsActive = state;
    SetDirty();
}

void GameObject::ActivateAwakeRecursivelyInternal(DeactivateOperation deactivateOperation, AwakeFromLoadQueue &queue)
{
    if (IsActivating())
    {
        ErrorStringObject("GameObject is already being activated or deactivated.", this);
        return;
    }
    bool state;
    bool changed;
    if (m_IsActiveCached != -1)
    {
        bool oldState = m_IsActiveCached;
        m_IsActiveCached = -1;
        state = IsActive();
        changed = oldState != state;
    }
    else
    {
        state = IsActive();
        changed = true;
    }

    m_ActivationState = state ? kActivatingChildren : kDeactivatingChildren;

    Transform *transform = QueryComponent<Transform>();
    if (transform)
    {
        // use a loop by index rather than a iterator, as the children can adjust
        // the child list during the Awake call, and invalidate the iterator
        for (int i = 0; i < transform->GetChildrenCount(); i++)
            transform->GetChild(i).GetGameObject().ActivateAwakeRecursivelyInternal(deactivateOperation, queue);
    }

    if (changed)
    {
        m_ActivationState = state ? kActivatingComponents : kDeactivatingComponents;
        for (size_t i = 0; i < m_Component.size(); i++)
        {
            Unity::Component& component = *m_Component[i].GetComponentPtr();
            if (state)
            {
                Assert(&*component.m_GameObject == this);
                component.SetGameObjectInternal(this);
                queue.Add(*m_Component[i].GetComponentPtr());
            }
            else
                component.Deactivate(deactivateOperation);
        }

        if (state)
            UpdateActiveGONode();
        else
            m_ActiveGONode.RemoveFromList();
    }
    m_ActivationState = kNotActivating;
}

void GameObject::ActivateAwakeRecursively(DeactivateOperation deactivateOperation)
{
    AwakeFromLoadQueue queue(kMemTempAlloc);
    ActivateAwakeRecursivelyInternal(deactivateOperation, queue);
    queue.AwakeFromLoad(kActivateAwakeFromLoad);
}

void GameObject::SetActiveRecursivelyDeprecated(bool state)
{
    if (IsPrefabParent())
    {
        ErrorString(Format("Prefab GameObject's can not be made active! (%s)", GetName()));
        return;
    }

    // First Mark all objects as active
    MarkActiveRecursively(state);

    // Then awake them.
    ActivateAwakeRecursively();
}

void GameObject::ComponentPair::SetComponentPtr(Unity::Component* const ptr)
{
    if (ptr != NULL)
    {
        component = ptr;
        typeIndex = ptr->GetType()->GetRuntimeTypeIndex();
        return;
    }

    component = NULL;
    typeIndex = RTTI::DefaultTypeIndex;
}

void GameObject::FinalizeAddComponentInternal(Unity::Component* com)
{
    // Make sure it isn't already added to another GO
    Assert(com->m_GameObject.GetInstanceID() == InstanceID_None || com->GetGameObjectPtr() == this);

    com->m_GameObject = this;
    com->SetHideFlags(GetHideFlags());

    SetSupportedMessagesDirty();

    if (IsActive())
        com->AwakeFromLoad(kActivateAwakeFromLoad);
    else
        com->AwakeFromLoad(kDefaultAwakeFromLoad);

    com->SetDirty();
    SetDirty();
}

void GameObject::AddComponentInternal(Unity::Component* com)
{
    Assert(com != NULL);
    m_Component.push_back(ComponentPair::FromComponent(com));
    FinalizeAddComponentInternal(com);
}

Unity::Component* GameObject::QueryComponentByType(const Unity::Type* type) const
{
    // Find a component with the requested ID
    Container::const_iterator i;
    Container::const_iterator end = m_Component.end();
    for (i = m_Component.begin(); i != end; ++i)
    {
        if (type->IsBaseOf(i->GetTypeIndex()))
            return i->GetComponentPtr();
    }

    return NULL;
}

Unity::Component* GameObject::QueryComponentByExactType(const Unity::Type* type) const
{
    // Find a component with the requested ID
    Container::const_iterator i;
    Container::const_iterator end = m_Component.end();
    RuntimeTypeIndex index = type->GetRuntimeTypeIndex();
    for (i = m_Component.begin(); i != end; ++i)
    {
        if (i->GetTypeIndex() == index)
            return i->GetComponentPtr();
    }

    return NULL;
}

void GameObject::RemoveComponentAtIndex(int index)
{
    Container::iterator i = m_Component.begin() + index;

    Unity::Component* com = i->GetComponentPtr();
    Assert(com != NULL);

    m_Component.erase(i);
    com->m_GameObject = NULL;

    com->SetDirty();
    SetDirty();

    SendMessage(kDidRemoveComponent, com);

    SetSupportedMessagesDirty();
}

void GameObject::SetComponentAtIndexInternal(PPtr<Unity::Component> component, int index)
{
    m_Component[index] = ComponentPair::FromComponent(component);
}

void GameObject::SetSupportedMessagesDirty()
{
    Assert(!IsDestroying());

    MessageIdentifier::OptimizedMessageMask oldSupportedMessage = m_SupportedMessages;
    m_SupportedMessages = 0;
    if (IsDestroying())
        return;

    GetSupportedMessagesRecalculate();
    if (oldSupportedMessage != m_SupportedMessages)
    {
        for (Container::iterator i = m_Component.begin(); i != m_Component.end(); ++i)
            if (i->GetComponentPtr())
                i->GetComponentPtr()->SupportedMessagesDidChange(m_SupportedMessages);
    }
}

void GameObject::GetSupportedMessagesRecalculate()
{
    Assert(!IsDestroying());

    m_SupportedMessages = 0;
    for (Container::iterator i = m_Component.begin(); i != m_Component.end(); ++i)
        if (i->GetComponentPtr())
            m_SupportedMessages |= i->GetComponentPtr()->CalculateSupportedMessages();
}

void GameObject::InvalidateSupportedMessages()
{
    m_SupportedMessages = 0;
}

Unity::Component* GameObject::GetComponentPtrAtIndex(int i) const
{
    return m_Component[i].GetComponentPtr();
}

int GameObject::GetComponentIndex(Unity::Component *component)
{
    Assert(!IsDestroying());

    for (int i = 0; i < GetComponentCount(); i++)
    {
        if (&GetComponentAtIndex(i) == component)
            return i;
    }

    return -1;
}

void GameObject::SwapComponents(int index1, int index2)
{
    Assert(index1 <= (int)m_Component.size() && index1 >= 0);
    Assert(index2 <= (int)m_Component.size() && index2 >= 0);

    ComponentPair tmp = m_Component[index1];
    m_Component[index1] = m_Component[index2];
    m_Component[index2] = tmp;

    Unity::Component* comp1 = m_Component[index1].GetComponentPtr();
    Unity::Component* comp2 = m_Component[index2].GetComponentPtr();
    if (comp1 && comp1->Is<Behaviour>())
    {
        Behaviour* beh = static_cast<Behaviour*>(comp1);
        if (beh->GetEnabled())
        {
            beh->SetEnabled(false);
            beh->SetEnabled(true);
        }
    }
    if (comp2 && comp2->Is<Behaviour>())
    {
        Behaviour* beh = static_cast<Behaviour*>(comp2);
        if (beh->GetEnabled())
        {
            beh->SetEnabled(false);
            beh->SetEnabled(true);
        }
    }
    SetDirty();
}

bool GameObject::IsActive() const
{
    if (m_IsActiveCached != -1)
        return m_IsActiveCached;

    // Calculate active state based on the hierarchy
    m_IsActiveCached = m_IsActive && !(IsPersistent() || IsPrefabParent());
    Transform *trs = QueryComponent<Transform>();
    if (trs)
    {
        Transform *parent = trs->GetParent();
        if (parent && parent->GetGameObjectPtr())
        {
            m_IsActiveCached = m_IsActiveCached && parent->GetGameObjectPtr()->IsActive();
        }
    }

    return m_IsActiveCached;
}

bool GameObject::IsActiveIgnoreImplicitPrefab()
{
    Transform *trs = QueryComponent<Transform>();
    if (trs)
    {
        Transform *parent = GetComponent<Transform>().GetParent();
        if (parent)
            return m_IsActive && parent->GetGameObject().IsActiveIgnoreImplicitPrefab();
    }

    return m_IsActive;
}

void GameObject::Activate()
{
    if (IsActive())
        return;

    PROFILER_AUTO(gActivateGameObjectProfiler, this);

    if (IsDestroying())
    {
        ErrorStringObject("GameObjects can not be made active when they are being destroyed.", this);
        return;
    }

    SetDirty();

    ActivateInternal();
    ActivateAwakeRecursively();
    // After AwakeFromLoad, 'this' could have been destroyed (if user is Destroying in OnEnable or Awake)
    // So do not access it any further
}

void GameObject::Deactivate(DeactivateOperation operation)
{
    PROFILER_AUTO(gDeactivateGameObjectProfiler, this)

    if (!IsActive())
    {
        if (m_IsActive)
        {
            m_IsActive = false;
            SetDirty();
        }
        return;
    }

    m_IsActive = false;

    ActivateAwakeRecursively(operation);

    SetDirty();
}

void GameObject::SetSelfActive(bool state)
{
    if (state)
        Activate();
    else
        Deactivate(kNormalDeactivate);
}

void GameObject::AddComponentInternal(GameObject& gameObject, Unity::Component& clone)
{
    Assert(clone.m_GameObject == NULL);
    gameObject.m_Component.push_back(ComponentPair::FromComponent(&clone));
    clone.m_GameObject = &gameObject;
}

void GameObject::RemoveComponentFromGameObjectInternal(Unity::Component& clone)
{
    GameObject* go = clone.GetGameObjectPtr();
    if (go == NULL)
        return;

    int index = go->GetComponentIndex(&clone);
    if (index == -1)
        return;

    go->m_Component.erase(go->m_Component.begin() + index);
    clone.m_GameObject = NULL;
}

static void DestroyComponentDuringConsistencyCheck(Unity::Component* component)
{
    Assert(component != NULL);

#if UNITY_EDITOR
    if (IsPrefabInstanceOrDisconnectedInstance(component))
        DisconnectPrefabInstance(component);
#endif

    // Destroy the object but not before we force (fake) flagging that it was correctly awoken which of course it hasn't yet.
    component->SetAwakeCalledInternal();
    component->SetAwakeDidLoadThreadedCalledInternal();
    DestroySingleObject(component);
}

void GameObject::AddFirstTransformComponentInternal(Transform* newTransform)
{
    // Add transform as first component.
    Assert(newTransform != NULL);
    Assert(QueryComponent<Transform>() == NULL);
    m_Component.insert(m_Component.begin(), ComponentPair::FromComponent(newTransform));
    FinalizeAddComponentInternal(newTransform);
}

void GameObject::ReplaceTransformComponentInternal(Transform* newTransform)
{
    Assert(newTransform != NULL);
    Assert(newTransform->GetParentPtrInternal() == NULL);
    Assert(newTransform->GetChildrenCount() == 0);

    Transform* oldTransform = QueryComponentAtIndex<Transform>(0);
    oldTransform->EnsureTransformHierarchyExists();

#if UNITY_EDITOR
    // Transfer root order.
    newTransform->SetRootOrder(oldTransform->GetRootOrder());
#endif

    // Remove the old transform from its parent.
    Transform* parent = oldTransform->GetParent();
    if (parent != NULL)
    {
        // Replace old transform with new transform in parent's list of children
        Transform::iterator i = parent->Find(oldTransform);
        *i = newTransform;
        newTransform->SetParentPtrInternal(parent);
        oldTransform->SetParentPtrInternal(NULL);
    }
    else
    {
        // Ensure new transform has the same scene as old transform
        UnityScene* scene = oldTransform->GetScene();
        if (scene != NULL)
        {
            UnityScene::RemoveRootFromScene(*oldTransform, true);
            UnityScene::AddRootToScene(*scene, *newTransform);
        }
    }

    // Move the source children so they are children of the target instead.
    newTransform->GetChildrenInternal().swap(oldTransform->GetChildrenInternal());
    Transform::TransformComList& children = newTransform->GetChildrenInternal();
    for (int index = 0; index < children.size(); ++index)
        children[index]->SetParentPtrInternal(newTransform);

    // Update TransformHierarchy with new transform
    TransformAccess access = oldTransform->GetTransformAccess();
    access.hierarchy->mainThreadOnlyTransformPointers[access.index] = newTransform;
    newTransform->m_TransformData = access;
    m_Component[0] = ComponentPair::FromComponent(newTransform);
    oldTransform->m_GameObject = NULL;
    oldTransform->m_TransformData.hierarchy = NULL;
    newTransform->RegisterChangeSystemInterests();

    // Ensure new transform's properties match the TransformHierarchy's values
    newTransform->ApplyRuntimeToSerializedData();
    if (newTransform->GetType() == TypeOf<UI::RectTransform>())
    {
        const Vector3f localPosition = newTransform->GetLocalPosition();
        Vector2f anchoredPosition(localPosition.x, localPosition.y);
        static_cast<UI::RectTransform*>(newTransform)->SetAnchoredPositionWithoutNotification(anchoredPosition);
    }

    FinalizeAddComponentInternal(newTransform);

    DestroyComponentDuringConsistencyCheck(oldTransform);

#if !UNITY_RELEASE
    newTransform->GetRoot().ValidateHierarchy(*newTransform->GetTransformAccess().hierarchy);
#endif
}

bool GameObject::EnsureUniqueTransform()
{
    // Make sure we always have at least one (primary) transform on a gameobject.
    Transform* primaryTransform = NULL;
    size_t primaryIndex = 0;
    bool transformMerged = false;
    int foundTransformComponents = 0;

    // Check all components.
    for (size_t index = 0; index < GetComponentCount(); ++index)
    {
        // Fetch the component.
        Unity::Component* com = GetComponentPtrAtIndex(index);

        // Ignore if this isn't a transform.
        if (com == NULL || !com->Is<Transform>())
            continue;

        // Fetch the transform.
        Transform* sourceTransform = static_cast<Transform*>(com);
        ++foundTransformComponents;

        // If we don't yet have a primary transform then note it and continue searching.
        if (primaryTransform == NULL)
        {
            primaryTransform = sourceTransform;
            primaryIndex = index;
            continue;
        }

        // We have found more than one transform at this point.
        // For prefabs (persistent), touching the transform hierarchy will lead to all kinds of troubles depending on where we're calling this from.
        if (IsPersistent())
            return false;

        // For scene objects (transient), the first RectTransform found has the priority here and the first base Transform found
        // will be merged into it.  Any subsequent RectTransform or base Transform will simply be removed.

        // Fetch the transform types.
        const Unity::Type* primaryType = primaryTransform->GetType();
        const Unity::Type* sourceType = sourceTransform->GetType();

        // Have we already performed a transform merge or we've got a duplicate transform type?
        if (transformMerged || sourceType == primaryType)
        {
            // Merge the source into the primary but don't merge transform state.
            MergeTransformComponents(*sourceTransform, *primaryTransform, false);

            // Remove the source component.
            RemoveComponentAtIndex(index--);

            // Destroy the component.
            DestroyComponentDuringConsistencyCheck(sourceTransform);

            continue;
        }

        // At this point we know we have different transforms and that we want to merge them whilst destroying one.
        // We just need to ensure we merge the base Transform into the RectTransform (assuming it has priority) and remove the base Transform.
        // NOTE: We could probably change this to detect any Transform-derived type rather than RectTransform specifically.
        if (primaryType == TypeOf<UI::RectTransform>())
        {
            // Merge the source into the primary.
            MergeTransformComponents(*sourceTransform, *primaryTransform, true);

            // Remove the source component.
            RemoveComponentAtIndex(index--);

            // Destroy the component.
            DestroyComponentDuringConsistencyCheck(sourceTransform);
        }
        else
        {
            // Merge the primary into the source.
            MergeTransformComponents(*primaryTransform, *sourceTransform, true);

            // Remove the primary component.
            RemoveComponentAtIndex(primaryIndex);
            primaryIndex = --index;

            // Destroy the component.
            DestroyComponentDuringConsistencyCheck(primaryTransform);

            // Set the primary to be the source.
            primaryTransform = sourceTransform;
        }

        // We have performed a merge so flag this as we don't want any more merges!
        transformMerged = true;
    }

    // If we didn't find a transform then simply add a base transform for now.
    //@TODO: We should perform a more generalized consistency check outside of this method that ensures that all existing
    // components have their component dependencies satisfied.
    if (primaryTransform == NULL)
    {
        ErrorStringObject(Format("Transform component could not be found on game object. Adding one!"), this);
        primaryTransform = AddTransformComponentUnchecked<Transform>(*this);
        primaryIndex = GetComponentCount() - 1;
    }

    // We now have a unique transform however we should ensure that it is the first component for consistency.
    if (primaryIndex != 0)
    {
        // To preserve the order we are doing erase/insert instead of swap.
        // It's is an acceptable trade-off as it's running only when it has to recover from data corruption.
        // This also handles efficiently cases when the added transform component is the last one
        // or when we have only two components (equivalent to swap).
        ComponentPair primaryComponent = m_Component[primaryIndex];
        m_Component.erase(m_Component.begin() + primaryIndex);
        m_Component.insert(m_Component.begin(), primaryComponent);
    }

    return (foundTransformComponents == 1);
}

void GameObject::CheckConsistency()
{
    Super::CheckConsistency();

    // Remove duplicates from m_Component.
    // It is possible that m_Component can have multiply entries of the same Component instance.
    // That could come from scene merge, e.g. see case 578463.
    size_t i = 0;
    while (i < m_Component.size())
    {
        InstanceID curComponentInstanceID = m_Component[i].GetComponentPtr().GetInstanceID();
        size_t j = i + 1;
        while (j < m_Component.size())
        {
            if (curComponentInstanceID == m_Component[j].GetComponentPtr().GetInstanceID())
            {
                ErrorStringObject(Format("Object %s (named '%s') has multiple entries of the same %s component. Removing it!",
                        GetTypeName(), m_Name.c_str(), Unity::Type::GetTypeByRuntimeTypeIndex(m_Component[i].GetTypeIndex())->GetName()), this);
                m_Component.erase(m_Component.begin() + j);
            }
            else
                j++;
        }
        i++;
    }

    // Remove Components from m_Component if they vanished without deactivating.
    // (eg. class hierarchy changed and the class doesn't exist anymore when loading from disk)
    i = 0;
    while (i < m_Component.size())
    {
        // Use is object available instead of normal comparison so that we dont load the object
        // which might already trigger the component to query for other components.
        InstanceID CurComponentInstanceID = m_Component[i].GetComponentPtr().GetInstanceID();
        if (!IsObjectAvailable(CurComponentInstanceID))
        {
            //TODO: Any way to improve this error message (during deserialization the identifier of the missing component should be available)
            ErrorStringObject("Component could not be loaded when loading game object. Cleaning up!", this);
            m_Component.erase(m_Component.begin() + i);
        }
        else
            i++;
    }

#if UNITY_EDITOR
    // Strip components from excluded modules - but only in play mode, since we don't want to modify scene data.
    if (GetApplicationPtr() && GetApplicationPtr()->IsPlayingOrWillEnterExitPlaymode())
    {
        i = 0;
        while (i < m_Component.size())
        {
            Unity::Component* component = m_Component[i].GetComponentPtr();

            if (component && ModuleMetadata::Get().GetModuleIncludeSettingForClass(component->GetType()) == kForceExclude)
            {
                DestroyComponentDuringConsistencyCheck(component);
                m_Component.erase(m_Component.begin() + i);
            }
            else
                i++;
        }
    }

#endif

    // Preload all the components!
    // This is necessary to avoid recursion and awake functions calling remove component,
    // When we are removing the wrong ones anyway.
    i = 0;
    while (i < m_Component.size())
    {
        Unity::Component* com = m_Component[i].GetComponentPtr();

        // Make sure the type in the components container actually matches the type of the component
        // When changing a terrain monobehaviour to a terrain component the serialization system adds the type as monobehaviour
        // but it add a terrain component
        m_Component[i].SetComponentPtr(com); // resets the typeindex
        i++;
    }

    // Remove Components with wrong gameobject ptrs
    i = 0;
    while (i < m_Component.size())
    {
        Unity::Component* com = m_Component[i].GetComponentPtr();
        if (com && com->GetGameObjectPtr() == this)
        {
            i++;
            continue;
        }

        if (com)
        {
            if (com->GetGameObjectPtr() == NULL)
            {
                com->SetGameObjectInternal(this);
                ErrorStringObject(Format("Component (%s) has a broken GameObject reference. Fixing!", com->GetTypeName()), this);
                continue;
            }
            else
            {
                ErrorStringObject(Format("Failed to load component (%s)! Removing it!", com->GetTypeName()), this);
                com->SetHideFlags(kHideAndDontSave);
            }
        }
        else
        {
            ErrorStringObject(Format("Failed to load component (%s)! Removing it!", Unity::Type::GetTypeByRuntimeTypeIndex(m_Component[i].GetTypeIndex())->GetName()), this);
        }

        m_Component.erase(m_Component.begin() + i);
    }

    // Ensure that we've only got a single transform component performing merges and deletes as appropriate.
    // NOTE: We must ignore this action on persistent object as during a check-consistency, we cannot guarantee if we're
    // being called from a hierarchical consistency check.  Touching the transform hierarchy here can cause problems.
    if (!EnsureUniqueTransform())
    {
        if (IsPersistent())
            ErrorStringObject("Prefab has multiple Transform components! Removing them automatically would not be safe.", this);
        else
            ErrorStringObject("GameObject has multiple Transform components! Merged into single one.", this);
    }

#if UNITY_EDITOR
    if (m_IsOldVersion && m_IsActive && !IsPersistent() && !IsActiveIgnoreImplicitPrefab())
        WarningStringObject("GameObject is active but a parent is inactive. Active state is now inherited. Change the parenting to get back the old behaviour!", this);
#endif
}

void GameObject::SetLayer(int layer)
{
    if (layer >= 0 && layer < 32)
    {
        m_Layer = layer;
        SendMessage(kLayerChanged);
        SetDirty();
    }
    else
        ErrorString("A game object can only be in one layer. The layer needs to be in the range [0...31]");
}

void GameObject::SetCullSceneMask(UInt64 mask)
{
    m_CullSceneMask = mask;

    Transform &t = GetComponent<Transform>();
    for (int i = 0; i != t.GetChildrenCount(); i++)
        t.GetChild(i).GetGameObject().SetCullSceneMask(mask);

    SendMessage(kCullSceneChanged);
    SetDirty();
}

UInt64 GameObject::GetCullSceneMask() const
{
    Transform &t = GetComponent<Transform>();
    UnityScene *scene = t.GetScene();
    return (scene == NULL) ? ~(UInt64)0 : scene->GetCullingMask();
}

void GameObject::SetTag(UInt32 tag)
{
    #if UNITY_EDITOR
    m_TagString = GetTagManager().TagToString(tag);
    #endif

    m_Tag = tag;
    UpdateActiveGONode();

    Assert(!(tag != 0xffffffff && tag != m_Tag));
    Assert(!(tag == 0xffffffff && m_Tag != 0xFFFF));
    SendMessage(kLayerChanged);
    SetDirty();
}

void GameObject::SetHideFlags(HideFlags flags)
{
    SetHideFlagsObjectOnly(flags);
    for (size_t i = 0; i < m_Component.size(); i++)
    {
        Unity::Component& com = *m_Component[i].GetComponentPtr();
        com.SetHideFlags(flags);
    }
}

template<class TransferFunction>
void GameObject::ComponentPair::Transfer(TransferFunction& transfer)
{
    transfer.Transfer(component, "component");
    if (transfer.IsReadingPPtr())
    {
        typeIndex = component ? component->GetType()->GetRuntimeTypeIndex() : 0;
    }
}

template<class TransferFunction>
void GameObject::TransferComponents(TransferFunction& transfer)
{
    if (transfer.IsVersionSmallerOrEqual(4))
    {
        typedef dynamic_array<std::pair<SInt32, ImmediatePtr<Unity::Component> > > OldContainer;
        OldContainer components(kMemTempAlloc);
        transfer.Transfer(components, "m_Component", kHideInEditorMask | kStrongPPtrMask);
        m_Component.reserve(components.size());
        for (OldContainer::const_iterator i = components.begin(); i != components.end(); ++i)
        {
            if (i->second)
                m_Component.push_back(ComponentPair::FromComponent(i->second));
        }
        return;
    }

    // When cloning objects for prefabs and instantiate, we don't use serialization to duplicate the hierarchy,
    // we duplicate the hierarchy directly
    if (!SerializePrefabIgnoreProperties(transfer))
        return;

#if UNITY_EDITOR
    if (transfer.IsWriting() && transfer.NeedsInstanceIDRemapping())
    {
        Container filtered_components(kMemTempAlloc);
        for (Container::iterator i = m_Component.begin(); i != m_Component.end(); i++)
        {
            LocalSerializedObjectIdentifier localIdentifier;
            InstanceIDToLocalSerializedObjectIdentifier(i->GetComponentPtr()->GetInstanceID(), localIdentifier);
            if (localIdentifier.localIdentifierInFile != 0)
                filtered_components.push_back(*i);
        }
        transfer.Transfer(filtered_components, "m_Component", kHideInEditorMask | kStrongPPtrMask);
        return;
    }
#endif

    transfer.Transfer(m_Component, "m_Component", kHideInEditorMask | kStrongPPtrMask);
}

template<class TransferFunction>
void GameObject::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);
    transfer.SetVersion(5);
    TransferComponents(transfer);

    TRANSFER(m_Layer);

#if !UNITY_EDITOR
    transfer.Transfer(m_Name, "m_Name");
    TRANSFER(m_Tag);
    transfer.Transfer(m_IsActive, "m_IsActive");
#elif UNITY_EDITOR
    if (transfer.IsVersionSmallerOrEqual(3))
        m_IsOldVersion = true;

    if (transfer.IsVersionSmallerOrEqual(1))
    {
        TRANSFER(m_Tag);
        m_TagString = GetTagManager().TagToString(m_Tag);
        transfer.Transfer(m_IsActive, "m_IsActive");
    }
    else if (transfer.IsVersionSmallerOrEqual(2))
    {
        TRANSFER(m_TagString);
        m_Tag = GetTagManager().StringToTag(m_TagString);
        transfer.Transfer(m_IsActive, "m_IsActive");
    }
    else
    {
        transfer.Transfer(m_Name, "m_Name");

        if (transfer.IsSerializingForGameRelease())
        {
            TRANSFER(m_Tag);
            if (transfer.IsReading())
                m_TagString = GetTagManager().TagToString(m_Tag);

            transfer.Transfer(m_IsActive, "m_IsActive");
        }
        else
        {
            transfer.Transfer(m_TagString, "m_TagString");
            if (transfer.IsReading())
                m_Tag = GetTagManager().StringToTagAddIfUnavailable(m_TagString);

            transfer.Transfer(m_Icon, "m_Icon", kNoTransferFlags);
            transfer.Transfer(m_NavMeshLayer, "m_NavMeshLayer", kHideInEditorMask);

            transfer.Transfer(m_StaticEditorFlags, "m_StaticEditorFlags", kNoTransferFlags | kGenerateBitwiseDifferences);

            // Read deprecated static flag and set it up as m_StaticEditorFlags
            if (transfer.IsReadingBackwardsCompatible())
            {
                bool isStatic = false;
                transfer.Transfer(isStatic, "m_IsStatic", kNoTransferFlags);
                if (isStatic)
                    m_StaticEditorFlags = 0xFFFFFFFF;
            }
            transfer.Transfer(m_IsActive, "m_IsActive", kHideInEditorMask);
        }
    }

#endif

    // Make sure that old prefabs are always active.
    if (transfer.IsVersionSmallerOrEqual(3) && IsPersistent())
        m_IsActive = true;
}

void GameObject::MarkGameObjectAndComponentDependencies(GarbageCollectorThreadState& gc) const
{
    GameObject::Container::const_iterator end = m_Component.end();
    for (GameObject::Container::const_iterator i = m_Component.begin(); i != end; ++i)
    {
        MarkObjectAsRoot(*i->GetComponentPtr(), gc);
    }
}

bool GameObject::GetIsStaticDeprecated()
{
#if UNITY_EDITOR
    return m_StaticEditorFlags != 0;
#else
    return false;
#endif
}

void GameObject::SetIsStaticDeprecated(bool s)
{
#if UNITY_EDITOR
    m_StaticEditorFlags = s ? 0xFFFFFFFF : 0;
    SetDirty();
#endif
}

bool GameObject::IsStaticBatchable() const
{
#if UNITY_EDITOR
    return AreStaticEditorFlagsSet(kBatchingStatic);
#else
    return false;
#endif
}

#if UNITY_EDITOR

bool GameObject::AreStaticEditorFlagsSet(StaticEditorFlags flags) const
{
    return (m_StaticEditorFlags & (UInt32)flags) != 0;
}

StaticEditorFlags GameObject::GetStaticEditorFlags() const
{
    return (StaticEditorFlags)m_StaticEditorFlags;
}

void GameObject::SetStaticEditorFlags(StaticEditorFlags flags)
{
    m_StaticEditorFlags = (UInt32)flags;
    SetDirty();
}

void GameObject::SetIcon(PPtr<Texture2D> icon)
{
    if (m_Icon != icon)
    {
        m_Icon = icon;
        SetDirty();
    }
}

PPtr<Texture2D> GameObject::GetIcon() const
{
    return m_Icon;
}

#endif

void GameObject::RegisterDestroyedCallback(DestroyGOCallbackFunction* callback)
{
    s_GameObjectDestroyedCallback = callback;
}

void GameObject::InvokeDestroyedCallback(GameObject* go)
{
    if (s_GameObjectDestroyedCallback)
        s_GameObjectDestroyedCallback(go);
}

void GameObject::RegisterSetGONameCallback(SetGONameFunction* callback)
{
    s_SetGONameCallback = callback;
}

void GameObject::InitializeClass()
{
    GameObjectManager::StaticInitialize();
}

void GameObject::CleanupClass()
{
    GameObjectManager::StaticDestroy();
}

void GameObject::SendMessageAny(const MessageIdentifier& messageIdentifier, MessageData& messageData)
{
    __FAKEABLE_METHOD__(GameObject, SendMessageAny, (messageIdentifier, messageData));

    if (GetDisableSendMessage())
    {
        WarningString("SendMessage cannot be called during Awake, CheckConsistency, or OnValidate");
    }

    Assert(messageIdentifier.GetMessageId() != -1);
    #if DEBUGMODE
    if (messageIdentifier.parameterType != messageData.type)
        AssertString("The messageData sent has an incorrect type.");
    #endif

    for (size_t i = 0; i < m_Component.size(); i++)
    {
        RuntimeTypeIndex typeIndex = m_Component[i].GetTypeIndex();
        if (MessageHandler::Get().HasMessageCallback(typeIndex, messageIdentifier))
        {
            Unity::Component& component = *(m_Component[i].GetComponentPtr());
            MessageHandler::Get().HandleMessage(&component, typeIndex, messageIdentifier, messageData);
        }
    }
}

bool GameObject::WillHandleMessage(const MessageIdentifier& messageIdentifier)
{
    __FAKEABLE_METHOD__(GameObject, WillHandleMessage, (messageIdentifier));

    Assert(messageIdentifier.GetMessageId() != -1);

    for (Container::iterator i = m_Component.begin(); i != m_Component.end(); i++)
    {
        RuntimeTypeIndex typeIndex = i->GetTypeIndex();
        if (MessageHandler::Get().HasMessageCallback(typeIndex, messageIdentifier))
        {
            Unity::Component& component = *i->GetComponentPtr();
            if (MessageHandler::Get().WillHandleMessage(&component, typeIndex, messageIdentifier))
                return true;
        }
    }
    return false;
}

void GameObject::TransformParentHasChanged()
{
    // Reactivate transform hierarchy, but only if it has been activated before,
    // otherwise we change activation order.
    if (m_IsActiveCached != -1)
        ActivateAwakeRecursively();
}

void GameObject::CopyProperties(GameObject& dest)
{
    dest.m_Layer = m_Layer;
    dest.m_Tag = m_Tag;
    dest.m_IsActive = m_IsActive;
    dest.m_IsActiveCached = -1;
    dest.m_Name = m_Name;

#if UNITY_EDITOR
    dest.m_StaticEditorFlags = m_StaticEditorFlags;
    dest.m_TagString = m_TagString;
    dest.m_MarkedVisible = m_MarkedVisible;
    dest.m_Icon = m_Icon;
    dest.m_NavMeshLayer = m_NavMeshLayer;
#endif
}

void SendMessageDirect(Object& target, const MessageIdentifier& messageIdentifier, MessageData& messageData)
{
    const Unity::Type* type = target.GetType();
    RuntimeTypeIndex typeIndex = type->GetRuntimeTypeIndex();
    if (MessageHandler::Get().HasMessageCallback(typeIndex, messageIdentifier))
    {
        MessageHandler::Get().HandleMessage(&target, typeIndex, messageIdentifier, messageData);
    }
}

namespace Unity
{
    char const* Component::GetName() const
    {
        if (m_GameObject)
            return m_GameObject->m_Name.c_str();
        else
            return GetTypeName();
    }

    void Component::SetName(char const* name)
    {
        if (m_GameObject)
            m_GameObject->SetName(name);
    }

    void Component::ThreadedCleanup()
    {
    }

    void Component::SendMessageAny(const MessageIdentifier& messageID, MessageData& messageData)
    {
        GameObject* go = GetGameObjectPtr();
        if (go)
            go->SendMessageAny(messageID, messageData);
    }

    void Component::AwakeFromLoad(AwakeFromLoadMode awakeMode)
    {
        Super::AwakeFromLoad(awakeMode);

        // Force load the game object. This is in order to prevent ImmediatePtrs not being dereferenced after loading.
        // Which can cause a crash in Resources.UnloadUnusedAssets()
        // Resources.Load used to store incorrect preload data which made this trigger.
        ::GameObject* dereferenceGameObject = m_GameObject;
        UNUSED(dereferenceGameObject);
    }

    template<class TransferFunction>
    void Component::Transfer(TransferFunction& transfer)
    {
        Super::Transfer(transfer);

        if (SerializePrefabIgnoreProperties(transfer))
            transfer.Transfer(m_GameObject, "m_GameObject", kHideInEditorMask | kStrongPPtrMask);
    }

    void Component::MarkGameObjectAndComponentDependencies(GarbageCollectorThreadState& gc) const
    {
        // mark the host game object
        MarkInstanceIDAsRoot(m_GameObject.GetInstanceID(), gc);
    }

    void Component::CheckConsistency()
    {
        Super::CheckConsistency();
        GameObject* go = GetGameObjectPtr();
        if (go)
        {
            for (int i = 0; i < go->GetComponentCount(); i++)
            {
                Component* com = go->m_Component[i].GetComponentPtr();
                if (com == this)
                    return;
            }

            ErrorStringObject(Format("CheckConsistency: GameObject does not reference component %s. Fixing.", GetTypeName()), go);
            go->AddComponentInternal(this);
        }

        // MonoBehaviours are allowed to exists without a game object
        if (Is<MonoBehaviour>())
        {
            return;
        }

    #if UNITY_EDITOR
        if (m_GameObject == NULL)
        {
            GetDelayedCleanupManager().MarkForDeletion(this, "GameObject pointer is invalid");
        }
    #endif
    }

    void Component::SetEnabled(bool enable)
    {
        AssertFormatMsg(!HasEnabled(), "Component of class '%s' overrides HasEnabled but not SetEnabled().", GetTypeName());

        WarningStringMsg("Component of class '%s' does not support SetEnabled calls. Do not call SetEnabled on this class.", GetTypeName());
    }
} // End namespace Unity

GameObjectManager* GameObjectManager::s_Instance = NULL;
void GameObjectManager::StaticInitialize()
{
    Assert(GameObjectManager::s_Instance == NULL);
    GameObjectManager::s_Instance = UNITY_NEW(GameObjectManager, kMemBaseObject);
}

void GameObjectManager::StaticDestroy()
{
    Assert(GameObjectManager::s_Instance);
    UNITY_DELETE(GameObjectManager::s_Instance, kMemBaseObject);
}

GameObjectManager& GetGameObjectManager()
{
    Assert(GameObjectManager::s_Instance);
    return *GameObjectManager::s_Instance;
}

IMPLEMENT_OBJECT_SERIALIZE(GameObject);
IMPLEMENT_OBJECT_SERIALIZE(Unity::Component);

IMPLEMENT_REGISTER_CLASS(GameObject, 1);
IMPLEMENT_REGISTER_CLASS(Unity, Component, 2);

INSTANTIATE_TEMPLATE_TRANSFER_EXPORTED(GameObject);
INSTANTIATE_TEMPLATE_TRANSFER_EXPORTED(Unity::Component);

void MergeTransformComponents(Transform& source, Transform& target, bool mergeTRS)
{
    // Clear out both involved hierarchies.
    Transform* oldSourceRoot = (source.GetParent() != NULL) ? &source.GetRoot() : NULL;
    Transform* oldTargetRoot = (target.GetParent() != NULL) ? &target.GetRoot() : NULL;
    source.ClearTransformHierarchyAndApplyToSerializedData();
    target.ClearTransformHierarchyAndApplyToSerializedData();

    // Fetch the local TRS of the source.
    const Vector3f localPosition = source.m_LocalPosition;
    const Quaternionf localRotation = source.m_LocalRotation;
    const Vector3f localScale = source.m_LocalScale;

#if UNITY_EDITOR
    // Transfer root order.
    target.SetRootOrder(source.GetRootOrder());
#endif

    // Ensure target transform has the same scene as source transform
    UnityScene* sourceScene = source.GetScene();
    UnityScene* targetScene = target.GetScene();
    if (sourceScene != NULL && targetScene != sourceScene)
    {
        if (targetScene != NULL)
            UnityScene::RemoveRootFromScene(target, true);
        UnityScene::AddRootToScene(*sourceScene, target);
    }

    // Remove the source from its parent.
    Transform* sourceParent = source.GetParent();
    if (sourceParent != NULL)
    {
        // Source is no longer parented.
        source.SetParentPtrInternal(NULL);

        // Find the source in its parent children.
        Transform::TransformComList& sourceParentChildren = sourceParent->GetChildrenInternal();
        for (int index = 0; index < sourceParentChildren.size(); ++index)
        {
            // Find the source.
            Transform* transform = sourceParentChildren[index];
            if (transform != &source)
                continue;

            // Does the target already have a parent?
            if (target.GetParent() == NULL)
            {
                // Please see the line below.
                // Since we manually set the parent ptr without invoking Transform::SetParent (),
                // we have to manually remove it from the parent UnityScene in order to keep the
                // data consistent.
                UnityScene::RemoveRootFromScene(target, true);

                // No, so ensure we maintain the children order and replace the source with the target as a child.
                sourceParentChildren[index] = &target;
                target.SetParentPtrInternal(sourceParent);

                break;
            }

            // Yes, so we'll just remove the child.
            Transform::iterator foundChild = sourceParent->Find(&source);
            if (foundChild != sourceParent->m_Children.end())
                sourceParent->m_Children.erase(foundChild);
            break;
        }
    }

    // Move the source children so they are children of the target instead.
    Transform::TransformComList& sourceChildren = source.GetChildrenInternal();
    for (int index = 0; index < sourceChildren.size(); ++index)
    {
        Transform* sourceChild = sourceChildren[index];

        // Check if we have a source child and it's not already a child of the target (just in-case).
        if (sourceChild && target.Find(sourceChild) == target.end())
        {
#if UNITY_EDITOR
            // Is this a prefab instance?
            if (!sourceChild->IsPrefabParent())
            {
                // Yes, so fetch the prefab.
                Prefab* prefab = sourceChild->GetPrefab();
                if (prefab != NULL)
                {
                    // If the prefab instance transform parent is being removed then replace it with the new target.
                    PPtr<Transform>& transformParent = prefab->m_Modification.m_TransformParent;
                    if (transformParent.IsValid() && transformParent.GetInstanceID() == source.GetInstanceID())
                    {
                        transformParent = &target;
                        prefab->SetDirty();
                    }
                }
            }
#endif
            // We can use it as a target child.
            sourceChild->SetParentPtrInternal(&target);
            target.GetChildrenInternal().push_back(sourceChild);
        }
    }

    // Remove all the children references from the source.
    sourceChildren.clear();

    // Rebuild TransformHierarchies.
    target.RebuildTransformHierarchy();
    if (oldSourceRoot != NULL)
        oldSourceRoot->EnsureTransformHierarchyExists();
    if (oldTargetRoot != NULL)
        oldTargetRoot->EnsureTransformHierarchyExists();

    // Finish if we're not merging transform state.
    if (!mergeTRS)
        return;

    // Set the target local transform state to what the source was.
    //TODO: move this TRS merge code to the Transform class...
    target.SetLocalPositionWithoutNotification(Vector3fTofloat3(localPosition));
    target.SetLocalRotationWithoutNotification(QuaternionfTofloat4(localRotation));
    target.SetLocalScaleWithoutNotification(Vector3fTofloat3(localScale));

    if (target.GetType() == TypeOf<UI::RectTransform>())
    {
        Vector2f anchoredPosition(localPosition.x, localPosition.y);
        ((UI::RectTransform&)target).SetAnchoredPositionWithoutNotification(anchoredPosition);
    }
}
