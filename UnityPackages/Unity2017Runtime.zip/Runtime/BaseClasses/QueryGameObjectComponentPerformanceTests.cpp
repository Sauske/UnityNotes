#include "UnityPrefix.h"

#if ENABLE_PERFORMANCE_TESTS

#include "Runtime/Testing/PerformanceTesting.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Graphics/Mesh/MeshRenderer.h"
#include "Runtime/Dynamics/BoxCollider.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/BaseClasses/GameObject.h"


PERFORMANCE_TEST_SUITE(QueryGameObjectComponentPerformanceTests)
{
    template<class T>
    T* NewObjectResetAndAwake();

    template<>
    BoxCollider* NewObjectResetAndAwake()
    {
        return NEW_OBJECT_RESET_AND_AWAKE(BoxCollider);
    }

    template<>
    Transform* NewObjectResetAndAwake()
    {
        return NEW_OBJECT_RESET_AND_AWAKE(Transform);
    }

    template<>
    MeshRenderer* NewObjectResetAndAwake()
    {
        return NEW_OBJECT_RESET_AND_AWAKE(MeshRenderer);
    }

    template<class T>
    T* QueryGameObjectComponent(GameObject* go);

    template<>
    Collider* QueryGameObjectComponent(GameObject* go)
    {
        return go->QueryComponent<Collider>();
    }

    template<>
    Transform* QueryGameObjectComponent(GameObject* go)
    {
        return go->QueryComponent<Transform>();
    }

    template<>
    MeshRenderer* QueryGameObjectComponent(GameObject* go)
    {
        return go->QueryComponent<MeshRenderer>();
    }

    template<class TObj, class TFiller, int GameObjectCount, int IMin, int IMax>
    class GameObjectPerformanceFixture
    {
    public:

        GameObjectPerformanceFixture()
            : p(NULL)
        {
            for (int i = 0; i < GameObjectCount; ++i)
            {
                int fillerCount = (i % (1 + IMax - IMin)) + IMin;
                GameObject* go = gameObjects[i] = NEW_OBJECT_RESET_AND_AWAKE(GameObject);
                for (int f = 0; f < fillerCount; ++f)
                {
                    go->AddComponentInternal(NewObjectResetAndAwake<TFiller>());
                }
                go->AddComponentInternal(NewObjectResetAndAwake<TObj>());
            }
        }

        ~GameObjectPerformanceFixture()
        {
            for (int i = 0; i < GameObjectCount; ++i)
            {
                DestroyObjectHighLevel(gameObjects[i]);
            }
        }

        static const int kOuterIterations = 1000;

        template<class TQuery>
        void Run()
        {
            PERFORMANCE_TEST_LOOP(kOuterIterations)
            {
                for (UInt32 nGameObject = 0; nGameObject < GameObjectCount; ++nGameObject)
                {
                    p = QueryGameObjectComponent<TQuery>(gameObjects[nGameObject]);
                }
            }
        }

        volatile void* p;
        GameObject* gameObjects[GameObjectCount];
    };

    typedef GameObjectPerformanceFixture<Transform, MeshRenderer, 1024, 0, 0>  QueryTransform_FromObjectsWith_Only_1_Transform_Type;
    typedef GameObjectPerformanceFixture<Transform, MeshRenderer, 1024, 1, 8>  QueryTransform_FromObjectsWith_1_to_8_MeshRenderers_Type;
    typedef GameObjectPerformanceFixture<Transform, MeshRenderer, 1024, 8, 16> QueryTransform_FromObjectsWith_8_to_16_MeshRenderers_Type;

    typedef GameObjectPerformanceFixture<MeshRenderer, BoxCollider, 1024, 0, 0>  QueryMeshRenderer_FromObjectsWith_Only_1_MeshRenderer_Type;
    typedef GameObjectPerformanceFixture<MeshRenderer, BoxCollider, 1024, 1, 8>  QueryMeshRenderer_FromObjectsWith_1_to_8_BoxColliders_Type;
    typedef GameObjectPerformanceFixture<MeshRenderer, BoxCollider, 1024, 8, 16> QueryMeshRenderer_FromObjectsWith_8_to_16_BoxColliders_Type;

    typedef GameObjectPerformanceFixture<BoxCollider, MeshRenderer, 1024, 0, 0>  QueryCollider_FromObjectsWith_Only_1_BoxCollider_Type;
    typedef GameObjectPerformanceFixture<BoxCollider, MeshRenderer, 1024, 1, 8>  QueryCollider_FromObjectsWith_1_to_8_MeshRenderers_Type;
    typedef GameObjectPerformanceFixture<BoxCollider, MeshRenderer, 1024, 8, 16> QueryCollider_FromObjectsWith_8_to_16_MeshRenderers_Type;


    TEST_FIXTURE(QueryTransform_FromObjectsWith_Only_1_Transform_Type, QueryTransform_FromObjectsWith_Only_1_Transform)
    {
        Run<Transform>();
    }

    TEST_FIXTURE(QueryTransform_FromObjectsWith_1_to_8_MeshRenderers_Type, QueryTransform_FromObjectsWith_1_to_8_MeshRenderers)
    {
        Run<Transform>();
    }

    TEST_FIXTURE(QueryTransform_FromObjectsWith_8_to_16_MeshRenderers_Type, QueryTransform_FromObjectsWith_8_to_16_MeshRenderers)
    {
        Run<Transform>();
    }


    TEST_FIXTURE(QueryMeshRenderer_FromObjectsWith_Only_1_MeshRenderer_Type, QueryMeshRenderer_FromObjectsWith_Only_1_MeshRenderer)
    {
        Run<MeshRenderer>();
    }

    TEST_FIXTURE(QueryMeshRenderer_FromObjectsWith_1_to_8_BoxColliders_Type, QueryMeshRenderer_FromObjectsWith_1_to_8_BoxColliders)
    {
        Run<MeshRenderer>();
    }

    TEST_FIXTURE(QueryMeshRenderer_FromObjectsWith_8_to_16_BoxColliders_Type, QueryMeshRenderer_FromObjectsWith_8_to_16_BoxColliders)
    {
        Run<MeshRenderer>();
    }

    TEST_FIXTURE(QueryCollider_FromObjectsWith_Only_1_BoxCollider_Type, QueryCollider_FromObjectsWith_Only_1_BoxCollider)
    {
        Run<Collider>();
    }

    TEST_FIXTURE(QueryCollider_FromObjectsWith_1_to_8_MeshRenderers_Type, QueryCollider_FromObjectsWith_1_to_8_MeshRenderers)
    {
        Run<Collider>();
    }

    TEST_FIXTURE(QueryCollider_FromObjectsWith_8_to_16_MeshRenderers_Type, QueryCollider_FromObjectsWith_8_to_16_MeshRenderers)
    {
        Run<Collider>();
    }
}

#endif
