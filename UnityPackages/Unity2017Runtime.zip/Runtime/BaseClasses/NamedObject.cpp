#include "UnityPrefix.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "Runtime/Utilities/RegisterRuntimeInitializeAndCleanup.h"
#include "NamedObject.h"

NamedObject::NamedObject(MemLabelId label, ObjectCreationMode mode)
    :   Super(label, mode)
{
}

void NamedObject::ThreadedCleanup()
{
}

template<class TransferFunction>
void NamedObject::Transfer(TransferFunction& transfer)
{
    Super::Transfer(transfer);
    transfer.Transfer(m_Name, "m_Name", kHideInEditorMask);
}

void NamedObject::SetName(char const* name)
{
    if (strcmp(m_Name.c_str(), name) != 0)
    {
        m_Name.assign(name, GetMemoryLabel());
        SetDirty();
    }
}

IMPLEMENT_REGISTER_CLASS(NamedObject, 130);
IMPLEMENT_OBJECT_SERIALIZE(NamedObject);
INSTANTIATE_TEMPLATE_TRANSFER_EXPORTED(NamedObject);
