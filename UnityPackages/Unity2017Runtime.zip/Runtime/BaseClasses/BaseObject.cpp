#include "UnityPrefix.h"
#include "Configuration/UnityConfigure.h"
#include "BaseObject.h"
#include "BaseObjectUtilities.h"
#include "Runtime/BaseClasses/TypeManager.h"
#include "Runtime/Serialize/PersistentManager.h"
#include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"
#include "External/boost/dynamic_bitset.h"
#include "Runtime/Utilities/RegisterRuntimeInitializeAndCleanup.h"
#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/Profiler/MemoryProfilerStats.h"
#include "Runtime/ScriptingBackend/ScriptingApi.h"
#include "Runtime/Testing/Faking.h"
#include "EventManager.h"
#include "EventIDs.h"
#if ENABLE_MONO
#include "Runtime/Mono/MonoIncludes.h"
#endif

#include "Runtime/Mono/MonoManager.h"
#include "Runtime/Scripting/ScriptingUtility.h"

#include "Configuration/UnityConfigure.h"
#if THREADED_LOADING
#include "Runtime/Threads/ThreadSpecificValue.h"
#include "Runtime/Threads/ProfilerMutex.h"
#endif

#if !UNITY_EXTERNAL_TOOL
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Profiler/MemoryProfiler.h"
#endif
#include "Runtime/Allocator/MemoryManager.h"


#define SHOW_REGISTERED_CLASS_INFO 0
#define SHOW_DELETED_OBJECTS !UNITY_EDITOR && 0


#if THREADED_LOADING
#define CHECK_IN_MAIN_THREAD Assert(Thread::CurrentThreadIsMainThread());
#else
#define CHECK_IN_MAIN_THREAD
#endif

Object::IDToPointerMap*   Object::ms_IDToPointer = NULL;

static Object::ObjectDestroyCallbackFunction* gDestroyedCallbackFunc = NULL;

static MemLabelRootId* gBaseObjectManagerContainer = NULL;

namespace BaseObjectManager
{
    void StaticInitialize(void*)
    {
        gBaseObjectManagerContainer = UNITY_NEW_AS_ROOT(MemLabelRootId, kMemBaseObject, "Managers", "BaseObjectManager") ();
        TypeManager::InitializeGlobalInstance();
        Object::StaticInitialize();
    }

    void StaticDestroy(void*)
    {
        Object::StaticDestroy();
        TypeManager::CleanupGlobalInstance();
        UNITY_DELETE(gBaseObjectManagerContainer, kMemBaseObject);
    }
}

static RegisterRuntimeInitializeAndCleanup s_BaseObjectManagerCallbacks(BaseObjectManager::StaticInitialize, BaseObjectManager::StaticDestroy);

#if UNITY_EDITOR
static Object::ObjectDirtyCallbackFunction*   gSetDirtyCallbackFunc = NULL;
#endif

PROFILER_INFORMATION(gObjectCreationMutexLockInfo, "Object.CreateObject mutex lock", kProfilerLoading)

#if THREADED_LOADING
Mutex           gCreateObjectMutex;
#if DEBUGMODE
static UNITY_TLS_VALUE(int) gCheckObjectCreationMutex;
#endif
#endif

void LockObjectCreation()
{
    #if THREADED_LOADING
    LOCK_MUTEX(gCreateObjectMutex, gObjectCreationMutexLockInfo);
    #if DEBUGMODE
    ++gCheckObjectCreationMutex;
    #endif
    #endif
}

void UnlockObjectCreation()
{
    #if THREADED_LOADING
    gCreateObjectMutex.Unlock();
    #if DEBUGMODE
    --gCheckObjectCreationMutex;
    #endif
    #endif
}

static volatile size_t gLowestInstanceID = -10;
static ExecutionRestrictions gExecutionRestrictions = kNoRestriction;

InstanceID AllocateNextLowestInstanceID()
{
    __FAKEABLE_FUNCTION__(AllocateNextLowestInstanceID, ());

    AtomicAdd(&gLowestInstanceID, -2);
    return InstanceID_Make((SInt32)gLowestInstanceID);
}

#if ENFORCE_INSTANCEID_TYPE_SAFETY
namespace core
{
    UInt32 hash<InstanceID>::operator()(InstanceID i) const
    {
        return static_cast<UInt32>(ComputeIntHash(InstanceID_AsSInt32Ref(i)));
    }
}
#endif

#if UNITY_EDITOR
InstanceIDResolveCallback* gInstanceIDResolveCallback = NULL;
const void* gInstanceIDResolveContext = NULL;

void SetInstanceIDResolveCallback(InstanceIDResolveCallback callback, const void* context)
{
    gInstanceIDResolveCallback = callback;
    gInstanceIDResolveContext = context;
}

#endif

void InstanceIDToLocalSerializedObjectIdentifier(InstanceID id, LocalSerializedObjectIdentifier& localIdentifier)
{
    #if UNITY_EDITOR
    // Early out if referenced object is null
    if (id == InstanceID_None)
    {
        localIdentifier.localSerializedFileIndex = 0;
        localIdentifier.localIdentifierInFile = 0;
        return;
    }

    if (gInstanceIDResolveCallback == NULL)
    {
        GetPersistentManager().InstanceIDToLocalSerializedObjectIdentifierInternal(id, localIdentifier);
        return;
    }
    else
    {
        gInstanceIDResolveCallback(id, localIdentifier, const_cast<void*>(gInstanceIDResolveContext));
    }
    #else
    GetPersistentManager().InstanceIDToLocalSerializedObjectIdentifierInternal(id, localIdentifier);
    #endif
}

void LocalSerializedObjectIdentifierToInstanceID(const LocalSerializedObjectIdentifier& localIdentifier, InstanceID& instanceID)
{
    GetPersistentManager().LocalSerializedObjectIdentifierToInstanceIDInternal(localIdentifier, instanceID);
}

Object* ReadObjectFromPersistentManager(InstanceID instanceID)
{
    if (instanceID == InstanceID_None)
        return NULL;
    else
    {
        // In the Player it is not possible to call MakeObjectPersistent,
        // thus instance id's that are positive are the only ones that can be loaded from disk
        #if !UNITY_EDITOR
        if (InstanceID_AsSInt32Ref(instanceID) < 0)
            return NULL;
        #endif

        Object* o = GetPersistentManager().ReadObject(instanceID);
        return o;
    }
}

Object* PreallocateObjectFromPersistentManager(InstanceID instanceID, bool threadedLoading)
{
    Object* obj = NULL;

    if (!threadedLoading)
    {
        obj = PPtr<Object>(instanceID);
    }
    else
    {
        obj = GetPersistentManager().PreallocateObjectThreaded(instanceID);
    }

    return obj;
}

void DestroyWithoutLoadingButDontDestroyFromFile(InstanceID instanceID, bool removeFromPersistentManager)
{
    if (removeFromPersistentManager)
        GetPersistentManager().MakeObjectUnpersistent(instanceID, kDontDestroyFromFile);
    UnloadObject(Object::IDToPointer(instanceID));
}

void DestroySingleObject(Object* o)
{
    if (o == NULL)
        return;

    if (o->IsPersistent())
        GetPersistentManager().MakeObjectUnpersistent(o->GetInstanceID(), kDestroyFromFile);

    // Lock changes to IDToPointer so that we can safely lookup pointers using IDToPointerThreadSafe
    LockObjectCreation();

    delete_object_internal(o);

    UnlockObjectCreation();
}

Object::Object(MemLabelId label, ObjectCreationMode mode)
    : m_MonoReference()
{
    Assert((long)GetLabelIdentifier(label) < (long)(1 << kMemLabelBits));
    m_MemLabelIdentifier = GetLabelIdentifier(label);
    m_InstanceID = InstanceID_None;
    m_CachedTypeIndex = INVALID_CACHED_TYPEINDEX;
    m_EventIndex = NULL;

#if !UNITY_RELEASE
    m_AwakeCalled                   = 0;
    m_ResetCalled                   = 0;
    m_AwakeThreadedCalled           = 0;
    m_AwakeDidLoadThreadedCalled    = 0;
    m_MainThreadCleanupCalled       = 0;
#endif


#if UNITY_EDITOR
    m_DirtyIndex = 0;
    m_FileIDHint = 0;
#endif
    m_HideFlags = 0;
    m_TemporaryFlags = 0;
    m_IsPersistent = false;

#if ENABLE_MEM_PROFILER
    m_FullMemoryLabel = label;
#endif

#if ENABLE_DOTNET
    m_TemporaryUnusedAssetsFlags = 0;
#endif

#if ENABLE_PROFILER
    m_ObjectProfilerListIndex = -1;
#endif
}

Object* Object::CalculateCachedTypeIndex(Object* obj)
{
    Assert(obj->GetTypeVirtualInternal()->GetRuntimeTypeIndex() < (1 << kCachedTypeIndexBits));
    obj->m_CachedTypeIndex = obj->GetTypeVirtualInternal()->GetRuntimeTypeIndex();
    return obj;
}

void Object::InsertObjectInMap(Object* obj)
{
    Assert(ms_IDToPointer->find(obj->GetInstanceID()) == ms_IDToPointer->end());
    ms_IDToPointer->insert(std::make_pair(obj->GetInstanceID(), obj));

    PROFILER_REGISTER_OBJECT(obj);
}

void Object::RegisterInstanceID(Object* obj)
{
    CHECK_IN_MAIN_THREAD

        LockObjectCreation();
    Assert(obj != NULL);
    Assert(obj->m_InstanceID != InstanceID_None);
    InsertObjectInMap(obj);

    UnlockObjectCreation();
}

void Object::RegisterInstanceIDNoLock(Object* obj)
{
    CHECK_IN_MAIN_THREAD
        Assert(obj != NULL);
    Assert(obj->m_InstanceID != InstanceID_None);
    CalculateCachedTypeIndex(obj);
    InsertObjectInMap(obj);
}

Object* Object::AllocateAndAssignInstanceID(Object* obj)
{
    CHECK_IN_MAIN_THREAD
        Assert(obj->m_InstanceID == InstanceID_None);

    LockObjectCreation();

    // Create a new unique instanceID for this Object.
    // The created id will be negative beginning with -1
    // Ids loaded from a file will be positive beginning with 1
    obj->SetInstanceID(AllocateNextLowestInstanceID());
    Assert((InstanceID_AsSInt32Ref(obj->GetInstanceID()) & 1) == 0);

    CalculateCachedTypeIndex(obj);
    InsertObjectInMap(obj);

    UnlockObjectCreation();

    obj->SetDirty();

    return obj;
}

Object* Object::AllocateAndAssignInstanceIDNoLock(Object* obj)
{
    CHECK_IN_MAIN_THREAD
        Assert(obj->m_InstanceID == InstanceID_None);

    // Create a new unique instanceID for this Object.
    // The created id will be negative beginning with -1
    // Ids loaded from a file will be positive beginning with 1
    obj->SetInstanceID(AllocateNextLowestInstanceID());
    Assert((InstanceID_AsSInt32Ref(obj->GetInstanceID()) & 1) == 0);

    CalculateCachedTypeIndex(obj);

    InsertObjectInMap(obj);

    obj->SetDirty();

    return obj;
}

enum { kMonoObjectCachedPtrOffset = 12 };

// This must be executed on the main thread
void delete_object_internal_step1(Object* object)
{
#if SHOW_DELETED_OBJECTS
    if (object->GetType() != TypeOf<Mesh>())        // GUI creates lots of meshes during runtime, ignore those
    {
        const char* n = object->GetName();
        if (n == NULL)
            n = "<NULL>";
        printf_console("Deleting %s (%s).\n", n, object->GetTypeName());
    }
#endif


    PROFILER_UNREGISTER_OBJECT(object);

#if !UNITY_RELEASE
    // Explicitly allow destroying objects without Awake() having been called.
    object->CheckCorrectAwakeUsage(false);
#endif

#if THREADED_LOADING && DEBUGMODE
    Assert(gCheckObjectCreationMutex >= 1);
#endif

    // Send destroy message & clear event index
    if (object->m_EventIndex != NULL)
    {
        GetEventManager().InvokeEvent(object->m_EventIndex, object, kWillDestroyEvent);
        GetEventManager().RemoveEvent(object->m_EventIndex);
        object->m_EventIndex = NULL;
    }

    // Remove this objects instanceID from the table.
    Assert(Object::ms_IDToPointer->find(object->GetInstanceID()) != Object::ms_IDToPointer->end());
    Object::ms_IDToPointer->erase(object->GetInstanceID());

    if (gDestroyedCallbackFunc)
        gDestroyedCallbackFunc(object->GetInstanceID());

    object->MainThreadCleanup();

    object->m_InstanceID = InstanceID_None;

    if (GetMonoManagerPtr() && object->GetGCHandle().HasTarget())
        object->SetCachedScriptingObject(SCRIPTING_NULL);
}

Object::~Object()
{
    // Ensure PreCleanupObject was called
    #if DEBUGMODE
    Assert(m_InstanceID == InstanceID_None);
    #endif
    #if !UNITY_RELEASE
    // Ensure that MainThreadCleanup calls Super::MainThreadCleanup. This should be done at the end of the function
    Assert(m_MainThreadCleanupCalled);
    #endif
}

void Object::SetIsPersistent(bool p)
{
    PROFILER_CHANGE_PERSISTANCY(GetInstanceID(), m_IsPersistent, p);
    m_IsPersistent = p;
}

void Object::SetupWeakHandle()
{
    if (m_MonoReference.HasTarget())
    {
        ScriptingObjectPtr object = m_MonoReference.Resolve();
        ScriptingGCHandle weakref(object, GCHANDLE_WEAK);
        SetCachedScriptingObject(SCRIPTING_NULL);

        object = SCRIPTING_NULL;
        m_MonoReference = weakref;
    }
}

bool Object::RevertWeakHandle()
{
    if (m_MonoReference.HasTarget())
    {
        ScriptingObjectPtr target = m_MonoReference.Resolve();
        m_MonoReference.ReleaseAndClear();
        if (target)
        {
            SetCachedScriptingObject(target);
#if ENABLE_DOTNET
            // Restore cached ptr for managed object, not sure why we don't do this for Mono as well, because we reset cachedPtr in SetupWeakHandle
            // But on Mono it seems cachedPtr persists ?!
            // Maybe it's related to cachedPtr optimization
            register ScriptingObjectOfType<Object> instance(target);
            instance.SetCachedPtr(this);
#endif
        }
        return target != SCRIPTING_NULL;
    }
    else
        return false;
}

void Object::SetCachedScriptingObject(ScriptingObjectPtr object)
{
    if (object)
    {
        Assert(!m_MonoReference.HasTarget());
        m_MonoReference.AcquireStrong(object);
        return;
    }

    if (!m_MonoReference.HasTarget())
    {
        AssertString("Dont do this");
        return;
    }

    ScriptingObjectOfType<Object> instance(m_MonoReference.Resolve());
    instance.SetCachedPtr(0);

    m_MonoReference.ReleaseAndClear();

#if ENABLE_DOTNET
    instance = ScriptingObjectPtr(SCRIPTING_NULL);
#else
    instance = (ScriptingObjectPtr)SCRIPTING_NULL;
#endif
}

void Object::RegisterDestroyedCallback(ObjectDestroyCallbackFunction* callback)
{
    gDestroyedCallbackFunc = callback;
}

///@TODO: MemLabelId -> MemLabelIdentifier.
//        Because the root object pointer will always be the object itself.
Object* Object::Produce(const Unity::Type* targetCastType, const Unity::Type* produceType, InstanceID instanceID, MemLabelId memLabel, ObjectCreationMode mode)
{
    #if ENABLE_ASSERTIONS
    switch (mode)
    {
        case kCreateObjectDefault:
        case kCreateObjectDefaultNoLock:

        #if THREADED_LOADING
            AssertMsg(Thread::EqualsCurrentThreadID(GetPersistentManager().GetMainThreadID()),
            "Cannot create on non-main thread without kCreateObjectFromNonMainThread");
        #endif

            if (mode == kCreateObjectDefault)
                AssertMsg(IDToPointer(instanceID) == NULL, "Object is already loaded");

            break;

        case kCreateObjectFromNonMainThread:
            AssertMsg(instanceID != InstanceID_None, "Cannot create on non-main thread without an instanceID");
            break;

        default:
            AssertMsg(false, "Unknown case");
            break;
    }
    #endif // ENABLE_ASSERTIONS

    // @joe says "not sure exactly why we did this. probably not necessary anymore but all our instanceID allocations are increment in even numbers." (scobi 12-jun-17)
    AssertMsg((InstanceID_AsSInt32Ref(instanceID) & 1) == 0, "Bit 0 of InstanceID is reserved");

    if (produceType == NULL)
        return NULL;

    Unity::Type::FactoryFunction* factory = produceType->GetFactory();
    if (factory == NULL)
        return NULL;

    Object* newObject = factory(memLabel, mode);
    if (newObject == NULL)
        return NULL;

    if (instanceID != InstanceID_None)
    {
        newObject->SetInstanceID(instanceID);
        CalculateCachedTypeIndex(newObject);

        if (mode == kCreateObjectDefault)
        {
            RegisterInstanceID(newObject);
            newObject->SetDirty();
        }
        else if (mode == kCreateObjectDefaultNoLock)
        {
            RegisterInstanceIDNoLock(newObject);
            newObject->SetDirty();
        }
    }
    else
    {
        if (mode == kCreateObjectDefaultNoLock)
            AllocateAndAssignInstanceIDNoLock(newObject);
        else
            AllocateAndAssignInstanceID(newObject);
    }

    // we could do this targetCastType test against produceType, but then we'd run into problems with types
    // not existing (whether by stripping or other means, such as deprecation or fwd/back compat serialization)
    // and we'd be giving potential false positives with error messages. so instead we ask the produced
    // instance its actual type, and test against that.
    if (!newObject->Is(targetCastType))
    {
        AssertString(Format("Invalid conversion of runtime type %s to static type %s",
                newObject->GetType()->GetName(), targetCastType->GetName()));

        newObject->Reset();
        DestroySingleObject(newObject);
        newObject = NULL;
    }

    return newObject;
}

void Object::CheckInstanceIDsLoaded(InstanceID* instanceIDs, int size)
{
    for (int i = 0; i < size; i++)
    {
        if (ms_IDToPointer->count(instanceIDs[i]))
            instanceIDs[i] = InstanceID_None;
    }
}

#if THREADED_LOADING

Object* InstanceIDToObjectPartiallyLoadedThreadSafe(InstanceID instanceID, bool isLoadingThread)
{
    if (!isLoadingThread)
        return PPtr<Object>(instanceID);
    else
    {
        Object* obj = Object::IDToPointerThreadSafe(instanceID);
        if (obj == NULL)
            return GetPersistentManager().GetPartiallyLoadedObject(instanceID);
        else
            return obj;
    }
}

#endif

template<class Collector>
static void FindObjectsOfTypesImplementation(Object::IDToPointerMap& map, Collector collector, const Unity::Type* type1, va_list args)
{
    CHECK_IN_MAIN_THREAD

    dynamic_array<const Unity::Type*> types(kMemTempAlloc);

    if (type1 != NULL)
        types.push_back(type1);

    while (true)
    {
        const Unity::Type* type = va_arg(args, const Unity::Type*);
        if (type == NULL)
            break;

        types.push_back(type);
    }

    for (Object::IDToPointerMap::iterator i = map.begin(); i != map.end(); ++i)
    {
        for (size_t j = 0; j < types.size(); ++j)
        {
            if (i->second->Is(types[j]))
            {
                collector(i);
                break;
            }
        }
    }
}

template<class Collector>
static void FindObjectsOfTypesImplementation(Object::IDToPointerMap& map, Collector collector, PersistentTypeID persistentTypeID1, va_list args)
{
    CHECK_IN_MAIN_THREAD

    dynamic_array<const Unity::Type*> types(kMemTempAlloc);

    const Unity::Type* type1 = Unity::Type::FindTypeByPersistentTypeID(persistentTypeID1);
    if (type1 != NULL)
        types.push_back(type1);

    while (true)
    {
        // warning: ‘PersistentTypeID’ is promoted to ‘int’ when passed through ‘...’
        // note: (so you should pass ‘int’ not ‘PersistentTypeID’ to ‘va_arg’)
        // note: if this code is reached, the program will abort
        PersistentTypeID arg = (PersistentTypeID)va_arg(args, int);
        if (arg == Unity::Type::UndefinedPersistentTypeID)
            break;

        const Unity::Type* type = Unity::Type::FindTypeByPersistentTypeID(arg);
        if (type != NULL)
            types.push_back(type);
    }

    for (Object::IDToPointerMap::iterator i = map.begin(); i != map.end(); ++i)
    {
        for (size_t j = 0; j < types.size(); ++j)
        {
            if (i->second->Is(types[j]))
            {
                collector(i);
                break;
            }
        }
    }
}

// This is an expensive operation - ensure we make it visible
PROFILER_INFORMATION(gFindObjectsOfType, "FindObjectsOfType", kProfilerOther)

template<class Collector>
static void FindObjectsOfTypeImplementation(Object::IDToPointerMap& map, const Unity::Type* type, Collector collector)
{
    PROFILER_AUTO(gFindObjectsOfType, NULL)
    CHECK_IN_MAIN_THREAD

    if (type == NULL)
        return;

    for (Object::IDToPointerMap::iterator i = map.begin(); i != map.end(); ++i)
    {
        if (i->second->Is(type))
            collector(i);
    }
}

struct InstanceIDCollector
{
    dynamic_array<InstanceID>& instanceIDs;

    InstanceIDCollector(dynamic_array<InstanceID>& _instanceIDs)
        : instanceIDs(_instanceIDs)
    {}

    void operator()(Object::IDToPointerMap::iterator iterator)
    {
        instanceIDs.push_back(iterator->first);
    }
};

struct ObjectCollector
{
    dynamic_array<Object*>& objects;

    ObjectCollector(dynamic_array<Object*>& _objects)
        : objects(_objects)
    {}

    void operator()(Object::IDToPointerMap::iterator iterator)
    {
        objects.push_back(iterator->second);
    }
};

void Object::FindInstanceIDsOfType(const Unity::Type* type, dynamic_array<InstanceID>& instanceIDs, bool sorted)
{
    InstanceIDCollector collector(instanceIDs);
    FindObjectsOfTypeImplementation(*ms_IDToPointer, type, collector);

    if (sorted)
        std::sort(instanceIDs.begin(), instanceIDs.end());
}

void Object::FindInstanceIDsOfTypes(dynamic_array<InstanceID>& instanceIDs, const Unity::Type* type1, ...)
{
    va_list args;
    va_start(args, type1);
    InstanceIDCollector collector(instanceIDs);
    FindObjectsOfTypesImplementation(*ms_IDToPointer, collector, type1, args);
    va_end(args);
}

void Object::FindObjectsOfType(const Unity::Type* type, dynamic_array<Object*>& derivedObjects, bool sorted)
{
    ObjectCollector collector(derivedObjects);
    FindObjectsOfTypeImplementation(*ms_IDToPointer, type, collector);

    if (sorted)
        std::sort(derivedObjects.begin(), derivedObjects.end(), CompareInstanceID());
}

void Object::FindObjectsOfTypes(dynamic_array<Object*>& objects, const Unity::Type* type1, ...)
{
    va_list args;
    va_start(args, type1);
    ObjectCollector collector(objects);
    FindObjectsOfTypesImplementation(*ms_IDToPointer, collector, type1, args);
    va_end(args);
}

void Object::StaticInitialize()
{
    Object::ms_IDToPointer = UNITY_NEW(Object::IDToPointerMap, gBaseObjectManagerContainer->rootLabel) (1024 * 128, gBaseObjectManagerContainer->rootLabel);

    TypeRegistrationDesc desc;
    memset(&desc, 0, sizeof(TypeRegistrationDesc));

    desc.init.className = "Object";
    desc.init.classNamespace = "";
    desc.init.module = "Core";
    desc.init.persistentTypeID = 0;
    desc.init.size = sizeof(Object);
    desc.init.derivedFromInfo.typeIndex = RTTI::DefaultTypeIndex;
    desc.init.derivedFromInfo.descendantCount = RTTI::DefaultDescendentCount;
    desc.init.isAbstract = true;

    desc.type = &TypeContainer<Object>::rtti;

    TypeManager::Get().RegisterType(desc);
}

void Object::StaticDestroy()
{
    AssertMsg(ms_IDToPointer->empty(), "All object instances wasn't destroyed before shutting down");
    UNITY_DELETE(Object::ms_IDToPointer, gBaseObjectManagerContainer->rootLabel);
}

void Object::AddEvent(EventCallback* callback, void* userData)
{
    m_EventIndex = GetEventManager().AddEvent(callback, userData, m_EventIndex);
}

void Object::RemoveEvent(EventCallback* callback, void* userData)
{
    m_EventIndex = GetEventManager().RemoveEvent(m_EventIndex, callback, userData);
}

bool Object::HasEvent(EventCallback* callback, const void* userData) const
{
    return EventManager::HasEvent(m_EventIndex, callback, userData);
}

void Object::InvokeEvent(int eventType)
{
    EventManager::InvokeEvent(m_EventIndex, this, eventType);
}

bool IsObjectAvailable(InstanceID instanceID)
{
    Object* temp = Object::IDToPointer(instanceID);
    if (temp != NULL)
        return true;

    return GetPersistentManager().IsObjectAvailable(instanceID);
}

INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(Object, EXPORTDLL, Transfer, void);

template<class TransferFunction>
void Object::Transfer(TransferFunction& transfer)
{
#if UNITY_EDITOR
    if (!transfer.IsSerializingForGameRelease() && SerializePrefabIgnoreProperties(transfer) && !transfer.GetBuildUsage().strippedPrefabObject)
    {
        UInt32 flags = m_HideFlags;
        transfer.Transfer(flags, "m_ObjectHideFlags", kHideInEditorMask);
        m_HideFlags = flags;
    }

    if (transfer.GetFlags() & kSerializeDebugProperties)
    {
        InstanceID instanceID = GetInstanceID();
        transfer.Transfer(instanceID, "m_InstanceID");

        LocalIdentifierInFileType fileID;
        if (IsPersistent())
            fileID = GetPersistentManager().GetLocalFileID(instanceID);
        else
            fileID = GetFileIDHint();

        transfer.Transfer(fileID, "m_LocalIdentfierInFile");
    }
#endif
}

#if UNITY_EDITOR

void Object::RegisterDirtyCallback(ObjectDirtyCallbackFunction* callback)
{
    gSetDirtyCallbackFunc = callback;
}

Object::ObjectDirtyCallbackFunction* Object::GetDirtyCallback()
{
    return gSetDirtyCallbackFunc;
}

void Object::BatchSetPersistentDirty(Object * const * objectsToDirty, size_t count)
{
    for (int i = 0; i < count; ++i)
    {
        // When we run out of dirty indices, make sure it stays at 1
        objectsToDirty[i]->m_DirtyIndex++;
        if (objectsToDirty[i]->m_DirtyIndex == 0)
            objectsToDirty[i]->m_DirtyIndex = 1;
    }

    if (gSetDirtyCallbackFunc)
        gSetDirtyCallbackFunc(objectsToDirty, count);
}

void Object::SetDirty()
{
    // When we run out of dirty indices, make sure it stays at 1
    m_DirtyIndex++;
    if (m_DirtyIndex == 0)
        m_DirtyIndex = 1;

    if (gSetDirtyCallbackFunc)
    {
        Object* objectsToDirty[1] = {this};
        gSetDirtyCallbackFunc(objectsToDirty, 1);
    }

    #if !UNITY_RELEASE
    m_DEBUGPersistentTypeID = GetType()->GetPersistentTypeID();
    #endif
}

void Object::ClearPersistentDirty()
{
    m_DirtyIndex = 0;
}

void Object::SetPersistentDirtyIndex(UInt32 dirtyValue)
{
    m_DirtyIndex = dirtyValue;
}

#endif


ExecutionRestrictions GetExecutionRestrictions()
{
    return gExecutionRestrictions;
}

ExecutionRestrictions SetExecutionRestrictions(ExecutionRestrictions desiredRestrictions)
{
    ASSERT_RUNNING_ON_MAIN_THREAD;

    ExecutionRestrictions originalRestrictions = gExecutionRestrictions;
    gExecutionRestrictions = desiredRestrictions;
    return originalRestrictions;
}

void delete_object_internal(Object* p)
{
    if (!p)
        return;

    delete_object_internal_step1(p);
    delete_object_internal_step2(p);
}

// This can be execute on any thread.
void delete_object_internal_step2(Object* p)
{
    MemLabelId label = p->GetMemoryLabel();
    p->~Object();
    UNITY_FREE(label, p);
}

void UnloadObject(Object* p)
{
    if (!p)
        return;

    LockObjectCreation();
    delete_object_internal(p);
    UnlockObjectCreation();
}

size_t Object::GetRuntimeMemorySize() const
{
#if ENABLE_MEM_PROFILER
    return GetMemoryProfiler()->GetRelatedMemorySize(GetMemoryLabel());
#else
    return 0;
#endif
}

int Object::GetOffsetOfInstanceIdMember()
{
    //technically in the c++ standard, using offsetof() on non POD types is not allowed.
    //we can remove this code when we kill the WinRT-non-il2cpp backend, which will be before
    //we run into a compiler where this is actually not supported.
#if __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#endif
    return offsetof(Object, m_InstanceID);
#if __clang__
#pragma clang diagnostic pop
#endif
}

#if !UNITY_RELEASE

void Object::CheckCorrectAwakeUsage(bool mustHaveCalledAwake)
{
    if (mustHaveCalledAwake && m_AwakeCalled == 0)
        AssertString(Format("Awake has not been called '%s' (%s). Figure out where the object gets created and call AwakeFromLoad correctly.", GetName(), GetTypeName()), this);

    if (m_ResetCalled == 0)
        AssertString(Format("Reset has not been called '%s' (%s). Figure out where the object gets created and call Reset correctly.", GetName(), GetTypeName()), this);

    if (m_AwakeThreadedCalled && !m_AwakeDidLoadThreadedCalled)
        AssertString(Format("AwakeFromLoadThreaded has not been called '%s' (%s). Figure out where the object gets created and call AwakeFromLoadThreaded correctly.", GetName(), GetTypeName()), this);
}

#endif // !UNITY_RELEASE
