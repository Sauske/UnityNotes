#pragma once

#include "Runtime/Threads/AtomicRefCounter.h"
#include "Runtime/Utilities/MemoryPool.h"

typedef void EventCallback (void* userData, void* sender, int eventType);

class EventManager;

// Small event entry. Keep this tight.
struct EventEntry
{
    void Create();
    void Destroy(EventManager *pEventManager);

    void PreInvoke();
    bool CanBeInvoked();
    void PostInvoke(EventManager *pEventManager);

    void*          userData;
    EventEntry*    next;
    EventCallback* callback;

private:
    AtomicRefCounter refCounter;
};

class EventManager
{
public:
    typedef EventEntry* EventIndex;

private:
    ////@TODO: Memory pool has a minimum size of 32 bytes. This one fits in 12. WHAT?
    MemoryPool m_EventPool;

    #if DEBUGMODE
    EventIndex m_InvokingEventList;
    EventIndex m_InvokingEventActiveNode;
    #endif

public:
    EventManager(MemLabelRef label);

    /// Adds an event
    /// If there is already a previous event registered, it will chain them.
    /// The reference to the event is the returned eventIndex
    EventIndex AddEvent(EventCallback* callback, void* userData, EventIndex previousIndex);

    /// Removes all events with the event index.
    void RemoveEvent(EventIndex index);

    /// Removes an event with a specific callback & userData
    /// Returns the new event or null if no events in that index exist anymore.
    /// AddEvent and RemoveEvent calls must be balanced.
    EventIndex RemoveEvent(EventIndex index, EventCallback* callback, void* userData);

    void InvokeEventNonStatic(EventIndex index, void* senderUserData, int eventType);

    void DeallocateEntry(EventEntry *eventEntry);

    /// Does the event with that specific callback and userData exist?
    static bool HasEvent(const EventIndex index, EventCallback* callback, const void* userData);

    static void InvokeEvent(EventIndex index, void* senderUserData, int eventType);

private:
    static void InvokeEventCommon(EventManager *pEventManager, EventIndex index, void* senderUserData, int eventType);
};

EventManager& GetEventManager();
