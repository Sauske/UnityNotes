#include "UnityPrefix.h"

#if ENABLE_PERFORMANCE_TESTS

#include "Runtime/Testing/PerformanceTesting.h"
#include "Runtime/Transform/Transform.h"
#include "Runtime/Graphics/Mesh/MeshRenderer.h"
#include "Runtime/Dynamics/BoxCollider.h"
#include "Runtime/Misc/GameObjectUtility.h"


PERFORMANCE_TEST_SUITE(PPtrDynamicCastPerformanceTests)
{
    template<int ComponnentCount>
    class PPtrDynamicCastPerformanceFixture
    {
    public:
        PPtrDynamicCastPerformanceFixture()
            : p(NULL)
        {
            const Unity::Type* componentTypes[] =
            {
                TypeOf<BoxCollider>(),
                TypeOf<Transform>(),
                TypeOf<MeshRenderer>()
            };

            // Shuffle components to avoid 100% hit on branch predictions
            uint32_t r = 22695477;
            for (int i = 0; i < ComponnentCount; ++i)
            {
                // Simple linear congruential generator (https://en.wikipedia.org/wiki/Linear_congruential_generator) to avoid a dependency on a random generator
                r = 1664525 * r + 1013904223;

                Object* component = Object::Produce(componentTypes[(r >> 16) % 3]);
                component->Reset();
                components[i] = dynamic_pptr_cast<Unity::Component*>(component);
            }
        }

        ~PPtrDynamicCastPerformanceFixture()
        {
            for (int i = 0; i < ComponnentCount; ++i)
            {
                DestroyObjectHighLevel(components[i]);
            }
        }

        static const int kOuterIterations = 10000;

        template<class TQuery>
        void Run()
        {
            PERFORMANCE_TEST_LOOP(kOuterIterations)
            {
                for (UInt32 nComponent = 0; nComponent < ComponnentCount; ++nComponent)
                {
                    p = dynamic_pptr_cast<TQuery*>(components[nComponent]);
                }
            }
        }

        volatile void* p;
        Unity::Component* components[ComponnentCount];
    };

    typedef PPtrDynamicCastPerformanceFixture<1024>  PPtrDynamicCast_From_Mixed_Type;

    TEST_FIXTURE(PPtrDynamicCast_From_Mixed_Type, PPtrDynamicCast_From_Mixed_To_Transform)
    {
        Run<Transform>();
    }

    TEST_FIXTURE(PPtrDynamicCast_From_Mixed_Type, PPtrDynamicCast_From_Mixed_To_Collider)
    {
        Run<Collider>();
    }

    TEST_FIXTURE(PPtrDynamicCast_From_Mixed_Type, PPtrDynamicCast_From_Mixed_To_MeshRenderer)
    {
        Run<MeshRenderer>();
    }
}

#endif
