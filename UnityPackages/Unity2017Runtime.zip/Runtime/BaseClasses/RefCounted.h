#pragma once

#include "Configuration/UnityConfigure.h"
#include "Runtime/Mono/MonoIncludes.h"
#include "Runtime/Scripting/ScriptingUtility.h"
#include "Runtime/ScriptingBackend/ScriptingApi.h"

class TrackedReferenceBase
{
public:
    ScriptingGCHandle m_MonoObjectReference;

    TrackedReferenceBase() : m_MonoObjectReference() {}

    ~TrackedReferenceBase()
    {
        if (m_MonoObjectReference.HasTarget())
        {
            ScriptingObjectPtr target = m_MonoObjectReference.Resolve();
            if (target)
            {
                void* nativePointer = 0;
                MarshallNativeStructIntoManaged(nativePointer, target);
                target = SCRIPTING_NULL;
            }

            m_MonoObjectReference.ReleaseAndClear();
        }
    }
};
