#include <new>
#include "UnityPrefix.h"
#include "EventManager.h"
#include "Runtime/Testing/Faking.h"
#include "Runtime/Utilities/RuntimeStatic.h"

////@TODO: Assert on recursive calls...

void EventEntry::Create()
{
}

void EventEntry::Destroy(EventManager *pEventManager)
{
    if (refCounter.Release())
    {
        pEventManager->DeallocateEntry(this);
    }
}

void EventEntry::PreInvoke()
{
    refCounter.Retain();
}

bool EventEntry::CanBeInvoked()
{
    return refCounter.Count() >= 2;
}

void EventEntry::PostInvoke(EventManager *pEventManager)
{
    Destroy(pEventManager);
}

RuntimeStatic<EventManager, true> s_EventManagerInstance(kMemManager);

EventManager& GetEventManager()
{
    return *s_EventManagerInstance;
}

EventManager::EventManager(MemLabelRef label)
    : m_EventPool(label, false, "EventManager", sizeof(EventEntry), 1024 * 4)
#if DEBUGMODE
    ,   m_InvokingEventList(NULL)
    ,   m_InvokingEventActiveNode(NULL)
#endif
{
}

EventManager::EventIndex EventManager::AddEvent(EventCallback* callback, void* userData, EventIndex previousIndex)
{
    EventIndex event = new(m_EventPool.Allocate())EventEntry();

    event->Create();
    event->userData = userData;
    event->callback = callback;
    event->next = previousIndex;

    return event;
}

/// Removes all events with the event index.
void EventManager::RemoveEvent(EventIndex index)
{
    while (index != NULL)
    {
        EventIndex next = index->next;
        index->Destroy(this);
        index = next;
    }
}

/// Removes an event with a specific callback & userData
/// Returns the new event or null if no events in that index exist anymore.
EventManager::EventIndex EventManager::RemoveEvent(EventIndex index, EventCallback* callback, void* userData)
{
    EventIndex previousIndex = NULL;
    EventIndex curEvent = index;
    while (curEvent != NULL)
    {
        if (curEvent->callback == callback && curEvent->userData == userData)
        {
            // While invoking we are allowed to remove the event being invoked itself but no other events on the same chain.
            #if DEBUGMODE
            Assert(m_InvokingEventList != index || m_InvokingEventActiveNode == curEvent);
            #endif

            EventIndex nextEvent = curEvent->next;
            curEvent->Destroy(this);

            if (previousIndex)
                previousIndex->next = nextEvent;

            if (index == curEvent)
                return nextEvent;
            else
                return index;
        }

        previousIndex = curEvent;

        curEvent = curEvent->next;
    }

    return index;
}

void EventManager::InvokeEventNonStatic(EventIndex index, void* senderUserData, int eventType)
{
    EventManager::InvokeEventCommon(this, index, senderUserData, eventType);
}

void EventManager::DeallocateEntry(EventEntry *eventEntry)
{
    __FAKEABLE_METHOD__(EventManager, DeallocateEntry, (eventEntry));
    m_EventPool.Deallocate(eventEntry);
}

bool EventManager::HasEvent(const EventIndex index, EventCallback* callback, const void* userData)
{
    EventIndex curIndex = index;
    while (curIndex != NULL)
    {
        if (curIndex->callback == callback && curIndex->userData == userData)
            return true;

        curIndex = curIndex->next;
    }
    return false;
}

void EventManager::InvokeEvent(EventIndex index, void* senderUserData, int eventType)
{
    InvokeEventCommon(&GetEventManager(), index, senderUserData, eventType);
}

void EventManager::InvokeEventCommon(EventManager *pEventManager, EventIndex index, void* senderUserData, int eventType)
{
#if DEBUGMODE
    pEventManager->m_InvokingEventList = index;
#endif

    EventIndex iterIndex = index;
    while (iterIndex != NULL)
    {
        iterIndex->PreInvoke();
        iterIndex = iterIndex->next;
    }

    iterIndex = index;
    while (iterIndex != NULL)
    {
#if DEBUGMODE
        pEventManager->m_InvokingEventActiveNode = iterIndex;
#endif
        EventIndex currentIndex = iterIndex;
        if (currentIndex->CanBeInvoked())
        {
            currentIndex->callback(currentIndex->userData, senderUserData, eventType);
        }
        iterIndex = currentIndex->next;
        currentIndex->PostInvoke(pEventManager);
    }

#if DEBUGMODE
    pEventManager->m_InvokingEventList = NULL;
    pEventManager->m_InvokingEventActiveNode = NULL;
#endif
}
