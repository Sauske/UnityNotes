#ifndef NAMEDOBJECT_H
#define NAMEDOBJECT_H

#include "EditorExtension.h"
#include "Runtime/Containers/ConstantString.h"

class EXPORT_COREMODULE NamedObject : public EditorExtension
{
    REGISTER_CLASS_TRAITS(kTypeIsAbstract);
    REGISTER_CLASS(NamedObject);
    DECLARE_OBJECT_SERIALIZE();
public:

    virtual char const* GetName() const { return m_Name.c_str(); }
    virtual void SetName(char const* name);


    NamedObject(MemLabelId label, ObjectCreationMode mode);

    inline void MarkGameObjectAndComponentDependencies(GarbageCollectorThreadState& gc) const {}

protected:

    ConstantString m_Name;
};

#endif
