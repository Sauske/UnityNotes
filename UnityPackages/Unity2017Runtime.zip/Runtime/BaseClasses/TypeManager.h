#pragma once

#include "Type.h"
#include "Runtime/BaseClasses/Variant.h"
#include "Runtime/BaseClasses/ObjectDefines.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Utilities/HashStringFunctions.h"
#include "Runtime/Threads/ReadWriteLock.h"
#include "Runtime/Core/Containers/hash_map.h"
#include <map>

class dynamic_bitset;

class TypeManager
{
public:
    TypeManager(RTTI::RuntimeTypeArray& runtimeTypes);
    ~TypeManager();

    // ---------------------------------------------------------------------------
    // PUBLIC API

    // TODO (scobi 21-jun-17) would like to see this concept of faking an inline wrapped up better;
    // see https://ono.unity3d.com/unity/draft/pull-request/30359/_/core/typeinfo/sendmessage#comment-207798
#if ENABLE_UNIT_TESTS
    static TypeManager& Get();
    static TypeManager& Get_Unfaked()
#else
    static TypeManager& Get()
#endif
    {
        Assert(ms_Instance != NULL);
        return *ms_Instance;
    }

    static void InitializeGlobalInstance();
    static void CleanupGlobalInstance();

    void InitializeAllTypes();
    void CallInitializeTypes();
    void CallPostInitializeTypes();
    void CleanupAllTypes();

    void RegisterReservedPersistentTypeID(PersistentTypeID id, const char* name);
    void RegisterType(const TypeRegistrationDesc& desc);

    // this is intended to be used by general code, so we're going to automatically pull RTTI from static data to keep general code needing to understand type system internals
    template<typename T>
    void RegisterType(PersistentTypeID typeID, const char* name, const char* nameSpace)
    {
        TypeRegistrationDesc desc = TYPEREGISTRATIONDESC_DEFAULT_INITIALIZER_LIST;
        desc.type = &TypeContainer<T>::rtti;
        desc.init.persistentTypeID = typeID;
        desc.init.className = name;
        desc.init.classNamespace = nameSpace;
        desc.init.attributes = RegisterAttributes<T>(desc.init.attributeCount);
        RegisterType(desc);
    }

    template<typename T, typename Base>
    void RegisterType(PersistentTypeID typeID, const char* name, const char* nameSpace)
    {
        TypeRegistrationDesc desc = TYPEREGISTRATIONDESC_DEFAULT_INITIALIZER_LIST;
        desc.type = &TypeContainer<T>::rtti;
        desc.init.base = &TypeContainer<Base>::rtti;
        desc.init.persistentTypeID = typeID;
        desc.init.className = name;
        desc.init.classNamespace = nameSpace;
        desc.init.attributes = RegisterAttributes<T>(desc.init.attributeCount);
        RegisterType(desc);
    }

    // Convenience methods that wraps RegisterType(...)
    void RegisterStrippedType(PersistentTypeID typeID, RTTI* type, const char* name, const char* nameSpace);
    void RegisterNonObjectType(PersistentTypeID typeID, RTTI* destinationRTTI, const char* name, const char* nameSpace);

    // ------------------------------------------------------------------------
    // INTERNAL API - Used only by Unity::Type and Tests

    const RTTI* RuntimeTypeIndexToRTTI(UInt32 typeIndex) const { DebugAssert(typeIndex < m_RuntimeTypes.Count); return m_RuntimeTypes.Types[typeIndex]; }
    const RTTI* PersistentTypeIDToRTTI(PersistentTypeID persistentTypeID) const;
    const RTTI* ClassNameToRTTI(const char* name, bool caseInsensitive = false) const;
    void FindAllRTTIDerivedTypes(const RTTI* baseType, dynamic_array<const RTTI*>& derivedTypes, bool onlyNonAbstract) const;
    void FindAllRTTIDerivedTypes(PersistentTypeID persistentTypeID, dynamic_array<PersistentTypeID>& derivedClasses, bool onlyNonAbstract) const;
    const RTTI* GetDeserializationRTTIStubForPersistentTypeID(PersistentTypeID typeID);
    UInt32 TypeCount() const { return m_RuntimeTypes.Count; }
    typedef core::hash_map<const Unity::Type*, ::detail::AttributeMapEntry*> AttributeLookupMap;
    static AttributeLookupMap CreateAttributeLookupMap();
    static void RegisterTypeInGlobalAttributeMap(const RTTI& rtti, const AttributeLookupMap& attrLookupMap);

private:
    class Builder;

    struct TypeCallbackStruct
    {
        TypeCallback* initType;
        TypeCallback* postInitType;
        TypeCallback* cleanupType;

        TypeCallbackStruct()
        {
            initType = postInitType = cleanupType = NULL;
        }
    };

    struct HashFunctorPersistentTypeID
    {
        size_t operator()(PersistentTypeID data) const
        {
            return ComputeIntHash(data);
        }
    };

    struct ConstCharPtrHashFunctor
    {
        size_t operator()(const char* str) const
        {
            return ComputeShortStringHash32(str);
        }
    };

    struct ConstCharPtrEqualTo
    {
        bool operator()(const char* a, const char* b) const
        {
            return a == b || (a != NULL && b != NULL && strcmp(a, b) == 0);
        }
    };

    typedef std::map<PersistentTypeID, TypeCallbackStruct> TypeCallbacks;

    typedef core::hash_map<const char*, const RTTI*, ConstCharPtrHashFunctor, ConstCharPtrEqualTo> StringToTypeMap;

    typedef core::hash_map<PersistentTypeID, RTTI*, HashFunctorPersistentTypeID> RTTIMap;

    typedef core::hash_map<PersistentTypeID, const char*, HashFunctorPersistentTypeID> ReservedTypeIDMap;

    typedef core::hash_map<PersistentTypeID, RTTI*, HashFunctorPersistentTypeID> DeserializationStubMap;


    void FatalErrorOnPersistentTypeIDConflict(PersistentTypeID typeID, const char* name);
    void InitializeDerivedFromInfoAndRegisterAttributes();

    static TypeManager* ms_Instance;

    RTTI::RuntimeTypeArray& m_RuntimeTypes;
    TypeCallbacks m_TypeCallbacks;
    StringToTypeMap m_StringToType;
    RTTIMap m_RTTI;
    ReservedTypeIDMap m_ReservedTypeIDs;

    mutable ReadWriteLock m_DeserializationStubMapLock;
    DeserializationStubMap m_DeserializationStubMap;
};
