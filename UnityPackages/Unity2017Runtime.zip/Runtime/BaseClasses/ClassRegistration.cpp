#include "UnityPrefix.h"
#include "Runtime/BaseClasses/BaseObject.h"
#include "Runtime/Modules/ModuleRegistration.h"
#include "Runtime/BaseClasses/TypeManager.h"

#if SUPPORTS_GRANULAR_CLASS_REGISTRATION
// In case of granular class registration, calls are auto-generated.
#define RegisterAllClasses RegisterAllClassesGranular
#endif


#define RESERVE_TYPEID(klass, persistentTypeID)            TypeManager::Get().RegisterReservedPersistentTypeID (persistentTypeID, #klass);
#define RESERVE_DEPRECATED_TYPEID(klass, persistentTypeID) TypeManager::Get().RegisterReservedPersistentTypeID (persistentTypeID, #klass);


#if DEBUGMODE
void RegisterDeprecatedTypeIDs()
{
    /// DO NOT REMOVE CLASS IDS FROM THIS LIST TO MAKE ROOM FOR A NEW ONE. IT WILL RESULT IN CLASSID CONFLICTS ON OLD PROJECTS

    RESERVE_DEPRECATED_TYPEID(BehaviourManager, 7)  // Removed in Unity 3.2
    RESERVE_DEPRECATED_TYPEID(Filter, 16)  // Removed ages ago
    RESERVE_DEPRECATED_TYPEID(Pipeline, 17)  // Removed in Unity 5.0, Deprecated and non-functional for much longer.
    RESERVE_DEPRECATED_TYPEID(PipelineManager, 31)     // Removed in Unity 3.2
    RESERVE_DEPRECATED_TYPEID(BaseBehaviourManager, 34)    // Removed in Unity 3.2
    RESERVE_DEPRECATED_TYPEID(LateBehaviourManager, 35)   // Removed in Unity 3.2
    RESERVE_DEPRECATED_TYPEID(FixedBehaviourManager, 46)   // Removed in Unity 3.2
    RESERVE_DEPRECATED_TYPEID(UpdateManager, 63)   // Removed in Unity 3.2
    RESERVE_DEPRECATED_TYPEID(RenderLayer, 67)  // Intermediate abstract class refactored away post-Unity 3.2
    RESERVE_DEPRECATED_TYPEID(AnimationTrack2, 112)
    RESERVE_DEPRECATED_TYPEID(ResourceManagerOLD, 113)
    RESERVE_DEPRECATED_TYPEID(GooballCollider, 77)
    RESERVE_DEPRECATED_TYPEID(VertexSnapper, 79)
    RESERVE_DEPRECATED_TYPEID(LightManager, 85)  // -> changed id DO NOT REUSE
    //RESERVE_DEPRECATED_TYPEID (PreloadManager, 90) // Now used by Avatar
    //RESERVE_DEPRECATED_TYPEID (ScaleFilter, 91) // deprecated pre 1.0, now used by AnimatorController
    //RESERVE_DEPRECATED_TYPEID (TextureRect, 93) // Now used by RuntimeAnimatorController
    //RESERVE_DEPRECATED_TYPEID (MotorJoint, 95) // Now used by Animator
    RESERVE_DEPRECATED_TYPEID(Decal, 97)  // Pre 1.0
    RESERVE_DEPRECATED_TYPEID(EulerRotationMotor, 139)
    RESERVE_DEPRECATED_TYPEID(ParticleCloudColor, 103)  // Pre 1.0
    RESERVE_DEPRECATED_TYPEID(TextScript, 105)
    RESERVE_DEPRECATED_TYPEID(VertexProgram, 106)
    RESERVE_DEPRECATED_TYPEID(FragmentProgram, 107)
    RESERVE_DEPRECATED_TYPEID(GooStickyness, 151)
    RESERVE_DEPRECATED_TYPEID(ClothAnimator, 99)  // PRE 1.0
    RESERVE_DEPRECATED_TYPEID(PatchRenderer, 100)  // PRE 1.0
    RESERVE_DEPRECATED_TYPEID(Stretcher, 101)  // PRE 1.0
    RESERVE_DEPRECATED_TYPEID(AudioManager, 80)  // -> changed id DO NOT REUSE
    //RESERVE_DEPRECATED_TYPEID (AxisRenderer, 1008) // REMOVED in 2.0, now used by ComputeShaderImporter
    RESERVE_DEPRECATED_TYPEID(BBoxRenderer, 1009)  // REMOVED in 2.0
    RESERVE_DEPRECATED_TYPEID(CopyTransform, 1010)  // REMOVED in 2.1
    //RESERVE_DEPRECATED_TYPEID (DotRenderer, 1011) // REMOVED in 2.0, now used by AvatarMask
    RESERVE_DEPRECATED_TYPEID(AvatarMask, 1011)  // changed id in 5.6, AvatarMask is now a runtime class
    RESERVE_DEPRECATED_TYPEID(SphereRenderer, 1012)  // Not here anymore
    RESERVE_DEPRECATED_TYPEID(WireRenderer, 1024)  // Removed in 2.0
    RESERVE_DEPRECATED_TYPEID(AnimationManager, 71)  // Removed in 4.3
    RESERVE_DEPRECATED_TYPEID(LightProbesLegacy, 197)  // Removed in 5.0
}

void RegisterReservedTypeIDs()
{
}

typedef std::set<PersistentTypeID, std::less<PersistentTypeID>, STL_ALLOCATOR(kMemBaseObject, PersistentTypeID)> RegisteredClassSet;

RegisteredClassSet* gVerifyRegisteredClasses = NULL;

static RegisteredClassSet& GetVerifyClassRegistration()
{
    if (gVerifyRegisteredClasses == NULL)
    {
        gVerifyRegisteredClasses = UNITY_NEW_AS_ROOT_NO_LABEL(RegisteredClassSet(), kMemBaseObject, "Managers", "Class Registration");
    }
    return *gVerifyRegisteredClasses;
}

void AddVerifyClassRegistration(PersistentTypeID type)    // NOTE : prototype defined in ObjectDefines.h
{
    SET_ALLOC_OWNER(CreateMemLabel(kMemBaseObject, &GetVerifyClassRegistration()));
    GetVerifyClassRegistration().insert(type);
}

void CleanupVerifyClassRegistration()
{
    if (gVerifyRegisteredClasses != NULL)
    {
        UNITY_DELETE(gVerifyRegisteredClasses, kMemBaseObject); // allocated on first access
        gVerifyRegisteredClasses = NULL;
    }
}

static void VerifyThatAllClassesHaveBeenRegistered()
{
    const RegisteredClassSet& types = GetVerifyClassRegistration();

    for (RegisteredClassSet::const_iterator i = types.begin(); i != types.end(); ++i)
    {
        if (Unity::Type::FindTypeByPersistentTypeID(*i) == NULL)
            FatalErrorString(Format("Class with persistent type id 0x%08X has not been registered but is included in the build. You must add the class to RegisterAllClasses.", *i));
    }
}

#endif

#define UNITY_KERNEL_CLASS(...) PP_VARG_SELECT_OVERLOAD(UNITY_KERNEL_CLASS_,(__VA_ARGS__))

// Forward declarations
#define UNITY_KERNEL_CLASS_1(x) class x; template <> void RegisterClass<x>();
#define UNITY_KERNEL_CLASS_2(ns, x) namespace ns { class x; } template<> void RegisterClass<ns::x>();
#define UNITY_KERNEL_BUILTIN(x, persistentTypeID)
#define UNITY_KERNEL_NONHIERARCHY_CLASS(x, persistentTypeID) class x;
#define UNITY_KERNEL_STRUCT(x, persistentTypeID) struct x;
#include "ClassRegistration.inc.h"
#undef UNITY_KERNEL_STRUCT
#undef UNITY_KERNEL_NONHIERARCHY_CLASS
#undef UNITY_KERNEL_BUILTIN
#undef UNITY_KERNEL_CLASS_1
#undef UNITY_KERNEL_CLASS_2

void RegisterBuiltinTypes()
{
#define UNITY_KERNEL_CLASS_1(x)
#define UNITY_KERNEL_CLASS_2(ns, x)
#define UNITY_KERNEL_BUILTIN(x, persistentTypeID) \
    { \
        TypeManager::Get().RegisterNonObjectType(static_cast<PersistentTypeID>(persistentTypeID), &TypeContainer<x>::rtti, #x, ""); \
    }
#define UNITY_KERNEL_NONHIERARCHY_CLASS(x, persistentTypeID) UNITY_KERNEL_BUILTIN(x, persistentTypeID)
#define UNITY_KERNEL_STRUCT(x, persistentTypeID) UNITY_KERNEL_BUILTIN(x, persistentTypeID)
#include "ClassRegistration.inc.h"
#undef UNITY_KERNEL_STRUCT
#undef UNITY_KERNEL_NONHIERARCHY_CLASS
#undef UNITY_KERNEL_BUILTIN
#undef UNITY_KERNEL_CLASS_1
#undef UNITY_KERNEL_CLASS_2
}

// Stripped class registration
#define UNITY_KERNEL_CLASS_1(x) \
    template<> void RegisterStrippedType<x>(PersistentTypeID inPersistentTypeID, const char* inName, const char* inNamespace) \
    { \
        TypeManager::Get().RegisterStrippedType(inPersistentTypeID, &TypeContainer<x>::rtti, inName, inNamespace);\
    }
#define UNITY_KERNEL_CLASS_2(ns, x) UNITY_KERNEL_CLASS_1(ns::x)
#define UNITY_KERNEL_BUILTIN(x, persistentTypeID)
#define UNITY_KERNEL_NONHIERARCHY_CLASS(x, persistentTypeID)
#define UNITY_KERNEL_STRUCT(x, persistentTypeID)
#include "ClassRegistration.inc.h"
#undef UNITY_KERNEL_STRUCT
#undef UNITY_KERNEL_NONHIERARCHY_CLASS
#undef UNITY_KERNEL_BUILTIN
#undef UNITY_KERNEL_CLASS_1
#undef UNITY_KERNEL_CLASS_2

void RegisterAllClasses()
{
#if DEBUGMODE
    RegisterDeprecatedTypeIDs();
    RegisterReservedTypeIDs();
#endif

    RegisterBuiltinTypes();

    // NOTE: Add the class registration to the ClassRegistration.inc file

#define UNITY_KERNEL_CLASS_1(x) RegisterClass<x>();
#define UNITY_KERNEL_CLASS_2(ns, x) RegisterClass<ns::x>();
#define UNITY_KERNEL_BUILTIN(x, persistentTypeID)
#define UNITY_KERNEL_NONHIERARCHY_CLASS(x, persistentTypeID)
#define UNITY_KERNEL_STRUCT(x, persistentTypeID)
#include "ClassRegistration.inc.h"
#undef UNITY_KERNEL_CLASS_1
#undef UNITY_KERNEL_CLASS_2


#if SUPPORTS_GRANULAR_CLASS_REGISTRATION
    void InvokeRegisterStaticallyLinkedModuleClasses();
    InvokeRegisterStaticallyLinkedModuleClasses();
#else
    ModuleManager::Get().EnsureModulesRegistered();
#endif

#if DEBUGMODE
    VerifyThatAllClassesHaveBeenRegistered();
#endif
}

#undef UNITY_KERNEL_CLASS
