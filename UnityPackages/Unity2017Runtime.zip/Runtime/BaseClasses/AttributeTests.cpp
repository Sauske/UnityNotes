#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "AttributeContainer.h"
#include "Attribute.h"
#include "Runtime/Testing/TemplatedTest.h"
#include "TypeManager.h"


UNIT_TEST_SUITE(Attribute)
{
    // Need to define this here even though it is in ObjectDefines.h since the suite
    // is in its own namespace an the attribute registration below does a partial
    // specialization that wouldn't work without this.
    template<typename T>
    const ConstVariantRef* RegisterAttributes(size_t& attributeCountOut)
    {
        attributeCountOut = 0;
        return NULL;
    }

    struct NonExistingEmptyAttribute {};
    struct NonExistingNonEmptyAttribute { char data; };

    class TestDummyAttribute {};

    class TestIntArgumentAttribute
    {
    public:
        TestIntArgumentAttribute(int value) : value(value)
        {
        }

        int value;
    };

    class AClassWithTestIntArgumentAttribute {};

    const int kTestIntArgument1 = 99;

    REGISTER_TYPE_ATTRIBUTES(AClassWithTestIntArgumentAttribute,
        (TestIntArgument, (kTestIntArgument1))
        );

    class TestTypeArgumentAttribute
    {
    public:
        TestTypeArgumentAttribute(const Unity::Type* value) : value(value)
        {
        }

        const Unity::Type* value;
    };

    class AClassWithTestTypeArgumentAttributeAndTestIntArgumentAttribute {};

    // Returns an unused runtime type index that can be use in tests
    RuntimeTypeIndex GetUniqueRuntimeTypeIndex()
    {
        static RuntimeTypeIndex s_index = RTTI::RuntimeTypeArray::MAX_RUNTIME_TYPES - 1;
        AssertMsg(s_index > TypeManager::Get().TypeCount(), "Too many unique runtime indices used in tests. Rewrite tests to reduce runtime indices.");
        return s_index--;
    }

    REGISTER_TYPE_ATTRIBUTES(AClassWithTestTypeArgumentAttributeAndTestIntArgumentAttribute,
        (TestIntArgument, (kTestIntArgument1))
            (TestTypeArgument, (TypeOf<int>()))
        );

    TEST(AClass_WithATestIntArgumentAttribute_WillRegisterTheAttribute)
    {
        size_t attributeCount = 0;
        const ConstVariantRef* attributes = RegisterAttributes<AClassWithTestIntArgumentAttribute>(attributeCount);
        CHECK_EQUAL(1, attributeCount);

        const ConstVariantRef& v = attributes[0];
        CHECK_EQUAL(TypeOf<TestIntArgumentAttribute>(), v.GetType());
        CHECK_EQUAL(kTestIntArgument1, v.Get<TestIntArgumentAttribute>().value);
    }

    TEST(IntType_FindAttributeUsingTestDummyAttribute_ReturnsNoAttribute)
    {
        // CHECK_NULL doesn't support null check on const * so we need to const_cast
        CHECK(!TypeOf<int>()->HasAttribute<SuiteAttributekUnitTestCategory::TestDummyAttribute>());
    }

    TEST(AClassWithTestIntArgumentAttribute_FindAttributeUsingTestIntArgumentAttribute_ReturnsExpectedAttribute)
    {
        TypeManager::AttributeLookupMap attrLookupMap = TypeManager::CreateAttributeLookupMap();
        Unity::Type testType;
        RTTI& rtti = reinterpret_cast<RTTI&>(testType);
        rtti.attributes = RegisterAttributes<AClassWithTestIntArgumentAttribute>(rtti.attributeCount);
        rtti.derivedFromInfo.typeIndex = GetUniqueRuntimeTypeIndex();
        TypeManager::RegisterTypeInGlobalAttributeMap(rtti, attrLookupMap);

        const TestIntArgumentAttribute * a = testType.FindAttribute<TestIntArgumentAttribute>();
        // CHECK_NOT_NULL doesn't support null check on const * so we need to const_cast
        CHECK_NOT_NULL(const_cast<TestIntArgumentAttribute*>(a));
        CHECK_EQUAL(kTestIntArgument1, a->value);

        CHECK(testType.HasAttribute<TestIntArgumentAttribute>());
    }

    TEST(AClassWithTestIntArgumentAttribute_GetAttributesOnType_ReturnsExpectedAttribute)
    {
        Unity::Type testType;
        RTTI& rtti = reinterpret_cast<RTTI&>(testType);
        rtti.attributes = RegisterAttributes<AClassWithTestIntArgumentAttribute>(rtti.attributeCount);

        Unity::TypeAttributes attributes;
        testType.GetAttributes(attributes);
        CHECK(attributes.begin() != attributes.end());
        CHECK(++(attributes.begin()) == attributes.end());
        const TestIntArgumentAttribute * a = testType.FindAttribute<TestIntArgumentAttribute>();
        ConstVariantRef avar(*a);
        Unity::TypeAttributes::const_iterator i = std::find(attributes.begin(), attributes.end(), avar);
        CHECK(i != attributes.end());
    }

    TEST(AClassWithTestTypeArgumentAttributeAndTestIntArgumentAttribute_GetAttributesOnType_ReturnsExpectedAttribute)
    {
        Unity::Type testType;
        RTTI& rtti = reinterpret_cast<RTTI&>(testType);
        rtti.attributes = RegisterAttributes<AClassWithTestTypeArgumentAttributeAndTestIntArgumentAttribute>(rtti.attributeCount);

        Unity::TypeAttributes attributes;
        testType.GetAttributes(attributes);
        CHECK(attributes.begin() != attributes.end());
        CHECK(++(attributes.begin()) != attributes.end());
        CHECK(++(++(attributes.begin())) == attributes.end());

        const TestIntArgumentAttribute * a1 = testType.FindAttribute<TestIntArgumentAttribute>();
        ConstVariantRef a1var(*a1);
        Unity::TypeAttributes::const_iterator i = std::find(attributes.begin(), attributes.end(), a1var);
        CHECK(i != attributes.end());

        const TestTypeArgumentAttribute * a2 = testType.FindAttribute<TestTypeArgumentAttribute>();
        ConstVariantRef a2var(*a2);
        i = std::find(attributes.begin(), attributes.end(), a2var);
        CHECK(i != attributes.end());
    }

    TEST(AClass_WithAnIntArgumentAttributeAndTestTypeArgumentAttribute_WillRegisterBothAttributes)
    {
        size_t attributeCount = 0;
        const ConstVariantRef* attributes = RegisterAttributes<AClassWithTestTypeArgumentAttributeAndTestIntArgumentAttribute>(attributeCount);
        CHECK_EQUAL(2, attributeCount);

        const ConstVariantRef& v1 = attributes[0];
        CHECK_EQUAL(TypeOf<TestIntArgumentAttribute>(), v1.GetType());
        CHECK_EQUAL(kTestIntArgument1, v1.Get<TestIntArgumentAttribute>().value);

        const ConstVariantRef& v2 = attributes[1];
        CHECK_EQUAL(TypeOf<TestTypeArgumentAttribute>(), v2.GetType());
        CHECK_EQUAL(TypeOf<int>(), v2.Get<TestTypeArgumentAttribute>().value);
    }

    TEST(AClass_WithAnIntArgumentAttributeAndTestTypeArgumentAttribute_HasAttributeReturnsExpected)
    {
        TypeManager::AttributeLookupMap attrLookupMap = TypeManager::CreateAttributeLookupMap();
        Unity::Type testType;
        RTTI& rtti = reinterpret_cast<RTTI&>(testType);
        rtti.attributes = RegisterAttributes<AClassWithTestTypeArgumentAttributeAndTestIntArgumentAttribute>(rtti.attributeCount);
        rtti.derivedFromInfo.typeIndex = GetUniqueRuntimeTypeIndex();
        TypeManager::RegisterTypeInGlobalAttributeMap(rtti, attrLookupMap);
        CHECK(testType.HasAttribute<TestIntArgumentAttribute>());
        CHECK(testType.HasAttribute<TestTypeArgumentAttribute>());
        CHECK(!testType.HasAttribute<TestDummyAttribute>());
    }
}

INTEGRATION_TEST_SUITE(Attribute)
{
    TEST(AClassWithNoAttributes_GetAttributesOnType_ReturnsNoAttributes)
    {
        Unity::TypeAttributes attributes;
        TypeOf<int>()->GetAttributes(attributes);
        CHECK(attributes.begin() == attributes.end());
    }

    TEMPLATED_TEST(AnAttributeNoAssociatedWithAnyType_GetAllAttributes_ReturnsEmptyContainer, TAttribute)
    {
        Unity::AllAttributes<TAttribute> attributes = Unity::Type::GetAllAttributes<TAttribute>();
        CHECK(attributes.begin() == attributes.end());
    }

    INSTANTIATE_TEMPLATED_TEST(AnAttributeNoAssociatedWithAnyType_GetAllAttributes_ReturnsEmptyContainer, (SuiteAttributekUnitTestCategory::NonExistingEmptyAttribute));
    INSTANTIATE_TEMPLATED_TEST(AnAttributeNoAssociatedWithAnyType_GetAllAttributes_ReturnsEmptyContainer, (SuiteAttributekUnitTestCategory::NonExistingNonEmptyAttribute));

    TEST(AttributesRegistered_GetAttributeCount_CanBeUsedToIndexAllAttributes)
    {
        UInt32 typeCount = Unity::Type::GetTypeCount();
        for (UInt32 i = 0; i < typeCount; ++i)
        {
            const Unity::Type* t1 = Unity::Type::GetTypeByRuntimeTypeIndex(i);
            size_t count = t1->GetAttributeCount();
            for (size_t j = 0; j < count; ++j)
            {
                CHECK(t1->GetAttribute(j).HasValue());
            }
        }
    }

    TEST(AttributesRegistered_GetAttributes_CanBeIterated)
    {
        UInt32 typeCount = Unity::Type::GetTypeCount();
        for (UInt32 i = 0; i < typeCount; ++i)
        {
            const Unity::Type* t1 = Unity::Type::GetTypeByRuntimeTypeIndex(i);
            Unity::TypeAttributes attributes;
            t1->GetAttributes(attributes);
            for (Unity::TypeAttributes::const_iterator j = attributes.begin(); j != attributes.end(); ++j)
            {
                CHECK_NOT_NULL(const_cast<Unity::Type*>(j.GetType()));
                CHECK(j->HasValue());
            }
        }
    }
}

#endif // ENABLE_UNIT_TESTS
