#pragma once

#include <map>
#include "Runtime/Threads/Mutex.h"
#include "GameManager.h"

enum BitMasks
{
    // Can't modify these without breaking backwards compatibility!
    kDefaultLayer = 0,
    kNoFXLayer = 1,
    kIgnoreRaycastLayer = 2,
    kIgnoreCollisionLayer = 3,
    kWaterLayer = 4,
    kUILayer = 5,
    kNumLayers = 32,

    kDefaultLayerMask = 1 << kDefaultLayer,
    kNoFXLayerMask = 1 << kNoFXLayer,
    kIgnoreRaycastMask = 1 << kIgnoreRaycastLayer,
    kIgnoreCollisionMask = 1 << kIgnoreCollisionLayer,
    kPreUnity2UnusedLayer = 1 << 5,

    kDefaultRaycastLayers = ~kIgnoreRaycastMask,

    kUserLayer = 8,
};

enum Tags
{
    kUntagged = 0,
    kRespawnTag = 1,
    kFinishTag = 2,
    kEditorOnlyTag = 3,
    kMainCameraTag = 5,
    kPlayerTag = 6,
    kGameControllerTag = 7,
    kFirstUserTag = 20000,
    kLastUserTag = 30000,
    kUndefinedTag = -1
};

static const UInt64 kDefaultSceneCullingMask = 1ULL << 63;

struct SortingLayerEntry
{
    DECLARE_SERIALIZE_NO_PPTR(SortingLayerEntry)

    SortingLayerEntry() : uniqueID(1), locked(false) {}
    core::string name;
    UInt32 uniqueID;
    bool locked;
};

typedef std::pair<const UInt32, core::string> UInt32StringPair;
typedef std::map<UInt32, core::string, std::less<UInt32>, STL_ALLOCATOR(kMemPermanent, UInt32StringPair)> UnsignedToString;

typedef std::pair<const core::string, UInt32> StringUInt32Pair;
typedef std::map<core::string, UInt32, std::less<core::string>, STL_ALLOCATOR(kMemPermanent, StringUInt32Pair)> StringToUnsigned;

class TagManager FINAL : public GlobalGameManager
{
    REGISTER_CLASS_TRAITS(kTypeIsSealed);
    REGISTER_CLASS(TagManager);
    DECLARE_OBJECT_SERIALIZE();
protected:
    StringToUnsigned* m_StringToTag;
    UnsignedToString* m_TagToString;
    MemLabelRootId* m_TagManagerContainer;

    StringToUnsigned* m_StringToMask;
    core::string m_MaskToString[32];
#if UNITY_EDITOR
    Mutex m_TagToStringMutex;
    int m_LockedPickingLayers;
#endif

public:
    TagManager(MemLabelId label, ObjectCreationMode mode);

    virtual void Reset();

    bool ShouldIgnoreInGarbageDependencyTracking();

    void AddDefaultLayerIfNeeded();
    void FindDefaultLayerIndex();

    dynamic_array<SortingLayerEntry> m_SortingLayers;
    int m_DefaultLayerIndex;

public:
    void RegisterTag(UInt32 tag, const core::string& name);
    void RegisterLayer(UInt32 layer, const core::string& name);
    void RegisterDefaultTagsAndLayerMasks();

    UInt32 StringToTag(const core::string& tag);
    const core::string& TagToString(UInt32 tag);
#if UNITY_EDITOR
    UInt32 StringToTagAddIfUnavailable(const core::string& tag);
    void RemoveTag(const core::string& tag);
#endif
    UInt32 StringToLayer(const core::string& layer);
    const core::string& LayerToString(UInt32 layer);

    UnsignedToString GetTags();

public:
    // -------------------------------------------------------------------
    // Sorting layers:
    //
    // Can be reordered in the inspector. The drawing order is as shown in the inspector.
    // Internally each sorting layer has "unique ID" (GUID hashed into an int), and in-editor Renderers that want to
    // use them refer to the layer by this ID.

    int GetSortingLayerCount();
    core::string GetSortingLayerName(int index);
    core::string GetSortingLayerNameFromUniqueID(int id);
    core::string GetSortingLayerNameFromValue(int layerValue);

    int GetSortingLayerUniqueID(int index);
    int GetSortingLayerUniqueIDFromValue(int layerValue);
    int GetSortingLayerUniqueIDFromName(const core::string& name);

    int GetSortingLayerIndexFromValue(int layerValue);

    // these return final sorting layer values
    // (i.e. zero is always "default" - the returned value can be negative or positive)
    int GetSortingLayerValueFromUniqueID(int id);
    int GetSortingLayerValueFromName(const core::string& name);

    bool IsSortingLayerUniqueIDValid(int id);

#if UNITY_EDITOR
    void SetSortingLayerName(int index, const core::string& name);
    void AddSortingLayer();
    void UpdateSortingLayersOrder();
    void SetSortingLayerLocked(int index, bool locked);
    bool GetSortingLayerLocked(int index);
    bool IsSortingLayerDefault(int index);
    void SwapSortingLayers(int idx1, int idx2);

    void SetLockedPickingLayers(int lockedPickingLayers);
    int GetLockedPickingLayers();
#endif // #if UNITY_EDITOR
};

TagManager& GetTagManager();
