#include "UnityPrefix.h"
#include "ManagerContextLoading.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Serialize/PersistentManager.h"
#include "Runtime/Serialize/SerializedFile.h"
#include "Runtime/Misc/GameObjectUtility.h"
#include "Runtime/BaseClasses/ManagerContext.h"
#include "Runtime/Serialize/AwakeFromLoadQueue.h"
#include "Runtime/Serialize/LoadProgress.h"
#include "Runtime/BaseClasses/GameManager.h"
#include "Runtime/Utilities/StaticAssert.h"
#include "Runtime/PreloadManager/PreloadData.h"
#include "Runtime/SceneManager/SceneManager.h"


PROFILER_INFORMATION(gCollectGameManagers, "CollectGameManagers", kProfilerLoading)

void CollectLevelGameManagers(InstanceIDArray& outputObjects, bool stripManagersNotNeededForBuild)
{
    PROFILER_AUTO(gCollectGameManagers, NULL);
    const ManagerContext& context = GetManagerContext();
    for (int i = 0; i < ManagerContext::kManagerCount; i++)
    {
        #if !UNITY_EDITOR
        // In players we might have stripped all managers
        if (!context.m_Managers[i])
            continue;
        #endif

        Object& object = *context.m_Managers[i];
        if (object.Is<LevelGameManager>())
        {
            Assert(!object.IsPersistent() && !object.TestHideFlag(Object::kDontSaveInEditor));
            if (!stripManagersNotNeededForBuild || ((LevelGameManager&)object).ShouldWriteForBuild())
                outputObjects.push_back(object.GetInstanceID());
        }
    }
}

static InstanceID GetGlobalManagerInstanceID(const core::string& path, int managerIndex)
{
    InstanceID instanceID = GetPersistentManager().GetInstanceIDFromPathAndFileID(path, managerIndex + 1);
    return instanceID;
}

PROFILER_INFORMATION(kProfileLoadManager, "Loading Manager", kProfilerLoading);
static Object* LoadManager(const core::string& path, int managerIndex)
{
    PROFILER_AUTO(kProfileLoadManager, NULL);
    Object* obj = dynamic_instanceID_cast<Object*>(GetGlobalManagerInstanceID(path, managerIndex));
    return obj;
}

core::string PlayerLoadSettingsAndInput(const core::string& globalManagerPath)
{
    ManagerContext::Managers loadManagers[] =
    {
        ManagerContext::kPlayerSettings,
        ManagerContext::kInputManager,
        ManagerContext::kBuildSettings,
        ManagerContext::kGraphicsSettings,
        ManagerContext::kQualitySettings,
        ManagerContext::kRuntimeInitializeOnLoadManager,
    };

    const ManagerContext& ctx = GetManagerContext();
    for (size_t i = 0; i < sizeof(loadManagers) / sizeof(loadManagers[0]); ++i)
    {
        int index = loadManagers[i];
        SetManagerPtrInContext(index, LoadManager(globalManagerPath, index));
        if (ctx.m_Managers[index] == NULL || !ctx.m_Managers[index]->Is(ctx.m_ManagerTypes[index]))
            return Format("Failed to load %s (internal index #%i).\r\nMost likely data file is corrupted, or built with mismatching\r\neditor and platform support versions.", ctx.m_ManagerTypes[index]->GetName(), index);
    }

    return core::string();
}

PROFILER_INFORMATION(kProfileGlobalManagerLoad, "Loading Gloabl Managers", kProfilerLoading);
core::string PlayerLoadGlobalManagers(const char* globalManagerPath, const char* globalManagerAssetPath, GlobalManagerMaskType loadManagerMask)
{
    PROFILER_AUTO(kProfileGlobalManagerLoad, NULL);
    PersistentManager& pm = GetPersistentManager();

    // Load game managers according to load mask! All global game managers are coming first in the main data
    // (Global game managers have to be loaded before selecting the screen resolution.
    // ProjectSettings is used by screen selector and RenderManager, InputManager by screen switching)
    GlobalManagerMaskType runningMaskForTest = 1U;
    for (int i = 0; i < ManagerContext::kGlobalManagerCount; i++, runningMaskForTest <<= 1)
    {
        if ((loadManagerMask & runningMaskForTest) == 0)
            continue;

        // Skip managers which have been stripped from the build
        if (GetManagerContext().m_ManagerTypes[i] == NULL)
            continue;

        Object* manager = LoadManager(globalManagerPath, i);
        SetManagerPtrInContext(i, manager);
    }

    // Load global manager dependencies
    PreloadData* preload = dynamic_instanceID_cast<PreloadData*>(pm.GetInstanceIDFromPathAndFileID(globalManagerAssetPath, 1));
    if (preload)
    {
        dynamic_array<InstanceID> dependencies(kMemTempJobAlloc);
        preload->GetInstanceIDArray(dependencies);
        LoadProgress empty;
        pm.LoadObjectsThreaded(dependencies.begin(), dependencies.size(), empty);
    }
    else
    {
        return "PreloadData is missing. It should always be there.";
    }

    // Load all global manager assets
    if (pm.LoadFileCompletely(globalManagerAssetPath) != kNoError)
        return "PlayerInitEngineGraphics: Loading game manager assets failed";

    return core::string();
}

void CreateMissingGlobalGameManagers()
{
    const ManagerContext& context = GetManagerContext();

    for (int i = 0; i < ManagerContext::kGlobalManagerCount; i++)
    {
        Assert(context.m_ManagerTypes[i] != NULL);

        if (context.m_Managers[i] == NULL)
            SetManagerPtrInContext(i, CreateGameManager(context.m_ManagerTypes[i]));
    }
}

void ValidateGlobalGameManagers()
{
    core::string error;
    const ManagerContext& context = GetManagerContext();

    dynamic_array<GameManager*> allManagers(kMemTempAlloc);
    Object::FindObjectsOfType(allManagers);

    for (int i = 0; i < ManagerContext::kGlobalManagerCount; i++)
    {
        Assert(context.m_ManagerTypes[i] != NULL);

        std::vector<GameManager*> specificManagers;
        for (size_t j = 0; j < allManagers.size(); j++)
        {
            if (allManagers[j]->Is(context.m_ManagerTypes[i]))
            {
                specificManagers.push_back(allManagers[j]);
            }
        }

        if (specificManagers.size() == 1)
            ;
        else if (specificManagers.size() == 0)
        {
            error += Format("No managers are loaded of type: %s\n", context.m_ManagerTypes[i]->GetName());
        }
        else
        {
            error += Format("Multiple managers are loaded of type: %s\n", context.m_ManagerTypes[i]->GetName());
        }
    }

    if (!error.empty())
        ErrorString(error);
}

static int GetGlobalManagerIndexFromType(const Unity::Type* type)
{
    const ManagerContext& context = GetManagerContext();

    for (int i = 0; i < ManagerContext::kGlobalManagerCount; i++)
    {
        if (context.m_ManagerTypes[i] == type)
            return i;
    }

    return -1;
}

void AssignGlobalGameManager(Object* obj)
{
    GlobalGameManager* gameManager = dynamic_pptr_cast<GlobalGameManager*>(obj);
    if (gameManager == NULL)
        return;

    int index = GetGlobalManagerIndexFromType(gameManager->GetType());

    if (index != -1)
    {
        if (GetManagerPtrFromContext(index) != NULL && GetManagerPtrFromContext(index) != gameManager)
        {
            ErrorStringMsg("GlobalGameManager of type '%s' already exists.", gameManager->GetTypeName());
        }

        SetManagerPtrInContext(index, gameManager);
    }
    else
    {
        AssertString("Couldn't find game manager context slot");
    }
}
