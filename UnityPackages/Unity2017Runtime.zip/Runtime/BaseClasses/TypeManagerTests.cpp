#include "UnityPrefix.h"

#if ENABLE_UNIT_TESTS

#include "Runtime/Testing/Testing.h"
#include "Attribute.h"
#include "TypeManager.h"
#include "Runtime/Serialize/SerializeUtility.h"
#include "Runtime/Serialize/TransferFunctions/GenerateTypeTreeTransfer.h"
#include "Runtime/Serialize/SerializationCaching/MemoryCacheReader.h"
#include "Runtime/Serialize/SerializationCaching/MemoryCacheWriter.h"
#include "Runtime/Transform/Transform.h"
#if UNITY_EDITOR
#include "Runtime/Serialize/TransferFunctions/YAMLWrite.h"
#include "Runtime/Serialize/TransferFunctions/YAMLRead.h"
#include "Editor/Src/AssetPipeline/AssetImporter.h"
#include "Runtime/Serialize/TransferFunctions/StreamedBinaryWrite.h"
#include "Runtime/Serialize/TransferFunctions/SafeBinaryRead.h"
#include "Runtime/Serialize/SerializationCaching/CachedWriter.h"
#endif


UNIT_TEST_SUITE(TypeManager)
{
    typedef PersistentTypeID TestClassID;

    TypeRegistrationDesc InitTypeRegistrationDesc(PersistentTypeID id, RTTI* type, RTTI* base, const char* name)
    {
        TypeRegistrationDesc desc = TYPEREGISTRATIONDESC_DEFAULT_INITIALIZER_LIST;
        desc.init.base = base;
        desc.init.className = name;
        desc.init.persistentTypeID = id;
        desc.init.size = 10;
        desc.type = type;
        return desc;
    }

    void RegisterTypeHelper(TypeManager& manager, PersistentTypeID id, RTTI* type, RTTI* base, const char* name, const char* nameSpace, int size, RTTI::FactoryFunction* factory, TypeFlags flags)
    {
        TypeRegistrationDesc desc = InitTypeRegistrationDesc(id, type, base, name);
        desc.init.factory = factory;
        desc.init.classNamespace = nameSpace;
        desc.init.size = size;

        desc.init.isAbstract = HasFlag(flags, kTypeIsAbstract);
        desc.init.isSealed = HasFlag(flags, kTypeIsSealed);
        desc.init.isEditorOnly = HasFlag(flags, kTypeIsEditorOnly);
        desc.init.isStripped = HasFlag(flags, kTypeIsStripped);

        manager.RegisterType(desc);
    }

    struct FixtureManagedNotInitialized
    {
        TestClassID classID_Base;

        RTTI rtti_Base;

        RTTI::RuntimeTypeArray storage;
        TypeManager m_Manager;

        FixtureManagedNotInitialized() :
            m_Manager(storage),
            classID_Base(0)
        {
            RegisterTypeHelper(m_Manager, classID_Base, &rtti_Base, NULL, "TestBaseClass", "", 42, NULL, kTypeIsAbstract);
        }

        ~FixtureManagedNotInitialized()
        {
            m_Manager.CleanupAllTypes();
        }
    };

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterNonObjectType_SetsClassNameInRTTI)
    {
        RTTI rtti;
        m_Manager.RegisterNonObjectType(static_cast<PersistentTypeID>(121), &rtti, "MyNonClassName", "");
        CHECK(strcmp(rtti.className, "MyNonClassName") == 0);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterNonObjectType_SetsNamespaceInRTTI)
    {
        RTTI rtti;
        m_Manager.RegisterNonObjectType(static_cast<PersistentTypeID>(121), &rtti, "MyClassName", "MyNamespace");
        CHECK(strcmp(rtti.classNamespace, "MyNamespace") == 0);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, GetFullName_HasExpectedNamespacePrefix)
    {
        RTTI rtti;
        m_Manager.RegisterNonObjectType(static_cast<PersistentTypeID>(121), &rtti, "MyClassName", NULL);
        CHECK_EQUAL("MyClassName", rtti.GetFullName());
        m_Manager.RegisterNonObjectType(static_cast<PersistentTypeID>(122), &rtti, "MyClassName2", "");
        CHECK_EQUAL("MyClassName2", rtti.GetFullName());
        m_Manager.RegisterNonObjectType(static_cast<PersistentTypeID>(123), &rtti, "MyClassName3", "MyNamespace");
        CHECK_EQUAL("MyNamespace::MyClassName3", rtti.GetFullName());
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_SetsClassIDInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        RegisterTypeHelper(m_Manager, classID_Test, &rtti, &rtti_Base, "MyClass", "", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK_EQUAL(classID_Test, rtti.persistentTypeID);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterStrippedClass_SetsClassIDInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        m_Manager.RegisterStrippedType(classID_Test, &rtti, "MyClass", "");
        m_Manager.InitializeAllTypes();

        CHECK_EQUAL(classID_Test, rtti.persistentTypeID);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_SetsClassNameInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        RegisterTypeHelper(m_Manager, classID_Test, &rtti, &rtti_Base, "MyClass", "", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK(strcmp(rtti.className, "MyClass") == 0);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterStrippedClass_SetsClassNameInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        m_Manager.RegisterStrippedType(classID_Test, &rtti, "MyClass", "");
        m_Manager.InitializeAllTypes();

        CHECK(strcmp(rtti.className, "MyClass") == 0);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_SetsNamespaceInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        RegisterTypeHelper(m_Manager, classID_Test, &rtti, &rtti_Base, "MyClass", "MyNamespace", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK(strcmp(rtti.classNamespace, "MyNamespace") == 0);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterStrippedClass_SetsNamespaceInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        m_Manager.RegisterStrippedType(classID_Test, &rtti, "MyClass", "MyNamespace");
        m_Manager.InitializeAllTypes();

        CHECK(strcmp(rtti.classNamespace, "MyNamespace") == 0);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_SetsFactoryInRTTI)
    {
        struct Helper
        {
            static Object* Factory(MemLabelId label, ObjectCreationMode mode) { return NULL; }
        };

        TestClassID classID_Test(21);
        RTTI rtti;

        RegisterTypeHelper(m_Manager, classID_Test, &rtti, &rtti_Base, "MyClass", "", 10, &Helper::Factory, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK(rtti.factory == &Helper::Factory);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_SetsIsAbstractInRTTI)
    {
        TestClassID classID_Abstract(21);
        TestClassID classID_NonAbstract(22);
        RTTI rtti_abstract;
        RTTI rtti_not_abstract;

        RegisterTypeHelper(m_Manager, classID_Abstract, &rtti_abstract, &rtti_Base, "MyAbstractClass", "", 10, NULL, kTypeIsAbstract);
        RegisterTypeHelper(m_Manager, classID_NonAbstract, &rtti_not_abstract, &rtti_Base, "MyNonAbstractClass", "", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK(rtti_abstract.isAbstract);
        CHECK(!rtti_not_abstract.isAbstract);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_SetsSealedInRTTI)
    {
        TestClassID classID_Sealed(21);
        TestClassID classID_NotSealed(22);
        RTTI rtti_sealed;
        RTTI rtti_not_sealed;

        RegisterTypeHelper(m_Manager, classID_Sealed, &rtti_sealed, &rtti_Base, "MySealedClass", "", 10, NULL, kTypeIsSealed);
        RegisterTypeHelper(m_Manager, classID_NotSealed, &rtti_not_sealed, &rtti_Base, "MyNonSealedClass", "", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK(rtti_sealed.isSealed);
        CHECK(!rtti_not_sealed.isSealed);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_SetsEditorOnlyInRTTI)
    {
        TestClassID classID_EditorOnly(21);
        TestClassID classID_NotEditorOnly(22);
        RTTI rtti_true;
        RTTI rtti_false;

        RegisterTypeHelper(m_Manager, classID_EditorOnly, &rtti_true, &rtti_Base, "MyEditorOnlyClass", "", 10, NULL, kTypeIsEditorOnly);
        RegisterTypeHelper(m_Manager, classID_NotEditorOnly, &rtti_false, &rtti_Base, "MyNotEditorOnlyClass", "", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK(rtti_true.isEditorOnly);
        CHECK(!rtti_false.isEditorOnly);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterClass_DoesntSetIsStrippedInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        RegisterTypeHelper(m_Manager, classID_Test, &rtti, &rtti_Base, "MyNotStrippedClass", "", 10, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();
        CHECK(!rtti.isStripped);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterStrippedClass_SetIsStrippedInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        m_Manager.RegisterStrippedType(classID_Test, &rtti, "MyStrippedClass", "");
        m_Manager.InitializeAllTypes();
        CHECK(rtti.isStripped);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, RegisterStrippedClass_SetsDefaultsInRTTI)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        m_Manager.RegisterStrippedType(classID_Test, &rtti, "MyClass", "");
        m_Manager.InitializeAllTypes();

        CHECK_EQUAL(static_cast<void*>(NULL), rtti.base);
        CHECK_EQUAL(static_cast<void*>(NULL), rtti.factory);
        CHECK_EQUAL(-1, rtti.size);
        CHECK(!rtti.isAbstract);
        CHECK(!rtti.isSealed);
        CHECK(!rtti.isEditorOnly);
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, TypeIndexToType_ReturnsValidTypeForValidTypeIndex)
    {
        TestClassID classID_Test1(21);
        TestClassID classID_Test2(22);
        RTTI rtti_test1;
        RTTI rtti_test2;

        RegisterTypeHelper(m_Manager, classID_Test1, &rtti_test1, &rtti_Base, "Class1", "", 42, NULL, kTypeNoFlags);
        RegisterTypeHelper(m_Manager, classID_Test2, &rtti_test2, &rtti_Base, "Class2", "", 42, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK_EQUAL(&rtti_Base, m_Manager.RuntimeTypeIndexToRTTI(rtti_Base.derivedFromInfo.typeIndex));
        CHECK_EQUAL(&rtti_test1, m_Manager.RuntimeTypeIndexToRTTI(rtti_test1.derivedFromInfo.typeIndex));
        CHECK_EQUAL(&rtti_test2, m_Manager.RuntimeTypeIndexToRTTI(rtti_test2.derivedFromInfo.typeIndex));
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, ClassNameToType_ReturnsValidTypeForRegisteredName)
    {
        TestClassID classID_Test1(21);
        TestClassID classID_Test2(22);
        RTTI rtti_test1;
        RTTI rtti_test2;

        RegisterTypeHelper(m_Manager, classID_Test1, &rtti_test1, &rtti_Base, "Class1", "", 42, NULL, kTypeNoFlags);
        RegisterTypeHelper(m_Manager, classID_Test2, &rtti_test2, &rtti_Base, "Class2", "", 42, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK_EQUAL(&rtti_test1, m_Manager.ClassNameToRTTI("Class1"));
        CHECK_EQUAL(&rtti_test2, m_Manager.ClassNameToRTTI("Class2"));
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, ClassNameToType_ReturnsNullForUnregisteredName)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        RegisterTypeHelper(m_Manager, classID_Test, &rtti, &rtti_Base, "Class1", "", 42, NULL, kTypeNoFlags);
        m_Manager.InitializeAllTypes();

        CHECK_EQUAL(static_cast<const RTTI*>(NULL), m_Manager.ClassNameToRTTI("NoClassWithThisName"));
    }

    TEST_FIXTURE(FixtureManagedNotInitialized, ClassNameToType_ReturnsNullForStrippedClass)
    {
        TestClassID classID_Test(21);
        RTTI rtti;

        m_Manager.RegisterStrippedType(classID_Test, &rtti, "Class1", "");
        m_Manager.InitializeAllTypes();

        CHECK_EQUAL(static_cast<const RTTI*>(NULL), m_Manager.ClassNameToRTTI("Class1"));
    }

    #if ENABLE_ASSERTIONS
    TEST_FIXTURE(FixtureManagedNotInitialized, MultipleAttributesWithSameTypeRegistered_FailsAssertion)
    {
        TestClassID attrID(234), testID(123);
        RTTI attrRtti, testRtti;
        Unity::Type* attrType;

        m_Manager.RegisterType(InitTypeRegistrationDesc(attrID, &attrRtti, NULL, "AttrClass"));
        attrType = reinterpret_cast<Unity::Type*>(&attrRtti);

        TypeRegistrationDesc testDesc = InitTypeRegistrationDesc(testID, &testRtti, NULL, "TestClass");
        ConstVariantRef testAttrs[2];
        int dummy = 1;
        testAttrs[0] = ConstVariantRef(attrType, &dummy);
        testAttrs[1] = ConstVariantRef(attrType, &dummy);
        testDesc.init.attributes = testAttrs;
        testDesc.init.attributeCount = 2;

        EXPECT(Assert, "Only a single instance of a given attribute (AttrClass) is permitted to be registered to a type (TestClass)");
        m_Manager.RegisterType(testDesc);
    }
    #endif // ENABLE_ASSERTIONS

    struct FixtureWithSimpleHierarchy
    {
        TestClassID classID_Base;
        TestClassID classID_Abstract;
        TestClassID classID_Abstract_AbstractChild;
        TestClassID classID_Abstract_ConcreteChild;
        TestClassID classID_Stripped_1;
        TestClassID classID_Concrete;
        TestClassID classID_Concrete_AbstractChild;
        TestClassID classID_Concrete_ConcreteChild;
        TestClassID classID_Stripped_2;

        RTTI rtti_Base;
        RTTI rtti_Abstract;
        RTTI rtti_Abstract_AbstractChild;
        RTTI rtti_Abstract_ConcreteChild;
        RTTI rtti_Stripped_1;
        RTTI rtti_Concrete;
        RTTI rtti_Concrete_AbstractChild;
        RTTI rtti_Concrete_ConcreteChild;
        RTTI rtti_Stripped_2;

        RTTI::RuntimeTypeArray storage;
        TypeManager m_Manager;

        FixtureWithSimpleHierarchy() :
            m_Manager(storage),
            classID_Base(0),
            classID_Abstract(50),
            classID_Abstract_AbstractChild(51),
            classID_Abstract_ConcreteChild(52),
            classID_Stripped_1(90),
            classID_Concrete(60),
            classID_Concrete_AbstractChild(61),
            classID_Concrete_ConcreteChild(62),
            classID_Stripped_2(92)
        {
            RegisterTypeHelper(m_Manager, classID_Base, &rtti_Base, NULL, "TestBaseClass", "", 42, NULL, kTypeIsAbstract);
            RegisterTypeHelper(m_Manager, classID_Abstract, &rtti_Abstract, &rtti_Base, "Abstract", "", 42, NULL, kTypeIsAbstract);
            RegisterTypeHelper(m_Manager, classID_Abstract_AbstractChild, &rtti_Abstract_AbstractChild, &rtti_Abstract, "Abstract_AbstractChild", "", 42, NULL, kTypeIsAbstract);

            m_Manager.RegisterStrippedType(classID_Stripped_1, &rtti_Stripped_1, "Stripped_1", "");

            RegisterTypeHelper(m_Manager, classID_Concrete, &rtti_Concrete, &rtti_Base, "Concrete", "", 42, NULL, kTypeNoFlags);
            RegisterTypeHelper(m_Manager, classID_Concrete_ConcreteChild, &rtti_Concrete_ConcreteChild, &rtti_Concrete, "Concrete_ConcreteChild", "", 42, NULL, kTypeNoFlags);

            RegisterTypeHelper(m_Manager, classID_Abstract_ConcreteChild, &rtti_Abstract_ConcreteChild, &rtti_Abstract, "Abstract_ConcreteChild", "", 42, NULL, kTypeNoFlags);
            RegisterTypeHelper(m_Manager, classID_Concrete_AbstractChild, &rtti_Concrete_AbstractChild, &rtti_Concrete, "Concrete_AbstractChild", "", 42, NULL, kTypeIsAbstract);

            m_Manager.RegisterStrippedType(classID_Stripped_2, &rtti_Stripped_2, "Stripped_2", "");

            m_Manager.InitializeAllTypes();
        }

        ~FixtureWithSimpleHierarchy()
        {
            m_Manager.CleanupAllTypes();
        }
    };

    inline bool IsDerivedFrom(const RTTI* derivedType, const RTTI* baseType)
    {
        return RTTI::IsDerivedFrom(derivedType->derivedFromInfo.typeIndex, baseType->derivedFromInfo.typeIndex, baseType->derivedFromInfo.descendantCount);
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, IsDerivedFrom_SelfReturnTrue)
    {
        CHECK(IsDerivedFrom(&rtti_Base, &rtti_Base));

        CHECK(IsDerivedFrom(&rtti_Abstract, &rtti_Abstract));
        CHECK(IsDerivedFrom(&rtti_Abstract_AbstractChild, &rtti_Abstract_AbstractChild));
        CHECK(IsDerivedFrom(&rtti_Abstract_ConcreteChild, &rtti_Abstract_ConcreteChild));

        CHECK(IsDerivedFrom(&rtti_Concrete, &rtti_Concrete));
        CHECK(IsDerivedFrom(&rtti_Concrete_AbstractChild, &rtti_Concrete_AbstractChild));
        CHECK(IsDerivedFrom(&rtti_Concrete_ConcreteChild, &rtti_Concrete_ConcreteChild));
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, IsDerivedFrom_DirectBaseReturnsTrue)
    {
        CHECK(IsDerivedFrom(&rtti_Abstract, &rtti_Base));
        CHECK(IsDerivedFrom(&rtti_Concrete, &rtti_Base));

        CHECK(IsDerivedFrom(&rtti_Abstract_AbstractChild, &rtti_Abstract));
        CHECK(IsDerivedFrom(&rtti_Abstract_ConcreteChild, &rtti_Abstract));

        CHECK(IsDerivedFrom(&rtti_Concrete_AbstractChild, &rtti_Concrete));
        CHECK(IsDerivedFrom(&rtti_Concrete_ConcreteChild, &rtti_Concrete));
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, IsDerivedFrom_IndirectBaseReturnsTrue)
    {
        CHECK(IsDerivedFrom(&rtti_Abstract_AbstractChild, &rtti_Base));
        CHECK(IsDerivedFrom(&rtti_Abstract_ConcreteChild, &rtti_Base));
        CHECK(IsDerivedFrom(&rtti_Concrete_AbstractChild, &rtti_Base));
        CHECK(IsDerivedFrom(&rtti_Concrete_ConcreteChild, &rtti_Base));
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, IsDerivedFrom_NonBaseReturnsFalse)
    {
        CHECK(!IsDerivedFrom(&rtti_Abstract, &rtti_Concrete));
        CHECK(!IsDerivedFrom(&rtti_Concrete, &rtti_Abstract));

        CHECK(!IsDerivedFrom(&rtti_Abstract_AbstractChild, &rtti_Concrete));
        CHECK(!IsDerivedFrom(&rtti_Abstract_ConcreteChild, &rtti_Concrete));
        CHECK(!IsDerivedFrom(&rtti_Concrete_AbstractChild, &rtti_Abstract));
        CHECK(!IsDerivedFrom(&rtti_Concrete_ConcreteChild, &rtti_Abstract));
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, IsDerivedFrom_StrippedReturnsFalse)
    {
        CHECK(!IsDerivedFrom(&rtti_Stripped_1, &rtti_Base));
        CHECK(!IsDerivedFrom(&rtti_Stripped_2, &rtti_Base));

        CHECK(!IsDerivedFrom(&rtti_Stripped_1, &rtti_Concrete));
        CHECK(!IsDerivedFrom(&rtti_Stripped_1, &rtti_Abstract));
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, FindAllRTTIDerivedTypes_Type_BothAbstractAndNonAbstract)
    {
        dynamic_array<const RTTI*> typeResult;
        m_Manager.FindAllRTTIDerivedTypes(&rtti_Abstract, typeResult, false);
        CHECK_EQUAL(3, typeResult.size());
        CHECK(std::find(typeResult.begin(), typeResult.end(), &rtti_Abstract) != typeResult.end());
        CHECK(std::find(typeResult.begin(), typeResult.end(), &rtti_Abstract_ConcreteChild) != typeResult.end());
        CHECK(std::find(typeResult.begin(), typeResult.end(), &rtti_Abstract_AbstractChild) != typeResult.end());

        typeResult.clear();
        m_Manager.FindAllRTTIDerivedTypes(&rtti_Concrete, typeResult, false);
        CHECK_EQUAL(3, typeResult.size());
        CHECK(std::find(typeResult.begin(), typeResult.end(), &rtti_Concrete) != typeResult.end());
        CHECK(std::find(typeResult.begin(), typeResult.end(), &rtti_Concrete_ConcreteChild) != typeResult.end());
        CHECK(std::find(typeResult.begin(), typeResult.end(), &rtti_Concrete_AbstractChild) != typeResult.end());
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, FindAllRTTIDerivedTypes_Type_OnlyNonAbstract)
    {
        dynamic_array<const RTTI*> typeResult;
        m_Manager.FindAllRTTIDerivedTypes(&rtti_Abstract, typeResult, true);
        CHECK_EQUAL(1, typeResult.size());
        CHECK(std::find(typeResult.begin(), typeResult.end(), &rtti_Abstract_ConcreteChild) != typeResult.end());

        typeResult.clear();
        m_Manager.FindAllRTTIDerivedTypes(&rtti_Concrete, typeResult, true);
        CHECK_EQUAL(2, typeResult.size());
        CHECK(std::find(typeResult.begin(), typeResult.end(), &rtti_Concrete) != typeResult.end());
        CHECK(std::find(typeResult.begin(), typeResult.end(), &rtti_Concrete_ConcreteChild) != typeResult.end());
    }

    static bool Contains(const dynamic_array<PersistentTypeID>& ids, TestClassID& testID)
    {
        for (dynamic_array<PersistentTypeID>::const_iterator it = ids.begin(); it != ids.end(); ++it)
        {
            if (*it == testID)
                return true;
        }
        return false;
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, FindAllRTTIDerivedTypes_PersistentTypeID_BothAbstractAndNonAbstract)
    {
        dynamic_array<PersistentTypeID> classIDResult;
        m_Manager.FindAllRTTIDerivedTypes(classID_Abstract, classIDResult, false);
        CHECK_EQUAL(3, classIDResult.size());
        CHECK(Contains(classIDResult, classID_Abstract));
        CHECK(Contains(classIDResult, classID_Abstract_AbstractChild));
        CHECK(Contains(classIDResult, classID_Abstract_ConcreteChild));

        classIDResult.clear();
        m_Manager.FindAllRTTIDerivedTypes(classID_Concrete, classIDResult, false);
        CHECK_EQUAL(3, classIDResult.size());
        CHECK(Contains(classIDResult, classID_Concrete));
        CHECK(Contains(classIDResult, classID_Concrete_AbstractChild));
        CHECK(Contains(classIDResult, classID_Concrete_ConcreteChild));
    }

    TEST_FIXTURE(FixtureWithSimpleHierarchy, FindAllRTTIDerivedTypes_PersistentTypeID_OnlyNonAbstract)
    {
        dynamic_array<PersistentTypeID> classIDResult;
        m_Manager.FindAllRTTIDerivedTypes(classID_Abstract, classIDResult, true);
        CHECK_EQUAL(1, classIDResult.size());
        CHECK(Contains(classIDResult, classID_Abstract_ConcreteChild));

        classIDResult.clear();
        m_Manager.FindAllRTTIDerivedTypes(classID_Concrete, classIDResult, true);
        CHECK_EQUAL(2, classIDResult.size());
        CHECK(Contains(classIDResult, classID_Concrete));
        CHECK(Contains(classIDResult, classID_Concrete_ConcreteChild));
    }

    struct FixtureWithMultipleHierarchies
    {
        TestClassID classID_Base1;
        TestClassID classID_Derived1_a;
        TestClassID classID_Derived1_b;
        TestClassID classID_Base2;
        TestClassID classID_Derived2_a;
        TestClassID classID_Base3;

        RTTI rtti_Base1;
        RTTI rtti_Derived1_a;
        RTTI rtti_Derived1_b;
        RTTI rtti_Base2;
        RTTI rtti_Derived2_a;
        RTTI rtti_Base3;

        RTTI::RuntimeTypeArray storage;
        TypeManager m_Manager;

        FixtureWithMultipleHierarchies() :
            m_Manager(storage),
            classID_Base1(50),
            classID_Derived1_a(51),
            classID_Derived1_b(52),
            classID_Base2(60),
            classID_Derived2_a(61),
            classID_Base3(70)
        {
            RegisterTypeHelper(m_Manager, classID_Base1, &rtti_Base1, NULL, "Base1", "", 42, NULL, kTypeIsAbstract);
            RegisterTypeHelper(m_Manager, classID_Derived1_a, &rtti_Derived1_a, &rtti_Base1, "Derived1_a", "", 42, NULL, kTypeIsAbstract);
            RegisterTypeHelper(m_Manager, classID_Derived1_b, &rtti_Derived1_b, &rtti_Base1, "Derived1_b", "", 42, NULL, kTypeIsAbstract);

            RegisterTypeHelper(m_Manager, classID_Base2, &rtti_Base2, NULL, "Base2", "", 42, NULL, kTypeIsAbstract);
            RegisterTypeHelper(m_Manager, classID_Derived2_a, &rtti_Derived2_a, &rtti_Base2, "Derived2_a", "", 42, NULL, kTypeIsAbstract);

            RegisterTypeHelper(m_Manager, classID_Base3, &rtti_Base3, NULL, "Base3", "", 42, NULL, kTypeIsAbstract);

            m_Manager.InitializeAllTypes();
        }

        ~FixtureWithMultipleHierarchies()
        {
            m_Manager.CleanupAllTypes();
        }
    };

    TEST_FIXTURE(FixtureWithMultipleHierarchies, MultipleHierarchies_TypeIndicesAreValid)
    {
        CHECK(rtti_Base1.derivedFromInfo.typeIndex != RTTI::DefaultTypeIndex);
        CHECK(rtti_Derived1_a.derivedFromInfo.typeIndex != RTTI::DefaultTypeIndex);
        CHECK(rtti_Derived1_b.derivedFromInfo.typeIndex != RTTI::DefaultTypeIndex);
        CHECK(rtti_Base2.derivedFromInfo.typeIndex != RTTI::DefaultTypeIndex);
        CHECK(rtti_Derived2_a.derivedFromInfo.typeIndex != RTTI::DefaultTypeIndex);
        CHECK(rtti_Base3.derivedFromInfo.typeIndex != RTTI::DefaultTypeIndex);
    }

    TEST_FIXTURE(FixtureWithMultipleHierarchies, MultipleHierarchies_DescendantCountIsCorrect)
    {
        // NOTE : descendant count is 1 + #descendants
        CHECK_EQUAL(3, rtti_Base1.derivedFromInfo.descendantCount);
        CHECK_EQUAL(2, rtti_Base2.derivedFromInfo.descendantCount);
        CHECK_EQUAL(1, rtti_Base3.derivedFromInfo.descendantCount);
    }

    TEST_FIXTURE(FixtureWithMultipleHierarchies, MultipleHierarchies_DerivedFromIsTrueWithinHierarchies)
    {
        CHECK(RTTI::IsDerivedFrom(rtti_Derived1_a, rtti_Base1));
        CHECK(RTTI::IsDerivedFrom(rtti_Derived2_a, rtti_Base2));
    }

    TEST_FIXTURE(FixtureWithMultipleHierarchies, MultipleHierarchies_DerivedFromIsFalseAcrossHierarchies)
    {
        CHECK(!RTTI::IsDerivedFrom(rtti_Base1, rtti_Base2));
        CHECK(!RTTI::IsDerivedFrom(rtti_Base1, rtti_Base3));

        CHECK(!RTTI::IsDerivedFrom(rtti_Derived1_a, rtti_Base2));
        CHECK(!RTTI::IsDerivedFrom(rtti_Derived1_b, rtti_Base3));
        CHECK(!RTTI::IsDerivedFrom(rtti_Derived2_a, rtti_Base1));
    }

    TEST(CallbacksAreCalledWhenExpected)
    {
        TestClassID classID_base(0);
        TestClassID classID_init(10);
        TestClassID classID_postInit(11);
        TestClassID classID_cleanup(12);

        RTTI rtti_base;
        RTTI rtti_init;
        RTTI rtti_postInit;
        RTTI rtti_cleanup;

        RTTI::RuntimeTypeArray storage;
        TypeManager manager(storage);
        RegisterTypeHelper(manager, classID_base, &rtti_base, NULL, "TestBaseClass", "", 42, NULL, kTypeIsAbstract);

        static UInt32 init_called = 0;
        static UInt32 postinit_called = 0;
        static UInt32 cleanup_called = 0;

        struct CallbackHelper
        {
            static void InitCallback() { ++init_called; }
            static void PostInitCallback() { ++postinit_called; }
            static void CleanupCallback() { ++cleanup_called; }
        };

        TypeRegistrationDesc initDesc = InitTypeRegistrationDesc(classID_init, &rtti_init, &rtti_base, "ClassWithStaticInit");
        initDesc.initCallback = &CallbackHelper::InitCallback;
        manager.RegisterType(initDesc);

        TypeRegistrationDesc postInitDesc = InitTypeRegistrationDesc(classID_postInit, &rtti_postInit, &rtti_base, "ClassWithStaticPostInit");
        postInitDesc.postInitCallback = &CallbackHelper::PostInitCallback;
        manager.RegisterType(postInitDesc);

        TypeRegistrationDesc cleanupDesc = InitTypeRegistrationDesc(classID_cleanup, &rtti_cleanup, &rtti_base, "ClassWithStaticCleanup");
        cleanupDesc.cleanupCallback = &CallbackHelper::CleanupCallback;
        manager.RegisterType(cleanupDesc);

        manager.InitializeAllTypes();

        CHECK_EQUAL(0, init_called);
        CHECK_EQUAL(0, postinit_called);
        CHECK_EQUAL(0, cleanup_called);

        manager.CallInitializeTypes();

        CHECK_EQUAL(1, init_called);
        CHECK_EQUAL(0, postinit_called);
        CHECK_EQUAL(0, cleanup_called);

        manager.CallPostInitializeTypes();

        CHECK_EQUAL(1, init_called);
        CHECK_EQUAL(1, postinit_called);
        CHECK_EQUAL(0, cleanup_called);

        manager.CleanupAllTypes();

        CHECK_EQUAL(1, init_called);
        CHECK_EQUAL(1, postinit_called);
        CHECK_EQUAL(1, cleanup_called);
    }
}

INTEGRATION_TEST_SUITE(TypeManagerIntegration)
{
    TEST(TypeIndicesAreConsecutive)
    {
        for (UInt32 i = 0; i < Unity::Type::GetTypeCount(); ++i)
            CHECK(TypeManager::Get().RuntimeTypeIndexToRTTI(i) != NULL);
    }

    TEST(IsDerivedFrom_ForAllRegisteredClasses_MatchesDataInType)
    {
        struct local
        {
            static bool IsDerivedFromByWalkingBase(const Unity::Type* derivedType, const Unity::Type* baseType)
            {
                const Unity::Type* i = derivedType;
                while (i)
                {
                    if (baseType == i)
                        return true;

                    i = i->GetBaseClass();
                }
                return false;
            }
        };

        for (UInt32 i = 0; i < Unity::Type::GetTypeCount(); ++i)
        {
            const Unity::Type* t1 = Unity::Type::GetTypeByRuntimeTypeIndex(i);
            for (UInt32 j = 0; j < Unity::Type::GetTypeCount(); ++j)
            {
                const Unity::Type* t2 = Unity::Type::GetTypeByRuntimeTypeIndex(j);
                CHECK_EQUAL(local::IsDerivedFromByWalkingBase(t1, t2), t1->IsDerivedFrom(t2));
            }
        }
    }

    TEST(TypeIndex_ForAllRegisteredClasses_IsUnique)
    {
        for (UInt32 i = 0; i < Unity::Type::GetTypeCount(); ++i)
        {
            const RTTI* t1 = TypeManager::Get().RuntimeTypeIndexToRTTI(i);
            for (UInt32 j = 0; j < Unity::Type::GetTypeCount(); ++j)
            {
                const RTTI* t2 = TypeManager::Get().RuntimeTypeIndexToRTTI(j);
                if (i != j)
                    CHECK(t1->derivedFromInfo.typeIndex != t2->derivedFromInfo.typeIndex);
            }
        }
    }

#if UNITY_EDITOR
    TEST(IsEditorOnly_AssetImporterIsEditorOnly)
    {
        const Unity::Type* type = TypeOf<AssetImporter>();
        CHECK(type->IsEditorOnly());
    }

    struct SerializeType
    {
        DECLARE_SERIALIZE_NO_PPTR(SerializeType);
        const Unity::Type* type;
    };

    template<class TransferFunction>
    void SerializeType::Transfer(TransferFunction& transfer)
    {
        transfer.Transfer(type, "type");
    }

    const PersistentTypeID NonExistingTypeID = static_cast<PersistentTypeID>(42);

    const char* serializedTransformTypeData = "type: 4\n";  // PersistentTypeID of Transform
    const char* serializedUnknownTypeData   = "type: 42\n"; // Non existing PersistentTypeID
    const char* serializedUndefinedTypeData = "type: -1\n"; // Undefined PersistentTypeID

    TEST(Type_SerializeTransformType_SerializedYaml)
    {
        SerializeType input;
        core::string str;
        input.type = TypeOf<Transform>();
        YAMLWrite write(kNoTransferInstructionFlags);

        input.Transfer(write);
        write.OutputToString(str);

        CHECK_EQUAL(serializedTransformTypeData, str);
    }

    TEST(Type_SerializeUndefinedType_SerializedYaml)
    {
        SerializeType input;
        core::string str;
        input.type = NULL;
        YAMLWrite write(kNoTransferInstructionFlags);

        input.Transfer(write);

        write.OutputToString(str);
        CHECK_EQUAL(serializedUndefinedTypeData, str);
    }

    TEST(Type_DeserializeYaml_TransformType)
    {
        SerializeType output;
        output.type = NULL;
        YAMLRead read(serializedTransformTypeData,
                      strlen(serializedTransformTypeData),
                      kNoTransferInstructionFlags, kMemTempAlloc);

        output.Transfer(read);

        CHECK_MSG(TypeOf<Transform>() == output.type, "Deserializing Transform type gave back unexpected type");
    }

    TEST(Type_YamlDeserialization_UndefinedType)
    {
        SerializeType output;
        output.type = NULL;
        YAMLRead read(serializedUndefinedTypeData,
                      strlen(serializedUndefinedTypeData),
                      kNoTransferInstructionFlags, kMemTempAlloc);

        output.Transfer(read);

        CHECK_MSG(output.type == NULL, "Deserializing undefined type didn't give back NULL type");
    }

    TEST(Type_YamlDeserialization_UnknownType)
    {
        SerializeType output;
        output.type = NULL;
        YAMLRead read(serializedUnknownTypeData,
                      strlen(serializedUnknownTypeData),
                      kNoTransferInstructionFlags, kMemTempAlloc);

        output.Transfer(read);

        CHECK_MSG(output.type != NULL, "Deserializing unknown type gave back unexpected NULL type");
        CHECK_MSG(output.type->GetPersistentTypeID() == NonExistingTypeID, "Deserializing unknown type gave back type with unexpected classID");
    }


    template<class T>
    struct BinarySerializeType
    {
        DECLARE_SERIALIZE_NO_PPTR(BinarySerializeType_ClassID);
        T a;
        T b;
    };

    template<class T>
    template<class TransferFunction>
    void BinarySerializeType<T>::Transfer(TransferFunction& transfer)
    {
        TRANSFER(a);
        TRANSFER(b);
    }

    template<class T>
    void ReadInstanceFromVector(T& instance, const dynamic_array<UInt8>& data, const TypeTreeIterator& type)
    {
        MemoryCacheReader memoryCache(const_cast<dynamic_array<UInt8>&>(data));
        SafeBinaryRead readStream;
        CachedReader& readCache = readStream.Init(type, 0, data.size(), kNoTransferInstructionFlags, kMemTempAlloc);
        readCache.InitRead(memoryCache, 0, data.size());

        readStream.Transfer(instance, "Base");
        readCache.End();
    }

    template<class T>
    static inline void WriteInstanceToVector(const T& instance, dynamic_array<UInt8>& data)
    {
        data.clear();

        MemoryCacheWriter memoryCache(data);
        StreamedBinaryWrite<false> writeStream;
        CachedWriter& writeCache = writeStream.Init(kNoTransferInstructionFlags, BuildTargetSelection::NoTarget());

        writeCache.InitWrite(memoryCache);
        writeStream.Transfer(const_cast<T&>(instance), "Base");

        if (!writeCache.CompleteWriting() || writeCache.GetPosition() != data.size())
            ErrorString("Error while writing serialized data.");
    }

    template<typename IntegerType>
    void CheckIntegerTypeConvertsToTypePtr()
    {
        BinarySerializeType<IntegerType> integerVersion;
        integerVersion.a = 4;
        integerVersion.b = (IntegerType) - 1;

        TypeTree integerVersionTypeTree;
        GenerateTypeTreeTransfer transfer(integerVersionTypeTree, kNoTransferInstructionFlags, &integerVersion, sizeof(integerVersion));
        transfer.TransferBase(integerVersion);

        dynamic_array<UInt8> integerVersionData(kMemTempAlloc);
        WriteInstanceToVector(integerVersion, integerVersionData);

        BinarySerializeType<const Unity::Type*> typePtrVersion;
        typePtrVersion.a = TypeOf<Object>();
        typePtrVersion.b = TypeOf<Object>();

        ReadInstanceFromVector(typePtrVersion, integerVersionData, integerVersionTypeTree.Root());

        CHECK(TypeOf<Transform>() == typePtrVersion.a);
        CHECK(NULL == typePtrVersion.b);
    }

    TEST(CanDeserialize_TypePtr_From16BitIntegerTypes)
    {
        CheckIntegerTypeConvertsToTypePtr<SInt16>();
        CheckIntegerTypeConvertsToTypePtr<UInt16>();
    }

    TEST(CanDeserialize_TypePtr_From32BitIntegerTypes)
    {
        CheckIntegerTypeConvertsToTypePtr<SInt32>();
        CheckIntegerTypeConvertsToTypePtr<UInt32>();
    }

    TEST(Type_CanGenerateTypeTreeContaining_Type)
    {
        TypeTree type;
        SerializeType output;
        output.type = NULL;
        GenerateTypeTreeTransfer generator(type, kNoTransferInstructionFlags, NULL, sizeof(SerializeType));

        output.Transfer(generator);

        TypeTreeIterator typeMember = type.Root();
        CHECK_EQUAL("type", typeMember.Name().c_str());
        CHECK_EQUAL("Type*", typeMember.Type().c_str());
        CHECK(typeMember.IsBasicDataType());
    }

    TEST(Type_PrimitiveTypesAreNotObjectDerived)
    {
        const Unity::Type* floatType = Unity::Type::FindTypeByName("float");
        CHECK(floatType != NULL);

        const Unity::Type* intType = Unity::Type::FindTypeByName("int");
        CHECK(intType != NULL);

        const Unity::Type* boolType = Unity::Type::FindTypeByName("bool");
        CHECK(boolType != NULL);

        CHECK(!floatType->IsDerivedFrom<Object>());
        CHECK(!intType->IsDerivedFrom<Object>());
        CHECK(!boolType->IsDerivedFrom<Object>());
    }

    TEST(GetDeserializationStubForPersistentTypeID_DoesNotReturnNULL)
    {
        RTTI::RuntimeTypeArray storage;
        TypeManager typeManager(storage);
        const RTTI* stub = typeManager.GetDeserializationRTTIStubForPersistentTypeID(42);

        CHECK(stub != NULL);
    }

    TEST(GetDeserializationStubForPersistentTypeID_WithPersistentTypeID_ReturnsStubThatHasSamePersistentTypeID)
    {
        RTTI::RuntimeTypeArray storage;
        TypeManager typeManager(storage);
        const PersistentTypeID expectedPersistentTypeID = 42;
        const RTTI* stub = typeManager.GetDeserializationRTTIStubForPersistentTypeID(expectedPersistentTypeID);

        PersistentTypeID actualPersistentTypeID = stub->persistentTypeID;

        CHECK_EQUAL(expectedPersistentTypeID, actualPersistentTypeID);
    }

    TEST(GetDeserializationStubForPersistentTypeID_CalledMultipleTimesWithSameID_ReturnsSameStub)
    {
        RTTI::RuntimeTypeArray storage;
        TypeManager typeManager(storage);
        const RTTI* expectedStub = typeManager.GetDeserializationRTTIStubForPersistentTypeID(42);
        const RTTI* secondStub   = typeManager.GetDeserializationRTTIStubForPersistentTypeID(42);

        CHECK_EQUAL(expectedStub, secondStub);
    }

#endif // UNITY_EDITOR
}


#endif
