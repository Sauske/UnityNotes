#pragma once

#include "BaseObject.h"

#if !UNITY_RELEASE

enum DumpObjectFlags
{
    kDumpObjectHeader       = 1 << 0,   // Object address, ID, class, hideflags, etc
    kDumpObjectFields       = 1 << 1,   // All serialized object fields
    kDumpObjectPersistence  = 1 << 2,   // PersistentManager registration data
    kDumpObjectScript       = 1 << 3,   // For MonoBehaviours/ScriptableObjects, the scripting class name

    kDumpObjectEverything = 0xffffffff
};

// Dumping routines that print objects to the log.  This is mostly meant for debugging.

// Dump a single object, given a pointer to the object.
void DumpObject(Object* object, DumpObjectFlags flags = kDumpObjectEverything);

// Dump a single object, given its InstanceID.
void DumpObjectByID(InstanceID instanceID, DumpObjectFlags flags = kDumpObjectEverything);

// Dump all objects with the given (case-sensitive) name.
void DumpObjectByName(const char* name, DumpObjectFlags flags = kDumpObjectEverything);

// Dump all objects of the given type.
void DumpAllObjectsOfType(const Unity::Type* type, DumpObjectFlags flags = kDumpObjectEverything);

// Dump all objects with a type looked up from the given type name.
void DumpAllObjectsOfTypeName(const char* className, DumpObjectFlags flags = kDumpObjectEverything);

#endif // !UNITY_RELEASE

struct CompareInstanceID
{
    bool operator()(const Object* lhs, const Object* rhs)  const
    {
        return lhs->GetInstanceID() < rhs->GetInstanceID();
    }
};
