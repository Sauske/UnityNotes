#include "UnityPrefix.h"
#include "BaseObjectUtilities.h"
#include "Runtime/Serialize/PersistentManager.h"
#include "Runtime/Serialize/TransferUtility.h"
#include "Runtime/Mono/MonoBehaviour.h"


#if !UNITY_RELEASE

void DumpObject(Object* object, DumpObjectFlags flags)
{
    if (!object)
    {
        printf_console("Object: null\n");
        return;
    }

    // Dump general information.
    if (flags & kDumpObjectHeader)
    {
        const Unity::Type* type = object->GetType();
        printf_console("Object: %p, ID: %i, ClassID: %i, Class: %s, Name: %s, ScriptObject GetGCHandle: %p\n",
            object, object->GetInstanceID(), type->GetPersistentTypeID(), type->GetName(),
            object->GetName(), ScriptingGCHandle::ToScriptingBackendNativeGCHandle(object->GetGCHandle()));

        // Dump hide flags.
        Object::HideFlags hideFlags = object->GetHideFlags();
        if (!hideFlags)
            printf_console("  HideFlags: none\n");
        else
            printf_console("  Hide Flags:%s%s%s%s%s%s\n",
                HasFlag(hideFlags, Object::kHideInHierarchy) ? "kHideInHierarchy" : "",
                HasFlag(hideFlags, Object::kHideInspector) ? "kHideInspector" : "",
                HasFlag(hideFlags, Object::kDontSaveInEditor) ? "kDontSaveInEditor" : "",
                HasFlag(hideFlags, Object::kNotEditable) ? "kNotEditable" : "",
                HasFlag(hideFlags, Object::kDontSaveInBuild) ? "kDontSaveInBuild" : "",
                HasFlag(hideFlags, Object::kDontUnloadUnusedAsset) ? "kDontUnloadUnusedAsset" : "");
    }

    // Dump information about object location on disk.
    if (flags & kDumpObjectPersistence)
    {
        if (!object->IsPersistent())
        {
            printf_console("  IsPersistent: false");
            #if UNITY_EDITOR
            printf_console(" FileIDHint: %i", object->GetFileIDHint());
            #endif
            printf_console("\n");
        }
        else
        {
            SerializedObjectIdentifier id;
            if (!GetPersistentManager().InstanceIDToSerializedObjectIdentifier(object->GetInstanceID(), id))
                printf_console("  IsPersistent: true, Cannot find file ID");
            else
            {
                core::string path = GetPersistentManager().GetPathName(object->GetInstanceID());
                printf_console("  IsPersistent: true, Path: %s, SerializedFileIndex: %i, FileID: %lli\n",
                    path.c_str(),
                    id.serializedFileIndex,
                    id.localIdentifierInFile);
            }
        }
    }

    // Dump scripting information, if it's a MonoBehaviour.
    if (flags & kDumpObjectScript
        && object->Is<MonoBehaviour>())
    {
        MonoBehaviour* monoBehaviour = static_cast<MonoBehaviour*>(object);
        core::string scriptClassName = monoBehaviour->GetScriptFullClassName();
        printf_console("  ScriptClass: %s\n", scriptClassName.c_str());
    }

    // Dump value of fields.
    #if SUPPORT_TEXT_SERIALIZATION && !UNITY_EXTERNAL_TOOL
    if (flags & kDumpObjectFields)
    {
        TransferInstructionFlags flags = kNoTransferInstructionFlags;
        #if UNITY_EDITOR
        flags |= kSerializeDebugProperties;
        #endif
        core::string dump;
        WriteObjectToString(*object, dump, flags);
        printf_console("%s\n", dump.c_str());
    }
    #endif
}

void DumpObjectByID(InstanceID instanceID, DumpObjectFlags flags)
{
    DumpObject(Object::IDToPointer(instanceID), flags);
}

void DumpObjectByName(const char* name, DumpObjectFlags flags)
{
    dynamic_array<Object*> objects(kMemTempAlloc);
    Object::FindObjectsOfType(objects);

    int objectCount = 0;
    for (size_t i = 0; i < objects.size(); ++i)
    {
        if (strcmp(name, objects[i]->GetName()) == 0)
        {
            DumpObject(objects[i], flags);
            ++objectCount;
        }
    }

    printf_console("%i objects\n", objectCount);
}

void DumpAllObjectsOfType(const Unity::Type* type, DumpObjectFlags flags)
{
    dynamic_array<Object*> objects(kMemTempAlloc);
    Object::FindObjectsOfType(type, objects);

    for (size_t i = 0; i < objects.size(); ++i)
        DumpObject(objects[i], flags);

    printf_console("%i objects\n", objects.size());
}

void DumpAllObjectsOfTypeName(const char* className, DumpObjectFlags flags)
{
    const Unity::Type* type = Unity::Type::FindTypeByName(className);
    if (type == NULL)
        return;

    DumpAllObjectsOfType(type, flags);
}

#endif // !UNITY_RELEASE
