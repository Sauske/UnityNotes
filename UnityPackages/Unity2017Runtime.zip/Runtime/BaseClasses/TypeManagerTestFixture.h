#pragma once

#include "Runtime/Testing/Faking.h"
#include "TypeManager.h"

// this fixture base helps with type system-related testing. it automatically manages a custom
// and isolated type system for you. to use:
//
//   1. derive your fixture from TypeManagerTestFixture
//   2. in your fixture's ctor:
//      * call RegisterTestType<MyType>("MyType") for each type
//      * you can optionally pass in an expected attr count for sanity checking your test
//      * call Init() to commit the types
//   3. use the normal type system functions - it will only contain the types you registered
//
// note: if using attributes, you need to put your types outside the test suite in order for the
// attrs to register properly.
//
// example:
//
//  namespace MyTestTypes { class MyTestType {}; }
//  REGISTER_TYPE_ATTRIBUTES(MyTestTypes::MyTestType, (MyAttribute, (param0, param1)));
//
//  UNIT_TEST_SUITE(MySuiteName)
//  {
//      using namespace MyTestTypes;
//
//      struct MyFixture : TypeManagerTestFixture
//      {
//          MyFixture()
//          {
//              #define REGISTER(CLASS_, ATTRCOUNT_) RegisterTestType<CLASS_>(#CLASS_, ATTRCOUNT_)
//              REGISTER(MyTestType, 1);
//              #undef REGISTER
//
//              Init();
//          }
//      };
//
//      ... the usual tests here ...
//  }

struct TypeManagerTestFixture
{
    RTTI::RuntimeTypeArray m_Storage;
    TypeManager m_Manager;
    PersistentTypeID m_NextPersistentTypeID;

    FAKE_STATIC_METHOD(RTTI, GetRuntimeTypes, RTTI::RuntimeTypeArray & ());
    FAKE_STATIC_METHOD(TypeManager, Get, TypeManager & ());

    TypeManagerTestFixture()
        : m_Manager(m_Storage)
        , m_NextPersistentTypeID(1)
    {
        RTTI_GetRuntimeTypes.Returns(m_Storage);
        TypeManager_Get.Returns(m_Manager);
    }

    template<typename T>
    const Unity::Type* RegisterTestType(const char* typeName, int expectedAttrCount = -1)
    {
        TypeManager::Get().RegisterType<T>(m_NextPersistentTypeID++, typeName, NULL);
        AssertAttributeCount<T>(expectedAttrCount);
        return Unity::Type::FindTypeByPersistentTypeID(m_NextPersistentTypeID - 1);
    }

    template<typename T, typename Base>
    const Unity::Type* RegisterTestType(const char* typeName, int expectedAttrCount = -1)
    {
        TypeManager::Get().RegisterType<T, Base>(m_NextPersistentTypeID++, typeName, NULL);
        AssertAttributeCount<T>(expectedAttrCount);
        return Unity::Type::FindTypeByPersistentTypeID(m_NextPersistentTypeID - 1);
    }

    void Init()
    {
        m_Manager.InitializeAllTypes();
    }

    ~TypeManagerTestFixture()
    {
        m_Manager.CleanupAllTypes();
    }

private:

    template<typename T>
    void AssertAttributeCount(int expectedAttrCount)
    {
        if (expectedAttrCount >= 0)
        {
            size_t actualAttrCount = TypeOf<T>()->GetAttributeCount();
            AssertFormatMsg(
                expectedAttrCount == actualAttrCount,
                "Type %s has %d attrs but expected %d",
                TypeOf<T>()->GetFullName().c_str(), actualAttrCount, expectedAttrCount);
        }
    }
};
