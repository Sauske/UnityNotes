#ifndef OBJECTDEFINES_H
#define OBJECTDEFINES_H

#include "Runtime/Allocator/BaseAllocator.h"
#include "Configuration/UnityConfigure.h"
#include "Runtime/Allocator/MemoryMacros.h"
#include "Runtime/BaseClasses/Type.h"
#include "Runtime/Core/CoreMacros.h"
#include "Runtime/Modules/ExportModules.h"
#include "Runtime/Utilities/RegisterRuntimeInitializeAndCleanup.h"
#include "Runtime/Utilities/TypeUtilities.h"

namespace BaseObjectInternal
{
    template<typename type>
    inline Object* NewObject(MemLabelId label, ObjectCreationMode mode)
    {
        return UNITY_NEW_AS_ROOT(type, label, "Objects", NULL) (mode);
    }
}
// ----------------------------------------------------------------------------

#define NEW_OBJECT(CLASS_) reinterpret_cast<CLASS_*>(::Object::AllocateAndAssignInstanceID(BaseObjectInternal::NewObject<CLASS_>(kMemBaseObject, kCreateObjectDefault)))
#define NEW_OBJECT_USING_MEMLABEL(CLASS_, MEMLABEL_) reinterpret_cast<CLASS_*>(::Object::AllocateAndAssignInstanceID(BaseObjectInternal::NewObject<CLASS_>(MEMLABEL_, kCreateObjectDefault)))
#define NEW_OBJECT_FROM_THREAD(CLASS_) reinterpret_cast<CLASS_*>(::Object::CalculateCachedTypeIndex(BaseObjectInternal::NewObject<CLASS_>(kMemBaseObject, kCreateObjectFromNonMainThread)))

#define NEW_OBJECT_RESET_AND_AWAKE(CLASS_) ResetAndAwake (NEW_OBJECT (CLASS_))


// ----------------------------------------------------------------------------


#if BUILDING_DYNAMICLIB
// Exporting transfer functions is not needed for WinRT players today
#if PLATFORM_WIN && !PLATFORM_WINRT
#define EXPORTDLL __declspec(dllexport)
#elif PLATFORM_OSX
#define EXPORTDLL __attribute__((visibility("default")))
#else
#define EXPORTDLL
#endif
#else // BUILDING_DYNAMICLIB
#define EXPORTDLL
#endif // BUILDING_DYNAMICLIB


// ----------------------------------------------------------------------------


#if DEBUGMODE && COMPILER_SUPPORTS_DECLTYPE

#define REGISTER_VALIDATE_TYPE(TYPE_NAME_) CompileTimeAssert((IsSameType<const TYPE_NAME_*,decltype(this)>::result), "REGISTER_CLASS: " #TYPE_NAME_ " typename mismatch"); \
class MISSING_SEMICOLON_AFTER_REGISTER_VALIDATE_TYPE

#else

#define REGISTER_VALIDATE_TYPE(TYPE_NAME_) \
class MISSING_SEMICOLON_AFTER_REGISTER_VALIDATE_TYPE

#endif


// ----------------------------------------------------------------------------


#if DEBUGMODE

void EXPORT_COREMODULE AddVerifyClassRegistration(PersistentTypeID persistentTypeID);
void EXPORT_COREMODULE CleanupVerifyClassRegistration();

template<int PersistentTypeID>
struct VerifyObjectIsRegisteredHelper
{
    static void VerifyClassRegistration(void*) { AddVerifyClassRegistration(PersistentTypeID); }
    static RegisterRuntimeInitializeAndCleanup s_Init;
};

#define IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED(PERSISTENT_TYPE_ID)  \
template<> RegisterRuntimeInitializeAndCleanup VerifyObjectIsRegisteredHelper<PERSISTENT_TYPE_ID>::s_Init(&VerifyObjectIsRegisteredHelper<PERSISTENT_TYPE_ID>::VerifyClassRegistration, NULL, 1); \
class MISSING_SEMICOLON_AFTER_IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED

#else

#define IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED(PERSISTENT_TYPE_ID) \
class MISSING_SEMICOLON_AFTER_IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED

#endif


// ----------------------------------------------------------------------------


// This macro creates a compile-time test with which you can retrieve
// a static method from a class while ignoring any instances in it's parent class.
// It will return NULL when the static method does not exist.
#define CREATE_GET_STATIC_METHOD_FROM_TYPE_HELPER(HELPER_NAME_, METHOD_DECLARATION_, METHOD_NAME_) \
template<class T> struct HELPER_NAME_ \
{ \
private: \
    template<ToPointerType<METHOD_DECLARATION_>::ResultType> struct TestInstance; \
    template<typename Q> static FalseType Test(...); \
    template<typename Q> static TrueType  Test(TestInstance<&Q::METHOD_NAME_>*, ...); \
    template<typename Q> static FalseType Test(typename EnableIf<IsSameType<TestInstance<&Q::METHOD_NAME_>, TestInstance<&Q::Super::METHOD_NAME_> >::result>::type*, void*); \
    enum { value = sizeof(Test<T>(0, 0)) == sizeof(TrueType) }; \
    struct TypeNoCallback { enum MyEnum { METHOD_NAME_ = 0 }; }; \
public: \
    static ToPointerType<METHOD_DECLARATION_>::ResultType GetMethod() { return (ToPointerType<METHOD_DECLARATION_>::ResultType)Conditional<value, T, TypeNoCallback>::type::METHOD_NAME_; } \
}; \
class MISSING_SEMICOLON_AFTER_CREATE_UNIQUE_METHOD_IN_CLASS_TEST


CREATE_GET_STATIC_METHOD_FROM_TYPE_HELPER(GetInitializeClassMethodFromType, void(), InitializeClass);
CREATE_GET_STATIC_METHOD_FROM_TYPE_HELPER(GetPostInitializeClassMethodFromType, void(), PostInitializeClass);
CREATE_GET_STATIC_METHOD_FROM_TYPE_HELPER(GetCleanupClassMethodFromType, void(), CleanupClass);


// ----------------------------------------------------------------------------

// Register (possibly multiple) traits for a class that is registered after this Macro using REGISTER_CLASS.
// Valid values are kTypeNoFlags, kTypeIsAbstract, kTypeIsSealed, kTypeIsEditorOnly
#define REGISTER_CLASS_TRAITS(...) public: struct kTypeFlags { enum { value = UNSIGNED_FLAGS(__VA_ARGS__) }; }; \
public: \
    class MISSING_SEMICOLON_AFTER_REGISTER_CLASS_TRAITS_MACRO


// ----------------------------------------------------------------------------


#define REGISTER_CLASS(TYPE_NAME_) \
public: \
    /* NOTE: do not change the order of these two typedefs */ \
    typedef ThisType Super; \
    typedef TYPE_NAME_ ThisType; \
\
    static const char* GetPPtrTypeString () { return "PPtr<"#TYPE_NAME_">"; } \
    static TYPE_NAME_* Produce(InstanceID instanceID = InstanceID_None, MemLabelId memLabel = kMemBaseObject, ObjectCreationMode mode = kCreateObjectDefault) \
        { return Object::Produce<TYPE_NAME_>(instanceID, memLabel, mode); } \
    static TYPE_NAME_* Produce(const Unity::Type* type, InstanceID instanceID = InstanceID_None, MemLabelId memLabel = kMemBaseObject, ObjectCreationMode mode = kCreateObjectDefault) \
        { return Object::Produce<TYPE_NAME_>(type, instanceID, memLabel, mode); } \
private: \
    virtual const Unity::Type*const GetTypeVirtualInternal() const { REGISTER_VALIDATE_TYPE(TYPE_NAME_); return TypeOf<TYPE_NAME_>(); } \
protected: \
    ~TYPE_NAME_ () { ThreadedCleanup(); } \
    void ThreadedCleanup(); \
public: \
    class MISSING_SEMICOLON_AFTER_REGISTER_CLASS_MACRO


// ----------------------------------------------------------------------------

template<typename T>
void RegisterClass();

// This is the default no-op registration of attributes for a type.
// It is called by RegisterClass<T>() and should be specialized if
// a specific type has any attributes. This is most easily done using
// the REGISTER_TYPE_ATTRIBUTES macro defined in Attribute.h.
template<typename T>
const ConstVariantRef* RegisterAttributes(size_t& attributeCountOut)
{
    attributeCountOut = 0;
    return NULL;
}

template<UInt32 typeID>
inline void PerformRegisterClassCompileTimeChecks()
{
    CompileTimeAssert(typeID > 0, "IMPLEMENT_REGISTER_CLASS: PersistentTypeID must be higher than 0.");
    CompileTimeAssert(typeID < 0x80000000, "IMPLEMENT_REGISTER_CLASS: PersistentTypeID must be lower than 0x80000000.");
}

#define IMPLEMENT_REGISTER_CLASS_2(TYPE_NAME_, PERSISTENT_TYPE_ID) \
    IMPLEMENT_REGISTER_CLASS_3(,TYPE_NAME_, PERSISTENT_TYPE_ID)

#define IMPLEMENT_REGISTER_CLASS_3(NAMESPACE_, TYPE_NAME_, PERSISTENT_TYPE_ID) \
/* If defined get the TypeFlags for our type, otherwise return kTypeNoFlags. Ignores inherited TypeFlags. */ \
enum { k##NAMESPACE_##TYPE_NAME_##TypeFlags = SelectOnTypeEquality<NAMESPACE_::TYPE_NAME_::ThisType::kTypeFlags, NAMESPACE_::TYPE_NAME_::Super::kTypeFlags, kTypeNoFlags, NAMESPACE_::TYPE_NAME_::ThisType::kTypeFlags::value>::result }; \
IMPLEMENT_CLASS_VERIFY_OBJECT_IS_REGISTERED(PERSISTENT_TYPE_ID); \
static TypeRegistrationDesc NAMESPACE_##TYPE_NAME_##_TypeRegistrationDesc = \
{ \
    { /* RTTI */ \
        &TypeContainer<NAMESPACE_::TYPE_NAME_::Super>::rtti, \
        NULL, \
        #TYPE_NAME_, \
        #NAMESPACE_, \
        "Core", \
        PERSISTENT_TYPE_ID, \
        sizeof(NAMESPACE_::TYPE_NAME_), \
        { \
            static_cast<RuntimeTypeIndex>(RTTI::DefaultTypeIndex), \
            RTTI::DefaultDescendentCount, \
        }, \
        (k##NAMESPACE_##TYPE_NAME_##TypeFlags & kTypeIsAbstract) != 0, \
        (k##NAMESPACE_##TYPE_NAME_##TypeFlags & kTypeIsSealed) != 0, \
        (k##NAMESPACE_##TYPE_NAME_##TypeFlags & kTypeIsEditorOnly) != 0, \
        false, \
        NULL, \
        0 \
    }, \
    &TypeContainer<NAMESPACE_::TYPE_NAME_>::rtti, \
    NULL, \
    NULL, \
    NULL, \
}; \
template<> void RegisterClass<NAMESPACE_::TYPE_NAME_>() \
{ \
    PerformRegisterClassCompileTimeChecks<PERSISTENT_TYPE_ID>(); \
    \
    /* These parts of the struct are initialized within this method to make sure the linker removes */ \
    /* these methods when RegisterClass is not called. This is essential for Unity's stripping to work! */ \
    NAMESPACE_##TYPE_NAME_##_TypeRegistrationDesc.init.factory = ProduceHelper<NAMESPACE_::TYPE_NAME_, (k##NAMESPACE_##TYPE_NAME_##TypeFlags & kTypeIsAbstract) != 0 >::Produce; \
    NAMESPACE_##TYPE_NAME_##_TypeRegistrationDesc.initCallback = GetInitializeClassMethodFromType<NAMESPACE_::TYPE_NAME_>::GetMethod(); \
    NAMESPACE_##TYPE_NAME_##_TypeRegistrationDesc.postInitCallback = GetPostInitializeClassMethodFromType<NAMESPACE_::TYPE_NAME_>::GetMethod(); \
    NAMESPACE_##TYPE_NAME_##_TypeRegistrationDesc.cleanupCallback = GetCleanupClassMethodFromType<NAMESPACE_::TYPE_NAME_>::GetMethod(); \
    \
    TypeRegistrationDesc& desc = NAMESPACE_##TYPE_NAME_##_TypeRegistrationDesc ; \
    desc.init.attributes = RegisterAttributes<NAMESPACE_::TYPE_NAME_>(desc.init.attributeCount); \
    void GlobalRegisterType(const TypeRegistrationDesc& desc); \
    GlobalRegisterType(desc); \
} \
class MISSING_SEMICOLON_AFTER_IMPLEMENT_REGISTER_CLASS_MACRO


// Implements the registration of a class.
//
// Usage: IMPLEMENT_REGISTER_CLASS(MyNameSpace, MyTypeName, xxxxxxx)
//
// Where 'MyNameSpace' is optional and xxxxxxx is an unique persistent-type-id for this class
//
// To create a valid persistent-type-id use the following perl expression and copy/paste its result:
//      perl -e "printf('0x%08X', int(rand(0x80000000 - 20000)) + 20000)"
//
#define IMPLEMENT_REGISTER_CLASS(...) PP_VARG_SELECT_OVERLOAD(IMPLEMENT_REGISTER_CLASS_,(__VA_ARGS__))


// ----------------------------------------------------------------------------


template<typename T, bool isAbstract>
struct ProduceHelper
{
    static Object* Produce(MemLabelId label, ObjectCreationMode mode) { AssertFormatMsg(false, "Can't produce abstract class %s", TypeOf<T>()->GetName()); return NULL; }
};

template<typename T>
struct ProduceHelper<T, false>
{
    static Object* Produce(MemLabelId label, ObjectCreationMode mode) { return BaseObjectInternal::NewObject<T>(label, mode); }
};


// ----------------------------------------------------------------------------


// Should be placed in every serializable object derived class (DECLARE_OBJECT_SERIALIZE())
#if UNITY_EDITOR
    #define DECLARE_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        static const char* GetTypeString () { return TypeOf<ThisType>()->GetName(); } \
        static bool MightContainPPtr () { return true; } \
        static bool AllowTransferOptimization () { return false; } \
        template<class TransferFunction> void Transfer (TransferFunction& transfer); \
        virtual void VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer); \
        virtual void VirtualRedirectTransfer (SafeBinaryRead& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer);\
        virtual void VirtualRedirectTransfer (StreamedBinaryWrite<true>& transfer);\
        virtual void VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryRead<true>& transfer);  \
        virtual void VirtualRedirectTransfer (RemapPPtrTransfer& transfer); \
        virtual void VirtualRedirectTransfer (YAMLRead& transfer); \
        virtual void VirtualRedirectTransfer (YAMLWrite& transfer); \
        virtual void VirtualRedirectTransfer (JSONRead& transfer); \
        virtual void VirtualRedirectTransfer (JSONWrite& transfer); \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

    #define DECLARE_STRIPPED_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        void VirtualStrippedRedirectTransfer (GenerateTypeTreeTransfer& transfer); \
        void VirtualStrippedRedirectTransfer (SafeBinaryRead& transfer); \
        void VirtualStrippedRedirectTransfer (StreamedBinaryWrite<true>& transfer); \
        void VirtualStrippedRedirectTransfer (StreamedBinaryWrite<false>& transfer); \
        void VirtualStrippedRedirectTransfer (StreamedBinaryRead<true>& transfer); \
        void VirtualStrippedRedirectTransfer (StreamedBinaryRead<false>& transfer); \
        void VirtualStrippedRedirectTransfer (YAMLRead& transfer); \
        void VirtualStrippedRedirectTransfer (YAMLWrite& transfer); \
        void VirtualStrippedRedirectTransfer (JSONRead& transfer); \
        void VirtualStrippedRedirectTransfer (JSONWrite& transfer); \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_STRIPPED_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#elif SUPPORT_ENDIAN_SWAP_SERIALIZATION
    #define DECLARE_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        static const char* GetTypeString () { return TypeOf<ThisType>()->GetName(); } \
        static bool MightContainPPtr () { return true; } \
        static bool AllowTransferOptimization () { return false; } \
        template<class TransferFunction> void Transfer (TransferFunction& transfer); \
        virtual void VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer); \
        virtual void VirtualRedirectTransfer (SafeBinaryRead& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryRead<true>& transfer);  \
        virtual void VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer); \
        virtual void VirtualRedirectTransfer (RemapPPtrTransfer& transfer); \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

// Only supported in editor
    #define DECLARE_STRIPPED_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_STRIPPED_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#elif SUPPORT_SERIALIZED_TYPETREES
    #define DECLARE_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        static const char* GetTypeString () { return TypeOf<ThisType>()->GetName(); } \
        static bool MightContainPPtr () { return true; } \
        static bool AllowTransferOptimization () { return false; } \
        template<class TransferFunction> void Transfer (TransferFunction& transfer); \
        virtual void VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer); \
        virtual void VirtualRedirectTransfer (SafeBinaryRead& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer); \
        virtual void VirtualRedirectTransfer (RemapPPtrTransfer& transfer); \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

// Only supported in editor
    #define DECLARE_STRIPPED_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_STRIPPED_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#else
    #define DECLARE_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        static const char* GetTypeString () { return TypeOf<ThisType>()->GetName(); } \
        static bool MightContainPPtr () { return true; } \
        static bool AllowTransferOptimization () { return false; } \
        template<class TransferFunction> void Transfer (TransferFunction& transfer); \
        virtual void VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer); \
        virtual void VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer); \
        virtual void VirtualRedirectTransfer (RemapPPtrTransfer& transfer); \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

// Only supported in editor
    #define DECLARE_STRIPPED_OBJECT_SERIALIZE(...) /* the "..." will be removed in the near future */ \
    public: \
        class MISSING_SEMICOLON_AFTER_DECLARE_STRIPPED_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#endif

// ----------------------------------------------------------------------------


// Has to be placed in the .cpp file of a serializable class (IMPLEMENT_OBJECT_SERIALIZE (Transform))
// you also have to #include "Runtime/Serialize/TransferFunctions/SerializeTransfer.h"

#if UNITY_EDITOR // Editor needs to support swapped endian writing, player doesn't.

    #define INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(FULL_TYPENAME_, DECL_, FUNCTION_NAME_, FUNCTION_RETURN_TYPE_) \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(GenerateTypeTreeTransfer& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(SafeBinaryRead& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryRead<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryRead<true>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryWrite<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryWrite<true>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(RemapPPtrTransfer& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(YAMLRead& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(YAMLWrite& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(JSONRead& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(JSONWrite& transfer); \
    class MISSING_SEMICOLON_AFTER_INSTANTIATE_TEMPLATE_TRANSFER; /* semicolon will be removed in the near future */

    #define IMPLEMENT_OBJECT_SERIALIZE_WITH_DECL(PREFIX_, DECL_) \
    DECL_ void PREFIX_ VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer)     { transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (SafeBinaryRead& transfer)               { SET_ALLOC_OWNER(GetMemoryLabel()); transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer)    { SET_ALLOC_OWNER(GetMemoryLabel()); transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryRead<true>& transfer)     { SET_ALLOC_OWNER(GetMemoryLabel()); transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (RemapPPtrTransfer& transfer)            { transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer)   { transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryWrite<true>& transfer)    { transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (YAMLRead& transfer)                     { SET_ALLOC_OWNER(GetMemoryLabel()); transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (YAMLWrite& transfer)                    { transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (JSONRead& transfer)                     { SET_ALLOC_OWNER(GetMemoryLabel()); transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (JSONWrite& transfer)                    { transfer.TransferBase (*this); }\
    class MISSING_SEMICOLON_AFTER_IMPLEMENT_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#elif SUPPORT_ENDIAN_SWAP_SERIALIZATION
    #define INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(FULL_TYPENAME_, DECL_, FUNCTION_NAME_, FUNCTION_RETURN_TYPE_) \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(GenerateTypeTreeTransfer& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(SafeBinaryRead& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryRead<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryRead<true>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryWrite<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(RemapPPtrTransfer& transfer); \
    class MISSING_SEMICOLON_AFTER_INSTANTIATE_TEMPLATE_TRANSFER; /* semicolon will be removed in the near future */


    #define IMPLEMENT_OBJECT_SERIALIZE_WITH_DECL(PREFIX_, DECL_) \
    DECL_ void PREFIX_ VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer)     { transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (SafeBinaryRead& transfer)               { SET_ALLOC_OWNER(GetMemoryLabel()); transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer)    { SET_ALLOC_OWNER(GetMemoryLabel()); transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryRead<true>& transfer)     { SET_ALLOC_OWNER(GetMemoryLabel()); transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer)   { transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (RemapPPtrTransfer& transfer)            { transfer.TransferBase (*this); }\
    class MISSING_SEMICOLON_AFTER_IMPLEMENT_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#elif SUPPORT_SERIALIZED_TYPETREES
    #define INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(FULL_TYPENAME_, DECL_, FUNCTION_NAME_, FUNCTION_RETURN_TYPE_) \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(GenerateTypeTreeTransfer& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(SafeBinaryRead& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryRead<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryWrite<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(RemapPPtrTransfer& transfer); \
    class MISSING_SEMICOLON_AFTER_INSTANTIATE_TEMPLATE_TRANSFER; /* semicolon will be removed in the near future */


    #define IMPLEMENT_OBJECT_SERIALIZE_WITH_DECL(PREFIX_, DECL_) \
    DECL_ void PREFIX_ VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer)     { transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (SafeBinaryRead& transfer)               { SET_ALLOC_OWNER(GetMemoryLabel()); transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer)    { SET_ALLOC_OWNER(GetMemoryLabel()); transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer)   { transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (RemapPPtrTransfer& transfer)            { transfer.TransferBase (*this); }\
    class MISSING_SEMICOLON_AFTER_IMPLEMENT_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#else
    #define INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(FULL_TYPENAME_, DECL_, FUNCTION_NAME_, FUNCTION_RETURN_TYPE_) \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(GenerateTypeTreeTransfer& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryRead<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(StreamedBinaryWrite<false>& transfer); \
    template DECL_ FUNCTION_RETURN_TYPE_ FULL_TYPENAME_::FUNCTION_NAME_(RemapPPtrTransfer& transfer); \
    class MISSING_SEMICOLON_AFTER_INSTANTIATE_TEMPLATE_TRANSFER; /* semicolon will be removed in the near future */

    #define IMPLEMENT_OBJECT_SERIALIZE_WITH_DECL(PREFIX_, DECL_) \
    DECL_ void PREFIX_ VirtualRedirectTransfer (GenerateTypeTreeTransfer& transfer)     { transfer.TransferBase (*this); }\
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryRead<false>& transfer)    { SET_ALLOC_OWNER(GetMemoryLabel()); transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (StreamedBinaryWrite<false>& transfer)   { transfer.TransferBase (*this); } \
    DECL_ void PREFIX_ VirtualRedirectTransfer (RemapPPtrTransfer& transfer)            { transfer.TransferBase (*this); }\
    class MISSING_SEMICOLON_AFTER_IMPLEMENT_OBJECT_SERIALIZE; /* semicolon will be removed in the near future */

#endif


#define IMPLEMENT_OBJECT_SERIALIZE(TYPE_) IMPLEMENT_OBJECT_SERIALIZE_WITH_DECL(TYPE_::, )

#define INSTANTIATE_TEMPLATE_TRANSFER(FULL_TYPENAME_) INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(FULL_TYPENAME_, ,Transfer,void)
#define INSTANTIATE_TEMPLATE_TRANSFER_EXPORTED(FULL_TYPENAME_) INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(FULL_TYPENAME_, EXPORTDLL,Transfer,void)
#define INSTANTIATE_TEMPLATE_TRANSFER_FUNCTION(FULL_TYPENAME_, FUNCTION_NAME_) INSTANTIATE_TEMPLATE_TRANSFER_WITH_DECL(FULL_TYPENAME_, ,FUNCTION_NAME_,void)


// ----------------------------------------------------------------------------


// Use this to make a Generic C++ GET/SET function: GET_SET (float, Velocity, m_Velocity)
//  Implements GetVelocity, SetVelocity
#define GET_SET(TYPE_NAME_, PROP_NAME_, VAR_NAME_)    void Set##PROP_NAME_ (const TYPE_NAME_ val) { VAR_NAME_ = val; }  const TYPE_NAME_ Get##PROP_NAME_ () const {return (const TYPE_NAME_)VAR_NAME_; }
#define GET_SET_DIRTY(TYPE_NAME_, PROP_NAME_, VAR_NAME_)  void Set##PROP_NAME_ (const TYPE_NAME_ val) { VAR_NAME_ = val; SetDirty(); }  const TYPE_NAME_ Get##PROP_NAME_ () const {return (const TYPE_NAME_)VAR_NAME_; }
#define GET_SET_DIRTY_REF(TYPE_NAME_, PROP_NAME_, VAR_NAME_)  void Set##PROP_NAME_ (const TYPE_NAME_& val) { VAR_NAME_ = val; SetDirty(); } const TYPE_NAME_& Get##PROP_NAME_ () const {return VAR_NAME_; }
#define GET_SET_COMPARE_DIRTY(TYPE_NAME_, PROP_NAME_, VAR_NAME_)  void Set##PROP_NAME_ (const TYPE_NAME_ val) { if ((TYPE_NAME_)VAR_NAME_ == val) return; VAR_NAME_ = val; SetDirty(); }    const TYPE_NAME_ Get##PROP_NAME_ () const {return (const TYPE_NAME_)VAR_NAME_; }

#endif
