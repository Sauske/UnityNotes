#ifndef CULLER_H
#define CULLER_H

#include "CullingParameters.h"
#include "Runtime/BaseClasses/MessageIdentifier.h"

struct ScriptableCullingParameters;
struct CullResults;
struct SceneCullingParameters;
struct JobFence;
class GameObject;

DECLARE_MESSAGE_IDENTIFIER(kOnWillRenderObject);

void CullScene(SceneCullingParameters& cullingParameters, const ScriptableCullingParameters& cullingCameraParameters, CullResults& cullResults);
void CullIntermediateRenderersOnly(const SceneCullingParameters& cullingParameters, CullResults& results);

bool IsGameObjectFiltered(GameObject& go, CullFiltering cullFilterMode);

#endif
