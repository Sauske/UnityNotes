#include "UnityPrefix.h"
#include "Flare.h"
#include "Runtime/Allocator/BatchAllocator.h"
#include "Runtime/Interfaces/IPhysics2D.h"
#include "Runtime/Interfaces/IPhysics.h"
#include "Runtime/Interfaces/IRaycast.h"
#include "Runtime/Interfaces/IPhysics.h"
#include "RenderSettings.h"
#include "RenderManager.h"
#include "Runtime/Camera/Camera.h"
#include "Runtime/BaseClasses/IsPlaying.h"
#include "Runtime/BaseClasses/MessageHandlerRegistration.h"
#include "Runtime/Shaders/ShaderPassContext.h"
#include "Runtime/Input/TimeManager.h"
#include "Runtime/BaseClasses/TagManager.h"
#include "Runtime/GfxDevice/GfxDevice.h"
#include "Runtime/Shaders/ShaderNameRegistry.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Graphics/Mesh/DynamicVBO.h"
#include "Runtime/Graphics/Mesh/MeshVertexFormat.h"
#include "Runtime/Graphics/GraphicsHelper.h"
#include "Runtime/Camera/GraphicsSettings.h"
#include "Runtime/Transform/Transform.h"

PROFILER_INFORMATION(gFlareRenderProfile, "Flare.Render", kProfilerRender)
PROFILER_INFORMATION(gFlareUpdateProfile, "Flare.Update", kProfilerRender)
PROFILER_INFORMATION(gFlareGeometryJobProfile, "Flare.GeometryJob", kProfilerRender)

static RuntimeStatic<FlareManager> s_FlareManager(kMemRenderer, RuntimeStatic<FlareManager>::kManual);

static SHADERPROP(FlareTexture);

static DefaultMeshVertexFormat gFlareVertexFormat(VERTEX_FORMAT3(Vertex, TexCoord0, Color));

static void CalculateFlareGetUVCoords(int layout, int imageIndex, const Vector2f& pixOffset, Vector2f& outUV0, Vector2f& outUV1);

Flare::Flare(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
{
}

void Flare::ThreadedCleanup()
{
}

void Flare::Reset()
{
    Super::Reset();
    resize_trimmed(m_Elements, 1);
    m_Elements[0].m_ImageIndex = 0;
    m_Elements[0].m_Rotate = false;
    m_Elements[0].m_Position = 0.0f;
    m_Elements[0].m_Size = 0.5f;
    m_Elements[0].m_Color = ColorRGBAf(1, 1, 1, 0);
    m_Elements[0].m_Zoom = true;
    m_Elements[0].m_Fade = true;
    m_Elements[0].m_UseLightColor = true;
    m_UseFog = true;
    m_TextureLayout = 0;
}

template<class TransferFunc>
void Flare::Transfer(TransferFunc& transfer)
{
    Super::Transfer(transfer);
    TRANSFER(m_FlareTexture);
    TRANSFER(m_TextureLayout);
    TRANSFER(m_Elements);
    TRANSFER(m_UseFog);
}

struct FlareVertex
{
    Vector3f vert;
    ColorRGBA32 color;
    Vector2f uv;
};

// Matches the modes used in the inspector for texture layout:
enum FlareLayout
{
    kLayoutLargeRestSmall = 0,
    kLayoutMixed,
    kLayout1x1,
    kLayout2x2,
    kLayout3x3,
    kLayout4x4,
};


// Get the UV coords for a flare element.
// Returns: outUV0 is top-left UV, outUV1 is bottom-right UV.
static void CalculateFlareGetUVCoords(int layout, int imageIndex, const Vector2f& pixOffset, Vector2f& outUV0, Vector2f& outUV1)
{
    switch (layout)
    {
        case kLayoutLargeRestSmall:
            if (imageIndex != 0)
            {
                imageIndex -= 1;
                int xImg = (imageIndex & 1);
                int yImg = (imageIndex >> 1);
                float imgSize = .5f;
                outUV0 = Vector2f((float)(xImg + 0) * imgSize, (float)(yImg + 0) * imgSize * 0.5f + 0.5f) + pixOffset;
                outUV1 = Vector2f((float)(xImg + 1) * imgSize, (float)(yImg + 1) * imgSize * 0.5f + 0.5f) - pixOffset;
            }
            else
            {
                outUV0 = Vector2f(0.0f, 0.0f) + pixOffset;
                outUV1 = Vector2f(1.0f, 0.5f) - pixOffset;
            }
            break;

        case kLayoutMixed:
            switch (imageIndex)
            {
                case 0:
                    outUV0 = Vector2f(0.0f, 0.0f); // + pixOffset;
                    outUV1 = Vector2f(1.0f, 0.5f) - pixOffset;
                    break;
                case 1:
                    outUV0 = Vector2f(0.0f, 0.50f); // + pixOffset;
                    outUV1 = Vector2f(0.5f, 0.75f) - pixOffset;
                    break;
                case 2:
                    outUV0 = Vector2f(0.0f, 0.75f); // + pixOffset;
                    outUV1 = Vector2f(0.5f, 1.00f) - pixOffset;
                    break;
                default:
                    imageIndex -= 3;
                    int xImg = (imageIndex & 1);
                    int yImg = (imageIndex >> 1);
                    const float imgSize = 0.25f;
                    outUV0 = Vector2f((float)(xImg + 0) * imgSize + 0.5f, (float)(yImg + 0) * imgSize * 0.5f + 0.5f) + pixOffset;
                    outUV1 = Vector2f((float)(xImg + 1) * imgSize + 0.5f, (float)(yImg + 1) * imgSize * 0.5f + 0.5f) - pixOffset;
                    break;
            }
            break;

        default:
        {
            // the rest of layouts are regular grids
            const int grid = layout - 1;
            int xImg = imageIndex % grid;
            int yImg = imageIndex / grid;
            float imgSize = 1.0f / (float)grid;
            outUV0 = Vector2f((float)(xImg + 0) * imgSize, (float)(yImg + 0) * imgSize) + pixOffset;
            outUV1 = Vector2f((float)(xImg + 1) * imgSize, (float)(yImg + 1) * imgSize) - pixOffset;
        }
        break;
    }
}

FlareManager::FlareManager()
    : m_FlareMaterial(NULL)
{
}

int FlareManager::AddFlare()
{
    // Find unused flare, and put it there if there is one
    FlareList::iterator it, itEnd = m_Flares.end();
    int index = 0;
    for (it = m_Flares.begin(); it != itEnd; ++it, ++index)
    {
        if (!it->used)
        {
            it->used = true;
            // set brightness of this to zero in all cameras
            for (RendererList::iterator rit = m_Renderers.begin(); rit != m_Renderers.end(); ++rit)
            {
                DebugAssert(rit->second.size() == m_Flares.size());
                rit->second[index] = 0.0f;
            }
            return index;
        }
    }

    // No unused flare found; add new one
    index = m_Flares.size();
    m_Flares.push_back(FlareEntry());
    // add zero brightness to all cameras
    for (RendererList::iterator rit = m_Renderers.begin(); rit != m_Renderers.end(); ++rit)
    {
        rit->second.push_back(0.0f);
        DebugAssert(rit->second.size() == m_Flares.size());
    }
    return index;
}

void FlareManager::UpdateFlare(int handle, Flare *flare, Transform& transform,
    bool infinite, float brightness, const ColorRGBAf &color,
    float fadeSpeed, UInt32 layers, UInt32 ignoredLayers
    )
{
    Assert(handle >= 0 && handle < (int)m_Flares.size());
    FlareEntry& i = m_Flares[handle];
    i.used = true;
    i.transform = &transform;
    i.flare = flare;
    i.infinite = infinite;
    i.brightness = brightness;
    i.color = color;
    i.fadeSpeed = fadeSpeed;
    i.layers = layers;
    i.ignoredLayers = ignoredLayers;
}

void FlareManager::DeleteFlare(int handle)
{
    Assert(handle >= 0 && handle < (int)m_Flares.size());
    // mark it as unused
    FlareEntry& flare = m_Flares[handle];
    flare.used = false;
}

void FlareManager::AddCamera(Camera &camera)
{
    Assert(m_Renderers.find(&camera) == m_Renderers.end());
    m_Renderers[&camera] = std::vector<float>();
    std::vector<float> &vec = m_Renderers[&camera];
    vec.resize(m_Flares.size(), 0.0f);
    Assert(vec.size() == m_Flares.size());
}

void FlareManager::RemoveCamera(Camera &camera)
{
    RendererList::iterator i = m_Renderers.find(&camera);
    Assert(i != m_Renderers.end());
    m_Renderers.erase(i);
}

struct FlareManagerUpdateJobData
{
    FlareManagerUpdateJobData(const Camera& camera) : m_NumJobsInBatch(0), m_CamFar(camera.GetFar()), m_CamPosition(camera.GetPosition()) {}

    static const int kNumInBatch = 10;
    FlareManager::FlareEntry* m_Flares[kNumInBatch];
    float* m_Brightness[kNumInBatch];
    Vector3f m_Position[kNumInBatch];
    int m_NumJobsInBatch;
    float m_CamFar;
    Vector3f m_CamPosition;
};

void FlareManager::Update()
{
    const Camera &cam = GetCurrentCamera();
    RendererList::iterator it = m_Renderers.find(&cam);
    if (it == m_Renderers.end())
    {
        AssertString("Flare renderer to update not found");
        return;
    }

    Assert(it->second.size() == m_Flares.size());
    float *brightness = (it->second.size() ? &it->second[0] : NULL);

    JobFence jobGroup;
    Job* jobs;
    int jobsCount = 0;
    ALLOC_TEMP_AUTO(jobs, m_Flares.size());

    FlareManagerUpdateJobData* jobData = NULL;

    for (FlareList::iterator i = m_Flares.begin(); i != m_Flares.end(); ++i, ++brightness)
    {
        if (!i->used)
            continue;

        if (i->infinite)
            i->position = i->transform->TransformDirection(Vector3f(0, 0, 1));
        else
            i->position = i->transform->GetPosition();

        // Allocate job if not yet created
        if (!jobData)
        {
            jobData = UNITY_NEW(FlareManagerUpdateJobData, kMemTempJobAlloc) (cam);
        }

        // Flush batch?
        if (jobData->m_NumJobsInBatch == FlareManagerUpdateJobData::kNumInBatch)
        {
            jobs[jobsCount++] = Job(FlareManager::UpdateJob, jobData);
            jobData = UNITY_NEW(FlareManagerUpdateJobData, kMemTempJobAlloc) (cam);
        }

        // Add flare
        jobData->m_Flares[jobData->m_NumJobsInBatch] = &(*i);
        jobData->m_Brightness[jobData->m_NumJobsInBatch] = brightness;
        if (i->infinite)
            jobData->m_Position[jobData->m_NumJobsInBatch] = cam.WorldToViewportPoint(cam.GetPosition() + i->position);
        else
            jobData->m_Position[jobData->m_NumJobsInBatch] = cam.WorldToViewportPoint(i->position);
        jobData->m_NumJobsInBatch++;
    }

    // Flush final batch
    if (jobData && jobData->m_NumJobsInBatch)
    {
        jobs[jobsCount++] = Job(FlareManager::UpdateJob, jobData);
        jobData = NULL;
    }

    IPhysics* physics3d = GetIPhysics();
    IPhysics2D* physics2d = GetIPhysics2D();

    if (jobsCount > 0)
    {
        if (physics3d)
            physics3d->AutoSyncTransforms();
        if (physics2d)
            physics2d->AutoSyncTransforms();
    }

    // we need to disable the auto sync mode so that we won't run into a problem calling raycast from another thread
    bool autoSyncMode3d = true;
    bool autoSyncMode2d = true;

    if (physics3d)
    {
        autoSyncMode3d = physics3d->GetAutoSyncTransforms();
        physics3d->SetAutoSyncTransforms(false, false);
    }
    if (physics2d)
    {
        autoSyncMode2d = physics2d->GetAutoSyncTransforms();
        physics2d->SetAutoSyncTransforms(false, false);
    }

    ScheduleDifferentJobsConcurrent(jobGroup, jobs, jobsCount);
    SyncFence(jobGroup);

    if (physics3d)
    {
        physics3d->SetAutoSyncTransforms(autoSyncMode3d, false);
    }
    if (physics2d)
    {
        physics2d->SetAutoSyncTransforms(autoSyncMode2d, false);
    }
}

void FlareManager::UpdateJob(FlareManagerUpdateJobData* job)
{
    PROFILER_AUTO(gFlareUpdateProfile, NULL)

    const float camFar = job->m_CamFar;
    const Vector3f& camPosition = job->m_CamPosition;

    IRaycast* raycast = GetRaycastInterface();
    IPhysics2D* raycast2D = GetIPhysics2D();

    for (int j = 0; j < job->m_NumJobsInBatch; ++j)
    {
        const FlareEntry* i = job->m_Flares[j];
        float* brightness = job->m_Brightness[j];
        const Vector3f& pos = job->m_Position[j];

        int layers = ~i->ignoredLayers;

        float fadeAmt = i->fadeSpeed * (IsWorldPlaying() ? GetDeltaTime() : 1.0f);
        // We want flares to fade out at half speed of which they fade in
        float fadeOutAmt = fadeAmt * .5f;

        float targetVisible;
        if (!i->infinite)
        {
            if (pos.z < camFar && (pos.x > 0.0f && pos.x < 1.0f) && (pos.y > 0.0f && pos.y < 1.0f))
                targetVisible = 1.0f;
            else
                targetVisible = 0.0f;
        }
        else
        {
            if (pos.x > 0.0F && pos.x < 1.0F && pos.y > 0.0F && pos.y < 1.0F)
                targetVisible = 1.0f;
            else
                targetVisible = 0.0f;
        }

        if (targetVisible)
        {
            float t = 10000;
            Ray r;
            r.SetOrigin(camPosition);
            if (!i->infinite)
            {
                t = Magnitude(camPosition - i->position);
                r.SetDirection((i->position - camPosition) / t);
            }
            else
                r.SetDirection(-i->position);

            RaycastHit hit;
            if (raycast && raycast->Raycast(r, t, layers, QueryTriggerInteraction_UseGlobal, hit))
                targetVisible = 0.0f;

            RaycastHit2D hit2D;
            if (targetVisible != 0.0f && raycast2D && raycast2D->Raycast(r, t, layers, hit2D))
                targetVisible = 0.0f;
        }

        if (targetVisible > *brightness)
        {
            *brightness += fadeAmt;
            if (*brightness > 1.0f)
                *brightness = 1.0f;
        }
        else if (targetVisible < *brightness)
        {
            *brightness -= fadeOutAmt;
            if (*brightness < 0.0f)
                *brightness = 0.0f;
        }
    }

    // Just like ScheduleJob, it is the responsibility of the job to deallocate user data
    UNITY_DELETE(job, kMemTempJobAlloc);
}

struct FlareManagerGeometryJob
{
    FlareManagerGeometryJob() {}

    Matrix4x4f m_WorldToCamera;
    Matrix4x4f m_CameraToWorld;
    float m_Visibility;
    ColorRGBAf m_TintColor;
    int m_TextureLayout;
    float m_FogDensity;
    float m_DoubleNearDistance;
    bool m_Infinite;
    bool m_UseFog;
    Vector3f m_Position;
    Vector2f m_PixelOffset;
    int m_NumElements;
    bool m_renderStereoFlares;
    Flare::FlareElement m_FlareElements[1];     // extra memory is allocated based on m_NumElements
};

void FlareManager::LoadFlareMaterial()
{
    // Create the material used for the flares
    GetGraphicsSettings().GetBuiltinShaderSettings(GraphicsSettings::kLensFlare).CreateMaterialIfNeeded(&m_FlareMaterial);
}

void FlareManager::RenderFlares(const Matrix4x4f& worldToCamera)
{
    LoadFlareMaterial();
    if (m_FlareMaterial == NULL)
        return;

    Shader* shader = m_FlareMaterial->GetShader();
    if (!shader)
        return;
    const int ssIndex = shader->GetActiveSubShaderIndex();
    if (!GetCurrentCameraPtr())
        return;

    PROFILER_AUTO(gFlareRenderProfile, NULL)

    Camera &cam = GetCurrentCamera();
    Matrix4x4f cameraToWorld;
    Matrix4x4f::Invert_Full(worldToCamera, cameraToWorld);
    float fogDensity = GetRenderSettings().GetUseFog() ? GetRenderSettings().GetFogDensity() : 0.0f;
    float doubleNearDistance = cam.GetNear() * 2.0F;

    Update();

    if (!m_Flares.size())
        return;

    GfxDevice& device = GetGfxDevice();

    RendererList::iterator it = m_Renderers.find(&cam);
    Assert(it->second.size() == m_Flares.size());
    float *brightness = &it->second[0];

    // allocate temp memory
    int numFlares = 0;

    FlareEntry** flareEntries;
    ALLOC_TEMP_AUTO(flareEntries, m_Flares.size());

    Flare** flares;
    ALLOC_TEMP_AUTO(flares, m_Flares.size());

    Texture** flareTextures;
    ALLOC_TEMP_AUTO(flareTextures, m_Flares.size());

    bool renderStereoFlares = cam.GetStereoEnabled();
    float* flareBrightness;
    ALLOC_TEMP_AUTO(flareBrightness, m_Flares.size());

    // Cache visible flares
    int totalElements = 0;
    for (FlareList::iterator i = m_Flares.begin(); i != m_Flares.end(); ++i, ++brightness)
    {
        if (!i->used)
            continue;

        if ((*brightness) <= 0.0f)
            continue;

        Flare *fl = i->flare;
        if (!fl)
            continue;

        Texture* flareTex = fl->GetTexture();
        if (!flareTex)
            continue;

        // Add visible flare
        flareEntries[numFlares] = &(*i);
        flares[numFlares] = fl;
        flareTextures[numFlares] = flareTex;
        flareBrightness[numFlares++] = *brightness;

        // How much memory we need for the element arrays
        totalElements += fl->m_Elements.size();
    }

    // No visible flares?
    if (!numFlares)
        return;

    // Allocate geometry job data
    BatchAllocator batchAllocator;
    DynamicVBOGeometryJobData* geometryJobData = NULL;
    batchAllocator.AllocateRoot(geometryJobData, 1);
    batchAllocator.AllocateField(geometryJobData->data, numFlares);
    batchAllocator.AllocateField(geometryJobData->userData, ((sizeof(int) * numFlares) + (sizeof(FlareManagerGeometryJob) * numFlares) + (sizeof(Flare::FlareElement) * totalElements)) / sizeof(int), ALIGN_OF(int), sizeof(int));
    batchAllocator.Commit(kMemTempJobAlloc);

    // Populate job data
    int elementOffset = 0;
    for (int i = 0; i < numFlares; i++)
    {
        FlareManager::FlareEntry* f = flareEntries[i];
        Flare *fl = flares[i];
        Texture* flareTex = flareTextures[i];

        geometryJobData->data[i] = GeometryJobData(sizeof(FlareVertex), fl->m_Elements.size() * 4, 0);

        int userDataOffset = (sizeof(int) * numFlares) + (sizeof(FlareManagerGeometryJob) * i) + (sizeof(Flare::FlareElement) * elementOffset);
        ((int*)geometryJobData->userData)[i] = userDataOffset;  // offset into the user data where this FlareManagerGeometryJob starts

        FlareManagerGeometryJob& jobData = (FlareManagerGeometryJob&)((UInt8*)geometryJobData->userData)[userDataOffset];
        jobData.m_NumElements = fl->m_Elements.size();
        jobData.m_WorldToCamera = worldToCamera;
        jobData.m_CameraToWorld = cameraToWorld;
        jobData.m_Visibility = f->brightness * flareBrightness[i];
        jobData.m_TintColor = f->color;
        jobData.m_TextureLayout = fl->m_TextureLayout;
        jobData.m_FogDensity = fogDensity;
        jobData.m_DoubleNearDistance = doubleNearDistance;
        jobData.m_Infinite = f->infinite;
        jobData.m_UseFog = fl->m_UseFog;
        jobData.m_Position = f->position;
        jobData.m_renderStereoFlares = renderStereoFlares;

        // Get the UV offsets to address the texture on texel boundaries
        // Use this to work around OpenGL's feature that UVs are in the middle of a texel.
        jobData.m_PixelOffset.Set(flareTex->GetTexelSizeX() * 0.5f, flareTex->GetTexelSizeY() * 0.5f);

        int elementIndex = 0;
        std::vector<Flare::FlareElement>::const_iterator it, itEnd = fl->m_Elements.end();
        for (it = fl->m_Elements.begin(); it != itEnd; ++it)
        {
            jobData.m_FlareElements[elementIndex++] = *it;
        }

        elementOffset += fl->m_Elements.size();
    }

    Texture *lastTex = NULL;
    ShaderChannelMask channels = kShaderChannelMaskInvalid;

    DynamicVBOChunkHandle vboChunk;
    device.ScheduleDynamicVBOGeometryJobs(RenderGeometryJob, ReleaseGeometryJobMem, NULL, geometryJobData, numFlares, kPrimitiveQuads, &vboChunk);
    geometryJobData = NULL; // the final job deallocates this, so prevent this thread from using the pointer again

    Matrix4x4f matView = device.GetViewMatrix();
    Matrix4x4f matWorld = device.GetWorldMatrix();

    if (!renderStereoFlares)
    {
        device.SetViewMatrix(Matrix4x4f::identity); // implicitly sets world to identity
    }

    device.SetWorldMatrix(Matrix4x4f::identity);

    // Render
    UInt32 batchStart = 0;
    UInt32 batchCount = 0;
    ShaderPassContext& passContext = GetDefaultPassContext();
    for (int i = 0; i < numFlares; ++i)
    {
        Flare* fl = flares[i];
        Texture* flareTex = flareTextures[i];

        UInt32 vertexCount = fl->m_Elements.size() * 4;

        if (lastTex != flareTex)
        {
            if (batchCount)
            {
                DynamicVBO::DrawParams params(sizeof(FlareVertex), batchStart, batchCount, 0, (batchCount / 4) * 6);
                device.GetDynamicVBO().DrawChunk(vboChunk, channels, gFlareVertexFormat.GetVertexFormat()->GetAvailableChannels(), gFlareVertexFormat.GetVertexDecl(channels), &params, 1);
                GPU_TIMESTAMP();
                batchStart += batchCount * sizeof(FlareVertex);
                batchCount = 0;
            }

            lastTex = flareTex;
            passContext.properties.SetTexture(kSLPropFlareTexture, lastTex);
            channels = m_FlareMaterial->SetPassSlow(0, passContext, ssIndex);
        }

        batchCount += vertexCount;
    }
    if (batchCount)
    {
        DynamicVBO::DrawParams params(sizeof(FlareVertex), batchStart, batchCount, 0, (batchCount / 4) * 6);
        device.GetDynamicVBO().DrawChunk(vboChunk, channels, gFlareVertexFormat.GetVertexFormat()->GetAvailableChannels(), gFlareVertexFormat.GetVertexDecl(channels), &params, 1);
        GPU_TIMESTAMP();
    }

    if (!renderStereoFlares)
    {
        device.SetViewMatrix(matView);
    }

    device.SetWorldMatrix(matWorld);
}

void SetupStereoFlareElement(FlareVertex* flareVertexBuffer, const Vector2f& size, const Vector2f& uv0, const Vector2f& uv1, const ColorRGBA32& color, const Matrix4x4f& cameraToWorld, const Vector3f& elementPosWS, bool flareElementRotates)
{
    Vector3f direction = cameraToWorld.GetPosition() - elementPosWS;
    Matrix3x3f transformation;

    const Vector3f& upAxisY = (flareElementRotates) ? Vector3f::yAxis : cameraToWorld.GetAxisY();
    const Vector3f& upAxisX = (flareElementRotates) ? Vector3f::xAxis : cameraToWorld.GetAxisY();

    if (!LookRotationToMatrix(direction, upAxisY, &transformation))
    {
        LookRotationToMatrix(direction, upAxisX, &transformation);
    }


    Vector3f right(transformation.GetColumn(0));
    Vector3f up(transformation.GetColumn(1));

    flareVertexBuffer[0].vert = elementPosWS - right * size.x - up * size.y;
    flareVertexBuffer[0].uv.Set(uv0.x, uv0.y);
    flareVertexBuffer[0].color = color;

    flareVertexBuffer[1].vert = elementPosWS + right * size.y - up * size.x;
    flareVertexBuffer[1].uv.Set(uv1.x, uv0.y);
    flareVertexBuffer[1].color = color;

    flareVertexBuffer[2].vert = elementPosWS + right * size.x + up * size.y;
    flareVertexBuffer[2].uv.Set(uv1.x, uv1.y);
    flareVertexBuffer[2].color = color;

    flareVertexBuffer[3].vert = elementPosWS - right * size.y + up * size.x;
    flareVertexBuffer[3].uv.Set(uv0.x, uv1.y);
    flareVertexBuffer[3].color = color;
}

void SetupMonoFlareElement(FlareVertex* flareVertexBuffer, const Vector2f& size, const Vector2f& uv0, const Vector2f& uv1, const ColorRGBA32& color, const Vector3f& elementPosVS)
{
    flareVertexBuffer[0].vert.Set(elementPosVS.x - size.x, elementPosVS.y - size.y, elementPosVS.z);
    flareVertexBuffer[0].uv.Set(uv1.x, uv0.y);
    flareVertexBuffer[0].color = color;

    flareVertexBuffer[1].vert.Set(elementPosVS.x + size.y, elementPosVS.y - size.x, elementPosVS.z);
    flareVertexBuffer[1].uv.Set(uv0.x, uv0.y);
    flareVertexBuffer[1].color = color;

    flareVertexBuffer[2].vert.Set(elementPosVS.x + size.x, elementPosVS.y + size.y, elementPosVS.z);
    flareVertexBuffer[2].uv.Set(uv0.x, uv1.y);
    flareVertexBuffer[2].color = color;

    flareVertexBuffer[3].vert.Set(elementPosVS.x - size.y, elementPosVS.y + size.x, elementPosVS.z);
    flareVertexBuffer[3].uv.Set(uv1.x, uv1.y);
    flareVertexBuffer[3].color = color;
}

void FlareManager::RenderGeometryJob(DynamicVBOGeometryJobData* jobData, unsigned int index)
{
    PROFILER_AUTO(gFlareGeometryJobProfile, 0)

    GeometryJobData& data = jobData->data[index];

    int userDataOffset = ((int*)jobData->userData)[index];
    FlareManagerGeometryJob& userData = (FlareManagerGeometryJob&)((UInt8*)jobData->userData)[userDataOffset];

    if (data.mappedVertexData)
    {
        FlareVertex* vbPtr = (FlareVertex*)data.mappedVertexData;

        const ColorRGBAf& tintColor = userData.m_TintColor;
        int textureLayout = userData.m_TextureLayout;
        float fogDensity = userData.m_FogDensity;
        const Vector2f& pixelOffset = userData.m_PixelOffset;
        Matrix3x3f transformation;

        Vector3f positionVS;
        if (!userData.m_Infinite)
            positionVS = userData.m_WorldToCamera.MultiplyPoint3(userData.m_Position);
        else
            positionVS = userData.m_WorldToCamera.MultiplyVector3(-userData.m_Position * userData.m_DoubleNearDistance);

        Vector2f p(positionVS.x, positionVS.y);
        p = NormalizeSafe(p,  Vector2f(1, 0));

        float visibility = userData.m_Visibility;
        if (userData.m_UseFog)
            visibility *= 1.0f - RenderSettings::CalcFogFactor(fogDensity, positionVS.z);

        for (int i = 0; i < userData.m_NumElements; ++i)
        {
            const Flare::FlareElement& element = userData.m_FlareElements[i];

            Vector2f uv0, uv1;
            CalculateFlareGetUVCoords(textureLayout, element.m_ImageIndex, pixelOffset, uv0, uv1);

            // Had to invert uv's when we flipped all our textures to conform to opengl
            // the actual code using the uv's should flip uv's instead of this fix.
            uv0.y = 1.0F - uv0.y;
            uv1.y = 1.0F - uv1.y;

            float s = element.m_Size * positionVS.z * (element.m_Zoom ? visibility * 0.01f : 0.01f);
            Vector2f size;
            if (element.m_Rotate)
            {
                size = p * (s * 1.4f);
            }
            else
            {
                size.x = size.y  = s;
            }

            ColorRGBA32 color;

            const float gammaIntensityModifier = LinearToGammaSpace(visibility);

            if (!element.m_UseLightColor)
            {
                color = (element.m_Color * gammaIntensityModifier);
            }
            else
            {
                ColorRGBAf col = element.m_Color;
                col.r *= tintColor.r;
                col.g *= tintColor.g;
                col.b *= tintColor.b;
                col.a *= tintColor.a;
                if (element.m_Fade)
                    col = col * (gammaIntensityModifier);
                color = col;
            }
            color = GammaToActiveColorSpace(color);

            Vector3f posVS = Lerp(positionVS, Vector3f(0, 0, positionVS.z), element.m_Position);

            // vertices
            if (userData.m_renderStereoFlares)
            {
                SetupStereoFlareElement(vbPtr, size, uv0, uv1, color, userData.m_CameraToWorld, userData.m_CameraToWorld.MultiplyPoint3(posVS), element.m_Rotate);
            }
            else
            {
                SetupMonoFlareElement(vbPtr, size, uv0, uv1, color, posVS);
            }

            vbPtr += 4;
        }
    }
}

void FlareManager::ReleaseGeometryJobMem(DynamicVBOGeometryJobData* jobData)
{
    PROFILER_AUTO(gFlareGeometryJobProfile, 0)
    BatchAllocator::DeallocateRoot(kMemTempJobAlloc, jobData);
}

FlareManager& GetFlareManager()
{
    return *(s_FlareManager.EnsureInitialized());
}

IMPLEMENT_REGISTER_CLASS(LensFlare, 123);
IMPLEMENT_OBJECT_SERIALIZE(LensFlare);

LensFlare::LensFlare(MemLabelId label, ObjectCreationMode mode)
    :   Super(label, mode)
{
    m_Handle = -1;
    m_FadeSpeed = 3.0f;
}

void LensFlare::ThreadedCleanup()
{
}

void LensFlare::Reset()
{
    Super::Reset();
    m_Brightness = 1.0f;
    m_Color = ColorRGBAf(1, 1, 1, 0);
    m_Directional = false;
    m_FadeSpeed = 3.0f;
    m_IgnoreLayers.m_Bits = kNoFXLayerMask | kIgnoreRaycastMask;
}

template<class TransferFunc>
void LensFlare::Transfer(TransferFunc& transfer)
{
    Super::Transfer(transfer);
    TRANSFER(m_Flare);
    TRANSFER(m_Color);
    TRANSFER(m_Brightness);
    TRANSFER(m_FadeSpeed);
    TRANSFER(m_IgnoreLayers);
    TRANSFER(m_Directional);
}

inline void LensFlare::UpdateFlare()
{
    GetFlareManager().UpdateFlare(m_Handle, m_Flare, GetComponent<Transform>(), m_Directional,
        m_Brightness, m_Color, m_FadeSpeed,
        GetGameObject().GetLayerMask(), m_IgnoreLayers.m_Bits
        );
}

void LensFlare::AwakeFromLoad(AwakeFromLoadMode awakeMode)
{
    Super::AwakeFromLoad(awakeMode);
    if ((awakeMode & kDidLoadFromDisk) == 0 && m_Handle != -1)
        UpdateFlare();
}

void LensFlare::SetBrightness(float brightness)
{
    m_Brightness = brightness;
    SetDirty();
    if (m_Handle != -1)
        UpdateFlare();
}

void LensFlare::SetFadeSpeed(float fadeSpeed)
{
    m_FadeSpeed = fadeSpeed;
    SetDirty();
    if (m_Handle != -1)
        UpdateFlare();
}

void LensFlare::SetColor(const ColorRGBAf& color)
{
    m_Color = color;
    SetDirty();
    if (m_Handle != -1)
        UpdateFlare();
}

void LensFlare::SetFlare(Flare *flare)
{
    m_Flare = flare;
    SetDirty();
    if (m_Handle != -1)
        UpdateFlare();
}

void LensFlare::AddToManager()
{
    m_Handle = GetFlareManager().AddFlare();
    UpdateFlare();
}

void LensFlare::RemoveFromManager()
{
    GetFlareManager().DeleteFlare(m_Handle);
    m_Handle = -1;
}

IMPLEMENT_REGISTER_CLASS(FlareLayer, 124);

FlareLayer::FlareLayer(MemLabelId label, ObjectCreationMode mode)
    : Super(label, mode)
{}

void FlareLayer::ThreadedCleanup()
{
}

void FlareLayer::AddToManager()
{
    Camera &cam = GetComponent<Camera>();
    GetFlareManager().AddCamera(cam);
}

void FlareLayer::RemoveFromManager()
{
    Camera &cam = GetComponent<Camera>();
    GetFlareManager().RemoveCamera(cam);
}

IMPLEMENT_REGISTER_CLASS(Flare, 121);
IMPLEMENT_OBJECT_SERIALIZE(Flare);
