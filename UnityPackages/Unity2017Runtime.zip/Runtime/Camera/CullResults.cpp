#include "UnityPrefix.h"
#include "CullResults.h"
#include "SharedLightData.h"
#include "Runtime/2D/Sorting/SortingGroupManager.h"
#include "Runtime/Camera/LightProbeProxyVolume.h"
#include "Runtime/Camera/SharedRendererScene.h"
#include "Runtime/Interfaces/IUmbra.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Geometry/Intersection.h"
#include "Runtime/Camera/RenderSettings.h"
#include "Runtime/Graphics/LightmapSettings.h"
#include "Runtime/Utilities/ArrayUtility.h"
#include "Runtime/Jobs/Jobs.h"
#include "ShadowCulling.h"
#include "RenderNodeQueuePrepareContext.h"
#include "Runtime/Testing/Faking.h"


PROFILER_INFORMATION(gDestroyCullResults                , "DestroyCullResults" , kProfilerRender);
PROFILER_INFORMATION(gCreateSharedRendererScene, "CullResults.CreateSharedRendererScene", kProfilerRender);


CullResults::CullResults() :
    needsCullCallback(kMemTempJobAlloc),
    shadowedLights(kMemTempJobAlloc),
    lodDataArrays(kMemTempJobAlloc),
    treeSceneNodes(kMemTempJobAlloc),
    treeBoundingBoxes(kMemTempJobAlloc),
    shadowCullData(NULL),
    visibleSceneIndexListCombined(kMemTempJobAlloc),
    dynamicBounds(kMemTempJobAlloc),
    isValid(false),
    sharedRendererScene(NULL)
{
    for (size_t i = 0; i < kRendererTypeCount; i++)
        rendererCullCallbacks[i].set_memory_label(kMemTempJobAlloc);
}

void SyncFenceCullResults(CullResults& results)
{
    SyncFence(results.sceneCullingOutputIsReady);
    SyncFence(results.occlusionBufferIsReady);
    SyncFence(results.generateCombinedDynamicListReady);
    SyncFence(results.addLocalLightsFence);
    SyncFence(results.cullLocalLightsFence);
    for (size_t i = 0; i < results.shadowedLights.size(); i++)
        SyncFence(results.shadowedLights[i].shadowCasterCullingOutputIsReady);
}

ActiveLights::~ActiveLights()
{
    for (size_t i = 0; i < lights.size(); i++)
        lights[i].light->Release();
}

void CopyActiveLights(const ActiveLights& src, ActiveLights& dst)
{
    dst = src;
    for (size_t i = 0; i < dst.lights.size(); i++)
        dst.lights[i].light->AddRef();
}

CullResults::~CullResults()
{
    PROFILER_AUTO(gDestroyCullResults, NULL)

    SyncFenceCullResults(*this);

    DestroySharedRendererScene();

    if (sceneCullingOutput.umbraVisibility)
        GetIUmbra()->FreeVisibility(sceneCullingOutput.umbraVisibility, false, kMemTempJobAlloc);

    for (size_t i = 0; i < shadowedLights.size(); i++)
    {
        DestroyCullingOutput(shadowedLights[i].visibleShadowCasters);
        if (shadowedLights[i].shadowCuller)
            GetIUmbra()->DeleteShadowCuller(shadowedLights[i].shadowCuller);
    }

    DestroyCullingOutput(sceneCullingOutput);

    UNITY_DELETE(shadowCullData, kMemTempJobAlloc);
}

void InitIndexList(IndexList& list, size_t count)
{
    int* array = (int*)UNITY_MALLOC(kMemTempJobAlloc, count * sizeof(int));
    list = IndexList(array, 0, count);
}

void DestroyIndexList(IndexList& list)
{
    UNITY_FREE(kMemTempJobAlloc, list.indices);
    list.indices = NULL;
}

void CreateCullingOutput(const RendererCullData* rendererCullData, CullingOutput& cullingOutput)
{
    for (int i = 0; i < kVisibleListCount; i++)
        InitIndexList(cullingOutput.visible[i], rendererCullData[i].rendererCount);
}

void DestroyCullingOutput(CullingOutput& cullingOutput)
{
    for (int i = 0; i < kVisibleListCount; i++)
        DestroyIndexList(cullingOutput.visible[i]);
}

void CullResults::Init(const Umbra::Tome* tome)
{
    activeLights.numDirLights = 0;
    activeLights.numSpotLights = 0;
    activeLights.numPointLights = 0;
    activeLights.numOffScreenSpotLights = 0;
    activeLights.numOffScreenPointLights = 0;

    if (tome != NULL)
    {
        InitIndexList(sceneCullingOutput.visible[kStaticRenderers], GetIUmbra()->GetUmbraObjectCount(tome));

        sceneCullingOutput.umbraVisibility = GetIUmbra()->AllocateVisibility(tome, sceneCullingOutput.visible[kStaticRenderers].indices, kMemTempJobAlloc);
    }
    else
    {
        sceneCullingOutput.umbraVisibility = NULL;
    }
}

void CullResults::InitDynamic(const RendererCullData* rendererCullData)
{
    for (int i = kStaticRenderers + 1; i < kVisibleListCount; i++)
        InitIndexList(sceneCullingOutput.visible[i], rendererCullData[i].rendererCount);

    // Setup static index lists in case there is no umbra culling going on
    if (sceneCullingOutput.umbraVisibility == NULL)
    {
        Assert(sceneCullingOutput.visible[kStaticRenderers].reservedSize == 0);
        InitIndexList(sceneCullingOutput.visible[kStaticRenderers], rendererCullData[kStaticRenderers].rendererCount);
    }
    else
    {
        Assert(rendererCullData[kStaticRenderers].rendererCount == sceneCullingOutput.visible[kStaticRenderers].reservedSize);
    }
}

void SetCullingPlanes(CullingParameters& parameters, const Plane* planes, int planeCount)
{
    parameters.cullingPlaneCount = planeCount;

    for (int i = 0; i < planeCount; i++)
        parameters.cullingPlanes[i] = planes[i];
}

void CalculateCustomCullingParameters(CullingParameters& cullingParameters, const LODParameters& lodParams, UInt32 cullingMask, const Plane* planes, int planeCount)
{
    cullingParameters.lodParams = lodParams;

    // Shadow code handles per-layer cull distances itself

    Assert(planeCount <= CullingParameters::kMaxPlanes);
    SetCullingPlanes(cullingParameters, planes, planeCount);
    cullingParameters.cullingPlaneCount = planeCount;
    cullingParameters.layerCull = CullingParameters::kLayerCullNone;
    cullingParameters.cullingMask = cullingMask;
    cullingParameters.sceneMask = kDefaultSceneCullingMask;
}

// @TODO:  jobify?
static void CullReflectionProbes(SharedRendererScene* sharedRendererScene, CullResults& results)
{
    const CullingParameters& cullingParameters = results.sceneCullParameters;
    ReflectionProbesContext &context = results.sharedRendererScene->reflectionProbesContext;
    sharedRendererScene->reflectionProbesContext.CopyFrom(GetReflectionProbes().GetContext());

    dynamic_array<Plane> planes(kMemTempAlloc);
    planes.resize_uninitialized(CullingParameters::kMaxPlanes);

    for (int i = 0; i < context.cubes.size(); i++)
    {
        bool visible = ((context.cubes[i].sceneMask & cullingParameters.sceneMask) != 0);

        Matrix4x4f mat = context.cubes[i].transform;
        Vector3f offset = mat.GetPosition();

        // NOTE:  normally, for a general matrix M, we'd need to multiply by the transpose of the inverse of M.
        // in our case, M is already the inverse of a known matrix, and the position is implicit in the AABB --
        // so we just want the 3x3 transpose (i.e. rotation/scale), which simplifies things quite a bit.
        for (int j = 0; j < cullingParameters.cullingPlaneCount; j++)
        {
            Plane plane = cullingParameters.cullingPlanes[j];

            float localDist = plane.distance + Dot(offset, plane.normal);

            // this function really should be called TransposeMultiplyVector3(), but that's exactly what we want...
            plane.normal = mat.InverseMultiplyVector3Affine(plane.normal);
            plane.distance = localDist - Dot(offset, plane.normal);

            float rmag = 1.0f / Magnitude(plane.normal);
            plane.normal *= rmag;
            plane.distance *= rmag;

            planes[j] = plane;
        }

        if (visible)
            visible &= IntersectAABBPlaneBounds(context.aabbs[i], planes.data(), cullingParameters.cullingPlaneCount);

        context.cubes[i].visible = visible;
    }
}

const SharedRendererScene* CullResults::GetOrCreateSharedRendererScene()
{
    PROFILER_AUTO(gCreateSharedRendererScene, NULL);

    __FAKEABLE_METHOD__(CullResults, GetOrCreateSharedRendererScene, ());

    if (sharedRendererScene == NULL)
    {
        CullResults& cullResults = *this;
        sharedRendererScene = UNITY_NEW(SharedRendererScene, kMemTempJobAlloc)(kMemTempJobAlloc);

        ExtractRenderNodeQueue(cullResults, kDefaultSceneExtractionFlags, sharedRendererScene->queue);

        SyncFence(cullResults.addLocalLightsFence);
        CopyActiveLights(cullResults.activeLights, sharedRendererScene->activeLights);

        CullAllPerObjectLights(cullResults.sceneCullParameters.renderPath, sharedRendererScene->queue, sharedRendererScene->activeLights, sharedRendererScene->perObjectLightCulling);

        CullReflectionProbes(sharedRendererScene, cullResults);

        sharedRendererScene->lightProbeProxyVolumeContext.CopyFrom(GetLightProbeProxyVolumeManager().GetContext());
        const LightmapSettings& lightmaps = GetLightmapSettings();
        sharedRendererScene->lightProbeContext.Init(lightmaps, GetRenderSettings());
        sharedRendererScene->lightmapSettingsData = lightmaps.AcquireSharedData();
        GetSortingGroupManager().CopyTo(sharedRendererScene->sortingGroupDataArray);
    }

    return sharedRendererScene;
}

void CullResults::DestroySharedRendererScene()
{
    if (sharedRendererScene)
    {
        sharedRendererScene->Release();
        sharedRendererScene = NULL;
    }
}
