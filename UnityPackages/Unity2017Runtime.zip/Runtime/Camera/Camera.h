#pragma once

#include "CameraTypes.h"
#include "Runtime/GameCode/Behaviour.h"
#include <vector>
#include "Runtime/Math/Rect.h"
#include "Runtime/Math/Color.h"
#include "Runtime/Geometry/Ray.h"
#include "Runtime/Graphics/CommandBuffer/RenderingEvents.h"
#include "Runtime/Camera/RenderLoops/RenderLoop.h" //@TODO remove
#include "Runtime/Camera/RenderManager.h"
#include "Runtime/Modules/ExportModules.h"
#include "Runtime/Camera/CullingParameters.h"
#include "Runtime/Shaders/GraphicsCaps.h"
#include "Runtime/Shaders/ShaderPassContext.h"
#include "Runtime/GfxDevice/GfxDeviceObjects.h"
#include "Runtime/SceneManager/UnityScene.h"
#include "CameraCullingParameters.h"

#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Graphics/QualitySettings.h"


struct CoreCameraValues;
struct SharedRendererScene;
struct ImageFilter;
class CameraStackRenderingState;
class Cubemap;
class Plane;
class IntermediateRenderers;
class Texture;
class TextureRef;
class Shader;
class Material;
class RenderTexture;
class GfxDevice;
struct RenderLoop;
struct ShadowCullData;
struct CullResults;
struct CullingParameters;
struct ShaderPassContext;
struct ShaderReplaceData;
struct SceneCullingParameters;
struct CameraCullingParameters;
struct ShadowMapCache;
class Vector2f;
struct ScriptingRenderBuffer;
struct DrawGridParameters;

namespace Umbra
{ class DebugRenderer; }

DECLARE_MESSAGE_IDENTIFIER(kPreCull);
DECLARE_MESSAGE_IDENTIFIER(kPostRender);
DECLARE_MESSAGE_IDENTIFIER(kPreRender);

// The Camera
class EXPORT_COREMODULE Camera : public Behaviour
{
    // Tag class as sealed, this makes QueryComponent faster.
    REGISTER_CLASS_TRAITS(kTypeIsSealed);
    REGISTER_CLASS(Camera);
    DECLARE_OBJECT_SERIALIZE();
public:
    // Match OpaqueSortMode on C# side
    enum OpaqueSortMode
    {
        kOpaqueSortDefault = 0, // bucketed front-to-back or no depth sorting, depending on the GPU
        kOpaqueSortFrontToBack = 1,
        kOpaqueSortNoDepthSort = 2,
    };

    // Match TransparencySortMode on C# side
    enum TransparencySortMode
    {
        kTransparencySortDefault = 0,
        kTransparencySortPerspective = 1,
        kTransparencySortOrthographic = 2,
        kTransparencySortCustomAxis = 3,
    };

    enum
    {
        kPreviewLayer = 31,
        kNumLayers = 32
    };

    // used to save/restore the internal matrix state
    struct MatrixState
    {
        Matrix4x4f viewMatrix;
        Matrix4x4f projMatrix;
        Matrix4x4f skyboxProjMatrix;

        bool implicitViewMatrix;
        bool implicitProjMatrix;
        bool implicitSkyboxProjMatrix;
    };

    enum RenderPlane
    {
        // Render plane that is behind of the scene.
        kBackPlane,
        // Render plane that is in front of the scene for opaque or transparent rendering.
        kFrontPlaneOpaque,
        kFrontPlaneTransparent,
        kNumRenderPlanes
    };

    // Callback to draw into the camera render planes.
    // - camera is the one that is rendering.
    // - userData is the same as what is passed to AddRenderPlaneCallback.
    typedef void (*RenderPlaneCallback)(Camera& camera, void* userData);

    enum RenderFlag
    {
        kRenderFlagNone,
        kRenderFlagStandalone = 1 << 0,
        kRenderFlagSinglePassStereo = 1 << 1,
        kRenderFlagSetRenderTarget = 1 << 2,
        kRenderFlagDontRestoreRenderState = 1 << 4,
        kRenderFlagSetRenderTargetFinal = 1 << 5,
        kRenderFlagExplicitShaderReplace = 1 << 6,
        kRenderFlagDontBlitTargetTexture = 1 << 7,
        kRenderFlagInstancingStereo = 1 << 8,
        kRenderFlagMultiviewStereo = 1 << 9,
        kRenderFlagUseExistingCameraStackRenderingState = 1 << 10,
    };

    enum StereoViewMatrixMode
    {
        // The stereo view matrices are computed by the camera
        kStereoViewMatrixModeImplicit,

        // The stereo view matrices have been set to arbitrary
        // values which requires a double cull
        kStereoViewMatrixModeExplicitUnsafeForSingleCull,

        // The stereo view matrices have been set outside
        // the camera, but close enough to the mono camera
        // that we can still assume a single cull is enough
        kStereoViewMatrixModeExplicitSafeForSingleCull,
    };

    class PerformRenderFunction
    {
    public:
        virtual void operator()(Camera* camera, RenderingPath renderPath, CullResults* cullResults) = 0;
        virtual ~PerformRenderFunction() {}
    };

    class DefaultPerformRenderFunction : public PerformRenderFunction
    {
        // This class is implemented as a Singleton because we want to easily be able to tell
        // if more than one DefaultPerformRenderFunction is executed in MultiCustomRender.
        // We chose the Singleton strategy because this class has no data members.
    public:
        virtual void operator()(Camera* camera, RenderingPath renderPath, CullResults* cullResults)
        {
            if (camera && cullResults)
                DoRenderLoop(*camera->m_RenderLoop, renderPath, *cullResults, *camera->m_ShadowCache, camera->GetRenderImmediateObjects());
        }

        static DefaultPerformRenderFunction& Instance()
        {
            static DefaultPerformRenderFunction instance;
            return instance;
        }

    private:
        DefaultPerformRenderFunction() {}
        DefaultPerformRenderFunction(const DefaultPerformRenderFunction&) {}
        DefaultPerformRenderFunction& operator=(const DefaultPerformRenderFunction&) { return *this; }
        ~DefaultPerformRenderFunction() {}
    };

    class RenderNodeQueuePerformRenderFunction : public PerformRenderFunction
    {
    public:
        typedef void(*FunctionPtr)(Camera& camera, const RenderNodeQueue& queue);
        RenderNodeQueuePerformRenderFunction(FunctionPtr f, const RenderNodeQueue& rnq)
            : m_Function(f)
            , m_RenderNodeQueue(rnq)
        {
        }

        virtual void operator()(Camera* camera, RenderingPath renderPath, CullResults* cullResults)
        {
            m_Function(*camera, m_RenderNodeQueue);
        }

        FunctionPtr m_Function;
        const RenderNodeQueue& m_RenderNodeQueue;
    };

    class PerformEyeRenderFunction
    {
    public:
        virtual void operator()(Camera* camera, CullResults* cullResults, RenderFlag renderFlags) = 0;
        virtual ~PerformEyeRenderFunction() {}
    };

    class DefaultPerformEyeRenderFunction : public PerformEyeRenderFunction
    {
    public:
        virtual void operator()(Camera* camera, CullResults* cullResults, RenderFlag renderFlags)
        {
            if (camera && cullResults)
            {
                CameraRenderingParams params = camera->ExtractCameraRenderingParams();
                camera->Render(*cullResults, GetDefaultPassContext(), &params, renderFlags);
            }
        }
    };


public:
    Camera(MemLabelId label, ObjectCreationMode mode);
    // ~Camera (); declared-by-macro

    virtual void MainThreadCleanup();

    virtual void Reset();
    virtual void AwakeFromLoad(AwakeFromLoadMode awakeMode);

    virtual void CheckConsistency();

    // Extract parameters that are overridden for stereo rendering like position and view matrix
    CameraRenderingParams ExtractCameraRenderingParams() const;

    // Set up the viewport, render target, load modelview & projection matrices
    // Flags are a bitmask of kRenderFlagXXX
    void SetupRender(ShaderPassContext& passContext, RenderFlag renderFlags = kRenderFlagNone);
    void SetupRender(ShaderPassContext& passContext, const CameraRenderingParams& params, RenderFlag renderFlags = kRenderFlagNone);

    bool StereoSetupRenderForSRP(ShaderPassContext& passContext, RenderFlag renderFlags);
    void StereoEndRenderForSRP();
    void StartMultiEyeRendering();
    void StopMultiEyeRendering();

    // Cull with default culling parameters
    void Cull(CullResults& results, CullFlag cullFlags = kCullFlagNone);
    void StandaloneCull(Shader* replacementShader, const core::string& replacementTag, CullResults& results);

    // Cull With custom parameters
    void CustomCull(const CameraCullingParameters& params, CullResults& cullResults, bool sendOnPreCullMessage = true);

    bool SendOnPreCullMessage(const CameraCullingParameters& parameters);

    // Cull scene
    void SetScene(UnityScene *scene);
    UnityScene *GetScene() const;

    void CalculateFrustumPlanes(Plane* frustum, const Matrix4x4f& overrideWorldToClip, float overrideFarPlane, float& outBaseFarDistance, bool implicitNearFar) const;
    void CalculateCullingParameters(CullingParameters& cullingParameters) const;


    // Clear the camera for how its set up - use skybox if neccessary
    void Clear();
    void ClearNoSkybox(bool noDepth);
    void RenderSkybox();

    // Add/remove a callback to draw in the specified render plane.
    //
    // - Order is preserved so the first callback to be installed will be called
    //   first.
    // - Duplicates are ignored; the pair [cb, userData, plane] is the key in the list.
    void AddRenderPlaneCallback(RenderPlaneCallback func, void* userData, RenderPlane plane);
    void RemoveRenderPlaneCallback(RenderPlaneCallback func, void* userData, RenderPlane plane);

    void UpdateVelocity();

    // Set up the camera transform & render
    // Flags are a bitmask of kRenderFlagXXX; kRenderFlagPrepareImageFilters always implied
    void Render(CullResults& cullResults, ShaderPassContext& passContext, RenderFlag renderFlags, RenderManager::PostPerCameraFunctor postPerCameraCall = NULL);
    // If params is passed, use these for rendering (overrides projection etc., mostly for VR/Stereo).
    // Otherwise figure out render params internally, after any camera callbacks are done.
    void Render(CullResults& cullResults, ShaderPassContext& passContext, const CameraRenderingParams* params, RenderFlag renderFlags, RenderManager::PostPerCameraFunctor postPerCameraCall = NULL);
    void CustomRender(CullResults& cullResults, ShaderPassContext& passContext, const CameraRenderingParams* params, RenderFlag renderFlags, PerformRenderFunction* renderFunctionObj, RenderManager::PostPerCameraFunctor postPerCameraCall = NULL);
    void CustomRenderWithPipeline(ShaderPassContext& passContext, RenderFlag renderFlags, PostProcessCullResults* postProcessCullResults = NULL, void* postProcessCullResultsData = NULL);

    // Render to stereoscopic 3d backbuffer
    void RenderStereo(RenderFlag renderFlags, CullFlag cullFlags, PerformEyeRenderFunction* eyeRenderFunctionObj);

    // Out-of-order cull / rendering.
    void StandaloneRender(RenderFlag renderFlags, Shader* replacementShader, const core::string& replacementTag);
    void StandaloneCustomRender(RenderFlag renderFlags, Shader* replacementShader, const core::string& replacementTag, PerformRenderFunction* renderFunctionObj);
    void StandaloneSetup(ShaderPassContext& passContext);

    // Render to a cubemap.
    // - For a render texture it will render into a temp 2D render texture and blit into each face of the cubemap
    // - For a cubemap it will render into a temp 2D render texture, readpixel the contents into the cubemap and upload the texture
    // Thus it is not necessary to have a depth buffer on the target render texture.
    // @faceMask - determines which face to render. For ex., faceMask = 1, will render only first face. faceMask = 63, will render all the faces
    // @resolutionScale - the scaling factor applied to the temp 2D render texture. The content will be downscaled when blitting into the final cubemap face
    bool StandaloneRenderToCubemap(Texture* texture, int faceMask, PostProcessCullResults* postProcessCullResults = NULL, void* postProcessCullResultsData = NULL, UInt32 resolutionScale = 1);

    // Rendering command buffers set for specified camera event.
    void AddCommandBuffer(RenderCameraEventType type, RenderingCommandBuffer* buffer) { m_RenderEvents.AddCommandBuffer(type, buffer); }
    void RemoveCommandBuffer(RenderCameraEventType type, RenderingCommandBuffer* buffer) { m_RenderEvents.RemoveCommandBuffer(type, buffer); }
    void RemoveCommandBuffers(RenderCameraEventType type) { m_RenderEvents.RemoveCommandBuffers(type); }
    void RemoveAllCommandBuffers() { m_RenderEvents.RemoveAllCommandBuffers(); }
    const RenderEventsContext::CommandBufferArray& GetCommandBuffers(RenderCameraEventType type) { return m_RenderEvents.GetCommandBuffers(type); }
    int GetCommandBufferCount() const { return m_RenderEvents.GetCommandBufferCount(); }
    void InvokeRenderEventCB(RenderCameraEventType type, ShaderPassContext& passContext, RenderNodeQueue& nodeQueue)
    {
        if (type == kRenderEvent_BeforeForwardOpaque)
            InvokeRenderPlaneCallbacks(kFrontPlaneOpaque);
        else if (type == kRenderEvent_BeforeForwardAlpha)
            InvokeRenderPlaneCallbacks(kBackPlane);
        else if (type == kRenderEvent_AfterForwardAlpha)
            InvokeRenderPlaneCallbacks(kFrontPlaneTransparent);

        profiling::Marker* profilerInfos = NULL;
        #if ENABLE_PROFILER
        profilerInfos = kProfilerBlocksForRenderCameraEvents;
        #endif
        m_RenderEvents.ExecuteCommandBuffers(type, RenderEventsContext::kFullMask, passContext, nodeQueue, profilerInfos, GetInstanceID());
    }

    // One of built-in temporary render textures
    RenderTexture* GetBuiltinRenderTexture(BuiltinRenderTextureType type);

    void SetFov(float deg);
    float GetFov() const;
    void ResetFieldOfView();

    void RestoreFovToPreVRModeValue();

    void SetNear(float n);
    float GetNear() const;
    void SetFar(float f);
    float GetFar() const;

    // Projection's near and far plane (can differ from GetNear/Far() for custom projection matrix)
    float GetProjectionNear() const;
    float GetProjectionFar() const;

    void SetAllowHDR(bool enable) { m_State.m_AllowHDR = enable; SetDirty(); }
    bool GetAllowHDR() const { return m_State.m_AllowHDR; }
    bool GetUsingHDR() const { return m_State.m_UsingHDR; }  // Cached when setting up the render
    // A recompute is needed if Camera.hdr is called from script before rendering (case 483603)
    bool CalculateUsingHDR() const;

    void SetAllowMSAA(bool msaa) { m_State.m_AllowMSAA = msaa; SetDirty(); }
    bool GetAllowMSAA() const { return m_State.m_AllowMSAA; }

    void SetAllowDynamicResolution(bool dynamicResolution) { m_State.m_AllowDynamicResolution = dynamicResolution; SetDirty(); }
    bool GetAllowDynamicResolution() const { return m_State.m_AllowDynamicResolution && GetGraphicsCaps().supportsDynamicResolution; }

    void SetForceIntoRT(bool forceIntoRT) { m_State.m_ForceIntoRT = forceIntoRT; SetDirty(); }
    bool GetForceIntoRT() const { return m_State.m_ForceIntoRT; }

    void SetRenderingPath(int rp) { m_State.m_RenderingPath = rp; SetDirty(); }
    RenderingPath GetRenderingPath() const { return static_cast<RenderingPath>(m_State.m_RenderingPath); }

    void SetOrthographicSize(float f);
    float GetOrthographicSize() const { return m_State.m_OrthographicSize; }

    bool GetOrthographic() const { return m_State.m_Orthographic; }
    void SetOrthographic(bool v);

    void GetTemporarySettings(CameraTemporarySettings& settings) const;
    void SetTemporarySettings(const CameraTemporarySettings& settings);

    float GetAspect() const;
    void SetAspect(float aspect);
    void ResetAspect();


    bool IsValidToRender() const;

    void SetNormalizedViewportRect(const Rectf& normalizedRect);
    Rectf GetNormalizedViewportRect(RenderTexture* target = NULL, bool isRenderingInStereo = false) const;

    // The screen view port rect of the camera.
    // If the cameras normalized viewport rect is set to be the fullscreen, then this will always go from
    // 0, 0 to width, height.
    Rectf GetScreenViewportRect(bool adjustForDynamicScale = true) const { return GetCameraRect(true, adjustForDynamicScale); }
    RectInt GetScreenViewportRectInt(bool adjustForDynamicScale = true) const;
    // Similar to GetScreenViewportRect, except this can have non-zero origin even for fullscreen cameras.
    // This only ever happens in editor's game view when using forced aspect ratio or size.
    Rectf GetPhysicalViewportRect(bool adjustForDynamicScale = true) const { return GetCameraRect(false, adjustForDynamicScale); }

    void SetScreenViewportRect(const Rectf& pixelRect);

    // Get the final in-rendertarget render rectangle.
    // This takes into account any render texture setup we may have.
    Rectf GetRenderRectangle() const;


    /// The Camera render order is determined by sorting all cameras by depth.
    /// Small depth camera are rendered first, big depth cameras last.
    float GetDepth() const { return m_State.m_Depth; }
    void SetDepth(float depth);

    /// Set the background color of the camera.
    void SetBackgroundColor(const ColorRGBAf& color);
    ColorRGBAf GetBackgroundColor() const { return m_State.m_BackGroundColor; }

    // The clearing mode used for the camera.
    enum ClearMode
    {
        kSkybox = 1,
        kSolidColor = 2,
        kDepthOnly = 3,
        kDontClear = 4
            // Watch out for check consistency when changing this!
    };

    void SetClearFlags(int flags);
    ClearMode GetClearFlags() const { return static_cast<ClearMode>(m_State.m_ClearFlags); }

    void SetCullingMask(UInt32 cullingMask);
    UInt32 GetCullingMask() const { return m_State.m_CullingMask.m_Bits; }

    void SetEventMask(UInt32 cullingMask);
    UInt32 GetEventMask() const { return m_State.m_EventMask.m_Bits; }

    Vector3f GetPosition() const;

    void SetUseOcclusionCulling(bool occlusionCull) { m_State.m_OcclusionCulling = occlusionCull; }
    bool GetUseOcclusionCulling() const { return m_State.m_OcclusionCulling; }

    /// A screen space point is defined in pixels.
    /// The left-bottom of the screen is (0,0). The right-top is (screenWidth,screenHeight)
    /// The z position is between 0...1. 0 is on the near plane. 1 is on the far plane

    /// A viewport space point is normalized and relative to the camera
    /// The left-bottom of the camera is (0,0). The top-right is (1,1)
    /// The z position is between 0...1. 0 is on the near plane. 1 is on the far plane

    /// Projects a World space point into screen space.
    /// on return: canProject is true if the point could be projected to the screen (The point is inside the frustum)
    Vector3f WorldToScreenPoint(const Vector3f& worldSpacePoint, bool* canProject = NULL) const;
    /// Unprojects a screen space point into world space
    Vector3f ScreenToWorldPoint(const Vector3f& screenSpacePoint) const;

    /// Projects a world space point into viewport space
    Vector3f WorldToViewportPoint(const Vector3f &worldSpace) const;
    /// Unprojects a view port space into world space
    Vector3f ViewportToWorldPoint(const Vector3f &viewPort) const;

    /// Unprojects a view port space into camera space
    Vector3f ViewportToCameraPoint(const Vector3f &viewPort) const;

    // Converts a screen point into a world space ray
    Ray ScreenPointToRay(const Vector2f& screenPos) const;
    // Converts a viewport point into a world space ray
    Ray ViewportPointToRay(const Vector2f& viewportPos) const;

    // Converts a point between screen space and viewport space
    Vector3f ScreenToViewportPoint(const Vector3f& screenPos) const;
    Vector3f ViewportToScreenPoint(const Vector3f& viewPortPos) const;

    void CalculateViewportRayVectors(const Rectf& viewport, float z, MonoOrStereoscopicEye eye, Vector3f outRays[4]) const;

    // Calculates the distance between the left and right
    // edges of the frustum pyramid at the far plane
    float CalculateFarPlaneWorldSpaceLength() const;

    // Calculates the distance between the left and right
    // edges of the frustum pyramid at the near plane
    float CalculateNearPlaneWorldSpaceLength() const;

    void WindowSizeHasChanged();

    void AddImageFilter(const ImageFilter& filter);
    void RemoveImageFilter(const ImageFilter& filter);

    // Returns TRUE if there are any image effects, otherwise FALSE.
    // NOTE: This doesn't check for any that might be included in command buffers.
    bool HasAnyImageFilters() const;

    const Vector3f& GetVelocity() const { return m_State.m_Velocity; }

    const Matrix4x4f& GetWorldToCameraMatrix() const;
    void GetImplicitWorldToCameraMatrix(Matrix4x4f& outMatrix) const;
    Matrix4x4f GetCameraToWorldMatrix() const;

    const Matrix4x4f& GetProjectionMatrix() const;
    const Matrix4x4f& GetCullingMatrix() const;
    void GetSkyboxProjectionMatrix(float nearClip, Matrix4x4f& outMatrix) const;
    void GetImplicitProjectionMatrix(float overrideNearPlane, Matrix4x4f& outMatrix) const;
    void GetImplicitProjectionMatrix(float overrideNearPlane, float overrideFarPlane, float fov, float aspect, Matrix4x4f& outMatrix) const;

    void GetClipToWorldMatrix(Matrix4x4f& outMatrix) const;
    const Matrix4x4f& GetWorldToClipMatrix() const;

    void SetWorldToCameraMatrix(const Matrix4x4f& matrix);
    void SetProjectionMatrix(const Matrix4x4f& matrix);
    void SetCullingMatrix(const Matrix4x4f& matrix);

    // Set the last frame view projection matrix for motion vectors
    const Matrix4x4f& GetPreviousViewProjectionMatrix() const { return m_PrevFrameViewProj; }
    const Matrix4x4f& GetStereoPreviousViewProjectionMatrix(const StereoscopicEye eye) const { return m_StereoPrevFrameViewProj[eye]; }
    void InitializePreviousViewProjectionMatrix();
    void UpdatePreviousViewProjectionMatrix();
    void StashLastUsedViewProjectionMatrix(const Matrix4x4f& mat);
    void StashStereoLastUsedViewProjectionMatrices(const StereoscopicEye eye, const Matrix4x4f& mat);

    // Return the non jittered projection matrix if it has been
    // set by the user.
    // This is needed for motion vectors if the camera is jittered
    const Matrix4x4f& GetNonJitteredProjectionMatrix() const;
    void SetNonJitteredProjectionMatrix(const Matrix4x4f& projMatrix);
    const Matrix4x4f& GetStereoNonJitteredProjectionMatrix(const StereoscopicEye eye) const;
    void CopyStereoDeviceProjectionMatrixToNonJittered(const StereoscopicEye eye);

    bool GetUseJitteredProjectionMatrixForTransparent() const { return m_UseJitteredProjMatrixForTransparent; }
    void SetUseJitteredProjectionMatrixForTransparent(bool useJitteredMatrixForTransparent) { m_UseJitteredProjMatrixForTransparent = useJitteredMatrixForTransparent; }

    void ResetWorldToCameraMatrix();
    void ResetProjectionMatrix();
    void ResetCullingMatrix() { m_State.m_ImplicitCullingMatrix = true; }
    bool IsImplicitWorldToCameraMatrix() const { return m_State.m_ImplicitWorldToCameraMatrix; }
    bool IsImplicitProjectionMatrix() const { return m_State.m_ImplicitProjectionMatrix; }

    const Matrix4x4f& GetStereoProjectionMatrix(StereoscopicEye eye) const;
    void SetStereoProjectionMatrix(StereoscopicEye eye, const Matrix4x4f& m);

    const Matrix4x4f& GetStereoViewMatrix(StereoscopicEye eye) const;
    void SetStereoViewMatrix(StereoscopicEye eye, const Matrix4x4f& m);
    void SetStereoViewMatricesAndMode(const Matrix4x4f& leftEyeViewMatrix, const Matrix4x4f& rightEyeViewMatrix, StereoViewMatrixMode mode);

    void GetStereoSkyboxProjectionMatrix(StereoscopicEye eye, float nearClip, Matrix4x4f& outMatrix) const;
    const Matrix4x4f& GetStereoWorldToClipMatrix(StereoscopicEye eye) const;

    void ResetStereoProjectionMatrices();
    void ResetStereoViewMatrices();
    bool IsImplicitStereoProjectionMatrix() const { return m_State.m_ImplicitStereoProjectionMatrices; }
    bool IsImplicitStereoViewMatrix() const { return m_State.m_StereoViewMatrixMode == kStereoViewMatrixModeImplicit; }

    void SetReplacementShader(Shader* shader, const core::string& replacementTag);
    void ResetReplacementShader();
    Shader *GetReplacementShader() const;
    core::string GetReplacementShaderTag() const {return m_State.m_ReplacementTag; }

    // Get/Set the texture to render into.
    RenderTexture *GetTargetTexture() const;
    void SetTargetTexture(RenderTexture *tex);

    void SetTargetBuffers(int colorCount, RenderSurfaceHandle* color, RenderSurfaceHandle depth, RenderTexture** originatedFrom);
    void SetTargetBuffersScript(int colorCount, const ScriptingRenderBuffer* color, ScriptingRenderBuffer* depth);

    // TODO: mrt support?
    RenderSurfaceHandle GetTargetColorBuffer(int index = 0) const { return m_State.m_TargetColorBuffer[index]; }
    RenderSurfaceHandle GetTargetDepthBuffer() const { return m_State.m_TargetDepthBuffer; }

    const float *GetLayerCullDistances() const { return m_State.m_LayerCullDistances; }
    void SetLayerCullDistances(float *layerCullDistances) {memcpy(m_State.m_LayerCullDistances, layerCullDistances, sizeof(float) * kNumLayers); }

    bool GetLayerCullSpherical() const { return m_State.m_LayerCullSpherical; }
    void SetLayerCullSpherical(bool enable) { m_State.m_LayerCullSpherical = enable; }

    OpaqueSortMode GetOpaqueSortMode() const { return m_State.m_OpaqueSortMode; }
    void SetOpaqueSortMode(OpaqueSortMode m) { m_State.m_OpaqueSortMode = m; }
    bool GetShouldUseOpaqueDepthSorting() const
    {
        return
            (m_State.m_OpaqueSortMode == kOpaqueSortDefault && !GetGraphicsCaps().hasHiddenSurfaceRemovalGPU) || // default: do distance sorting on non-TBDR GPUs
            (m_State.m_OpaqueSortMode == kOpaqueSortFrontToBack);
    }

    bool IsImplicitTransparencySortSettings() const { return m_State.m_ImplicitTransparencySortSettings; }
    void ResetTransparencySortSettings() { m_State.m_ImplicitTransparencySortSettings = true; }
    TransparencySortMode GetTransparencySortMode() const { return m_State.m_TransparencySortMode; }
    void SetTransparencySortMode(TransparencySortMode m) { m_State.m_TransparencySortMode = m; m_State.m_ImplicitTransparencySortSettings = false; }

    Vector3f GetTransparencySortAxis() const { return m_State.m_TransparencySortAxis; }
    void SetTransparencySortAxis(const Vector3f& axis) { m_State.m_TransparencySortAxis = NormalizeSafe(axis, Vector3f(0, 0, 1.0f)); m_State.m_ImplicitTransparencySortSettings = false; }

    // Get the current target. This can be different than the textureTarget if some image filters require
    // A temporary buffer to render into.
    RenderTexture *GetCurrentTargetTexture() const { return m_CurrentTargetTexture; }
    void SetCurrentTargetTexture(RenderTexture* rt) { m_CurrentTargetTexture = rt; }
    RenderTexture *GetCurrentTargetTextureFromRenderBuffer() const { return m_State.m_TargetBuffersOriginatedFrom[0]; }


    static void InitializeClass();
    static void CleanupClass();

    void CopyFrom(const Camera& other);

    void CalculateFarCullDistances(float* farCullDistances, float baseFarDistance) const;

    enum DepthTextureModes
    {
        kDepthTexDepthBit = (1 << 0),
        kDepthTexDepthNormalsBit = (1 << 1),
        kMotionVectorBit = (1 << 2)
    };
    UInt32 GetDepthTextureMode() const { return m_State.m_DepthTextureMode; }
    void SetDepthTextureMode(UInt32 m);

    bool GetClearStencilAfterLightingPass() const { return m_State.m_ClearStencilAfterLightingPass; }
    void SetClearStencilAfterLightingPass(bool clear) { m_State.m_ClearStencilAfterLightingPass = clear; }

    bool GetStereoEnabled() const;
    bool GetStereoSingleCullEnabled() const;
    bool AreVRStereoViewMatricesWithinSingleCullTolerance() const;
    SinglePassStereo GetSinglePassStereo() const;

    float GetStereoSeparation() const;
    float GetVRDeviceStereoSeparation() const;
    void SetStereoSeparation(float separation) { m_State.m_StereoSeparation = separation; }

    float GetStereoConvergence() const { return m_State.m_StereoConvergence; }
    void SetStereoConvergence(float convergence) { m_State.m_StereoConvergence = convergence; }

    RenderingPath CalculateRenderingPath() const;
    bool CalculateCanDoShadows() const;
    float CalculateShadowDistance() const;

    // Get the resolved skybox material we want to render with.
    Material *GetSkyboxMaterial() const;

    // Implementations in EditorCameraDrawing.cpp, UI is in SceneRenderModeWindow.cs
    #if UNITY_EDITOR

    // Match DrawCameraMode order in C# code!
    enum EditorDrawingMode
    {
        kEditorDrawTextured,
        kEditorDrawWire,
        kEditorDrawTexturedWire,
        kEditorDrawShadowCascades,
        kEditorDrawRenderPaths,
        kEditorDrawAlphaChannel,
        kEditorDrawOverdraw,
        kEditorDrawMipmaps,
        kEditorDrawDeferredDiffuse,
        kEditorDrawDeferredSpecular,
        kEditorDrawDeferredSmoothness,
        kEditorDrawDeferredNormal,
        kEditorDrawCharting,
        kEditorDrawSystems,
        kEditorDrawRealtimeAlbedo,
        kEditorDrawRealtimeEmissive,
        kEditorDrawRealtimeIndirect,
        kEditorDrawRealtimeDirectionality,
        kEditorDrawBakedLightmap,
        kEditorDrawClustering,
        kEditorDrawLitClustering,
        kEditorValidateAlbedo,
        kEditorValidateMetalSpecular,
        kEditorDrawShadowMasks,
        kEditorDrawLightOverlap,
        kEditorDrawBakedAlbedo,
        kEditorDrawBakedEmissive,
        kEditorDrawBakedDirectionality,
        kEditorDrawBakedTexelValidity,
        kEditorDrawBakedIndices,
        kEditorDrawBakedCharting,
        kEditorSpriteMask,
        kEditorDrawModeCount,
    };


    bool IsDrawingModeEnabled(EditorDrawingMode mode) const;
    void ClearEditorCamera();  // clears
    void RenderEditorCamera(EditorDrawingMode mode, const DrawGridParameters* gridParam);  // renders camera content (does not clear)
    void DoRenderGridAndPostLayers(const DrawGridParameters* gridParam, CullResults& results, RenderFlag renderFlags);
    void FinishRenderingEditorCamera(RenderFlag renderFlags = kRenderFlagNone, bool drawGizmos = true);
    EditorDrawingMode GetLastEditorDrawingMode() const;
    void SetOnlyRenderIntermediateObjects() { m_OnlyRenderIntermediateObjects = true; }
    static bool ShouldShowChannelErrors(const Camera* ptr);
    void RenderEditorCameraFade(float fade);
    void SetAnimateMaterials(bool animate);
    bool GetAnimateMaterials() const { return m_State.m_AnimateMaterials; }
    void SetAnimateMaterialsTime(float time);
    void EmitGUIGeometryToCamera(Camera* destCam);

    bool IsFiltered(GameObject& gameObject) const;
    void SetFilterMode(int filterMode) { m_FilterMode = filterMode; }
    int  GetFilterMode() const         { return m_FilterMode; }

    static void DestroyEditorCamera();
    bool IsSceneCamera() const { return m_IsSceneCamera; }
    #endif // #if UNITY_EDITOR

    bool GetRenderImmediateObjects() const;

    // Get Screen Index ID Equivalent.
    void SetTargetDisplay(int targetDisplay);
    int GetTargetDisplay() const;
    TargetEyeMask GetStereoTargetEye() const { return m_State.m_TargetEye; }
    void SetStereoTargetEye(TargetEyeMask stereoTargetEye);

    bool IsCurrentlyRendering() const;

    CameraType GetCameraType() const { return m_State.m_CameraType; }
    void SetCameraType(CameraType t) { m_State.m_CameraType = t; }

    void SaveMatrixState(MatrixState& state) const;
    void RestoreMatrixState(const MatrixState& state);

    std::vector<core::string> GetCameraBufferWarnings() const;

    // to handle RenderTexture releasing we need two step procedure
    // 1. We can trigger RT releasing due to caps/emulation switching and/or context loss
    //    to handle that we will kill RT's render surfaces (they will be automatically recreated when we render to RT again)
    // 2. We can trigger RT releasing as part of RT destruction
    // to handle both cases we go like this:
    // first we call OnRenderSurfaceDestroyed from RenderTexture::Release, and we reset Camera's target buffers if needed
    // then we call OnRenderTextureDestroyed from RenderTexture::MainThreadCleanup and we reset Camera's target texture if needed
    // TODO: with current setup case of Camera rendering to RenderBuffers (Camera.SetTargetBuffers) is not properly handled
    //       we will not crash, but after releasing all RenderTextures Camera will fall back to "render to backbuffer"
    static void OnRenderSurfaceDestroyed(RenderSurfaceHandle rs, RenderTexture* originRT);
    static void OnRenderTextureDestroyed(RenderTexture* rt);

    void UpdateDepthTextures(const CullResults& cullResults, const SharedRendererScene& rendererScen, bool useSinglePassStereoe);

    static void PrepareCullingParametersRendererArrays(const CoreCameraValues& coreCameraValues, CullResults& results);

    void SetActiveVRUsage() const;
    bool UsesStereoRenderTarget() const;
    bool TargetBuffersFromScripts() { return m_BuffersSetFromScripts; } // required for Deferred and MotionVector render loops

    bool IsRenderingToScalableBuffer() const;

private:

    struct RenderPlaneCallbackItem
    {
        RenderPlaneCallback cb;
        void* userData;
        RenderPlane plane;
        bool operator==(const RenderPlaneCallbackItem& o) const
        {
            return cb == o.cb && userData == o.userData && plane == o.plane;
        }
    };
    typedef dynamic_array<RenderPlaneCallbackItem> RenderPlaneCallbacks;

    StereoscopicEye GetStereoEyeBegin() const;
    StereoscopicEye GetStereoEyeEnd() const;

    void RenderLensFlares(const CullResults* cullResults, ShaderPassContext& passContext, const Matrix4x4f& worldToCamera);
    void DoRenderPostLayers(const CullResults* cullResults, ShaderPassContext& passContext, RenderFlag renderFlags, RenderManager::PostPerCameraFunctor postPerCameraCall = NULL);            // Render any post-layers (before image effects)
    void DoRenderGUILayer(ShaderPassContext& passContext, RenderFlag renderFlags);
    void ResolveLastTargetToCurrentTarget() const;

    // Use DoRender if you're going to do one pass over the objects that the camera is supposed to render in a frame (this should be the default)
    void DoRender(CullResults& cullResults, const SharedRendererScene& sharedRendererScene, RenderFlag renderFlags, PerformRenderFunction* customRender);
    // Use the following routines directly if you want to call DoRender twice in a row without going through frame cleanup first.
    // If you think you need to do:
    // DoRender(...);
    // DoRender(...);
    // then use these routines instead.
    // If for example you want to render the same list of objects in two passes with special overlay drawings you would use this set of functions.
    // Check EditorCameraDrawing.cpp for reference usage.

    void PreMultiCustomRender(CullResults& cullResults, RenderFlag renderFlags, bool bSkipMarkers = false);
    void MultiCustomRender(CullResults& cullResults, PerformRenderFunction* const* renderFunctionObjects, size_t count, bool bSkipMarkers = false);
    void PostMultiCustomRender(RenderFlag renderFlags, bool bSkipMarkers = false);

    void BindSinglePassStereoMatricesAndViewport(GfxDevice& device, SinglePassStereo singlePassStereo, bool undoRenderViewportScale = false) const;
    void BeginSinglePassStereo(GfxDevice& device, ShaderPassContext& passContext, RenderFlag renderFlags, bool undoRenderViewportScale = false) const;
    void EndSinglePassStereo(GfxDevice& device, ShaderPassContext& passContext, RenderFlag renderFlags) const;

    // Behaviour stuff
    virtual void AddToManager();
    virtual void RemoveFromManager();

    void SetTargetTextureBuffers(RenderTexture* tex, int colorCount, RenderSurfaceHandle* color, RenderSurfaceHandle depth, RenderTexture** rbOrigin);
    bool ApplyRenderTexture();
    void SetRenderTargetAndViewport();

    static void CalculateMatrixShaderProps(const Matrix4x4f& inView, Matrix4x4f& outWorldToCamera, Matrix4x4f& outCameraToWorld);
    void SetCameraShaderProps(ShaderPassContext& passContext, const CameraRenderingParams& params);

    static void PrepareCullingParameters(const CameraCullingParameters& parameters, RenderingPath renderPath, CullResults& results);

    static void PrepareLODCullingData(CullResults& results, const CoreCameraValues& coreCameraValues);

    void UpdateDepthTextures(const CullResults& cullResults, const SharedRendererScene& rendererScene, RenderFlag renderFlags);
    void RenderDepthTexture(const CullResults& cullResults, const SharedRendererScene& rendererScene, ShaderPassContext& passContext, RenderFlag renderFlags);
    void RenderDepthNormalsTexture(const CullResults& cullResults, const SharedRendererScene& rendererScene, ShaderPassContext& passContext, RenderFlag renderFlags);

    void CleanupAfterRendering(const CullResults* cullResults);
    void CleanupDepthTextures();

    Rectf GetCameraRect(bool zeroOrigin, bool adjustForDynamicScale = true) const;

    void InvokeRenderPlaneCallbacks(RenderPlane plane);

    bool ShouldUseVRFieldOfView() const;

#if UNITY_EDITOR
    class EditorEyeRenderFunction;

    void RenderEditorCamera(EditorDrawingMode drawMode, const DrawGridParameters* gridParam, CullResults* cullData, RenderFlag renderFlags, int clearFlags);

    void SetupCameraStackRenderingState();
    void ReleaseCameraStackRenderingState();

    bool ExecuteCustomRenderPipeline(EditorDrawingMode drawMode, const DrawGridParameters* gridParam, RenderFlag renderFlags);

    void DoRenderSelected(const SceneCullingParameters& culling, bool modeAllowsHightlight, RenderFlag renderFlags = kRenderFlagNone) const;
#endif


private:
    // When generating tooltips/ranges/enums for inspector with Doxygen, we want to attribute all these to Camera class and not to CopiableState.
    // For this the struct declaration is excluded with the cond command (unless HIDDEN_SYMBOLS is defined in ENABLED_SECTIONS).
    /// @cond HIDDEN_SYMBOLS
    //
    // Camera state that is copied in Camera::CopyFrom
    //
    // Rule of thumb: only values that can be set from script (either directly, or as a side-effect) should be part of camera state copy.
    //
    struct CopiableState
    {
        CopiableState();
        void Reset();
        /// @endcond

        mutable Matrix4x4f  m_WorldToCameraMatrix;
        mutable Matrix4x4f  m_ProjectionMatrix;
        mutable Matrix4x4f  m_WorldToClipMatrix;
        mutable Matrix4x4f  m_SkyboxProjectionMatrix;
        mutable float       m_FieldOfView;///< Field of view of the camera range { 0.00001, 179 }
        mutable float       m_FieldOfViewBeforeEnablingVRMode;

        mutable Matrix4x4f  m_StereoViewMatrices[kStereoscopicEyeCount];
        mutable Matrix4x4f  m_StereoProjectionMatrices[kStereoscopicEyeCount];
        mutable Matrix4x4f  m_StereoWorldToClipMatrices[kStereoscopicEyeCount];
        mutable Matrix4x4f  m_CullingMatrix;

        PPtr<RenderTexture> m_TargetTexture; ///< The texture to render this camera into

        RenderSurfaceHandle m_TargetColorBuffer[kMaxSupportedRenderTargets];
        int                 m_TargetColorBufferCount;
        RenderSurfaceHandle m_TargetDepthBuffer;
        // we need to set active RenderTexture's for GfxDevice. While this is very unfortunate
        // some code paths use "active RT" to determine what to do
        RenderTexture*      m_TargetBuffersOriginatedFrom[kMaxSupportedRenderTargets];

        int                 m_TargetDisplay;        ///< Target Display Index. Can be between 1 to 8. 0 is default display {0, 8}
        TargetEyeMask       m_TargetEye;
        PPtr<Shader>        m_ReplacementShader;
        core::string            m_ReplacementTag;

        unsigned int        m_ClearFlags;///< enum { Skybox = 1, Solid Color = 2, Depth only = 3, Don't Clear = 4 }
        ColorRGBAf          m_BackGroundColor;///< The color to which camera clears the screen
        Rectf               m_NormalizedViewPortRect;

        BitField            m_CullingMask;///< Which layers the camera renders
        BitField            m_EventMask;///< Which layers receive events

        float               m_Depth;///< A camera with a larger depth is drawn on top of a camera with a smaller depth range {-100, 100}
        Vector3f            m_Velocity;
        Vector3f            m_LastPosition;

        float               m_OrthographicSize;
        float               m_NearClip; ///< Near clipping plane
        float               m_FarClip;  ///< Far clipping plane
        int                 m_RenderingPath;///< enum { Use Graphics Settings = -1, Legacy Vertex Lit=0, Forward=1, Legacy Deferred (light prepass)=2, Deferred=3 } Rendering path to use.

        float               m_LayerCullDistances[kNumLayers];
        float               m_Aspect;
        OpaqueSortMode      m_OpaqueSortMode;
        TransparencySortMode m_TransparencySortMode;
        Vector3f            m_TransparencySortAxis;
        bool                m_ImplicitTransparencySortSettings;

        UInt32              m_DepthTextureMode;

        mutable bool        m_DirtyProjectionMatrix;
        mutable bool        m_DirtySkyboxProjectionMatrix;
        bool                m_ImplicitWorldToCameraMatrix;
        bool                m_ImplicitProjectionMatrix;
        bool                m_ImplicitSkyboxProjectionMatrix;
        StereoViewMatrixMode m_StereoViewMatrixMode;
        bool                m_ImplicitStereoProjectionMatrices;
        bool                m_ImplicitCullingMatrix;
        bool                m_ImplicitAspect;
        bool                m_Orthographic;///< Is camera orthographic?
        bool                m_OcclusionCulling;
        bool                m_LayerCullSpherical;
        bool                m_AllowHDR;
        bool                m_UsingHDR;
        bool                m_AllowMSAA;
        bool                m_AllowDynamicResolution;
        bool                m_ForceIntoRT;
        bool                m_ClearStencilAfterLightingPass;
        float               m_StereoSeparation;
        float               m_StereoConvergence;
        int                 m_StereoFrameCounter;
        CameraType          m_CameraType;
    #if UNITY_EDITOR
        bool                m_AnimateMaterials;
        float               m_AnimateMaterialsTime;
    #endif

        UnityScene          *m_Scene;

        // See DOXYGEN comment above
        /// @cond HIDDEN_SYMBOLS
    };
    /// @endcond

    CopiableState       m_State;

    // Transient state: not copied by CopyFrom!
    bool                    m_IsRendering;
    bool                    m_IsRenderingStereo;
    bool                    m_IsStandaloneCustomRendering;
    bool                    m_IsCulling;
    bool                    m_IsNonJitteredProjMatrixSet;
    bool                    m_IsStereoNonJitteredProjMatrixCopied[kStereoscopicEyeCount];
    bool                    m_UseJitteredProjMatrixForTransparent;
    bool                    m_BuffersSetFromScripts;    // when true we've set the cameras m_TargetColorBuffer and m_TargetDepthBuffer from scripts so favour those values over the m_CurrentTargetTexture
    RenderLoop*             m_RenderLoop;
    ShadowMapCache*         m_ShadowCache;
    RenderEventsContext     m_RenderEvents;
    RenderTexture*          m_CurrentTargetTexture; // The texture we're rendering into _right now_
    RenderTexture*          m_DepthTexture;
    RenderTexture*          m_DepthNormalsTexture;
    RenderPlaneCallbacks    m_RenderPlaneCallbacks;
    Matrix4x4f              m_PrevFrameViewProj;
    Matrix4x4f              m_LastUsedViewProj;
    Matrix4x4f              m_StereoPrevFrameViewProj[kStereoscopicEyeCount];
    Matrix4x4f              m_StereoLastUsedViewProj[kStereoscopicEyeCount];
    Matrix4x4f              m_NonJitteredProjMatrix;
    Matrix4x4f              m_StereoNonJitteredProjMatrix[kStereoscopicEyeCount];

    bool                    m_VRIgnoreImplicitCameraUpdate;

    MatrixState             m_PrevMatrixStateForStereoSRP;
    Rectf                   m_PrevNormalizedViewportRectForStereoSRP;
    RenderFlag              m_CurrentRenderFlagsForStereoSRP;

    #if UNITY_EDITOR
    CullResults*    m_EditorCullResults;
    int             m_FilterMode;
    bool            m_OnlyRenderIntermediateObjects;
    bool            m_IsSceneCamera;
    CameraStackRenderingState* m_StackState;
    EditorDrawingMode m_LastDrawingMode;
    #endif
};

BIND_MANAGED_TYPE_NAME(Camera, UnityEngine_Camera);

ENUM_FLAGS(Camera::RenderFlag);

void ClearWithSkybox(bool clearDepth, Camera const* camera);

Rectf GetCameraOrWindowRect(const Camera* camera);

RenderTextureFormat GetRenderTextureColorFormat(bool wantsHDR, bool forDeferred, bool needsWideAlpha = true);
