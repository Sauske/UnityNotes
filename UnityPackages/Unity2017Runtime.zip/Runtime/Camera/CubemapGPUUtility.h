#pragma once

class RenderTexture;
class Texture;

// GPU cubemap convolution.
// - Timeslicing
//   Convolution can be more than 10ms on the GPU thus it is built to be
//   timeslicable via incremental, faceMask, first, last, remap parameters
int CubemapGPUConvolution(RenderTexture* renderTexture, RenderTexture* scratch, bool incremental, const int faceMask, unsigned first, unsigned last, bool remap);
bool CubemapGPUBlend(Texture* lhs, Texture* rhs, float blend, RenderTexture* renderTexture);
