#pragma once

// Currently our cameras are set up independently from each other, but in many
// cases what people want to use them for is a "camera stack" (e.g. background camera,
// renders distant objects; then foreground camera, renders most of scene, then weapon
// camera; and then image postprocessing on the *whole stack*). Getting postprocessing
// to work reliably in various conditions (HDR, deferred, AA, ...) without knowledge of
// "this is a stack of cameras" is tricky. So instead we do try to figure out
// "what are the stacks?" from the cameras that we have, and work on them.
//
// Camera Stack: sequence of cameras, that are rendering into the same render target(s),
// with the same viewport.

#include "Camera.h"
#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Graphics/StereoRenderTexture.h"
#include <vector>

class RenderTexture;

struct CameraTargetsAndRect
{
    CameraTargetsAndRect() : m_TargetTexture(NULL), m_Display(0), m_ColorCount(0), m_Stereo(false), m_SinglePassStereo(kSinglePassStereoNone) {}

    bool operator==(const CameraTargetsAndRect& o) const
    {
        if (m_Display != o.m_Display) return false;
        if (m_Stereo != o.m_Stereo) return false;
        if (m_Viewport != o.m_Viewport) return false;
        if (m_TargetTexture != o.m_TargetTexture) return false;
        for (int i = 0; i < kMaxSupportedRenderTargets; ++i)
        {
            if (m_ColorBuffer[i] != o.m_ColorBuffer[i])
                return false;
        }
        if (m_DepthBuffer != o.m_DepthBuffer) return false;
        return true;
    }

    bool operator!=(const CameraTargetsAndRect& o) const
    {
        return !(*this == o);
    }

    Rectf               m_Viewport;
    RenderTexture*      m_TargetTexture;
    RenderSurfaceHandle m_ColorBuffer[kMaxSupportedRenderTargets];
    RenderSurfaceHandle m_DepthBuffer;
    int                 m_Display;
    int                 m_ColorCount;
    bool                m_Stereo;
    SinglePassStereo    m_SinglePassStereo;
};


// Stack of cameras, rendering into the same target(s) and viewport.
struct CameraStack
{
    CameraStack();

    dynamic_array<PPtr<Camera> > m_Cameras;
    CameraTargetsAndRect    m_CameraTarget;         // Camera target for this stack
    bool    m_ForceUseRT;   // Force rendering into RT?
    bool    m_HDR;      // Does any camera in the whole stack want to use HDR rendering?
    bool    m_HasDeferred;          // Does any camera in the whole stack need deferred?
    bool    m_MSAA;                 // Does any camera have MSAA
    bool    m_DynamicResolution;    //Does any camera in the stack want Dynamic Resolution
    bool    m_HasCommandBuffers;
};


typedef std::list<PPtr<Camera> > CameraList;
typedef std::vector<CameraStack> CameraStackArray;


// Find camera stacks from a list of cameras.
// Cameras are expected to be ordered in increasing "depth" setting.
void FindCameraStacks(const CameraList& cameraList, CameraStackArray& outStacks);

// Returns if current platform supports rendering to MSAA backbuffer
bool PlatformSupportsMSAABB();

// State kept around while rendering a single stack of cameras.
// Things like whether we're in HDR rendering right now; or what kind of temporary
// built-in buffers we're using etc.
class CameraStackRenderingState
{
public:
    enum TargetType
    {
        kGenerated,
        kUserDefined,       // rendering to user defined RT
        kToScreen,          // currently rendering into final target (after all image fx)
        kStereo,                // Render to VR buffer
        kStereoDirectToEyeTexture ,         // render directly to eye textures.
        kStereoResolveToEyeTexture, // render to temp and resolve to eye texture.
    };

    CameraStackRenderingState();
    void SetCurrentCamera(Camera* cam);
    Camera* GetCurrentCamera() const;
    void BeginRenderingStack(const CameraStack& stack, const bool firstStack);
    void BeginRenderingOneCamera(Camera& cam);
    void ReleaseResources();

    // currently we still allow to update camera's targetTexture/target-buffers from script while it is rendering.
    // i agree this is not quite reasonable thing to do but this is possible right now so lets keep the possibility for some time
    void UpdateCameraTargetTexture(RenderTexture* rt);

    RenderTexture* GetOrCreateBuiltinRT(BuiltinRenderTextureType type, int width, int height, DepthBufferFormat depthFormat, RenderTextureFormat colorFormat, UInt32 flags, RenderTextureReadWrite colorSpace, VRTextureUsage vrUsage, int antiAliasing);
    RenderTexture* GetBuiltinRT(BuiltinRenderTextureType type);
    RenderTexture* GetTargetTexture();
    TargetType GetTarget() const { return m_TargetType; }
    RenderTexture* GetSrcTextureForImageFilters() const;
    RenderTexture* GetDstTextureForImageFilters() const;
    bool IsRenderingLastCamera() const;
    bool IsRenderingFirstCamera() const;
    bool ShouldResolveLastTarget() const;
    RenderTexture* GetAfterFinalCameraTarget() const;
    void SetCurrentlyRenderingEye(StereoscopicEye eye);
    void EndStereoRendering();
    const Camera* GetFirstCamera() const { return m_FirstCamera; }

private:
    void SetupLastEyeCameras(const CameraStack & stack);
    RenderTexture* GetImageEffectTexture(bool src) const;
    TargetType CalculateStereoCameraTargetType() const;
    TargetType CalculateCameraTargetType() const;
    RenderTexture* GetStereoImageEffectTexture(bool src) const;
    RenderTextureDesc GetCameraStackTempEyeTextureDesc();
    RenderTextureDesc GetCameraStackTempTextureDesc();
    void ValidateRenderViewportScale();
    bool IsRenderingToScalableBuffer() const;

    RenderTexture*  m_TempBuffers[kBuiltinRTCount];
    StereoRenderTexture m_TempInitialEyePair;
    TargetType      m_TargetType;

    Camera* m_CurrentCamera;
    const Camera* m_FirstCamera;
    const Camera* m_LastCamera;
    const Camera* m_LastLeftEyeCamera;
    const Camera* m_LastRightEyeCamera;
    CameraTargetsAndRect    m_CameraTarget;
    StereoscopicEye m_Eye;
    bool m_ForceUseRT;  // Force rendering into RT?
    bool m_HDR;     // Does any camera in the whole stack want to use HDR rendering?
    bool m_HasDeferred;         // Does any camera in the whole stack need deferred?
    bool m_MSAA;                    // Does any camera have MSAA
    bool m_DynamicResolution; //Does any camera in the stack want Dynamic Resolution?
    bool m_FirstStack; // is this the first camera stack we are rendering?
    bool m_HasCommandBuffers;
};


// Helper class for single-shot rendering of one camera - embeds a stack rendering state,
// starts rendering it in the constructor; ends in destructor.
class AutoScopedCameraStackRenderingState
{
public:
    AutoScopedCameraStackRenderingState(Camera& camera);
    ~AutoScopedCameraStackRenderingState();
    CameraStackRenderingState& GetStackState() { return m_StackState; }

private:
    Camera* m_PrevCamera;
    CameraStackRenderingState* m_PrevCameraStackState;
    CameraStackRenderingState m_StackState;
};
