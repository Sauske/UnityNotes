#include "UnityPrefix.h"
#include "CubemapGPUUtility.h"
#include "CameraUtil.h"
#include "RenderManager.h"

#include "Runtime/Graphics/RenderTexture.h"
#include "Runtime/Shaders/ShaderNameRegistry.h"
#include "Runtime/Shaders/Material.h"
#include "Runtime/GfxDevice/GfxDevice.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Utilities/RegisterRuntimeInitializeAndCleanup.h"
#include "MaterialStateCache.h"
#include "AllFacesMask.h"

PROFILER_INFORMATION(gReflectionProbesConvolution, "ReflectionProbes.Convolution", kProfilerRender)
PROFILER_INFORMATION(gBlendCubemap, "BlendCubemap", kProfilerRender)

namespace CubemapGPUUtility_Static
{
    static ShaderLab::FastPropertyName kSLPropMainTex = ShaderLab::Property("_MainTex");
    static ShaderLab::FastPropertyName kSLPropTexel = ShaderLab::Property("_Texel");
    static ShaderLab::FastPropertyName kSLPropLevel = ShaderLab::Property("_Level");
    static ShaderLab::FastPropertyName kSLPropScale = ShaderLab::Property("_Scale");
    static ShaderLab::FastPropertyName kSLPropRadius = ShaderLab::Property("_Radius");
    static ShaderLab::FastPropertyName kSLPropTexA = ShaderLab::Property("_TexA");
    static ShaderLab::FastPropertyName kSLPropTexB = ShaderLab::Property("_TexB");
    static ShaderLab::FastPropertyName kSLPropValue = ShaderLab::Property("_value");
} // namespace CubemapGPUUtility_Static

static Material* gBlurMaterial = NULL;
static Material* gCopyMaterial = NULL;
static Material* gBlendMaterial = NULL;

void CleanupCubemapGPUUtilityMaterials(void*)
{
    gBlurMaterial = NULL;
    gCopyMaterial = NULL;
    gBlendMaterial = NULL;
}

static RegisterRuntimeInitializeAndCleanup s_CleanupCubemapGPUUtilityMaterials(NULL, &CleanupCubemapGPUUtilityMaterials);

static void RenderFace(GfxDevice& device, MaterialStateCache& stateCache, RenderTexture* target, int lod, int face, float z)
{
    const float(*coord)[6][5][3];

    if (GetGraphicsCaps().usesOpenGLTextureCoords)
    {
        // OpenGL
        static const float gl_coord[6][5][3] =
        {
            // XPOS: { 1, -v, -u }
            { { 1.f, 1.f, 1.f }, { 1.f, 1.f, -1.f }, { 1.f, -1.f, -1.f }, { 1.f, -1.f, 1.f } },
            // XNEG: { -1, -v, u }
            { { -1.f, 1.f, -1.f }, { -1.f, 1.f, 1.f }, { -1.f, -1.f, 1.f }, { -1.f, -1.f, -1.f } },
            // YPOS: { +u, 1, +v }
            { { -1.f, 1.f, -1.f }, { 1.f, 1.f, -1.f }, { 1.f, 1.f, 1.f }, { -1.f, 1.f, 1.f } },
            // YNEG: { +u, -1, -v }
            { { -1.f, -1.f, 1.f }, { 1.f, -1.f, 1.f }, { 1.f, -1.f, -1.f }, { -1.f, -1.f, -1.f } },
            // ZPOS: { +u, -v, 1 }
            { { -1.f, 1.f, 1.f }, { 1.f, 1.f, 1.f }, { 1.f, -1.f, 1.f }, { -1.f, -1.f, 1.f } },
            // ZNEG: { -u, -v, -1 }
            { { 1.f, 1.f, -1.f }, { -1.f, 1.f, -1.f }, { -1.f, -1.f, -1.f }, { 1.f, -1.f, -1.f } }
        };
        coord = &gl_coord;
    }
    else
    {
        // DirectX
        static const float dx_coord[6][5][3] =
        {
            // XPOS: { 1, -v, +u }
            { { 1.f, 1.f, 1.f }, { 1.f, 1.f, -1.f }, { 1.f, -1.f, -1.f }, { 1.f, -1.f, 1.f } },
            // XNEG: { -1, -v, -u }
            { { -1.f, 1.f, -1.f }, { -1.f, 1.f, 1.f }, { -1.f, -1.f, 1.f }, { -1.f, -1.f, -1.f } },
            // YPOS: { +u, 1, +v }
            { { -1.f, 1.f, -1.f }, { 1.f, 1.f, -1.f }, { 1.f, 1.f, 1.f }, { -1.f, 1.f, 1.f } },
            // YNEG: { +u, -1, -v }
            { { -1.f, -1.f, 1.f }, { 1.f, -1.f, 1.f }, { 1.f, -1.f, -1.f }, { -1.f, -1.f, -1.f } },
            // ZPOS: { +u, -v, 1 }
            { { -1.f, 1.f, 1.f }, { 1.f, 1.f, 1.f }, { 1.f, -1.f, 1.f }, { -1.f, -1.f, 1.f } },
            // ZNEG: { -u, -v, -1 }
            { { 1.f, 1.f, -1.f }, { -1.f, 1.f, -1.f }, { -1.f, -1.f, -1.f }, { 1.f, -1.f, -1.f } }
        };
        coord = &dx_coord;
    }

    RenderTexture::SetActive(target, lod, (CubemapFace)face, 0, RenderTexture::kFlagNone);

    // Clear target if we're on tiled GPU, to avoid restore of previous RT contents into memory
    const GraphicsCaps& caps = GetGraphicsCaps();
    if (caps.hasTiledGPU || caps.warnRenderTargetUnresolves)
        device.Clear(kGfxClearColor, ColorRGBAf(1, 0, 0, 0), 1.0f, 0);

    ShaderChannelMask channels = stateCache.Flush();

    device.ImmediateBegin(kPrimitiveQuads, channels);

    device.ImmediateTexCoordAll((*coord)[face][0][0], (*coord)[face][0][1], (*coord)[face][0][2]);
    device.ImmediateVertex(0, 0, z);

    device.ImmediateTexCoordAll((*coord)[face][3][0], (*coord)[face][3][1], (*coord)[face][3][2]);
    device.ImmediateVertex(0, 1, z);

    device.ImmediateTexCoordAll((*coord)[face][2][0], (*coord)[face][2][1], (*coord)[face][2][2]);
    device.ImmediateVertex(1, 1, z);

    device.ImmediateTexCoordAll((*coord)[face][1][0], (*coord)[face][1][1], (*coord)[face][1][2]);
    device.ImmediateVertex(1, 0, z);

    device.ImmediateEnd();
}

static bool RenderCubemapWithMaterial(Material& material, const int faceMask, RenderTexture* targetRenderTexture)
{
    using namespace CubemapGPUUtility_Static;

    GfxDevice& device = GetGfxDevice();
    // Render all mip-levels
    int size = targetRenderTexture->GetWidth();
    int mipLevel = 0;

    #define ZSTEP   (1.f/(1 << 16))
    float z = 1.f - ZSTEP;

    // Set up ortho matrix before applying shaders
    DeviceMVPMatricesState preserveMVP;
    LoadFullScreenOrthoMatrix();
    device.SetInvertProjectionMatrix(targetRenderTexture->CalculateNeedsInvertedProjection());

    MaterialStateCache cache;
    cache.SetMaterial(&material);

    while (size > 0)
    {
        for (int face = 0; face < 6; face++)
        {
            if (faceMask & (1 << face))
            {
                cache.SetFloat(kSLPropLevel, mipLevel);
                RenderFace(device, cache, targetRenderTexture, mipLevel, face, z);
            }
        }

        if (targetRenderTexture->HasMipMap() && !targetRenderTexture->GetAutoGenerateMips())
        {
            mipLevel++;
            size >>= 1;
        }
        else
            break;
    }

    RenderTexture::SetBackbufferActive();

    return false;
}

bool CubemapGPUBlend(Texture* lhs, Texture* rhs, float blend, RenderTexture* renderTexture)
{
    using namespace CubemapGPUUtility_Static;
    PROFILER_AUTO(gBlendCubemap, NULL);

    if (gBlendMaterial == NULL)
    {
        Shader* blendShader = GetScriptMapper().FindShader("Hidden/CubeBlend");
        if (blendShader == NULL)
            return false;

        gBlendMaterial = Material::CreateMaterial(*blendShader, Object::kHideAndDontSave);
    }

    gBlendMaterial->SetTexture(kSLPropTexA, lhs);
    gBlendMaterial->SetTexture(kSLPropTexB, rhs);
    gBlendMaterial->SetFloat(kSLPropValue, clamp01(blend));

    RenderCubemapWithMaterial(*gBlendMaterial, kAllFacesMask, renderTexture);

    return true;
}

int CubemapGPUConvolution(RenderTexture* renderTexture, RenderTexture* scratch, bool incremental, const int faceMask, unsigned first, unsigned last, bool remap)
{
    using namespace CubemapGPUUtility_Static;
    PROFILER_AUTO(gReflectionProbesConvolution, NULL);

    if (scratch == NULL || renderTexture == NULL)
        return -1;

    int finished = 0;

    if (gBlurMaterial == NULL)
    {
        Shader* copyShader = GetScriptMapper().FindShader("Hidden/CubeCopy");
        Shader* blurShader = GetScriptMapper().FindShader("Hidden/CubeBlur");

        if (copyShader == NULL || blurShader == NULL)
            return -1;

        gBlurMaterial = Material::CreateMaterial(*blurShader, Object::kHideAndDontSave);
        gCopyMaterial = Material::CreateMaterial(*copyShader, Object::kHideAndDontSave);
    }


    //  Note: Because every neighbouring faces are involved during filtering,
    //  it doesn't make much sense to use a partial faceMask at this point.

    renderTexture->SetFilterMode(kTexFilterNearest);
    scratch->SetFilterMode(kTexFilterNearest);

    GfxDevice &device = GetGfxDevice();
    AutoGfxDeviceBeginEndFrame frame;
    if (!frame.GetSuccess())
    {
        AssertString("todo");
    }

    // Set up ortho matrix before applying shaders
    DeviceMVPMatricesState preserveMVP;
    LoadFullScreenOrthoMatrix();
    device.SetInvertProjectionMatrix(scratch->CalculateNeedsInvertedProjection());


    MaterialStateCache cache;


    // blur each face and ping-pong between the two textures

    #define ZSTEP   (1.f/(1 << 16))

    int size = renderTexture->GetWidth() >> 1;
    int lod = 1;
    float z = 1.f - ZSTEP;

    bool ready = false;

    float texel = 1.f / size; // should be 2.f/size, but size is already divided by two
    while (size > 0)
    {
        if (lod <= last)
        {
            if (lod < first)
            {
                if (lod == first - 1 && scratch != renderTexture && (lod & 1) && !incremental)
                {
                    for (int i = 0; i < 6; ++i)
                    {
                        if (!(faceMask & (1 << i)))
                            continue;

                        // copy corresponding face
                        cache.SetMaterial(gCopyMaterial);
                        cache.SetTexture(kSLPropMainTex, renderTexture);
                        cache.SetFloat(kSLPropLevel, lod);

                        RenderFace(device, cache, scratch, lod, i, z);
                        z -= ZSTEP;
                    }
                }
            }
            else
            {
                for (int i = 0; i < 6; ++i)
                {
                    if (!(faceMask & (1 << i)))
                        continue;

                    cache.SetMaterial(gBlurMaterial);
                    cache.SetFloat(kSLPropTexel, texel);
                    cache.SetFloat(kSLPropScale, 1.f);
                    cache.SetFloat(kSLPropRadius, 3.f);
                    // use previous lod as source
                    cache.SetFloat(kSLPropLevel, lod - 1.f);

                    if (lod & 1)
                    {
                        // auxiliary cube's lod is one less than target's lod
                        cache.SetTexture(kSLPropMainTex, renderTexture);
                        RenderFace(device, cache, scratch, lod, i, z);
                    }
                    else
                    {
                        cache.SetTexture(kSLPropMainTex, scratch);
                        RenderFace(device, cache, renderTexture, lod, i, z);
                    }
                    z -= ZSTEP;
                }
            }
            ready = (size == 1);
        }

        size >>= 1;
        texel *= 2.f;
        ++lod;
    }

    if (ready && remap)
    {
        /*
         *  copy back levels into aux
         */
        size = renderTexture->GetWidth();
        lod = 0;

        while (size > 0)
        {
            if (lod < first)
            {
                for (int i = 0; i < 6; ++i)
                {
                    if (!(faceMask & (1 << i)))
                        continue;

                    cache.SetMaterial(gCopyMaterial);
                    cache.SetTexture(kSLPropMainTex, renderTexture);
                    cache.SetFloat(kSLPropLevel, lod);

                    RenderFace(device, cache, scratch, lod, i, z);
                    z -= ZSTEP;
                }
            }
            else if (!(lod & 1))
            {
                for (int i = 0; i < 6; ++i)
                {
                    if (!(faceMask & (1 << i)))
                        continue;

                    cache.SetMaterial(gCopyMaterial);
                    cache.SetTexture(kSLPropMainTex, renderTexture);
                    cache.SetFloat(kSLPropLevel, lod);

                    RenderFace(device, cache, scratch, lod, i, z);
                    z -= ZSTEP;
                }
            }
            size >>= 1;
            lod += 1;
        }

        //float step = 1.f/(lod-1);
        const int specularSteps = 7;    // MM: using 7 instead of lod since this is what the baked probes use regardless of resolution (look for m_CubemapConvolutionSteps).
        float step = 1.0f / (float)(specularSteps > 1 ? specularSteps - 1 : 1);

        float roughness = step;
        size = renderTexture->GetWidth() >> 1;
        lod = 1;

        scratch->SetFilterMode(kTexFilterTrilinear);

        while (size > 0)
        {
            float width = pow(roughness, 1.9f) * (2. * renderTexture->GetWidth());     // MM: original power was 1.5. I changed it to make blur strengths similar to baked probes

            #define WIDTH_OF(level) ((1 << ((level) + 1)))

            int level;
            float f;
            if (size > 1)
            {
                level = 7;
                float n0;
                while ((n0 = WIDTH_OF(level)) > width)
                {
                    --level;
                }
                float n1 = WIDTH_OF(level + 1);
                f = (width - n0) / (n1 - n0);
            }
            else
            {
                level = 7;
                f = 0.f;
            }

            for (int i = 0; i < 6; ++i)
            {
                if (!(faceMask & (1 << i)))
                    continue;

                cache.SetMaterial(gCopyMaterial);
                cache.SetTexture(kSLPropMainTex, scratch);
                cache.SetFloat(kSLPropLevel, level + f);

                RenderFace(device, cache, renderTexture, lod, i, z);
                z -= ZSTEP;
            }
            roughness += step;
            size >>= 1;
            lod++;
        }

        finished = (faceMask & (1 << 5)) != 0;
    }
    else if (scratch != renderTexture)
    {
        /*
         *  copy back auxiliary levels into renderTexture
         */
        size = renderTexture->GetWidth() >> 1;
        lod = 1;

        while (size > 0)
        {
            if (lod >= first && lod <= last)
            {
                for (int i = 0; i < 6; ++i)
                {
                    if (!(faceMask & (1 << i)))
                        continue;

                    cache.SetMaterial(gCopyMaterial);
                    cache.SetFloat(kSLPropLevel, lod);
                    cache.SetTexture(kSLPropMainTex, scratch);

                    RenderFace(device, cache, renderTexture, lod, i, z);
                    z -= ZSTEP;

                    finished = (size == 1) && (faceMask & (1 << 5)) != 0;
                }
            }
            size >>= 2;
            lod += 2;
        }
    }

    RenderTexture::SetBackbufferActive();

    if (finished)
    {
        renderTexture->SetFilterMode(kTexFilterTrilinear);
    }

    return finished;
}

#if 0

// TENTATIVE for a better approximation on the GPU
int ReflectionProbes::BakeCubeMipmaps(ReflectionProbe* probe, RenderTexture* renderTexture)
{
    int finished = 0;
    Shader *copyShader = GetScriptMapper().FindShader("Hidden/CubeCopy");
    Shader *blurShader = GetScriptMapper().FindShader("Hidden/CubeBlur");
    Shader *blurShaderOdd = GetScriptMapper().FindShader("Hidden/CubeBlurOdd");

    if (copyShader && blurShader)
    {
        /*
         *  Note: Because every neighbouring faces are involved during filtering,
         *  it doesn't make much sense to use a partial faceMask at this point.
         */
        PPtr<Material> blur = Material::CreateMaterial(*blurShader, Object::kHideAndDontSave);
        PPtr<Material> blurOdd = Material::CreateMaterial(*blurShaderOdd, Object::kHideAndDontSave);
        PPtr<Material> copy = Material::CreateMaterial(*copyShader, Object::kHideAndDontSave);

        static const ShaderLab::FastPropertyName kSLPropMainTex = ShaderLab::Property("_MainTex");
        static const ShaderLab::FastPropertyName kSLPropTexel = ShaderLab::Property("_Texel");
        static const ShaderLab::FastPropertyName kSLPropLevel = ShaderLab::Property("_Level");
        static const ShaderLab::FastPropertyName kSLPropScale = ShaderLab::Property("_Scale");

        bool release = false;
        RenderTexture *scratch = NULL;

        if (scratch == NULL)
        {
            // create auxiliary cubemap with half the size of the target texture
            scratch = AcquireScratchTexture(probe, renderTexture);
            release = true;
        }
        renderTexture->SetFilterMode(kTexFilterNearest);
        scratch->SetFilterMode(kTexFilterNearest);

        DeviceMVPMatricesState preserveMVP;
        GfxDevice &device = GetGfxDevice();
        AutoGfxDeviceBeginEndFrame frame;
        if (!frame.GetSuccess())
        {
            AssertString("todo");
        }

        // blur each face and ping-pong between the two textures

        #define ZSTEP   (1.f/(1 << 16))

        int size = renderTexture->GetWidth() >> 1;
        int lod = 1;
        while (size > 0)
        {
            ++lod;
            size >>= 1;
        }
        size = renderTexture->GetWidth() >> 1;
        float z = 1.f - ZSTEP;

        float step = 1.f / (lod - 1);
        float roughness = step;

        float current = 0;
        float even = 2.f;
        float odd = 3.f;

        lod = 1;
        int src = 0;
        float texel = 1.f / size; // should be 2.f/size, but size is already divided by two

        while (size > 0)
        {
            float width = pow(roughness, 1.5f) * (2. * renderTexture->GetWidth());

            for (int i = 0; i < 6; ++i)
            {
                blur->SetFloat(kSLPropTexel, texel);
                blur->SetFloat(kSLPropScale, 1.f);
                blur->SetFloat(kSLPropLevel, lod - 1.f);

                if (src == 0)
                {
                    RenderFaceWithTex(device, blur, scratch, size, lod, i, renderTexture, z);
                }
                else
                {
                    RenderFaceWithTex(device, blur, renderTexture, size, lod, i, scratch, z);
                }
                z -= ZSTEP;
            }
            src = !src;
            current += even;
            texel *= 2.f;

            while (current + .75f * odd < width)
            {
                for (int i = 0; i < 6; ++i)
                {
                    blurOdd->SetFloat(kSLPropTexel, texel);
                    blurOdd->SetFloat(kSLPropLevel, lod);

                    if (src == 0)
                    {
                        // auxiliary cube's lod is one less than target's lod
                        RenderFaceWithTex(device, blurOdd, scratch, size, lod, i, renderTexture, z);
                    }
                    else
                    {
                        RenderFaceWithTex(device, blurOdd, renderTexture, size, lod, i, scratch, z);
                    }
                    z -= ZSTEP;
                }
                src = !src;
                current += odd;
            }

            if (src != 0)
            {
                // copy back into renderTexture
                for (int i = 0; i < 6; ++i)
                {
                    copy->SetFloat(kSLPropLevel, lod);
                    RenderFaceWithTex(device, copy, renderTexture, size, lod, i, scratch, z);
                    z -= ZSTEP;
                }
                src = !src;
            }

            even *= 2.f;
            odd *= 2.f;
            roughness += step;
            size >>= 1;
            ++lod;
        }

        blur->SetTexture(kSLPropMainTex, NULL);
        copy->SetTexture(kSLPropMainTex, NULL);
        blurOdd->SetTexture(kSLPropMainTex, NULL);
        RenderTexture::SetBackbufferActive();

        renderTexture->SetFilterMode(kTexFilterTrilinear);

        device.FinishRendering();

        if (release)
        {
            ReleaseScratchTexture(scratch);
        }
        DestroySingleObject(copy);
        DestroySingleObject(blur);
        DestroySingleObject(blurOdd);

        finished = 1;
    }
    else
    {
        finished = -1;
    }
    return finished;
}

#endif
