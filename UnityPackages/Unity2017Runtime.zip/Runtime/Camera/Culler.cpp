#include "UnityPrefix.h"
#include "Culler.h"
#include "SceneCulling.h"
#include "RendererScene.h"
#include "CullResults.h"
#include "Runtime/Graphics/LOD/LODGroupManager.h"
#include "Runtime/Graphics/QualitySettings.h"
#include "Runtime/Graphics/Renderer.h"
#include "Runtime/Graphics/RendererUpdateManager.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Interfaces/ITerrainManager.h"
#include "LightCulling.h"
#include "Runtime/Camera/Camera.h"
#include "Culling/PerObjectLightCulling.h"
#include "Runtime/Camera/LightManager.h"
#include "Runtime/Camera/Light.h"
#include "Runtime/Camera/ShadowCulling.h"
#include "Runtime/Camera/RenderLoops/BuiltinShaderParamUtility.h"
#include "Runtime/Core/Callbacks/GlobalCallbacks.h"
#include "Culling/LowLevelCullingLoops.h"
#include "Runtime/Allocator/BatchAllocator.h"

#include "Runtime/Graphics/ScriptableRenderLoop/ScriptableCulling.h"

PROFILER_INFORMATION(gSceneCulling                                      , "SceneCulling"             , kProfilerRender);
PROFILER_INFORMATION(gCullActiveLights                                  , "CullAllVisibleLights"    , kProfilerRender);
PROFILER_INFORMATION(gCullScene                                         , "CullSceneObjects"    , kProfilerRender);
PROFILER_INFORMATION(gPrepareSceneNodes                                 , "PrepareSceneNodes" , kProfilerRender);
PROFILER_INFORMATION(gPrepareSceneNodesSetup                            , "PrepareSceneNodesSetUp" , kProfilerRender);
PROFILER_INFORMATION(gPrepareSceneNodesJob                              , "PrepareSceneNodesJob" , kProfilerRender);
PROFILER_INFORMATION(gSceneNodesInitJob                                 , "SceneNodesInitJob" , kProfilerRender);
PROFILER_INFORMATION(gPrepareSceneNodesCombineJob                       , "PrepareSceneNodesCombineJob" , kProfilerRender);
PROFILER_INFORMATION(gFindDirectionalShadowCastingLights                , "FindDirectionalShadowCastingLights" , kProfilerRender);
PROFILER_INFORMATION(gFindLocalShadowCastingLights                      , "FindLocalShadowCastingLights" , kProfilerRender);
PROFILER_INFORMATION(gFindShadowCastingLights                           , "FindShadowCastingLights" , kProfilerRender);
PROFILER_INFORMATION(gCullSendEvents                                    , "CullSendEvents" , kProfilerRender);
PROFILER_INFORMATION(gAddLocalLights                                    , "AddLocalLights", kProfilerRender);

DEFINE_MESSAGE_IDENTIFIER(kOnWillRenderObject, ("OnWillRenderObject", MessageIdentifier::kEnableMessageOptimization | MessageIdentifier::kSendToScripts | MessageIdentifier::kDontSendToDisabled));


void InvokeOnWillRenderObject(const NeedsCullCallback& renderers)
{
    // Invoke OnWillRenderObject callbacks.
    // These can only ever happen on non intermediate Renderers.
    // Scene needs to know we are calling scripts (case 445226).
    GetRendererScene().SetPreventAddRemoveRenderer(true);
    for (size_t i = 0; i < renderers.size(); ++i)
    {
        Assert(renderers[i]->IsRenderer());
        Renderer* r = static_cast<Renderer*>(renderers[i]);
        r->SendMessage(kOnWillRenderObject);
    }
    GetRendererScene().SetPreventAddRemoveRenderer(false);
}

static void FindShadowCastingLights(ActiveLights& activeLights, ShadowedLights& shadowedLights, const size_t startIndex, const size_t endIndex)
{
    PROFILER_AUTO(gFindShadowCastingLights, NULL);

    for (size_t index = startIndex; index < endIndex; index++)
    {
        ActiveLight& light = activeLights.lights[index];
        if (light.isVisibleInPrepass && light.insideShadowRange && light.light->GetShadowType() != kShadowNone)
        {
            light.shadowedLightIndex = shadowedLights.size();
            ShadowedLight& shadowedLight = shadowedLights.emplace_back();
            shadowedLight.lightIndex = index;
        }
        else
            light.shadowedLightIndex = -1;
    }
}

static void FindDirectionalShadowCastingLights(ActiveLights& activeLights, ShadowedLights& shadowedLights)
{
    PROFILER_AUTO(gFindDirectionalShadowCastingLights, NULL);

    size_t index = 0;
    size_t endIndex = activeLights.numDirLights;

    FindShadowCastingLights(activeLights, shadowedLights, index, endIndex);
}

static void FindLocalShadowCastingLights(ActiveLights& activeLights, ShadowedLights& shadowedLights)
{
    PROFILER_AUTO(gFindLocalShadowCastingLights, NULL);

    size_t index =  activeLights.numDirLights;
    size_t endIndex = activeLights.numDirLights + activeLights.numSpotLights + activeLights.numPointLights;

    FindShadowCastingLights(activeLights, shadowedLights, index, endIndex);
}

static void LocalLightShadowCasterCulling(const SceneCullingParameters& cullingParameters, CullResults& results)
{
    if (cullingParameters.renderPath == kRenderPathLegacyVertexLoop)
        return;

    // Local light source shadow culling
    size_t startIndex = results.shadowedLights.size();
    FindLocalShadowCastingLights(results.activeLights, results.shadowedLights);

    size_t endIndex = results.shadowedLights.size();
    //Don't call local light shadow culling if we don't have shadow casting local lights.
    if (endIndex - startIndex == 0)
        return;

    CullLocalLightShadowCasters(startIndex, endIndex, cullingParameters.excludeLightmappedShadowCasters, results);
}

struct AddLocalLightsJobInfo
{
    LocalLightCullingParameters lightCullingParams;
    ActiveLights customLights;
    SceneCullingParameters const* params;
    SharedLightData const** localLights;
    float* visibilityFades;
    Vector4f* localLightBSpheres;
    IndexList visibleLocalLights;
    IndexList offScreenLocalLights;
    CullResults* results;
    //Gather light rect and on/offscreen info here
    Rectf* lightScreenRects;
    TargetEyeMask* lightVisibilityMasks;
    bool shadowsEnabled;
    int localLightsCount;
};
static void AddLocalLightsJob(AddLocalLightsJobInfo* jobInfo)
{
    PROFILER_AUTO(gAddLocalLights, NULL);

    AddActiveLocalLights(*jobInfo->results,
        jobInfo->lightCullingParams,
        jobInfo->localLights,
        jobInfo->localLightBSpheres,
        jobInfo->visibleLocalLights,
        jobInfo->visibilityFades,
        jobInfo->offScreenLocalLights,
        jobInfo->results->activeLights,
        jobInfo->customLights,
        jobInfo->lightScreenRects,
        jobInfo->lightVisibilityMasks);

    DestroyIndexList(jobInfo->visibleLocalLights);
    DestroyIndexList(jobInfo->offScreenLocalLights);

    // Shadows might be disabled in quality setting
    if (jobInfo->shadowsEnabled)
        LocalLightShadowCasterCulling(*jobInfo->params, *jobInfo->results);
    for (size_t i = 0; i < jobInfo->localLightsCount; i++)
        jobInfo->localLights[i]->Release();

    jobInfo->customLights.~ActiveLights();
    BatchAllocator::DeallocateRoot(kMemTempJobAlloc, jobInfo);
}

//@TODO: We should split this function function into the part that requires dynamic objects + static objects to have completed culling.
//       And the part that does not. And then call them at different stages in the culling pipeline.
//       We can get some more parallelism that way.
static void CullLights(const SceneCullingParameters& cullingParameters, CullResults& results)
{
    LightManager::Lights& lights = GetLightManager().GetAllLights();
    size_t lightCount = lights.size_slow();

    // Early exit if the scene does not have lights
    const bool hasCustomLights = GlobalCallbacks::Get().addCustomLights.AnyRegistered();
    if (lightCount == 0 && !hasCustomLights)
    {
        results.activeLights.hasMainLight = false;
        results.activeLights.hasShadowedDirLights = false;
        return;
    }

    PROFILER_AUTO(gCullActiveLights, NULL);

    // Add visible local lights and off screen local lights to the outlights...
    bool shadowsEnabled = (GetQualitySettings().GetCurrent().shadows != QualitySettings::kShadowsDisable);
    BatchAllocator jobBatchAllocator;
    const int eyeCount = cullingParameters.stereo ? 2 : 1;
    AddLocalLightsJobInfo* addLocalLightsJobInfo = NULL;

    jobBatchAllocator.AllocateRoot(addLocalLightsJobInfo);
    jobBatchAllocator.AllocateField(addLocalLightsJobInfo->localLights, lightCount);
    jobBatchAllocator.AllocateField(addLocalLightsJobInfo->localLightBSpheres, lightCount);
    jobBatchAllocator.AllocateField(addLocalLightsJobInfo->lightScreenRects, lightCount * eyeCount);
    jobBatchAllocator.AllocateField(addLocalLightsJobInfo->visibilityFades, lightCount);
    jobBatchAllocator.AllocateField(addLocalLightsJobInfo->lightVisibilityMasks, lightCount);
    jobBatchAllocator.Commit(kMemTempJobAlloc);

    //Batch Allocator is just a malloc need to make sure custom lights are initialized.
    new(&(addLocalLightsJobInfo->customLights))ActiveLights();

    addLocalLightsJobInfo->shadowsEnabled = shadowsEnabled;
    addLocalLightsJobInfo->params = &cullingParameters;
    addLocalLightsJobInfo->results = &results;

    dynamic_array<const Light*> directionalLights(kMemTempAlloc);

    directionalLights.reserve(lightCount);
    results.isShadowCastingLight.reserve(lightCount);

    unsigned int localLightCount = 0;
    // Collect active lights and their parameters into separate arrays
    FindActiveLights(directionalLights, addLocalLightsJobInfo->localLights, addLocalLightsJobInfo->localLightBSpheres, results.isShadowCastingLight, *results.shadowCullData, localLightCount);
    addLocalLightsJobInfo->localLightsCount = localLightCount;
    // Reserve memory for lights...
    const size_t directionalLightCount = directionalLights.size();
    const size_t totalLightCount = directionalLightCount + localLightCount;
    results.activeLights.lights.reserve(totalLightCount);
    results.shadowedLights.reserve(totalLightCount);
    results.lightIndexMap.resize_uninitialized(totalLightCount);
    for (int i = 0; i < totalLightCount; i++)
    {
        results.lightIndexMap[i] = i;
    }

    // Add directional lights to the outLights...
    AddDirectionalLights(directionalLights.begin(), directionalLights.size(), results.activeLights);

    // Must reserve here otherwise the shadowlight pointer in activelight might become invalid...
    FindDirectionalShadowCastingLights(results.activeLights, results.shadowedLights);

    InitIndexList(addLocalLightsJobInfo->visibleLocalLights, localLightCount);
    InitIndexList(addLocalLightsJobInfo->offScreenLocalLights, localLightCount);

    //Setup the custom light data before doing the local light culling
    InitLocalLightCullingParameters(results, addLocalLightsJobInfo->lightCullingParams);
    AddActiveCustomLights(addLocalLightsJobInfo->lightCullingParams, results, addLocalLightsJobInfo->customLights);

    // Cull active local lights, and directional shadow casters in parallel
    CullLocalLights(results.cullLocalLightsFence,
        results.occlusionBufferIsReady,
        cullingParameters,
        localLightCount,
        addLocalLightsJobInfo->localLightBSpheres,
        results.isShadowCastingLight,
        addLocalLightsJobInfo->visibleLocalLights,
        addLocalLightsJobInfo->offScreenLocalLights,
        addLocalLightsJobInfo->visibilityFades,
        addLocalLightsJobInfo->lightScreenRects,
        addLocalLightsJobInfo->lightVisibilityMasks,
        addLocalLightsJobInfo->localLights,
        *results.shadowCullData);
    CullDirectionalShadowCasters(results.shadowedLights.size(), cullingParameters, results);
    ScheduleJobDepends(results.addLocalLightsFence, AddLocalLightsJob, addLocalLightsJobInfo, results.cullLocalLightsFence);
}

static void CullSendEvents(CullResults& results, NeedsCullCallback& needsCullCallback, NeedsCullCallback* rendererCullCallbacks, const ScriptableCullingParameters& cullingCameraParameters)
{
    PROFILER_AUTO(gCullSendEvents, NULL);

    // Send OnBecameVisible / OnBecameInvisible callback
    SyncFence(results.sceneCullingOutputIsReady);

    GlobalCallbacks::Get().afterCullingOutputReady.Invoke(
        results.sceneCullingOutput.visible,
        results.sceneCullParameters.renderers);

    SyncFence(results.nodesHaveBeenPrepared);

    // Invoke renderer callbacks (Only scene visible objects)
    InvokeOnWillRenderObject(needsCullCallback);

    // Update any renderers changed during the callbacks.
    GetRendererUpdateManager().UpdateAll(GetRendererScene());

    for (int i = 0; i < kRendererTypeCount; i++)
    {
        if (rendererCullCallbacks[i].size())
            GlobalCallbacks::Get().rendererCullingOutputReady[i].Invoke(rendererCullCallbacks[i].data(), rendererCullCallbacks[i].size(), cullingCameraParameters, cullingCameraParameters.cameraProperties.worldToCamera);
    }
}

////@TODO: Rename all this stuff it now only extracts the callbacks...
//         It would be best to just precache what needs callbacks completely instead of redoing it every frame...

// ---------------------------------------------------------------------------------------------------------------------------------
typedef dynamic_array<unsigned int> CallbackNodes;
// Used by the jobs that walk the scene nodes
struct PrepareSceneNodesJobData
{
    const IndexList*    visible;
    const SceneNode*    nodes;
    CullResults*        cullResults;
    int                 offset;
    bool*               rendererTypeRequiresCallback;
    CallbackNodes       callbackNodes[kMaximumBlockRangeCount];
    BlockRange          blocks[kMaximumBlockRangeCount];
};

// Used by the scheduling jobs that launch jobs for each of [0..kVisibleListCount]
struct ScheduleSceneNodesJobData
{
    //  Input
    PrepareSceneNodesJobData    jobData[kVisibleListCount];
    JobFence                    fences[kVisibleListCount];
    int                         offsets[kVisibleListCount];
    bool                        rendererTypeRequiresCallback[kRendererTypeCount];
    int                         jobCount;
    CullResults*                cullResults;
};

//  Walk scene nodes and setup renderer and lodFade.
//  Also creates a list of indexes for nodes requiring callback attention later
static void PrepareSceneNodesJob(PrepareSceneNodesJobData* jobData, unsigned int index)
{
    PROFILER_AUTO(gPrepareSceneNodesJob, NULL);

    const SceneNode* nodes = jobData->nodes;
    const IndexList* visible = jobData->visible;
    const bool* rendererTypeRequiresCallback =  jobData->rendererTypeRequiresCallback;

    const int begin = jobData->blocks[index].startIndex;
    const int end = (begin + jobData->blocks[index].rangeSize);

    Assert(begin >= 0);
    Assert(begin < end);

    for (int i = begin; i < end; ++i)
    {
        const SceneNode& node = nodes[visible->indices[i]];
        if (node.needsCullCallback || rendererTypeRequiresCallback[node.renderer->GetRendererType()])
        {
            //  Just push int index (SceneNode is relatively large - measurably quicker)
            //  Nodes that enter here are << total nodes
            jobData->callbackNodes[index].push_back(i);
        }
    }
}

// Each of [0..kVisibleList] can launch a variable number of jobs
// This combine job both assists with jobs and processing/combining non-direct output
static void PrepareSceneNodesJobCombine(ScheduleSceneNodesJobData* jobData)
{
    PROFILER_AUTO(gPrepareSceneNodesCombineJob, NULL);

    const bool* rendererTypeRequiresCallback = jobData->rendererTypeRequiresCallback;
    NeedsCullCallback& needsCullCallback = jobData->cullResults->needsCullCallback;
    NeedsCullCallback* rendererCullCallbacks = jobData->cullResults->rendererCullCallbacks;

    const int jobSetCount = jobData->jobCount;
    Assert(jobSetCount == kVisibleListCount);

    for (int i = 0; i < jobSetCount; ++i)
    {
        //  We need to ensure all sub jobs are over the line
        //  And SyncFence will allow us to assist if there are any pending
        SyncFence(jobData->fences[i]);

        //  This set of jobs have finished - see if there are callback nodes to process
        //  These are (usually) few in number relative to input set size
        const IndexList* visible = jobData->jobData[i].visible;
        const SceneNode* nodes = jobData->jobData[i].nodes;
        const int jobCount = jobData->jobData[i].blocks[0].rangesTotal;
        for (int j = 0; j < jobCount; ++j)
        {
            CallbackNodes& callbackNodes = jobData->jobData[i].callbackNodes[j];
            const int callbackCount = callbackNodes.size();
            Assert(callbackCount <= jobData->jobData[i].blocks[j].rangeSize);
            if (callbackCount)
            {
                //  Add all nodes of interest that were marked up in the jobs
                for (int k = 0; k < callbackCount; ++k)
                {
                    const int index = callbackNodes[k];
                    Assert(index >= jobData->jobData[i].blocks[j].startIndex);
                    Assert(index < (jobData->jobData[i].blocks[j].startIndex + jobData->jobData[i].blocks[j].rangeSize));
                    const SceneNode& node = nodes[visible->indices[index]];
                    if (node.needsCullCallback)
                    {
                        needsCullCallback.push_back(node.renderer);
                    }
                    const RendererType rendererType = node.renderer->GetRendererType();
                    if (rendererTypeRequiresCallback[rendererType])
                    {
                        rendererCullCallbacks[rendererType].push_back(node.renderer);
                    }
                }
            }
        }
    }

    //  Free up highest level jobData
    UNITY_DELETE(jobData, kMemTempJobAlloc);
}

//  This runs as soon as the culling output is available
//  Presizes the VisibleNodes output array (and job starting points) so jobs can write directly rather than into interim containers
static void PresizeOutputJob(ScheduleSceneNodesJobData* jobData)
{
    PROFILER_AUTO(gSceneNodesInitJob, NULL);

    //  Set up starting points for each job of [0..kVisibleListCount] to write into
    int total = 0;
    for (int i = 0; i < jobData->jobCount; ++i)
    {
        jobData->offsets[i] = total;
        total += jobData->cullResults->sceneCullingOutput.visible[i].size;
    }

    //  Setup data used for culling callbacks
    for (int i = 0; i < kRendererTypeCount; ++i)
    {
        jobData->rendererTypeRequiresCallback[i] = GlobalCallbacks::Get().rendererCullingOutputReady[(RendererType)i].AnyRegistered();
    }
}

// Schedules a group of jobs but only if data is present for this type
// This is called [0..kVisibleListCount] times and is a job itself
static void ScheduleSceneNodesJobs(ScheduleSceneNodesJobData* jobData, unsigned int index)
{
    PROFILER_AUTO(gPrepareSceneNodesSetup, NULL);

    const IndexList* visible = &jobData->cullResults->sceneCullingOutput.visible[index];
    PrepareSceneNodesJobData&   prepareSceneNodesJobData = jobData->jobData[index];
    const int howManyForThisType = visible->size;

    //  If there are Indices in this IndexList then we create sub jobs from this one
    if (howManyForThisType != 0)
    {
        const SceneNode* nodes = jobData->cullResults->sceneCullParameters.renderers[index].nodes;
        //  Ideal amount of nodes per job
        static  const   int kIdealNodesPerJob = 500;

        //  Figure out how many jobs we need for specified granularity (and setup ranges in blocks)
        const int jobCount = ConfigureBlockRangesWithMinIndicesPerJob(prepareSceneNodesJobData.blocks, howManyForThisType, kIdealNodesPerJob);

        //  Setup job variant data with only output setup deferred until later, once culling concludes
        for (int j = 0; j < jobCount; ++j)
        {
            const size_t size = prepareSceneNodesJobData.blocks[j].rangeSize;
            prepareSceneNodesJobData.visible = visible;
            prepareSceneNodesJobData.nodes = nodes;
            prepareSceneNodesJobData.cullResults = jobData->cullResults;
            //  Member variable dynamic_array will default to kMemDynamicArray label (slow) - reassign before it allocates anything for fast alloc in following reserve
            prepareSceneNodesJobData.callbackNodes[j].set_memory_label(kMemTempJobAlloc);
            prepareSceneNodesJobData.callbackNodes[j].reserve(size);
            prepareSceneNodesJobData.rendererTypeRequiresCallback = (bool*)&jobData->rendererTypeRequiresCallback;
            prepareSceneNodesJobData.offset = jobData->offsets[index];
        }

        ScheduleJobForEach(jobData->fences[index], PrepareSceneNodesJob, &prepareSceneNodesJobData, jobCount);
    }
    // Otherwise we create no sub jobs and require a manual fence clear
    else
    {
        prepareSceneNodesJobData.blocks[0].rangesTotal = 0;
        ClearFenceWithoutSync(jobData->fences[index]);
    }
}

// Schedules kVisibleListCount jobs to create jobs to process the scene nodes of each
void PrepareSceneNodes(CullResults* results)
{
    PROFILER_AUTO(gPrepareSceneNodes, NULL);

    const int jobCount = kVisibleListCount;

    //  Create our invariant job data
    ScheduleSceneNodesJobData& scheduleSceneNodesJobData = *UNITY_NEW(ScheduleSceneNodesJobData, kMemTempJobAlloc);
    scheduleSceneNodesJobData.jobCount = jobCount;
    scheduleSceneNodesJobData.cullResults = results;

    //  Schedule very quick prelude job that subsequent group of jobs go after
    //  It simply resizes the output array and sets up domains for the jobs to write directly to
    //  This cannot execute until the scene culling output is finished
    JobFence noWaitFence;
    ScheduleJobDepends(noWaitFence, PresizeOutputJob, &scheduleSceneNodesJobData, results->sceneCullingOutputIsReady);

    //  Schedule jobs with a combine function that will bring together output and assist until output is complete. These run immediately after init job
    //  These two schedules together mean we go wide on setting up the job data too
    ScheduleJobForEachDepends(results->nodesHaveBeenPrepared, ScheduleSceneNodesJobs, &scheduleSceneNodesJobData, jobCount, noWaitFence, PrepareSceneNodesJobCombine);

    //  Nothing waits on this - it's simply used to trigger a dependency
    ClearFenceWithoutSync(noWaitFence);
}

//  ---------------------------------------------------------------------------------------------------------------------------------

void CullScene(SceneCullingParameters& cullingParameters, const ScriptableCullingParameters& cullingCameraParameters, CullResults& results)
{
    PROFILER_AUTO(gSceneCulling, NULL);

    CullingOutput& cullingOutput = results.sceneCullingOutput;

    CullDynamicScene(results.sceneCullingOutputIsReady, results.occlusionBufferIsReady, cullingParameters, cullingOutput);

    PrepareSceneNodes(&results);

    if (cullingParameters.cullLights)
    {
        if (GlobalCallbacks::Get().addCustomLights.AnyRegistered())     // uses rendererCullCallbacks, so need to wait for it to be populated
            SyncFence(results.nodesHaveBeenPrepared);
        CullLights(cullingParameters, results);
    }

    CullSendEvents(results, results.needsCullCallback, results.rendererCullCallbacks, cullingCameraParameters);
}

void CullIntermediateRenderersOnly(const SceneCullingParameters& cullingParameters, CullResults& results)
{
    Assert(cullingParameters.renderers[kDynamicRenderer].nodes == NULL);

    const RendererCullData& cullData = cullingParameters.renderers[kCameraIntermediate];
    if (cullData.rendererCount > 0)
    {
        IndexList& visibleRenderers = results.sceneCullingOutput.visible[kCameraIntermediate];
        for (int i = 0; i < cullData.rendererCount; i++)
            visibleRenderers[i] = i;
        visibleRenderers.size = cullData.rendererCount;
    }

    if (cullingParameters.cullLights)
        CullLights(cullingParameters, results);
}
