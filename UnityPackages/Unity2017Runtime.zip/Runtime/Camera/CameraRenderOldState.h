#pragma once

#include "CameraTypes.h"
#include "Runtime/GameCode/Behaviour.h"
#include "Runtime/Math/Rect.h"
#include "Runtime/Math/Color.h"
#include "Runtime/Geometry/Ray.h"
#include "Runtime/Graphics/CommandBuffer/RenderingEvents.h"
#include "Runtime/Graphics/Texture.h"
#include "Runtime/Shaders/Shader.h"
#include "Runtime/Modules/ExportModules.h"
#include "Runtime/Shaders/GraphicsCaps.h"
#include "Runtime/GfxDevice/GfxDeviceObjects.h"
#include <vector>

class CameraStackRenderingState;
class RenderTexture;
struct ShaderPassContext;

struct CameraRenderOldState
{
    CameraRenderOldState() : viewport(0, 0, 1, 1), cameraStackRenderState(NULL), sRGBWrite(false)
    {
    }

    RectInt viewport;
    RectInt scissorRect;
    PPtr<Camera> camera;
    CameraStackRenderingState* cameraStackRenderState;
    PPtr<RenderTexture> activeRT;
    bool                sRGBWrite;
    bool                scissorEnabled;

    Matrix4x4f matWorld;
    Matrix4x4f matView;
    Matrix4x4f matProj;

    ShaderPropertySheet::TextureProperty depthTex;
    ShaderPropertySheet::TextureProperty depthNormalsTex;
};

void StoreRenderState(CameraRenderOldState& state, const ShaderPassContext& passContext);
void RestoreRenderState(CameraRenderOldState& state, ShaderPassContext& passContext);
