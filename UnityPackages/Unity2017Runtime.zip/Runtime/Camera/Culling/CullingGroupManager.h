#pragma once

#include "Runtime/Utilities/dynamic_array.h"
#include "Runtime/Camera/CullingParameters.h"
#include "Runtime/BaseClasses/BaseObject.h"

class CullingGroup;
struct SceneCullingParameters;
struct CullingOutput;
struct JobFence;

class CullingGroupManager
{
public:

    void AddCullingGroup(CullingGroup* area);
    void RemoveCullingGroup(CullingGroup* area);

    const dynamic_array<CullingGroup*>& GetCullingGroups() const;

    void CullAndSendEvents(const SceneCullingParameters& cullingParameters, const InstanceID cameraInstanceID, const CullingOutput& sceneCullingData, const JobFence& staticCullingDone);

    static CullingGroupManager& Get();
    static void InitializeClass(void* data);
    static void CleanupClass(void* data);

private:

    CullingGroupManager();

    dynamic_array<CullingGroup*> m_CullingGroups;
    static CullingGroupManager*  s_CullingGroupManager;
};

inline const dynamic_array<CullingGroup*>&  CullingGroupManager::GetCullingGroups() const   { return m_CullingGroups; }
inline CullingGroupManager&                 CullingGroupManager::Get()                      { return *s_CullingGroupManager; }
