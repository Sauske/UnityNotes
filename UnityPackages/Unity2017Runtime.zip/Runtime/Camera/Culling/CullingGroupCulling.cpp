#include "UnityPrefix.h"
#include "CullingGroup.h"
#include "Runtime/Camera/Culling/LowLevelCullingLoops.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Jobs/BlockRangeJob.h"

/* ------ TODOS:------
 * RJF: enable API for pausing/resuming (already done, but write test)
 * RJF: More runtime tests
 * RJF: More documentation

 * ----- FUTURE: -----
 * Camera.ScheduleStaticCulling()
 * CullingGroup.MarkUpdateCompleted()
 * If we actually find this to be a real world problem: Allow setup where all spheres are the same size, to reduce data stored / improve efficiency?


Doc notes:
* Mention that OcclusionPortal State can not be modified in cullinggroup callback (1 frame delay in this case)

 */

PROFILER_INFORMATION(gScheduleCullingGroups                             , "ScheduleCullingGroups" ,     kProfilerRender);
PROFILER_INFORMATION(gCullGroupSpheres                                  , "CullGroupSphereRange",       kProfilerRender);
PROFILER_INFORMATION(gCullGroupCombineResults                           , "CullGroupCombineResults",    kProfilerRender);

struct CullingGroupData;
struct CullingGroupsJobData;

struct CullingGroupData
{
    const Vector4f*                         boundingSpheres;
    BlockRange                              subTaskRange;

    math::float3                            distanceRefPoint;
    const math::float4*                     boundingDistances;
    CullingGroup::CullingUpdateType         updateType;
    size_t                                  numBoundingDistances;
    bool                                    shouldCullBeyondMaxDistance;

    UInt8*                                  output;
};

struct CullingGroupsJobData
{
    const CullingParameters*        cullingParams;

    const Umbra::OcclusionBuffer*   occlusionBuffer;
    const bool*                     useUmbraOcclusionCulling;

    CullingGroupData*               groups;

    dynamic_array<unsigned int>     subTaskGroupIndices;
    dynamic_array<BlockRange>       subTasks;

    BlockRange                      tasks[kMaximumBlockRangeCount];

    CullingGroupsJobData()
        : subTaskGroupIndices(kMemTempJobAlloc),
        subTasks(kMemTempJobAlloc)
    {}
};

static inline void CalculateDistanceIndicesFor4Spheres(const math::float1& refX, const math::float1& refY, const math::float1& refZ,
    const Vector4f* spheres,
    const math::float4* boundingDistances, size_t numBoundingDistances,
    UInt8* output)
{
    using namespace math;

    float4 sphere0 = vload4f(spheres[0].GetPtr());
    float4 sphere1 = vload4f(spheres[1].GetPtr());
    float4 sphere2 = vload4f(spheres[2].GetPtr());
    float4 sphere3 = vload4f(spheres[3].GetPtr());

    float4 deltaXs = float4(sphere0.x, sphere1.x, sphere2.x, sphere3.x) - refX;
    float4 deltaYs = float4(sphere0.y, sphere1.y, sphere2.y, sphere3.y) - refY;
    float4 deltaZs = float4(sphere0.z, sphere1.z, sphere2.z, sphere3.z) - refZ;
    float4 radii    = float4(sphere0.w, sphere1.w, sphere2.w, sphere3.w);

    float4 distances = (deltaXs * deltaXs)
        + (deltaYs * deltaYs)
        + (deltaZs * deltaZs)
        - (radii * radii);

    int4 indices = int4(ZERO);
    for (size_t index = 0; index < numBoundingDistances; ++index)
    {
        // operators generate -1 (0xFFFFFFFFFF) or 0. Hence this is the same as
        // indices += (distances > boundingDistances[index]) & int4(1);
        indices -= distances > boundingDistances[index];
    }

    // Note that this overwrites the top bit in the result byte so do it before culling
    output[0] = indices.x;
    output[1] = indices.y;
    output[2] = indices.z;
    output[3] = indices.w;
}

static void CalculateDistanceIndices(CullingGroupData& group, BlockRange& range, CullingGroupsJobData& job)
{
    using namespace math;

    const Vector4f* boundingSpheres = group.boundingSpheres;

    float1 refX = group.distanceRefPoint.x;
    float1 refY = group.distanceRefPoint.y;
    float1 refZ = group.distanceRefPoint.z;

    // Process spheres 4 at a time.
    size_t i;
    for (i = range.startIndex; i + 4 <= range.startIndex + range.rangeSize; i += 4)
    {
        CalculateDistanceIndicesFor4Spheres(refX, refY, refZ,
            boundingSpheres + i,
            group.boundingDistances, group.numBoundingDistances,
            &group.output[i]);
    }

    // Deal with unaligned (aligned by 4) leftover spheres
    size_t numLeftover = (range.startIndex + range.rangeSize) - i;
    if (numLeftover > 0)
    {
        Vector4f leftoverSpheres[4];
        for (size_t j = 0; j < numLeftover; ++j)
            leftoverSpheres[j] = boundingSpheres[i + j];

        UInt8 leftoverOutput[4];
        CalculateDistanceIndicesFor4Spheres(refX, refY, refZ, leftoverSpheres, group.boundingDistances, group.numBoundingDistances, leftoverOutput);

        for (size_t j = 0; j < numLeftover; ++j)
            group.output[i + j] = leftoverOutput[j];
    }
}

static void CalculateVisibilityState(CullingGroupData& group, BlockRange& range, CullingGroupsJobData& job)
{
    if (*job.useUmbraOcclusionCulling)
        GetIUmbra()->CullBoundingSpheresUmbra(group.boundingSpheres, job.occlusionBuffer, range.startIndex, range.startIndex + range.rangeSize, group.output, CullingGroup::kIsVisible, true);
    else
        CullBoundingSpheresWithoutUmbra(*(job.cullingParams), group.boundingSpheres, range.startIndex, range.startIndex + range.rangeSize, group.output, CullingGroup::kIsVisible, true);
}

static void CalcDistanceStateOnly(CullingGroupData& group, BlockRange& range, CullingGroupsJobData& job)
{
    CalculateDistanceIndices(group, range, job);
}

static void CalcDistanceAndVisibilityState(CullingGroupData& group, BlockRange& range, CullingGroupsJobData& job)
{
    CalculateDistanceIndices(group, range, job);
    CalculateVisibilityState(group, range, job);
}

static void ClearVisibilityBit(CullingGroupData& group, BlockRange& range)
{
    size_t end = range.startIndex + range.rangeSize;
    for (size_t i = range.startIndex; i < end; ++i)
        group.output[i] &= ~CullingGroup::kIsVisible;
}

static void ApplyDistanceCulling(CullingGroupData& group, BlockRange& range, CullingGroupsJobData& job)
{
    size_t end = range.startIndex + range.rangeSize;
    for (size_t i = range.startIndex; i < end; ++i)
    {
        if ((group.output[i] & CullingGroup::kDistanceIndexMask) >= group.numBoundingDistances)
            group.output[i] &= ~CullingGroup::kIsVisible;
    }
}

static void CullGroupJob(CullingGroupsJobData* jobData, unsigned int taskIndex)
{
    PROFILER_AUTO(gCullGroupSpheres, NULL);

    BlockRange& task = jobData->tasks[taskIndex];

    for (int i = task.startIndex; i < task.startIndex + task.rangeSize; ++i)
    {
        CullingGroupData& group = jobData->groups[jobData->subTaskGroupIndices[i]];

        switch (group.updateType)
        {
            case CullingGroup::kUpdateNothing:
                ClearVisibilityBit(group, jobData->subTasks[i]);
                break;
            case CullingGroup::kUpdateVisibility:
                CalculateVisibilityState(group, jobData->subTasks[i], *jobData);
                break;
            case CullingGroup::kUpdateDistance:
                CalcDistanceStateOnly(group, jobData->subTasks[i], *jobData);
                break;
            case CullingGroup::kUpdateVisibilityAndDistance:
                CalcDistanceAndVisibilityState(group, jobData->subTasks[i], *jobData);
                break;
        }

        if (group.shouldCullBeyondMaxDistance)
            ApplyDistanceCulling(group, jobData->subTasks[i], *jobData);
    }
}

static void CleanUpJob(CullingGroupsJobData* job)
{
    PROFILER_AUTO(gCullGroupCombineResults, NULL);

    UNITY_FREE(kMemTempJobAlloc, job->groups);
    UNITY_DELETE(job, kMemTempJobAlloc);
}

static inline bool ShouldCullCamera(const SceneCullingParameters& cullingParameters, const InstanceID cameraInstanceID, CullingGroup& group)
{
    return group.GetTargetCamera().GetInstanceID() == cameraInstanceID;
}

void ScheduleCullingAllGroups(JobFence& fence, const SceneCullingParameters& cullingParameters, const InstanceID cameraInstanceID, const CullingOutput& sceneCullingData, const dynamic_array<CullingGroup*>& groups, const JobFence& staticCullingDone)
{
    PROFILER_AUTO(gScheduleCullingGroups, NULL);

    if (groups.empty())
        return;

    CullingGroupsJobData* jobData = UNITY_NEW(CullingGroupsJobData, kMemTempJobAlloc);
    jobData->cullingParams = &cullingParameters;
    jobData->useUmbraOcclusionCulling = &sceneCullingData.useUmbraOcclusionCulling;
    if (*jobData->useUmbraOcclusionCulling)
        jobData->occlusionBuffer = GetIUmbra()->GetUmbraVisibilityOutputBuffer(sceneCullingData.umbraVisibility);

    jobData->groups = (CullingGroupData*)UNITY_MALLOC(kMemTempJobAlloc, sizeof(CullingGroupData) * groups.size());

    // Set up per-group data and count the total spheres to process
    size_t totalSpheres = 0;
    for (int i = 0; i < groups.size(); ++i)
    {
        CullingGroup& srcGroup = *groups[i];
        CullingGroupData& group = jobData->groups[i];

        group.boundingSpheres = srcGroup.GetBoundingSpheres();

        group.updateType = srcGroup.GetUpdateType();

        if ((group.updateType & CullingGroup::kUpdateVisibility) && !ShouldCullCamera(cullingParameters, cameraInstanceID, srcGroup))
            group.updateType = (CullingGroup::CullingUpdateType)(group.updateType & ~CullingGroup::kUpdateVisibility);

        if (group.updateType & CullingGroup::kUpdateDistance)
        {
            group.distanceRefPoint = srcGroup.GetEffectiveDistanceReferencePoint();
            group.numBoundingDistances = srcGroup.GetBoundingDistancesCount();
            group.boundingDistances = srcGroup.GetBoundingDistances();
            group.shouldCullBeyondMaxDistance = !srcGroup.GetLastBoundingDistanceIsInfinity();
        }
        else
        {
            group.numBoundingDistances = 0;
            group.shouldCullBeyondMaxDistance = false;
        }

        group.output = srcGroup.GetCurrentStateBuffer();

        totalSpheres += srcGroup.GetBoundingSphereCount();
    }

    if (totalSpheres == 0)
    {
        UNITY_FREE(kMemTempJobAlloc, jobData->groups);
        UNITY_DELETE(jobData, kMemTempJobAlloc);
        return;
    }

    // Now we know the size of the workload, we can pick a number of jobs / spheres per job
    int taskCount = CalculateJobCountWithMinIndicesPerJob(totalSpheres, 256);
    size_t spheresPerJob = std::ceil(totalSpheres / (float)taskCount);

    int subTaskEstimate = taskCount + groups.size();
    jobData->subTasks.reserve(subTaskEstimate);
    jobData->subTaskGroupIndices.reserve(subTaskEstimate);

    BlockRangeBalancedWorkload workload(jobData->tasks, spheresPerJob);

    for (int i = 0; i < groups.size(); ++i)
    {
        jobData->groups[i].subTaskRange = AddGroupToWorkload(workload, groups[i]->GetBoundingSphereCount(), jobData->subTasks, jobData->subTaskGroupIndices);
    }

    Assert(workload.currentTaskIndex == taskCount - 1);

    ScheduleJobForEachDepends(fence, CullGroupJob, jobData, taskCount, staticCullingDone, CleanUpJob, kHighJobPriority);
}
