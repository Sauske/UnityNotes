#include "UnityPrefix.h"
#include "CullingGroupManager.h"
#include "CullingGroup.h"
#include "CullingGroupCulling.h"
#include "Runtime/Utilities/RegisterRuntimeInitializeAndCleanup.h"
#include "Runtime/Jobs/Jobs.h"
#include "Runtime/Profiler/Profiler.h"

PROFILER_INFORMATION(gCullingGroupSendEvents                                , "CullingGroupSendEvents" ,        kProfilerRender);


CullingGroupManager* CullingGroupManager::s_CullingGroupManager = NULL;

CullingGroupManager::CullingGroupManager()
{
}

void CullingGroupManager::AddCullingGroup(CullingGroup* area)
{
    area->m_GroupIndex = m_CullingGroups.size();
    m_CullingGroups.push_back(area);
}

void CullingGroupManager::RemoveCullingGroup(CullingGroup* area)
{
    CullingGroup* replaceArea = m_CullingGroups.back();
    m_CullingGroups[area->m_GroupIndex] = m_CullingGroups.back();
    m_CullingGroups.pop_back();

    replaceArea->m_GroupIndex = area->m_GroupIndex;
    area->m_GroupIndex = -1;
}

/// @brief
/// @param cullingParameters
/// @param cameraInstanceID
/// @param sceneCullingData
/// @param staticCullingDone
void CullingGroupManager::CullAndSendEvents(const SceneCullingParameters& cullingParameters, const InstanceID cameraInstanceID, const CullingOutput& sceneCullingData, const JobFence& staticCullingDone)
{
    // Schedule
    JobFence cullingGroupJobs;
    const dynamic_array<CullingGroup*>& groups = GetCullingGroups();
    ScheduleCullingAllGroups(cullingGroupJobs, cullingParameters, cameraInstanceID, sceneCullingData, groups, staticCullingDone);

    // Wait right away because we need to send the events.
    PROFILER_AUTO(gCullingGroupSendEvents, NULL);
    SyncFence(cullingGroupJobs);

    // Send events
    for (int i = 0; i < groups.size(); i++)
    {
        CullingGroup& group = *groups[i];

        if (group.GetTargetCamera().GetInstanceID() != cameraInstanceID)
            continue;

        group.NotifyVisible();
        group.NotifyInvisible();
    }
}

void CullingGroupManager::InitializeClass(void* data)
{
    s_CullingGroupManager = UNITY_NEW(CullingGroupManager, kMemCulling);
}

void CullingGroupManager::CleanupClass(void* data)
{
    UNITY_DELETE(s_CullingGroupManager, kMemCulling);
}

static RegisterRuntimeInitializeAndCleanup s_RegisterCullingGroupManager(CullingGroupManager::InitializeClass, CullingGroupManager::CleanupClass);
