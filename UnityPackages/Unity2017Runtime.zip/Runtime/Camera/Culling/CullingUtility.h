#pragma once

inline int CountTotalVisibleRendererCount(const CullingOutput& cullData)
{
    int count = 0;
    for (int j = 0; j < kVisibleListCount; j++)
        count += cullData.visible[j].size;
    return count;
}
