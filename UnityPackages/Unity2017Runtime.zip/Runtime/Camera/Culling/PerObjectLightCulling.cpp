#include "UnityPrefix.h"
#include "PerObjectLightCulling.h"
#include "Runtime/Camera/Camera.h"
#include "Runtime/Camera/CameraUtil.h"
#include "Runtime/Camera/RenderLoops/DeferredUtils.h"
#include "Runtime/Camera/RendererProbeUtils.h"
#include "Runtime/Camera/LightUtil.h"
#include "Runtime/Shaders/Material.h"
#include "Runtime/Shaders/SharedMaterialDataUtility.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Shaders/ShaderImpl/ShaderImpl.h"
#include "Runtime/Graphics/LightmapSettings.h"
#include "External/boost/dynamic_bitset.h"
#include "Runtime/Geometry/Intersection.h"
#include "Runtime/Camera/ShadowCulling.h"

///@TODO: There is a ton of special casing code here especially with offscreenVisible lights etc....
///       Write unit tests for this.

//@TODO: It seems like offscreen light handling for vertex lights
//* Poppping when going offscreen. This is also present in 5.3...


PROFILER_INFORMATION(gCullPerObjectLights                               , "CullPerObjectLights" , kProfilerRender);
PROFILER_INFORMATION(gCullPerObjectLightsCombine                        , "CullPerObjectLightsCombine" , kProfilerRender);
PROFILER_INFORMATION(gComputeNeedsPerObjectLights               , "ComputeNeedsPerObjectLights" , kProfilerRender);

static bool DoesNeedForwardPathInDeferred(const RenderNode& node, const RenderingPathExt renderPathToCheck, bool hardwareSupportShadowMaskInDeferred, bool mainLightPreventsLightmappedObjectsFromDeferred)
{
    //@TODO: We could easily cache all this information in the SharedMaterialData directly.
    // Some Cached Flags could be really useful for things like this.

    const MaterialInfo* materialInfos = node.materialInfos;

    // using shadowMask in deferred but hardware does not support it -> fallbacking nodes with shadowmask to forward
    if (!hardwareSupportShadowMaskInDeferred && IsLightmappedForShadows(node.rendererData.m_LightmapIndex))
        return true;

    // subtractive mode is not supported in deferred ->
    // - nodes using lightmap will be forward lit as we don't have the relevant shader variations in deferred.
    // - nodes using light probes will be forward lit as we don't have an occlusion target in the gbuffer in subtractive mode.
    if ((mainLightPreventsLightmappedObjectsFromDeferred && (IsLightmappedForRendering(node.rendererData.m_LightmapIndex, kStaticLightmap))) || ((LightProbeUsage)node.rendererData.m_LightProbeUsage != kLightProbeOff))
        return true;

    // Check whether there are objects/shaders that are not handled by deferred, but are rendered with forward path
    for (int mi = 0; mi < node.materialCount; ++mi)
    {
        const MaterialInfo& materialInstance = materialInfos[mi];

        const Shader* shader = materialInstance.sharedMaterialData->shader;
        // if render queue belongs to alpha range - it
        // will be rendered in forward mode
        const int queue = GetActualRenderQueue(materialInstance, shader);
        if (queue > kGeometryQueueIndexMax)
            return true;

        // if shader does not support the used deferred path -
        // it will be rendered in forward mode
        Assert(shader);
        Assert(shader->GetShaderLabShader());
        int ss = shader->GetShaderLabShader()->GetDefaultSubshaderIndex(renderPathToCheck);
        if (ss == -1)
            return true;
    }

    return false;
}

static void ComputeNeedsPerObjectLights(const RenderNodeQueue& queue, size_t objectCount, const int renderPath, dynamic_bitset& cullPerObjectLightsResultsNeeded, bool mainLightPreventsLightmappedObjectsFromDeferred)
{
    PROFILER_AUTO(gComputeNeedsPerObjectLights, NULL);

    if (renderPath >= kRenderPathPrePass)
    {
        const RenderingPathExt renderPathToCheck = (renderPath == kRenderPathPrePass) ? kRenderPathExtPrePass : kRenderPathExtDeferred;
        bool hardwareSupportShadowMaskInDeferred = (GetGraphicsCaps().maxMRTs > kGBufferShadowMask);

        cullPerObjectLightsResultsNeeded.resize(objectCount, false);
        for (size_t i = 0; i < objectCount; ++i)
        {
            const RenderNode& node = queue.GetNode(i);

            bool forwardPathFound = DoesNeedForwardPathInDeferred(node, renderPathToCheck, hardwareSupportShadowMaskInDeferred, mainLightPreventsLightmappedObjectsFromDeferred);
            cullPerObjectLightsResultsNeeded[i] = forwardPathFound;
        }
    }
    else
    {
        // Forward always needs per object light culling
        cullPerObjectLightsResultsNeeded.resize(objectCount, true);
    }
}

static inline bool IsLightCulled(const ActiveLight& light, int layerMask, bool lightmappedObject)
{
    // Skip light, if its direct contribution is baked
    DebugAssert(light.light);
    DebugAssert(light.lightmapModeForRendering == GetLightmapModeForRender(*light.light));
    if (lightmappedObject && HasBakedDirectLightInLightmap(light.lightmapModeForRendering))
        return true;

    // Cull by layer mask
    if ((layerMask & light.cullingMask) == 0)
        return true;

    return false;
}

static inline bool IsDirectionalLightCulled(const ActiveLight& light, int layerMask, bool lightmappedObject)
{
    DebugAssert(light.lightType == kLightDirectional);

    return IsLightCulled(light, layerMask, lightmappedObject);
}

static inline bool IsSpotLightCulledByFrustum(const ActiveLight& light, const AABB& localObjectAABB, const Matrix4x4f& objectTransform)
{
    const SharedLightData& source = *light.light;

    // Detailed culling: frustum vs local AABB
    Plane planes[6];
    Matrix4x4f zscale, objectToLightMatrix, projectionMatrix;
    zscale.SetScale(Vector3f(1.0F, 1.0F, -1.0F));

    const float minNearDist = 0.0001F;
    const float minNearFarRatio = 0.00001F;
    float nearDist = std::max(minNearDist, source.GetRange() * minNearFarRatio);
    float farDist = std::max(nearDist + 0.0001F, source.GetRange());
    projectionMatrix.SetPerspectiveCotan(source.GetCotanHalfSpotAngle(), nearDist, farDist);

    // objectToLightMatrix = zscale * GetWorldToLocalMatrix * objectTransform
    Matrix4x4f temp;
    MultiplyMatrices4x4(&zscale, &source.GetWorldToLocalMatrix(), &temp);
    MultiplyMatrices4x4(&temp, &objectTransform, &objectToLightMatrix);

    // finalProjMatrix = projectionMatrix * objectToLightMatrix
    Matrix4x4f finalProjMatrix;
    MultiplyMatrices4x4(&projectionMatrix, &objectToLightMatrix, &finalProjMatrix);
    ExtractProjectionPlanes(finalProjMatrix, planes);

    if (!IntersectAABBFrustumFull(localObjectAABB, planes))
        return true;

    return false;
}

// Note: this is hot function during culling phase (according to the Intel VTune)
// It's important to keep it inlined as IsLightCulled and IntersectAABBAABB are the most likely early out paths.
static inline bool IsSpotLightCulled(const ActiveLight& light, int layerMask, bool lightmappedObject, const AABB& globalObjectAABB, const AABB& localObjectAABB, const Matrix4x4f& objectTransform)
{
    DebugAssert(light.lightType == kLightSpot);

    // Common code (is inlined)
    if (IsLightCulled(light, layerMask, lightmappedObject))
        return true;

    // AABB vs AABB
    if (!IntersectAABBAABB(globalObjectAABB, light.boundingBox))
        return true;

    return IsSpotLightCulledByFrustum(light, localObjectAABB, objectTransform);
}

static inline bool IsPointLightCulled(const ActiveLight& light, int layerMask, bool lightmappedObject, const TransformInfo& info)
{
    DebugAssert(light.lightType == kLightPoint);

    // Common code
    if (IsLightCulled(light, layerMask, lightmappedObject))
        return true;

    // World AABB vs sphere
    if (!IntersectAABBSphere(info.worldAABB, light.cullSphere))
        return true;

    // Transformed local AABB vs sphere
    if (!IntersectTransformedAABBSphere(info.localAABB, info.worldMatrix, info.transformType, light.cullSphere))
        return true;

    return false;
}

static inline float CalculateLightIntensityAtPoint(const float lum, const SharedLightData& light, const Vector3f& position)
{
    if (light.GetLightType() == kLightDirectional)
    {
        if (light.GetShadowType() != kShadowNone)
            return lum * 16.0f;
        else
            return lum;
    }
    else
    {
        float sqrDistance = SqrMagnitude(position - light.GetWorldPosition());
        float atten = LightAttenuateApprox(sqrDistance, light.GetRange() * light.GetRange());
        return lum * atten;
    }
}

static inline void AddLight(const ActiveLights& activeLights, const Vector3f& objectCenter, int index, ObjectCulledLights& outLights)
{
    const ActiveLight& light = activeLights.lights[index];
    float blend = CalculateLightIntensityAtPoint(light.luminance, *light.light, objectCenter);
    CulledLight culledLight(index, blend + GetRenderModeSortBias(light.lightRenderMode));
    outLights.push_back(culledLight);
}

static bool CullPerObjectLights(const ActiveLights& activeLights, const RenderNode& node, int layerMask, bool lightmappedObject, ObjectCulledLights& outLights)
{
    const size_t prevSize       = outLights.size();
    const TransformInfo& transformInfo = node.rendererData.m_TransformInfo;
    const AABB& worldAABB = transformInfo.worldAABB;
    const Vector3f objectCenter = worldAABB.GetCenter();

    size_t index = 0;
    size_t endIndex = activeLights.numDirLights;
    for (; index < endIndex; index++)
        if (!IsDirectionalLightCulled(activeLights.lights[index], layerMask, lightmappedObject))
            AddLight(activeLights, objectCenter, index, outLights);

    endIndex += activeLights.numSpotLights;
    for (; index < endIndex; index++)
        if (!IsSpotLightCulled(activeLights.lights[index], layerMask, lightmappedObject, worldAABB, transformInfo.localAABB, transformInfo.worldMatrix))
            AddLight(activeLights, objectCenter, index, outLights);

    endIndex += activeLights.numPointLights;
    for (; index < endIndex; index++)
        if (!IsPointLightCulled(activeLights.lights[index], layerMask, lightmappedObject, transformInfo))
            AddLight(activeLights, objectCenter, index, outLights);

    const size_t numOnScreen = outLights.size();

    endIndex += activeLights.numOffScreenSpotLights;
    for (; index < endIndex; index++)
        if (!IsSpotLightCulled(activeLights.lights[index], layerMask, lightmappedObject, worldAABB, transformInfo.localAABB, transformInfo.worldMatrix))
            AddLight(activeLights, objectCenter, index, outLights);

    endIndex += activeLights.numOffScreenPointLights;
    for (; index < endIndex; index++)
        if (!IsPointLightCulled(activeLights.lights[index], layerMask, lightmappedObject, transformInfo))
            AddLight(activeLights, objectCenter, index, outLights);

    size_t  nowSize = outLights.size();

    if (nowSize != prevSize)
    {
        //  Sort in place (but only if required)
        std::sort(&outLights[prevSize], outLights.end());
    }

    bool hasOffScreenLights = (nowSize != numOnScreen);
    return hasOffScreenLights;
}

struct CullAllPerObjectLightsJobData
{
    ~CullAllPerObjectLightsJobData()
    {
        UNITY_DELETE(jobLightOffsets[0], kMemTempJobAlloc);     //  All jobs share subranges of one offset allocation
        int jobCount = blocks[0].rangesTotal;
        for (int i = 0; i < jobCount; ++i)
        {
            UNITY_DELETE(jobCulledLights[i], kMemTempJobAlloc);
        }
    }

    dynamic_bitset          needsPerObjectLights;

    const RenderNodeQueue*  queue;
    const ActiveLights*     lights;
    int                     renderPath;
    bool                    hasLightProbeTetrahedra;
    bool                    areLightProbesBaked;

    int                     objectCount;

    PerObjectLightCullingOutput* output;

    ObjectCulledLights*     jobCulledLights[kMaximumBlockRangeCount];
    UInt32*                 jobLightOffsets[kMaximumBlockRangeCount];
    BlockRange              blocks[kMaximumBlockRangeCount];
};

//  @TODO: Do more work in each job - light probes etc
static void CullAllPerObjectLightsJob(CullAllPerObjectLightsJobData* jobData, unsigned int index)
{
    PROFILER_AUTO(gCullPerObjectLights, NULL);

    const int begin = jobData->blocks[index].startIndex;
    const int end = begin + jobData->blocks[index].rangeSize;
    const dynamic_bitset& needsPerObjectLights = jobData->needsPerObjectLights;

    const RenderNodeQueue& queue = *jobData->queue;
    const ActiveLights& lights = *jobData->lights;
    ObjectCulledLights& forwardCulledLights = *jobData->jobCulledLights[index];
    UInt32* forwardLightOffsets = jobData->jobLightOffsets[index];

    for (int i = begin, count = 0; i < end; ++i)
    {
        UInt32 offsetMask = forwardCulledLights.size();

        const RenderNode& node = queue.GetNode(i);

        // skip CullPerObjectLight computation if the renderer does not need the results
        if (!needsPerObjectLights[i])
        {
            forwardLightOffsets[count++] = offsetMask;
            continue;
        }

        const UInt32 layerMask = 1 << node.layer;
        const bool isLightmapped = IsLightmappedForRendering(node.rendererData.m_LightmapIndex, kStaticLightmap);

        bool hasOffScreenLights = CullPerObjectLights(lights, node, layerMask, isLightmapped, forwardCulledLights);

        offsetMask |= hasOffScreenLights ? kHasOffscreenLightMask : 0;
        forwardLightOffsets[count++] = offsetMask;
    }
}

static void CullAllPerObjectLightsCombineJob(CullAllPerObjectLightsJobData* jobData)
{
    PROFILER_AUTO(gCullPerObjectLightsCombine, NULL);
    const int   jobCount = jobData->blocks[0].rangesTotal;
    ObjectCulledLights& forwardCulledLights = jobData->output->forwardCulledLights;
    ObjectLightIndices& forwardLightOffsets = jobData->output->forwardLightOffsets;

    //  Work out combined size of culled lights so we can resize/reserve destination just once
    int totalLights = 0;
    for (int i = 0; i < jobCount; ++i)
    {
        totalLights += (*jobData->jobCulledLights[i]).size();
    }

    //  Make immediate fully-sized reservations
    forwardCulledLights.reserve(totalLights);
    forwardLightOffsets.resize_uninitialized(jobData->objectCount + 1);

    int offsetCount = 0;
    for (int i = 0; i < jobCount; ++i)
    {
        ObjectCulledLights& jobCulledLights = *jobData->jobCulledLights[i];
        UInt32* jobLightOffsets = jobData->jobLightOffsets[i];
        //  -----------------------------------------------------------------------------------------------------------
        //  As jobs can complete in any order, so we must resolve offsets when all are done. Here we take the relative
        //  offsets stored in each job and make them absolute.
        //  To do this we must increase the relative offsets by the volume of lights that precede them in the combined
        //  array. This is at least I and D cache friendly.
        size_t  offsetRangeSize = jobData->blocks[i].rangeSize;
        const int existing = forwardCulledLights.size();

        if (existing)
        {
            for (int j = 0; j < offsetRangeSize; ++j)
            {
                UInt32 offset = (jobLightOffsets[j] & kOffsetMask) + existing;
                UInt32 offscreenMask = jobLightOffsets[j] & kHasOffscreenLightMask;

                jobLightOffsets[j] = offset | offscreenMask;
            }
        }

        memcpy(&forwardLightOffsets[offsetCount], jobLightOffsets, sizeof(UInt32) * offsetRangeSize);    // faster than sequential [] operator usage on dyn array
        offsetCount += offsetRangeSize;

        //  -----------------------------------------------------------------------------------------------------------
        //  Now concatenate to existing array (pre reserved so no resizing/additional copying takes place)
        forwardCulledLights.insert(forwardCulledLights.end(), jobCulledLights.begin(), jobCulledLights.end());
    }
    //  Final entry in light offsets is the total count ( we need the plus 1 - see GetObjectLightDetails )
    forwardLightOffsets[offsetCount] = forwardCulledLights.size();

    UNITY_DELETE(jobData, kMemTempJobAlloc);
}

void CullAllPerObjectLights(int renderPath, const RenderNodeQueue& queue, const ActiveLights& lights, PerObjectLightCullingOutput& output)
{
    size_t objectCount = queue.GetRenderNodesCount();
    if (objectCount == 0 || lights.lights.size() == 0)
        return;

    PROFILER_AUTO(gCullPerObjectLights, NULL);

    CullAllPerObjectLightsJobData& cullAllPerObjectLightsJobData = *UNITY_NEW(CullAllPerObjectLightsJobData, kMemTempJobAlloc);
    cullAllPerObjectLightsJobData.needsPerObjectLights.set_memory_label(kMemTempJobAlloc);
    cullAllPerObjectLightsJobData.queue = &queue;
    cullAllPerObjectLightsJobData.lights = &lights;
    cullAllPerObjectLightsJobData.output = &output;
    cullAllPerObjectLightsJobData.hasLightProbeTetrahedra = GetLightmapSettings().HasLightProbeTetrahedra();
    cullAllPerObjectLightsJobData.areLightProbesBaked = GetLightmapSettings().AreLightProbesBaked();
    cullAllPerObjectLightsJobData.renderPath = renderPath;
    cullAllPerObjectLightsJobData.objectCount = objectCount;

    const ActiveLight* mainActiveLight = GetMainActiveLight(lights);
    bool mainLightPreventsLightmappedObjectsFromDeferred = (mainActiveLight && mainActiveLight->light && mainActiveLight->lightmapModeForRendering == kLightmapModeRealtimeDynamicObjectsOnly);

    //  The total cost of CullAllPerObjectLights is O(NumVisibleNodes*NumLights). One unit of computation  is therefore the cost of
    //  processing one light against one node, accepting that all light costs are not the same (dir < point < spot etc).
    //  As such, we may have very high loads of one or both. Could be high nodes (common?) or high lights (less common?)
    //  but..we ScheduleJobForEach against a certain number of visible nodes, so we try to balance against the total units of computation
    //  rather than the number of nodes.
    static  const   int kIdealComputationsPerJob = 500; //  @TODO: Can we establish something more empirically?
    const   int totalComputations = objectCount * lights.lights.size();
    int balancedNumJobs = (totalComputations + (kIdealComputationsPerJob - 1)) / kIdealComputationsPerJob;
    int minVisibleObjectsPerJob = objectCount / balancedNumJobs;
    minVisibleObjectsPerJob = std::max<int>(minVisibleObjectsPerJob, 1);

    //  But ultimately it comes down to how many worker threads there are and ConfigureBlockRangesWithMinIndicesPerJob will clamp accordingly
    const int jobCount = ConfigureBlockRangesWithMinIndicesPerJob(cullAllPerObjectLightsJobData.blocks, objectCount, minVisibleObjectsPerJob);

    //  Do minimal allocations for all jobs here on same thread to avoid concurrent jobs hitting the allocator at same time (mutex locks show up in profiler)
    UInt32* offsets = (UInt32*)UNITY_MALLOC(kMemTempJobAlloc, objectCount * sizeof(UInt32));
    for (int i = 0; i < jobCount; ++i)
    {
        cullAllPerObjectLightsJobData.jobCulledLights[i] = (ObjectCulledLights*)UNITY_NEW(ObjectCulledLights, kMemTempJobAlloc);
        cullAllPerObjectLightsJobData.jobCulledLights[i]->set_memory_label(kMemTempJobAlloc);
        size_t size = cullAllPerObjectLightsJobData.blocks[i].rangeSize;
        cullAllPerObjectLightsJobData.jobCulledLights[i]->reserve(size * 5);
        cullAllPerObjectLightsJobData.jobLightOffsets[i] = &offsets[cullAllPerObjectLightsJobData.blocks[i].startIndex];
    }

    ComputeNeedsPerObjectLights(queue, objectCount, renderPath, cullAllPerObjectLightsJobData.needsPerObjectLights, mainLightPreventsLightmappedObjectsFromDeferred);

    //  Kick off MULTIPLE jobs that will complete in arbitrary order. Call CullAllPerObjectLightsCombineJob when ALL conclude
    ScheduleJobForEach(output.fence, CullAllPerObjectLightsJob, &cullAllPerObjectLightsJobData, jobCount, CullAllPerObjectLightsCombineJob);
}

//@TODO-Later: move to shadowculling
bool IsObjectWithinShadowRange(const ShadowJobData& shadowCullData, const AABB& bounds)
{
    if (shadowCullData.useSphereCulling)
    {
        float sqrDist = SqrMagnitude(bounds.GetCenter() - shadowCullData.shadowCullCenter);
        if (sqrDist < shadowCullData.shadowCullSquareRadius)
            return true;
        Sphere sphere(shadowCullData.shadowCullCenter, shadowCullData.shadowCullRadius);
        return IntersectAABBSphere(bounds, sphere);
    }
    else
    {
        return IntersectAABBPlaneBounds(bounds, &shadowCullData.shadowCullPlanes[kPlaneFrustumFar], 1);
    }
}
