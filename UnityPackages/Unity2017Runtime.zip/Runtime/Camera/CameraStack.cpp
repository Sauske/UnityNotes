#include "UnityPrefix.h"
#include "CameraStack.h"
#include "Runtime/Graphics/RenderBufferManager.h"
#include "Runtime/Graphics/RenderTexture.h"
#include "Runtime/Profiler/Profiler.h"
#include "Runtime/Graphics/QualitySettings.h"
#include "Runtime/Camera/CameraUtil.h"
#include "ImageFilters.h"
#include "Runtime/Misc/PlayerSettings.h"
#include "GraphicsSettings.h"
#include "RenderManager.h"
#include "Runtime/Interfaces/IVRDevice.h"

#if PLATFORM_WEBGL
#include "Runtime/GfxDevice/opengles/GraphicsCapsGLES.h"
#endif

PROFILER_INFORMATION(gFindCameraStacksProfile, "Camera.FindStacks", kProfilerRender)

// -------------------------------------------------------------------------------------------
// CameraStack functionality


static void CameraListToPointerArray(const CameraList& cameras, dynamic_array<Camera*>& outCameraPtrs)
{
    outCameraPtrs.reserve(cameras.size());
    for (CameraList::const_iterator it = cameras.begin(), itEnd = cameras.end(); it != itEnd; ++it)
    {
        Camera* cam = *it;
        if (cam == NULL)
            continue;
        if (!cam->GetEnabled())
            continue;
        outCameraPtrs.push_back(cam);
    }
}

static void DebugValidateCameraOrder(const dynamic_array<Camera*>& cameras)
{
#if !UNITY_RELEASE
    float prevDepth = -std::numeric_limits<float>::infinity();
    for (size_t i = 0; i < cameras.size(); ++i)
    {
        float depth = cameras[i]->GetDepth();
        DebugAssertMsg(depth >= prevDepth, "Cameras are expected to be passed in increasing depth in CameraStack code");
        prevDepth = depth;
    }
#endif
}

static void GetTargetsFromCamera(const Camera& cam, CameraTargetsAndRect& outTargets)
{
    outTargets.m_Viewport = cam.GetNormalizedViewportRect();
    outTargets.m_TargetTexture = cam.GetTargetTexture();
    outTargets.m_Stereo = cam.GetStereoEnabled();
    outTargets.m_SinglePassStereo = cam.GetSinglePassStereo();
    outTargets.m_ColorCount = 0;
    for (int i = 0; i < kMaxSupportedRenderTargets; ++i)
    {
        outTargets.m_ColorBuffer[i] = cam.GetTargetColorBuffer(i);
        if (outTargets.m_ColorBuffer[i].IsValid())
        {
            // corner case, if backbuffer we don't 'really' have a surface handle
            // if a user sets camera RT to null we do not handle it well +
            // it breaks a lot of things to try and fix it there;
            if (outTargets.m_ColorBuffer[i] != GetGfxDevice().GetBackBufferColorSurface())
                outTargets.m_ColorCount++;
        }
    }

    outTargets.m_DepthBuffer = cam.GetTargetDepthBuffer();
    outTargets.m_Display = cam.GetTargetDisplay();
}

static void GetTargetsFromCameras(const dynamic_array<Camera*>& cameras, dynamic_array<CameraTargetsAndRect>& outTargets)
{
    outTargets.resize_uninitialized(cameras.size());
    for (size_t i = 0, n = cameras.size(); i != n; ++i)
    {
        GetTargetsFromCamera(*cameras[i], outTargets[i]);
    }
}

int CalculateDesiredAntiAliasingForStack()
{
    if (!GetGraphicsCaps().hasMultiSample)
        return 1;

    int aa = GetQualitySettings().GetCurrent().antiAliasing;
    return std::min(std::max(aa, 1), 8);
}

void FindCameraStacks(const CameraList& cameraList, CameraStackArray& outStacks)
{
    PROFILER_AUTO(gFindCameraStacksProfile, NULL);

    outStacks.resize(0);

    // array of valid & enabled cameras
    dynamic_array<Camera*> cameraPtrs(kMemTempAlloc);
    CameraListToPointerArray(cameraList, cameraPtrs);
    const size_t cameraCount = cameraPtrs.size();
    // no cameras case, simplifies cases below
    if (cameraCount == 0)
        return;

    DebugValidateCameraOrder(cameraPtrs);

    // array of render target + rect information, matches cameras array
    dynamic_array<CameraTargetsAndRect> cameraTargets(kMemTempAlloc);
    GetTargetsFromCameras(cameraPtrs, cameraTargets);
    DebugAssert(cameraCount == cameraTargets.size());

    // stack indices per camera
    dynamic_array<int> stackIndices(kMemTempAlloc);
    stackIndices.resize_uninitialized(cameraCount);
    DebugAssert(!stackIndices.empty()); // no cameras case handled above

    // for each camera, figure out which stack we fall into
    // start at 0, then increment the stack index when a
    // change is encounted. This ensures ordering is preserved
    stackIndices[0] = 0;
    int stackCount = 1;

    for (size_t iCam = 1; iCam < cameraCount; ++iCam)
    {
        if (cameraTargets[iCam] != cameraTargets[iCam - 1])
            ++stackCount;

        stackIndices[iCam] = stackCount - 1;
    }

    // fill in final stacks info
    outStacks.resize(stackCount);
    for (size_t i = 0; i < cameraCount; ++i)
    {
        int camStack = stackIndices[i];
        DebugAssert(camStack >= 0 && camStack < stackCount);
        CameraStack& stack = outStacks[camStack];
        Camera* cam = cameraPtrs[i];
        stack.m_Cameras.push_back(cam);
        stack.m_ForceUseRT = stack.m_ForceUseRT || cam->HasAnyImageFilters() || cam->GetForceIntoRT();
        stack.m_HDR = stack.m_HDR || cam->GetAllowHDR();
        stack.m_MSAA = stack.m_MSAA || cam->GetAllowMSAA();
        stack.m_DynamicResolution = stack.m_DynamicResolution || cam->GetAllowDynamicResolution();
        stack.m_HasCommandBuffers = stack.m_HasCommandBuffers || (cam->GetCommandBufferCount() > 0);

        RenderingPath path = cam->CalculateRenderingPath();
        stack.m_HasDeferred = stack.m_HasDeferred || (path == kRenderPathPrePass) || (path == kRenderPathDeferred);
        stack.m_CameraTarget = cameraTargets[i];
    }

    for (size_t i = 0; i < stackCount; ++i)
    {
        int camStack = stackIndices[i];
        DebugAssert(camStack >= 0 && camStack < stackCount);
        CameraStack& stack = outStacks[camStack];

        // disable MSAA if deferred or MSAA is disabled
        if (stack.m_HasDeferred || CalculateDesiredAntiAliasingForStack() < 2)
            stack.m_MSAA = false;

        const TierGraphicsSettings& settings = GetGraphicsSettings().GetTierSettings();
        stack.m_HDR &= settings.useHDR;
    }
}

// -------------------------------------------------------------------------------------------
// Internal utility functions


bool PlatformSupportsMSAABB()
{
#if PLATFORM_ANDROID || UNITY_APPLE_PVR || PLATFORM_PSVITA
    return true;
#elif PLATFORM_WEBGL
    // back-buffer MSAA only on webgl1.0
    return IsGfxLevelES2(GetGraphicsCaps().gles.featureLevel);
#else
    return false;
#endif
}

CameraStackRenderingState::TargetType CameraStackRenderingState::CalculateStereoCameraTargetType() const
{
    Assert(m_CameraTarget.m_Stereo);

    bool hasFullScreenViewport = CompareApproximately(m_CameraTarget.m_Viewport, Rectf(0.0f, 0.0f, 1.0f, 1.0f));

    if (!hasFullScreenViewport || m_ForceUseRT || m_HDR || m_HasDeferred || m_HasCommandBuffers || !m_FirstStack)
    {
        return kStereo;
    }

    if (m_MSAA)
    {
        GraphicsCaps& caps = GetGraphicsCaps();
        TextureDimension texDim = GetIVRDevice()->GetEyeTextureDimension();
        if ((texDim == kTexDim2D && !caps.hasMultiSampleAutoResolve) || (texDim == kTexDim2DArray && !caps.hasMultiSampleTexture2DArrayAutoResolve))
            return kStereoResolveToEyeTexture;
    }

    return kStereoDirectToEyeTexture;
}

CameraStackRenderingState::TargetType CameraStackRenderingState::CalculateCameraTargetType() const
{
    if (m_CameraTarget.m_Stereo)
        return CalculateStereoCameraTargetType();

    if (m_CameraTarget.m_TargetTexture)
    {
        // if a user wants HDR we will blit at the last step
        // we can't use the provided texture ;(
        // also deferred + msaa
        bool isHDRFormat = IsHDRRTFormat(m_CameraTarget.m_TargetTexture->GetColorFormat()) || m_CameraTarget.m_TargetTexture->GetColorFormat() == kRTFormatDefaultHDR;
        if ((m_HDR && !isHDRFormat && !IsDepthRTFormat(m_CameraTarget.m_TargetTexture->GetColorFormat()))
            || (m_HasDeferred && m_CameraTarget.m_TargetTexture->GetAntiAliasing() > 1))
        {
            return kGenerated;
        }

        return kUserDefined;
    }

    if (!m_HasDeferred && m_CameraTarget.m_ColorCount > 0)
        return kUserDefined;

    if (!m_ForceUseRT
        && !m_HDR
        && !m_HasDeferred
        && !m_DynamicResolution
        && (!m_MSAA || PlatformSupportsMSAABB()))
        return kToScreen;

    return kGenerated;
}

CameraStack::CameraStack()
    : m_ForceUseRT(false)
    , m_HDR(false)
    , m_HasDeferred(false)
    , m_MSAA(false)
    , m_DynamicResolution(false)
    , m_HasCommandBuffers(false)
{}

// -------------------------------------------------------------------------------------------
// CameraStackRenderingState


CameraStackRenderingState::CameraStackRenderingState()
    : m_TempInitialEyePair()
    , m_TargetType(kGenerated)
    , m_CurrentCamera(NULL)
    , m_FirstCamera(NULL)
    , m_LastCamera(NULL)
    , m_LastLeftEyeCamera(NULL)
    , m_LastRightEyeCamera(NULL)
    , m_Eye(kStereoscopicEyeDefault)
    , m_ForceUseRT(false)
    , m_HDR(false)
    , m_HasDeferred(false)
    , m_MSAA(false)
    , m_DynamicResolution(false)
    , m_FirstStack(false)
    , m_HasCommandBuffers(false)
{
    memset(m_TempBuffers, 0, sizeof(m_TempBuffers));
}

void CameraStackRenderingState::SetCurrentCamera(Camera* cam)
{
    m_CurrentCamera = cam;
}

void CameraStackRenderingState::UpdateCameraTargetTexture(RenderTexture* rt)
{
    m_CameraTarget.m_TargetTexture = rt;
}

Camera* CameraStackRenderingState::GetCurrentCamera() const
{
    return m_CurrentCamera;
}

RenderTexture* CameraStackRenderingState::GetSrcTextureForImageFilters() const
{
    return GetImageEffectTexture(true);
}

RenderTexture* CameraStackRenderingState::GetDstTextureForImageFilters() const
{
    return GetImageEffectTexture(false);
}

RenderTexture* CameraStackRenderingState::GetStereoImageEffectTexture(bool src) const
{
    IVRDevice* vrDevice = GetIVRDevice();
    bool isLastCameraForAnyEye = (m_CurrentCamera == m_LastLeftEyeCamera) || (m_CurrentCamera == m_LastRightEyeCamera) || IsRenderingLastCamera();

    switch (m_TargetType)
    {
        case kStereo:
            return (src || !isLastCameraForAnyEye) ? m_TempInitialEyePair.GetEyeTexture(m_Eye) : vrDevice->GetActiveEyeTexture(m_Eye);
        case kStereoResolveToEyeTexture:
            return m_TempInitialEyePair.GetEyeTexture(m_Eye);
        case kStereoDirectToEyeTexture:
            return vrDevice->GetActiveEyeTexture(m_Eye);
        default:
            ErrorStringMsg("Unknown camera stack stereo target type: %d.", m_TargetType);
            return NULL;
    }
}

bool IsStereoTargetType(CameraStackRenderingState::TargetType targetType)
{
    return
        (targetType == CameraStackRenderingState::kStereo) ||
        (targetType == CameraStackRenderingState::kStereoResolveToEyeTexture) ||
        (targetType == CameraStackRenderingState::kStereoDirectToEyeTexture);
}

RenderTexture* CameraStackRenderingState::GetImageEffectTexture(bool src) const
{
    if (m_TargetType == kToScreen)
        return NULL;

    if (m_TargetType == kUserDefined)
    {
        // if this is null it implies MRT set via Camera.SetTarget
        if (m_CameraTarget.m_TargetTexture)
            return m_CameraTarget.m_TargetTexture;

        if (m_CurrentCamera == m_LastCamera)
            return NULL;

        // image effects need the real target RT here...
        // return the first MRT color target as that's all
        // we can use for image effects :(
        return m_CurrentCamera->GetCurrentTargetTextureFromRenderBuffer();
    }

    if (IsStereoTargetType(m_TargetType))
    {
        return GetStereoImageEffectTexture(src);
    }

    // if we are the last camera return the target....
    // otherwise return the temp as more rendering is still to happen!
    if (src)
        return m_TempInitialEyePair.GetEyeTexture(m_Eye);

    return IsRenderingLastCamera() ? m_CurrentCamera->GetTargetTexture() : m_TempInitialEyePair.GetEyeTexture(m_Eye);
}

bool CameraStackRenderingState::IsRenderingLastCamera() const
{
    return m_CurrentCamera == m_LastCamera;
}

bool CameraStackRenderingState::IsRenderingFirstCamera() const
{
    return m_CurrentCamera == m_FirstCamera;
}

bool CameraStackRenderingState::ShouldResolveLastTarget() const
{
    int clearFlags = m_CurrentCamera->GetClearFlags();
    return m_TargetType != kToScreen
        && m_TargetType != kUserDefined
        && IsRenderingFirstCamera()
        && (clearFlags == Camera::kDepthOnly || clearFlags == Camera::kDontClear);
}

RenderTexture* CameraStackRenderingState::GetAfterFinalCameraTarget() const
{
    if (m_TargetType == kToScreen)
        return NULL;

    if (IsStereoTargetType(m_TargetType))
    {
        IVRDevice* vrDevice = GetIVRDevice();
        return vrDevice->GetActiveEyeTexture(m_Eye);
    }

    return m_CurrentCamera->GetTargetTexture();
}

void CameraStackRenderingState::SetCurrentlyRenderingEye(StereoscopicEye eye)
{
    m_Eye = eye;
}

RenderTextureDesc CameraStackRenderingState::GetCameraStackTempEyeTextureDesc()
{
    RenderTextureDesc desc;
    int msaa = m_MSAA ? CalculateDesiredAntiAliasingForStack() : 1;
    IVRDevice* vrDevice = GetIVRDevice();
    DebugAssert(vrDevice != NULL);
    RenderTextureDesc eyeDesc = vrDevice->GetDefaultEyeTextureDesc();
    desc.width = RoundfToInt(eyeDesc.width * m_CameraTarget.m_Viewport.width);
    desc.height = RoundfToInt(eyeDesc.height * m_CameraTarget.m_Viewport.height);
    desc.vrUsage = eyeDesc.vrUsage;
    desc.volumeDepth = eyeDesc.volumeDepth;
    desc.dimension = eyeDesc.dimension;

    if (m_TargetType == kStereoResolveToEyeTexture)
    {
        desc.flags |= kRTFlagNoResolvedColorSurface;

        // In the case where we are using DirectX with a camera that uses MSAA
        // and not image effects, we should avoid y flipping the texture.
        // This is because when we resolve the texture, it will not get re flipped.
        // This will also allow us to continue using the fast path for rendering
        // to the device texture.  This change ensures the temp textures and
        // the eye textures will always be in the same orientation.
        if (!GetGraphicsCaps().usesOpenGLTextureCoords)
        {
            if ((eyeDesc.flags & kRTFlagAllowVerticalFlip) == 0)
            {
                desc.flags = SetOrClearFlags(desc.flags, kRTFlagAllowVerticalFlip, false);
            }
        }
    }

    desc.colorFormat = GetRenderTextureColorFormat(m_HDR, m_HasDeferred);
    desc.depthFormat = kDepthFormatMin24bits_Stencil;
    desc.antiAliasing = msaa;
    desc.flags = SetFlags(desc.flags, kRTFlagSRGB);  // this is a dumb way of setting it to 'default' because of the active colorspace check.

    // Depth Compositing needs to be able to read the depth from temp render target
    if (vrDevice->GetDeviceDepthBufferEnabled())
        desc.flags = SetFlags(desc.flags, kRTFlagsAssignTextureForDepth);

    bool useDynamicScale = IsRenderingToScalableBuffer();
    desc.flags = SetOrClearFlags(desc.flags, kRTFlagDynamicallyScalable, useDynamicScale);

    return desc;
}

RenderTextureDesc CameraStackRenderingState::GetCameraStackTempTextureDesc()
{
    RenderTextureDesc desc;
    int msaa = m_MSAA ? CalculateDesiredAntiAliasingForStack() : 1;

    desc.width = RenderBufferManager::kFullSize;
    desc.height = RenderBufferManager::kFullSize;
    desc.colorFormat = GetRenderTextureColorFormat(m_HDR, m_HasDeferred);
    desc.depthFormat = kDepthFormatMin24bits_Stencil;
    desc.antiAliasing = msaa;
    desc.flags = SetFlags(desc.flags, kRTFlagSRGB);      // this is a dumb way of setting it to 'default' because of the active colorspace check.

    bool useDynamicScale = IsRenderingToScalableBuffer();
    desc.flags = SetOrClearFlags(desc.flags, kRTFlagDynamicallyScalable, useDynamicScale);

    return desc;
}

void CameraStackRenderingState::ValidateRenderViewportScale()
{
    IVRDevice* vrDevice = GetIVRDevice();
    if (vrDevice)
    {
        vrDevice->SetRenderViewportScaleEnabled(!m_HasDeferred);
    }
}

RenderTexture* CameraStackRenderingState::GetTargetTexture()
{
    if (m_TargetType == kToScreen)
        return NULL;

    if (m_TargetType == kStereoDirectToEyeTexture)
    {
        IVRDevice* vrDevice = GetIVRDevice();
        return vrDevice->GetActiveEyeTexture(m_Eye);
    }

    if (m_TargetType == kUserDefined)
    {
        // if this is null it implies MRT set via Camera.SetTarget
        return m_CameraTarget.m_TargetTexture;
    }

    // needs a render target (VR + other)
    if (m_TempInitialEyePair.IsEmpty())
    {
        RenderTextureDesc desc;
        if (m_TargetType == kStereo || m_TargetType == kStereoResolveToEyeTexture)
        {
            desc = GetCameraStackTempEyeTextureDesc();
        }
        else
        {
            desc = GetCameraStackTempTextureDesc();
        }

        m_TempInitialEyePair.AllocateTemp(desc);
    }

    return m_TempInitialEyePair.GetEyeTexture(m_Eye);
}

void CameraStackRenderingState::SetupLastEyeCameras(const CameraStack& stack)
{
    // only set the last eye cameras if they are one of the last two cameras together
    // or if one is the last camera by itself.
    // basically, don't set a last eye camera if there is any non-last eye camera between it and the end.

    size_t size = stack.m_Cameras.size();
    Assert(size);

    const Camera* lastCamera = stack.m_Cameras.back();
    m_LastRightEyeCamera = lastCamera->GetStereoTargetEye() == kTargetEyeMaskRight ? lastCamera : NULL;
    m_LastLeftEyeCamera = lastCamera->GetStereoTargetEye() == kTargetEyeMaskLeft ? lastCamera : NULL;

    if (size < 2)
        return;

    const Camera* penultimateCamera = stack.m_Cameras[size - 2];

    if (penultimateCamera->GetStereoEnabled() && lastCamera == m_LastLeftEyeCamera)
    {
        m_LastRightEyeCamera = penultimateCamera;
    }
    else if (penultimateCamera->GetStereoEnabled() && lastCamera == m_LastRightEyeCamera)
    {
        m_LastLeftEyeCamera = penultimateCamera;
    }
}

void CameraStackRenderingState::BeginRenderingStack(const CameraStack& stack, const bool firstStack)
{
    AssertMsg(m_TempInitialEyePair.IsEmpty(), "Render Target RT is already created!");
    m_ForceUseRT = stack.m_ForceUseRT;
    m_HDR = stack.m_HDR;
    m_HasDeferred = stack.m_HasDeferred;
    m_MSAA = stack.m_MSAA;
    m_DynamicResolution = stack.m_DynamicResolution;
    m_CameraTarget = stack.m_CameraTarget;
    m_HasCommandBuffers = stack.m_HasCommandBuffers;

    m_FirstStack = firstStack;
    SetupLastEyeCameras(stack);

    m_TargetType = CalculateCameraTargetType();

    m_FirstCamera = stack.m_Cameras.front();
    m_LastCamera = stack.m_Cameras.back();

    ValidateRenderViewportScale();
}

void CameraStackRenderingState::BeginRenderingOneCamera(Camera& cam)
{
    AssertMsg(m_TempInitialEyePair.IsEmpty(), "Render Target RT is already created!");
    m_FirstStack = true;
    m_ForceUseRT = cam.HasAnyImageFilters() || cam.GetForceIntoRT();

    const TierGraphicsSettings& settings = GetGraphicsSettings().GetTierSettings();
    m_HDR = cam.GetAllowHDR() && settings.useHDR;

    RenderingPath path = cam.CalculateRenderingPath();
    m_HasDeferred = path == kRenderPathPrePass || path == kRenderPathDeferred;
    m_MSAA = m_HasDeferred ? false : (cam.GetAllowMSAA() && CalculateDesiredAntiAliasingForStack() > 1);
    m_DynamicResolution = cam.GetAllowDynamicResolution();
    m_HasCommandBuffers = (cam.GetCommandBufferCount() > 0);

    GetTargetsFromCamera(cam, m_CameraTarget);

    m_FirstCamera = &cam;
    m_CurrentCamera = &cam;
    m_LastCamera = &cam;

    m_TargetType = CalculateCameraTargetType();

    cam.SetCurrentTargetTexture(GetTargetTexture());
}

void CameraStackRenderingState::EndStereoRendering()
{
    if (GetIVRDevice() && IsStereoTargetType(m_TargetType))
    {
        bool resolveMultisampledColorTex = (m_TargetType == kStereoResolveToEyeTexture);
        GetIVRDevice()->ResolveColorAndDepthToEyeTextures(m_TempInitialEyePair, resolveMultisampledColorTex);

        GetIVRDevice()->PostRender(m_CurrentCamera);
        GetIVRDevice()->MirrorStereoTextureToScreen();
    }
}

void CameraStackRenderingState::ReleaseResources()
{
    RenderBufferManager& rbm = GetRenderBufferManager();
    for (int i = 0; i < kBuiltinRTCount; ++i)
    {
        rbm.ReleaseTempBuffer(m_TempBuffers[i]);
        m_TempBuffers[i] = NULL;
    }

    if (!m_TempInitialEyePair.IsEmpty())
    {
        m_TempInitialEyePair.ReleaseTemp();
    }

    //@TODO: track grab passes per camera stack too?
    //ShaderLab::ClearGrabPassFrameState();
}

RenderTexture* CameraStackRenderingState::GetOrCreateBuiltinRT(BuiltinRenderTextureType type, int width, int height, DepthBufferFormat depthFormat, RenderTextureFormat colorFormat, UInt32 flags, RenderTextureReadWrite colorSpace, VRTextureUsage vrUsage, int antiAliasing)
{
    RenderTexture* rt = GetBuiltinRT(type);
    if (rt || type == kBuiltinRTCurrentActive)
        return rt;

    bool useDynamicScale = IsRenderingToScalableBuffer();

    if (useDynamicScale)
    {
        flags |= RenderBufferManager::kRBUseDynamicScale;
    }

    int rtWidth = width;
    int rtHeight = height;
    int volumeDepth = 1;

    if (m_TargetType == kStereo)
    {
        RenderTextureDesc eyeDesc = GetIVRDevice()->GetDefaultEyeTextureDesc();
        bool needsArray = eyeDesc.dimension == kTexDim2DArray;
        rtWidth = width == -1 ? RoundfToInt(eyeDesc.width * m_CameraTarget.m_Viewport.width) : width;
        rtHeight = height == -1 ? RoundfToInt(eyeDesc.height * m_CameraTarget.m_Viewport.height) : height;
        flags |= needsArray ? RenderBufferManager::kRBArray : 0;
        volumeDepth = needsArray ? kStereoscopicEyeCount : 1;
    }

    RenderBufferManager& rbm = GetRenderBufferManager();
    rt = rbm.GetTempBuffer(rtWidth, rtHeight, depthFormat, colorFormat, flags, volumeDepth, colorSpace,  vrUsage, antiAliasing);
    if (!rt)
    {
        WarningStringMsg("Failed to create temporary builtin render texture (type %i size %ix%i color format %i depth format %i)", type, width, height, colorFormat, depthFormat);
    }

    AssertFormatMsg(m_TempBuffers[type] == NULL, "Temporary builtin RT of this type (%i) is already set?", type);
    m_TempBuffers[type] = rt;
    return rt;
}

RenderTexture* CameraStackRenderingState::GetBuiltinRT(BuiltinRenderTextureType type)
{
    AssertFormatMsg(type >= 0 && type < kBuiltinRTCount, "Invalid temporary builtin RT type %i", type);
    AssertMsg(type != kBuiltinRTCameraTarget, "CameraTarget case should be handled by code above GetTempBuffer");
    if (type == kBuiltinRTCurrentActive)
        return RenderTexture::GetActive();
    return m_TempBuffers[type];
}

bool CameraStackRenderingState::IsRenderingToScalableBuffer() const
{
    // First take the camera stacks calculated choice of if it wants to dynamically scale
    // Then override if it set to render to a target that is explicitly set to be dynamically scaling
    bool useDynamicScale = m_DynamicResolution;
    if (m_CameraTarget.m_TargetTexture)
    {
        useDynamicScale = m_CameraTarget.m_TargetTexture->GetUseDynamicScale();
    }
    else if (m_CameraTarget.m_ColorBuffer[0].IsValid())
    {
        useDynamicScale = m_CameraTarget.m_ColorBuffer[0].object->flags & kSurfaceCreateDynamicScale;
    }
    else if (m_CameraTarget.m_DepthBuffer.IsValid())
    {
        useDynamicScale = m_CameraTarget.m_DepthBuffer.object->flags & kSurfaceCreateDynamicScale;
    }
    return useDynamicScale;
}

// -------------------------------------------------------------------------------------------
// AutoScopedCameraStackRenderingState


AutoScopedCameraStackRenderingState::AutoScopedCameraStackRenderingState(Camera& camera)
{
    m_PrevCamera = GetRenderManager().GetCurrentCameraPtr();
    m_PrevCameraStackState = GetRenderManager().GetCurrentCameraStackStatePtr();
    GetRenderManager().SetCurrentCameraAndStackState(&camera, &m_StackState);
    m_StackState.BeginRenderingOneCamera(camera);
}

AutoScopedCameraStackRenderingState::~AutoScopedCameraStackRenderingState()
{
    m_StackState.ReleaseResources();
    GetRenderManager().SetCurrentCameraAndStackState(m_PrevCamera, m_PrevCameraStackState);
}
