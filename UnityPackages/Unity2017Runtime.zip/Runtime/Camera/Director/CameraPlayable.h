#pragma once

#if ENABLE_DIRECTOR_TEXTURE

#include "Runtime/Graphics/Director/TexturePlayable.h"
#include "Runtime/Camera/Camera.h"
#include "CoreScriptingClasses.h"

class CameraPlayable : public TexturePlayable
{
public:

    DEFINE_PLAYABLE(CameraPlayable, GetCoreScriptingClasses().cameraPlayable, TexturePlayable);

    virtual void Process(int outputPort, const FrameData& info, void* processData);

    Camera* GetCamera() const { return m_Camera; }
    void SetCamera(Camera* camera);

protected:

    virtual bool SetInputConnection(Playable* input, int inputPort);

private:

    PPtr<Camera>    m_Camera;
};

BIND_MANAGED_TYPE_NAME(CameraPlayable, UnityEngine_Experimental_Playables_CameraPlayable);

#endif //ENABLE_DIRECTOR_TEXTURE
