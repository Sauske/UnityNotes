#if ENABLE_DIRECTOR_TEXTURE

#include "UnityPrefix.h"
#include "CameraPlayable.h"

#include "Runtime/Camera/Camera.h"
#include "Runtime/Director/Core/PlayableGraph.h"
#include "Runtime/Graphics/CopyTexture.h"
#include "Runtime/Graphics/RenderTexture.h"

CameraPlayable::CameraPlayable(DirectorPlayerType)
    : TexturePlayable(kTexture)
{
}

void CameraPlayable::Process(int outputPort, const FrameData& info, void* processData)
{
    Camera* cam = m_Camera;

    if (cam != NULL)
    {
        RenderTexture* camTex = cam->GetCurrentTargetTexture();
        if (camTex == NULL)
            return;

        RenderTexture* renderTex = GetOutputTexture(camTex->GetWidth(), camTex->GetHeight());

        if (renderTex == NULL)
            return;

        CopyTexture(camTex, renderTex);
    }
}

void CameraPlayable::SetCamera(Camera* camera)
{
    m_Camera = camera;
}

bool CameraPlayable::SetInputConnection(Playable* input, int inputPort)
{
    // Never allow inputs in the this leaf node.
    return false;
}

#endif //ENABLE_DIRECTOR_TEXTURE
